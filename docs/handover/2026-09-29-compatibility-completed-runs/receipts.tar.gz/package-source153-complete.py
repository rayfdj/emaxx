from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).parent
root = p.parents[2]
sha = lambda data: hashlib.sha256(data).hexdigest()
audit = json.loads((p / 'source153-completed-validation-audit.json').read_text())
assert audit['macos'] == {'status': 'passed', 'library': 2912, 'ignored': 2,
                          'cargo': {'bins': 60, 'integration': 39}}
assert audit['linux']['completed_group_passes'] == 2387
assert audit['linux']['status'] == 'failed'
assert audit['linux_frozen']['total_files'] == 519
assert audit['linux_frozen']['total_outcomes'] == 7928
assert audit['linux_frozen']['mismatching_outcomes'] == 1
selected = {}
suffixes = {'.json', '.log', '.txt', '.stdout', '.stderr', '.loaded', '.el', '.py'}
for dirname in ['full-gate-source153', 'linux-source153-full-artifacts',
                'linux-source153-frozen-artifacts', 'linux-source153-reclamation-artifacts']:
    for f in (p / dirname).rglob('*'):
        if f.is_file() and f.suffix in suffixes:
            selected[str(f.relative_to(p))] = f
for f in p.iterdir():
    if f.is_file() and f.suffix in suffixes and (
        f.name.startswith(('source153-full-gate', 'linux-source153-full-failed',
                           'linux-source153-frozen-failed',
                           'source153-ordinary-keymap-translated-sequence-validation'))
        or f.name in ['source153-manifest.json', 'source153-completed-validation-audit.json',
                      'run-source153-full-gate.py', 'package-source153-complete.py',
                      'keymap-translated-sequence-validation.el']
    ):
        selected[f.name] = f
out = root / 'docs/handover/2026-09-29-compatibility-completed-runs'
out.mkdir(exist_ok=False)
files = []
with (out / 'receipts.tar.gz').open('xb') as stream:
    with gzip.GzipFile(fileobj=stream, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, f in sorted(selected.items()):
                data = f.read_bytes()
                info = tarfile.TarInfo(name)
                info.mode = 0o644
                info.size = len(data)
                archive.addfile(info, io.BytesIO(data))
                files.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
with tarfile.open(out / 'receipts.tar.gz', 'r:gz') as archive:
    assert archive.getnames() == [f['path'] for f in files]
    for f in files:
        data = archive.extractfile(f['path']).read()
        assert len(data) == f['bytes'] and sha(data) == f['sha256']
data = (out / 'receipts.tar.gz').read_bytes()
manifest = {
    'source_manifest': 'source153-manifest.json',
    'macos_commit': '82fcb6c9c09d3d66e01e893a600d4d4b6cf19121',
    'linux_commit': '900a6b7f33458297b99282ecde43a8bef7f81896',
    'scope': 'Complete macOS Rust gate: 3,011 passed, two existing ignores. Linux passes nine library groups (2,387 tests), then aborts on native non-LIFO reclamation in lightweight; both Cargo stages remain unexecuted. Linux frozen executes 519 files and 7,928 outcomes; one GNU-side Eglot request timeout differs. The former repeat failure now matches. Linux focused unwind-payload reclamation passes.',
    'new_negative_control': 'Ordinary redefined key-parse returning nil, an integer or a symbol differs from GNU array type validation. Exact original outputs and fixture preserved; production repair still requires validation.',
    'qualification': 'Original Linux runs remain failed. No unexecuted test is counted as passing. Complete Rust artifacts were locally rehashed; their identities and image manifests are portable, not the executables themselves. Frozen Linux binaries are identified by runner provenance. Darwin GNU is source/ABI matched, not the frozen executable. No full-goal or performance completion claim.',
    'archive': {'path': 'receipts.tar.gz', 'bytes': len(data), 'sha256': sha(data)},
    'files': files,
}
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print('Verified', len(files), 'receipts;', len(data), 'archive bytes')
