from pathlib import Path
import gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve()
root=p.parents[2]
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda name:json.loads((p/name).read_text())
rust=read('source170-linux-complete-rust-audit.json')
terminal=read('source170-complete-terminal-audit.json')
frozen=read('source170-linux-frozen-audit.json')
replay=read('source170-mac-retention-replay.json')
assert rust['status']=='passed' and rust['total_passed']==3034
assert terminal['status']=='passed' and terminal['verified_checkpoints']==679
assert frozen['matching_outcomes']==7927 and frozen['mismatching_outcomes']==1 and frozen['successful_processes']==1038
assert frozen['runner_summaries']['emaxx']['unexpected']==0 and frozen['runner_summaries']['oracle']['unexpected']==1
assert replay['exit_code']==0 and replay['binary_unchanged'] and replay['source_unchanged']
out = root / 'docs/handover/2026-09-30-event-root-full-validation'
out.mkdir(exist_ok=False)
suffixes = {'.json', '.log', '.txt', '.stdout', '.stderr', '.py', '.patch', '.el', '.expected'}
files = {}
for directory in ['linux-source170-full-artifacts', 'linux-source170-frozen-artifacts', 'linux-source166-root-provenance-artifacts', 'linux-source166-root-frames-artifacts']:
    for f in (p / directory).rglob('*'):
        if f.is_file() and f.suffix in suffixes:
            files[str(f.relative_to(p))] = f
for f in p.iterdir():
    if f.is_file() and f.suffix in suffixes and (
        f.name.startswith(('source170-full-tty', 'source170-terminal-', 'source166-exact-', 'source170-mac-retention-replay'))
        or f.name in ['source170-linux-complete-rust-audit.json', 'source170-linux-frozen-audit.json',
                      'source170-complete-terminal-audit.json', 'source166-root-provenance-audit.json',
                      'audit-source170-linux-frozen.py', 'package-source170-full-validation.py',
                      'replay-source170-mac-retention.py', 'verify-complete-rust-receipts.py',
                      'verify-complete-terminal-receipts.py', 'source170-manifest.json']
    ):
        files[f.name] = f
inventory = []
with (out / 'receipts.tar.gz').open('xb') as stream:
    with gzip.GzipFile(fileobj=stream, mode='wb', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w') as archive:
            for name, f in sorted(files.items()):
                data = f.read_bytes()
                info = tarfile.TarInfo(name)
                info.mode = 0o644
                info.size = len(data)
                archive.addfile(info, io.BytesIO(data))
                inventory.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
with tarfile.open(out / 'receipts.tar.gz', 'r:gz') as archive:
    assert archive.getnames() == [item['path'] for item in inventory]
    for item in inventory:
        data = archive.extractfile(item['path']).read()
        assert sha(data) == item['sha256'] and len(data) == item['bytes']
data = (out / 'receipts.tar.gz').read_bytes()
record = {
    'status': 'complete source170 validation recorded: Linux Rust and terminal pass, macOS Rust and Linux frozen fail',
    'source_revision': '3d45f96ffba413e1bdf2e41e05d34716de2b726f',
    'linux_rust': rust,
    'terminal': terminal,
    'frozen': {k: v for k, v in frozen.items() if k != 'provenance'},
    'macos_rust': {'status': 'failed', 'passed': 2195, 'failed': 1,
                   'previous_archive': '../2026-09-30-gc-retention-diagnosis/manifest.json',
                   'standalone_original_binary_replay': replay},
    'diagnosis': 'Original source166 Linux failure reproduced three times in its exact retained executable under GDB. Native stack provenance locates the retaining word at eval_call stack offset 0xa8; inspected assembly writes one byte there (ELF RVA 0x97ea7e), leaving stale upper pointer bytes during setq/let execution.',
    'qualification': 'No assertion, selector, timeout, expected outcome or comparison strictness changed. GNU Eglot has one unexpected JSON-RPC timeout; the full frozen result remains failed. The unchanged macOS binary passes a standalone replay, so that pass cannot certify the isolated source173 candidate. Current source172 and source173 repairs are separate pending validation. Darwin GNU matches source/ABI, not its frozen executable. No performance or full-goal completion claim.',
    'archive': {'path': 'receipts.tar.gz', 'bytes': len(data), 'sha256': sha(data)},
    'files': inventory,
}
(out / 'manifest.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: value for key, value in record.items() if key != 'files'}, indent=2))
