from pathlib import Path
import hashlib,json,re
p=Path(__file__).parent
root=p.parents[2]
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
head='3d45f96ffba413e1bdf2e41e05d34716de2b726f'
fr=next((p/'linux-source170-frozen-artifacts').glob('*/compat/frozen-*'))
s=json.loads((fr/'summary.json').read_text())
lock=json.loads((root/'compat/oracle.lock.linux.json').read_text())
manifest=root/'compat/oracle_tests_all_linux.txt'
expected={};current=None
for line in manifest.read_text().splitlines():
 match=re.fullmatch(r'(\S+): discovered=(\d+) selected=(\d+)',line)
 if match:
  current=match[1];expected[current]={'discovered':int(match[2]),'selected':int(match[3]),'names':[]}
 elif line.strip():expected[current]['names'].append(line.strip())
assert len(expected)==519 and sum(x['selected'] for x in expected.values())==7928
assert s['mode']=='frozen' and s['name_filter'] is None and s['selector']==lock['selector_default']
assert len(s['files'])==len(set(s['files']))==519 and set(s['files'])==set(expected)
assert s['frozen_manifest']['sha256']==sha(manifest)
prov=s['provenance'];assert prov['subject_git_head']==head and not prov['subject_git_dirty']
assert prov['oracle_sha256']==lock['emacs_binary_sha256'] and prov['oracle_repo_commit']==lock['emacs_repo_commit']
runner_counts={r:{k:0 for k in ['total','passed','failed','skipped','unexpected']} for r in ['emaxx','oracle']}
matching=0;mismatching=0;processes=0;failures=[]
for file,inv in expected.items():
 directory=(fr/file).with_suffix('.compat')
 comp=json.loads((directory/'comparison.json').read_text())
 matching+=comp['matching_outcomes'];mismatching+=comp['mismatching_outcomes']
 assert comp['matching_outcomes']+comp['mismatching_outcomes']==inv['selected']
 reports={}
 for runner in runner_counts:
  report=json.loads((directory/(runner+'.json')).read_text());reports[runner]=report
  assert report['file_status']=='loaded' and report['file_error'] is None and report['selector']==s['selector']
  assert len(report['discovered_tests'])==inv['discovered'] and sorted(report['selected_tests'])==sorted(inv['names'])
  results=report['results'];assert sorted(x['name'] for x in results)==sorted(inv['names'])
  observed={k:sum(x['status']==k for x in results) for k in ['passed','failed','skipped']}
  observed.update(total=len(results),unexpected=sum(not x['expected'] for x in results));assert observed==report['summary']
  for k,n in observed.items():runner_counts[runner][k]+=n
  process=json.loads((directory/(runner+'.execution.json')).read_text())['process']
  assert process['exit_code']==0 and process['test_started'] and not process['timed_out'] and process['timeout_phase'] is None
  processes+=1
 if not comp['matches']:
  failures.append({'file':file,'issues':comp['issues'],'execution_issues':comp['execution_issues'],
                   'unexpected_results':{r:[x for x in reports[r]['results'] if not x['expected']] for r in reports}})
 else:assert not comp['issues'] and not comp['execution_issues']
assert runner_counts==s['runner_summaries'] and (matching,mismatching,processes)==(7927,1,1038)
assert sorted(f['file'] for f in failures)==sorted(s['mismatches'])==sorted(s['unsuccessful_files'])

result={'status':'frozen outcome comparison failed','source_commit':head,'run_id':36665843610,'files':len(expected),'matching_outcomes':matching,'mismatching_outcomes':mismatching,'successful_processes':processes,'runner_summaries':runner_counts,'failures':failures,'provenance':prov,'qualification':'All original frozen files, selectors and raw outcomes audited. An unexpected GNU outcome remains an actual comparison failure; no result is normalized or waived. This does not clear the separate macOS Rust reclamation failure and makes no performance claim.'}
with (p/'source170-linux-frozen-audit.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['provenance','failures']},indent=2))
