from pathlib import Path
import hashlib
import json
import os
import sys

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/gc/emaxx'
sys.path.insert(0, str(root / 'tools'))
from diagnose_rust_gate import execute
from serial_grouped_gate import gate

sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
manifest = json.loads((p / 'source170-manifest.json').read_text())
assert all(sha(root / name) == digest for name, digest in manifest.items())
summary = json.loads((p / 'full-gate-source170/summary.json').read_text())
binary = Path(summary['test_binary']['path'])
assert sha(binary) == summary['test_binary']['sha256']
environment = gate.gate_environment(True)
overrides = {
    'EMAXX_GC_VERIFY': '1',
    'EMAXX_FIXTURE_IMAGE_DIR': str(root / 'target/grouped-gate/fixture-images'),
    'EMAXX_GNU_SOURCE_DIRECTORY': str(p.parent / 'recovered-2026-09-30/emacs'),
    'EMAXX_DUMP_SOURCE_DIRECTORY': str(p.parent / 'recovered-2026-09-30/emacs'),
    'EMACS_TEST_DIRECTORY': str(p.parent / 'recovered-2026-09-30/emacs/test'),
}
environment.update(overrides)
command = [str(binary), 'suspended_bytecode_retains_operand_and_unwind_roots', '--test-threads', '1']
record = {'binary_sha256': sha(binary), 'working_directory': str(root),
          'environment_override': overrides, 'template': True}
os.chdir(root)
record.update(execute(command, environment, p / 'source170-mac-retention-replay.log'))
record['binary_unchanged'] = sha(binary) == summary['test_binary']['sha256']
record['source_unchanged'] = all(sha(root / name) == digest for name, digest in manifest.items())
with (p / 'source170-mac-retention-replay.json').open('x') as f:
    json.dump(record, f, indent=2)
print(json.dumps(record, indent=2), flush=True)
