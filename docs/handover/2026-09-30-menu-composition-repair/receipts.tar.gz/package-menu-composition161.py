from pathlib import Path
import gzip, hashlib, io, json, re, tarfile
p=Path(__file__).parent; root=p.parents[2]
sha=lambda data:hashlib.sha256(data).hexdigest()
for mode in ['debug','release']:
    result=json.loads((p/f'source161-{mode}-selected-inventory-check.json').read_text())
    assert result['expected']==72 and result['process_exit_code']==0
    assert result['summary']=='test result: ok. 72 passed; 0 failed; 0 ignored;'
for stage in ['check','fmt','clippy','diff','ordinary-build','ordinary-image']:
    result=json.loads((p/f'source161-{stage}-result.json').read_text())
    assert result['exit_code']==0 and result['source_unchanged']
comparisons=[json.loads(f.read_text()) for f in p.glob('source161-ordinary-*-comparison.json')]
assert len(comparisons)==17 and sum(c['passed'] for c in comparisons)==15
terminal=json.loads((p/'source155-full-ttydiff-result.json').read_text())
assert terminal['exit_code']==1 and terminal['complete_start_inventory'] and terminal['started_scenarios']==223
raw=(p/'source155-full-ttydiff.log').read_text()
divergences=re.findall(r'DIVERGE \[([^\]]+)\]: 1 terminal difference\(s\)\n  row 0:\n    gnu  : \'File Edit Options Buffers Tools Table Org Text Help\'\n    emaxx: \'File Edit Options Buffers Tools Text Help\'',raw)
assert len(divergences)==17 and raw.count('DIVERGE [')==17
for tag,expected in [('source139',True),('source155',False),('source161',True)]:
    assert json.loads((p/f'{tag}-terminal-org-terminal-result.json').read_text())['passed']==expected
selected={}; suffixes={'.json','.log','.txt','.stdout','.stderr','.el','.expected','.py','.patch'}
names={'check-menu-composition.py','static-menu-composition.py','test-menu-composition.py','release-menu-composition.py','build-menu-composition.py','compare-continuation-fixtures.py','replay-org-terminal.py','run-source155-full-tty.py','package-menu-composition161.py','keymap-org-menu.el','keymap-live-input.el','keymap-live-sequence.el'}
prefixes=('source159','source161','source155-full-tty','source139-terminal-org-terminal','source155-terminal-org-terminal','source139-retained-keymap-live-input')
for f in p.iterdir():
    if f.is_file() and f.suffix in suffixes and (f.name.startswith(prefixes) or f.name in names):
        if f.name.startswith(('source161-full-gate','source161-full-tty')):continue
        selected[f.name]=f
out=root/'docs/handover/2026-09-30-menu-composition-repair';out.mkdir(exist_ok=False)
files=[]
with (out/'receipts.tar.gz').open('xb') as stream:
    with gzip.GzipFile(fileobj=stream,mode='wb',filename='',mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as archive:
            for name,f in sorted(selected.items()):
                data=f.read_bytes();info=tarfile.TarInfo(name);info.mode=0o644;info.size=len(data)
                archive.addfile(info,io.BytesIO(data));files.append({'path':name,'bytes':len(data),'sha256':sha(data)})
with tarfile.open(out/'receipts.tar.gz','r:gz') as archive:
    assert archive.getnames()==[f['path'] for f in files]
    for f in files:
        data=archive.extractfile(f['path']).read();assert len(data)==f['bytes'] and sha(data)==f['sha256']
data=(out/'receipts.tar.gz').read_bytes()
record={'published_commit':'d9caac1e9535b97438cdcb52abe7d3cfde434f7b','source_manifest':'source161-manifest.json',
'scope':'Render actual composed menu maps through unchanged GNU keymap-canonicalize. Root active maps and accumulated entries through Lisp callbacks. Existing caption and coordinate assertions remain unchanged, with their GNU early Lisp owner loaded.',
'validation':'Strict checks, 72 debug and 72 release selected controls, 15 ordinary exact GNU comparisons and the unchanged org-open terminal scenario pass. Full source161 Rust/Linux frozen/terminal runs are active and excluded from this package.',
'previous_terminal':{'result':terminal,'divergences':divergences,'qualification':'All 223 default scenarios were started; 17 diverged on the Table/Org menu row. Each divergent scenario stops at its first differing checkpoint, so later checkpoints within those scenarios are unexecuted. The 17 failures remain failed.'},
'failures_preserved':'Source159 passes 71 selected debug controls and fails one coordinate control in a bare interpreter. Source161 loads the real GNU owner in that existing test, preserving expected outcomes. Source155 focused and complete terminal failures remain.',
'known_preexisting_limits':'Two additional ordinary probes mutate later key-sequence events in collecting prefix callbacks. Source161 differs from GNU on both. The original vector case also fails retained main source139; expanded cases cover strings, unibyte Meta, Lucid and translated input. Separate keymap architecture work addresses the eager sequence copy. Initial non-array sequence rejection also remains a documented preexisting issue for this production candidate.',
'qualification':'Darwin oracle is source/ABI matched, not the frozen executable. This checkpoint is not full goal or performance completion.',
'archive':{'path':'receipts.tar.gz','bytes':len(data),'sha256':sha(data)},'files':files}
(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
print('Verified',len(files),'menu repair receipts;',len(data),'archive bytes')
