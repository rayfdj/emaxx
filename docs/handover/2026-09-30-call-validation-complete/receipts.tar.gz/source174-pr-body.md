Keymaps now use their actual Lisp cons and char-table storage. Lookup, prefix redefinition, collecting menu filters, native access and garbage collection observe the same graph. This removes the private record maps, snapshots, binding caches and permanent roots. Queued file events retain their live callbacks across collection, and TLS peer queries build independent mutable reports from the live session.

The evaluator classifies subrs once and reads arity from the authoritative native descriptor. This removes duplicated optional metadata and a second function decode before special-form dispatch. Exact-binary diagnosis tied the earlier reclamation failure to stale pointer bytes beside a one-byte metadata spill; the original survival and reclamation assertions remain unchanged.

Current source: `178fdf37d529a55e0fa1cf748faf668612a1d454` (source174). Strict compiler, formatting, warnings-denied Clippy and diff checks pass, along with **395 gate / 395 release controls** and **12 ordinary exact GNU comparisons**. All 345 compiled/test inputs match the isolated macOS checkout. [Audited receipts](https://github.com/rayfdj/emaxx/blob/runtime-char-tables/docs/handover/2026-09-30-combined-call-repair/manifest.json) retain raw outcomes and artifact identities.

Complete validation is in progress:

- [Linux full Rust gate](https://github.com/rayfdj/emaxx/actions/runs/36680285969)
- [Linux full frozen compatibility](https://github.com/rayfdj/emaxx/actions/runs/36680294974)
- Complete macOS Rust gate and unchanged 223-scenario terminal inventory.

Keep this PR in draft until the combined candidate completes validation. Earlier reclamation failures and the source170 full comparison's GNU Eglot timeout remain preserved. The successful affected-file Eglot replay does not reclassify that full run. Darwin GNU matches the source/native ABI but differs from the frozen executable pin. No pin, existing assertion, selector, expected outcome, ignore or timeout changes in this candidate. The input-decoding draft is separate and unmerged; allocation accounting, representation completion, final audit and locked performance criteria remain open.
