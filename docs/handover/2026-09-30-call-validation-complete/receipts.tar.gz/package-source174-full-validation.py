from pathlib import Path
import gzip
import hashlib
import io
import json
import subprocess
import tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
read = lambda name: json.loads((p / name).read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
rust = {platform: read("source174-" + platform + "-complete-rust-audit.json")
        for platform in ["macos", "linux"]}
assert rust["macos"]["total_passed"] == 3023 and rust["linux"]["total_passed"] == 3035
assert all(item["status"] == "passed" and item["native_artifact_identity"] == "passed" for item in rust.values())
names = {platform: read("source174-" + platform + "-rust-name-audit.json")
         for platform in rust}
assert names["macos"]["raw_names_verified"] == 2926
assert names["linux"]["raw_names_verified"] == 2934
frozen = read("source174-linux-complete-frozen-audit.json")
assert frozen["status"] == "matched" and frozen["verified_files"] == 519
assert frozen["verified_outcomes"] == 7928 and frozen["successful_processes"] == 1038
terminal = read("source174-complete-terminal-audit.json")
assert terminal["status"] == "passed" and terminal["scenarios"] == 223
assert terminal["screen_comparisons"] == 651 and terminal["filesystem_comparisons"] == 28
supervisor = read("source174-full-local-supervisor-result.json")
assert supervisor["source_unchanged"] and all(code == 0 for code in supervisor["exit_codes"].values())
inputs = {**read("source174-manifest.json"), **read("source174-supplemental-inputs.json")}
assert len(inputs) == 349
assert all(sha((root / name).read_bytes()) == digest for name, digest in inputs.items())
head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip()
heads = list(dict.fromkeys(["178fdf37d529a55e0fa1cf748faf668612a1d454", head]))
for revision in heads:
    data = subprocess.check_output(["git", "archive", revision, "--", *inputs], cwd=root)
    with tarfile.open(fileobj=io.BytesIO(data)) as archive:
        assert all(sha(archive.extractfile(name).read()) == digest for name, digest in inputs.items())
equivalence = {"verified_commits": heads, "verified_inputs": len(inputs),
               "qualification": "345 original Rust/test/build inputs plus four supplemental embedded files. Supplemental files were checked after the initial run manifests; all match the recorded base."}
with (p / "source174-published-source-equivalence.json").open("x") as stream:
    json.dump(equivalence, stream, indent=2)

files = {}
suffixes = {".json", ".log", ".txt", ".stdout", ".stderr", ".loaded", ".py", ".patch", ".el", ".expected", ".md", ".d"}
for directory in ["full-gate-source174", "linux-source174-full-artifacts", "linux-source174-frozen-artifacts"]:
    for f in (p / directory).rglob("*"):
        if f.is_file() and f.suffix in suffixes:
            files[str(f.relative_to(p))] = f
helpers = {"package-source174-full-validation.py", "verify-complete-rust-receipts.py",
           "verify-source174-macos-rust.py", "verify-complete-frozen-receipts.py",
           "verify-complete-terminal-receipts.py", "audit-source174-linux-names.py",
           "audit-source174-linux-names-line-attempt.py", "audit-source174-macos-names.py",
           "run-source174-full-gate.py", "run-source174-full-tty.py",
           "source-dependency-coverage-audit.json"}
for f in p.iterdir():
    if f.is_file() and f.suffix in suffixes and (f.name.startswith("source174-") or f.name in helpers):
        files[f.name] = f

out = root / "docs/handover/2026-09-30-call-validation-complete"
out.mkdir(exist_ok=False)
inventory = []
with (out / "receipts.tar.gz").open("xb") as stream:
    with gzip.GzipFile(fileobj=stream, mode="wb", filename="", mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w") as archive:
            for name, f in sorted(files.items()):
                data = f.read_bytes()
                info = tarfile.TarInfo(name)
                info.mode = 0o644
                info.size = len(data)
                archive.addfile(info, io.BytesIO(data))
                inventory.append({"path": name, "bytes": len(data), "sha256": sha(data)})
with tarfile.open(out / "receipts.tar.gz", "r:gz") as archive:
    assert archive.getnames() == [item["path"] for item in inventory]
    for item in inventory:
        data = archive.extractfile(item["path"]).read()
        assert len(data) == item["bytes"] and sha(data) == item["sha256"]
data = (out / "receipts.tar.gz").read_bytes()
record = {
    "status": "source174 complete Rust gates, Linux frozen comparison and macOS terminal inventory pass",
    "production_commit": "178fdf37d529a55e0fa1cf748faf668612a1d454",
    "source_equivalence": equivalence, "rust": rust, "raw_name_audits": names,
    "linux_frozen": frozen, "terminal": terminal,
    "selected_validation": "395 gate and 395 release controls, 12 ordinary exact GNU comparisons and all strict checks pass; original combined-call archive retains their evidence.",
    "prior_failures": "Source166/source170 reclamation failures and source170's full GNU Eglot timeout remain failed historical runs. Both original reclamation assertions now pass in these complete Rust gates. Supplemental ordinary input probes still differ and are preserved; the separate reader draft is not production.",
    "artifact_qualification": "Post-run binaries and remaining fixture images were rehashed; their bytes are retained locally and omitted from this portable text archive. Remaining images are not a transcript of individual test image use. Linux frozen executable identities come from runner provenance. Four embedded files were absent from the original pre-run source manifests and are covered by the later supplemental audit.",
    "qualification": "All full Rust inventories, raw names, results and native identities pass. All original Linux frozen files, selectors, expected outcomes and process statuses match; existing expected failures/skips remain distinct. All default terminal checkpoints match source/ABI-matched GNU, which is not the frozen Darwin executable. No oracle pin, ignore, selector, timeout or survival/reclamation contract was relaxed. The dump test now asserts real Lisp sharing instead of removed private-record bookkeeping. Representation completion, reader integration, physical allocation accounting, final audit and locked performance parity remain open. This is a merge checkpoint, not completion of the full goal.",
    "archive": {"path": "receipts.tar.gz", "bytes": len(data), "sha256": sha(data)}, "files": inventory,
}
(out / "manifest.json").write_text(json.dumps(record, indent=2) + "\n")
print("Verified", len(inventory), "closed receipts;", len(data), "archive bytes")
