from pathlib import Path
import json,subprocess,sys,time
p=Path(__file__).parent.resolve();root=p.parent/'recovered-2026-09-30/gc/emaxx'
def wait_result(name):
 deadline=time.monotonic()+7200
 while time.monotonic()<deadline:
  try:d=json.loads((p/name).read_text())
  except (FileNotFoundError,json.JSONDecodeError):time.sleep(3);continue
  if d.get('exit_code')!=0:raise RuntimeError(f'{name} did not pass: {d}')
  return d
 raise RuntimeError(f'Timed out waiting for {name}; no test result inferred')
for mode in ['debug','release']:
 wait_result(f'source170-{mode}-selected-result.json')
 subprocess.run([sys.executable,str(p/'test-keymap-command-loops.py'),'source170',mode,str(root)],check=True)
wait_result('source170-ordinary-image-result.json')
script=(p/'compare-continuation-fixtures.py').read_text().replace('/private/tmp/emaxx-runtime-gnu-20260928',str(p.parent/'recovered-2026-09-30/emacs'))
comparison=p/'compare-recovered-continuation-fixtures.py'
with comparison.open('x') as f:f.write(script)
names='keymap-parameterized-char-table keymap-prefix-filter-count keymap-filter-effects keymap-prefix-precedence keymap-lookup-argument-order keymap-filter-error-unbound keymap-translated-sequence-validation unwind-protected-payloads unwind-native-payloads unwind-payload-reclamation keymap-description-context keymap-menu-fallback keymap-menu-case-table-order string-make-multibyte-identity keymap-org-menu keymap-anonymous-reclamation keymap-sequence-types keymap-symbol-stores keymap-live-input keymap-live-sequence key-binding-live-prefix key-binding-filter-semantics keymap-rebound-prefix-commands keymap-redefined-prefix keymap-dispatch-live-bindings keymap-special-events'.split()
subprocess.run([sys.executable,str(comparison),'source170',str(root),*names],check=True)
script=(p/'run-focused-tls-process-gc.py').read_text().replace('source166-focused-tls-','source170-focused-tls-').replace("r/'validation/emaxx/target/frame-validation/release/emaxx'", "r/'gc/emaxx/target/frame-validation/release/emaxx'")
comparison=p/'run-source170-tls-process-gc.py'
with comparison.open('x') as f:f.write(script)
subprocess.run([sys.executable,str(comparison)],check=True)
tls=json.loads((p/'source170-focused-tls-process-gc-comparison.json').read_text())
expected=(root/'tests/fixtures/process-tls-gc.expected').read_text().rstrip('\n')
assert all(r['exit_code']==0 and not r['timed_out'] and r['inputs_unchanged'] and r['stdout']==expected and r['stderr']=='' for r in tls.values())
with (p/'source170-ordinary-comparison-suite.json').open('x') as f:json.dump({'status':'passed','ordinary_exact_gnu_comparisons':27,'fixtures':names+['process-tls-gc'],'qualification':'Complete selected fixture suite only; no frozen, full Rust, terminal or performance claim.'},f,indent=2)
print('All 27 ordinary exact GNU comparisons passed.',flush=True)
