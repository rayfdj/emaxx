from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).parent.resolve();w=p.parent/'recovered-2026-09-30/diagnostic/emaxx'
tag='source166-root-trace'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
inputs={str(f.relative_to(w)):sha(f) for f in sorted((w/'src').rglob('*.rs'))}
with (p/(tag+'-manifest.json')).open('x') as f:json.dump(inputs,f,indent=2)
with (p/(tag+'.patch')).open('xb') as f:f.write(subprocess.check_output(['git','diff','--binary'],cwd=w))
for label,cmd in [('check',['cargo','check','--locked','--all-targets','--all-features']),('clippy',['cargo','clippy','--locked','--all-targets','--all-features','--','-D','warnings']),('fmt',['cargo','fmt','--all','--','--check'])]:
 env={'CARGO_TARGET_DIR':str(w/'target/frame-validation'),'CARGO_BUILD_JOBS':'1'}
 with (p/(tag+'-'+label+'-command.json')).open('x') as f:json.dump({'command':cmd,'working_directory':str(w),'environment_override':env},f,indent=2)
 start=time.monotonic()
 with (p/(tag+'-'+label+'.log')).open('x') as log:r=subprocess.run(cmd,cwd=w,env={**os.environ,**env},stdout=log,stderr=subprocess.STDOUT,timeout=1800)
 result={'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'source_unchanged':all(sha(w/f)==h for f,h in inputs.items())}
 with (p/(tag+'-'+label+'-result.json')).open('x') as f:json.dump(result,f,indent=2)
 print(label,result,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
