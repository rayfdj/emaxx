from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
r = p.parent / 'recovered-2026-09-30'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read('source170-manifest.json')
assert len(manifest) == 343
for checkout in [root, r / 'gc/emaxx']:
    assert all(sha((checkout / name).read_bytes()) == digest for name, digest in manifest.items())
for stage in ['check', 'clippy', 'fmt', 'diff', 'debug-build', 'release-build', 'ordinary-build', 'ordinary-image']:
    result = read(f'source170-{stage}-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
for mode in ['debug', 'release']:
    selected = []
    for kind, expected in [('selected', 413), ('command-loops', 69)]:
        tag = f'source170-{mode}-{kind}'
        result = read(tag + '-result.json')
        command = read(tag + '-command.json')
        assert result['exit_code'] == 0 and result['source_unchanged']
        inventory = command['selected_inventory']
        assert len(inventory) == expected
        log = (p / (tag + '.log')).read_text()
        summaries = re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', log, re.M)
        assert summaries[-1] == ('ok', str(expected), '0', '0')
        starts = list(re.finditer(r'^test (\S+) \.\.\. ', log, re.M))
        assert sorted(match[1] for match in starts) == sorted(inventory)
        # --nocapture allows each test to print between its name and verdict.
        # The runner is serial, so every complete block must end in `ok`.
        for index, match in enumerate(starts):
            end = starts[index + 1].start() if index + 1 < len(starts) else log.rindex('test result:')
            assert log[match.end():end].strip().endswith('ok'), match[1]
        assert sha((p / f'source170-{mode}-libtest').read_bytes()) == command['binary_sha256']
        selected.extend(inventory)
    assert len(set(selected)) == 482
suite = read('source170-ordinary-comparison-suite.json')
assert suite['status'] == 'passed' and suite['ordinary_exact_gnu_comparisons'] == 27
for fixture in suite['fixtures']:
    tag = 'source170-focused-tls-process-gc' if fixture == 'process-tls-gc' else f'source170-ordinary-{fixture}'
    comparison = read(tag + '-comparison.json')
    if fixture != 'process-tls-gc':
        assert comparison['passed'] and comparison['exact_match']
    results = comparison.get('outcomes', comparison)
    for editor in ['gnu', 'emaxx']:
        result = results[editor]
        assert result['exit_code'] == 0 and not result['timed_out'] and result['inputs_unchanged']
        assert not (p / f'{tag}-{editor}.stderr').read_bytes()
    assert (p / f'{tag}-gnu.stdout').read_bytes() == (p / f'{tag}-emaxx.stdout').read_bytes()
for name, metadata in read('source170-ordinary-artifacts.json').items():
    assert sha(Path(name).read_bytes()) == metadata['sha256']
    assert sha(Path(metadata['immutable_copy']).read_bytes()) == metadata['sha256']
mac = read('source166-recovered-complete-rust-audit.json')
assert mac['status'] == 'passed' and mac['total_passed'] == 3019
for metadata in read('full-gate-source166-recovered/retained-inputs/manifest.json')['files']:
    # This receipt's paths are relative to the retained-inputs directory.
    assert sha((p / 'full-gate-source166-recovered/retained-inputs' / metadata['artifact']).read_bytes()) == metadata['sha256']

out = root / 'docs/handover/2026-09-30-event-roots'
out.mkdir(exist_ok=False)
suffixes = {'.json', '.log', '.txt', '.stdout', '.stderr', '.py', '.patch', '.el', '.expected', '.loaded', '.apparmor'}
files = {}
prefixes = ('source167-', 'source168-', 'source169-', 'source170-', 'source166-recovered-', 'source166-focused-tls-', 'source166-tls-', 'source166-root-trace')
for f in p.iterdir():
    if not f.is_file() or f.suffix not in suffixes:
        continue
    if f.name.startswith('source170-') and ('full-gate' in f.name or 'full-tty' in f.name or 'terminal-' in f.name):
        continue  # Active full-run receipts are packaged only after completion.
    if f.name.startswith(prefixes) or f.name in {
        'source166-manifest.json', 'package-source170-checkpoint.py',
        'check-event-roots.py', 'static-event-roots.py', 'test-event-roots.py', 'release-event-roots.py',
        'build-event-roots.py', 'run-command-loop-controls.py', 'queue-source170-comparisons.py',
        'run-source170-tls-process-gc.py', 'compare-recovered-continuation-fixtures.py',
        'verify-complete-rust-receipts.py', 'run-source166-recovered-full-gate.py',
        'check-root-trace.py', 'check-root-trace2.py', 'check-root-trace3.py',
    }:
        files[f.name] = f
for directory in ['full-gate-source166-recovered', 'linux-source166-root-trace-artifacts', 'weak-root-trace3-preparation']:
    for f in (p / directory).rglob('*'):
        if f.is_file() and f.suffix in suffixes:
            files[str(f.relative_to(p))] = f
for name in ['oracle-ready.json', 'emacs-build.json', 'native-abi-check.log', 'gnu-build.log']:
    files['recovered-gnu/' + name] = r / name
inventory = []
with (out / 'receipts.tar.gz').open('xb') as stream:
    with gzip.GzipFile(fileobj=stream, mode='wb', filename='', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w') as archive:
            for name, f in sorted(files.items()):
                data = f.read_bytes()
                info = tarfile.TarInfo(name)
                info.mode = 0o644
                info.size = len(data)
                archive.addfile(info, io.BytesIO(data))
                inventory.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
with tarfile.open(out / 'receipts.tar.gz', 'r:gz') as archive:
    assert archive.getnames() == [f['path'] for f in inventory]
    for f in inventory:
        data = archive.extractfile(f['path']).read()
        assert sha(data) == f['sha256'] and len(data) == f['bytes']
data = (out / 'receipts.tar.gz').read_bytes()
record = {
    'status': 'selected validation passed; complete source170 validation pending',
    'base_commit': read('source170-base.json')['commit'],
    'source_inputs': len(manifest), 'debug_passed': 482, 'release_passed': 482,
    'ordinary_exact_gnu_comparisons': 27,
    'previous_source166_mac': mac,
    'previous_source166_terminal': read('source166-recovered-terminal-interruption.json'),
    'preserved_failures': [
        'Source168 test compilation failed on two missing borrows.',
        'Source169 passed 412 controls and failed its new queue test before the owned error report was consumed; source170 keeps the live-report assertion and checks release after consumption.',
        'Source166 ordinary signal and TLS-GC probes differ from source/ABI-matched GNU.',
        'The preliminary TLS probe also differs after gnutls-deinit; this additional difference is unresolved.',
        'Source166 complete Linux Rust and frozen failures remain in the previous failure archive.',
        'Linux instrumented run 36664022033 passes the original reclamation assertion, but its child captures the trace output. The changed binary does not clear the ordinary failure. Revised trace logging is diagnostic only.',
    ],
    'qualification': 'Selected passes do not certify full compatibility, a fixed cause of earlier Linux failures, or performance. GNU is source/ABI matched, not the Darwin frozen executable. No existing test assertion, inventory, timeout or expectation is weakened.',
    'archive': {'path': 'receipts.tar.gz', 'bytes': len(data), 'sha256': sha(data)},
    'files': inventory,
}
(out / 'manifest.json').write_text(json.dumps(record, indent=2) + '\n')
print('Audited and archived', len(inventory), 'receipts;', len(data), 'bytes.')
