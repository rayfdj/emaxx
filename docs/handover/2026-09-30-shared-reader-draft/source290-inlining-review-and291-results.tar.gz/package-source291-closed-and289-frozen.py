from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
out = p.parents[2] / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda n: json.loads((p / n).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected', '.h', '.apparmor', '.loaded'}
selected = read('source291-selected-audit.json')
perf = read('vm-inline-performance-audit.json')
assert selected['status'] == 'passed' and selected['source_inputs_verified'] == 528
assert perf['status'] == 'all 288 processes and actual results/modes verified'
for audit in (selected, perf):
    assert all(sha(Path(n).read_bytes()) == h for n, h in audit['evidence_files'].items())
files = {f.name: f for f in p.iterdir() if f.is_file() and f.suffix in allowed and (f.name.startswith(('source291-', 'vm-inline-performance-', 'inline-selection-', 'inline-performance-sequence-', 'inline-sequence-')) or f.suffix == '.py' and 'source291' in f.name)}
for tag in ('source289', 'source290', 'source291'):
    for directory in sorted(p.glob(tag + '-vm-inline-pilot-*')) + [p / (tag + '-core-native')]:
        for f in directory.rglob('*'):
            if f.is_file() and f.suffix in allowed:
                files[str(f.relative_to(p))] = f
for n in ['source290-selected-closed-audit.json', 'source290-application-decision.json', 'source290-application-review.json', 'source290-two-cohort-descriptive-review.json', 'source290-applied-commit.json', 'source290-applied-push.json', 'source290-profile-followup-review.json', 'source290-profile-scope-qualification.json', 'source290-linux-rust-launch.json', 'source290-linux-frozen-launch.json', 'source290-linux-rust-dispatch.json', 'source290-linux-frozen-dispatch.json', 'dispatch-source290-linux.py', 'measure-vm-inline.py', 'audit-vm-inline-performance.py', 'finish-inline-performance.py', 'compare-vm-dispatch-fixtures.py', 'printer-varied-v3-293638f0.el', 'printer-varied-v3-gnu.stdout', 'package-source196-failure-and197-results.py', Path(__file__).name]:
    files[n] = p / n
package('source290-inlining-review-and291-results', files, dict(status='closed source291 selected validation and complete three-way diagnostic; source290 applied', selected=selected, performance=perf, application_review=read('source290-application-review.json'), qualification='All 288 new processes compare source289/source290/source291; the performance audit qualification mistakenly names the predecessor source286/288/289 cohort. Its actual commands, manifests, samples and ratios identify 289/290/291. This explicit correction preserves that original receipt. The earlier 192-process cohort and held decision remain in the source290-integer-vm-performance archive. Both cohorts inform source290 application b870a848. Source291 remains unapplied. Selected passes and diagnostic gains do not establish full validation or calibrated GNU parity.', goal_complete=False))
audit = read('source289-linux-frozen-raw-integrity-audit.json')
assert audit['status'] == 'passed' and audit['outcomes'] == 7928
files = {}; excluded = []
for f in (p / 'source289-linux-frozen-artifacts').rglob('*'):
    if not f.is_file():
        continue
    name = str(f.relative_to(p))
    if f.suffix in allowed or f.name == 'Makefile':
        files[name] = f
    else:
        excluded.append(dict(path=name, bytes=f.stat().st_size, sha256=sha(f.read_bytes())))
for f in p.iterdir():
    if f.is_file() and f.suffix in allowed and f.name.startswith('source289-linux-frozen-'):
        files[f.name] = f
for n in ['audit-source289-linux-frozen.py', 'verify-complete-frozen-receipts279.py', 'source289-manifest.json', 'package-source196-failure-and197-results.py', Path(__file__).name]:
    files[n] = p / n
package('source289-complete-linux-frozen', files, dict(status='closed full source289 Linux frozen validation', audit=audit, excluded_binaries=excluded, qualification='All 519 files, 7928 equal outcomes and 1038 successful processes verify, with execution and retained oracle hashes. Each editor has 7670 passes, 47 expected failures and 211 skips. No category is relabeled. This certifies this tested source289 scope, not source290, macOS, performance or full-goal completion.', goal_complete=False))
launch = dict(runtime_source='source290', source_commit='b870a848be77dd7e99931dd3c6efd65c2f3183bc', linux=[read('source290-linux-' + kind + '-launch.json') for kind in ('rust', 'frozen')], macos='unstarted', goal_complete=False)
with (out / 'source290-full-validation-launch.json').open('x') as f:
    json.dump(launch, f, indent=2)
    f.write('\n')
