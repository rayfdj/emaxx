from pathlib import Path
import hashlib,json,subprocess,sys,time
p=Path(__file__).parent.resolve();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
fixed={n:sha(p/n) for n in ['measure-vm-inline.py','audit-vm-inline-performance.py',Path(__file__).name]}
state=dict(status='waiting for source291 selected audit',helpers=fixed,steps=[],goal_complete=False)
def save(): (p/'inline-performance-sequence-state.json').write_text(json.dumps(state,indent=2)+'\n')
save();success=False
try:
 while not (p/'inline-selection-result.json').exists():
  print(state['status'],flush=True);time.sleep(30)
 selected=json.loads((p/'inline-selection-result.json').read_text());assert selected['status']=='selected correctness audited; performance pending',selected['status']
 assert len(selected['steps'])==3 and all(x['exit_code']==0 for x in selected['steps'])
 for name in ['measure-vm-inline.py','audit-vm-inline-performance.py']:
  assert all(sha(p/n)==h for n,h in fixed.items())
  state['status']='running '+name;save();start=time.monotonic();command=[sys.executable,'-B',str(p/name)]
  with (p/('inline-sequence-'+name+'.log')).open('xb') as log:r=subprocess.run(command,cwd=p,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
  result=dict(command=command,exit_code=r.returncode,elapsed_seconds=time.monotonic()-start);state['steps'].append(result);save();print(json.dumps(result),flush=True);assert r.returncode==0
 state['status']='timing audited; source decision pending';success=True
except Exception as error:state.update(status='sequence stopped',error=repr(error))
finally:
 save()
 with (p/'inline-performance-sequence-result.json').open('x') as f:json.dump(state,f,indent=2)
print(json.dumps(dict(status=state['status'],error=state.get('error'))),flush=True)
sys.exit(0 if success else 1)
