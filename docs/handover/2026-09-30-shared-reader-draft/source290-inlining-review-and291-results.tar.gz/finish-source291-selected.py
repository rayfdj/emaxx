from pathlib import Path
import hashlib,json,os,subprocess,sys,time
p=Path(__file__).parent.resolve();c=p.parent/'recovered-2026-10-05/vm-integer-inlining/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();read=lambda n:json.loads((p/n).read_text())
fixed={n:sha(p/n) for n in ['compare-vm-dispatch-fixtures.py','compare-source291-generated-loaded.py','audit-source291-selected.py',Path(__file__).name]}
state=dict(status='waiting for source291 validation',steps=[],helpers=fixed,goal_complete=False)
def save(): (p/'inline-selection-state.json').write_text(json.dumps(state,indent=2)+'\n')
save();success=False
try:
 while not (p/'source291-validation-result.json').exists():
  print(state['status'],flush=True);time.sleep(30)
 v=read('source291-validation-result.json');assert v['status']=='strict, selected and ordinary build passed; raw audit and ordinary comparisons required',v['status']
 names=list(read('source290-selected-closed-audit.json')['ordinary_results']);assert len(names)==45
 stages=[('ordinary',[sys.executable,'-B',str(p/'compare-vm-dispatch-fixtures.py'),'source291',str(c),*names]),('generated',[sys.executable,'-B',str(p/'compare-source291-generated-loaded.py')]),('audit',[sys.executable,'-B',str(p/'audit-source291-selected.py')])]
 for name,command in stages:
  assert all(sha(p/n)==h for n,h in fixed.items())
  state['status']='running '+name;save();start=time.monotonic()
  with (p/f'inline-selection-{name}-command.json').open('x') as f:json.dump(dict(command=command,working_directory=str(p),helpers=fixed),f,indent=2)
  with (p/f'inline-selection-{name}.log').open('xb') as log:r=subprocess.run(command,cwd=p,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
  result=dict(stage=name,exit_code=r.returncode,elapsed_seconds=time.monotonic()-start,helpers_unchanged=all(sha(p/n)==h for n,h in fixed.items()))
  state['steps'].append(result);save();print(json.dumps(result),flush=True)
  assert r.returncode==0 and result['helpers_unchanged']
 state['status']='selected correctness audited; performance pending';success=True
except Exception as error:state.update(status='selected sequence stopped',error=repr(error))
finally:
 save()
 with (p/'inline-selection-result.json').open('x') as f:json.dump(state,f,indent=2)
print(json.dumps(dict(status=state['status'],error=state.get('error'))),flush=True)
sys.exit(0 if success else 1)
