from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
tree = ast.parse((p / 'package-source196-failure-and197-results.py').read_text())
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected'}
files = {f.name: f for f in p.glob('source206-*') if f.is_file() and f.suffix in allowed}
for name in ['test-bytecode-controls206.py', 'freeze-bytecode-candidate.py', 'audit-source206-baseline.py', Path(__file__).name]:
    files[name] = p / name
package('source206-bytecode-negative-controls', files, json.loads((p / 'source206-baseline-audit.json').read_text()))

files = {f.name: f for f in p.glob('source204-full-ttydiff*') if f.is_file() and f.suffix in allowed}
for name in ['source204-complete-terminal-audit.json', 'source204-manifest.json',
             'run-source204-full-tty.py', 'verify-complete-reader-terminal-receipts.py', Path(__file__).name]:
    files[name] = p / name
package('source204-complete-terminal', files, json.loads((p / 'source204-complete-terminal-audit.json').read_text()))

files = {}
for name in ['source204-census-diagnosis-local-checks-v2.json', 'source204-census-diagnosis-dispatch.json',
             'check-source204-census-diagnosis.py', 'source204-results-pr-body.md', Path(__file__).name]:
    files[name] = p / name
for name in ['tools/diagnose_exact_census.py', 'tools/diagnostics/exact-census-watch.py', '.github/workflows/frozen-run.yml']:
    files[name] = root / name
scope = json.loads((p / 'source204-census-diagnosis-dispatch.json').read_text())
scope['qualification'] = 'Exact-retained-artifact diagnosis launched on published dca0453e. Runtime inputs remain source204. Six malformed-input controls rejected. No replay or debugger outcome yet.'
package('source204-census-diagnosis-start', files, scope)
