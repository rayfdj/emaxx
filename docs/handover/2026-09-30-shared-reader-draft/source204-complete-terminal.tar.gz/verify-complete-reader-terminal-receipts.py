from pathlib import Path
import hashlib
import json
import re
import runpy
import sys

p = Path(__file__).parent
tag = sys.argv[1]
result = json.loads((p / f'{tag}-full-ttydiff-result.json').read_text())
command = json.loads((p / f'{tag}-full-ttydiff-command.json').read_text())
raw = (p / f'{tag}-full-ttydiff.log').read_text()
assert result['exit_code'] == 0 and result['source_unchanged'] and result['inputs_unchanged']
assert result['complete_start_inventory'] and result['terminal_summary'] == ['PASS: all scenarios match']
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
for name, digest in command['inputs'].items():
    assert sha(Path(name)) == digest, name
root = Path(command['working_directory'])
manifest = json.loads((p / command['source_manifest']).read_text())
assert all(sha(root / name) == digest for name, digest in manifest.items())
module = runpy.run_path(str(root / 'tools/ttydiff.py'), run_name='inventory_only')
scenarios = module['select_scenarios']([])
assert [s[0] for s in scenarios] == command['inventory']
assert len(scenarios) == result['expected_scenarios'] == result['started_scenarios'] == 226
starts = re.findall(r'^RUN \[(\d+)/(\d+)\] (.+)$', raw, re.M)
assert starts == [(str(i + 1), str(len(scenarios)), s[0]) for i, s in enumerate(scenarios)]
expected = []
for scenario in scenarios:
    name, keys = scenario[0], scenario[2]
    final_label, final_filesystem = name, False
    for index, item in enumerate(keys):
        action = module['normalize_action'](item, index)
        if not action.checkpoint:
            continue
        label = f'{name}::{index + 1}:{action.name}'
        if index + 1 == len(keys):
            final_label, final_filesystem = label, action.filesystem
        else:
            expected.append(label)
            if action.filesystem:
                expected.append(label + ' filesystem')
    expected.append(final_label)
    if final_filesystem:
        expected.append(final_label + ' filesystem')
observed = re.findall(r'^MATCH \[(.+)\]: (?:text area identical \(\d+ rows\)|isolated fixture trees identical)$', raw, re.M)
assert observed == expected, {'expected': len(expected), 'observed': len(observed)}
assert not re.search(r'^(?:DIVERGE|ERROR|REQUIRED|FAIL|SKIP|Traceback)', raw, re.M)
assert raw.splitlines()[-1] == 'PASS: all scenarios match'
audit = {
    'status': 'passed', 'scenarios': len(scenarios),
    'verified_checkpoints': len(expected),
    'screen_comparisons': sum(not label.endswith(' filesystem') for label in expected),
    'filesystem_comparisons': sum(label.endswith(' filesystem') for label in expected),
    'log_sha256': sha(p / f'{tag}-full-ttydiff.log'),
    'inputs_rehashed': len(command['inputs']),
    'qualification': 'Complete unchanged default scenario, screen and filesystem inventories match raw reports in order. Source/ABI-matched Darwin GNU is not the frozen executable. No performance certification.',
}
with (p / f'{tag}-complete-terminal-audit.json').open('x') as f:
    json.dump(audit, f, indent=2)
    f.write('\n')
print(json.dumps(audit, indent=2))
