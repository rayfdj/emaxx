from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve();out=p.parents[2]/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest();read=lambda n:json.loads((p/n).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
allowed={'.json','.log','.txt','.py','.patch','.stdout','.stderr','.el','.expected','.h'}
selected={tag:read(tag+'-selected-audit.json') for tag in ('source292','source294')}
for tag,audit in selected.items():
    assert audit['status']=='passed' and audit['source_inputs_verified']==532 and audit['ordinary_comparisons']==47
    assert all(r['passed']==290 and r['failed']==0 and r['ignored']==2 for r in audit['profiles'].values())
    assert audit['retained_broad_probe_failure']['exact_match'] is False
    assert all(sha(Path(n).read_bytes())==h for n,h in audit['evidence_files'].items())
assert read('source294-manifest.json')==read('source293-manifest.json')
files={f.name:f for f in p.iterdir() if f.is_file() and f.suffix in allowed and (f.name.startswith(('source292-','source293-','source294-','buffer-selection-','buffer-line-','line-cache-')) or f.suffix=='.py' and any(x in f.name for x in ('source292','source293','source294','buffer-line','buffer_line')))}
for n in ['source290-manifest.json','source290-selected-closed-audit.json','source290-gate-inventory.log','source290-release-inventory.log','compare-vm-dispatch-fixtures.py','printer-varied-v3-293638f0.el','printer-varied-v3-gnu.stdout','package-source196-failure-and197-results.py',Path(__file__).name]:files[n]=p/n
for f in p.glob('source290-line-index-baseline-*'):
    if f.is_file() and f.suffix in allowed:files[f.name]=f
package('source294-buffer-line-selected',files,dict(status='closed selected validation for fresh LF baseline292 and indexed candidate294',audits=selected,stale_build_rejection=read('source293-stale-cache-review.json'),qualification='All532 source inputs and modes reconstruct from7f687d58 and main. Explicit fresh compilation is verified for294; reused293 binaries are rejected and no timing from them is accepted. Each fresh variant has290 passes/two existing ignores per profile and47 actual ordinary GNU comparisons, including338 LF motion rows and198 generated reader/printer rows. The unchanged broader probe remains failed with60 existing display-column differences; all line/motion fields now match and column values equal the original290 values. Original setup/parser failures stay preserved. Full platform, display-width correctness, accounting/ownership and calibrated performance remain open.',goal_complete=False))
perf=read('buffer-line-fresh-performance-audit.json')
assert perf['status']=='all 288 processes and actual results/modes verified'
assert all(sha(Path(n).read_bytes())==h for n,h in perf['evidence_files'].items())
files={}
for tag in ('source290','source292','source294'):
    for directory in sorted(p.glob(tag+'-buffer-line-fresh-pilot-*'))+[p/(tag+'-core-native')]:
        for f in directory.rglob('*'):
            if f.is_file() and f.suffix in allowed:files[str(f.relative_to(p))]=f
for f in p.iterdir():
    if f.is_file() and f.suffix in allowed and f.name.startswith(('buffer-line-fresh-performance-','buffer-performance-')):files[f.name]=f
for n in ['measure-buffer-line-fresh.py','audit-buffer-line-fresh-performance.py','finish-buffer-line-performance-fresh.py','package-source196-failure-and197-results.py',Path(__file__).name]:files[n]=p/n
package('source294-buffer-line-performance',files,dict(status='all288 actual diagnostic results and modes verified',audit=perf,qualification='Three rotated repetitions of every unchanged16-workload pilot for original290, LF-only corrected baseline292 and freshly rebuilt indexed candidate294. All results, slower cases, startup/total/RSS/GC and unavailable-allocation reports are retained. No builds, tests or profiles run during timing. The independent broad display-column failure remains open. This diagnostic is not calibrated nine-round acceptance or the unchanged3% every-case criterion.',goal_complete=False))
