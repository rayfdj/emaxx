from pathlib import Path
import hashlib,io,json,re,subprocess,sys,tarfile
p=Path(__file__).parent.resolve();repository=p.parents[2];sys.path.insert(0,str(repository/'tools'));import grouped_gate as gate
head='7e894a667b0bc0076dcf0555fb1d1f6fcbfb648c';artifact=p/('source312-linux-rust-artifacts/ordinary-linux-'+head);root=artifact/'rust'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();read=lambda f:json.loads(f.read_text())
terminal=read(p/'source312-linux-rust-terminal.json');assert terminal['headSha']==head and terminal['status']=='completed' and terminal['conclusion']=='failure'
s=read(root/'summary.json');assert s['status']=='failed' and s['scope']=='full' and s['git']==dict(head=head,dirty=False)
assert not s['runs'] and not s['cargo_stages']
inventory=gate.parse_inventory((root/'inventory.txt').read_text());assert len(inventory)==3066
old=gate.parse_inventory((p/'source311-linux-rust-artifacts/ordinary-linux-447c84c13017f47878855273a2a0609f9f9edeb1/rust/inventory.txt').read_text());assert set(old)<=set(inventory) and len(inventory)-len(old)==3
groups,_=gate.classify_inventory(inventory,'full');assert {n:len(v) for n,v in groups.items()}==s['inventory']['groups']
seen={};raw_files={};totals=dict(passed=0,failed=0,ignored=0)
logs=sorted(root.glob('repeat-01-*.log'));assert len(logs)==6
for log in logs:
 group=log.name.removeprefix('repeat-01-').removesuffix('.log');raw=log.read_text();starts=list(re.finditer(r'^test (\S+) \.\.\. ',raw,re.M));assert set(m[1] for m in starts)==set(groups[group]) and len(starts)==len(groups[group])
 for i,m in enumerate(starts):
  end=starts[i+1].start() if i+1<len(starts) else raw.index('\n\nfailures:',m.end()) if '\n\nfailures:' in raw[m.end():] else raw.rindex('test result:')
  captured=raw[m.end():end].strip();assert m[1] not in seen
  verdict='failed' if captured.endswith('FAILED') else 'passed' if re.search(r'(?:^|\s)ok$',captured) else 'ignored' if captured.startswith('ignored') else None
  assert verdict,(m[1],captured);seen[m[1]]=verdict;totals[verdict]+=1
 result=gate.parse_test_result(raw);assert result['passed']==sum(seen[n]=='passed' for n in groups[group]) and result['failed']==sum(seen[n]=='failed' for n in groups[group])
 raw_files[log.name]=sha(log)
failed=sorted(n for n,v in seen.items() if v=='failed');assert failed==['lisp::primitives::tests::native_pseudovector_census_matches_gnu_word_layout','lisp::primitives::tests::native_vector_and_closure_census_matches_gnu_word_layout']
assert totals==dict(passed=2297,failed=2,ignored=0)
raw=(root/'repeat-01-primitives.log').read_text();reference=[]
for name,stem,first in [(failed[0],'vector-pseudovector-word-census','(((0 -7)'),(failed[1],'vector-closure-rounded-census','(((0 -9)')]:
 section=raw.split('---- '+name+' stdout ----\n',1)[1].split('\n---- ',1)[0]
 assert 'assert_upstream_primitive_contract' in section and 'oracle disagreed' in section
 actual=json.loads(re.search(r'^  left: (".*")$',section,re.M)[1]);expected=json.loads(re.search(r'^ right: (".*")$',section,re.M)[1]);assert actual.startswith(first)
 published=subprocess.check_output(['git','show',head+':tests/fixtures/'+stem+'.expected'],cwd=repository).decode().strip();assert expected==published
 assert actual.replace(first,'(((0 '+('2)' if 'pseudo' in stem else '0)'),1)==expected
 reference.append(dict(test=name,actual_gnu_output=actual,unchanged_expected=expected,failure_before_emaxx_comparison=True))
retained=read(root/'retained-inputs/manifest.json');assert retained['status']=='retained' and retained['gate_status']=='failed' and retained['gate_summary_sha256']==sha(root/'summary.json')
for item in retained['files']:assert sha(root/'retained-inputs'/item['artifact'])==item['sha256'] and (root/'retained-inputs'/item['artifact']).stat().st_size==item['bytes']
assert next(x['sha256'] for x in retained['files'] if x['artifact']=='libtest')==s['test_binary']['sha256']
cap=read(artifact/'oracle-inputs/manifest.json');ver=read(artifact/'oracle-inputs/verification.json');assert cap['source_commit']=='636f166cfc86aa90d63f592fd99f3fdd9ef95ebd' and not cap['source_tracked_changes'];assert ver['status']=='unchanged' and ver['files_verified']==4 and ver['capture_manifest_sha256']==sha(artifact/'oracle-inputs/manifest.json')
for item in cap['files']:assert sha(artifact/'oracle-inputs'/item['artifact'])==item['sha256']
manifest=read(p/'source312-final-manifest.json');assert len(manifest)==552
archive=subprocess.check_output(['git','archive',head,'--',*manifest],cwd=repository)
with tarfile.open(fileobj=io.BytesIO(archive)) as src:assert all(hashlib.sha256(src.extractfile(n).read()).hexdigest()==h for n,h in manifest.items())
unstarted=sorted(set(inventory)-set(seen));assert len(unstarted)==767
result=dict(status='failed: two GNU reference census assumptions',source_commit=head,run_id=37557907197,source_inputs_verified=552,inventory=3066,observed=totals,failed=failed,unstarted_library=unstarted,cargo_stages='not started',raw_verdicts=seen,gnu_failures=reference,retained=retained,oracle_capture=cap,oracle_verification=ver,raw_files={str(f.relative_to(artifact)):sha(f) for f in artifact.rglob('*') if f.is_file()},goal_complete=False,qualification='All raw started test names and outcomes and the complete unstarted inventory independently checked. Both failures occur in the GNU oracle assertion before Emaxx evaluates that contract. The original tests and failed result remain preserved; source313 changes only the pre-measurement census setup and needs separate validation. No complete Linux Rust pass claimed for312.')
(p/'source312-linux-rust-failure-audit.json').open('x').write(json.dumps(result,indent=2));print({k:result[k] for k in ['status','inventory','observed']})
