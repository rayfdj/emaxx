from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve();out=p.parents[2]/'docs/handover/2026-09-30-shared-reader-draft';sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda n:json.loads((p/n).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package');exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
mac=read('source312-macos-rust-audit.json');lf=read('source312-linux-frozen-complete-audit.json');mf=read('source312-macos-frozen-audit.json');lr=read('source312-linux-rust-failure-audit.json');perf=read('source312-linux-pair-performance-audit.json');tty=read('source312-terminal-startup-failure-audit.json')
assert mac['total_passed']==3155 and mac['status']=='passed';assert lf['status']=='matched' and lf['verified_outcomes']==7928
assert mf['mismatching_outcomes']==6 and mf['matching_outcomes']==7915;assert lr['observed']==dict(passed=2297,failed=2,ignored=0);assert perf['status']=='192 actual Linux process results and modes independently verified'
files={};excluded=[];allowed={'.json','.log','.txt','.py','.patch','.stdout','.stderr','.el','.expected','.h','.c','.loaded','.apparmor'}
dirs=[(p/'source312-linux-rust-artifacts','linux-rust'),(p/'source312-linux-frozen-artifacts','linux-frozen'),(p/'source312-linux-core-runtime-pair-artifacts','linux-pair'),(p/'full-gate-source312','macos-rust'),(Path(mf['raw_root']),'macos-frozen'),(p/'source312-full-retained-gnu','macos-gnu-inputs')]
for base,prefix in dirs:
 assert base.is_dir()
 for f in base.rglob('*'):
  if not f.is_file():continue
  name=prefix+'/'+str(f.relative_to(base))
  if f.suffix in allowed or f.name in ['Makefile','stdout','stderr']:files[name]=f
  else:excluded.append(dict(path=name,bytes=f.stat().st_size,sha256=sha(f.read_bytes())))
for f in p.iterdir():
 if f.is_file() and f.suffix in allowed and f.name.startswith(('source312-full-','source312-linux-','source312-macos-')):files['receipts/'+f.name]=f
helpers=['audit-source312-linux-frozen.py','verify-complete-frozen-receipts279.py','audit-source312-linux-pair.py','audit-source312-linux-rust-failure.py','audit-source312-macos-frozen.py','audit-source312-macos-rust-names.py','verify-source312-macos-rust.py','source312-terminal-startup-failure-audit.json','source312-final-manifest.json','source312-final-modes.json','source312-final-portable-complete.patch','source312-applied-commit.json',Path(__file__).name,'package-source196-failure-and197-results.py']
for name in helpers:files['receipts/'+name]=p/name
assert all(f.is_file() for f in files.values())
package('source312-closed-platform-results',files,dict(status='source312 Linux/macOS completed results independently audited; failures retained',source_commit='7e894a667b0bc0076dcf0555fb1d1f6fcbfb648c',linux_rust={k:lr[k] for k in ['status','run_id','inventory','observed','failed','cargo_stages']},linux_rust_unstarted=767,linux_frozen=lf,macos_rust=mac,macos_frozen={k:mf[k] for k in ['status','verified_files','matching_outcomes','mismatching_outcomes','successful_processes','runner_summaries','differences']},original_terminal_attempt=tty,performance={k:perf[k] for k in ['status','run_id','raw_body_geometric_ratio','paired_gnu_geometric_ratios','qualification']},excluded_binaries=excluded,goal_complete=False,qualification='Preserves complete raw inventories, outputs, process results, retained artifact identities and independent audit helpers. MacOS strict frozen remains failed with six existing feature skip-diagnostic differences; expected failures/skips are not passes. Linux Rust has two GNU-only census failures and unstarted remainder. A fixture-only313 correction and separate terminal retry require their own validation. The timing pilot does not meet the calibrated nine-round every-case GNU ceiling; incomplete architecture/accounting/soundness requirements remain open.'))
