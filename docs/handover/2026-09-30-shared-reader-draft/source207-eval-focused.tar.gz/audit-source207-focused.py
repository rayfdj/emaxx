from pathlib import Path
import ast
import hashlib
import json
import re

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/eval-frames/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read('source207-manifest.json')
assert len(manifest) == 410 and all(sha(root / name) == digest for name, digest in manifest.items())
tree = ast.parse((p / 'audit-shared-reader196-fresh-selected.py').read_text())
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'audit_log')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<raw-auditor>', 'exec'))
command = read('source207-gate-focused-command.json')
result = read('source207-gate-focused-result.json')
assert result['exit_code'] == 0 and result['source_unchanged']
names = command['selected_inventory']
assert len(names) == 9
assert not audit_log(names, (p / 'source207-gate-focused.log').read_text(), 9, 0)
assert command['binary_sha256'] == sha(p / 'source207-gate-libtest')
inventory = (p / 'source207-gate-inventory.txt').read_text()
assert all(name + ': test\n' in inventory for name in names)
for label in ['check', 'fmt', 'clippy', 'diff', 'gate-build']:
    outcome = read('source207-' + label + '-result.json')
    assert outcome['exit_code'] == 0 and outcome['source_unchanged']
    raw = (p / ('source207-' + label + '.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
    for line in raw.splitlines():
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        assert item.get('message', {}).get('level') not in ['error', 'warning']
    if label in ['fmt', 'diff']:
        assert not raw
record = dict(status='strict checks and nine focused gate controls pass', inputs=410,
              binary_sha256=command['binary_sha256'], passed=9, failed=0, ignored=0, names=names,
              source_unchanged=True,
              qualification='Selected macOS gate evidence only. Source204 passed these local census tests too; Linux repair is not proved. Broader gate/release controls, ordinary build/comparison and full validation remain pending. Static frame/code reduction is not a performance measurement.')
with (p / 'source207-focused-audit.json').open('x') as f:
    json.dump(record, f, indent=2)
    f.write('\n')
print(json.dumps(record, indent=2))
