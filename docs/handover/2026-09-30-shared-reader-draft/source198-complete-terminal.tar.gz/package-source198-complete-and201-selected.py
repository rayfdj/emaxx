from pathlib import Path
import ast
import collections
import gzip
import hashlib
import io
import json
import re
import tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda file: json.loads(file.read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<package>', 'exec'), globals())
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected', '.apparmor'}

directory, = (p / 'linux-source198-exact-retained-artifacts').rglob('rust-exact-roots')
summary = read(directory / 'summary.json')
assert summary['artifact_run'] == '36748039991' and summary['source_revision'] == '7e45db47438a39e97658bddaceba903e0e41c186'
assert summary['source_matches_original'] and summary['source_unchanged'] and summary['binary_unchanged']
assert summary['binary_sha256'] == '89058fe557e1d3138199c8c6d905c9ca502b03af38b218a6485c723254d19a65'
original, = (directory / 'original').rglob('rust/summary.json')
retained = read(original.parent / 'retained-inputs/manifest.json')
assert retained['gate_summary_sha256'] == sha(original.read_bytes())
for entry in retained['files']:
    file = original.parent / 'retained-inputs' / entry['artifact']
    assert sha(file.read_bytes()) == entry['sha256'] and file.stat().st_size == entry['bytes']
assert sha((original.parent / 'retained-inputs/libtest').read_bytes()) == summary['binary_sha256']
assert any(entry['sha256'] == '93471768b88dff7b9d83ee62c4e57b31994f3195890e42d9ae2595b842e38754' for entry in retained['files'])
source = read(directory / 'source-before.json')
manifest = read(p / 'source198-manifest.json')
assert len(source) == 398 and all(manifest[name] == digest for name, digest in source.items())
plain = (directory / 'plain.log').read_text()
debugger = (directory / 'debugger.log').read_text()
name = 'lisp::primitives::tests::suspended_bytecode_retains_operand_and_unwind_roots'
assert summary['plain']['exit_code'] == 101 and not summary['plain']['timed_out']
assert re.findall(r'^test (\S+) \.\.\. FAILED$', plain, re.M) == [name, name]
assert re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', plain, re.M) == [('FAILED', '0', '1', '0')] * 2
assert 'left: "((1 t 0) (1 t 1))"' in plain and 'right: "((1 t 0) (1 t 0))"' in plain
assert 'tests.rs:25627:5' in plain
assert summary['debugger']['exit_code'] == 0 and not summary['debugger']['timed_out']
assert re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', debugger, re.M) == [('ok', '1', '0', '0')]
traces = [json.loads(line[11:]) for line in debugger.splitlines() if line.startswith('EXACT_ROOT ')]
assert traces == read(directory / 'trace-events.json') and len(traces) == summary['trace_events'] == 20
errors = collections.Counter(line for line in debugger.splitlines() if line.startswith('Python Exception'))
assert sum(errors.values()) == 498
audit = {'status': 'original failure reproduced; debugger pass has read errors',
         'ordinary_failed': 1, 'child_failed': 1, 'original_binary_and_retained_images_verified': True,
         'source_inputs_verified': 398, 'debugger_passed': 1, 'debugger_trace_events': len(traces),
         'debugger_errors': dict(errors),
         'qualification': 'The ordinary replay reproduces the same original Emaxx reclamation assertion with the exact retained executable and startup image. A separate hardware-watchpoint process passes; 498 Python OverflowError callbacks limit that trace. No retaining root or runtime repair is established. A later bitmap change in Value::cons follows reuse of the reclaimed cell and is not evidence of the old key surviving.'}
with (p / 'source198-exact-retained-audit.json').open('x') as stream:
    json.dump(audit, stream, indent=2)
    stream.write('\n')
files = {str(file.relative_to(directory)): file for file in directory.rglob('*')
         if file.is_file() and file.suffix in allowed}
for name in [Path(__file__).name, 'source198-exact-retained-audit.json',
             'source198-linux-exact-retained-final-state.json', 'source198-linux-exact-retained-download.json',
             'source198-linux-exact-retained-ci.log', 'source198-linux-exact-retained-dispatch.json']:
    files['receipts/' + name] = p / name
package('source198-exact-retained-failure', files, audit)

for stem, directory_name, audit_name, helpers in [
    ('source198-linux-frozen', 'linux-source198-frozen-artifacts', 'source198-linux-frozen-audit.json', ['verify-complete-frozen-receipts.py']),
]:
    directory = p / directory_name
    files = {str(file.relative_to(directory)): file for file in directory.rglob('*')
             if file.is_file() and file.suffix in allowed}
    for name in [Path(__file__).name, audit_name, stem + '-final-state.json', stem + '-download.json', stem + '-ci.log', *helpers]:
        files['receipts/' + name] = p / name
    package(stem, files, read(p / audit_name))

terminal = read(p / 'source198-complete-terminal-audit.json')
assert terminal['scenarios'] == 226 and terminal['verified_checkpoints'] == 686
files = {file.name: file for file in p.iterdir() if file.is_file() and file.suffix in allowed
         and file.name.startswith(('source198-full-tty', 'source198-full-local-supervisor'))}
for name in [Path(__file__).name, 'source198-complete-terminal-audit.json', 'source198-manifest.json',
             'verify-complete-reader-terminal-receipts.py', 'run-source198-full-tty.py']:
    files[name] = p / name
package('source198-complete-terminal', files, terminal)

selected = read(p / 'source201-selected-evidence-audit.json')
assert all(item['raw_passed'] == 454 and item['raw_failed'] == 0 for item in selected['rust'])
assert len(selected['ordinary_source201']) == 36
files = {file.name: file for file in p.iterdir() if file.is_file() and file.suffix in allowed and file.name.startswith('source201-')}
for name in [Path(__file__).name, 'audit-source201-selected.py', 'check-reader201.py', 'static-reader201.py',
             'test-reader201.py', 'build-reader201.py', 'queue-source201-validation.py',
             'freeze-vector-candidate.py', 'audit-source201-patch.py', 'compare-recovered-continuation-fixtures.py']:
    files[name] = p / name
package('source201-vector-selected-validation', files, selected)
