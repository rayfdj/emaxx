from pathlib import Path
import hashlib, json, re
p = Path(__file__).parent.resolve()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()

def parse(text):
    tokens = iter(re.findall(r'[()]|[^()\s]+', text))

    def one(token):
        if token != '(':
            assert token != ')'
            return token
        values = []
        for token in tokens:
            if token == ')':
                return values
            values.append(one(token))
        raise AssertionError('Unclosed result list')

    result = one(next(tokens))
    assert next(tokens, None) is None
    return result

rows = {}
for editor in ['gnu', 'emaxx']:
    stem = 'source249-string-equality-property-hashes-' + editor
    command = json.loads((p / (stem + '-command.json')).read_text())
    result = json.loads((p / (stem + '-result.json')).read_text())
    assert result['exit_code'] == 0 and not (p / (stem + '.stderr')).read_bytes()
    assert sha(p / (stem + '.stdout')) == result['stdout_sha256']
    assert all(sha(Path(name)) == digest for name, digest in command['inputs'].items())
    rows[editor] = parse((p / (stem + '.stdout')).read_text())
    assert len(rows[editor]) == 6
rows_different = []
observations = differences = 0
for a, b in zip(rows['gnu'], rows['emaxx']):
    assert a[0] == b[0] and len(a) == len(b)
    observations += len(a) - 1
    differences += sum(x != y for x, y in zip(a[1:], b[1:]))
    if a != b: rows_different.append(dict(stage=a[0], gnu=a[1:], emaxx=b[1:]))
assert observations == 15 and differences == 13 and len(rows_different) == 6
record = dict(status='confirmed source249 negative', fixture='string-equality-property-hashes.el',
              fixture_sha256=sha(p / 'string-equality-property-hashes.el'), observations=observations,
              differing_observations=differences, differing_rows=rows_different,
              qualification='Successful ordinary processes with exact same fixture, empty stderr and unchanged inputs. fns.c:hash_interval hashes the property plist using sxhash_obj, whose string values ignore their own properties. This is source249 evidence. The related source258 issue was identified by static C/Rust review before any runtime test; its pending queue was withdrawn, not reported as a failed or passing execution.')
with (p / 'source249-string-equality-property-hashes-negative-audit.json').open('x') as f:
    json.dump(record, f, indent=2)
print(json.dumps(dict(observations=observations, differing_observations=differences, processes_verified=True)))
