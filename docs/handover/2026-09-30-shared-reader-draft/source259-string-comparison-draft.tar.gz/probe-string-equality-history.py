from pathlib import Path
import hashlib, json, os, subprocess, time

p = Path(__file__).parent.resolve()
root = p.parents[2]
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
fixture = p / 'string-equality-storage.el'
audit = json.loads((p / 'source249-string-equality-storage-negative-audit.json').read_text())
assert sha(fixture) == audit['fixture_sha256']
gnu_output = (p / 'source249-string-equality-storage-gnu.stdout').read_bytes()
current_output = (p / 'source249-string-equality-storage-emaxx.stdout').read_bytes()
records = []
for version in [174, 207]:
    label = 'source' + str(version)
    artifacts = json.loads((p / (label + '-ordinary-artifacts.json')).read_text())
    for name, entry in artifacts.items():
        assert sha(Path(name)) == sha(Path(entry['immutable_copy'])) == entry['sha256']
    binary = Path(next(name for name in artifacts if Path(name).name == 'emaxx'))
    command = [str(binary), '-Q', '--batch', '--eval', '(prin1 ' + fixture.read_text() + ')']
    inputs = {str(path): sha(path) for path in [fixture, Path(__file__), binary, binary.with_suffix('.pdmp')]}
    prefix = label + '-string-equality-storage-original-location'
    with (p / (prefix + '-command.json')).open('x') as stream:
        json.dump(dict(command=command, inputs=inputs, working_directory=str(root),
                       environment_override=dict(LANG='C', LC_ALL='C'), timeout_seconds=120,
                       qualification='Recorded source174/main or source207 executable/image at its original location, preserving native-library paths. Both retained and original bytes verified against the original receipt.'), stream, indent=2)
    started = time.monotonic()
    result = subprocess.run(command, cwd=root, env=dict(os.environ, LANG='C', LC_ALL='C'), stdin=subprocess.DEVNULL, capture_output=True, timeout=120)
    for suffix, data in [('stdout', result.stdout), ('stderr', result.stderr)]:
        with (p / (prefix + '.' + suffix)).open('xb') as stream:
            stream.write(data)
    record = dict(source=label, exit_code=result.returncode, elapsed_seconds=time.monotonic() - started,
                  stdout_sha256=sha(p / (prefix + '.stdout')), stderr_sha256=sha(p / (prefix + '.stderr')),
                  matches_gnu=result.stdout == gnu_output, matches_source249=result.stdout == current_output,
                  inputs_unchanged=all(sha(Path(name)) == digest for name, digest in inputs.items()))
    with (p / (prefix + '-result.json')).open('x') as stream:
        json.dump(record, stream, indent=2)
    assert record['inputs_unchanged']
    records.append(record)
    print(json.dumps(record), flush=True)
with (p / 'string-equality-storage-history-audit.json').open('x') as stream:
    json.dump(dict(records=records, fixture_sha256=sha(fixture),
                   qualification='Historical comparisons are limited to this exact fixture. A nonzero process cannot establish the equality verdict; its failure is retained. No other regression is excused and no general correctness certificate is inferred.'), stream, indent=2)
