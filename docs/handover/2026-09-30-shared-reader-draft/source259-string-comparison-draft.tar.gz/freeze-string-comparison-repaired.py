from pathlib import Path
import hashlib, json, subprocess, sys
p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/string-comparisons/emaxx'
tag = 'source' + sys.argv[1]
assert sys.argv[1].isdecimal()
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
files = [*root.joinpath('src').rglob('*.rs'), *root.joinpath('tests').rglob('*')]
files += [root / name for name in ['Cargo.toml', 'Cargo.lock', 'build.rs', 'tools/ttydiff.py', 'tools/fixtures/fieldnotes.org', 'tools/fixtures/fake_lsp_server.py']]
files += list(root.joinpath('.cargo').glob('*'))
files += [root / name for name in ['compat/emacs_compat_runner.el', 'src/lisp/bytecode/fixture-oracle-30.2.elc', 'src/lisp/bytecode/fixture-oracle2-30.2.elc', 'src/lisp/bytecode/fixture-oracle3-30.2.elc']]
manifest = {str(file.relative_to(root)): sha(file) for file in sorted(set(files)) if file.is_file()}
assert len(manifest) == 486
assert json.loads((p / (tag + '-manifest.json')).read_text()) == manifest
untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=root, text=True).splitlines()
extra = b''
for name in sorted(set(untracked) & set(manifest)):
    result = subprocess.run(['git', 'diff', '--no-index', '--binary', '--', '/dev/null', name], cwd=root, capture_output=True)
    assert result.returncode == 1 and not result.stderr
    extra += result.stdout
patches = {}
for label, base in [('portable-incremental', '3d7dd8f95803efdba97b3f0e51266fb70e8eebba'),
                    ('portable-complete', '21d20f0eec08f3c013d5d3eb3bd6e9cfc16b3199')]:
    patch = subprocess.check_output(['git', 'diff', '--binary', base, '--', *sorted(manifest)], cwd=root) + extra
    target = p / (tag + '-' + label + '.patch')
    with target.open('xb') as f:
        f.write(patch)
    patches[label] = dict(base=base, sha256=sha(target), bytes=len(patch))
record = dict(inputs=486, patches=patches, candidate=str(root), goal_complete=False,
              qualification='Isolated string comparison repair atop common-string source256. The affected equality paths compare actual canonical bytes and character counts. Symbol arguments read their Lisp name objects under the positioned-symbol policy; interval values use ordinary equality. Three exact ordinary GNU fixtures and a Rust Value contract are added. Read the distinct strict/runtime results for this source; this freeze makes no passing, architecture completion or performance claim.')
with (p / (tag + '-freeze.json')).open('x') as f:
    json.dump(record, f, indent=2)
print(json.dumps(record, indent=2))
