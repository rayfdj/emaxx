from pathlib import Path
import hashlib, json, re

p = Path(__file__).parent.resolve()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
def rows(path):
    parsed = [entry.split() for entry in re.findall(r'\(([^()]+)\)', path.read_text())]
    assert len(parsed) == 64 and all(len(row) == 5 for row in parsed)
    result = {tuple(row[:2]): row[2:] for row in parsed}
    assert len(result) == 64 and all(value in ['t', 'nil'] for row in result.values() for value in row)
    return result
gnu = rows(p / 'source249-string-equality-storage-gnu.stdout')
current = rows(p / 'source249-string-equality-storage-emaxx.stdout')
records = []
for version in [174, 207]:
    prefix = 'source' + str(version) + '-string-equality-storage-original-location'
    command = json.loads((p / (prefix + '-command.json')).read_text())
    result = json.loads((p / (prefix + '-result.json')).read_text())
    assert result['exit_code'] == 0 and result['inputs_unchanged'] and not (p / (prefix + '.stderr')).read_bytes()
    assert sha(p / (prefix + '.stdout')) == result['stdout_sha256']
    assert all(sha(Path(name)) == digest for name, digest in command['inputs'].items())
    old = rows(p / (prefix + '.stdout'))
    assert old.keys() == current.keys() == gnu.keys()
    old_bad = {(key, i) for key in gnu for i in range(3) if old[key][i] != gnu[key][i]}
    now_bad = {(key, i) for key in gnu for i in range(3) if current[key][i] != gnu[key][i]}
    assert len(old_bad) == 12 and len(now_bad) == 6 and now_bad < old_bad
    records.append(dict(baseline=version, paired_cases=64, boolean_comparisons=192,
                        baseline_wrong=12, source249_wrong=6,
                        remaining=[dict(pair=list(key), column=i) for key, i in sorted(now_bad)],
                        fixed=[dict(pair=list(key), column=i) for key, i in sorted(old_bad - now_bad)],
                        new_wrong=[]))
with (p / 'string-equality-storage-history-verdict-audit.json').open('x') as stream:
    json.dump(dict(status='specific historical gap confirmed', records=records,
                   qualification='This exact 64-pair/192-boolean matrix has twelve wrong comparisons in both recorded source174/main and source207 and six in source249, with no newly wrong comparison. The six remaining mismatches predate the later migrations. This is not a general correctness score or an excuse for separately recorded regressions.'), stream, indent=2)
print('Both historical baselines: 12 wrong comparisons; source249: six; no new wrong comparison in this matrix')
