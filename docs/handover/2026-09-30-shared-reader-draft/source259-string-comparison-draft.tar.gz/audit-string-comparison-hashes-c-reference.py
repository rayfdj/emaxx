from pathlib import Path
import hashlib
import json
import re
import subprocess

p = Path(__file__).parent.resolve()
candidate = p.parent / 'recovered-2026-09-30/string-comparisons/emaxx'
prior_candidate = p.parent / 'recovered-2026-09-30/common-strings/emaxx'
gnu = p.parent / 'rebuilt-2026-10-01/emacs'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read('source259-manifest.json')
prior = read('source256-manifest.json')
assert len(manifest) == 488 and all(sha(candidate / name) == digest for name, digest in manifest.items())
assert len(prior) == 480 and all(sha(prior_candidate / name) == digest for name, digest in prior.items())
changed = {name for name in prior if manifest[name] != prior[name]}
assert changed == {
    'src/lisp/types.rs', 'src/lisp/types/string_data.rs', 'src/lisp/primitives/strings.rs',
    'src/lisp/primitives/values.rs', 'src/lisp/primitives/dispatch/numeric.rs',
    'src/lisp/primitives/tests.rs', 'src/lisp/primitives/pdumper/tests.rs',
}
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=gnu, text=True).strip() == '636f166cfc86aa90d63f592fd99f3fdd9ef95ebd'
assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=gnu, text=True)
references = {
    'src/fns.c': ['DEFUN ("string-equal"', 'internal_equal (Lisp_Object o1', 'case Lisp_String:\n      return (SCHARS', 'sxhash_obj (Lisp_Object obj, int depth)\n{', 'hash_interval (INTERVAL interval, void *arg)'],
    'src/lisp.h': ['SYMBOLP (Lisp_Object x)', 'maybe_remove_pos_from_symbol (Lisp_Object x)'],
    'src/data.c': ['DEFUN ("symbol-name"', 'DEFUN ("position-symbol"'],
    'src/intervals.c': ['intervals_equal_1 (', 'compare_string_intervals (Lisp_Object s1'],
}
records = {}
for name, needles in references.items():
    text = (gnu / name).read_text()
    records[name] = dict(sha256=sha(gnu / name), anchors={needle: text[:text.index(needle)].count('\n') + 1 for needle in needles})
fixtures = ['string-equality-storage', 'string-equality-symbol-names-positioned', 'string-equality-property-values', 'string-equality-property-hashes']
assert set(manifest) - set(prior) == {'tests/fixtures/' + stem + suffix for stem in fixtures for suffix in ['.el', '.expected']}
for stem in fixtures:
    fixture = candidate / 'tests/fixtures' / (stem + '.el')
    expected = fixture.with_suffix('.expected')
    assert fixture.read_bytes() == (p / (stem + '.el')).read_bytes()
    assert expected.read_bytes() == (p / ('source249-' + stem + '-gnu.stdout')).read_bytes()
    comparison = read('source249-' + stem + '-comparison.json')
    assert comparison['inputs_unchanged'] and not comparison['same_stdout']
    for editor in ['gnu', 'emaxx']:
        name = 'source249-' + stem + '-' + editor
        command, result = read(name + '-command.json'), read(name + '-result.json')
        assert result['exit_code'] == 0 and not (p / (name + '.stderr')).read_bytes()
        assert sha(p / (name + '.stdout')) == result['stdout_sha256']
        assert all(sha(Path(file)) == digest for file, digest in command['inputs'].items())
for stage in ['check', 'fmt', 'clippy', 'diff']:
    result = read('source259-' + stage + '-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
    assert not re.search(r'^warning(?:\[.*\])?:', (p / ('source259-' + stage + '.log')).read_text(), re.M)
failed = read('source257-check-result.json')
assert failed['exit_code'] == 101 and failed['source_unchanged']
assert len(re.findall(r'^error\[E', (p / 'source257-check.log').read_text(), re.M)) == 8
previous = read('source257-manifest.json')
intermediate = read('source258-manifest.json')
assert {name for name in intermediate if intermediate[name] != previous[name]} == {'src/lisp/types.rs'}
assert {name for name in intermediate if manifest[name] != intermediate[name]} == {'src/lisp/primitives/values.rs', 'src/lisp/primitives/tests.rs', 'src/lisp/primitives/pdumper/tests.rs'}
withdrawal = read('source258-validation-withdrawal.json')
assert withdrawal['completed_runtime_stages'] == 0
record = dict(
    source='source259', source_inputs=488, unchanged_prior_source='source256', prior_inputs=480,
    changed_prior_files=sorted(changed), new_fixtures=fixtures, gnu_revision='636f166cfc86aa90d63f592fd99f3fdd9ef95ebd',
    gnu_references=records,
    implementation=[
        'SharedStringState::contents_equal compares character counts and actual stored bytes. SharedText and Value equality, ordinary Lisp equality and string-equal use this canonical contents path without decoded Rust text copies.',
        'Fstring_equal normalization reads the actual Lisp name of bare symbols, nil and t. Positioned-symbol names are accepted only when the forwarded GNU policy flag is enabled. Wrong-type checks retain argument order and the original offending object.',
        'Equal-including-properties checks object identity and canonical contents before comparing intervals by character position. It borrows existing spans rather than cloning text and properties.',
        'intervals_equal_1(..., true) compares property values with Fequal. Emaxx now uses ordinary equality for those values, preserving their contents while ignoring nested string properties. Existing interval-boundary and property-order comparison remains.',
        'String hashing reads actual storage bytes directly, removing the decoded text and extended-character allocations. Property-value hashing uses ordinary equality, as hash_interval does.',
        'The dumper writes key/value entries rather than cached hashes; load.rs reconstructs every standard hash after relocation. The existing dump/thaw contract now also checks unibyte, byte8 and private-use keys without removing an old assertion.',
        'The exact four ordinary GNU fixture inputs and expected output bytes are retained. Together they cover storage distinctions, symbol names and position policy, bad arguments, nested properties, mutation, collection, differing interval segmentation and custom hash-table lookup/replacement/removal.',
    ],
    failures_preserved=[
        'Source249 has six wrong booleans in the storage matrix, 92 wrong symbol/name observations, and eight property matrix plus three mutation observations, and thirteen hash/table observations. The original negative executables and images are retained.',
        'The initial symbol-name fixture called nonexistent make-symbol-with-pos; both processes exited255 before comparisons. The corrected distinct fixture uses actual GNU position-symbol.',
        'Source257 failed all-target checking with eight missing-import diagnostics in its new Rust test. Source258 changes only those test imports; no runtime validation occurred on source257.',
        'Static review caught the remaining nested-property hash inconsistency in source258 before runtime execution. Its waiting queue was explicitly withdrawn; the immutable strict results and patches remain. This is not a claimed runtime regression or test failure.',
        'The first portable-freeze helper failed on Python Path addition before opening patch/result outputs. Its executed source and observed error are preserved, with the corrected helper kept separately.',
    ],
    remaining=[
        'Source258 strict checks pass; selected gate/release and twenty-one ordinary comparisons are queued. No runtime success is inferred.',
        'The common-string draft still lacks GNU compact string headers/sblock allocation, complete symbol-cell authority, physical allocation accounting, actual cumulative counters and a public ownership boundary.',
        'String ordering/version operations and other consumers still use transient host text. Host raw-byte/private-use construction remains. Empty multibyte canonicalization and pure-string write protection are unfinished.',
        'Hash mixing remains the existing Emaxx algorithm. This change removes projection allocations and aligns the equality relation; GNU hash algorithm/cost parity is not established.',
        'No throughput, retained-memory, allocation saving or performance parity is measured. The locked sixteen-workload criterion, 3% ceiling and final platform/adversarial validation remain required.',
    ],
    goal_complete=False,
    qualification='Static C mechanism review, immutable negative evidence and exact strict/patch input verification. It does not certify all comparison, representation, GC, ownership or performance behavior.'
)
with (p / 'source259-c-reference-audit.json').open('x') as out:
    json.dump(record, out, indent=2)
print(json.dumps(dict(source='source259', inputs=488, prior_inputs_unchanged=480, strict='zero-warning pass', runtime='queued')))
