from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
candidate = p.parent / 'recovered-2026-09-30/string-comparisons/emaxx'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
manifest = read('source259-manifest.json')
assert len(manifest) == 488 and all(sha((candidate / name).read_bytes()) == digest for name, digest in manifest.items())
for stage in ['check', 'fmt', 'clippy', 'diff']:
    result = read('source259-' + stage + '-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
assert read('source259-patch-replay-audit.json')['status'] == 'exact'
assert read('source258-validation-withdrawal.json')['completed_runtime_stages'] == 0
files = {}
helpers = {
    'audit-source257-source258-patches.py', 'audit-source259-patches.py',
    'source255-gate-controls-command.json', 'source255-gate-inventory.log',
    'source249-gate-controls-command.json', 'source249-release-controls-command.json',
    'source249-gate-broad-command.json', 'source249-release-broad-command.json',
    'source256-manifest.json', 'source249-manifest.json',
    'package-source196-failure-and197-results.py', Path(__file__).name,
}
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected'}
for file in p.iterdir():
    if not file.is_file() or file.suffix not in allowed:
        continue
    name = file.name
    if (name in helpers or name.startswith(('source257-', 'source258-', 'source249-string-equality-', 'string-equality-', 'string-comparison-'))
        or (name.endswith('.py') and ('string-comparison' in name or name.startswith(('probe-string-equality-', 'audit-string-equality-'))))):
        files[name] = file
    elif name.startswith('source259-'):
        if any(name.startswith('source259-' + stage + '-') or name == 'source259-' + stage + '.log'
               for stage in ['check', 'fmt', 'clippy', 'diff', 'format']):
            files[name] = file
        elif name in ['source259-manifest.json', 'source259-unformatted.patch', 'source259-incremental.patch',
                      'source259-freeze.json', 'source259-portable-incremental.patch', 'source259-portable-complete.patch',
                      'source259-patch-replay-audit.json', 'source259-c-reference-audit.json', 'source259-strict-launch.json',
                      'source259-validation-queue-launch.json', 'source259-draft-status-snapshot.json']:
            files[name] = file
assert helpers <= files.keys()
for stem in ['string-equality-storage', 'string-equality-symbol-names-positioned',
             'string-equality-property-values', 'string-equality-property-hashes']:
    for suffix in ['.el', '.expected']:
        files['source259-fixtures/' + stem + suffix] = candidate / 'tests/fixtures' / (stem + suffix)
package('source259-string-comparison-draft', files, dict(
    source='source259', inputs=488, strict_checks='zero-warning pass',
    freeze=read('source259-freeze.json'), patch_replay=read('source259-patch-replay-audit.json'),
    c_reference=read('source259-c-reference-audit.json'),
    source258_queue_withdrawal=read('source258-validation-withdrawal.json'),
    queue_launch=read('source259-validation-queue-launch.json'),
    qualification='Unapplied comparison/hash repair atop separately packaged source256. Four ordinary source249 negatives, exact GNU fixtures, source257 missing-import failure and source258 withdrawal remain preserved. Source259 checks pass and patches replay all 488 inputs. Queue22381 follows source256, then runs 190 focused selectors, 962 affected tests in each profile and 21 ordinary GNU comparisons. Active runtime logs are excluded; no runtime pass, physical-memory saving, measured speedup or full-goal completion is claimed.'))
