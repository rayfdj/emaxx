import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/Users/nbmhqa186/projects/emaxx')
OUT = ROOT / 'target/runtime-goal/resume-2026-09-28'
FIXTURE = OUT / 'string-equality-property-values.el'
GNU = ROOT / 'target/runtime-goal/rebuilt-2026-10-01/emacs'
EMAXX = ROOT / 'target/runtime-goal/recovered-2026-09-30/coding-post-read/emaxx/target/frame-validation/release/emaxx'
HELPER = Path(__file__)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(name, data):
    with (OUT / name).open('x') as stream:
        json.dump(data, stream, indent=2)
        stream.write('\n')

env = dict(os.environ, LANG='C', LC_ALL='C', EMAXX_GC_VERIFY='1')
expression = '(prin1 ' + FIXTURE.read_text() + ')'
inputs = [FIXTURE, HELPER, GNU / 'src/emacs', GNU / 'src/emacs.pdmp',
          GNU / 'src/config.h', GNU / 'src/Makefile', EMAXX, EMAXX.with_suffix('.pdmp')]
before = {str(path): sha(path) for path in inputs}
assert before[str(EMAXX)] == '5a1921c8f8d1a2b1a487954ecef1b767b8bcfcd87661bcad7331612860e279bc'
assert before[str(GNU / 'src/emacs')] == '29cfb20de2474c040d439d4bdf69b4dfcfb7921464f1f686b6e1f6bcca7c74e5'
results = {}
for editor, binary in [('gnu', GNU / 'src/emacs'), ('emaxx', EMAXX)]:
    stem = 'source249-string-equality-property-values-' + editor
    command = [str(binary), '-Q', '--batch', '--eval', expression]
    save(stem + '-command.json', {'command': command, 'cwd': str(OUT),
         'environment_override': {'LANG': 'C', 'LC_ALL': 'C', 'EMAXX_GC_VERIFY': '1'},
         'inputs': before, 'timeout_seconds': 120,
         'qualification': 'Normal same-input GNU comparison. Rebuilt GNU; source249 release remains linked to the prior source/ABI-matched GNU installation. This is not a frozen run or timing sample.'})
    start = time.monotonic()
    with (OUT / (stem + '.stdout')).open('xb') as stdout, (OUT / (stem + '.stderr')).open('xb') as stderr:
        try:
            run = subprocess.run(command, cwd=OUT, env=env, stdin=subprocess.DEVNULL,
                                 stdout=stdout, stderr=stderr, timeout=120)
            result = {'exit_code': run.returncode}
        except subprocess.TimeoutExpired:
            result = {'exit_code': None, 'timeout': True}
    result.update({'elapsed_seconds': time.monotonic() - start,
                   'stdout_sha256': sha(OUT / (stem + '.stdout')),
                   'stderr_sha256': sha(OUT / (stem + '.stderr'))})
    save(stem + '-result.json', result)
    results[editor] = result
after = {str(path): sha(path) for path in inputs}
save('source249-string-equality-property-values-comparison.json', {
    'results': results, 'inputs_unchanged': before == after,
    'same_stdout': results['gnu']['stdout_sha256'] == results['emaxx']['stdout_sha256'],
    'goal_complete': False})
assert before == after
print(json.dumps(results, indent=2))
