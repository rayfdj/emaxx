from pathlib import Path
import hashlib, json, re
p = Path(__file__).parent.resolve()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()

def parse(text):
    tokens = iter(re.findall(r'[()]|[^()\s]+', text))

    def one(token):
        if token != '(':
            assert token != ')'
            return token
        values = []
        for token in tokens:
            if token == ')':
                return values
            values.append(one(token))
        raise AssertionError('Unclosed result list')

    result = one(next(tokens))
    assert next(tokens, None) is None
    return result

rows = {}
for editor in ['gnu', 'emaxx']:
    stem = 'source249-string-equality-property-values-' + editor
    command = json.loads((p / (stem + '-command.json')).read_text())
    result = json.loads((p / (stem + '-result.json')).read_text())
    assert result['exit_code'] == 0 and not (p / (stem + '.stderr')).read_bytes()
    assert sha(p / (stem + '.stdout')) == result['stdout_sha256']
    assert all(sha(Path(name)) == digest for name, digest in command['inputs'].items())
    rows[editor] = parse((p / (stem + '.stdout')).read_text())
    assert len(rows[editor]) == 2
    assert len(rows[editor][0]) == 64 and len(rows[editor][1]) == 6
    assert len({tuple(row[:2]) for row in rows[editor][0]}) == 64
matrix_differences = []
mutation_differences = []
for left, right in zip(rows['gnu'][0], rows['emaxx'][0]):
    assert left[:2] == right[:2]
    assert all(item in ['t', 'nil'] for item in left[2:] + right[2:])
    if left != right:
        assert left[2] == right[2] and left[4] == right[4]
        matrix_differences.append(dict(left=left[0], right=left[1], gnu=left[2:], emaxx=right[2:]))
for left, right in zip(rows['gnu'][1], rows['emaxx'][1]):
    assert left[0] == right[0]
    if left != right:
        mutation_differences.append(dict(stage=left[0], gnu=left[1], emaxx=right[1]))
assert len(matrix_differences) == 8 and len(mutation_differences) == 3
record = dict(status='confirmed source249 negative', fixture='string-equality-property-values.el',
              fixture_sha256=sha(p / 'string-equality-property-values.el'), pairs=64,
              mutation_and_interval_observations=6, matrix_differences=matrix_differences,
              mutation_differences=mutation_differences,
              qualification='Ordinary same-input processes, empty stderr, all retained inputs and outputs verified. intervals.c:compare_string_intervals uses intervals_equal_1(..., true), which calls Fequal on property values. Their own text properties are not recursively compared. No repair or historical-origin claim is inferred.')
with (p / 'source249-string-equality-property-values-negative-audit.json').open('x') as f:
    json.dump(record, f, indent=2)
print(json.dumps(dict(matrix_differences=8, mutation_differences=3, inputs_verified=True)))
