from pathlib import Path
import hashlib, json, re

p = Path(__file__).parent.resolve()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
rows = {}
for editor in ['gnu', 'emaxx']:
    stem = 'source249-string-equality-storage-' + editor
    command = json.loads((p / (stem + '-command.json')).read_text())
    result = json.loads((p / (stem + '-result.json')).read_text())
    assert result['exit_code'] == 0 and not (p / (stem + '.stderr')).read_bytes()
    assert sha(p / (stem + '.stdout')) == result['stdout_sha256']
    assert all(sha(Path(name)) == digest for name, digest in command['inputs'].items())
    parsed = re.findall(r'\(([^()]+)\)', (p / (stem + '.stdout')).read_text())
    assert len(parsed) == 64
    rows[editor] = {}
    for row in parsed:
        left, right, equal, properties, string = row.split()
        assert all(value in ['t', 'nil'] for value in [equal, properties, string])
        assert (left, right) not in rows[editor]
        rows[editor][left, right] = [equal, properties, string]
assert rows['gnu'].keys() == rows['emaxx'].keys()
differences = [dict(left=key[0], right=key[1], gnu=expected, emaxx=rows['emaxx'][key])
               for key, expected in rows['gnu'].items() if expected != rows['emaxx'][key]]
assert len(differences) == 6
assert sum(row['gnu'][1] != row['emaxx'][1] for row in differences) == 4
assert sum(row['gnu'][2] != row['emaxx'][2] for row in differences) == 2
assert all(row['gnu'][0] == row['emaxx'][0] for row in differences)
record = dict(status='confirmed source249 negative', fixture='string-equality-storage.el',
              fixture_sha256=sha(p / 'string-equality-storage.el'), pairs=64,
              columns=['equal', 'equal-including-properties', 'string-equal'], differences=differences,
              qualification='Ordinary same-input rebuilt GNU and retained source249 release. All processes/inputs verified. fns.c:Fstring_equal and internal_equal require matching character counts, byte counts and storage bytes. Rust projection text collapses these distinct cases in the two affected paths. The separate source256 draft remains frozen; no repair or historical origin is inferred.')
with (p / 'source249-string-equality-storage-negative-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps(dict(pairs=64, differing_rows=6, differences=differences), indent=2))
