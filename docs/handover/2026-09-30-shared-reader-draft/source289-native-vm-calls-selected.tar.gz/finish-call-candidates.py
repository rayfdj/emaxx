from pathlib import Path
import hashlib, json, os, subprocess, sys, time

p = Path(__file__).parent.resolve()
c = p.parent / 'recovered-2026-10-05/vm-call-entry/emaxx'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
fixed = {str(p / name): sha(p / name) for name in (
    'compare-vm-dispatch-fixtures.py', 'compare-source289-generated-loaded.py',
    'audit-source289-selected.py', 'audit-source286-macos-terminal.py',
    'measure-vm-call-entry.py', 'audit-vm-call-entry-performance.py', Path(__file__).name)}
state = dict(status='waiting for source289 validation', fixed_inputs=fixed, results=[], goal_complete=False)

def save():
    (p / 'call-candidates-finish-state.json').write_text(json.dumps(state, indent=2) + '\n')

def wait_for(name, status):
    state['status'] = status
    save()
    while not (p / name).exists():
        print(status, flush=True)
        time.sleep(30)
    return read(name)

def run(stage, command):
    assert all(sha(Path(path)) == digest for path, digest in fixed.items())
    state['status'] = 'running ' + stage
    save()
    started = time.monotonic()
    with (p / ('call-candidates-' + stage + '-command.json')).open('x') as stream:
        json.dump(dict(command=command, working_directory=str(p), fixed_inputs=fixed), stream, indent=2)
    with (p / ('call-candidates-' + stage + '.log')).open('xb') as log:
        result = subprocess.run(command, cwd=p, env=os.environ, stdin=subprocess.DEVNULL,
                                stdout=log, stderr=subprocess.STDOUT)
    record = dict(stage=stage, exit_code=result.returncode, elapsed_seconds=time.monotonic() - started,
                  helpers_unchanged=all(sha(Path(path)) == digest for path, digest in fixed.items()))
    with (p / ('call-candidates-' + stage + '-result.json')).open('x') as stream:
        json.dump(record, stream, indent=2)
    state['results'].append(record)
    save()
    print(json.dumps(record), flush=True)
    assert result.returncode == 0 and record['helpers_unchanged']

try:
    validation = wait_for('source289-validation-result.json', 'waiting for source289 validation')
    assert validation['status'] == 'strict, selected and ordinary build passed; raw audit and ordinary comparisons required'
    names = list(read('source288-selected-audit.json')['ordinary_results']) + ['bytecode-call-widths']
    assert len(names) == 44
    run('source289-ordinary', [sys.executable, '-B', str(p / 'compare-vm-dispatch-fixtures.py'), 'source289', str(c), *names])
    run('source289-generated', [sys.executable, '-B', str(p / 'compare-source289-generated-loaded.py')])
    run('source289-selected-audit', [sys.executable, '-B', str(p / 'audit-source289-selected.py')])
    full = wait_for('source286-full-queue-result.json', 'waiting for full source286 macOS validation before timing')
    assert full['status'] == 'complete macOS processes finished; raw evidence requires audit'
    assert full['results'][-1]['stage'] == 'oracle-verify' and full['results'][-1]['exit_code'] == 0
    run('source286-terminal-audit', [sys.executable, '-B', str(p / 'audit-source286-macos-terminal.py')])
    run('performance', [sys.executable, '-B', str(p / 'measure-vm-call-entry.py')])
    run('performance-audit', [sys.executable, '-B', str(p / 'audit-vm-call-entry-performance.py')])
    state['status'] = 'candidate correctness and diagnostic timing audited; application requires result review'
except Exception as error:
    state.update(status='post-validation sequence stopped', error=repr(error))
finally:
    save()
    with (p / 'call-candidates-finish-result.json').open('x') as stream:
        json.dump(state, stream, indent=2)
print(json.dumps(dict(status=state['status'], error=state.get('error'))), flush=True)
sys.exit(0 if state['status'].startswith('candidate correctness') else 1)
