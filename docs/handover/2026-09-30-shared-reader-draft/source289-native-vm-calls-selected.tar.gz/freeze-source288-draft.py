from pathlib import Path
import hashlib,io,json,os,subprocess,tarfile,tempfile
p=Path(__file__).parent.resolve();root=p.parents[2]
c=p.parent/'recovered-2026-10-05/native-argument-words/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
m=json.loads((p/'source288-manifest.json').read_text());base=json.loads((p/'source286-manifest.json').read_text())
assert len(m)==524 and all(sha(c/n)==h for n,h in m.items())
assert all(m[n]==h for n,h in base.items() if n.startswith('tests/'))
assert set(n for n,h in m.items() if base.get(n)!=h)=={'src/lisp/native_comp/runtime.rs','src/lisp/primitives/tests.rs','tests/fixtures/native-argument-words.el','tests/fixtures/native-argument-words.expected'}
test=(c/'src/lisp/primitives/tests.rs').read_bytes();prior=subprocess.check_output(['git','show','654aca96:src/lisp/primitives/tests.rs'],cwd=root)
assert test.startswith(prior) and test[len(prior):].count(b'#[test]')==1
patches=[];tracked_now=set(subprocess.check_output(['git','ls-files'],cwd=c,text=True).splitlines())
for label,commit in [('incremental','d1120c700d6a0bdee73dc391d2478668241c3ba5'),('complete','21d20f0eec08f3c013d5d3eb3bd6e9cfc16b3199')]:
    data=subprocess.check_output(['git','diff','--binary',commit,'--',*sorted(m)],cwd=c)
    for n in sorted(set(m)-tracked_now):
        r=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',n],cwd=c,capture_output=True)
        assert r.returncode==1 and not r.stderr;data+=r.stdout
    patch=p/('source288-portable-'+label+'.patch')
    with patch.open('xb') as f:f.write(data)
    tracked=set(subprocess.check_output(['git','ls-tree','-r','--name-only',commit],cwd=root,text=True).splitlines())
    archive=subprocess.check_output(['git','archive',commit,'--',*sorted(tracked&m.keys())],cwd=root)
    with tempfile.TemporaryDirectory(prefix='emaxx-native-argument-replay-',dir='/private/tmp') as temp:
        target=Path(temp)
        with tarfile.open(fileobj=io.BytesIO(archive)) as source:
            for item in source:
                assert not Path(item.name).is_absolute() and '..' not in Path(item.name).parts
                dest=target/item.name
                if item.isdir():dest.mkdir(parents=True,exist_ok=True)
                else:
                    assert item.isfile();dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(source.extractfile(item).read());os.chmod(dest,0o755 if item.mode&0o111 else 0o644)
        subprocess.run(['git','apply','--check',str(patch)],cwd=target,check=True)
        subprocess.run(['git','apply',str(patch)],cwd=target,check=True)
        assert all(sha(target/n)==h and (target/n).stat().st_mode&0o777==(c/n).stat().st_mode&0o777 for n,h in m.items())
    patches.append(dict(patch=patch.name,sha256=sha(patch),base=commit,inputs=524,bytes_and_modes='exact'))
result=dict(status='portable unapplied draft verified',candidate=str(c),source_manifest='source288-manifest.json',patches=patches,
            qualification='Only fixed-arity native calls stop copying through a temporary SmallVec. GNU funcall_subr passes argument words directly; Rust still needs NativeInvocation register slots to unwind through its assembly boundary. MANY retains owned writable storage and never aliases the caller Value slice. No new unsafe code, GC suppression, registry, mirror or workload special case. GNU and retained286 match the new lexical fixture before applying this change. Initial non-explicit lexical-binding probe remains separately retained. Selected validation and performance must finish before application.',goal_complete=False)
with (p/'source288-portable-draft-audit.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps(result,indent=2))
