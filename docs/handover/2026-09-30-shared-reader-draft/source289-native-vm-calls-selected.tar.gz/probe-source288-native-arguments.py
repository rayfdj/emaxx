from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).parent.resolve();c=p.parent/'recovered-2026-10-05/native-argument-words/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
fixture=c/'tests/fixtures/native-argument-words.el'
expected=fixture.with_suffix('.expected').read_bytes().rstrip(b'\n')
form='(prin1 '+fixture.read_text()+')';outputs=[]
for tag,binary in [('gnu',p.parent/'rebuilt-2026-10-01/emacs/src/emacs'),('baseline286',p.parent/'recovered-2026-10-03/vm-opcode-dispatch/emaxx/target/vm-dispatch-validation/release/emaxx')]:
    command=[str(binary),'-Q','--batch','--eval',form]
    inputs={str(f):sha(f) for f in (fixture,fixture.with_suffix('.expected'),binary,binary.with_suffix('.pdmp'),Path(__file__))}
    started=time.monotonic()
    r=subprocess.run(command,cwd=p,env=dict(os.environ,LANG='C',LC_ALL='C',EMAXX_GC_VERIFY='1'),capture_output=True,timeout=180)
    stem=p/('source288-native-arguments-lexical-'+tag)
    for suffix,data in (('.stdout',r.stdout),('.stderr',r.stderr)):
        with stem.with_suffix(suffix).open('xb') as f:f.write(data)
    result=dict(command=command,working_directory=str(p),environment_overrides=dict(LANG='C',LC_ALL='C',EMAXX_GC_VERIFY='1'),timeout_seconds=180,exit_code=r.returncode,elapsed_seconds=time.monotonic()-started,inputs=inputs,inputs_unchanged=all(sha(Path(n))==h for n,h in inputs.items()),stdout_sha256=hashlib.sha256(r.stdout).hexdigest(),stderr_hex=r.stderr.hex(),matches_expected=r.stdout==expected,
                qualification='Compiles lexical functions with GNU comp.el, matching the lexical-binding setup of comp-trampoline-compile. Covers0..8 fixed arguments,9/13 MANY, optional padding and rest. Actual native predicates, order and identity across GC are checked. Initial non-explicit lexical-binding probe is retained separately and is not sufficient to identify this ABI coverage.')
    with stem.with_suffix('.json').open('x') as f:json.dump(result,f,indent=2)
    print(tag,result['exit_code'],result['matches_expected'],r.stderr[:120],flush=True)
    assert r.returncode==0 and r.stdout==expected and not r.stderr and result['inputs_unchanged']
    outputs.append(r.stdout)
assert outputs[0]==outputs[1]
