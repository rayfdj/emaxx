from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
out = p / 'call-candidates-publication-stage'
out.mkdir(exist_ok=True)
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(node for node in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(node, ast.FunctionDef) and node.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected', '.h'}
assert read('source288-selected-audit.json')['status'] == 'passed'
assert read('source289-selected-audit.json')['status'] == 'passed'
assert read('vm-call-entry-performance-audit.json')['status'] == 'all 288 processes and actual results/modes verified'
files = {}
for file in p.iterdir():
    if not file.is_file() or file.suffix not in allowed:
        continue
    if file.name.startswith(('source288-', 'source289-')) and '-core-native' not in file.name:
        files[file.name] = file
    if file.suffix == '.py' and any(name in file.name for name in ('source288', 'source289')):
        files[file.name] = file
for name in ('compare-vm-dispatch-fixtures.py', 'printer-varied-v3-293638f0.el', 'printer-varied-v3-gnu.stdout',
             'source286-manifest.json', 'source286-selected-audit.json', 'source286-gate-inventory.log',
             'source286-release-inventory.log', 'native-and-vm-call-static-review.json',
             'call-candidates-queue-reordering.json', 'finish-call-candidates.py',
             'package-source196-failure-and197-results.py', Path(__file__).name):
    files[name] = p / name
scope = dict(status='selected native and VM call candidates validated; full goal incomplete',
             source288=read('source288-selected-audit.json'), source289=read('source289-selected-audit.json'),
             static_review=read('native-and-vm-call-static-review.json'),
             qualification='Source288 has524 verified inputs,273 selected passes per profile and44 exact ordinary GNU comparisons. Source289 includes that change and has526 inputs,274 selected passes per profile and45 ordinary comparisons. Every prior fixture remains; the one VM test setup only replaces the removed infallible conversion with clone. Both candidates retain198 generated rows/4088269 exact bytes. Source289 adds78 checked call-width rows across source/bytecode/native execution with GC. Portable patches replay bytes and modes fromd1120c70 and main21d20f0e. The initial source288 non-explicit lexical probe remains distinct. Two waiting supervisors were withdrawn before timing or source289 validation and replaced with a batched sequence; no completed or failed result was changed. This is selected evidence, not full-platform or performance-parity certification.', goal_complete=False)
package('source289-native-vm-calls-selected', files, scope)
files = {}
for tag in ('source286', 'source288', 'source289'):
    for directory in sorted(p.glob(tag + '-vm-call-entry-pilot-*')):
        for file in directory.rglob('*'):
            if file.is_file():
                files[str(file.relative_to(p))] = file
    for file in (p / (tag + '-core-native')).rglob('*'):
        if file.is_file() and file.suffix in allowed:
            files[str(file.relative_to(p))] = file
profiles = read('source289-call-profile-result.json')
assert profiles['inputs_unchanged'] and all(row['validation'] == 'completed' and row['samples'] == 20 for row in profiles['results'])
for path, digest in profiles['inputs'].items():
    assert sha(Path(path).read_bytes()) == digest
for file in (p / 'source289-call-profiles').rglob('*'):
    if file.is_file() and file.suffix in allowed:
        files[str(file.relative_to(p))] = file
for name in ('profile-source289-calls.py', 'source289-call-profile-result.json'):
    files[name] = p / name
for file in p.iterdir():
    if file.is_file() and file.suffix in allowed and (
        file.name.startswith(('vm-call-entry-performance-', 'native-arguments-performance-', 'call-candidates-'))
        or file.name in ('measure-vm-call-entry.py', 'audit-vm-call-entry-performance.py',
                         'measure-native-arguments.py', 'audit-native-arguments-performance.py', Path(__file__).name)):
        if file.name.endswith('-processes-before.txt'):
            continue
        files[file.name] = file
process_path = p / 'vm-call-entry-performance-processes-before.txt'
process_text = process_path.read_text()
competing = [line for line in process_text.splitlines() if any(token in line for token in (
    'cargo build ', 'cargo test ', '/rustc ', 'tools/ttydiff.py', 'tools/serial_grouped_gate.py', '/usr/bin/sample '))]
assert not competing
process_scope = dict(status='no competing build, test or profiling process at timing entry',
                     retained_local_inventory_sha256=sha(process_path.read_bytes()), competing_processes=competing,
                     qualification='The full local process inventory includes unrelated applications and is omitted from publication. Its hash and the exact task-relevant empty competitor result are retained. All benchmark commands, outputs, measurements and unfavorable results remain in this archive.')
process_receipt = p / 'call-candidates-timing-entry-process-audit.json'
with process_receipt.open('x') as stream:
    json.dump(process_scope, stream, indent=2)
files[process_receipt.name] = process_receipt
package('source289-native-vm-calls-performance', files,
        dict(status='all288 diagnostic processes and actual GNU results/modes verified',
             audit=read('vm-call-entry-performance-audit.json'),
             profiles=profiles,
             timing_entry=process_scope,
             qualification='Three rotated repetitions of the unchanged16-case pilot across source286, native-argument candidate288 and VM-entry candidate289. Own executable/image/native inputs for each candidate; no build, validation or profiling job runs during timing. The earlier two-candidate timing queue was withdrawn while waiting, after native preparation and before any timed process. All actual timing samples and unfavorable results are retained. No workload, size, expectation, timeout or tolerance changed. Real allocation counters, calibration and the nine-round3% acceptance criterion remain unsatisfied.', goal_complete=False))
