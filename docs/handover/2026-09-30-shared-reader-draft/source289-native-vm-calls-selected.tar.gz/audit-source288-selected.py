from pathlib import Path
import hashlib, json, re, subprocess

p = Path(__file__).parent.resolve()
root = p.parents[2]
c = p.parent / 'recovered-2026-10-05/native-argument-words/emaxx'
tag = 'source288'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read(tag + '-manifest.json')
prior_manifest = read('source286-manifest.json')
assert len(manifest) == 524 and all(sha(c / name) == digest for name, digest in manifest.items())
assert all(manifest[name] == digest for name, digest in prior_manifest.items() if name.startswith('tests/'))
prior_tests = subprocess.check_output(['git', 'show', 'd1120c70:src/lisp/primitives/tests.rs'], cwd=root, text=True)
tests, count = re.subn(r'\n#\[test\]\nfn native_argument_words_preserve_gnu_order_identity_and_optional_slots\(\) \{\n.*?\n\}\n\Z', '', (c / 'src/lisp/primitives/tests.rs').read_text(), flags=re.S)
assert count == 1 and tests == prior_tests
state = read(tag + '-validation-result.json')
assert len(state['results']) == 13
assert all(row['exit_code'] == 0 and not row['timed_out'] and row['source_unchanged'] for row in state['results'])
profiles = {}
new_test = 'lisp::primitives::tests::native_argument_words_preserve_gnu_order_identity_and_optional_slots'
selector = r'byte_?code|threads_retain_lexical_caller_roots|native_comp::runtime::|native.*(?:arity|calling|unwind|handler|argument)|numeric|arithmetic|remainder|modulo|bignum|float'
for profile in ('gate', 'release'):
    record = state['profiles'][profile]
    assert record['passed'] == 273 and record['failed'] == record['ignored'] == 0
    inventory = [line[:-6] for line in (p / (tag + '-' + profile + '-inventory.log')).read_text().splitlines() if line.endswith(': test')]
    prior = [line[:-6] for line in (p / ('source286-' + profile + '-inventory.log')).read_text().splitlines() if line.endswith(': test')]
    assert len(inventory) == len(set(inventory)) and set(inventory) == set(prior) | {new_test}
    names = [name for name in inventory if re.search(selector, name)]
    assert names == record['selectors']
    raw = (p / (tag + '-' + profile + '-selected.log')).read_text()
    assert re.findall(r'^test (\S+) \.\.\. ok$', raw, re.M) == names
    assert 'test result: ok. 273 passed; 0 failed; 0 ignored;' in raw
    assert sha(Path(record['binary'])) == sha(Path(record['retained_binary'])) == record['binary_sha256']
    for item in record['retained_inputs']:
        assert sha(Path(item['original'])) == sha(Path(item['retained'])) == item['sha256']
    profiles[profile] = record

ordinary = {}
names = list(read('source286-selected-audit.json')['ordinary_results']) + ['native-argument-words']
assert len(names) == 43
for name in names:
    comparison = read(tag + '-ordinary-' + name + '-comparison.json')
    assert comparison['passed'] and comparison['exact_match']
    outputs, programs = [], []
    for editor in ('gnu', 'emaxx'):
        stem = tag + '-ordinary-' + name + '-' + editor
        command, result = read(stem + '.command.json'), read(stem + '.result.json')
        assert all(sha(Path(path)) == digest for path, digest in command['inputs'].items())
        assert result == comparison['outcomes'][editor]
        assert result['exit_code'] == 0 and not result['timed_out'] and result['source_unchanged'] and result['inputs_unchanged']
        out, err = (p / (stem + '.stdout')).read_bytes(), (p / (stem + '.stderr')).read_bytes()
        assert out and not err and hashlib.sha256(out).hexdigest() == result['stdout_sha256'] and err.hex() == result['stderr_hex']
        assert result['expected_output'] is not False
        if name != 'native-argument-words':
            assert out == (p / ('source286-ordinary-' + name + '-' + editor + '.stdout')).read_bytes()
        else:
            assert out == (c / 'tests/fixtures/native-argument-words.expected').read_bytes().rstrip(b'\n')
        outputs.append(out)
        programs.append(command['command'][-1])
    assert outputs[0] == outputs[1] and programs[0] == programs[1]
    ordinary[name] = dict(passed=True, stdout_sha256=hashlib.sha256(outputs[0]).hexdigest(), stdout_bytes=len(outputs[0]))
assert read(tag + '-generated-loaded-comparison.json')['passed']
for editor in ('gnu', 'emaxx'):
    stem = tag + '-generated-loaded-' + editor
    command, result = read(stem + '-command.json'), read(stem + '-result.json')
    assert all(sha(Path(path)) == digest for path, digest in command['inputs'].items())
    assert result['exit_code'] == 0 and not result['timed_out'] and result['source_unchanged'] and result['inputs_unchanged']
    assert command['command'][-2:] == ['-l', str(p / 'printer-varied-v3-293638f0.el')]
    out = (p / (stem + '.stdout')).read_bytes()
    assert len(out) == 4088269 and len(out.splitlines()) == 198
    assert out == (p / 'printer-varied-v3-gnu.stdout').read_bytes() and not (p / (stem + '.stderr')).read_bytes()
artifacts = read(tag + '-ordinary-artifacts.json')
assert all(sha(Path(path)) == sha(Path(row['immutable_copy'])) == row['sha256'] for path, row in artifacts.items())
for stage in ('fmt', 'check', 'clippy', 'diff', 'ordinary-build', 'gate-build', 'release-build'):
    raw = (p / (tag + '-' + stage + '.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
    for line in raw.splitlines():
        if line.startswith('{'):
            assert json.loads(line).get('message', {}).get('level') not in ('warning', 'error')
portable = read(tag + '-portable-draft-audit.json')
assert len(portable['patches']) == 2
for row in portable['patches']:
    assert row['inputs'] == 524 and row['bytes_and_modes'] == 'exact' and sha(p / row['patch']) == row['sha256']
evidence = {str(path): sha(path) for path in p.glob(tag + '-*') if path.is_file() and path.suffix in ('.json', '.log', '.stdout', '.stderr', '.patch')}
record = dict(status='passed', source_inputs_verified=524, profiles=profiles,
              ordinary_comparisons=44, ordinary_results=ordinary,
              generated_rows=198, generated_bytes=4088269,
              ordinary_artifacts=artifacts, portable_replays=portable['patches'], evidence_files=evidence,
              qualification='Bounded selected validation; all prior tests and fixtures preserved. Fixed native calls fill existing register slots directly; MANY keeps owned writable storage. Actual same-input GNU results, native predicates, identity, optional/rest slots and GC are checked. The initial non-explicit lexical fixture is retained separately. Full final-platform validation and measured performance acceptance remain open.', goal_complete=False)
with (p / (tag + '-selected-audit.json')).open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps(dict(status='passed', source=tag, profiles={k: r['passed'] for k, r in profiles.items()}, ordinary_comparisons=44, source_inputs=524)))
