from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time

p = Path(__file__).parent.resolve()
c = p.parent / 'recovered-2026-10-05/native-argument-words/emaxx'
g = p.parent / 'rebuilt-2026-10-01/emacs'
target = c / 'target/vm-dispatch-validation'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda f: json.loads(f.read_text())
base = read(p / 'source286-manifest.json')
names = sorted(set(base) | {'tests/fixtures/native-argument-words.el', 'tests/fixtures/native-argument-words.expected'})
manifest = {n: sha(c / n) for n in names}
assert len(manifest) == 524 and (c.parent / 'emacs').resolve() == g.resolve()
assert all(manifest[n] == h for n, h in base.items() if n.startswith('tests/'))
changes = [n for n, h in manifest.items() if base.get(n) != h]
assert len(changes) == 4
with (p / 'source288-manifest.json').open('x') as f:
    json.dump(manifest, f, indent=2)
patch = subprocess.check_output(['git', 'diff', '--binary', '--', *names], cwd=c)
for n in sorted(set(manifest) - set(base)):
    r = subprocess.run(['git', 'diff', '--no-index', '--binary', '--', '/dev/null', n], cwd=c, capture_output=True)
    assert r.returncode == 1 and not r.stderr
    patch += r.stdout
with (p / 'source288-draft.patch').open('xb') as f:
    f.write(patch)
env = dict(os.environ, CARGO_TARGET_DIR=str(target), CARGO_BUILD_JOBS='1', LANG='C', LC_ALL='C',
           RUST_MIN_STACK='134217728', RUST_TEST_THREADS='1', EMAXX_GC_VERIFY='1',
           EMAXX_GNU_SOURCE_DIRECTORY=str(g), EMAXX_DUMP_SOURCE_DIRECTORY=str(g), EMACS_TEST_DIRECTORY=str(g / 'test'),
           EMAXX_IMAGE_TEMPLATE='1', EMAXX_FIXTURE_IMAGE_DIR=str(p / 'fixture-images-source288'))
state = dict(status='starting', candidate=str(c), source_manifest='source288-manifest.json', changes=changes,
             results=[], profiles={}, goal_complete=False)
unchanged = lambda: all(sha(c / n) == h for n, h in manifest.items())

def save_state():
    (p / 'source288-validation-state.json').write_text(json.dumps(state, indent=2) + '\n')

def run(stage, command, timeout=1800):
    assert unchanged()
    record = dict(command=command, working_directory=str(c), timeout_seconds=timeout,
                  environment_overrides={k: v for k, v in env.items() if k.startswith(('CARGO_', 'EMAXX_', 'RUST_', 'EMACS_TEST')) or k in ('LANG', 'LC_ALL')})
    with (p / ('source288-' + stage + '-command.json')).open('x') as f:
        json.dump(record, f, indent=2)
    state['status'] = 'running ' + stage
    save_state()
    started = time.monotonic()
    with (p / ('source288-' + stage + '.log')).open('xb') as log:
        try:
            completed = subprocess.run(command, cwd=c, env=env, stdin=subprocess.DEVNULL,
                                       stdout=log, stderr=subprocess.STDOUT, timeout=timeout)
            code, timed_out = completed.returncode, False
        except subprocess.TimeoutExpired:
            code, timed_out = None, True
    result = dict(stage=stage, exit_code=code, timed_out=timed_out,
                  elapsed_seconds=time.monotonic() - started, source_unchanged=unchanged())
    with (p / ('source288-' + stage + '-result.json')).open('x') as f:
        json.dump(result, f, indent=2)
    state['results'].append(result)
    save_state()
    print(json.dumps(result), flush=True)
    assert code == 0 and not timed_out and result['source_unchanged'], result

try:
    run('fresh-crate', ['cargo', 'clean', '--package', 'emaxx'])
    for stage, command in [
        ('fmt', ['cargo', 'fmt', '--all', '--', '--check']),
        ('check', ['cargo', 'check', '--locked', '--all-targets', '--all-features']),
        ('clippy', ['cargo', 'clippy', '--locked', '--all-targets', '--all-features', '--', '-D', 'warnings']),
        ('diff', ['git', 'diff', '--check']),
    ]:
        run(stage, command)
    for profile in ('gate', 'release'):
        run(profile + '-build', ['cargo', 'test', '--locked', '--profile', profile, '--all-features', '--lib', '--no-run', '--message-format=json'])
        artifacts = [json.loads(line) for line in (p / ('source288-' + profile + '-build.log')).read_text().splitlines() if line.startswith('{')]
        binaries = [Path(a['executable']) for a in artifacts if a.get('reason') == 'compiler-artifact' and a.get('profile', {}).get('test') and a.get('executable') and a['target']['name'] == 'emaxx' and 'lib' in a['target']['kind']]
        assert len(binaries) == 1
        binary = binaries[0]
        retained = p / ('source288-' + profile + '-libtest')
        assert not retained.exists()
        shutil.copy2(binary, retained)
        assert sha(binary) == sha(retained)
        run(profile + '-inventory', [str(binary), '--list'])
        inventory = [line[:-6] for line in (p / ('source288-' + profile + '-inventory.log')).read_text().splitlines() if line.endswith(': test')]
        prior = [line[:-6] for line in (p / ('source286-' + profile + '-inventory.log')).read_text().splitlines() if line.endswith(': test')]
        new_test = 'lisp::primitives::tests::native_argument_words_preserve_gnu_order_identity_and_optional_slots'
        assert set(inventory) == set(prior) | {new_test} and len(inventory) == len(set(inventory))
        selectors = [n for n in inventory if re.search(r'byte_?code|threads_retain_lexical_caller_roots|native_comp::runtime::|native.*(?:arity|calling|unwind|handler|argument)|numeric|arithmetic|remainder|modulo|bignum|float', n)]
        assert new_test in selectors
        run(profile + '-selected', [str(binary), '--exact', '--test-threads=1', *selectors])
        raw = (p / ('source288-' + profile + '-selected.log')).read_text()
        assert re.findall(r'^test (\S+) \.\.\. ok$', raw, re.M) == selectors
        assert f'test result: ok. {len(selectors)} passed; 0 failed; 0 ignored;' in raw
        state['profiles'][profile] = dict(passed=len(selectors), failed=0, ignored=0, selectors=selectors,
                                          binary=str(binary), retained_binary=str(retained), binary_sha256=sha(binary))
        retained_inputs = []
        retained_dir = p / ('source288-' + profile + '-retained-inputs')
        retained_dir.mkdir()
        for original in [binary, *sorted(Path(env['EMAXX_FIXTURE_IMAGE_DIR']).glob('*.pdmp'))]:
            copy = retained_dir / original.name
            shutil.copy2(original, copy)
            assert sha(copy) == sha(original)
            retained_inputs.append(dict(original=str(original), retained=str(copy), sha256=sha(copy), bytes=copy.stat().st_size))
        assert len(retained_inputs) >= 2
        state['profiles'][profile]['retained_inputs'] = retained_inputs
        save_state()
    run('ordinary-build', ['cargo', 'build', '--locked', '--release', '--all-features', '--bin', 'emaxx', '--bin', 'make-fingerprint', '--bin', 'compat-harness'])
    env['EMAXX_IMAGE_FORCE'] = '1'
    run('ordinary-image', ['sh', 'tools/build-image.sh', str(target / 'release/emaxx')])
    del env['EMAXX_IMAGE_FORCE']
    artifacts = {}
    for f in [target / 'release/emaxx', target / 'release/emaxx.pdmp']:
        copy = p / ('source288-ordinary-' + f.name)
        assert not copy.exists()
        shutil.copy2(f, copy)
        assert sha(copy) == sha(f)
        artifacts[str(f)] = dict(sha256=sha(f), immutable_copy=str(copy), bytes=f.stat().st_size)
    with (p / 'source288-ordinary-artifacts.json').open('x') as f:
        json.dump(artifacts, f, indent=2)
    state['status'] = 'strict, selected and ordinary build passed; raw audit and ordinary comparisons required'
except Exception as error:
    state.update(status='validation stopped', error=repr(error))
finally:
    save_state()
    with (p / 'source288-validation-result.json').open('x') as f:
        json.dump(state, f, indent=2)
print(json.dumps(dict(status=state['status'], profiles={k: r['passed'] for k, r in state['profiles'].items()}, error=state.get('error'))), flush=True)
sys.exit(0 if state['status'].startswith('strict, selected') else 1)
