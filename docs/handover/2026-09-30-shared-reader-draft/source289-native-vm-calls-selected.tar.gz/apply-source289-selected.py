from pathlib import Path
import hashlib, json, subprocess
p=Path(__file__).parent.resolve(); root=p.parents[2]
c=p.parent/'recovered-2026-10-05/vm-call-entry/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
read=lambda n:json.loads((p/n).read_text())
m,base=read('source289-manifest.json'),read('source286-manifest.json')
audit=read('source289-selected-audit.json'); perf=read('vm-call-entry-performance-audit.json')
assert audit['status']=='passed' and audit['ordinary_comparisons']==45
assert all(r['passed']==274 and r['failed']==r['ignored']==0 for r in audit['profiles'].values())
assert perf['status']=='all 288 processes and actual results/modes verified'
assert len(perf['cases'])==16
assert len(m)==526 and all(sha(c/n)==h for n,h in m.items())
assert len(base)==522 and all(sha(root/n)==h for n,h in base.items())
assert all(sha(Path(n))==h for n,h in audit['evidence_files'].items())
assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()=='runtime-char-tables'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head=='d1120c700d6a0bdee73dc391d2478668241c3ba5'
patch=p/'source289-portable-incremental.patch'
assert sha(patch)==next(r['sha256'] for r in audit['portable_replays'] if r['patch']==patch.name)
def run(stage, command):
    result=subprocess.run(command,cwd=root,capture_output=True,text=True)
    with (p/('source289-apply-'+stage+'.json')).open('x') as f:json.dump(dict(command=command,exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr),f,indent=2)
    result.check_returncode()
for stage,command in [('check',['git','apply','--check',str(patch)]),('patch',['git','apply',str(patch)]),('diff',['git','diff','--check'])]:run(stage,command)
assert all(sha(root/n)==h and (root/n).stat().st_mode&0o777==(c/n).stat().st_mode&0o777 for n,h in m.items())
expected={n for n,h in m.items() if base.get(n)!=h};assert len(expected)==9
run('stage',['git','add','--',*sorted(expected)])
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root,text=True).splitlines())==expected
run('commit',['git','-c','user.name=Ray','-c','user.email=26018378+rayfdj@users.noreply.github.com','commit','-m','Remove repeated work from native and bytecode call entry'])
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
record=dict(commit=commit,parent=head,source_inputs=526,source_manifest='source289-manifest.json',candidate=str(c),
            selected_audit_sha256=sha(p/'source289-selected-audit.json'),performance_audit_sha256=sha(p/'vm-call-entry-performance-audit.json'),
            qualification='Validated call-entry checkpoint:274 controls in both profiles and45 ordinary GNU comparisons, including78 call-width rows and198 generated reader/printer rows. Three rotated full16 pilots compare286, native-argument288 and VM-entry289; all288 outputs/modes match. Every timing, including unfavorable results, is retained; numerical interpretation is in the performance audit. Full-platform final validation, architecture/accounting and calibrated GNU performance parity remain open.',goal_complete=False)
with (p/'source289-applied-commit.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(record,indent=2))
