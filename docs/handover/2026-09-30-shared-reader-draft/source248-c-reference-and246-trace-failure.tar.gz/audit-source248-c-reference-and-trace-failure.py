from pathlib import Path
import hashlib, json, subprocess

p = Path(__file__).parent.resolve()
root = p.parents[2]
gnu = root / 'target/runtime-goal/recovered-2026-09-30/emacs'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())

def save(name, value):
    with (p / name).open('x') as stream:
        json.dump(value, stream, indent=2)

manifest = read('source248-manifest.json')
assert len(manifest) == 472
assert all(sha((root / name).read_bytes()) == digest for name, digest in manifest.items())
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=gnu, text=True).strip()
assert revision == '636f166cfc86aa90d63f592fd99f3fdd9ef95ebd'
c_files = {}
for name in ['src/coding.c', 'src/fns.c', 'src/lisp.h']:
    actual = (gnu / name).read_bytes()
    committed = subprocess.check_output(['git', 'show', revision + ':' + name], cwd=gnu)
    assert actual == committed
    c_files[name] = sha(actual)
controls = []
for fixture, prior in [('coding-candidate-symbol-properties', 'source246-coding-symbol-properties'),
                       ('overriding-property-identity', 'source246-overriding-property-identity')]:
    before = read(prior + '-negative-audit.json')
    after = read('source248-ordinary-' + fixture + '-comparison.json')
    actual = root / ('tests/fixtures/' + fixture + '.el')
    assert sha(actual.read_bytes()) == before['fixture_sha256']
    assert before['matches'] is False and after['passed'] and after['exact_match']
    expected = (root / ('tests/fixtures/' + fixture + '.expected')).read_bytes().rstrip(b'\n')
    outputs = {}
    for editor in ['gnu', 'emaxx']:
        negative = (p / (prior + '-' + editor + '.stdout')).read_bytes()
        positive = (p / ('source248-ordinary-' + fixture + '-' + editor + '.stdout')).read_bytes()
        assert sha(negative) == before['records'][editor]['stdout_sha256']
        assert sha(positive) == after['outcomes'][editor]['stdout_sha256']
        assert positive == expected
        outputs[editor] = dict(before=negative.decode(), after=positive.decode())
    assert outputs['gnu']['before'] == outputs['gnu']['after']
    controls.append(dict(fixture=fixture, unchanged_fixture_sha256=before['fixture_sha256'], outputs=outputs))
save('source248-c-reference-review.json', dict(status='reviewed against unchanged GNU C',
    gnu_revision=revision, c_files=c_files, root_inputs=472,
    mapping=[dict(gnu='coding.c:get_translation_table:6881 / lisp.h:SYMBOLP:1114',
                  rust='coding.rs:encoding_safety_translation_tables',
                  change='Resolve coding-owned symbol/list entries through existing get, including nil/t and enabled positioned symbols; leave the standard-table-only branch unchanged.'),
             dict(gnu='fns.c:plist_get:2606 / Fget:2622',
                  rust='dispatch/misc.rs:overriding_plist_property / direct_get',
                  change='Stop at the first matching property even if nil; nil then falls back to the real plist instead of searching later duplicates.')],
    controls=controls, goal_complete=False,
    qualification='Narrow source review of the two changed property behaviors, supported by identical-input negative and positive ordinary executions. This is not a claim that every surrounding coding or get behavior is complete. Full source248 platform runs are pending; no new object representation or property cache is introduced.'))

prefix = 'source246-linux-gnu-trace'
download = read(prefix + '-download.json')
base = p / (prefix + '-artifacts')
assert len(download['files']) == 31
assert all(sha((base / name).read_bytes()) == digest for name, digest in download['files'].items())
out = base / 'gnu-census-trace'
summary = json.loads((out / 'summary.json').read_text())
assert summary['status'] == 'diagnostic error'
assert summary['error'] == "ValueError('incomplete or failed GNU GC observation')"
assert len(summary['runs']) == 11
for row in summary['runs']:
    for suffix in ['stdout', 'stderr']:
        assert sha((out / row[suffix + '_file']).read_bytes()) == row[suffix + '_sha256']
ordinary = summary['runs'][:-1]
assert [row['padding_bytes'] for row in ordinary] == [None, 0, 8, 16, 32, 64, 128, 256, 1024, 4096]
expected = (root / 'tests/fixtures/vector-closure-rounded-census.expected').read_bytes().rstrip(b'\n')
for row in ordinary:
    assert row['exit_code'] == 0 and not row['timed_out'] and row['expected_output']
    assert (out / row['stdout_file']).read_bytes() == expected
    assert not (out / row['stderr_file']).read_bytes()
debugger = summary['runs'][-1]
assert debugger['exit_code'] == 1 and not debugger['timed_out']
events = json.loads((out / 'vector-closure-rounded-census-trace-events.json').read_text())
assert len(events) == 1 and events[0]['event'] == 'observer completed'
assert events[0]['explicit_collections'] == events[0]['captured_sweeps'] == 0
assert 'Error: end-of-file nil' in (out / debugger['stdout_file']).read_text()
assert 'End of file during parsing' in (out / debugger['stderr_file']).read_text()
head = '2dd1dea85d6fbd9ed3017346d4d17348bdbbd329'
executed = {}
for name in ['tools/diagnose_gnu_census_trace.py', 'tools/diagnostics/gnu-census-snapshot.py', '.github/workflows/frozen-run.yml']:
    data = subprocess.check_output(['git', 'show', head + ':' + name], cwd=root)
    target = p / (prefix + '-executed') / name
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as stream:
        stream.write(data)
    executed[name] = sha(data)
save(prefix + '-failure-audit.json', dict(status='failed diagnostic preserved and audited',
    run_id=36848112001, commit=head, downloaded_files=31, ordinary_processes_passed=10,
    ordinary_mismatches=0, debugger_exit=1, explicit_collections=0, captured_sweeps=0,
    unstarted_fixture='vector-pseudovector-word-census', executed_inputs=executed,
    qualification='GNU --eval received split/escaped arguments under GDB and stopped with end-of-file before the fixture ran. The observer used startup-with-shell off with GDB --args. No GC inventory or root cause was observed. Capture bytes are verified, but the helper aborted before post-run oracle/input verification. The full Linux Rust failure remains unresolved; no Emaxx runtime behavior changed in this diagnostic.'))
print(json.dumps(dict(c_reference='two repairs follow GNU C and retain both negative controls',
                      diagnostic='10 ordinary matches; observer failed before any GC observation')))
