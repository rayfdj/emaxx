from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
names = ['source248-c-reference-review.json', 'source246-linux-gnu-trace-failure-audit.json',
         'audit-source248-c-reference-and-trace-failure.py',
         'download-source246-linux-gnu-trace.py', 'source246-linux-gnu-trace-final-state.json',
         'source246-linux-gnu-trace-artifacts.json', 'source246-linux-gnu-trace-download.json',
         'source246-linux-gnu-trace-failed.log', Path(__file__).name]
files = {name: p / name for name in names}
for directory in ['source246-linux-gnu-trace-artifacts', 'source246-linux-gnu-trace-executed']:
    for path in (p / directory).rglob('*'):
        if path.is_file() and path.name not in ['emacs', 'emacs.pdmp']:
            files[str(path.relative_to(p))] = path
package('source248-c-reference-and246-trace-failure', files,
        dict(c_reference=read('source248-c-reference-review.json'),
             diagnostic=read('source246-linux-gnu-trace-failure-audit.json'),
             qualification='Two narrow source248 property repairs follow the exact GNU C reference and retain identical negative/positive fixture bytes. Full source248 validation is pending. Linux GNU observer failure is preserved: ten first-fixture ordinary matches, zero GC observations, second fixture and final verification unstarted. All downloaded raw members except the locally retained GNU executable/dump are packaged; their hashes remain in the manifest. No original failed gate is converted to a pass.'))
