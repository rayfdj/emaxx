from pathlib import Path
import hashlib, json, subprocess, zipfile

p = Path(__file__).parent.resolve()
run = 36848112001
head = '2dd1dea85d6fbd9ed3017346d4d17348bdbbd329'
prefix = 'source246-linux-gnu-trace'

def save(name, data):
    with (p / name).open('x') as stream:
        json.dump(data, stream, indent=2)

def query(args):
    return json.loads(subprocess.check_output(['gh', *args], text=True))

state = query(['run', 'view', str(run), '--repo', 'rayfdj/emaxx', '--json',
               'status,conclusion,headSha,url,jobs'])
assert state['status'] == 'completed' and state['conclusion'] == 'failure'
assert state['headSha'] == head
save(prefix + '-final-state.json', state)
artifacts = query(['api', f'repos/rayfdj/emaxx/actions/runs/{run}/artifacts'])
save(prefix + '-artifacts.json', artifacts)
assert artifacts['total_count'] == len(artifacts['artifacts']) == 1
artifact = artifacts['artifacts'][0]
assert artifact['name'] == 'ordinary-linux-' + head and not artifact['expired']
archive = p / (prefix + '-artifact.zip')
with archive.open('xb') as stream:
    subprocess.run(['gh', 'api', f"repos/rayfdj/emaxx/actions/artifacts/{artifact['id']}/zip"],
                   stdout=stream, check=True)
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
if artifact.get('digest'):
    assert artifact['digest'] == 'sha256:' + digest
destination = p / (prefix + '-artifacts')
destination.mkdir()
files = {}
with zipfile.ZipFile(archive) as contents:
    for member in contents.infolist():
        path = Path(member.filename)
        assert not path.is_absolute() and '..' not in path.parts
        assert (member.external_attr >> 16) & 0o170000 != 0o120000
        if member.is_dir():
            continue
        target = destination / path
        target.parent.mkdir(parents=True, exist_ok=True)
        data = contents.read(member)
        with target.open('xb') as stream:
            stream.write(data)
        files[str(path)] = hashlib.sha256(data).hexdigest()
save(prefix + '-download.json', dict(run_id=run, source_commit=head, artifact=artifact,
     archive_sha256=digest, files=files))
print(json.dumps(dict(run_id=run, status='downloaded and archive integrity checked',
                     files=len(files), archive_sha256=digest)))

with (p / (prefix + '-failed.log')).open('xb') as stream:
    subprocess.run(['gh', 'run', 'view', str(run), '--repo', 'rayfdj/emaxx', '--log-failed'], stdout=stream, check=True)
print(''.join((p / (prefix + '-failed.log')).read_text().splitlines(keepends=True)[-25:]))
