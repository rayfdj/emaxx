from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile
p=Path(__file__).parent.resolve();out=p.parents[2]/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest();read=lambda n:json.loads((p/n).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
closed=read('source292-validation-closed-result.json')
assert all(r['exit_code']==0 and r['source_unchanged'] for r in closed['results'])
assert all(r['passed']==290 and r['ignored']==2 for r in closed['profiles'].values())
assert read('source293-manifest.json')==read('source293-preflight-manifest.json')
files={}
names=['source292-manifest.json','source293-manifest.json','source293-preflight-manifest.json',
       'source292-preparation.json','source293-preparation.json','source292-scope.json','source293-static-review.json',
       'source292-portable-incremental.patch','source292-portable-complete.patch','source292-portable-draft-audit.json',
       'source293-preflight-portable-incremental.patch','source293-preflight-portable-complete.patch','source293-preflight-portable-draft-audit.json',
       'source292-validation-result.json','source292-continuation-result.json','source292-validation-closed-result.json',
       'source292-wrapper-stop-review.json','source292-image-setup-review.json','source292-ordinary-artifacts.json',
       'source292-motion-reference.json','source292-motion-gnu.stdout','source292-motion-gnu.stderr',
       'buffer-selection-result.json','buffer-selection-v2-result.json',
       'buffer-performance-sequence-result.json','buffer-performance-sequence-v2-result.json',
       'buffer-line-parser-negative-controls.json','source290-native-followup-review.json',
       'run-source292-validation.py','continue-source292-validation.py','finish-source292-image.py',
       'run-source293-validation.py','run-source293-validation-v2.py','buffer_line_validation_support.py',
       'compare-vm-dispatch-fixtures.py','compare-source292-generated-loaded.py','compare-source293-generated-loaded.py',
       'compare-buffer-line-broad-probe.py','replay-buffer-line-drafts.py',
       'audit-buffer-line-selected.py','audit-buffer-line-selected-v2.py','audit-buffer-line-selected-v3.py',
       'run-buffer-line-followups.py','run-buffer-line-followups-v2.py','run-buffer-line-followups-v3.py',
       'measure-buffer-line.py','audit-buffer-line-performance.py','finish-buffer-line-performance.py',
       'finish-buffer-line-performance-v2.py','finish-buffer-line-performance-v3.py',
       'probe-source290-line-index.py','package-source196-failure-and197-results.py',Path(__file__).name]
for name in names: files[name]=p/name
for f in p.glob('source290-line-index-baseline-*'):
    if f.is_file(): files[f.name]=f
for prefix in ['source292-cache-clone','source292-fresh-crate','source292-fmt','source292-check','source292-clippy','source292-diff','source292-gate','source292-release','source292-ordinary-build','source292-ordinary-image']:
    for f in p.glob(prefix+'*'):
        if f.is_file() and f.suffix in {'.json','.log'}: files[f.name]=f
for name in ['source293-validation-state.json','buffer-selection-v3-state.json','buffer-performance-sequence-v3-state.json']:
    snapshot=p/(name.removesuffix('.json')+'-launch-snapshot.json')
    with snapshot.open('x') as f:json.dump(read(name),f,indent=2)
    files[snapshot.name]=snapshot
package('source292-293-buffer-line-drafts',files,dict(status='portable unapplied drafts; source292 strict/selected/build closed, source293 validation running',source292_closed=closed,source293_snapshot=read('source293-validation-state-launch-snapshot.json'),qualification='532 inputs and file modes replay exactly from7f687d58 and main21d20f0e for each variant. Source292 isolates LF-only rope metadata correction;293 also replaces the backward scan with existing metadata lookup. Original broad GNU probe records155 differing rows;60 include existing display-column defects, whose cause and pending status are explicit. A separate338-row line-only control passes in both292 profiles; ordinary replays and293 validation/measurement remain pending. Original parser and missing build-helper orchestration failures stay preserved. No full validation, speed, display-width repair or goal completion is claimed.',goal_complete=False))
