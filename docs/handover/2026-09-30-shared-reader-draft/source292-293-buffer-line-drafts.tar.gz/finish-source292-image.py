from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys, time
p = Path(__file__).parent.resolve(); root = p.parents[2]
c = p.parent/'recovered-2026-10-05/buffer-line-index/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p/n).read_text())
state = read('source292-continuation-result.json')
assert state['status']=='validation stopped' and state['results'][-1]['stage']=='ordinary-image' and state['results'][-1]['exit_code']==127
assert len(state['results'])==14 and all(r['exit_code']==0 and r['source_unchanged'] for r in state['results'][:-1])
m=read('source292-manifest.json');assert all(sha(c/n)==h for n,h in m.items())
base=read('source292-preparation.json')['base_commit']
original_script=subprocess.check_output(['git','show',base+':tools/build-image.sh'],cwd=root)
setup=[]
for folder in ('buffer-line-index','buffer-line-lookup'):
    checkout=p.parent/'recovered-2026-10-05'/folder/'emaxx'
    script=checkout/'tools/build-image.sh';assert not script.exists()
    script.write_bytes(original_script);script.chmod(0o755)
    setup.append(dict(path=str(script),sha256=sha(script),source_commit=base))
with (p/'source292-image-setup-review.json').open('x') as f:
    json.dump(dict(original_stage='source292-ordinary-image-result.json',reason='Sparse checkout selected runtime/benchmark inputs but omitted the unchanged checked-in image build shell script. The ordinary binary build and both selected profiles already passed. Restore the exact base-commit script in each checkout; do not change or rerun completed runtime checks.',restored_files=setup,goal_complete=False),f,indent=2)
command_record=read('source292-ordinary-image-command.json')
command_record['inputs']={str(f):sha(f) for f in [c/'tools/build-image.sh',Path(__file__)]}
with (p/'source292-ordinary-image-recovered-command.json').open('x') as f:json.dump(command_record,f,indent=2)
start=time.monotonic()
with (p/'source292-ordinary-image-recovered.log').open('xb') as log:
    r=subprocess.run(command_record['command'],cwd=c,env=dict(os.environ,**command_record['environment_overrides']),stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,timeout=command_record['timeout_seconds'])
result=dict(stage='ordinary-image-recovered',exit_code=r.returncode,timed_out=False,elapsed_seconds=time.monotonic()-start,source_unchanged=all(sha(c/n)==h for n,h in m.items()))
with (p/'source292-ordinary-image-recovered-result.json').open('x') as f:json.dump(result,f,indent=2)
assert result['exit_code']==0 and result['source_unchanged']
artifacts={}
for file in [c/'target/vm-dispatch-validation/release/emaxx',c/'target/vm-dispatch-validation/release/emaxx.pdmp']:
    copy=p/('source292-ordinary-'+file.name);assert not copy.exists();shutil.copy2(file,copy)
    assert sha(copy)==sha(file)
    artifacts[str(file)]=dict(sha256=sha(file),immutable_copy=str(copy),bytes=file.stat().st_size)
with (p/'source292-ordinary-artifacts.json').open('x') as f:json.dump(artifacts,f,indent=2)
state['results']=state['results'][:-1]+[result]
state.update(status='strict, selected and ordinary build passed; raw audit and ordinary comparisons required',original_failed_attempts=['source292-validation-result.json','source292-continuation-result.json'],image_setup_review='source292-image-setup-review.json')
state.pop('error',None)
with (p/'source292-validation-closed-result.json').open('x') as f:json.dump(state,f,indent=2)
print(json.dumps(dict(status=state['status'],profiles={k:(v['passed'],v['ignored']) for k,v in state['profiles'].items()},original_failures_retained=True)))
