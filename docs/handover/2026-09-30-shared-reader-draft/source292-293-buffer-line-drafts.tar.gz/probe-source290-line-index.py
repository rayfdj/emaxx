from pathlib import Path
import hashlib, json, os, subprocess, time
p = Path(__file__).parent.resolve()
c = p.parent / 'recovered-2026-10-05/buffer-line-index/emaxx'
fixture = c / 'tests/fixtures/buffer-lf-line-index.el'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
form = '(prin1 ' + fixture.read_text() + ')'
editors = dict(gnu=p.parent / 'rebuilt-2026-10-01/emacs/src/emacs', emaxx=p.parent / 'recovered-2026-10-05/vm-integer-path/emaxx/target/vm-dispatch-validation/release/emaxx')
outputs = {}; outcomes = {}
for editor, binary in editors.items():
    stem = p / ('source290-line-index-baseline-' + editor)
    command = [str(binary), '-Q', '--batch', '--eval', form]
    inputs = {str(f): sha(f) for f in [fixture, binary, binary.with_suffix('.pdmp'), Path(__file__)]}
    with stem.with_suffix('.command.json').open('x') as f:
        json.dump(dict(command=command, inputs=inputs, cwd=str(p), environment_overrides=dict(LANG='C', LC_ALL='C', EMAXX_GC_VERIFY='1'), timeout_seconds=120), f, indent=2)
    start = time.monotonic()
    r = subprocess.run(command, cwd=p, env=dict(os.environ, LANG='C', LC_ALL='C', EMAXX_GC_VERIFY='1'), stdin=subprocess.DEVNULL, capture_output=True, timeout=120)
    stem.with_suffix('.stdout').write_bytes(r.stdout)
    stem.with_suffix('.stderr').write_bytes(r.stderr)
    result = dict(exit_code=r.returncode, elapsed_seconds=time.monotonic()-start, stdout_sha256=hashlib.sha256(r.stdout).hexdigest(), stderr_sha256=hashlib.sha256(r.stderr).hexdigest(), inputs_unchanged=all(sha(Path(n)) == h for n,h in inputs.items()))
    stem.with_suffix('.result.json').write_text(json.dumps(result, indent=2))
    assert r.returncode == 0 and not r.stderr and result['inputs_unchanged']
    outputs[editor] = r.stdout; outcomes[editor] = result
expected = fixture.with_suffix('.expected')
assert not expected.exists()
expected.write_bytes(outputs['gnu'] + b'\n')
record = dict(exact_match=outputs['gnu']==outputs['emaxx'], outcomes=outcomes, expected_from='actual GNU output', goal_complete=False)
(p / 'source290-line-index-baseline-comparison.json').write_text(json.dumps(record, indent=2))
print(json.dumps(record))
