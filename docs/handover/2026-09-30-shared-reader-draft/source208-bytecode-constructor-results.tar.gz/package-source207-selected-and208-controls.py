from pathlib import Path
import ast
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
tree = ast.parse((p / 'package-source196-failure-and197-results.py').read_text())
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected'}
prefixes = ('source207-gate-', 'source207-release-', 'source207-ordinary-',
            'source207-selected-', 'source207-check', 'source207-fmt', 'source207-clippy', 'source207-diff')
files = {f.name: f for f in p.iterdir() if f.is_file() and f.suffix in allowed and f.name.startswith(prefixes)}
for name in ['audit-source207-selected.py', 'source207-applied-source-audit.json',
             'source207-push.json', 'source207-remote-head.json', 'source207-pr-body.md',
             'source207-linux-rust-dispatch.json', 'source207-linux-rust-initial-state.json',
             'source207-linux-frozen-dispatch.json', 'source207-linux-frozen-initial-state.json',
             'source207-complete-validation-launch.json', 'run-source207-full-gate.py',
             'run-source207-full-tty.py', 'source207-full-gate-command.json',
             'source207-full-ttydiff-command.json', 'compare-recovered-continuation-fixtures.py',
             'eval-original-argument-words.el', 'eval-original-argument-words.expected',
             Path(__file__).name]:
    files[name] = p / name
package('source207-eval-selected-validation', files, json.loads((p / 'source207-selected-audit.json').read_text()))
prefixes = ('source208-check', 'source208-fmt', 'source208-clippy', 'source208-diff',
            'source208-gate-', 'source208-controls-')
files = {f.name: f for f in p.iterdir() if f.is_file() and f.suffix in allowed and f.name.startswith(prefixes)}
for name in ['audit-source208-controls.py', 'test-bytecode-controls208.py',
             'test-bytecode-controls-next.py', Path(__file__).name]:
    files[name] = p / name
package('source208-bytecode-constructor-results', files, json.loads((p / 'source208-controls-audit.json').read_text()))
