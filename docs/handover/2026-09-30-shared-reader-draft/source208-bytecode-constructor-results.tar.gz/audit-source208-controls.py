from pathlib import Path
import ast
import hashlib
import json
import re

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/bytecode-closure/emaxx'
read = lambda name: json.loads((p / name).read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
manifest = read('source208-manifest.json')
assert len(manifest) == 418 and all(sha(root / name) == digest for name, digest in manifest.items())
tree = ast.parse((p / 'audit-shared-reader196-fresh-selected.py').read_text())
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'audit_log')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<raw-auditor>', 'exec'))
command = read('source208-gate-controls-command.json')
result = read('source208-gate-controls-result.json')
assert result['exit_code'] == 101 and result['source_unchanged']
assert sha(p / 'source208-gate-libtest') == command['binary_sha256']
names = command['selected_inventory']
assert len(names) == 6
failed = audit_log(names, (p / 'source208-gate-controls.log').read_text(), 2, 4)
assert [name.rsplit('::', 1)[1] for name in failed] == [
    'bytecode_closure_allocation_is_header_and_actual_lisp_slots',
    'bytecode_closure_header_and_words_are_the_native_payload',
    'bytecode_code_mutation_between_calls_matches_gnu',
    'bytecode_code_mutation_during_active_call_matches_gnu',
]
for label in ['check', 'fmt', 'clippy', 'diff', 'gate-build']:
    outcome = read('source208-' + label + '-result.json')
    assert outcome['exit_code'] == 0 and outcome['source_unchanged']
    raw = (p / ('source208-' + label + '.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
    for line in raw.splitlines():
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        assert item.get('message', {}).get('level') not in ['error', 'warning']
    if label in ['fmt', 'diff']:
        assert not raw
driver = (p / 'source208-controls-driver.log').read_text()
assert 'FileNotFoundError' in driver and 'source208-gate-baseline.log' in driver
assert read('source208-controls-result.json')['steps'][-1]['exit_code'] == 1
record = dict(status='partial constructor repair; four original controls still fail',
              inputs_verified=418, binary_sha256=command['binary_sha256'],
              strict_checks='passed with zero warnings', passed=2, failed=4, ignored=0,
              passing_names=[n for n in names if n not in failed], failing_names=failed,
              raw_libtest_exit_code=101, supervisor_exit_code=1,
              footer_error='After preserving all six raw results, the helper tried to print the old baseline log filename. Its FileNotFoundError changes the wrapper exit to 1; the actual libtest exit is 101. No test is omitted or rerun.',
              raw_hashes={name: sha(p / name) for name in ['source208-gate-controls.log', 'source208-gate-controls-command.json', 'source208-gate-controls-result.json', 'source208-controls-driver.log']},
              qualification='GNU constructor field validation, slot sharing, valid cyclic/dotted descriptors and extra slots pass. Both layout and both live-code mutation assertions remain failed. No complete bytecode representation, full-gate or performance claim. This separate draft is not the published runtime.')
with (p / 'source208-controls-audit.json').open('x') as f:
    json.dump(record, f, indent=2)
    f.write('\n')
print(json.dumps(record, indent=2))
