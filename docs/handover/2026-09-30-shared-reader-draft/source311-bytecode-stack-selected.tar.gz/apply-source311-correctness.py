from pathlib import Path
import hashlib, json, subprocess

p = Path(__file__).parent.resolve()
root = p.parents[2]
c = p.parent / 'recovered-2026-10-06/bytecode-stack/emaxx'
d = root / 'docs/handover/2026-09-30-shared-reader-draft'
read = lambda n: json.loads((p / n).read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert head == '48593a3562ba26384bd9916099dbb08e53aa205e'
decision = read('source311-application-decision.json')
assert decision['status'].startswith('apply source311')
selected = read('source311-selected-audit.json')
assert selected['status'] == 'passed' and selected['source_inputs_verified'] == 548 and selected['auxiliary_inputs_verified'] == 94
assert selected['ordinary_comparisons'] == 58
assert all(r['passed'] == 1065 and r['failed'] == r['ignored'] == 0 for r in selected['profiles'].values())
for audit in [selected]:
    assert all(sha(Path(n)) == h for n, h in audit['evidence_files'].items())
assert all(sha(root / n) == h for n, h in read('source310-manifest.json').items())
manifest, modes = read('source311-manifest.json'), read('source311-modes.json')
assert all(sha(c / n) == h and (c / n).stat().st_mode & 0o777 == modes[n] for n, h in manifest.items())
auxiliary = read('source310-validation-input-recovery.json')['auxiliary_inputs']
assert all(sha(root / n) == item['sha256'] and (root / n).stat().st_mode & 0o777 == item['mode'] for n, item in auxiliary.items())
portable = read('source311-portable-draft-audit.json')['patches'][0]
assert portable['base'] == '5e6f6fc89654b5e695161f5e1713d06ff8ca1f3c'
patch = p / portable['patch']
assert sha(patch) == portable['sha256']
steps = []
for command in [['git', 'apply', '--check', str(patch)], ['git', 'apply', str(patch)], ['git', 'diff', '--check']]:
    result = subprocess.run(command, cwd=root, capture_output=True, text=True)
    steps.append(dict(command=command, exit_code=result.returncode, stdout=result.stdout, stderr=result.stderr))
    assert result.returncode == 0, steps[-1]
assert all(sha(root / n) == h and (root / n).stat().st_mode & 0o777 == modes[n] for n, h in manifest.items())
record = dict(status='source311 applied; all548 validated runtime inputs and94 auxiliary inputs verified',
              pre_apply_head=head, portable_patch_base=portable['base'], patch_sha256=sha(patch), steps=steps,
              original_failed_attempt='Actual source310 stack overflow and separate moved-image setup failure retained',
              performance_status='pending; unchanged full16 source310/source311 Linux diagnostic will follow publication',
              goal_complete=False)
with (p / 'source311-applied-source-verification.json').open('x') as f:
    json.dump(record, f, indent=2)
for name in ['source311-application-decision.json', 'source311-applied-source-verification.json']:
    with (d / name).open('xb') as f:
        f.write((p / name).read_bytes())
print(record['status'])
