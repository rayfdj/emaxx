from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
out = p.parents[2] / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda n: json.loads((p / n).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
audit = read('source311-selected-audit.json')
assert audit['status'] == 'passed' and audit['source_inputs_verified'] == 548
assert audit['auxiliary_inputs_verified'] == 94
assert all(r['passed'] == 1065 and r['failed'] == r['ignored'] == 0 for r in audit['profiles'].values())
assert audit['ordinary_comparisons'] == 58
for n, h in audit['evidence_files'].items():
    assert sha(Path(n).read_bytes()) == h
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected'}
files, excluded = {}, []
for f in p.iterdir():
    if f.is_file() and f.suffix in allowed and f.name.startswith('source311-'):
        files[f.name] = f
    elif f.is_dir() and f.name.startswith('source311-') and any(w in f.name for w in ['file-lifecycle', 'active-lifecycle', 'retained-inputs']):
        for item in f.rglob('*'):
            if not item.is_file():
                continue
            if item.suffix in allowed:
                files[str(item.relative_to(p))] = item
            else:
                excluded.append(dict(path=str(item.relative_to(p)), bytes=item.stat().st_size, sha256=sha(item.read_bytes())))
for f in p.glob('*.py'):
    if '311' in f.name and 'sequence' not in f.name and any(w in f.name for w in ['native-unit', 'source311']):
        files[f.name] = f
for pattern in ['bytecode-post-gc-*.el', 'native-unit309-*.el', 'source309-lifecycle-baseline-*', 'source309-file-lifecycle-baseline-comparison.json', 'source309-metadata-*.stdout']:
    for f in p.glob(pattern):
        if f.is_file() and f.suffix in allowed:
            files[f.name] = f
for n in [
    'source310-manifest.json', 'source310-modes.json', 'source310-selected-audit.json', 'source310-resumed-validation-result.json',
    'source310-resumed-gate-inventory.log', 'source310-resumed-release-inventory.log', 'source310-validation-input-recovery.json',
    'source304-selected-audit.json', 'native_fixed_validation_support.py',
    'printer-varied-v3-293638f0.el', 'printer-varied-v3-gnu.stdout', 'vm-stack-capacity.el',
    'source302-line-broad-gnu.stdout', 'package-source196-failure-and197-results.py', Path(__file__).name,
    'core_runtime_perf_pair.py', 'test-core-runtime-perf-pair.py',
]:
    files[n] = p / n
assert all(f.is_file() for f in files.values())
package('source311-bytecode-stack-selected', files, dict(
    status='selected bytecode-stack correctness validated; full-platform and performance requirements separate',
    source_inputs=548, auxiliary_inputs=94, passes_per_profile=1065, new_focused_per_profile=5,
    ordinary_comparisons=58, generated_rows=198, excluded_binaries=excluded, goal_complete=False,
    qualification=audit['qualification']))
