from pathlib import Path
import ast
p=Path(__file__).parent
old=(p/'audit-native-unit310-selected-resumed.py').read_text()
head='''from pathlib import Path
import hashlib, json, re
from native_fixed_validation_support import audit_selected

p = Path(__file__).parent.resolve()
c = p.parent / 'recovered-2026-10-06/bytecode-stack/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p / n).read_text())
manifest = read('source311-manifest.json')
modes = read('source311-modes.json')
assert len(manifest) == len(modes) == 548
assert all(sha(c / n) == h and (c / n).stat().st_mode & 0o777 == modes[n] for n, h in manifest.items())
prior = read('source310-manifest.json')
assert all(manifest[n] == h for n, h in prior.items() if n.startswith(('tests/', 'tools/', 'compat/')))
assert manifest['src/anti_cheat.rs'] == prior['src/anti_cheat.rs']
auxiliary = read('source310-validation-input-recovery.json')['auxiliary_inputs']
assert len(auxiliary) == 94
assert all(sha(c / n) == item['sha256'] and (c / n).stat().st_mode & 0o777 == item['mode'] for n, item in auxiliary.items())
assert all('bc_functions' not in (c / n).read_text() for n in manifest if n.endswith('.rs'))
development = read('source311-stack-development-result.json')
assert development['status'].startswith('development strict and selected controls passed')
assert manifest == read('source311-stack-development-manifest.json')
assert all(r['exit_code'] == 0 and not r['timed_out'] and r['source_unchanged'] for r in development['results'])
assert sha(p / development['runner']) == development['runner_sha256']
state = read('source311-validation-result.json')
assert state['development_validation']['sha256'] == sha(p / 'source311-stack-development-result.json')
assert state['status'] == 'strict, selected and ordinary build passed; raw audit and ordinary comparisons required'
assert all(r['exit_code'] == 0 and not r['timed_out'] and r['source_unchanged'] for r in state['results'])
assert sha(p / state['runner']) == state['runner_sha256']
new = {
    'lisp::bytecode::vm::bytecode_stack_footers_share_storage_and_preserve_borrowed_caller_arguments',
    'lisp::primitives::tests::bytecode_stack_capacity_and_nested_reservations_match_gnu',
}
focused_names = sorted(new | {'lisp::bytecode::vm::taken_bytecode_branch_outside_storage_errors_without_leaking_a_frame',
    'lisp::primitives::tests::threads_retain_lexical_caller_roots_across_separate_callee_environments',
    'lisp::primitives::tests::suspended_bytecode_retains_operand_and_unwind_roots'})
profiles = {}
for profile, required in [('gate', 3055), ('release', 3054)]:
    inventory = lambda tag: [line[:-6] for line in (p / f'{tag}-{profile}-inventory.log').read_text().splitlines() if line.endswith(': test')]
    names = inventory('source311')
    assert len(names) == len(set(names)) == required
    assert set(names) == set(inventory('source310-resumed')) | new
    baseline = set(read('source310-resumed-validation-result.json')['profiles'][profile]['selectors'])
    selected = [n for n in names if n in baseline or n in development['selected']['selectors'] or n in new]
    assert len(baseline) == 1036 and len(selected) == 1065 and baseline | new <= set(selected)
    assert len([n for n in selected if n.startswith('anti_cheat::')]) == 24
    record = state['profiles'][profile]
    assert record['selectors'] == selected
    focused = audit_selected((p / f'source311-{profile}-focused.log').read_text(), focused_names)
    counts = audit_selected((p / f'source311-{profile}-selected.log').read_text(), selected)
    assert focused['passed'] == 5 and counts['passed'] == record['passed'] == 1065
    assert sha(Path(record['binary'])) == sha(Path(record['retained_binary'])) == record['binary_sha256']
    for item in record['retained_inputs']:
        assert sha(Path(item['original'])) == sha(Path(item['retained'])) == item['sha256']
    messages = [json.loads(line) for line in (p / ('source311-stack-development-build.log' if profile == 'gate' else 'source311-release-build.log')).read_text().splitlines() if line.startswith('{')]
    artifacts = [a for a in messages if a.get('reason') == 'compiler-artifact' and a['target']['name'] == 'emaxx' and a.get('profile', {}).get('test') and a.get('executable')]
    assert len(artifacts) == 1 and artifacts[0]['fresh'] is False and artifacts[0]['executable'] == record['binary']
    profiles[profile] = dict(**counts, focused=focused, selectors=selected, binary_sha256=record['binary_sha256'])
for stage in ['fmt', 'check', 'clippy', 'build', 'diff', 'release-build', 'ordinary-build']:
    prefix = 'source311-stack-development-' if stage in ['fmt', 'check', 'clippy', 'build'] else 'source311-'
    raw = (p / (prefix + stage + '.log')).read_text()
    assert not re.search(r'^warning(?:\\[.*\\])?:', raw, re.M)
    for line in raw.splitlines():
        if line.startswith('{'):
            assert json.loads(line).get('message', {}).get('level') not in ['warning', 'error']
'''
body=old[old.index("artifacts = read('source310-ordinary-artifacts.json')"):old.index("assert read('source310-owner-negative2-result.json')")]
body=body.replace('source310-resumed-ordinary-queue','source311-ordinary-queue').replace('source310','source311').replace("== 546", "== 548")
body=body.replace("'native-unit-authority']", "'native-unit-authority', 'bytecode-stack-layout', 'vm-stack-capacity']").replace("== 52", "== 54")
tail='''negative = read('source311-stack-negative-audit.json')
assert negative['status'] == 'verified original setup failure and actual source310 semantic negative'
evidence = {str(f): sha(f) for f in p.glob('source311-*') if f.is_file() and f.suffix in ['.json', '.log', '.stdout', '.stderr', '.patch', '.el', '.expected']}
result = dict(status='passed', source_inputs_verified=548, auxiliary_inputs_verified=94, profiles=profiles, ordinary_comparisons=58,
              ordinary_results=ordinary, lifecycle_results=lifecycles, generated_rows=198,
              ordinary_artifacts=artifacts, portable_replays=portable['patches'], evidence_files=evidence, goal_complete=False,
              qualification='One 512K-word bytecode allocation contains actual four-word GNU frame footers and reserved operand ranges. Actual function values in the footer chain replace the parallel function-root vector. All 1036 predecessor selectors, 24 audit controls and original fixture bytes remain. Both profiles and 58 ordinary comparisons are independently audited. The original source310 capacity failure and the separate moved-image setup failure remain preserved. Host unwind/backtrace/handler metadata and transient ByteCodeObject views remain; function-resolution-before-GC order is unchanged. Selected correctness only: no complete platform, universal internal soundness, physical accounting or performance acceptance claim.')
(p / 'source311-selected-audit.json').open('x').write(json.dumps(result, indent=2))
print(json.dumps(dict(status='passed', source_inputs=548, passes_per_profile=1065, ordinary_comparisons=58)))
'''
out=head+body+tail
ast.parse(out)
(p/'audit-source311-selected.py').open('x').write(out)
print('prepared source311 raw auditor')
