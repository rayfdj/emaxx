from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).parent.resolve();root=p.parents[2];g=p.parent/'rebuilt-2026-10-01/emacs'
c=p.parent/'recovered-2026-10-06/bytecode-stack/emaxx'
fixture=c/'tests/fixtures/bytecode-stack-layout.el';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
results=[]
for tag,binary in [('gnu',g/'src/emacs'),('source310',p/'source310-ordinary-emaxx')]:
 inputs={str(f):sha(f) for f in [fixture,binary,binary.with_suffix('.pdmp')]}
 command=[str(binary),'-Q','--batch','--eval','(prin1 '+fixture.read_text()+')']
 record=dict(command=command,cwd=str(root),environment_overrides=dict(LANG='C',LC_ALL='C'),inputs=inputs,timeout_seconds=120)
 (p/('source311-stack-baseline-'+tag+'-command.json')).open('x').write(json.dumps(record,indent=2))
 start=time.monotonic();r=subprocess.run(command,cwd=root,env=dict(os.environ,LANG='C',LC_ALL='C'),capture_output=True,timeout=120)
 for suffix,data in [('stdout',r.stdout),('stderr',r.stderr)]: (p/('source311-stack-baseline-'+tag+'.'+suffix)).open('xb').write(data)
 result=dict(editor=tag,exit_code=r.returncode,elapsed_seconds=time.monotonic()-start,inputs_unchanged=all(sha(Path(n))==h for n,h in inputs.items()),stdout_sha256=hashlib.sha256(r.stdout).hexdigest(),stderr_sha256=hashlib.sha256(r.stderr).hexdigest())
 (p/('source311-stack-baseline-'+tag+'-result.json')).open('x').write(json.dumps(result,indent=2))
 results.append(result);assert r.returncode==0 and not r.stderr and result['inputs_unchanged'],result
print(json.dumps(results,indent=2))
assert (p/'source311-stack-baseline-gnu.stdout').read_bytes()!=(p/'source311-stack-baseline-source310.stdout').read_bytes()
(p/'source311-stack-baseline-audit.json').open('x').write(json.dumps(dict(status='actual GNU/source310 capacity mismatch reproduced',results=results,fixture_sha256=sha(fixture),goal_complete=False),indent=2))
