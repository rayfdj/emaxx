(progn
  (require 'xt-mouse)
  (require 'cl-lib)
  (let ((inhibit-message t)
        (calls 0)
        (outputs 0)
        (before (list xterm-mouse-mode
                      (length (terminal-list))
                      (terminal-live-p nil)
                      (terminal-parameter nil 'xterm-mouse-mode)
                      (lookup-key input-decode-map "\e[M")))
        (map input-decode-map))
    (cl-letf (((symbol-function 'terminal-name)
               (lambda (&optional _) (setq calls (1+ calls)) "fake-terminal"))
              ((symbol-function 'send-string-to-terminal)
               (lambda (&rest _) (setq outputs (1+ outputs)) nil)))
      (unwind-protect
          (progn
            (xterm-mouse-mode 1)
            (list before
                  (list xterm-mouse-mode calls outputs
                        (eq map input-decode-map)
                        (lookup-key input-decode-map "\e[M")
                        (lookup-key input-decode-map "\e[<")
                        (terminal-parameter nil 'xterm-mouse-mode))
                  (mapcar (lambda (terminal)
                            (list (terminal-live-p terminal)
                                  (length (frames-on-display-list terminal))))
                          (terminal-list))))
        (xterm-mouse-mode 0)))))
