from pathlib import Path
import hashlib
import json
import re

p = Path(__file__).parent.resolve()
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())


def audit_log(names, log, expected_passed, expected_failed):
    assert len(names) == len(set(names))
    summaries = re.findall(
        r"^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;",
        log, re.M)
    assert summaries == [("FAILED" if expected_failed else "ok",
                          str(expected_passed), str(expected_failed), "0")]
    starts = list(re.finditer(r"^test (\S+) \.\.\. ", log, re.M))
    assert sorted(item[1] for item in starts) == sorted(names)
    counts = {"ok": 0, "FAILED": 0}
    failures = []
    for index, item in enumerate(starts):
        end = starts[index + 1].start() if index + 1 < len(starts) else log.index("\n\nfailures:") if expected_failed else log.rindex("test result:")
        verdict = re.search(r"(?:^|\s)(ok|FAILED)$", log[item.end():end].strip())
        assert verdict, item[1]
        counts[verdict[1]] += 1
        if verdict[1] == "FAILED":
            failures.append(item[1])
    assert counts == {"ok": expected_passed, "FAILED": expected_failed}
    return failures


checkout = p.parent / 'recovered-2026-09-30/cons-roots/emaxx'
manifest = read('source204-manifest.json')
assert len(manifest) == 410
assert all(sha((checkout / name).read_bytes()) == digest for name, digest in manifest.items())
validation = read('source204-selected-validation-result.json')
assert validation['passed'] and validation['all_completed'] and validation['source_unchanged']
for check in ['check', 'fmt', 'clippy', 'diff', 'gate-build', 'gate-focused', 'release-build', 'release-focused', 'ordinary-build', 'ordinary-image']:
    result = read('source204-' + check + '-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
for entry in read('source204-ordinary-artifacts.json').values():
    file = Path(entry['immutable_copy'])
    assert sha(file.read_bytes()) == entry['sha256'] and file.stat().st_size == entry['bytes']

results = []
for tag, profile, passed, failed in [
    ("source204", "gate", len(read("source204-gate-selected-command.json")["selected_inventory"]), 0),
    ("source204", "release", len(read("source204-release-selected-command.json")["selected_inventory"]), 0),
]:
    stem = tag + "-" + profile + "-selected"
    command = read(stem + "-command.json")
    names = command["selected_inventory"]
    inventory = [line[:-6] for line in (p / (tag + "-" + profile + "-inventory.txt")).read_text().splitlines() if line.endswith(": test")]
    arguments = command["command"][1:]
    filters = [argument for argument in arguments if not argument.startswith("--")]
    assert names == [name for name in inventory if any(part in name for part in filters)]
    focus = read(tag + "-" + profile + "-focused-command.json")
    assert len(focus["selected_inventory"]) == 7
    assert not audit_log(focus["selected_inventory"], (p / (tag + "-" + profile + "-focused.log")).read_text(), 7, 0)
    assert focus["binary_sha256"] == command["binary_sha256"]
    result = read(stem + "-result.json")
    assert result["exit_code"] == (101 if failed else 0)
    assert result["source_unchanged"]
    log = (p / (stem + ".log")).read_text()
    failures = audit_log(names, log, passed, failed)
    assert sha((p / (tag + "-" + profile + "-libtest")).read_bytes()) == command["binary_sha256"]
    for required in ["threads_retain_lexical_caller_roots_across_separate_callee_environments",
                     "suspended_bytecode_retains_operand_and_unwind_roots"]:
        assert any(name.endswith("::" + required) for name in names)
    results.append({"source": tag, "profile": profile, "raw_passed": passed,
                    "raw_failed": failed, "raw_ignored": 0,
                    "inventory_and_binary_verified": True, "failures": failures})

fixtures = read("source204-selected-validation-result.json")["steps"][-1]["script"][3:]
assert len(fixtures) == len(set(fixtures)) == 40
for name in fixtures:
    comparison = read("source204-ordinary-" + name + "-comparison.json")
    assert comparison["passed"] and comparison["exact_match"]
    outputs = []
    for editor in ["gnu", "emaxx"]:
        stem = "source204-ordinary-" + name + "-" + editor
        outcome = read(stem + ".result.json")
        command = read(stem + ".command.json")
        assert outcome == comparison["outcomes"][editor]
        assert outcome["exit_code"] == 0 and not outcome["timed_out"]
        assert outcome["source_unchanged"] and outcome["inputs_unchanged"]
        assert outcome["expected_output"] is not False
        stdout = (p / (stem + ".stdout")).read_bytes()
        stderr = (p / (stem + ".stderr")).read_bytes()
        assert sha(stdout) == outcome["stdout_sha256"]
        assert stderr == b"" and outcome["stderr_hex"] == ""
        assert all(sha(Path(f).read_bytes()) == h for f, h in command["inputs"].items())
        outputs.append(stdout)
    assert outputs[0] == outputs[1]

# Challenge the raw-inventory auditor itself without changing any receipt.
names = ["alpha", "beta"]
good = "test alpha ... ok\ntest beta ... ok\ntest result: ok. 2 passed; 0 failed; 0 ignored;\n"
audit_log(names, good, 2, 0)
negative_controls = {
    "missing_test": good.replace("test beta ... ok\n", ""),
    "duplicate_test": good.replace("test beta ...", "test alpha ..."),
    "failed_verdict_with_green_summary": good.replace("beta ... ok", "beta ... FAILED"),
    "false_count": good.replace("2 passed", "3 passed"),
    "absent_summary": good[:good.index("test result:")],
}
rejected = []
for label, mutated in negative_controls.items():
    try:
        audit_log(names, mutated, 2, 0)
    except AssertionError:
        rejected.append(label)
    else:
        raise AssertionError("Accepted corrupt evidence: " + label)
with (p / "source204-selected-evidence-audit.json").open("x") as f:
    json.dump({"rust": results, "ordinary_source204": fixtures,
               "negative_controls_rejected": rejected,
               "qualification": "Audits selected raw evidence only. Earlier failures remain failures; full new-source compatibility and performance remain unproven."}, f, indent=2)
print("Verified two selected Rust inventories and 40 ordinary comparisons; rejected five corrupt-log controls.")
