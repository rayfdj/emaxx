from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve(); root=p.parents[2]; out=root/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda name:json.loads((p/name).read_text())
tree=ast.parse((p/'package-source196-failure-and197-results.py').read_text())
node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
allowed={'.json','.log','.txt','.py','.patch','.stdout','.stderr','.el','.expected','.raw','.report'}
selected=read('source204-correct-mode-selected-evidence-audit.json')
assert selected['status']=='passed with documented correct-mode replay'
assert [r['raw_passed'] for r in selected['rust']]==[596,596]
files={}
for f in p.iterdir():
 if not f.is_file() or f.suffix not in allowed:continue
 if f.name.startswith('source204-') and not f.name.startswith(('source204-full-','source204-continuation-','source204-checkpoint-')):files[f.name]=f
for name in ['audit-source204-correct-mode-selected.py','audit-source204-correct-mode-selected-v1.py','audit-source204-correct-mode-selected-v2.py','audit-source204-selected.py','check-cons204.py','static-cons204.py','test-cons204.py','build-cons204.py','queue-source204-validation.py','compare-recovered-continuation-fixtures.py','probe-record-purecopy-tty-v2.py','purecopy-five-kinds-gc-tty.el',Path(__file__).name]:files[name]=p/name
checkout=p.parent/'recovered-2026-09-30/cons-roots/emaxx'
for name in selected['covered_fixtures']:
 fixture=checkout/('tests/fixtures/'+name+'.el')
 if not fixture.exists():fixture=p/(name+'.el')
 files['fixtures/'+fixture.name]=fixture
 expected=fixture.with_suffix('.expected')
 if expected.exists():files['fixtures/'+expected.name]=expected
for f in p.glob('source201-cons-access-*-disassembly.txt'):files[f.name]=f
package('source204-cons-selected-validation',files,{'strict_zero_warning_checks':True,'gate_passed':596,'release_passed':596,'focused_per_profile':7,'batch_fixture_passes':39,'interactive_fixture_passes':1,'original_batch_attempt_passed':False,'source_inputs':410,'qualification':'Raw selected inventories and exact artifacts audited. The original purecopy batch attempt and two incomplete auditor invocations remain failed. The unchanged fixture and expected output pass with collecting callbacks in ordinary GNU and Emaxx terminal sessions. Full candidate validation, final accounting and GNU performance remain open. Static disassembly is not timing or dynamic instruction evidence.'})

base=p/'linux-source201-frozen-artifacts'; frozen=read('source201-linux-frozen-complete-audit.json'); assert frozen['verified_outcomes']==7928
files={str(f.relative_to(p)):f for f in base.rglob('*') if f.is_file() and f.suffix in allowed}
for f in p.glob('source201-linux-frozen-*'):
 if f.is_file() and f.suffix in allowed:files[f.name]=f
files['verify-complete-frozen-receipts.py']=p/'verify-complete-frozen-receipts.py'
files[Path(__file__).name]=Path(__file__)
package('source201-linux-frozen',files,frozen)

files={}
for name in ['run-source204-full-gate.py','run-source204-full-tty.py','source204-full-gate-launch.json','source204-full-tty-launch.json','source204-full-gate-command.json','source204-full-ttydiff-command.json','source204-applied-source-audit.json','source204-manifest.json','source204-correct-mode-selected-evidence-audit.json',Path(__file__).name]:files[name]=p/name
package('source204-complete-validation-start',files,{'source_inputs':410,'macos_full_rust_pid':read('source204-full-gate-launch.json')['pid'],'macos_full_terminal_pid':read('source204-full-tty-launch.json')['pid'],'qualification':'Launch records only, not results. Source checkout, helpers and artifacts must remain frozen until associated children finish. Exact published-head Linux validation still required.'})
