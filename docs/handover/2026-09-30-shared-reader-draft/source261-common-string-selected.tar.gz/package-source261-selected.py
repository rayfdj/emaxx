from pathlib import Path
import ast
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(node for node in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(node, ast.FunctionDef) and node.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
selected = read('source261-selected-audit.json')
assert selected['status'] == 'passed' and selected['source_inputs_verified'] == 488
assert selected['ordinary_comparisons'] == 22
assert all(row['focused_passes'] == 189 and row['affected_passes'] == 962 for row in selected['profiles'].values())
failed = read('source259-broad-failure-audit.json')
assert failed['counts'] == {'ok': 961, 'FAILED': 1, 'ignored': 0}
assert read('source260-clippy-result.json')['exit_code'] != 0
assert [row['exit_code'] for row in read('source261-validation-result.json')['results']] == [0, 0, 0, 0, 1]
assert all(row['exit_code'] == 0 for row in read('source261-retention-continuation-result.json')['results'])
for record in [read('source261-focused-audit.json'), read('source261-release-focused-audit-after-retention.json'), failed]:
    for item in record['retained_inputs']:
        assert sha(Path(item['artifact']).read_bytes()) == item['sha256']
helpers = {
    Path(__file__).name, 'package-source196-failure-and197-results.py',
    'audit-source259-broad-failure.py', 'audit-source256-broad-failure.py',
    'audit-native-code-fixture261.py', 'audit-source260-source261-patches.py',
    'check-string-comparison-hashes-draft.py', 'freeze-string-comparison-hashes.py',
    'run-native-code-fixture-focused.py', 'run-native-code-fixture-release.py',
    'audit-native-code-fixture-focused.py', 'audit-native-code-fixture-release.py',
    'audit-native-code-fixture-release-retained-cache.py', 'test-string-comparison-hashes-broad.py',
    'build-string-comparison-ordinary.py', 'compare-string-comparison-fixtures.py',
    'queue-native-code-fixture260-validation.py', 'queue-native-code-fixture261-validation.py',
    'continue-source261-after-retention-audit.py', 'audit-source261-selected.py',
    'queue-source261-full-macos.py', 'dispatch-source261-linux.py', 'audit-source238-release.py',
    'native-bytecode-unibyte-constructor.el', 'probe-native-bytecode-unibyte-constructor.py',
    'source249-setup-continuation-result.json', 'source249-gate-inventory.txt',
    'source249-release-inventory.txt', 'source249-gate-broad-command.json',
    'source249-release-broad-command.json', 'source249-gate-controls-command.json',
    'source255-gate-controls-command.json', 'source255-gate-inventory.log',
    'source256-gate-broad-command.json', 'source256-manifest.json',
    'source259-manifest.json', 'source259-freeze.json',
    'source259-validation-result.json', 'source259-validation-queue-state.json',
    'source259-validation-driver.log', 'source259-focused-audit.json',
    'source259-focused-retained-inputs.json', 'source259-broad-failure-audit.json',
    'source261-full-checkout.json', 'source261-full-launch.json',
    'source261-applied-commit.json', 'source261-applied-push.json',
    'source261-linux-rust-dispatch.json', 'source261-linux-rust-launch.json',
    'source261-linux-frozen-dispatch.json', 'source261-linux-frozen-launch.json',
    'source261-full-selected-audit-command.json', 'source261-full-selected-audit-result.json',
    'source261-full-cache-clone-command.json', 'source261-full-cache-clone-result.json',
    'source261-full-fresh-gate-crate-command.json', 'source261-full-fresh-gate-crate-result.json',
    'source261-full-oracle-capture-command.json', 'source261-full-oracle-capture-result.json',
}
allowed = {'.json', '.log', '.txt', '.py', '.el', '.expected', '.patch', '.stdout', '.stderr'}
files = {}
for path in p.iterdir():
    if not path.is_file() or path.suffix not in allowed:
        continue
    name = path.name
    include = name in helpers or name.startswith(('source260-', 'source259-gate-broad', 'source256-native-bytecode-constructor-gnu'))
    include |= name.startswith('source261-') and not name.startswith('source261-full-')
    if include:
        files[name] = path
assert helpers <= files.keys(), sorted(helpers - files.keys())
candidate = p.parent / 'recovered-2026-09-30/string-comparisons/emaxx'
for fixture in ['host-string-mutation', 'host-string-vector-mutation', 'string-equality-storage',
                'string-equality-symbol-names-positioned', 'string-equality-property-values', 'string-equality-property-hashes']:
    for extension in ['.el', '.expected']:
        name = 'tests/fixtures/' + fixture + extension
        files[name] = candidate / name
package('source261-common-string-selected', files, dict(
    selected=selected, source259_broad_failure=failed,
    full_validation_launch=read('source261-full-launch.json'),
    publication=read('source261-applied-commit.json'),
    linux_launches=[read('source261-linux-' + mode + '-launch.json') for mode in ['rust', 'frozen']],
    qualification='Source261 has zero-warning strict checks, 189 focused passes/two unchanged ignores and 962 affected passes in each profile, plus 22 ordinary exact GNU matches. All original native assertions remain. Source259 broad failure, source260 new-test lint failure and source261 retention-auditor failure are preserved. The corrected release auditor verifies its own executable/image and the extra earlier gate image. Both portable patches reproduce all 488 inputs. Commit eddfe782 is pushed to the task branch and exact-head Linux Rust/frozen runs are dispatched. Full macOS validation runs separately at that same clean commit; active logs and full-run verdicts are excluded. No Linux result, complete platform pass, physical accounting, ownership, memory saving, performance or full-goal claim.'))
