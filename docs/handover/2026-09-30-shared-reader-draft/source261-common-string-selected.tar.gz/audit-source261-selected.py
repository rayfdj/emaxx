from pathlib import Path
import ast
import hashlib
import json
import re

p = Path(__file__).parent.resolve()
candidate = p.parent / 'recovered-2026-09-30/string-comparisons/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
state = read('source261-validation-result.json')
assert state['status'] == 'selected validation finished; raw results require audit'
assert len(state['stages']) == 8 and len(state['results']) == 5
assert [row['exit_code'] for row in state['results']] == [0, 0, 0, 0, 1]
continuation = read('source261-retention-continuation-result.json')
assert continuation['status'] == 'selected continuation finished'
assert len(continuation['stages']) == len(continuation['results']) == 5
assert all(row['exit_code'] == 0 for row in continuation['results'])
for snapshot in [state, continuation]:
    assert all(row['source_unchanged'] and row['prior_source_unchanged'] and row['helper_unchanged']
               for row in snapshot['results'])
    assert all(sha(Path(name)) == digest for name, digest in snapshot['helper_sha256'].items())
manifest = read('source261-manifest.json')
assert len(manifest) == 488 and all(sha(candidate / name) == digest for name, digest in manifest.items())
node = next(node for node in ast.parse((p / 'audit-source238-release.py').read_text()).body
            if isinstance(node, ast.FunctionDef) and node.name == 'audit_log')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<unchanged-raw-verdict-auditor>', 'exec'))
new_names = {
    'lisp::primitives::tests::host_created_strings_preserve_mutation_properties_and_fill_errors',
    'lisp::primitives::tests::vector_held_host_strings_preserve_binding_identity_and_mutation',
    'lisp::primitives::tests::string_equality_compares_actual_storage_with_and_without_properties',
    'lisp::primitives::tests::string_equality_uses_lisp_symbol_names_and_positioned_symbol_policy',
    'lisp::primitives::tests::string_property_values_use_equal_across_mutation_gc_and_interval_boundaries',
    'lisp::primitives::tests::string_property_hashes_follow_equal_through_nested_mutation_and_lookup',
    'lisp::types::tests::string_value_equality_uses_bytes_and_character_counts',
}
ignored = ['tty::tty_differential_end_to_end', 'tty::tty_smoke_end_to_end']
inventories, profiles = {}, {}
for profile, count in [('gate', 3010), ('release', 3009)]:
    names = [line[:-6] for line in (p / ('source261-' + profile + '-inventory.log')).read_text().splitlines()
             if line.endswith(': test')]
    previous = [line[:-6] for line in (p / ('source249-' + profile + '-inventory.txt')).read_text().splitlines()
                if line.endswith(': test')]
    assert len(names) == len(set(names)) == count
    assert set(previous) <= set(names) and set(names) - set(previous) == new_names
    inventories[profile] = names
    focused_audit = read('source261-focused-audit.json' if profile == 'gate' else 'source261-release-focused-audit-after-retention.json')
    assert focused_audit['status'] == 'passed'
    assert focused_audit['counts'] == {'ok': 189, 'FAILED': 0, 'ignored': 2}
    for item in focused_audit['retained_inputs']:
        assert sha(Path(item['original'])) == sha(Path(item['artifact'])) == item['sha256']
    focused = read('source261-' + profile + '-controls-command.json')
    assert len(focused['selectors']) == 191
    audit_log(focused['selectors'], (p / ('source261-' + profile + '-controls.log')).read_text(), ignored)
    command = read('source261-' + profile + '-broad-command.json')
    result = read('source261-' + profile + '-broad-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
    selected = command['selected_inventory']
    assert len(selected) == len(set(selected)) == 962
    assert command['command'][1:] == selected + ['--exact', '--nocapture', '--test-threads=1']
    previous = read('source249-' + profile + '-broad-command.json')['selected_inventory']
    assert len(previous) == 955 and set(previous) <= set(selected)
    assert set(selected) - set(previous) == new_names
    common = read('source256-gate-broad-command.json')['selected_inventory']
    assert len(common) == 957 and set(common) <= set(selected)
    assert sha(p / ('source261-' + profile + '-libtest')) == command['binary_sha256'] == focused['binary_sha256']
    audit_log(selected, (p / ('source261-' + profile + '-broad.log')).read_text(), [])
    profiles[profile] = dict(focused_passes=189, existing_ignores=ignored, affected_passes=962,
                             complete_library_inventory=len(names), binary_sha256=command['binary_sha256'])
assert set(inventories['gate']) - set(inventories['release']) == {
    'file_system::posix::tests::posix_file_drop_rejects_an_externally_closed_descriptor'}
assert not set(inventories['release']) - set(inventories['gate'])
for stage in ['check', 'fmt', 'clippy', 'diff', 'gate-build', 'release-build', 'ordinary-build', 'ordinary-image']:
    result = read('source261-' + stage + '-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
    raw = (p / ('source261-' + stage + '.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
    for line in raw.splitlines():
        if line.startswith('{'):
            assert json.loads(line).get('message', {}).get('level') not in ['error', 'warning']
fixtures = state['stages'][-1][3:]
assert len(fixtures) == len(set(fixtures)) == 21
assert set(read('source249-setup-continuation-result.json')['stages'][1][3:]) <= set(fixtures)
ordinary = {}
for fixture in fixtures + ['native-bytecode-unibyte-constructor']:
    result = read('source261-ordinary-' + fixture + '-comparison.json')
    assert result['passed'] and result['exact_match']
    if fixture == 'native-bytecode-unibyte-constructor':
        expected = (p / 'source256-native-bytecode-constructor-gnu.stdout').read_bytes()
    else:
        expected = (candidate / ('tests/fixtures/' + fixture + '.expected')).read_bytes().rstrip(b'\n')
    for editor in ['gnu', 'emaxx']:
        prefix = 'source261-ordinary-' + fixture + '-' + editor
        command, row = read(prefix + '.command.json'), read(prefix + '.result.json')
        assert row['exit_code'] == 0 and not row['timed_out']
        assert row['source_unchanged'] and row['inputs_unchanged'] and row['expected_output'] is not False
        assert all(sha(Path(name)) == digest for name, digest in command['inputs'].items())
        assert sha(p / (prefix + '.stdout')) == row['stdout_sha256']
        assert (p / (prefix + '.stdout')).read_bytes() == expected
        assert (p / (prefix + '.stderr')).read_bytes() == b'' and row['stderr_hex'] == ''
    ordinary[fixture] = hashlib.sha256(expected).hexdigest()
artifacts = read('source261-ordinary-artifacts.json')
assert len(artifacts) == 2
for name, info in artifacts.items():
    assert sha(Path(name)) == sha(Path(info['immutable_copy'])) == info['sha256']
record = dict(status='passed', source_inputs_verified=488, profiles=profiles,
              ordinary_comparisons=len(ordinary), ordinary_expected_sha256=ordinary,
              ordinary_artifacts=artifacts, added_test_names=sorted(new_names),
              original_failures_preserved=True, goal_complete=False,
              qualification='Selected gate/release and 22 ordinary same-input GNU comparisons only. All source249 controls and existing ignores remain. Full macOS/Linux Rust, frozen and terminal runs are separate. No performance, memory, ownership or architecture completion is inferred.')
with (p / 'source261-selected-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps({key: record[key] for key in ['status', 'source_inputs_verified', 'profiles', 'ordinary_comparisons']}, indent=2))
