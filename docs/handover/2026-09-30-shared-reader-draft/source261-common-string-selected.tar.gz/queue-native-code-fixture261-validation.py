from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

p = Path(__file__).parent.resolve()
candidate = p.parent / 'recovered-2026-09-30/string-comparisons/emaxx'
prior_candidate = p.parent / 'recovered-2026-09-30/common-strings/emaxx'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
manifest = json.loads((p / 'source261-manifest.json').read_text())
prior_manifest = json.loads((p / 'source256-manifest.json').read_text())
unchanged = lambda: all(sha(candidate / name) == digest for name, digest in manifest.items())
prior_unchanged = lambda: all(sha(prior_candidate / name) == digest for name, digest in prior_manifest.items())
fixtures = [
    'coding-post-read-character-count', 'coding-post-read-fast-path',
    'overriding-property-identity', 'coding-candidate-symbol-properties',
    'coding-candidate-translation', 'coding-candidate-character-identities',
    'coding-candidate-inventory', 'file-write-coding-selection',
    'new-file-coding-lifecycle', 'file-write-order',
    'canonical-coding-character-storage', 'canonical-coding-identity-storage',
    'canonical-coding-conversion-storage', 'copied-canonical-string-storage',
    'coding-error-object-storage', 'host-string-mutation', 'host-string-vector-mutation',
    'string-equality-storage', 'string-equality-symbol-names-positioned',
    'string-equality-property-values', 'string-equality-property-hashes',
]
stages = [
    ['run-native-code-fixture-focused.py', '261'],
    ['audit-native-code-fixture-focused.py', '261'],
    ['test-string-comparison-hashes-broad.py', '261', 'gate'],
    ['run-native-code-fixture-release.py', '261'],
    ['audit-native-code-fixture-release.py', '261'],
    ['test-string-comparison-hashes-broad.py', '261', 'release'],
    ['build-string-comparison-ordinary.py', '261'],
    ['compare-string-comparison-fixtures.py', 'source261', str(candidate), *fixtures],
]
helpers = {str(p / stage[0]): sha(p / stage[0]) for stage in stages}
state = dict(status='waiting for source259 validation supervisor to exit', prior_pid=22381,
             source_manifest='source261-manifest.json', helper_sha256=helpers,
             stages=stages, goal_complete=False)
results = []


def save_state():
    (p / 'source261-validation-queue-state.json').write_text(json.dumps(state, indent=2) + '\n')


save_state()
try:
    assert len(manifest) == 488 and unchanged()
    assert len(prior_manifest) == 480 and prior_unchanged()
    for stage in ['check', 'fmt', 'clippy', 'diff']:
        result = json.loads((p / ('source261-' + stage + '-result.json')).read_text())
        assert result['exit_code'] == 0 and result['source_unchanged']
    while True:
        process = subprocess.run(['ps', '-p', '22381', '-o', 'command='], capture_output=True, text=True)
        if process.returncode == 1 and not process.stdout.strip():
            break
        assert process.returncode == 0 and 'queue-string-comparison259-validation.py' in process.stdout, process.stdout + process.stderr
        time.sleep(5)
    prior = json.loads((p / 'source259-validation-result.json').read_text())
    assert prior_unchanged()
    state['prior_validation_status'] = prior['status']
    state['prior_validation_record_sha256'] = sha(p / 'source259-validation-result.json')
    # Preserve the preceding draft's verdict. This source's validation does
    # not retroactively turn any prior source or setup failure into a pass.
    for name, *args in stages:
        helper = p / name
        assert unchanged() and prior_unchanged() and sha(helper) == helpers[str(helper)]
        command = [sys.executable, '-B', str(helper), *args]
        state.update(status='running selected string comparison validation', current_command=command)
        save_state()
        started = time.monotonic()
        result = subprocess.run(command, cwd=candidate, stdin=subprocess.DEVNULL,
                                env=dict(os.environ, PYTHONUNBUFFERED='1', PYTHONDONTWRITEBYTECODE='1'))
        results.append(dict(command=command, exit_code=result.returncode,
                            elapsed_seconds=time.monotonic() - started,
                            source_unchanged=unchanged(), prior_source_unchanged=prior_unchanged(),
                            helper_unchanged=sha(helper) == helpers[str(helper)]))
        if result.returncode or not all(results[-1][key] for key in ['source_unchanged', 'prior_source_unchanged', 'helper_unchanged']):
            break
    state.update(status='selected validation finished; raw results require audit', results=results)
except Exception as error:
    state.update(status='queue or validation failed', error=repr(error), results=results)
finally:
    save_state()
    with (p / 'source261-validation-result.json').open('x') as out:
        json.dump(state, out, indent=2)
print(json.dumps(state), flush=True)
sys.exit(0 if len(results) == len(stages) and all(
    row['exit_code'] == 0 and row['source_unchanged'] and row['prior_source_unchanged'] and row['helper_unchanged']
    for row in results) else 1)
