from pathlib import Path
import hashlib, json, re, subprocess, tempfile

p = Path(__file__).parent.resolve()
candidate = p.parent / 'recovered-2026-09-30/string-comparisons/emaxx'
previous_candidate = p.parent / 'recovered-2026-09-30/common-strings/emaxx'
gnu = p.parent / 'rebuilt-2026-10-01/emacs'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read('source261-manifest.json')
previous = read('source259-manifest.json')
path = 'src/lisp/native_comp/runtime.rs'
assert len(manifest) == 488 and all(sha(candidate / name) == digest for name, digest in manifest.items())
assert manifest.keys() == previous.keys()
assert {name for name in manifest if manifest[name] != previous[name]} == {path}
assert sha(previous_candidate / path) == previous[path]
with tempfile.TemporaryDirectory(prefix='emaxx-native-fixture-review-', dir='/private/tmp') as directory:
    directory = Path(directory)
    original = directory / path
    original.parent.mkdir(parents=True)
    original.write_bytes((previous_candidate / path).read_bytes())
    subprocess.run(['git', 'apply', '--check', str(p / 'source260-native-bytecode-fixture-prepared.patch')], cwd=directory, check=True)
    subprocess.run(['git', 'apply', str(p / 'source260-native-bytecode-fixture-prepared.patch')], cwd=directory, check=True)
    source260 = original.read_text()
    assert sha(original) == read('source260-manifest.json')[path]
    before = '.unwrap_err(),\n            crate::lisp::bytecode::ByteCodeError::NonUnibyteCode { char_index: 0 }'
    after = '.expect_err("GNU rejects Unicode text as byte-code storage"),\n            crate::lisp::bytecode::ByteCodeError::NonUnibyteCode { char_index: 0 }'
    assert source260.count(before) == 1
    assert source260.replace(before, after) == (candidate / path).read_text()
old = (previous_candidate / path).read_text()
new = (candidate / path).read_text()
start = old.index('    #[test]\n    fn native_funcall_dispatches_bytecode_like_eval_c()')
end = old.index('    #[test]\n    fn native_funcall_falls_back_for_alias_lambda_and_invalid_function()', start)
new_end = new.index('    #[test]\n    fn native_funcall_falls_back_for_alias_lambda_and_invalid_function()', start)
assert old[:start] == new[:start] and old[end:] == new[new_end:]
old_assertions = old[start:end].split('        assert!(matches!(', 1)[1]
assert old_assertions.rsplit('    }', 1)[0].strip() in new[start:new_end]
command = read('source256-native-bytecode-constructor-gnu-command.json')
result = read('source256-native-bytecode-constructor-gnu-result.json')
assert result['exit_code'] == 0 and result['inputs_unchanged']
assert all(sha(Path(name)) == digest for name, digest in command['inputs'].items())
assert sha(p / 'source256-native-bytecode-constructor-gnu.stdout') == result['stdout_sha256']
assert (p / 'source256-native-bytecode-constructor-gnu.stdout').read_text() == '((nil 3 3 (t t (137 84 135) 42)) (t 3 5 (error "Invalid byte-code object")))'
assert not (p / 'source256-native-bytecode-constructor-gnu.stderr').read_bytes()
for stage in ['check', 'fmt', 'clippy', 'diff']:
    receipt = read('source261-' + stage + '-result.json')
    assert receipt['exit_code'] == 0 and receipt['source_unchanged']
    assert not re.search(r'^warning(?:\[.*\])?:', (p / ('source261-' + stage + '.log')).read_text(), re.M)
assert read('source260-clippy-result.json')['exit_code'] == 101
assert 'used `unwrap_err()` on a `Result` value' in (p / 'source260-clippy.log').read_text()
assert read('source259-broad-failure-audit.json')['counts'] == {'ok': 961, 'FAILED': 1, 'ignored': 0}
references = {}
for name, needle in [('src/alloc.c', 'DEFUN ("make-byte-code"'), ('src/bytecode.c', 'eassert (!STRING_MULTIBYTE (bytestr))')]:
    text = (gnu / name).read_text()
    references[name] = dict(sha256=sha(gnu / name), anchor=needle, line=text[:text.index(needle)].count('\n') + 1)
record = dict(source='source261', source_inputs_verified=488, changed_since_source259=[path],
              scope='Only the existing native_funcall_dispatches_bytecode_like_eval_c Rust test changes; production runtime is byte-identical to source259.',
              gnu_references=references, gnu_probe=result,
              correction='Construct three actual unibyte opcode octets137/84/135. Retain native target classification, return42, empty backtrace and evaluation-depth assertions. Add rejection of the previous Unicode form with the existing NonUnibyteCode variant.',
              original_assertions_preserved=True, strict_checks='zero-warning pass',
              prior_failures={'source256_broad': [956, 1], 'source259_broad': [961, 1], 'source260': 'new test unwrap lint; fixed with explanatory expect_err, without suppression'},
              qualification='GNU validates the fixture storage and bytecode result through its ordinary constructor/funcall entry. The corrected native Rust test and both profile groups remain pending; no runtime or native-artifact pass is inferred from this static review. Full goal and performance remain open.',
              goal_complete=False)
with (p / 'source261-native-bytecode-fixture-audit.json').open('x') as f:
    json.dump(record, f, indent=2)
print(json.dumps(dict(source='source261', inputs=488, only_test_changed=True, original_assertions_preserved=True, strict='zero-warning pass')))
