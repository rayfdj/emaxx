from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

p = Path(__file__).parent.resolve()
candidate = p.parent / 'recovered-2026-09-30/string-comparisons/emaxx'
prior_candidate = p.parent / 'recovered-2026-09-30/common-strings/emaxx'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
source, prior_source = read('source261-manifest.json'), read('source256-manifest.json')
unchanged = lambda: all(sha(candidate / name) == digest for name, digest in source.items())
prior_unchanged = lambda: all(sha(prior_candidate / name) == digest for name, digest in prior_source.items())
prior = read('source261-validation-result.json')
assert len(source) == 488 and len(prior_source) == 480 and unchanged() and prior_unchanged()
assert [row['exit_code'] for row in prior['results']] == [0, 0, 0, 0, 1]
assert prior['results'][-1]['command'][-2:] == [str(p / 'audit-native-code-fixture-release.py'), '261']
assert all(row['source_unchanged'] and row['prior_source_unchanged'] and row['helper_unchanged'] for row in prior['results'])
process = subprocess.run(['ps', '-p', '26934', '-o', 'command='], capture_output=True, text=True)
assert process.returncode == 1 and not process.stdout.strip(), process.stdout + process.stderr
stages = [['audit-native-code-fixture-release-retained-cache.py', '261'], *prior['stages'][5:],
          ['compare-string-comparison-fixtures.py', 'source261', str(candidate), 'native-bytecode-unibyte-constructor']]
assert len(stages) == 5
helpers = {str(p / stage[0]): sha(p / stage[0]) for stage in stages}
state = dict(status='prepared continuation after retention auditor failure', prior_pid=26934,
             source_manifest='source261-manifest.json', helper_sha256=helpers, stages=stages,
             prior_result_sha256=sha(p / 'source261-validation-result.json'), goal_complete=False,
             qualification='Original release tests succeeded. Original auditor incorrectly required exactly two retained inputs, although the retention helper explicitly captures every post-run image and this cache also contains the preceding gate image. The replacement auditor verifies both image identities. No source, selector, expectation, test execution or old receipt changes.')
results = []


def save_state():
    (p / 'source261-retention-continuation-state.json').write_text(json.dumps(state, indent=2) + '\n')


try:
    for name, *args in stages:
        helper = p / name
        assert unchanged() and prior_unchanged() and sha(helper) == helpers[str(helper)]
        command = [sys.executable, '-B', str(helper), *args]
        state.update(status='running selected continuation', current_command=command)
        save_state()
        started = time.monotonic()
        result = subprocess.run(command, cwd=candidate, stdin=subprocess.DEVNULL,
                                env=dict(os.environ, PYTHONUNBUFFERED='1', PYTHONDONTWRITEBYTECODE='1'))
        results.append(dict(command=command, exit_code=result.returncode,
                            elapsed_seconds=time.monotonic() - started,
                            source_unchanged=unchanged(), prior_source_unchanged=prior_unchanged(),
                            helper_unchanged=sha(helper) == helpers[str(helper)]))
        if result.returncode or not all(results[-1][key] for key in ['source_unchanged', 'prior_source_unchanged', 'helper_unchanged']):
            break
    state.update(status='selected continuation finished', results=results)
except Exception as error:
    state.update(status='continuation failed', error=repr(error), results=results)
finally:
    save_state()
    with (p / 'source261-retention-continuation-result.json').open('x') as out:
        json.dump(state, out, indent=2)
print(json.dumps(state), flush=True)
sys.exit(0 if len(results) == len(stages) and all(
    row['exit_code'] == 0 and row['source_unchanged'] and row['prior_source_unchanged'] and row['helper_unchanged']
    for row in results) else 1)
