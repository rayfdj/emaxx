from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
audit = read('source249-rebuilt-terminal-audit.json')
assert audit['status'] == 'passed'
assert audit['fully_matching_scenarios'] == 226 and audit['matching_comparisons'] == 686
assert audit['unexecuted_comparisons'] == 0 and not audit['divergent_labels']
files = {}
names = {
    'source249-manifest.json', 'source248-manifest.json', 'source249-rebuilt-terminal-audit.json',
    'source249-rebuilt-frozen-audit.json', 'source248-full-ttydiff-retry-command.json',
    'queue-source249-rebuilt-full-tty.py', 'audit-source249-rebuilt-terminal.py',
    'package-source196-failure-and197-results.py', Path(__file__).name,
}
for file in p.iterdir():
    if file.is_file() and file.suffix in ['.json', '.log', '.py']:
        if file.name in names or file.name.startswith('source249-rebuilt-full-tty'):
            files[file.name] = file
assert names <= files.keys()
command = read('source249-rebuilt-full-tty-command.json')
for name in ['tools/ttydiff.py', 'tools/fixtures/fieldnotes.org', 'tools/fixtures/fake_lsp_server.py']:
    file = Path(command['working_directory']) / name
    assert sha(file.read_bytes()) == read('source249-manifest.json')[name]
    files['execution-source/' + name] = file
package('source249-complete-rebuilt-terminal', files, dict(
    terminal=audit,
    qualification='Complete rebuilt-GNU source249 terminal validation: 226 scenarios, 658 screen and 28 filesystem comparisons all match, ten execution inputs and 476 source inputs unchanged. Supervisor12347 has exited. The exact gate executable/image also produced the separately retained macOS frozen result with six skip-diagnostic mismatches; those remain failures. This archive does not certify either later common-string draft or full-goal/performance completion.'))
