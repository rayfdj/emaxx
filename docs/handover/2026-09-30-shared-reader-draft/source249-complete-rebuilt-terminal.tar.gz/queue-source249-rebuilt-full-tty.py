from pathlib import Path
import hashlib
import json
import os
import re
import runpy
import subprocess
import sys
import time

p = Path(__file__).parent.resolve()
root = p.parent / 'rebuilt-2026-10-01/emaxx'
gnu = root.parent / 'emacs'
subject = root / 'target/compat-subject/gate/emaxx'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
source = json.loads((p / 'source249-manifest.json').read_text())
unchanged = lambda: all(sha(root / name) == digest for name, digest in source.items())
state = dict(status='waiting for complete macOS Rust process to exit', prior_pid=64326, goal_complete=False)

def save(name, data):
    with (p / ('source249-rebuilt-full-tty-' + name + '.json')).open('x') as stream:
        json.dump(data, stream, indent=2)

def save_state():
    (p / 'source249-rebuilt-full-tty-queue-state.json').write_text(json.dumps(state, indent=2) + '\n')

save_state()
try:
    assert len(source) == 476 and unchanged()
    frozen = json.loads((p / 'source249-rebuilt-frozen-audit.json').read_text())
    assert frozen['verified_files'] == 519 and frozen['successful_processes'] == 1038
    assert frozen['matching_outcomes'] == 7915 and frozen['mismatching_outcomes'] == 6
    for original, record in frozen['subject_inputs'].items():
        assert sha(Path(original)) == record['sha256']
    while True:
        process = subprocess.run(['ps', '-p', '64326', '-o', 'command='], capture_output=True, text=True)
        if process.returncode == 1 and not process.stdout.strip():
            break
        assert process.returncode == 0 and 'queue-source249-rebuilt-full-gate.py' in process.stdout
        time.sleep(5)
    prior = json.loads((p / 'source249-rebuilt-full-gate-queue-result.json').read_text())
    assert prior['source_unchanged']
    state['prior_rust_exit_code'] = prior.get('exit_code')
    module = runpy.run_path(str(root / 'tools/ttydiff.py'), run_name='inventory_only')
    inventory = [entry[0] for entry in module['select_scenarios']([])]
    assert len(inventory) == len(set(inventory)) == 226
    inputs = {str(path): sha(path) for path in [subject, subject.with_suffix('.pdmp'),
              gnu / 'src/emacs', gnu / 'src/emacs.pdmp', gnu / 'src/config.h', gnu / 'src/Makefile',
              root / 'tools/ttydiff.py', root / 'tools/fixtures/fieldnotes.org',
              root / 'tools/fixtures/fake_lsp_server.py', Path(__file__)]}
    env = dict(EMAXX_TTYDIFF_REQUIRE='1', LANG='C', LC_ALL='C')
    command = ['/usr/bin/caffeinate', '-i', sys.executable, 'tools/ttydiff.py',
               str(subject), str(gnu / 'src/emacs'), str(gnu / 'lisp')]
    save('command', dict(command=command, working_directory=str(root), environment_overrides=env,
         inputs=inputs, inventory=inventory, source_manifest='source249-manifest.json',
         profile='gate', candidate_commit='1c0898fc58f1f7e2fffc5a245a1f8ff7894832a0',
         qualification='Complete unchanged terminal inventory, using the exact source249 gate binary/image from the rebuilt-GNU full frozen comparison. Runs after local full Rust exits. Existing source249 release selected validation remains separate. Both editors receive -Q and inherit HOME. Frozen has six retained feature-reporting skip-diagnostic mismatches; no frozen pass, pin adoption, selector, timeout or comparison change is implied.'))
    state.update(status='running complete rebuilt-oracle terminal comparison', command=command)
    save_state()
    started = time.monotonic()
    with (p / 'source249-rebuilt-full-tty.log').open('xb') as log:
        completed = subprocess.run(command, cwd=root, env=dict(os.environ, **env), stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
    text = (p / 'source249-rebuilt-full-tty.log').read_text(errors='replace')
    observed = re.findall(r'^RUN \[(\d+)/(\d+)\] (.+)$', text, re.M)
    complete = len(observed) == len(inventory) and all(int(a) == index + 1 and int(b) == len(inventory) and name == inventory[index] for index, (a, b, name) in enumerate(observed))
    result = dict(exit_code=completed.returncode, elapsed_seconds=time.monotonic() - started,
                  source_unchanged=unchanged(), inputs_unchanged=all(sha(Path(path)) == digest for path, digest in inputs.items()),
                  expected_scenarios=226, started_scenarios=len(observed), complete_start_inventory=complete,
                  terminal_summary=text.splitlines()[-1:])
    save('result', result)
    state.update(status='terminal process finished; raw evidence requires audit', **result)
except Exception as error:
    state.update(status='failed', error=repr(error))
finally:
    save_state()
    save('queue-result', state)
print(json.dumps(state), flush=True)
sys.exit(0 if state.get('exit_code') == 0 and state.get('source_unchanged') and state.get('inputs_unchanged') else 1)
