from pathlib import Path
import json,subprocess,os,time,hashlib
p=Path(__file__).parent.resolve();old=json.loads((p/'source310-erc-pristine-diagnostic/0/command.json').read_text());d=p/'source310-erc-signal-trace'
cmd=[s.replace(str(p/'source310-erc-pristine-diagnostic/0'),str(d)) for s in old['command']];env=dict(os.environ)
for k in list(env):
 if k.startswith('EMAXX_') or k in ['EMACSDATA','EMACSDOC','EMACSLOADPATH','EMACSNATIVELOADPATH','EMACSPATH','GREP_OPTIONS','LC_ALL','LC_CTYPE','XDG_CONFIG_HOME']:del env[k]
overrides={k:v.replace(str(p/'source310-erc-pristine-diagnostic/0'),str(d)) for k,v in old['environment_overrides'].items()};overrides['DYLD_INSERT_LIBRARIES']=str(p/'erc-crash-trace.dylib');env.update(overrides)
(d/'command.json').open('x').write(json.dumps(dict(command=cmd,cwd=old['cwd'],environment_overrides=overrides,qualification='Instrumented crash diagnosis, not compatibility acceptance; signal handler prints current thread backtrace and exits 128+signal',shim_sha256=hashlib.sha256((p/'erc-crash-trace.dylib').read_bytes()).hexdigest()),indent=2));start=time.monotonic()
with (d/'stdout').open('xb') as out,(d/'stderr').open('xb') as err:
 try:r=subprocess.run(cmd,cwd=old['cwd'],env=env,stdout=out,stderr=err,timeout=120);code=r.returncode;timed=False
 except subprocess.TimeoutExpired:code=None;timed=True
result=dict(exit_code=code,timed_out=timed,elapsed_seconds=time.monotonic()-start);(d/'result.json').open('x').write(json.dumps(result,indent=2));print(result)
