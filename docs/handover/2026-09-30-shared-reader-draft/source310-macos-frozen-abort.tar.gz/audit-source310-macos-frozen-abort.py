from pathlib import Path
import json,hashlib,collections,shutil,subprocess
p=Path(__file__).parent.resolve();c=p.parent/'recovered-2026-10-06/native-unit-full/emaxx';r=c/'target/compat/frozen-1791275115978456000-80476';read=lambda f:json.loads(f.read_text());sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
contract=read(r/'contract.json');assert len(contract['files'])==519 and read(r/'head.json')['commit']=='5e6f6fc89654b5e695161f5e1713d06ff8ca1f3c';assert not (r/'summary.json').exists()
seen={};counts={'oracle':collections.Counter(),'emaxx':collections.Counter()};matching=mismatching=successful=0;issues=[];verdicts=[]
for f in r.rglob('execution.json'):
 receipt=read(f);assert receipt['contract_sha256']==sha(r/'contract.json');name=receipt['file'];assert name in contract['files'] and name not in seen;seen[name]=str(f.parent.relative_to(r))
 for n,h in receipt['sha256'].items():assert sha(f.parent/n)==h
 row=dict(file=name)
 for runner in ['oracle','emaxx']:
  report=read(f.parent/(runner+'.json'));proc=read(f.parent/(runner+'.execution.json'))['process'];assert report['file']==name and report['selector']==contract['selector'];assert not proc['timed_out']
  raw=collections.Counter(x['status'] for x in report['results']);counts[runner].update(raw)
  assert len(report['results'])==report['summary']['total']
  row[runner]=dict(exit_code=proc['exit_code'],test_started=proc['test_started'],summary=report['summary'],file_status=report['file_status'])
  if proc['exit_code']==0:successful+=1
  else:issues.append(dict(file=name,runner=runner,process=proc))
 comparison=f.parent/'comparison.json'
 if comparison.exists():
  q=read(comparison);assert not q.get('execution_issues');matching+=q['matching_outcomes'];mismatching+=q['mismatching_outcomes'];row['comparison']=dict(matches=q['matches'],matching=q['matching_outcomes'],mismatching=q['mismatching_outcomes'])
 verdicts.append(row)
assert set(seen)==set(contract['files'][:183]);assert len(issues)==1
failure=issues[0];assert failure['file']=='test/lisp/erc/erc-scenarios-misc-commands.el' and failure['runner']=='emaxx' and failure['process']['exit_code'] is None and failure['process']['test_started']
assert len(list(r.rglob('comparison.json')))==182 and successful==365
reproductions=[read(p/f'source310-erc-pristine-diagnostic/{i}/result.json') for i in range(3)];assert all(x['exit_code']==-11 and x['signal']=='SIGSEGV' and not x['timed_out'] for x in reproductions)
# Preserve exact crashed executable/image independently of subsequent builds.
retain=p/'source310-macos-frozen-failed-inputs';retain.mkdir();retained=[]
for n in ['emaxx','emaxx.pdmp']:
 src=c/'target/compat-subject/gate'/n;dest=retain/n;subprocess.run(['cp','-c',str(src),str(dest)],check=True);assert sha(src)==sha(dest);retained.append(dict(source=str(src),artifact=str(dest),sha256=sha(dest),bytes=dest.stat().st_size))
result=dict(status='failed: partial frozen comparison aborted at Emaxx process termination',source_commit='5e6f6fc89654b5e695161f5e1713d06ff8ca1f3c',raw_directory=str(r),attempted_files=183,completed_comparisons=182,scheduled_files=519,unstarted_files=contract['files'][183:],matching_outcomes=matching,mismatching_outcomes=mismatching,raw_outcome_counts={k:dict(v) for k,v in counts.items()},successful_processes=successful,failed_processes=issues,per_file=verdicts,raw_files={str(f.relative_to(r)):sha(f) for f in r.rglob('*') if f.is_file()},retained_inputs=retained,ordinary_replay=read(p/'source310-erc-replay-result.json'),direct_signal_reproductions=reproductions,goal_complete=False,qualification='GNU passes the ERC case; Emaxx reports no result and terminates after test start. The harness did not record the signal, but three pristine-checkout direct reproductions captured SIGSEGV. Later runs with changed diagnostic output paths pass on the same binary, so the cause is not closed. No missing test or process failure is normalized. Only 183 of 519 files started; this is not the known six-diagnostic-only complete macOS result.')
(p/'source310-macos-frozen-abort-audit.json').open('x').write(json.dumps(result,indent=2));print({k:result[k] for k in ['status','attempted_files','completed_comparisons','matching_outcomes','mismatching_outcomes','raw_outcome_counts','successful_processes']})
