#include <signal.h>
#include <unistd.h>
#include <execinfo.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/ucontext.h>
static void trace_fault(int signo, siginfo_t *info, void *context) {
  void *frames[96];
  ucontext_t *uc = context;
  dprintf(2, "DIAGNOSTIC fault signal=%d address=%p pc=%p lr=%p\n", signo, info->si_addr,
          (void *)uc->uc_mcontext->__ss.__pc, (void *)uc->uc_mcontext->__ss.__lr);
  int n = backtrace(frames, 96);
  backtrace_symbols_fd(frames, n, 2);
  _exit(128 + signo);
}
__attribute__((constructor)) static void install_trace(void) {
  struct sigaction action = {0};
  action.sa_sigaction = trace_fault;
  action.sa_flags = SA_SIGINFO | SA_ONSTACK;
  sigemptyset(&action.sa_mask);
  sigaction(SIGSEGV, &action, NULL);
  sigaction(SIGBUS, &action, NULL);
}
