from pathlib import Path
import json,os,subprocess,time,signal
p=Path(__file__).parent.resolve();old=json.loads((p/'source310-erc-pristine-diagnostic/0/command.json').read_text());root=p/'source310-erc-pristine-diagnostic'
for index in range(3,9):
 d=root/str(index);d.mkdir();cmd=[s.replace(str(root/'0'),str(d)) for s in old['command']];env=dict(os.environ)
 for k in list(env):
  if k.startswith('EMAXX_') or k in ['EMACSDATA','EMACSDOC','EMACSLOADPATH','EMACSNATIVELOADPATH','EMACSPATH','GREP_OPTIONS','LC_ALL','LC_CTYPE','XDG_CONFIG_HOME']:del env[k]
 overrides={k:v.replace(str(root/'0'),str(d)) for k,v in old['environment_overrides'].items()};overrides['DYLD_INSERT_LIBRARIES']=str(p/'erc-crash-trace.dylib')
 if index>3:overrides['ERC_DIAGNOSTIC_PADDING']='a'*(128*(index-3))
 env.update(overrides);(d/'command.json').write_text(json.dumps(dict(command=cmd,cwd=old['cwd'],environment_overrides=overrides,qualification='instrumented diagnostic only; varies unrelated environment padding'),indent=2));start=time.monotonic()
 with (d/'stdout').open('wb') as out,(d/'stderr').open('wb') as err:
  try:r=subprocess.run(cmd,cwd=old['cwd'],env=env,stdout=out,stderr=err,timeout=90);code,timed=r.returncode,False
  except subprocess.TimeoutExpired:code,timed=None,True
 result=dict(exit_code=code,timed_out=timed,elapsed_seconds=time.monotonic()-start);(d/'result.json').write_text(json.dumps(result,indent=2));print(index,result,flush=True)
 if code not in [0,None] and b'DIAGNOSTIC fault' in (d/'stderr').read_bytes():break
