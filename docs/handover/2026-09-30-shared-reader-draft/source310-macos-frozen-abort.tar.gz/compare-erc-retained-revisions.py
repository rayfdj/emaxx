from pathlib import Path
import os,json,subprocess,time,signal,hashlib
p=Path(__file__).parent.resolve();old=json.loads((p/'source310-erc-pristine-diagnostic/0/command.json').read_text());root=p/'erc-retained-revisions';root.mkdir();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
bins={
'source308-release':p.parent/'recovered-2026-10-06/native-subr-callbacks/emaxx/target/vm-dispatch-validation/release/emaxx',
'source310-gate':Path(old['command'][0]),
'source310-release':p.parent/'recovered-2026-10-06/native-unit-owners/emaxx/target/vm-dispatch-validation/release/emaxx',
'source311-release':p.parent/'recovered-2026-10-06/bytecode-stack/emaxx/target/stack-development/release/emaxx',
'source312-gate':p.parent/'recovered-2026-10-06/bytecode-gc/emaxx/target/gc-development/gate/emaxx'}
for label,exe in bins.items():
 assert exe.is_file();d=root/label;d.mkdir();cmd=[s.replace(str(p/'source310-erc-pristine-diagnostic/0'),str(d)) for s in old['command']];cmd[0]=str(exe);env=dict(os.environ)
 for k in list(env):
  if k.startswith('EMAXX_') or k in ['EMACSDATA','EMACSDOC','EMACSLOADPATH','EMACSNATIVELOADPATH','EMACSPATH','GREP_OPTIONS','LC_ALL','LC_CTYPE','XDG_CONFIG_HOME']:del env[k]
 overrides={k:v.replace(str(p/'source310-erc-pristine-diagnostic/0'),str(d)) for k,v in old['environment_overrides'].items()};env.update(overrides)
 (d/'command.json').write_text(json.dumps(dict(command=cmd,cwd=old['cwd'],environment_overrides=overrides,executable_sha256=sha(exe),image_sha256=sha(exe.with_suffix('.pdmp'))),indent=2));start=time.monotonic()
 with (d/'stdout').open('wb') as out,(d/'stderr').open('wb') as err:
  try:r=subprocess.run(cmd,cwd=old['cwd'],env=env,stdout=out,stderr=err,timeout=180);code=r.returncode;timed=False
  except subprocess.TimeoutExpired:code=None;timed=True
 result=dict(exit_code=code,signal=signal.Signals(-code).name if code is not None and code<0 else None,timed_out=timed,elapsed_seconds=time.monotonic()-start)
 if (d/'emaxx.json').exists():result['ert_summary']=json.loads((d/'emaxx.json').read_text()).get('summary')
 (d/'result.json').write_text(json.dumps(result,indent=2));print(label,result,flush=True)
