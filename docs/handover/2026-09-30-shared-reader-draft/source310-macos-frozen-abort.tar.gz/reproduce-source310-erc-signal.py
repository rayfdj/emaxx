from pathlib import Path
import json,os,subprocess,time,tempfile,signal,hashlib
p=Path(__file__).parent.resolve();g=p.parent/'rebuilt-2026-10-01/emacs';old=json.loads((p/'source310-erc-direct-harness-env/command.json').read_text());root=p/'source310-erc-pristine-diagnostic';root.mkdir();clone=Path(tempfile.mkdtemp(prefix='emaxx-erc-pristine-'))/'emacs'
with (root/'clone.log').open('wb') as log:
 r=subprocess.run(['git','clone','--shared',str(g),str(clone)],stdout=log,stderr=subprocess.STDOUT);assert r.returncode==0
actual=subprocess.check_output(['git','rev-parse','HEAD'],cwd=clone).decode().strip();assert actual=='636f166cfc86aa90d63f592fd99f3fdd9ef95ebd'
for i in range(3):
 d=root/str(i);d.mkdir();tmp=Path(tempfile.mkdtemp(prefix='erc-pristine-',dir='/tmp'))
 cmd=[s.replace(str(g/'test'),str(clone/'test')).replace(str(p/'source310-erc-direct-harness-env'),str(d)).replace(old['environment_overrides']['TMPDIR'],str(tmp)) for s in old['command']]
 env=dict(os.environ)
 for k in list(env):
  if k.startswith('EMAXX_') or k in ['EMACSDATA','EMACSDOC','EMACSLOADPATH','EMACSNATIVELOADPATH','EMACSPATH','GREP_OPTIONS','LC_ALL','LC_CTYPE','XDG_CONFIG_HOME']:del env[k]
 overrides={k:v.replace(str(p/'source310-erc-direct-harness-env'),str(d)).replace(old['environment_overrides']['TMPDIR'],str(tmp)).replace(str(g/'test'),str(clone/'test')) for k,v in old['environment_overrides'].items()};env.update(overrides)
 (d/'command.json').write_text(json.dumps(dict(command=cmd,cwd=str(clone/'test'),environment_overrides=overrides,clone_commit=actual),indent=2));start=time.monotonic()
 with (d/'stdout').open('wb') as out,(d/'stderr').open('wb') as err:
  try:r=subprocess.run(cmd,cwd=clone/'test',env=env,stdout=out,stderr=err,timeout=180);code=r.returncode;timed=False
  except subprocess.TimeoutExpired:code=None;timed=True
 result=dict(exit_code=code,signal=signal.Signals(-code).name if code is not None and code<0 else None,timed_out=timed,elapsed_seconds=time.monotonic()-start)
 (d/'result.json').write_text(json.dumps(result,indent=2));print(i,result,flush=True)
