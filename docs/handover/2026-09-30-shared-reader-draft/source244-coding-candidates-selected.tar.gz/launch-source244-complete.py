from pathlib import Path
import hashlib, json, subprocess, sys

p = Path(__file__).parent.resolve()
read = lambda name: json.loads((p / name).read_text())
stages = read('source244-validation-result.json')
assert len(stages) == 7 and all(stage['exit_code'] == 0 for stage in stages)
assert read('source244-gate-focused-audit.json')['passed'] == 166
selected = read('source244-selected-audit.json')
assert selected['affected_passes'] == 949 and selected['ordinary_comparisons'] == 9
assert read('source244-upstream-compiler-raw-audit.json')['outcomes_per_editor'] == 177
records = []
for label, name in [('full-gate', 'run-source244-full-gate.py'),
                    ('release-and-ordinary', 'run-source244-release-and-ordinary.py'),
                    ('full-ttydiff', 'run-source244-full-tty.py')]:
    helper = p / name
    with (p / ('source244-' + label + '-driver.log')).open('x') as log:
        child = subprocess.Popen([sys.executable, '-B', str(helper)], stdin=subprocess.DEVNULL,
                                 stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    record = dict(pid=child.pid, command=[sys.executable, '-B', str(helper)],
                  helper_sha256=hashlib.sha256(helper.read_bytes()).hexdigest(),
                  source_manifest='source244-manifest.json', qualification='Launch is not a passing result.')
    with (p / ('source244-' + label + '-launch.json')).open('x') as stream:json.dump(record, stream, indent=2)
    records.append(record)
with (p / 'source244-complete-launch-result.json').open('x') as stream:json.dump(records, stream, indent=2)
print(json.dumps(records, indent=2), flush=True)
