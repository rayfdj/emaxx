from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
read = lambda name: json.loads((p / name).read_text())
focused = read('source244-gate-focused-audit.json')
selected = read('source244-selected-audit.json')
compiler = read('source244-upstream-compiler-raw-audit.json')
assert focused['passed'] == 166 and selected['affected_passes'] == 949
assert selected['ordinary_comparisons'] == 9 and compiler['outcomes_per_editor'] == 177
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected'}
patterns = [
    'source244-manifest.json', 'source244-*.patch', 'source244-freeze.json', 'source244-worktree-preparation.json',
    'source244-patch-replay-audit.json', 'source244-validation-*', 'source244-gate-*',
    'source244-selected-audit.json', 'source244-ordinary-artifacts.json', 'source244-ordinary-build*',
    'source244-ordinary-image*', 'source244-compiler-load-*', 'source244-upstream-compiler-*',
    'source244-task-checkout-applied.json', 'source244-complete-launch-result.json',
    'source244-full-gate-launch.json', 'source244-full-gate-command.json',
    'source244-full-ttydiff-launch.json', 'source244-full-ttydiff-command.json',
    'source244-release-and-ordinary-launch.json',
    'freeze-source244.py', 'audit-source244-*.py', 'check-source244.py', 'static-source244.py',
    'test-source244-*.py', 'build-source244.py', 'run-source244-*.py', 'launch-source244-complete.py',
    'probe-source244-compiler-load.py', 'compare-source244-upstream-compiler.py',
    'compare-source230-fixtures.py', 'audit-source238-release.py', Path(__file__).name,
]
for stage in ['check', 'fmt', 'clippy', 'diff']:
    patterns.append('source244-' + stage + '*')
for fixture in selected['fixtures']:
    patterns.append('source244-ordinary-' + fixture + '-*')
files = {str(file.relative_to(p)): file for pattern in patterns for file in p.glob(pattern)
         if file.is_file() and file.suffix in allowed}
for directory in ['source244-compiler-load', 'source244-upstream-compiler']:
    files.update({str(file.relative_to(p)): file for file in (p / directory).rglob('*')
                  if file.is_file() and file.suffix in allowed})
assert not any(name in files for name in ['source244-full-gate.log', 'source244-full-ttydiff.log',
                                         'source244-release-and-ordinary-driver.log', 'source244-ordinary-comparisons.log'])
package('source244-coding-candidates-selected', files,
        dict(patch_replay=read('source244-patch-replay-audit.json'), focused=focused, selected=selected,
             compiler=compiler, full_launches=read('source244-complete-launch-result.json'),
             qualification='Source244 repairs the safe-coding candidate list rather than bypassing GNU file-writing policy. All 464 inputs and modes replay from the task checkpoint and main. Zero-warning strict checks, 166 focused passes/two existing ignores, all 949 affected passes and nine ordinary comparisons are audited. The exact upstream compiler load now succeeds and all original 177 selected tests pass in both normal editors. Complete macOS, release and terminal runs have launched; their active logs are excluded. Linux and pinned Darwin validation and performance remain open. Translation-table semantics, candidate ordering and remaining general coding behavior are not certified by this targeted repair. Source243 complete frozen failure and all prior evidence remain unchanged.'))
