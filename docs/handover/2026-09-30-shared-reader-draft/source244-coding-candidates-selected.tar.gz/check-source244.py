from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/coding-selection/emaxx')
p=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28')
prefix='source'+sys.argv[1]
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
files=[*root.joinpath('src').rglob('*.rs'),*root.joinpath('tests').rglob('*')]
files += [root/name for name in ['Cargo.toml','Cargo.lock','build.rs','tools/ttydiff.py','tools/fixtures/fieldnotes.org','tools/fixtures/fake_lsp_server.py'] if (root/name).is_file()]
files += list(root.joinpath('.cargo').glob('*'))
files += [root/f for f in ['compat/emacs_compat_runner.el','src/lisp/bytecode/fixture-oracle-30.2.elc','src/lisp/bytecode/fixture-oracle2-30.2.elc','src/lisp/bytecode/fixture-oracle3-30.2.elc']]
files=sorted({f for f in files if f.is_file()})
manifest={str(f.relative_to(root)):sha(f) for f in files}
def save(name,data):
    with (p/(prefix+'-'+name+'.json')).open('x') as stream:json.dump(data,stream,indent=2);stream.write('\n')
assert manifest == json.loads((p/(prefix+'-manifest.json')).read_text())
command=['cargo','check','--locked','--all-targets','--all-features']
overrides={'CARGO_TARGET_DIR':'/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/coding-selection/emaxx/target/frame-validation','CARGO_BUILD_JOBS':'1'}
save('check-command',{'command':command,'working_directory':str(root),'environment_override':overrides,'source_manifest':prefix+'-manifest.json'})
start=time.monotonic()
with (p/(prefix+'-check.log')).open('x') as log:
    result=subprocess.run(command,cwd=root,env={**os.environ,**overrides},stdout=log,stderr=subprocess.STDOUT)
record={'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,'source_unchanged':all(sha(root/name)==value for name,value in manifest.items())}
save('check-result',record)
print(json.dumps(record),flush=True)
sys.exit(result.returncode or (0 if record['source_unchanged'] else 1))
