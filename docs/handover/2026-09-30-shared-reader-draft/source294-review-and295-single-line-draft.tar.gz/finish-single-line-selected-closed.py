from pathlib import Path
import hashlib, json, subprocess, sys, time
p = Path(__file__).parent.resolve()
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p/n).read_text())
helpers = {n:sha(p/n) for n in ['buffer_line_validation_support.py', 'run-source295-validation.py', 'verify-existing-portable-draft.py', 'compare-vm-dispatch-fixtures.py', 'compare-source292-generated-loaded.py', 'compare-source295-generated-loaded.py', 'compare-buffer-line-broad-probe.py', 'audit-single-line-selected.py', Path(__file__).name]}
state = dict(status='waiting for source295 fresh validation', steps=[], helpers=helpers, goal_complete=False)
def save(): (p/'single-line-selection-closed-state.json').write_text(json.dumps(state,indent=2)+'\n')
def run(stage, command):
    assert all(sha(p/n)==h for n,h in helpers.items())
    state['status']='running '+stage;save();start=time.monotonic()
    with (p/('single-line-selection-closed-'+stage+'-command.json')).open('x') as f: json.dump(dict(command=command, cwd=str(p), helpers=helpers),f,indent=2)
    with (p/('single-line-selection-closed-'+stage+'.log')).open('xb') as log:
        r=subprocess.run(command,cwd=p,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
    item=dict(stage=stage,exit_code=r.returncode,elapsed_seconds=time.monotonic()-start,helpers_unchanged=all(sha(p/n)==h for n,h in helpers.items()))
    state['steps'].append(item);save();print(json.dumps(item),flush=True)
    assert r.returncode==0 and item['helpers_unchanged']
save();success=False
try:
    while not (p/'source295-validation-result.json').exists():
        print(state['status'],flush=True);time.sleep(20)
    assert read('source292-validation-closed-result.json')['status']=='strict, selected and ordinary build passed; raw audit and ordinary comparisons required'
    assert read('source295-validation-result.json')['status']=='strict, selected and ordinary build passed; raw audit and ordinary comparisons required'
    names=list(read('source290-selected-closed-audit.json')['ordinary_results'])+['buffer-lf-line-motion']
    assert len(names)==46
    for tag,folder in [('source295','buffer-single-line')]:
        c=p.parent/'recovered-2026-10-05'/folder/'emaxx'
        if tag=='source295': run(tag+'-portable',[sys.executable,'-B',str(p/'verify-existing-portable-draft.py'),tag,str(c)])
        run(tag+'-ordinary',[sys.executable,'-B',str(p/'compare-vm-dispatch-fixtures.py'),tag,str(c),*names])
        run(tag+'-generated',[sys.executable,'-B',str(p/('compare-'+tag+'-generated-loaded.py'))])
        run(tag+'-broad-diagnosis',[sys.executable,'-B',str(p/'compare-buffer-line-broad-probe.py'),tag,str(c)])
        run(tag+'-audit',[sys.executable,'-B',str(p/'audit-single-line-selected.py'),tag,str(c)])
    state['status']='single-line selected audit closed; 60 original display-column failures retained separately; performance pending';success=True
except Exception as error:
    state.update(status='selection stopped',error=repr(error))
finally:
    save()
    with (p/'single-line-selection-closed-result.json').open('x') as f:json.dump(state,f,indent=2)
print(json.dumps(dict(status=state['status'],error=state.get('error'))),flush=True)
sys.exit(0 if success else 1)
