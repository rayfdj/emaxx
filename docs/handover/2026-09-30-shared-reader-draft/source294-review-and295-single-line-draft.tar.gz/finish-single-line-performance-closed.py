from pathlib import Path
import hashlib,json,subprocess,sys,time
p=Path(__file__).parent.resolve();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
fixed={n:sha(p/n) for n in ['measure-single-line.py','audit-single-line-performance.py',Path(__file__).name]}
state=dict(status='waiting for both line selected audits',helpers=fixed,steps=[],goal_complete=False)
def save(): (p/'single-line-performance-sequence-closed-state.json').write_text(json.dumps(state,indent=2)+'\n')
save();success=False
try:
 while not (p/'single-line-selection-closed-result.json').exists():
  print(state['status'],flush=True);time.sleep(30)
 selected=json.loads((p/'single-line-selection-closed-result.json').read_text());assert selected['status']=='single-line selected audit closed; 60 original display-column failures retained separately; performance pending',selected['status']
 assert len(selected['steps'])==5 and all(x['exit_code']==0 for x in selected['steps'])
 for name in ['measure-single-line.py','audit-single-line-performance.py']:
  assert all(sha(p/n)==h for n,h in fixed.items())
  state['status']='running '+name;save();start=time.monotonic();command=[sys.executable,'-B',str(p/name)]
  with (p/('single-line-performance-step-closed-'+name+'.log')).open('xb') as log:r=subprocess.run(command,cwd=p,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
  result=dict(command=command,exit_code=r.returncode,elapsed_seconds=time.monotonic()-start);state['steps'].append(result);save();print(json.dumps(result),flush=True);assert r.returncode==0
 state['status']='timing audited; source decision pending';success=True
except Exception as error:state.update(status='sequence stopped',error=repr(error))
finally:
 save()
 with (p/'single-line-performance-sequence-closed-result.json').open('x') as f:json.dump(state,f,indent=2)
print(json.dumps(dict(status=state['status'],error=state.get('error'))),flush=True)
sys.exit(0 if success else 1)
