from pathlib import Path
import hashlib,json,sys
p=Path(__file__).parent.resolve();tag,directory,*names=sys.argv[1:];c=Path(directory)
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();read=lambda n:json.loads((p/n).read_text())
manifest=read(tag+'-manifest.json');assert all(sha(c/n)==h for n,h in manifest.items())
assert tag=='source292' and len(names)==46
for name in names:
    comparison=read(tag+'-ordinary-'+name+'-comparison.json')
    assert comparison['passed'] and comparison['exact_match']
    programs=[];outputs=[]
    for editor in ('gnu','emaxx'):
        stem=tag+'-ordinary-'+name+'-'+editor
        command=read(stem+'.command.json');outcome=read(stem+'.result.json')
        assert all(sha(Path(n))==h for n,h in command['inputs'].items())
        assert outcome==comparison['outcomes'][editor]
        assert outcome['exit_code']==0 and not outcome['timed_out'] and outcome['inputs_unchanged'] and outcome['source_unchanged'] and outcome['expected_output'] is not False
        out=(p/(stem+'.stdout')).read_bytes();err=(p/(stem+'.stderr')).read_bytes()
        assert out and not err and hashlib.sha256(out).hexdigest()==outcome['stdout_sha256'] and err.hex()==outcome['stderr_hex']
        programs.append(command['command'][-1]);outputs.append(out)
    assert programs[0]==programs[1] and outputs[0]==outputs[1]
record=dict(status='all46 existing ordinary comparisons and92 process receipts independently reverified',reason='The terminated v3 coordinator had already spawned the valid source292 comparison child. It completed all46 comparisons; the later fresh coordinator stopped on a write-once receipt collision before rerunning anything. Reuse these verified completed results; preserve both coordinator states and the FileExistsError.',qualification='Only valid source292 executable/image outputs are reused. Source293 cached candidate results remain rejected. Source294 comparisons must run separately.',goal_complete=False)
with (p/'source292-existing-ordinary-verification.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(record))
