from pathlib import Path
import ast, hashlib, json, re, shutil

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/string-bytes/emaxx'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read('source228-manifest.json')
assert len(manifest) == 429 and all(sha(root / name) == digest for name, digest in manifest.items())
node = next(n for n in ast.parse((p / 'audit-shared-reader196-fresh-selected.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'audit_log')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<raw-auditor>', 'exec'))
failure = 'lisp::primitives::tests::completion_results_preserve_gnu_encoding_properties_and_identity'
groups = []
for profile in ['gate']:
    for group, passed, failed in [('controls', 24, 1), ('broad', 932, 1)]:
        stem = 'source228-' + profile + '-' + group
        command, result = read(stem + '-command.json'), read(stem + '-result.json')
        assert result['exit_code'] == (101 if failed else 0) and result['source_unchanged']
        assert sha(p / ('source228-' + profile + '-libtest')) == command['binary_sha256']
        assert command['environment_override']['LANG'] == command['environment_override']['LC_ALL'] == 'C'
        names = command['selected_inventory']
        if profile == 'release':
            assert names == read('source228-gate-' + group + '-command.json')['selected_inventory']
        assert audit_log(names, (p / (stem + '.log')).read_text(), passed, failed) == ([failure] if failed else [])
        groups.append(dict(profile=profile, stage=group, passed=passed, failed=failed, ignored=0, inventory_verified=len(names)))
for stage in ['check', 'fmt', 'clippy', 'diff', 'gate-build']:
    result = read('source228-' + stage + '-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
    raw = (p / ('source228-' + stage + '.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
    for line in raw.splitlines():
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        assert item.get('message', {}).get('level') not in ['error', 'warning']
retained = p / 'source228-retained-inputs'
retained.mkdir()
files = []
for source in [p / 'source228-gate-libtest', *sorted((p / 'fixture-images-source228').glob('*.pdmp'))]:
    target = retained / source.name
    digest = sha(source)
    shutil.copy2(source, target)
    assert sha(source) == sha(target) == digest
    files.append(dict(original=str(source), retained=str(target), sha256=digest, bytes=target.stat().st_size))
record = dict(status='gate completion repair retains one concat character-loss failure', inputs_verified=len(manifest),
              strict_checks='passed with zero warnings', groups=groups, retained_files=files, failing_names=[failure],
              qualification='The original Tramp test now passes, along with all 20 previous string/bytecode controls. The new unchanged GNU fixture fails because concat turns surrogate and beyond-Unicode characters into U+F8FF before completion sees them. Both original assertion values and the full 933-test broader inventory remain preserved. These are gate-profile results; release, complete validation and performance remain unverified.')
with (p / 'source228-results-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record, indent=2))
