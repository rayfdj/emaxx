from pathlib import Path
import hashlib, json, subprocess, sys

p = Path(__file__).parent.resolve()
root = p.parents[2]
artifact = p / 'source279-linux-frozen-artifacts'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda path: json.loads(path.read_text())
download = read(p / 'source279-linux-frozen-download.json')
assert download['run_id'] == 36950667238
assert sha(p / 'source279-linux-frozen-artifact.zip') == download['archive_sha256']
assert len(download['files']) == 5204
assert all(sha(artifact / path) == digest for path, digest in download['files'].items())
summaries = list(artifact.rglob('summary.json'))
assert len(summaries) == 1
frozen = summaries[0].parent
head = 'd64040a7efe9a5039750b7c0b8feb7796c57fe79'
subprocess.run([sys.executable, str(p / 'verify-complete-frozen-receipts279.py'), str(frozen),
                head, '36950667238', str(p / 'source279-linux-frozen-complete-audit.json')],
               cwd=root, check=True)
summary = read(summaries[0])
for file in summary['files']:
    directory = (frozen / file).with_suffix('.compat')
    execution = read(directory / 'execution.json')
    assert execution['contract_sha256'] == sha(frozen / 'contract.json')
    assert all(sha(directory / name) == digest for name, digest in execution['sha256'].items())
    pair = [read(directory / (runner + '.json')) for runner in ['oracle', 'emaxx']]
    assert {row['name']: (row['status'], row['expected']) for row in pair[0]['results']} == {
        row['name']: (row['status'], row['expected']) for row in pair[1]['results']}
capture = read(artifact / 'oracle-inputs/manifest.json')
verified = read(artifact / 'oracle-inputs/verification.json')
assert capture['status'] == 'captured' and verified['status'] == 'unchanged'
assert verified['capture_manifest_sha256'] == sha(artifact / 'oracle-inputs/manifest.json')
assert verified['files_verified'] == len(capture['files']) == 4
assert not capture['source_tracked_changes']
assert capture['source_commit'] == summary['provenance']['oracle_repo_commit']
for item in capture['files']:
    file = artifact / 'oracle-inputs' / item['artifact']
    assert file.stat().st_size == item['bytes'] and sha(file) == item['sha256']
assert capture['files'][0]['sha256'] == summary['provenance']['oracle_sha256']
record = dict(status='all raw execution hashes, paired outcomes and actual GNU inputs verified',
              files=519, outcomes=7928, successful_processes=1038, archive_members=5204,
              contract_sha256=sha(frozen / 'contract.json'), archive_sha256=download['archive_sha256'],
              oracle_capture=capture, oracle_after_verification=verified, goal_complete=False,
              qualification='Every paired outcome, execution hash, frozen inventory and actual GNU input is verified. Both editors report7670 passes,47 expected failures and211 skips; all177 original compiler tests pass. The original source244 and source272 GNU Eglot timeouts remain failed evidence, and this successful full Linux rerun does not establish their cause. The earlier GNU and Emaxx GC census variations remain unexplained. MacOS, the unapplied source281 printer draft, architecture and performance require separate evidence.')
with (p / 'source279-linux-frozen-raw-integrity-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps({k: record[k] for k in ['status', 'files', 'outcomes', 'successful_processes']}))
