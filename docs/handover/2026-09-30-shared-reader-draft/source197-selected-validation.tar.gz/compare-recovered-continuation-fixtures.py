from pathlib import Path
import hashlib, json, os, subprocess, sys, time

p = Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28')
tag, directory, *names = sys.argv[1:]
root = Path(directory)
manifest = json.loads((p / (tag + '-manifest.json')).read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
unchanged = lambda: all(sha(root / f) == h for f, h in manifest.items())
assert names and unchanged()
binaries = {'gnu': Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/emacs/src/emacs'),
            'emaxx': root / 'target/frame-validation/release/emaxx'}
comparisons = []
for name in names:
    fixture = root / ('tests/fixtures/' + name + '.el')
    if not fixture.exists():
        fixture = p / (name + '.el')
    expected_file = fixture.with_suffix('.expected')
    expected = expected_file.read_bytes().rstrip(b'\n') if expected_file.exists() else None
    results = {}
    for label, binary in binaries.items():
        stem = p / (tag + '-ordinary-' + name + '-' + label)
        inputs = {str(f): sha(f) for f in [binary, binary.with_suffix('.pdmp'), fixture]}
        command = [str(binary), '-Q', '--batch', '--eval', '(prin1 ' + fixture.read_text() + ')']
        with stem.with_suffix('.command.json').open('x') as f:
            json.dump({'command': command, 'working_directory': str(p), 'inputs': inputs,
                       'environment_override': {'EMAXX_GC_VERIFY': '1'}, 'timeout_seconds': 120,
                       'qualification': 'Ordinary exact same-input comparison; source-matched GNU, not the frozen Darwin executable. Execution modes and semantic checks are explicit in the fixture.'}, f, indent=2)
        start = time.monotonic()
        try:
            run = subprocess.run(command, cwd=p, env={**os.environ, 'EMAXX_GC_VERIFY': '1'}, capture_output=True, timeout=120)
            code, stdout, stderr, timeout = run.returncode, run.stdout, run.stderr, False
        except subprocess.TimeoutExpired as error:
            code, stdout, stderr, timeout = None, error.stdout or b'', error.stderr or b'', True
        stem.with_suffix('.stdout').write_bytes(stdout)
        stem.with_suffix('.stderr').write_bytes(stderr)
        result = {'exit_code': code, 'elapsed_seconds': time.monotonic() - start, 'timed_out': timeout,
                  'stdout_sha256': hashlib.sha256(stdout).hexdigest(), 'stderr_hex': stderr.hex(),
                  'expected_output': None if expected is None else stdout == expected,
                  'inputs_unchanged': all(sha(Path(f)) == h for f, h in inputs.items()), 'source_unchanged': unchanged()}
        with stem.with_suffix('.result.json').open('x') as f:
            json.dump(result, f, indent=2)
        results[label] = result
        print(name, label, code, stdout[:160], stderr[:160], flush=True)
    exact = all(results['gnu'][key] == results['emaxx'][key] for key in ['exit_code', 'stdout_sha256', 'stderr_hex'])
    passing = exact and all(r['exit_code'] == 0 and r['stderr_hex'] == '' and r['inputs_unchanged'] and r['source_unchanged'] and r['expected_output'] is not False for r in results.values())
    with (p / (tag + '-ordinary-' + name + '-comparison.json')).open('x') as f:
        json.dump({'outcomes': results, 'exact_match': exact, 'passed': passing}, f, indent=2)
    comparisons.append(passing)
assert all(comparisons), 'At least one ordinary fixture differs or failed'
