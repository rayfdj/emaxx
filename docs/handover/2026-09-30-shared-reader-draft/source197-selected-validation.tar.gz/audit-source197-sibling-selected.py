from pathlib import Path
import hashlib
import json
import re

p = Path(__file__).parent.resolve()
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())


def audit_log(names, log, expected_passed, expected_failed):
    assert len(names) == len(set(names))
    summaries = re.findall(
        r"^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;",
        log, re.M)
    assert summaries == [("FAILED" if expected_failed else "ok",
                          str(expected_passed), str(expected_failed), "0")]
    starts = list(re.finditer(r"^test (\S+) \.\.\. ", log, re.M))
    assert sorted(item[1] for item in starts) == sorted(names)
    counts = {"ok": 0, "FAILED": 0}
    failures = []
    for index, item in enumerate(starts):
        end = starts[index + 1].start() if index + 1 < len(starts) else log.index("\n\nfailures:") if expected_failed else log.rindex("test result:")
        verdict = re.search(r"(?:^|\s)(ok|FAILED)$", log[item.end():end].strip())
        assert verdict, item[1]
        counts[verdict[1]] += 1
        if verdict[1] == "FAILED":
            failures.append(item[1])
    assert counts == {"ok": expected_passed, "FAILED": expected_failed}
    return failures


results = []
for tag, profile, passed, failed in [
    ("source197", "gate", 30, 2),
    ("source197-sibling", "gate", 32, 0),
    ("source197-sibling", "release", 32, 0),
]:
    stem = tag + "-" + profile + "-selected"
    command = read(stem + "-command.json")
    names = command["selected_inventory"]
    result = read(stem + "-result.json")
    assert result["exit_code"] == (101 if failed else 0)
    assert result["source_unchanged"]
    log = (p / (stem + ".log")).read_text()
    failures = audit_log(names, log, passed, failed)
    assert sha(Path(command["command"][0]).read_bytes()) == command["binary_sha256"]
    for required in ["threads_retain_lexical_caller_roots_across_separate_callee_environments",
                     "suspended_bytecode_retains_operand_and_unwind_roots"]:
        assert any(name.endswith("::" + required) for name in names)
    results.append({"source": tag, "profile": profile, "raw_passed": passed,
                    "raw_failed": failed, "raw_ignored": 0,
                    "inventory_and_binary_verified": True, "failures": failures})

fixtures = read("source197-sibling-selected-validation-result.json")["steps"][-1]["script"][3:]
assert len(fixtures) == len(set(fixtures)) == 8
for name in fixtures:
    comparison = read("source197-sibling-ordinary-" + name + "-comparison.json")
    assert comparison["passed"] and comparison["exact_match"]
    outputs = []
    for editor in ["gnu", "emaxx"]:
        stem = "source197-sibling-ordinary-" + name + "-" + editor
        outcome = read(stem + ".result.json")
        command = read(stem + ".command.json")
        assert outcome == comparison["outcomes"][editor]
        assert outcome["exit_code"] == 0 and not outcome["timed_out"]
        assert outcome["source_unchanged"] and outcome["inputs_unchanged"]
        assert outcome["expected_output"] is not False
        stdout = (p / (stem + ".stdout")).read_bytes()
        stderr = (p / (stem + ".stderr")).read_bytes()
        assert sha(stdout) == outcome["stdout_sha256"]
        assert stderr == b"" and outcome["stderr_hex"] == ""
        assert all(sha(Path(f).read_bytes()) == h for f, h in command["inputs"].items())
        outputs.append(stdout)
    assert outputs[0] == outputs[1]


original = read("source197-gate-selected-command.json")
replay = read("source197-sibling-gate-selected-command.json")
assert {k: v for k, v in original.items() if k != "qualification"} == {k: v for k, v in replay.items() if k != "qualification"}
assert read("source197-sibling-gate-selected-result.json")["binary_unchanged"]
assert read("source197-sibling-selected-validation-result.json")["passed"]
assert results[0]["failures"] == read("source197-sibling-path-diagnosis.json")["original_run"]["gate_failed"]
root = Path(replay["working_directory"])
assert all(sha((root / name).read_bytes()) == digest for name, digest in read("source197-manifest.json").items())

# Challenge the raw-inventory auditor itself without changing any receipt.
names = ["alpha", "beta"]
good = "test alpha ... ok\ntest beta ... ok\ntest result: ok. 2 passed; 0 failed; 0 ignored;\n"
audit_log(names, good, 2, 0)
negative_controls = {
    "missing_test": good.replace("test beta ... ok\n", ""),
    "duplicate_test": good.replace("test beta ...", "test alpha ..."),
    "failed_verdict_with_green_summary": good.replace("beta ... ok", "beta ... FAILED"),
    "false_count": good.replace("2 passed", "3 passed"),
    "absent_summary": good[:good.index("test result:")],
}
rejected = []
for label, mutated in negative_controls.items():
    try:
        audit_log(names, mutated, 2, 0)
    except AssertionError:
        rejected.append(label)
    else:
        raise AssertionError("Accepted corrupt evidence: " + label)
with (p / "source197-sibling-selected-evidence-audit.json").open("x") as f:
    json.dump({"rust": results, "ordinary_source197-sibling": fixtures,
               "negative_controls_rejected": rejected,
               "qualification": "Audits selected raw evidence only. Earlier failures remain failures; full new-source compatibility and performance remain unproven."}, f, indent=2)
print("Verified the failed original and two passing selected Rust inventories, eight ordinary comparisons, and five corrupt-log controls.")
