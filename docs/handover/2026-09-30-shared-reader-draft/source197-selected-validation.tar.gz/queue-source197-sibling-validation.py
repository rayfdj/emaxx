from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

p = Path(__file__).parent.resolve()
root = p.parent / "recovered-2026-09-30/macro-saved-state/emaxx"
tag = "source197-sibling"
manifest = json.loads((p / "source197-manifest.json").read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
unchanged = lambda: all(sha(root / name) == digest for name, digest in manifest.items())
original = json.loads((p / "source197-gate-selected-command.json").read_text())
binary = Path(original["command"][0])
assert unchanged() and sha(binary) == original["binary_sha256"]
assert (root.parent / "emacs").resolve() == (p.parent / "recovered-2026-09-30/emacs").resolve()

record = {**original,
          "qualification": "Identical source197 gate executable, inventory and environment; only the missing ../emacs fixture symlink is restored. The original 30-pass/2-failure run stays failed."}
with (p / (tag + "-gate-selected-command.json")).open("x") as stream:
    json.dump(record, stream, indent=2)
start = time.monotonic()
with (p / (tag + "-gate-selected.log")).open("x") as log:
    completed = subprocess.run(original["command"], cwd=root,
                               env={**os.environ, **original["environment_override"]},
                               stdout=log, stderr=subprocess.STDOUT, timeout=3600)
result = {"exit_code": completed.returncode, "elapsed_seconds": time.monotonic() - start,
          "source_unchanged": unchanged(), "binary_unchanged": sha(binary) == original["binary_sha256"]}
with (p / (tag + "-gate-selected-result.json")).open("x") as stream:
    json.dump(result, stream, indent=2)
results = [{"script": ["identical-gate-replay"], **result}]
steps = [["test-reader197.py", "197-sibling", "release"],
         ["build-reader197.py", "197-sibling"],
         ["compare-recovered-continuation-fixtures.py", tag, str(root),
          "input-decode-macro-shared", "input-decode-macro-live-array",
          "input-decode-macro-raw-array", "input-decode-macro-nested-roots",
          "input-decode-macro-read-order", "input-decode-macro-reclamation",
          "input-decode-minibuffer-shared", "input-decode-minibuffer-queue"]]
if completed.returncode == 0 and result["source_unchanged"] and result["binary_unchanged"]:
    for args in steps:
        assert unchanged()
        run = subprocess.run([sys.executable, str(p / args[0]), *args[1:]])
        results.append({"script": args, "exit_code": run.returncode, "source_unchanged": unchanged()})
        if run.returncode or not unchanged():
            break
passed = len(results) == 4 and all(item["exit_code"] == 0 and item["source_unchanged"] for item in results)
with (p / (tag + "-selected-validation-result.json")).open("x") as stream:
    json.dump({"steps": results, "passed": passed, "all_completed": len(results) == 4,
               "source_unchanged": unchanged(), "completed_unix": time.time(),
               "qualification": "Source197 selected validation after restoring the GNU sibling fixture path. No full-source, physical allocation or performance claim."}, stream, indent=2)
raise SystemExit(0 if passed else 1)
