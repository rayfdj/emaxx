from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/macro-reader/emaxx'
gnu = p.parent / 'recovered-2026-09-30/emacs/src/emacs'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
manifest = json.loads((p / 'source196-fresh-manifest.json').read_text())
unchanged = lambda: all(sha(root / name) == digest for name, digest in manifest.items())
assert unchanged()
original = json.loads((p / 'source196-fresh-gate-selected-command.json').read_text())
binary = p / 'source196-fresh-full-gate-libtest'
assert sha(binary) == original['binary_sha256']

def run_case(stem, command, cwd, overrides, inputs, timeout=120):
    record = {'command': command, 'working_directory': str(cwd),
              'environment_override': overrides, 'inputs': inputs,
              'timeout_seconds': timeout, 'source_manifest': 'source196-fresh-manifest.json'}
    with (p / (stem + '-command.json')).open('x') as stream:
        json.dump(record, stream, indent=2)
    start = time.monotonic()
    try:
        run = subprocess.run(command, cwd=cwd, env={**os.environ, **overrides},
                             stdin=subprocess.DEVNULL, capture_output=True, timeout=timeout)
        code, stdout, stderr, timed_out = run.returncode, run.stdout, run.stderr, False
    except subprocess.TimeoutExpired as error:
        code, stdout, stderr, timed_out = None, error.stdout or b'', error.stderr or b'', True
    for suffix, content in [('stdout', stdout), ('stderr', stderr)]:
        with (p / (stem + '.' + suffix)).open('xb') as stream:
            stream.write(content)
    result = {'exit_code': code, 'timed_out': timed_out,
              'elapsed_seconds': time.monotonic() - start,
              'stdout_sha256': hashlib.sha256(stdout).hexdigest(),
              'stderr_sha256': hashlib.sha256(stderr).hexdigest(),
              'source_unchanged': unchanged(),
              'inputs_unchanged': all(sha(Path(f)) == digest for f, digest in inputs.items())}
    with (p / (stem + '-result.json')).open('x') as stream:
        json.dump(result, stream, indent=2)
    print(stem, code, stdout[-200:], stderr[-200:], flush=True)
    return result

name = 'lisp::primitives::tests::native_keyboard_input_family_matches_gnu_kboard_contracts'
run_case('source196-keyboard-contract-exact',
         [str(binary), name, '--exact', '--nocapture', '--test-threads=1'], root,
         original['environment_override'], {str(binary): sha(binary)})

source = (root / 'src/lisp/primitives/tests.rs').read_text()
section = source.split('fn native_keyboard_input_family_matches_gnu_kboard_contracts() {', 1)[1].split('for (program, expected)', 1)[0]
contracts = re.findall(r'\(\s*r#"(.*?)"#,\s*(?:r#"(.*?)"#|"((?:[^"\\]|\\.)*)")\s*,?\s*\)', section, re.S)
assert len(contracts) == 10, len(contracts)
comparisons = []
for index, (program, raw_expected, escaped_expected) in enumerate(contracts, 1):
    expected = raw_expected or json.loads('"' + escaped_expected + '"')
    outcomes = {}
    for editor, executable in [('gnu', gnu), ('emaxx', root / 'target/frame-validation/release/emaxx')]:
        stem = 'source196-keyboard-contract-%02d-%s' % (index, editor)
        inputs = {str(f): sha(f) for f in [executable, executable.with_suffix('.pdmp'), root / 'src/lisp/primitives/tests.rs']}
        outcomes[editor] = run_case(stem, [str(executable), '-Q', '--batch', '--eval', '(prin1 ' + program + ')'],
                                   p, {'EMAXX_GC_VERIFY': '1'}, inputs)
        outcomes[editor]['matches_expected'] = (p / (stem + '.stdout')).read_bytes() == expected.encode()
    comparisons.append({'index': index, 'program': program, 'expected': expected, 'outcomes': outcomes})
with (p / 'source196-keyboard-contract-diagnosis.json').open('x') as stream:
    json.dump({'comparisons': comparisons, 'qualification': 'Unchanged original contracts; ordinary source/ABI-matched GNU, not frozen Darwin. Exact Rust replay retains the failed full run.'}, stream, indent=2)
