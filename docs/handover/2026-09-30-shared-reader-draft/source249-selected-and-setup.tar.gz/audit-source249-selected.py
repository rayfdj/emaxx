from pathlib import Path
import ast, hashlib, json, subprocess, sys

p = Path(__file__).parent.resolve()
candidate = p.parent / 'recovered-2026-09-30/coding-post-read/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p / n).read_text())
state = read('source249-validation-result.json')
assert state['status'] == 'selected validation finished'
assert len(state['results']) == len(state['stages']) == 8
assert all(r['exit_code']==0 and r['source_unchanged'] and r['helper_unchanged'] for r in state['results'])
assert all(sha(Path(n)) == h for n, h in state['helper_sha256'].items())
manifest = read('source249-manifest.json')
assert len(manifest)==476 and all(sha(candidate / n)==h for n,h in manifest.items())
node = next(n for n in ast.parse((p / 'audit-source238-release.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'audit_log')
import re
exec(compile(ast.Module(body=[node], type_ignores=[]), '<raw-verdict-auditor>', 'exec'))
new_names = {
    'lisp::primitives::tests::coding_post_read_conversion_receives_character_counts',
    'lisp::primitives::tests::coding_post_read_ascii_shortcut_preserves_identity_and_hook_order',
}
profiles = {}
for profile in ['gate', 'release']:
    subprocess.run([sys.executable, '-B', str(p / 'audit-source249-focused.py'), profile], check=True)
    focused = read('source249-' + profile + '-focused-audit.json')
    assert focused['passed']==172 and len(focused['ignored'])==2
    command = read('source249-' + profile + '-broad-command.json')
    result = read('source249-' + profile + '-broad-result.json')
    assert result['exit_code']==0 and result['source_unchanged']
    names = command['selected_inventory']
    previous = read('source248-' + profile + '-broad-command.json')['selected_inventory']
    assert len(names)==len(set(names))==955
    assert set(previous)<=set(names) and set(names)-set(previous)==new_names
    assert sha(p / ('source249-' + profile + '-libtest'))==command['binary_sha256']
    audit_log(names, (p / ('source249-' + profile + '-broad.log')).read_text(), [])
    profiles[profile]=dict(focused_passes=172, existing_ignores=focused['ignored'], affected_passes=955)
fixtures=state['stages'][4][3:]
assert len(fixtures)==15 and len(set(fixtures))==15
ordinary={}
for fixture in fixtures:
    result=read('source249-ordinary-' + fixture + '-comparison.json')
    assert result['passed'] and result['exact_match']
    expected=(candidate / ('tests/fixtures/' + fixture + '.expected')).read_bytes().rstrip(b'\n')
    for editor in ['gnu','emaxx']:
        prefix='source249-ordinary-' + fixture + '-' + editor
        command=read(prefix + '.command.json')
        row=read(prefix + '.result.json')
        assert row['exit_code']==0 and not row['timed_out']
        assert row['source_unchanged'] and row['inputs_unchanged'] and row['expected_output']
        assert all(sha(Path(n))==h for n,h in command['inputs'].items())
        assert sha(p / (prefix + '.stdout'))==row['stdout_sha256']
        assert (p / (prefix + '.stdout')).read_bytes()==expected
        assert (p / (prefix + '.stderr')).read_bytes()==b'' and row['stderr_hex']==''
    ordinary[fixture]=hashlib.sha256(expected).hexdigest()
for fixture, tag in [('coding-post-read-character-count','post-read-count'),('coding-post-read-fast-path','post-read-fast')]:
    assert (candidate / ('tests/fixtures/' + fixture + '.el')).read_bytes()==(p / (fixture + '.el')).read_bytes()
    assert (candidate / ('tests/fixtures/' + fixture + '.expected')).read_bytes()==(p / ('source248-' + tag + '-gnu.stdout')).read_bytes()
artifacts=read('source249-ordinary-artifacts.json')
assert len(artifacts)==2
for name, info in artifacts.items():
    assert sha(Path(name))==sha(Path(info['immutable_copy']))==info['sha256']
for stage in ['ordinary-build','ordinary-image']:
    row=read('source249-' + stage + '-result.json')
    assert row['exit_code']==0 and row['source_unchanged']
    assert not re.search(r'^warning(?:\[.*\])?:', (p / ('source249-' + stage + '.log')).read_text(), re.M)
record=dict(status='passed', inputs_verified=476, profiles=profiles,
            ordinary_comparisons=len(ordinary), ordinary_expected_sha256=ordinary,
            unchanged_negative_fixtures=sorted(new_names), ordinary_artifacts=artifacts,
            qualification='Both profiles preserve all preceding selected and affected controls. All fifteen same-input ordinary comparisons match GNU; the original negative fixtures and GNU outputs are unchanged. This is selected validation only. Full platform/frozen/terminal, pinned Darwin, general translations, architecture and performance requirements remain separate and open.')
with (p / 'source249-selected-audit.json').open('x') as f:
    json.dump(record,f,indent=2)
print(json.dumps({k:record[k] for k in ['status','inputs_verified','profiles','ordinary_comparisons']},indent=2))
