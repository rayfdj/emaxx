from pathlib import Path
import ast, hashlib, json, re, shutil, sys

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/coding-post-read/emaxx'
profile = sys.argv[1] if len(sys.argv) > 1 else 'gate'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'audit-source238-release.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'audit_log')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<raw-verdict-auditor>', 'exec'))
manifest = read('source249-manifest.json')
assert len(manifest) == 476 and all(sha(root / name) == digest for name, digest in manifest.items())
command = read('source249-' + profile + '-controls-command.json')
result = read('source249-' + profile + '-controls-result.json')
assert result['exit_code'] == 0 and result['source_unchanged']
names = command['selected_inventory']
previous = read('source248-' + profile + '-controls-command.json')['selected_inventory']
assert len(names) == len(set(names)) == 174
assert set(previous) <= set(names)
assert set(names) - set(previous) == {'lisp::primitives::tests::coding_post_read_conversion_receives_character_counts', 'lisp::primitives::tests::coding_post_read_ascii_shortcut_preserves_identity_and_hook_order'}
ignored = ['tty::tty_differential_end_to_end', 'tty::tty_smoke_end_to_end']
audit_log(names, (p / ('source249-' + profile + '-controls.log')).read_text(), ignored)
for stage in ['check', 'fmt', 'clippy', 'diff', profile + '-build']:
    stage_result = read('source249-' + stage + '-result.json')
    assert stage_result['exit_code'] == 0 and stage_result['source_unchanged']
    raw = (p / ('source249-' + stage + '.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
    for line in raw.splitlines():
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        assert row.get('message', {}).get('level') not in ['warning', 'error']
binary = p / ('source249-' + profile + '-libtest')
assert sha(binary) == command['binary_sha256']
images = sorted((p / 'fixture-images-source249').glob('loadup-' + sha(binary)[:8] + '-*.pdmp'))
assert len(images) == 1
retained = p / ('source249-' + profile + '-focused-retained-inputs')
retained.mkdir()
files = []
for source in [binary, *images]:
    destination = retained / source.name
    digest = sha(source)
    shutil.copy2(source, destination)
    assert sha(source) == sha(destination) == digest
    files.append(dict(original=str(source), retained=str(destination), sha256=digest, bytes=destination.stat().st_size))
record = dict(status='passed', profile=profile, passed=172, failed=0, ignored=ignored,
              names=names, inputs_verified=476, retained_files=files, strict_checks='zero-warning pass',
              qualification='Every source248 selected control remains present. The two new exact negative GNU fixtures cover post-read character count, early ASCII return, NOCOPY identity, copied properties and continued hooks for region/buffer conversions. Prior GNU results and expected bytes are unchanged. Full platform/frozen/terminal, pinned Darwin and performance certification remain separate.')
with (p / ('source249-' + profile + '-focused-audit.json')).open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps({key: record[key] for key in ['status', 'profile', 'passed', 'ignored', 'strict_checks']}, indent=2))
