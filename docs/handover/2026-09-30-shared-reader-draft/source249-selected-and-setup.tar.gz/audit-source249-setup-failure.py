from pathlib import Path
import hashlib, json, re, shutil

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/coding-post-read/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p/n).read_text())
manifest=read('source249-manifest.json')
assert len(manifest)==476 and all(sha(root/n)==h for n,h in manifest.items())
command=read('source249-gate-controls-command.json')
result=read('source249-gate-controls-result.json')
assert result['exit_code']==101 and result['source_unchanged']
assert not (root.parent/'emacs').exists() and not (root.parent/'emacs').is_symlink()
text=(p/'source249-gate-controls.log').read_text()
starts=list(re.finditer(r'^test (\S+) \.\.\.',text,re.M))
assert [m[1] for m in starts]==command['selected_inventory']
assert len(starts)==174
passed,failed,ignored=[],[],[]
for index,match in enumerate(starts):
    stop=starts[index+1].start() if index+1<len(starts) else text.index('\nfailures:',match.end())
    body=text[match.end():stop].strip()
    if body.startswith('ignored,'):
        ignored.append(match[1])
    elif re.search(r'(?:^|\n)FAILED\s*$',body):
        assert 'src/test_support.rs:215:' in body
        assert 'Cannot open load file: No such file or directory, emacs-lisp/debug-early' in body
        failed.append(match[1])
    else:
        assert re.search(r'(?:^|\n)ok\s*$',body), (match[1],body[-400:])
        passed.append(match[1])
assert len(passed)==162 and len(failed)==10
assert ignored==['tty::tty_differential_end_to_end','tty::tty_smoke_end_to_end']
assert {'lisp::primitives::tests::coding_post_read_conversion_receives_character_counts',
        'lisp::primitives::tests::coding_post_read_ascii_shortcut_preserves_identity_and_hook_order'}<=set(passed)
binary=p/'source249-gate-libtest'
assert sha(binary)==command['binary_sha256']
images=sorted((p/'fixture-images-source249').glob('loadup-'+sha(binary)[:8]+'-*.pdmp'))
assert len(images)==1
retained=p/'source249-setup-failure-retained'
retained.mkdir()
files=[]
for source in [binary,*images]:
    destination=retained/source.name
    shutil.copy2(source,destination)
    assert sha(source)==sha(destination)
    files.append(dict(original=str(source),retained=str(destination),sha256=sha(destination),bytes=destination.stat().st_size))
state=read('source249-validation-result.json')
assert len(state['results'])==3 and state['results'][-1]['exit_code']==101
record=dict(status='failed selected run',inputs_verified=476,passed=len(passed),failed=len(failed),
            ignored=ignored,failed_names=failed,passed_names=passed,retained_files=files,
            raw_log_sha256=sha(p/'source249-gate-controls.log'),missing_path=str(root.parent/'emacs'),
            unstarted_stages=state['stages'][3:],
            qualification='All ten failures stop in the unchanged early-Lisp fixture while loading emacs-lisp/debug-early. Its CARGO_MANIFEST_DIR/../emacs path is absent in this new checkout; the preceding checkout has the GNU sibling link. Both new GNU-backed hook tests pass. This preserves the failed result before repairing checkout setup; only an unchanged executable/inventory replay can validate the correction. No source, fixture, expectation, selector or timeout changes.')
with (p/'source249-setup-failure-audit.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps({k:record[k] for k in ['status','inputs_verified','passed','failed','ignored','missing_path']},indent=2))
