from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p=Path(__file__).parent.resolve()
root=p.parents[2]
out=root/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda name:json.loads((p/name).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body
          if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
audit=read('source249-selected-audit.json')
assert audit['status']=='passed' and audit['inputs_verified']==476 and audit['ordinary_comparisons']==15
assert audit['prior_setup_failure_preserved']
for profile in ['gate','release']:
    assert audit['profiles'][profile]['focused_passes']==172 and audit['profiles'][profile]['affected_passes']==955
state=read('source249-setup-continuation-result.json')
assert len(state['results'])==5 and all(r['exit_code']==0 for r in state['results'])
allowed={'.json','.log','.txt','.py','.patch','.stdout','.stderr','.el','.expected'}
helpers={
    'queue-source249-validation.py','replay-source249-setup-and-continue.py',
    'check-source249.py','static-source249.py','test-source249-controls.py','test-source249-broad.py','build-source249.py',
    'compare-source230-fixtures.py','audit-source238-release.py','audit-source249-focused.py','audit-source249-selected.py',
    'audit-source249-focused-after-setup.py','audit-source249-selected-after-setup.py',
    'audit-source249-setup-failure.py','audit-source249-setup-failure-paths.py','audit-source249-c-reference.py',
    'freeze-source249.py','audit-source249-patches.py','package-source196-failure-and197-results.py',Path(__file__).name,
}
files={f.name:f for f in p.iterdir() if f.is_file() and f.suffix in allowed and
       (f.name.startswith('source249-') or f.name in helpers)}
assert helpers<=files.keys()
assert 'source249-gate-controls.log' in files and 'source249-gate-controls-setup-replay.log' in files
package('source249-selected-and-setup',files,
        dict(selected=audit,original_setup_failure=read('source249-setup-failure-audit.json'),
             qualification='Strict zero-warning checks and both selected profiles pass, preserving every previous control and adding two GNU-backed post-read contracts. The original selected failure remains failed: ten fixtures required the missing GNU sibling path. After only its restoration, the same gate executable and all 174 selectors pass. All fifteen ordinary comparisons use unchanged GNU expected bytes. Binaries/images are retained locally by hash. Complete platform/frozen/terminal gates, rebuilt Darwin oracle certification, broader coding, common representation, accounting, ownership and the locked performance goal remain separate.'))
