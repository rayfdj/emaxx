from pathlib import Path
import hashlib, json, subprocess

p = Path(__file__).parent.resolve()
root = p.parents[2]
candidate = p.parent / 'recovered-2026-09-30/coding-post-read/emaxx'
gnu = p.parent / 'recovered-2026-09-30/emacs'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read('source249-manifest.json')
assert len(manifest) == 476 and all(sha(candidate / n) == h for n, h in manifest.items())
assert all(sha(root / n) == h for n, h in read('source248-manifest.json').items())
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=gnu, text=True).strip()
assert revision == '636f166cfc86aa90d63f592fd99f3fdd9ef95ebd'
source = gnu / 'src/coding.c'
assert source.read_bytes() == subprocess.check_output(['git', 'show', revision + ':src/coding.c'], cwd=gnu)
controls = []
for fixture, tag in [('coding-post-read-character-count', 'post-read-count'),
                     ('coding-post-read-fast-path', 'post-read-fast')]:
    before = read('source248-' + tag + '-negative-audit.json')
    actual = candidate / 'tests/fixtures' / (fixture + '.el')
    expected = actual.with_suffix('.expected')
    assert before['matches'] is False and sha(actual) == before['fixture_sha256']
    gnu_output = (p / ('source248-' + tag + '-gnu.stdout')).read_bytes()
    emaxx_output = (p / ('source248-' + tag + '-emaxx.stdout')).read_bytes()
    assert expected.read_bytes() == gnu_output and emaxx_output != gnu_output
    history = read('coding-' + tag + '-history-original-location-audit.json')
    assert history['fixture_sha256'] == sha(actual)
    for row in history['records']:
        assert row['exit_code'] == 0 and row['inputs_unchanged']
        assert row['matches_source248'] and not row['matches_gnu']
        assert sha(p / (row['source'] + '-' + tag + '-original-location.stdout')) == row['stdout_sha256']
    controls.append(dict(fixture=fixture, fixture_sha256=sha(actual),
                         gnu_output_sha256=sha(expected), source248_output_sha256=hashlib.sha256(emaxx_output).hexdigest(),
                         reproduced_unchanged_on=[row['source'] for row in history['records']]))
record = dict(status='GNU source and unchanged negative controls verified',
              gnu_revision=revision, coding_c_sha256=sha(source), inputs_verified=476,
              root_runtime='unchanged source248', controls=controls,
              mapping=[
                  dict(gnu='coding.c:decode_coding_object:8193-8205',
                       rust='coding.rs:run_coding_conversion',
                       change='Pass the decoded temporary-buffer character count as produced_char, instead of Rust string bytes.'),
                  dict(gnu='coding.c:code_convert_string:9624-9644',
                       rust='coding.rs:decode_coding_text / dispatch/search_coding.rs:decode-coding-string',
                       change='Return from the ASCII string fast path before hooks; preserve NOCOPY object identity or produce a fresh unpropertized multibyte string. Region and buffer conversions still execute their hooks.')],
              qualification='Both exact negative fixtures also fail identically on retained source174/main and source207. This identifies these particular defects as pre-existing, not a denial of documented migration regressions. No new representation, cache, registry, changed upstream expectation or performance claim. General translation tables, broader hook/destination semantics, final pinned Darwin validation and the full architecture/performance goal remain open. Source249 runtime validation is queued separately.')
with (p / 'source249-c-reference-review.json').open('x') as f:
    json.dump(record, f, indent=2)
print(json.dumps({k: record[k] for k in ['status', 'gnu_revision', 'coding_c_sha256', 'inputs_verified', 'root_runtime']}, indent=2))
