from pathlib import Path
import hashlib, json, os, subprocess, sys, time

p = Path(__file__).parent.resolve()
root = p.parents[2]
candidate = p.parent / 'recovered-2026-09-30/coding-post-read/emaxx'
previous = p.parent / 'recovered-2026-09-30/coding-property-order/emaxx'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
manifest = json.loads((p / 'source249-manifest.json').read_text())
prior_manifest = json.loads((p / 'source248-manifest.json').read_text())
unchanged = lambda: all(sha(candidate / n) == h for n, h in manifest.items())
assert len(manifest) == 476 and unchanged()
assert all(sha(previous / n) == h == sha(root / n) for n, h in prior_manifest.items())
fixtures = [
    'coding-post-read-character-count', 'coding-post-read-fast-path',
    'overriding-property-identity', 'coding-candidate-symbol-properties',
    'coding-candidate-translation', 'coding-candidate-character-identities',
    'coding-candidate-inventory', 'file-write-coding-selection',
    'new-file-coding-lifecycle', 'file-write-order',
    'canonical-coding-character-storage', 'canonical-coding-identity-storage',
    'canonical-coding-conversion-storage', 'copied-canonical-string-storage',
    'coding-error-object-storage',
]
stages = [
    ['check-source249.py', '249'], ['static-source249.py', '249'],
    ['test-source249-controls.py', '249', 'gate'],
    ['build-source249.py', '249'],
    ['compare-source230-fixtures.py', 'source249', str(candidate), *fixtures],
    ['test-source249-broad.py', '249', 'gate'],
    ['test-source249-controls.py', '249', 'release'],
    ['test-source249-broad.py', '249', 'release'],
]
helpers = {str(p / stage[0]): sha(p / stage[0]) for stage in stages}
state = dict(status='waiting for source248 full terminal retry to exit',
             prior_pid=14540, source_manifest='source249-manifest.json',
             helper_sha256=helpers, stages=stages, goal_complete=False)
results = []
def save_state():
    (p / 'source249-validation-queue-state.json').write_text(json.dumps(state, indent=2) + '\n')
save_state()
try:
    while True:
        process = subprocess.run(['ps', '-p', '14540', '-o', 'command='], capture_output=True, text=True)
        if process.returncode == 1 and not process.stdout.strip():
            break
        if process.returncode or 'run-source248-full-tty-retry.py' not in process.stdout:
            raise RuntimeError('terminal supervisor state is ambiguous: ' + process.stdout + process.stderr)
        time.sleep(5)
    terminal = json.loads((p / 'source248-full-ttydiff-retry-result.json').read_text())
    state['prior_terminal_result'] = terminal
    assert terminal['source_unchanged'] and terminal['inputs_unchanged']
    assert unchanged()
    assert all(sha(previous / n) == h for n, h in prior_manifest.items())
    state['status'] = 'cloning completed source248 cache'
    save_state()
    (candidate / 'target').mkdir(exist_ok=True)
    assert not (candidate / 'target/frame-validation').exists()
    subprocess.run(['cp', '-cR', str(previous / 'target/frame-validation'),
                    str(candidate / 'target/frame-validation')], check=True)
    for name, *args in stages:
        helper = p / name
        assert sha(helper) == helpers[str(helper)] and unchanged()
        command = [sys.executable, '-B', str(helper), *args]
        state.update(status='running selected validation', current_command=command)
        save_state()
        start = time.monotonic()
        result = subprocess.run(command, cwd=candidate, stdin=subprocess.DEVNULL,
                                env={**os.environ, 'PYTHONUNBUFFERED': '1', 'PYTHONDONTWRITEBYTECODE': '1'})
        results.append(dict(command=command, exit_code=result.returncode,
                            elapsed_seconds=time.monotonic()-start,
                            source_unchanged=unchanged(), helper_unchanged=sha(helper)==helpers[str(helper)]))
        if result.returncode or not results[-1]['source_unchanged'] or not results[-1]['helper_unchanged']:
            break
    state.update(status='selected validation finished', results=results)
except Exception as error:
    state.update(status='queue or validation failed', error=repr(error), results=results)
finally:
    save_state()
    with (p / 'source249-validation-result.json').open('x') as f:
        json.dump(state, f, indent=2)
raise SystemExit(0 if len(results)==len(stages) and all(
    r['exit_code']==0 and r['source_unchanged'] and r['helper_unchanged'] for r in results
) else 1)
