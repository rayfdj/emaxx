from pathlib import Path
import hashlib, json, os, subprocess, sys, time

p = Path(__file__).parent.resolve()
root = p.parents[2]
candidate = p.parent / 'recovered-2026-09-30/coding-post-read/emaxx'
gnu = p.parent / 'recovered-2026-09-30/emacs'
sibling = candidate.parent / 'emacs'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
manifest = json.loads((p / 'source249-manifest.json').read_text())
unchanged = lambda: all(sha(candidate/n)==h for n,h in manifest.items())
failure = json.loads((p / 'source249-setup-failure-audit.json').read_text())
prior = json.loads((p / 'source249-gate-controls-command.json').read_text())
stages = failure['unstarted_stages']
helpers = {str(p / stage[0]): sha(p / stage[0]) for stage in stages}
state = dict(status='preparing unchanged selected replay', source_manifest='source249-manifest.json',
             prior_failure='source249-setup-failure-audit.json', helper_sha256=helpers, stages=stages,
             goal_complete=False)
results = []
def save(name, data):
    with (p / ('source249-' + name + '.json')).open('x') as f:
        json.dump(data, f, indent=2)
        f.write('\n')
def save_state():
    (p / 'source249-setup-continuation-state.json').write_text(json.dumps(state, indent=2)+'\n')
assert len(manifest)==476 and unchanged()
assert failure['passed']==162 and failure['failed']==10
assert len(prior['selected_inventory'])==174
assert prior['command'][1:-3]==prior['selected_inventory']
assert sha(Path(prior['command'][0]))==prior['binary_sha256']
assert not sibling.exists() and not sibling.is_symlink()
assert gnu.is_dir()
for f in failure['retained_files']:
    assert sha(Path(f['original']))==sha(Path(f['retained']))==f['sha256']
setup = dict(missing_sibling=str(sibling), absent_before=True, link_target=str(gnu),
             retained_failure_files=failure['retained_files'], source_unchanged_before=True)
sibling.symlink_to(gnu, target_is_directory=True)
assert sibling.resolve(strict=True)==gnu.resolve(strict=True)
setup.update(link_created=True, source_unchanged_after=unchanged())
save('setup-correction', setup)
save('gate-controls-setup-replay-command', prior)
save_state()
try:
    state['status']='running unchanged selected replay'
    save_state()
    start=time.monotonic()
    with (p / 'source249-gate-controls-setup-replay.log').open('x') as log:
        result=subprocess.run(prior['command'], cwd=prior['working_directory'],
                              env={**os.environ, **prior['environment_override']}, stdin=subprocess.DEVNULL,
                              stdout=log, stderr=subprocess.STDOUT, timeout=3600)
    replay=dict(exit_code=result.returncode, elapsed_seconds=time.monotonic()-start,
                source_unchanged=unchanged(), binary_unchanged=sha(Path(prior['command'][0]))==prior['binary_sha256'],
                command_unchanged=json.loads((p / 'source249-gate-controls-command.json').read_text())==prior)
    save('gate-controls-setup-replay-result', replay)
    state['replay_result']=replay
    assert replay['exit_code']==0 and replay['source_unchanged'] and replay['binary_unchanged'] and replay['command_unchanged']
    for name, *args in stages:
        helper = p / name
        assert unchanged() and sha(helper)==helpers[str(helper)]
        command=[sys.executable, '-B', str(helper), *args]
        state.update(status='continuing unexecuted selected stages', current_command=command)
        save_state()
        start=time.monotonic()
        result=subprocess.run(command, cwd=candidate, stdin=subprocess.DEVNULL,
                              env={**os.environ, 'PYTHONUNBUFFERED':'1','PYTHONDONTWRITEBYTECODE':'1'})
        results.append(dict(command=command, exit_code=result.returncode, elapsed_seconds=time.monotonic()-start,
                            source_unchanged=unchanged(), helper_unchanged=sha(helper)==helpers[str(helper)]))
        if result.returncode or not results[-1]['source_unchanged'] or not results[-1]['helper_unchanged']:
            break
    state.update(status='selected continuation finished', results=results)
except Exception as error:
    state.update(status='replay or continuation failed', error=repr(error), results=results)
finally:
    save_state()
    save('setup-continuation-result', state)
raise SystemExit(0 if len(results)==len(stages) and all(
    r['exit_code']==0 and r['source_unchanged'] and r['helper_unchanged'] for r in results) else 1)
