from pathlib import Path
import hashlib, json, re, subprocess

p = Path(__file__).parent.resolve()
root = p.parents[2]
head = json.loads((p / 'source243-checkpoint-commit.json').read_text())['commit']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == head
manifest = json.loads((p / 'source243-manifest.json').read_text())
assert len(manifest) == 462
assert all(hashlib.sha256((root / name).read_bytes()).hexdigest() == digest for name, digest in manifest.items())
for label, validation in [('rust', 'rust'), ('frozen', 'frozen')]:
    command = ['gh', 'workflow', 'run', 'frozen-run.yml', '--repo', 'rayfdj/emaxx',
               '--ref', 'runtime-char-tables', '-f', 'validation=' + validation]
    result = subprocess.run(command, cwd=root, stdin=subprocess.DEVNULL, capture_output=True, text=True)
    with (p / ('source243-linux-' + label + '-dispatch.json')).open('x') as out:
        json.dump(dict(command=command, commit=head, exit_code=result.returncode,
                       stdout=result.stdout, stderr=result.stderr), out, indent=2)
    result.check_returncode()
    match = re.search(r'/actions/runs/(\d+)', result.stdout)
    assert match, result.stdout
    run_id = int(match.group(1))
    state = json.loads(subprocess.check_output(['gh', 'run', 'view', str(run_id), '--repo', 'rayfdj/emaxx',
                      '--json', 'status,conclusion,headSha,url'], cwd=root, text=True))
    assert state['headSha'] == head
    record = dict(run_id=run_id, state=state, source_commit=head, runtime_source='source243',
                  qualification='Complete existing Linux validation on the exact pushed 462-input checkpoint. Source238 earlier successes and failures remain separate evidence. No passing verdict is inferred from dispatch.')
    with (p / ('source243-linux-' + label + '-launch.json')).open('x') as out:
        json.dump(record, out, indent=2)
    print(json.dumps(record, indent=2), flush=True)
