from pathlib import Path
import hashlib, io, json, subprocess, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
sha = lambda data: hashlib.sha256(data).hexdigest()
def output(args):
    return subprocess.check_output(args, cwd=root, text=True).strip()
def save(name, data):
    with (p / name).open('x') as out:
        json.dump(data, out, indent=2)
assert output(['git', 'branch', '--show-current']) == 'runtime-char-tables'
assert output(['git', 'rev-parse', 'HEAD']) == '3060be47cdd76737ea1a4fbcb4b27736c92c984b'
assert not output(['git', 'diff', '--cached', '--name-only'])
manifest = json.loads((p / 'source243-manifest.json').read_text())
assert len(manifest) == 462 and all(sha((root / name).read_bytes()) == digest for name, digest in manifest.items())
for name, key, expected in [('source243-focused-audit.json', 'passed', 165),
                            ('source243-broad-audit.json', 'passed', 948),
                            ('source243-new-ordinary-audit.json', 'ordinary_processes_verified', 16),
                            ('source243-selected-terminal-audit.json', 'matching_comparisons', 41)]:
    assert json.loads((p / name).read_text())[key] == expected
paths = ['HANDOVER.md', 'docs/runtime-representation-progress.md',
         'docs/runtime-representation-correctness-recovery-draft.md']
for stem in ['source240-complete-macos', 'source243-file-coding-recovery']:
    prefix = 'docs/handover/2026-09-30-shared-reader-draft/' + stem
    paths += [prefix + '-manifest.json', prefix + '.tar.gz']
    record = json.loads((root / (prefix + '-manifest.json')).read_text())
    archive = root / (prefix + '.tar.gz')
    assert sha(archive.read_bytes()) == record['archive']['sha256']
    with tarfile.open(archive) as source:
        assert source.getnames() == [entry['path'] for entry in record['files']]
        for entry in record['files']:
            data = source.extractfile(entry['path']).read()
            assert sha(data) == entry['sha256'] and len(data) == entry['bytes']
changed = set(output(['git', 'diff', '--name-only', '--', *sorted(manifest)]).splitlines())
new = set(output(['git', 'ls-files', '--others', '--exclude-standard']).splitlines()) & manifest.keys()
expected_staged = set(paths) | changed | new
subprocess.run(['git', 'diff', '--check'], cwd=root, check=True)
subprocess.run(['git', 'add', '--', *paths, *sorted(manifest)], cwd=root, check=True)
assert set(output(['git', 'diff', '--cached', '--name-only']).splitlines()) == expected_staged
subprocess.run(['git', 'diff', '--cached', '--check'], cwd=root, check=True)
tree = output(['git', 'write-tree'])
data = subprocess.check_output(['git', 'archive', tree, '--', *sorted(manifest)], cwd=root)
with tarfile.open(fileobj=io.BytesIO(data)) as source:
    for name, digest in manifest.items():
        entry = source.getmember(name)
        assert sha(source.extractfile(entry).read()) == digest
        assert bool(entry.mode & 0o111) == bool((root / name).stat().st_mode & 0o111)
subprocess.run(['git', '-c', 'user.name=Ray', '-c', 'user.email=26018378+rayfdj@users.noreply.github.com',
                'commit', '-m', 'Preserve canonical coding and GNU file-save semantics'], cwd=root, check=True)
head = output(['git', 'rev-parse', 'HEAD'])
assert output(['git', 'rev-parse', 'HEAD^{tree}']) == tree
assert not output(['git', 'status', '--porcelain'])
save('source243-checkpoint-commit.json', dict(commit=head, inputs_verified=462, paths=sorted(expected_staged),
     focused_passed=165, affected_passed=948, new_ordinary_comparisons=8,
     file_lifecycle_scenarios=11, matching_terminal_comparisons=41, goal_complete=False))
command = ['git', 'push', 'origin', 'HEAD:refs/heads/runtime-char-tables']
result = subprocess.run(command, cwd=root, stdin=subprocess.DEVNULL, capture_output=True, text=True)
save('source243-checkpoint-push.json', dict(command=command, exit_code=result.returncode,
                                          stdout=result.stdout, stderr=result.stderr))
result.check_returncode()
remote = output(['git', 'ls-remote', '--heads', 'origin', 'refs/heads/runtime-char-tables', 'refs/heads/main'])
refs = {line.split()[1]: line.split()[0] for line in remote.splitlines()}
assert refs['refs/heads/runtime-char-tables'] == head
save('source243-checkpoint-remote.json', dict(commit=head, refs=refs, raw=remote))
print(json.dumps(dict(commit=head, status='source243 checkpoint pushed', refs=refs, goal_complete=False), indent=2))
