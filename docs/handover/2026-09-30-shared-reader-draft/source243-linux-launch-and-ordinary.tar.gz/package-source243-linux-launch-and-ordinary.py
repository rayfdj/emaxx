from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
out = p.parents[2] / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
read = lambda name: json.loads((p / name).read_text())
ordinary = read('source243-ordinary-audit.json')
new = read('source243-new-ordinary-audit.json')
assert len(ordinary['fixtures']) == 57 and len(new['fixtures']) == 8
assert len(set(ordinary['fixtures'] + new['fixtures'])) == 65
commit = read('source243-checkpoint-commit.json')['commit']
linux = {label: read('source243-linux-' + label + '-launch.json') for label in ['rust', 'frozen']}
assert all(row['source_commit'] == row['state']['headSha'] == commit for row in linux.values())
allowed = {'.json', '.log', '.txt', '.py', '.stdout', '.stderr'}
patterns = ['source243-ordinary-*', 'source243-new-ordinary-audit.json', 'source243-manifest.json',
            'source243-checkpoint-*', 'source243-linux-*', 'launch-source243-linux.py',
            'commit-source243-file-coding.py', 'run-source243-release-and-ordinary.py',
            'audit-source243-ordinary.py', 'audit-source243-new-ordinary.py',
            'compare-source230-fixtures.py', Path(__file__).name]
files = {str(file.relative_to(p)): file for pattern in patterns for file in p.glob(pattern)
         if file.is_file() and file.suffix in allowed}
package('source243-linux-launch-and-ordinary', files,
        dict(source_commit=commit, preceding_ordinary=ordinary, new_ordinary=new,
             total_distinct_ordinary_comparisons=65, linux_launches=linux,
             qualification='Exact pushed source243 runtime checkpoint. All 57 preceding ordinary comparisons and eight new comparisons pass; 65 distinct same-input comparisons in total. Linux Rust and full frozen jobs are dispatched on this commit, with no completion inferred. Complete local macOS/release/terminal validation remains active and its active logs are excluded. Earlier failed sources and the unresolved GNU census diagnosis remain preserved; main and the full goal are unchanged.'))
