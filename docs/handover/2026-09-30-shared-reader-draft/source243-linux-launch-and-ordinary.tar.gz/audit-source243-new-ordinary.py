from pathlib import Path
import copy, hashlib, json, re

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/file-coding/emaxx'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read('source243-manifest.json')
assert len(manifest) == 462 and all(sha(root / name) == digest for name, digest in manifest.items())
for stage in ['ordinary-build', 'ordinary-image']:
    result = read('source243-' + stage + '-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
    assert not re.search(r'^warning(?:\[.*\])?:', (p / ('source243-' + stage + '.log')).read_text(), re.M)
artifacts = read('source243-ordinary-artifacts.json')
for name, entry in artifacts.items():
    assert sha(Path(name)) == entry['sha256'] == sha(Path(entry['immutable_copy']))
fixtures = ['canonical-coding-character-storage', 'canonical-coding-identity-storage',
            'canonical-coding-conversion-storage', 'copied-canonical-string-storage',
            'file-write-coding-selection', 'new-file-coding-lifecycle', 'file-write-order',
            'coding-error-object-storage']
for fixture in fixtures:
    stem = 'source243-ordinary-' + fixture
    comparison = read(stem + '-comparison.json')
    assert comparison['passed'] and comparison['exact_match']
    program = (root / ('tests/fixtures/' + fixture + '.el')).read_text()
    expected = (root / ('tests/fixtures/' + fixture + '.expected')).read_bytes().rstrip(b'\n')
    for editor in ['gnu', 'emaxx']:
        result = read(stem + '-' + editor + '.result.json')
        command = read(stem + '-' + editor + '.command.json')
        assert result == comparison['outcomes'][editor]
        assert result['exit_code'] == 0 and not result['timed_out'] and result['expected_output']
        assert result['source_unchanged'] and result['inputs_unchanged']
        assert command['environment_override']['LANG'] == command['environment_override']['LC_ALL'] == 'C'
        assert command['command'][1:] == ['-Q', '--batch', '--eval', '(prin1 ' + program + ')']
        assert command['fixture_mode'] == 'print-return-value'
        assert all(sha(Path(name)) == digest for name, digest in command['inputs'].items())
        stdout = p / (stem + '-' + editor + '.stdout')
        assert stdout.read_bytes() == expected and sha(stdout) == result['stdout_sha256']
        assert (p / (stem + '-' + editor + '.stderr')).read_bytes() == b''
audit = dict(status='all eight file-writing/coding/copy ordinary comparisons pass',
             fixtures=fixtures, ordinary_processes_verified=16, artifacts=artifacts,
             inputs_verified=462, goal_complete=False,
             qualification='Same normal -Q batch inputs, original expected outputs, exact output bytes and exit statuses. All four prior coding/copy fixtures, three new file-writing fixtures and actual error-object fixture pass. Every raw process/input hash is verified. This does not certify the terminal or full frozen inventory. GNU source/native ABI matches but the executable is not pinned Darwin.')
with (p / 'source243-new-ordinary-audit.json').open('x') as f:
    json.dump(audit, f, indent=2)
print(json.dumps(dict(status=audit['status'], comparisons=len(fixtures), processes=16), indent=2))
