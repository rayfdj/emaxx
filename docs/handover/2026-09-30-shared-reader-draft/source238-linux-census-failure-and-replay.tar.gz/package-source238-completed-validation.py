from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
out = p.parents[2] / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
read = lambda name: json.loads((p / name).read_text())
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected'}
def select(patterns):
    return {str(file.relative_to(p)): file for pattern in patterns for file in p.glob(pattern)
            if file.is_file() and file.suffix in allowed}
def tree(files, path):
    files.update({str(file.relative_to(p)): file for file in (p / path).rglob('*')
                  if file.is_file() and file.suffix in allowed})

macos = read('source238-macos-rust-complete-audit.json')
release = read('source238-release-audit.json')
ordinary = read('source238-ordinary-audit.json')
assert macos['total_passed'] == 3085 and macos['library_ignored'] == 2
assert [group['passed'] for group in release['groups']] == [101, 940]
assert len(ordinary['fixtures']) == 57
files = select(['source238-full-gate*', 'source238-macos-*', 'source238-release-*',
                'source238-ordinary-*', 'source238-manifest.json', 'source238-complete.patch',
                'source238-incremental.patch', 'source238-gate-inventory.txt',
                'audit-source238-macos-names.py', 'verify-source238-macos-rust.py',
                'audit-source238-release.py', 'audit-source238-ordinary.py',
                'run-source238-full-gate.py', 'run-source238-release-and-ordinary.py',
                'build-source238.py', 'compare-source230-fixtures.py',
                'test-source238-controls.py', 'test-source238-broad.py', Path(__file__).name])
tree(files, 'full-gate-source238')
package('source238-complete-macos-and-selected', files,
        dict(macos=macos, release=release, ordinary=ordinary,
             qualification='Complete macOS Rust, selected release and 57 ordinary comparisons pass. Four additional coding/copy probes in this archive fail and are separately repaired by the source240 draft. Linux Rust failed; full terminal and Linux frozen remain separate. The first Mac verifier ran before artifact retention and wrote no passing audit; the retention receipt records the setup correction. No goal or performance completion.'))

failure = read('source238-linux-rust-failure-audit.json')
replay = read('source238-linux-census-replay-audit.json')
assert failure['library_passed'] == 2250 and failure['library_failed'] == 1
assert len(failure['unstarted_library_tests']) == 745
assert replay['same_rust_executable_sha256'] == failure['binary_sha256']
files = select(['source238-linux-rust-*', 'source238-linux-census-replay-*',
                'source238-linux-primitives-replay-*', 'source238-manifest.json',
                'audit-source238-linux-rust-failure.py', 'audit-source238-census-replay.py',
                'launch-source238-primitives-replay.py', Path(__file__).name])
tree(files, 'source238-linux-rust-artifacts')
tree(files, 'source238-linux-census-replay-artifacts')
package('source238-linux-census-failure-and-replay', files,
        dict(failure=failure, selected_replay=replay,
             group_replay_launch=read('source238-linux-primitives-replay-launch.json'),
             qualification='The original full Linux run failed its GNU reference assertion before an Emaxx result. The exact Rust binary passes that unchanged control in a fresh job; GNU executable identity was not hashed in these Rust jobs. The fresh Emaxx fixture image differs. The selected replay does not identify the cause or certify the 745 unstarted library tests and unstarted Cargo stages. A fresh entire-primitives-group diagnosis is active. Expectations remain unchanged.'))
