from pathlib import Path
import hashlib, json, re

p = Path(__file__).parent.resolve()
root = p / 'source238-linux-census-replay-artifacts/rust-replay'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
s = json.loads((root / 'summary.json').read_text())
name = 'lisp::primitives::tests::native_vector_and_closure_census_matches_gnu_word_layout'
assert s['status'] == 'selected diagnostic passed' and s['exit_code'] == 0 and not s['timed_out']
assert s['git'] == s['source_after'] == {'head': '6ee4bd1b9e79cef790c6dc88a64ef1896a2679f2', 'dirty': False}
assert s['expected_tests'] == s['executed_tests'] == [name] and s['ignored_tests'] == []
assert s['total_tests'] == 2996 and s['fixture_images_before'] == []
raw = (root / 'replay.log').read_text()
assert re.findall(r'^test (\S+) \.\.\. (ok|FAILED)$', raw, re.M) == [(name, 'ok')]
assert re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', raw, re.M) == [('ok', '1', '0', '0')]
failed = json.loads((p / 'source238-linux-rust-failure-audit.json').read_text())
assert sha(root / 'libtest') == s['test_binary']['sha256'] == failed['binary_sha256']
for image in s['fixture_images']:
    file = root / image['artifact']
    assert sha(file) == image['sha256'] and file.stat().st_size == image['bytes']
download = json.loads((p / 'source238-linux-census-replay-download.json').read_text())
assert sha(p / 'source238-linux-census-replay-artifact.zip') == download['zip_sha256']
for entry in download['files']:
    file = root.parent / entry['path']
    assert sha(file) == entry['sha256'] and file.stat().st_size == entry['bytes']
record = dict(status='selected unchanged control passes', run_id=36814333394,
              runtime_source='source238', test=name, same_rust_executable_sha256=failed['binary_sha256'],
              fixture_images=s['fixture_images'], original_failure_run=36812116311,
              original_failure_remains=True, goal_complete=False,
              qualification='The unchanged control passes in a fresh Linux job with the exact same Rust executable hash. That control checks GNU first, then Emaxx. The fresh Emaxx fixture image differs, but the original failure occurred before Emaxx startup. This single selected replay does not identify the cause of the GNU census variation or certify the full failed inventory. No expectations, tests or thresholds changed.')
with (p / 'source238-linux-census-replay-audit.json').open('x') as f:
    json.dump(record, f, indent=2)
print(json.dumps(record, indent=2))
