from pathlib import Path
import hashlib, json, re, subprocess

p = Path(__file__).parent.resolve()
root = p.parents[2]
head = '6ee4bd1b9e79cef790c6dc88a64ef1896a2679f2'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == head
manifest = json.loads((p / 'source238-manifest.json').read_text())
assert all(hashlib.sha256((root / name).read_bytes()).hexdigest() == digest for name, digest in manifest.items())
command = ['gh', 'workflow', 'run', 'frozen-run.yml', '--repo', 'rayfdj/emaxx', '--ref', 'runtime-char-tables',
           '-f', 'validation=rust-replay', '-f', 'rust_filter=lisp::primitives::tests::']
result = subprocess.run(command, cwd=root, stdin=subprocess.DEVNULL, capture_output=True, text=True)
with (p / 'source238-linux-primitives-replay-dispatch.json').open('x') as f:
    json.dump(dict(command=command, commit=head, exit_code=result.returncode,
                   stdout=result.stdout, stderr=result.stderr,
                   purpose='Replay the entire unchanged 643-test primitives group to check whether the failed GNU census assertion depends on preceding controls. The single-test replay passed; the original full run remains failed.'), f, indent=2)
assert result.returncode == 0, result.stderr
match = re.search(r'/actions/runs/(\d+)', result.stdout)
assert match, result.stdout
run_id = int(match.group(1))
state = json.loads(subprocess.check_output(['gh', 'run', 'view', str(run_id), '--repo', 'rayfdj/emaxx',
                                         '--json', 'status,conclusion,headSha,url'], text=True))
assert state['headSha'] == head
with (p / 'source238-linux-primitives-replay-launch.json').open('x') as f:
    json.dump(dict(run_id=run_id, state=state, runtime_source='source238', expected_group_size=643,
                   qualification='Fresh unchanged group diagnosis, not a rerun of the complete failed gate. No expected results or inventory changed.'), f, indent=2)
print(json.dumps(dict(run_id=run_id, state=state), indent=2))
