from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve();out=p.parents[2]/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda n:json.loads((p/n).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
allowed={'.json','.log','.txt','.py','.stdout','.stderr','.el','.expected','.h','.loaded'}
for kind in ['frozen','gnu-census-trace']:
 files={}
 directory=p/('source310-linux-frozen-artifacts' if kind=='frozen' else 'source310-gnu-census-trace-artifacts')
 for f in directory.rglob('*'):
  if f.is_file() and f.suffix in allowed:files[str(f.relative_to(p))]=f
 if kind=='frozen':
  audit=read('source310-linux-frozen-complete-audit.json');raw=read('source310-linux-frozen-raw-integrity-audit.json')
  assert audit['status']=='matched' and (audit['verified_files'],audit['verified_outcomes'],audit['successful_processes'])==(519,7928,1038)
  assert raw['status']=='passed'
  base=Path(raw['raw_artifact_directory']);assert all(sha((base/n).read_bytes())==h for n,h in raw['raw_files'].items())
  names=['source310-linux-frozen-complete-audit.json','source310-linux-frozen-raw-integrity-audit.json','source310-linux-collection-result.json','source310-linux-collection-launch.json','source310-linux-audit-preparation.json','audit-source310-linux-frozen.py','verify-complete-frozen-receipts279.py','collect-source310-linux.py','source310-full-validation-launch.json','source310-manifest.json']
  scope=dict(status='complete source310 Linux frozen comparison matched',source_commit='5e6f6fc89654b5e695161f5e1713d06ff8ca1f3c',files=519,outcomes=7928,successful_processes=1038,qualification='Every outcome and raw process identity audited. Expected failures and skips remain separate from passes. The separate Linux Rust workflow remains failed; source310 macOS is running, and this bundle does not certify source311 or performance.',goal_complete=False)
 else:
  audit=read('source310-gnu-census-trace-audit.json');assert audit['status']=='raw GNU census trace verified'
  base=next(directory.glob('*/gnu-census-trace'));assert all(sha((base/n).read_bytes())==h for n,h in audit['evidence'].items())
  names=['source310-gnu-census-trace-audit.json','audit-source310-gnu-census-trace.py','source310-gnu-census-trace-launch.json','source310-gnu-census-trace-run.json','source310-gnu-census-trace-download.json']
  scope=dict(status=audit['status'],run_id=audit['run_id'],findings=audit['findings'],qualification=audit['qualification'],goal_complete=False)
  root=p.parents[2]
  for n in ['tools/diagnose_gnu_census_trace.py','tools/diagnostics/gnu-census-snapshot.py','tests/fixtures/vector-closure-rounded-census.el','tests/fixtures/vector-closure-rounded-census.expected','tests/fixtures/vector-pseudovector-word-census.el','tests/fixtures/vector-pseudovector-word-census.expected']:files[n]=root/n
 for n in names+[Path(__file__).name,'package-source196-failure-and197-results.py']:files[n]=p/n
 assert all(f.is_file() for f in files.values())
 package('source310-linux-'+kind+'-results',files,scope)
