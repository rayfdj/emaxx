from pathlib import Path
import hashlib,json
p=Path(__file__).parent.resolve();root=p.parents[2]
d=next((p/'source310-gnu-census-trace-artifacts').glob('*/gnu-census-trace'))
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
read=lambda f:json.loads(f.read_text())
s=read(d/'summary.json')
assert s['status']=='GC diagnosis completed' and s['git']=={'head':'48593a3562ba26384bd9916099dbb08e53aa205e','dirty':False}
assert s['inputs_unchanged'] and len(s['runs'])==22
for name,h in s['inputs'].items():
 relative=name.split('/emaxx/emaxx/emaxx/',1)[1]
 assert sha(root/relative)==h
capture=read(d/'gnu-inputs/manifest.json');verify=read(d/'gnu-inputs/verification.json')
assert capture['source_commit']=='636f166cfc86aa90d63f592fd99f3fdd9ef95ebd'
assert verify['status']=='unchanged' and verify['files_verified']==4
assert verify['capture_manifest_sha256']==sha(d/'gnu-inputs/manifest.json')
for f in capture['files']:assert sha(d/'gnu-inputs'/f['artifact'])==f['sha256']
assert capture['files'][0]['sha256']=='5e1721732427d69d8af63211f1e3833ec21e40f97f4b7f6cd4cb224b72cebfcf'
assert capture['files'][1]['sha256']=='bf4974228f3b3ea4374cec75a38eeb2bd0e7dd944da5bec4e6ad0387092502ae'
findings={}
for fixture in ['vector-closure-rounded-census','vector-pseudovector-word-census']:
 expected=(root/('tests/fixtures/'+fixture+'.expected')).read_bytes().rstrip(b'\n')
 program='(prin1 '+(root/('tests/fixtures/'+fixture+'.el')).read_text()+')'
 rows=[r for r in s['runs'] if r['label'].startswith(fixture+'-ordinary-')]
 assert [r['padding_bytes'] for r in rows]==[None,0,8,16,32,64,128,256,1024,4096]
 failures=[]
 for r in rows:
  assert r['command'][1:]==['--batch','-Q','--eval',program]
  assert r['exit_code']==0 and not r['timed_out']
  for suffix in ['stdout','stderr']:assert sha(d/r[suffix+'_file'])==r[suffix+'_sha256']
  assert not (d/r['stderr_file']).read_bytes()
  out=(d/r['stdout_file']).read_bytes();assert r['expected_output']==(out==expected)
  assert r['expected_sha256']==hashlib.sha256(expected).hexdigest()
  if out!=expected:
   # Every remaining result byte is identical; preserve the actual negative.
   first=b'(((0 0)' if fixture=='vector-closure-rounded-census' else b'(((0 2)'
   negative=b'(((0 -9)' if fixture=='vector-closure-rounded-census' else b'(((0 -7)'
   assert expected.startswith(first) and out==negative+expected[len(first):]
   failures.append(r['label'])
 debugger=next(r for r in s['runs'] if r['label']==fixture+'-gdb')
 assert debugger['exit_code']==0 and not debugger['timed_out']
 for suffix in ['stdout','stderr']:assert sha(d/debugger[suffix+'_file'])==debugger[suffix+'_sha256']
 stdout=(d/debugger['stdout_file']).read_text()
 events=[json.loads(line.split('GNU_CENSUS_TRACE ',1)[1]) for line in stdout.splitlines() if 'GNU_CENSUS_TRACE ' in line]
 assert events==read(d/(fixture+'-trace-events.json')) and len(events)==26
 assert [e['argv'] for e in events if e['event']=='inferior argument vector']==[rows[0]['command']]
 inv=[e for e in events if e['event']=='marked vector inventory'];ret=[e for e in events if e['event']=='explicit GC returned']
 assert [e['collection'] for e in inv]==[e['collection'] for e in ret]==list(range(1,9))
 previous={}
 for a,b in zip(inv,ret):
  objects={o['address']:o for o in a['objects']};assert len(objects)==len(a['objects'])
  live={n:o for n,o in objects.items() if o['marked']}
  assert a['live_objects']==len(live) and a['live_slots']==sum(o['bytes']//8 for o in live.values())==b['total_vector_slots']
  assert a['dropped_previous_live']==[o for n,o in previous.items() if n not in live]
  previous=live
 done=[e for e in events if e['event']=='observer completed'];assert len(done)==1 and not done[0]['errors'] and done[0]['captured_sweeps']==8
 findings[fixture]=dict(ordinary_processes=10,ordinary_matches=10-len(failures),ordinary_mismatches=failures,
  trace_live_slots=[e['live_slots'] for e in inv],trace_dropped=[e['dropped_previous_live'] for e in inv],trace_complete=done[0])
 if fixture=='vector-closure-rounded-census':
  a,b=inv[:2];dropped=b['dropped_previous_live']
  assert [(o['kind'],o['bytes']) for o in dropped]==[('PVEC_NORMAL_VECTOR',32),('PVEC_CLOSURE',40)]
  vector,closure=dropped;assert closure['words'][3]==vector['address']+5
  assert a['live_slots']-b['live_slots']==9
  before={o['address'] for o in a['objects'] if o['marked']};after={o['address'] for o in b['objects'] if o['marked']}
  assert not after-before and before-after=={o['address'] for o in dropped}
  candidate=[r for r in a['stack']['candidates'] if r['object_address']==closure['address']]
  assert len(candidate)==1 and candidate[0]['word']==closure['address']+5
  assert not [r for r in b['stack']['candidates'] if r['object_address'] in before-after]
  assert '(((0 -9)' in stdout
  findings[fixture]['retention_evidence']=dict(closure_points_to_constants_vector=True,dropped_words=9,stack_candidate_before=candidate,stack_candidates_after=[])
result=dict(status='raw GNU census trace verified',run_id=37432665927,findings=findings,
 evidence={str(f.relative_to(d)):sha(f) for f in d.rglob('*') if f.is_file()},goal_complete=False,
 qualification='The unmodified original vector fixture returns -9 in ordinary GNU and under the read-only debugger. Between its first two explicit collections, the actual GNU marked heap loses exactly one 40-byte closure and its 32-byte constants vector; no other object is added or removed from the marked inventory. A tagged closure pointer is present on the C stack in the first snapshot and absent in the second. That stack word is a candidate retention root, not a proven marking path. The record fixture reproduces -7 ordinarily but returns expected 2 under GDB; its exact dropped objects are not captured. Thus original global-heap deltas can include unrelated reclamation; these diagnostics do not turn any failed Rust run into a pass or certify Emaxx GC.')
(p/'source310-gnu-census-trace-audit.json').open('x').write(json.dumps(result,indent=2))
print(json.dumps(dict(status=result['status'],ordinary_matches={n:f['ordinary_matches'] for n,f in findings.items()},vector_dropped_words=9)))
