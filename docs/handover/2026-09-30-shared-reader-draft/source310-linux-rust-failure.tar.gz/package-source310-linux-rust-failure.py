from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve();out=p.parents[2]/'docs/handover/2026-09-30-shared-reader-draft';sha=lambda data:hashlib.sha256(data).hexdigest()
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package');exec(compile(ast.Module(body=[node],type_ignores=[]),'<packager>','exec'))
audit=json.loads((p/'source310-linux-rust-failure-audit.json').read_text());assert audit['status']=='failed' and audit['library_passed']==2295 and len(audit['unstarted_library_tests'])==765
artifact=p/'source310-linux-rust-failure-artifacts/ordinary-linux-5e6f6fc89654b5e695161f5e1713d06ff8ca1f3c'
files={str(f.relative_to(p)):f for f in artifact.rglob('*') if f.is_file() and f.suffix in {'.json','.log','.txt'}}
for name in ['audit-source310-linux-rust-failure.py','source310-linux-rust-failure-audit.json','source310-linux-rust-terminal.json','source310-linux-rust-failed.log','source310-linux-rust-log-result.json','source310-linux-rust-failure-download-command.json','source310-linux-rust-failure-download-result.json','source310-full-validation-launch.json','source310-manifest.json','source310-modes.json','package-source196-failure-and197-results.py',Path(__file__).name]:files[name]=p/name
package('source310-linux-rust-failure',files,dict(status='failed',audit=audit,qualification=audit['qualification'],goal_complete=False))
