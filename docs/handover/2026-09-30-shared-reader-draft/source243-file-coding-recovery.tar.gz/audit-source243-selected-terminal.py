from pathlib import Path
import hashlib
import json
import re
import runpy

p = Path(__file__).parent.resolve()
read = lambda name: json.loads((p / name).read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
command = read('source243-selected-ttydiff-command.json')
result = read('source243-selected-ttydiff-result.json')
root = Path(command['working_directory'])
manifest = read(command['source_manifest'])
assert len(manifest) == 462 and all(sha(root / name) == digest for name, digest in manifest.items())
assert len(command['inputs']) == 8
assert all(sha(Path(name)) == digest for name, digest in command['inputs'].items())
assert result['exit_code'] == 0 and result['source_unchanged'] and result['inputs_unchanged']
assert result['complete_start_inventory']
raw = (p / 'source243-selected-ttydiff.log').read_text()
module = runpy.run_path(str(root / 'tools/ttydiff.py'), run_name='inventory_only')
scenarios = module['select_scenarios'](command['inventory'])
assert [s[0] for s in scenarios] == command['inventory']
assert len(scenarios) == result['expected_scenarios'] == 11
expected = {}
for scenario in scenarios:
    name, keys = scenario[0], scenario[2]
    labels = []
    final_label, final_filesystem = name, False
    for index, item in enumerate(keys):
        action = module['normalize_action'](item, index)
        if not action.checkpoint:
            continue
        label = f'{name}::{index + 1}:{action.name}'
        if index + 1 == len(keys):
            final_label, final_filesystem = label, action.filesystem
        else:
            labels.append(label)
            if action.filesystem:
                labels.append(label + ' filesystem')
    labels.append(final_label)
    if final_filesystem:
        labels.append(final_label + ' filesystem')
    expected[name] = labels
expected_labels=[label for labels in expected.values() for label in labels]
starts=re.findall(r'^RUN \[(\d+)/(\d+)\] (.+)$',raw,re.M)
assert starts==[(str(i+1),'11',scenario[0]) for i,scenario in enumerate(scenarios)]
verdicts=re.findall(r'^(MATCH|DIVERGE) \[(.+)\]: (.+)$',raw,re.M)
assert [label for _,label,_ in verdicts]==expected_labels
assert all(kind=='MATCH' and re.fullmatch(r'text area identical \(\d+ rows\)|isolated fixture trees identical',detail) for kind,_,detail in verdicts)
old=read('source238-terminal-failure-audit.json')['divergent_labels']
assert len(old)==1 and set(old).issubset(expected_labels)
assert set(read('source238-terminal-failure-audit.json')['unexecuted_labels']).issubset(expected_labels)
assert raw.rstrip().endswith('PASS: all scenarios match')
record={'status':'all selected terminal comparisons match','inputs_verified':len(manifest),'scenarios':command['inventory'],'matching_comparisons':len(verdicts),'original_divergences_repaired':old,'log_sha256':sha(p/'source243-selected-ttydiff.log'),'qualification':'All eleven original file-lifecycle scenarios, the original coding-indicator divergence and its three previously unexecuted comparisons pass with unchanged actions, timeouts and comparison logic. GNU source/native ABI matches, but this is not the pinned Darwin binary or the complete 226-scenario inventory. No general file-I/O completeness or performance claim.'}
with (p/'source243-selected-terminal-audit.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(record,indent=2))
