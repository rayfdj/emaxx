from pathlib import Path
import errno, hashlib, json, os, pty, select, signal, time
p = Path(__file__).parent.resolve()
r = p.parent / 'recovered-2026-09-30'
fixture = p / 'write-region-prompt-consumption-probe.el'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
for editor, binary in [('gnu', r / 'emacs/src/emacs'), ('source243', r / 'file-coding/emaxx/target/frame-validation/release/emaxx')]:
    stem = 'source243-write-prompt-interactive-' + editor
    report = p / (stem + '.output')
    assert not report.exists()
    program = '(let ((observed ' + fixture.read_text() + ')) (let ((coding-system-for-write \'utf-8)) (with-temp-file (getenv "WRITE_PROMPT_RESULT") (prin1 observed (current-buffer)))) (kill-emacs 0))'
    command = [str(binary), '-Q', '-nw', '--eval', program]
    env = dict(LANG='C', LC_ALL='C', TERM='xterm-256color', WRITE_PROMPT_RESULT=str(report))
    inputs = {str(file): sha(file) for file in [binary, binary.with_suffix('.pdmp'), fixture]}
    with (p / (stem + '-command.json')).open('x') as f:
        json.dump(dict(command=command, environment_override=env, inputs=inputs,
                       qualification='Actual interactive PTY entry point. The same existing probe supplies no RET in unread-command-events and records remaining input after declining. Prior batch attempts are retained; noninteractive input routing did not exercise that queue.'), f, indent=2)
    start = time.monotonic()
    pid, fd = pty.fork()
    if pid == 0:
        os.chdir(r / 'file-coding/emaxx')
        os.execve(str(binary), command, {**os.environ, **env})
    status = None
    timed_out = False
    with (p / (stem + '.tty')).open('xb') as log:
        while True:
            ready, _, _ = select.select([fd], [], [], 0.1)
            if ready:
                try:
                    chunk = os.read(fd, 65536)
                except OSError as error:
                    if error.errno != errno.EIO:
                        raise
                    chunk = b''
                if chunk:
                    log.write(chunk)
            found, status = os.waitpid(pid, os.WNOHANG)
            if found:
                break
            if time.monotonic() - start > 90:
                timed_out = True
                os.killpg(pid, signal.SIGKILL)
                _, status = os.waitpid(pid, 0)
                break
    os.close(fd)
    record = dict(exit_code=os.waitstatus_to_exitcode(status), timed_out=timed_out,
                   elapsed_seconds=time.monotonic()-start, inputs_unchanged=all(sha(Path(name)) == digest for name, digest in inputs.items()),
                   report_sha256=sha(report) if report.exists() else None,
                   report=report.read_text() if report.exists() else None)
    with (p / (stem + '-result.json')).open('x') as f:
        json.dump(record, f, indent=2)
    print(editor, json.dumps(record), flush=True)
