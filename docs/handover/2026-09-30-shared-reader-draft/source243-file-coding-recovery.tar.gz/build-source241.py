from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
p=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28')
root=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/file-coding/emaxx')
tag='source'+sys.argv[1];manifest=json.loads((p/(tag+'-manifest.json')).read_text())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def unchanged():return all(sha(root/f)==h for f,h in manifest.items())
env={'CARGO_TARGET_DIR':'/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/file-coding/emaxx/target/frame-validation','CARGO_BUILD_JOBS':'1','LANG':'C','LC_ALL':'C',
     'RUST_MIN_STACK':'134217728','RUST_TEST_THREADS':'1','EMAXX_GC_VERIFY':'1',
     'EMAXX_GNU_SOURCE_DIRECTORY':'/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/emacs',
     'EMAXX_DUMP_SOURCE_DIRECTORY':'/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/emacs',
     'EMACS_TEST_DIRECTORY':'/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/emacs/test'}
def save(name,data):
    with (p/(tag+'-'+name+'.json')).open('x') as f:json.dump(data,f,indent=2)
binary=Path(env['CARGO_TARGET_DIR'])/'release/emaxx'
for name,cmd,extra in [
    ('ordinary-build',['cargo','build','--locked','--release','--all-features','--bin','emaxx','--bin','make-fingerprint','--bin','compat-harness'],{}),
    ('ordinary-image',['sh','tools/build-image.sh',str(binary)],{'EMAXX_IMAGE_FORCE':'1'})]:
    assert unchanged()
    save(name+'-command',{'command':cmd,'working_directory':str(root),'environment_override':{**env,**extra}})
    start=time.monotonic()
    with (p/(tag+'-'+name+'.log')).open('x') as log:
        r=subprocess.run(cmd,cwd=root,env={**os.environ,**env,**extra},stdout=log,stderr=subprocess.STDOUT,timeout=1800)
    result={'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'source_unchanged':unchanged()}
    save(name+'-result',result);print(name,result,flush=True)
    if r.returncode or not result['source_unchanged']:sys.exit(r.returncode or 2)
artifacts={}
for f in [binary,binary.with_suffix('.pdmp')]:
    destination=p/(tag+'-ordinary-'+f.name)
    assert not destination.exists();shutil.copy2(f,destination)
    assert sha(f)==sha(destination)
    artifacts[str(f)]={'sha256':sha(f),'immutable_copy':str(destination),'bytes':f.stat().st_size}
save('ordinary-artifacts',artifacts)
