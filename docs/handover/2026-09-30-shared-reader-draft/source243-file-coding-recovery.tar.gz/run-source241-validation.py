from pathlib import Path
import json, subprocess, sys, time
p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/file-coding/emaxx'
stages = [
    ['check-source241.py', '241'], ['static-source241.py', '241'],
    ['test-source241-controls.py', '241', 'gate'], ['build-source241.py', '241'],
    ['compare-source230-fixtures.py', 'source241', str(root),
     'file-write-coding-selection', 'new-file-coding-lifecycle', 'file-write-order',
     'canonical-coding-character-storage', 'canonical-coding-identity-storage',
     'canonical-coding-conversion-storage', 'copied-canonical-string-storage'],
    ['test-source241-broad.py', '241', 'gate'],
]
results = []
for name, *args in stages:
    command = [sys.executable, str(p / name), *args]
    start = time.monotonic()
    result = subprocess.run(command, stdin=subprocess.DEVNULL)
    results.append(dict(command=command, exit_code=result.returncode, elapsed_seconds=time.monotonic()-start))
    if result.returncode:
        break
with (p / 'source241-validation-result.json').open('x') as f:
    json.dump(results, f, indent=2)
raise SystemExit(results[-1]['exit_code'])
