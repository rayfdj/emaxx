from pathlib import Path
import hashlib, json, os, subprocess, time
p = Path(__file__).parent.resolve()
root = p.parents[2]
candidate = p.parent / 'recovered-2026-09-30/file-coding/emaxx'
base = '3060be47cdd76737ea1a4fbcb4b27736c92c984b'
assert not candidate.exists()
patch = p / 'source240-incremental.patch'
assert hashlib.sha256(patch.read_bytes()).hexdigest() == '26d4c617eb48a197dd6b325424ef1cf89043d1d9a76490768e796fc577bd05a6'
start = time.monotonic()
subprocess.run(['git', 'worktree', 'add', '--detach', str(candidate), base], cwd=root, check=True)
subprocess.run(['git', 'apply', '--check', str(patch)], cwd=candidate, check=True)
subprocess.run(['git', 'apply', str(patch)], cwd=candidate, check=True)
manifest = json.loads((p / 'source240-manifest.json').read_text())
assert all(hashlib.sha256((candidate / name).read_bytes()).hexdigest() == digest for name, digest in manifest.items())
gnu = p.parent / 'recovered-2026-09-30/emacs'
(candidate.parent / 'emacs').symlink_to(os.path.relpath(gnu, candidate.parent), target_is_directory=True)
cache = p.parent / 'recovered-2026-09-30/rx-repair/emaxx/target/frame-validation'
(candidate / 'target').mkdir()
subprocess.run(['cp', '-cR', str(cache), str(candidate / 'target/frame-validation')], check=True)
record = dict(candidate=str(candidate), base_commit=base, inherited_inputs=454,
              inherited_patch_sha256=hashlib.sha256(patch.read_bytes()).hexdigest(),
              cache_source=str(cache), elapsed_seconds=time.monotonic()-start,
              qualification='Source240 bytes replayed exactly into an independent checkout. Cache cloned from completed source238, not the running source240 gate. Subsequent source241 builds must verify their own fresh executable/image identity; no behavior pass claimed.')
with (p / 'source241-checkout.json').open('x') as f:
    json.dump(record, f, indent=2)
print(json.dumps(record, indent=2))
