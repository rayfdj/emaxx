from pathlib import Path
import ast, hashlib, json, re, shutil

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/file-coding/emaxx'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'audit-source238-release.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'audit_log')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<raw-verdict-auditor>', 'exec'))
manifest = read('source243-manifest.json')
assert len(manifest) == 462 and all(sha(root / name) == digest for name, digest in manifest.items())
c = read('source243-gate-controls-command.json')
r = read('source243-gate-controls-result.json')
assert r['exit_code'] == 0 and r['source_unchanged']
names = c['selected_inventory']
assert len(names) == len(set(names)) == 167
assert set(names) - set(read('source240-gate-controls-command.json')['selected_inventory']) == {
    'lisp::primitives::tests::file_write_coding_selection_preserves_lisp_policy_callbacks_and_restrictions',
    'lisp::primitives::tests::coding_errors_preserve_the_offending_symbol_object',
    'lisp::primitives::tests::new_file_coding_lifecycle_matches_gnu_after_save_and_revisit',
    'lisp::primitives::tests::file_write_coding_selection_preserves_overwrite_order_and_exclusive_creation',
    'lisp::primitives::tests::write_region_mustbenew_uses_gnu_short_answer_and_preserves_remaining_events'}
assert set(read('source240-gate-controls-command.json')['selected_inventory']) <= set(names)
ignored = ['tty::tty_differential_end_to_end', 'tty::tty_smoke_end_to_end']
audit_log(names, (p / 'source243-gate-controls.log').read_text(), ignored)
for stage in ['check', 'fmt', 'clippy', 'diff', 'gate-build']:
    result = read('source243-' + stage + '-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
    raw = (p / ('source243-' + stage + '.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
    for line in raw.splitlines():
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        assert row.get('message', {}).get('level') not in ['warning', 'error']
binary = p / 'source243-gate-libtest'
assert sha(binary) == c['binary_sha256']
images = sorted((p / 'fixture-images-source243').glob('loadup-' + sha(binary)[:8] + '-*.pdmp'))
assert len(images) == 1
retained = p / 'source243-focused-retained-inputs'
retained.mkdir()
files = []
for source in [binary, *images]:
    target = retained / source.name
    digest = sha(source)
    shutil.copy2(source, target)
    assert sha(source) == sha(target) == digest
    files.append(dict(original=str(source), retained=str(target), sha256=digest, bytes=target.stat().st_size))
audit = dict(status='strict and focused gate pass', inputs_verified=462, strict_checks='zero-warning pass',
             passed=165, failed=0, ignored=ignored, names=names, retained_files=files,
             goal_complete=False,
             qualification='All 162 preceding focused outcomes plus the three new GNU file-writing fixtures, actual coding-error object control and corrected prompt control, with original expected output. Callback selection, EOL, narrowing, mutation, forced GC, overwrite order and exclusive creation are covered. The prompt correction is grounded in the preserved actual GNU PTY result and retains file-protection assertions. Full gate, ordinary, terminal, Linux, release and performance validation remain separate. Root runtime still source238.')
with (p / 'source243-focused-audit.json').open('x') as f:
    json.dump(audit, f, indent=2)
print(json.dumps(dict(status=audit['status'], passed=165, ignored=ignored, retained_files=files), indent=2))
