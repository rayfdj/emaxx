(let* ((directory (make-temp-file "write-prompt-" t))
       (file (expand-file-name "state.dat" directory))
       (create-lockfiles nil)
       (inhibit-message t)
       (use-dialog-box nil))
  (unwind-protect
      (progn
        (let ((coding-system-for-write 'utf-8))
          (with-temp-file file (insert "old")))
        (let* ((noninteractive nil)
               (unread-command-events (list ?n ?o ?\r))
               (outcome (condition-case error
                            (write-region "new" nil file nil 'silent nil t)
                          (error (car error))))
               (pending (copy-sequence unread-command-events))
               (contents (with-temp-buffer
                           (insert-file-contents-literally file)
                           (buffer-string))))
          (list outcome pending contents)))
    (delete-directory directory t)))
