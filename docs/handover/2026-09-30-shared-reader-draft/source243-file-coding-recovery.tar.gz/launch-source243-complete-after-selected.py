from pathlib import Path
import hashlib, json, subprocess, sys, time

p = Path(__file__).parent.resolve()
result = p / 'source243-validation-result.json'
start = time.monotonic()
while not result.exists():
    assert time.monotonic() - start < 7200, 'Selected validation did not close'
    time.sleep(1)
stages = json.loads(result.read_text())
assert len(stages) == 6 and all(stage['exit_code'] == 0 for stage in stages)
subprocess.run([sys.executable, str(p / 'audit-source243-broad.py')], stdin=subprocess.DEVNULL, check=True)
assert json.loads((p / 'source243-focused-audit.json').read_text())['passed'] == 165
assert json.loads((p / 'source243-new-ordinary-audit.json').read_text())['ordinary_processes_verified'] == 16
records = []
for label, name in [('full-gate', 'run-source243-full-gate.py'),
                    ('release-and-ordinary', 'run-source243-release-and-ordinary.py')]:
    helper = p / name
    with (p / ('source243-' + label + '-driver.log')).open('x') as log:
        child = subprocess.Popen([sys.executable, str(helper)], stdin=subprocess.DEVNULL,
                                 stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    record = dict(pid=child.pid, command=[sys.executable, str(helper)],
                  helper_sha256=hashlib.sha256(helper.read_bytes()).hexdigest(),
                  source_manifest='source243-manifest.json')
    with (p / ('source243-' + label + '-launch.json')).open('x') as out:
        json.dump(record, out, indent=2)
    records.append(record)
with (p / 'source243-complete-launch-result.json').open('x') as out:
    json.dump(records, out, indent=2)
print(json.dumps(records, indent=2), flush=True)
