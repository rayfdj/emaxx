from pathlib import Path
import hashlib, json, re, shutil

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/file-coding/emaxx'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read('source242-manifest.json')
assert len(manifest) == 460 and all(sha(root / name) == digest for name, digest in manifest.items())
c = read('source242-gate-controls-command.json')
r = read('source242-gate-controls-result.json')
assert r['exit_code'] == 101 and r['source_unchanged']
names = c['selected_inventory']
assert len(names) == len(set(names)) == 166
raw = (p / 'source242-gate-controls.log').read_text()
assert re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', raw, re.M) == [('FAILED', '163', '1', '2')]
starts = list(re.finditer(r'^test (\S+) \.\.\. ', raw, re.M))
assert [m[1] for m in starts] == names
ignored = ['tty::tty_differential_end_to_end', 'tty::tty_smoke_end_to_end']
failed = ['lisp::primitives::tests::file_write_coding_selection_preserves_lisp_policy_callbacks_and_restrictions']
for index, match in enumerate(starts):
    end = starts[index + 1].start() if index + 1 < len(starts) else raw.rindex('test result:')
    block = raw[match.end():end].split('\n\nfailures:')[0].strip()
    if match[1] in ignored:
        assert block.startswith('ignored,')
    else:
        assert re.search(r'(?:^|\s)' + ('FAILED' if match[1] in failed else 'ok') + '$', block), match[1]
for stage in ['check', 'fmt', 'clippy', 'diff', 'gate-build']:
    result = read('source242-' + stage + '-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
    raw = (p / ('source242-' + stage + '.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
    for line in raw.splitlines():
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        assert row.get('message', {}).get('level') not in ['warning', 'error']
assert len(read('source242-validation-result.json')) == 3
binary = p / 'source242-gate-libtest'
assert sha(binary) == c['binary_sha256']
images = sorted((p / 'fixture-images-source242').glob('loadup-' + sha(binary)[:8] + '-*.pdmp'))
assert len(images) == 1
retained = p / 'source242-failed-retained-inputs'
retained.mkdir()
files = []
for source in [binary, *images]:
    target = retained / source.name
    digest = sha(source)
    shutil.copy2(source, target)
    assert sha(source) == sha(target) == digest
    files.append(dict(original=str(source), retained=str(target), sha256=digest, bytes=target.stat().st_size))
audit = dict(status='failed', inputs_verified=460, strict_checks='zero-warning pass',
             passed=163, failed=failed, ignored=ignored, names=names, retained_files=files,
             unexecuted_stages=['ordinary-build', 'ordinary-image', 'ordinary-comparisons', 'gate-broad'],
             goal_complete=False,
             qualification='The new GNU selection fixture fails only on the two invalid-coding payloads: Emaxx returns a formatted error string; GNU retains the offending symbol. Save/revisit, short-answer prompt and overwrite/exclusive creation controls pass. All fixtures and expected outputs remain unchanged. Ordinary build/comparisons and affected tests never run. This runtime is not applied to the task branch.')
with (p / 'source242-failure-audit.json').open('x') as f:
    json.dump(audit, f, indent=2)
print(json.dumps(dict(status=audit['status'], passed=163, failed=failed, retained_files=files), indent=2))
