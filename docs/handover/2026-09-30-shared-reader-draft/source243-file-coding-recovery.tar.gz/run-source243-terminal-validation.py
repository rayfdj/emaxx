from pathlib import Path
import json, subprocess, sys, time

p = Path(__file__).parent.resolve()
fixtures = ['file-write-coding-selection', 'new-file-coding-lifecycle', 'file-write-order',
            'canonical-coding-character-storage', 'canonical-coding-identity-storage',
            'canonical-coding-conversion-storage', 'copied-canonical-string-storage',
            'coding-error-object-storage']
needed = [p / ('source243-ordinary-' + name + '-comparison.json') for name in fixtures]
started = time.monotonic()
while not all(file.exists() for file in needed):
    closed = p / 'source243-validation-result.json'
    if closed.exists():
        assert all(stage['exit_code'] == 0 for stage in json.loads(closed.read_text())), 'Earlier validation failed'
    assert time.monotonic() - started < 3900, 'Ordinary prerequisites did not finish'
    time.sleep(1)

results = []
for name in ['audit-source243-new-ordinary.py', 'run-source243-selected-tty.py',
             'audit-source243-selected-terminal.py', 'diagnose-source243-write-prompt-interactive.py']:
    command = [sys.executable, str(p / name)]
    start = time.monotonic()
    result = subprocess.run(command, stdin=subprocess.DEVNULL)
    results.append(dict(command=command, exit_code=result.returncode, elapsed_seconds=time.monotonic()-start))
    if result.returncode:
        break
if all(row['exit_code'] == 0 for row in results):
    for editor in ['gnu', 'source243']:
        result = json.loads((p / ('source243-write-prompt-interactive-' + editor + '-result.json')).read_text())
        assert result['exit_code'] == 0 and not result['timed_out'] and result['inputs_unchanged']
        assert result['report'] == '(file-already-exists (111 13) "old")'
with (p / 'source243-terminal-validation-result.json').open('x') as out:
    json.dump(results, out, indent=2)
raise SystemExit(results[-1]['exit_code'])
