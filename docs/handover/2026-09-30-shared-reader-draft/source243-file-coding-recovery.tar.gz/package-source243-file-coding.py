from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
out = p.parents[2] / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
read = lambda name: json.loads((p / name).read_text())
focused = read('source243-focused-audit.json')
broad = read('source243-broad-audit.json')
ordinary = read('source243-new-ordinary-audit.json')
terminal = read('source243-selected-terminal-audit.json')
assert focused['passed'] == 165 and len(focused['ignored']) == 2
assert broad['passed'] == 948 and ordinary['ordinary_processes_verified'] == 16
assert len(terminal['scenarios']) == 11
assert all(stage['exit_code'] == 0 for stage in read('source243-validation-result.json'))
assert all(stage['exit_code'] == 0 for stage in read('source243-terminal-validation-result.json'))
prompt = {}
for editor in ['gnu', 'source243']:
    stem = 'source243-write-prompt-interactive-' + editor
    command, result = read(stem + '-command.json'), read(stem + '-result.json')
    assert result['exit_code'] == 0 and not result['timed_out'] and result['inputs_unchanged']
    assert result['report'] == '(file-already-exists (111 13) "old")'
    assert sha((p / (stem + '.output')).read_bytes()) == result['report_sha256']
    assert all(sha(Path(name).read_bytes()) == digest for name, digest in command['inputs'].items())
    prompt[editor] = result
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected', '.output', '.tty'}
patterns = [
    'source241-*', 'source242-*',
    'source243-manifest.json', 'source243-*.patch', 'source243-freeze.json',
    'source243-patch-replay-audit.json', 'source243-validation-*',
    'source243-gate-*', 'source243-focused-audit.json', 'source243-broad-audit.json',
    'source243-new-ordinary-audit.json', 'source243-ordinary-artifacts.json',
    'source243-ordinary-build*', 'source243-ordinary-image*',
    'source243-selected-tty*', 'source243-selected-terminal-audit.json',
    'source243-terminal-validation-*', 'source243-write-prompt-interactive-*',
    'source243-full-gate-launch.json', 'source243-full-gate-command.json',
    'source243-full-ttydiff-launch.json', 'source243-full-ttydiff-command.json',
    'source243-release-and-ordinary-launch.json', 'source243-complete-launch-result.json',
    'source243-complete-launch-driver.log', 'source243-complete-launch-supervisor.json',
    'source243-task-checkout-applied.json',
    'source240-ordinary-file-write-*', 'source240-ordinary-new-file-coding-probe-*',
    'source240-ordinary-write-region-prompt-consumption-probe-*',
    'source240-write-prompt-interactive-*', 'source240-ordinary-coding-error-object-storage-probe-*',
    'file-write-*.el', 'write-region-prompt-consumption-probe.el',
    'new-file-coding-probe.el', 'coding-error-object-storage-probe.el',
    'prepare-source241-checkout.py', 'audit-source241-source242-patches.py',
    'audit-source242-failure.py', 'audit-source243-*.py',
    'freeze-source24[123].py', 'check-source24[123].py', 'static-source24[123].py',
    'test-source24[123]-*.py', 'build-source24[123].py', 'run-source24[123]-*.py',
    'launch-source243-complete-after-selected.py', 'launch-source243-complete.py',
    'diagnose-write-prompt-interactive.py',
    'diagnose-source243-write-prompt-interactive.py', 'compare-source230-fixtures.py',
    'audit-source238-release.py', Path(__file__).name,
]
for stage in ['check', 'fmt', 'clippy', 'diff']:
    patterns += ['source243-' + stage + '*']
for fixture in ordinary['fixtures']:
    patterns.append('source243-ordinary-' + fixture + '-*')
files = {str(file.relative_to(p)): file for pattern in patterns for file in p.glob(pattern)
         if file.is_file() and file.suffix in allowed}
assert not any(name in files for name in ['source243-full-gate.log', 'source243-full-ttydiff.log',
                                         'source243-release-and-ordinary-driver.log'])
package('source243-file-coding-recovery', files,
        dict(prior_strict_failure=read('source241-failure-audit.json'),
             prior_focused_failure=read('source242-failure-audit.json'),
             patch_replay=read('source243-patch-replay-audit.json'), focused=focused, broad=broad,
             ordinary=ordinary, terminal=terminal, interactive_prompt=prompt,
             full_macos_launch=read('source243-full-gate-launch.json'),
             release_launch=read('source243-release-and-ordinary-launch.json'),
             full_terminal_launch=read('source243-full-ttydiff-launch.json'),
             qualification='Selected validation of the 462-input file-coding/copy repair. The original new-file indicator failure and all three previously unexecuted comparisons pass among the eleven unchanged file-lifecycle scenarios. Original failed sources and ordinary negative probes remain preserved. The prompt test correction follows actual GNU PTY evidence, retaining original-file protection and checking remaining input. Complete macOS, release/57 earlier ordinary comparisons and full terminal runs have launched; their active logs are excluded. Linux/frozen certification and every remaining architecture/performance requirement stay open. Main is unchanged.'))
