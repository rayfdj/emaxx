(progn
  (defvar write-selection-calls nil)
  (defvar write-selection-result nil)
  (defvar write-selection-mutate nil)
  (defun write-selection-observer (start end coding &optional interactive file)
    (push (list (if (stringp start) (append start nil) start)
                end coding interactive (file-name-nondirectory file))
          write-selection-calls)
    (when write-selection-mutate
      (if (stringp start)
          (aset start 0 ?Z)
        (goto-char start)
        (delete-char 1)
        (insert "Z")))
    (garbage-collect)
    write-selection-result)
  (defun write-selection-case (spec)
    (let* ((directory (make-temp-file "write-selection-" t))
           (file (expand-file-name "payload.dat" directory))
           (old-default (default-value 'buffer-file-coding-system))
           (coding-system-for-write (plist-get spec :explicit))
           (coding-system-require-warning (plist-get spec :warning))
           (file-coding-system-alist
            (if (plist-get spec :alist)
                '(("\\.dat\\'" . (utf-8 . utf-8-dos)))
              nil))
           (select-safe-coding-system-function
            (if (plist-get spec :observe)
                'write-selection-observer
              (if (plist-get spec :no-selector) nil
                select-safe-coding-system-function)))
           (write-selection-result (plist-get spec :selected))
           (write-selection-mutate (plist-get spec :mutate))
           (write-selection-calls nil)
           (last-coding-system-used 'before-write)
           (create-lockfiles nil)
           (inhibit-message t))
      (unwind-protect
          (progn
            (set-default 'buffer-file-coding-system (plist-get spec :default))
            (with-temp-buffer
              (when (plist-get spec :unibyte) (set-buffer-multibyte nil))
              (insert "Pab\nZ")
              (narrow-to-region 2 5)
              (when (plist-member spec :local)
                (setq-local buffer-file-coding-system (plist-get spec :local)))
              (let* ((string-source (and (plist-get spec :string) (copy-sequence "ab\n")))
                     (result
                      (condition-case error
                          (progn
                            (write-region string-source nil file nil 'silent)
                            (list 'ok last-coding-system-used
                                  (with-temp-buffer
                                    (set-buffer-multibyte nil)
                                    (insert-file-contents-literally file)
                                    (append (buffer-string) nil))))
                        (error (list 'error error last-coding-system-used
                                     (file-exists-p file))))))
                (list (plist-get spec :name) result (nreverse write-selection-calls)))))
        (set-default 'buffer-file-coding-system old-default)
        (delete-directory directory t))))
  (mapcar #'write-selection-case
          '((:name new-file)
            (:name explicit-utf8 :explicit utf-8)
            (:name explicit-unix-alias :explicit unix)
            (:name file-alist :alist t)
            (:name local-latin :local iso-latin-1)
            (:name default-eol :default utf-8-dos)
            (:name no-selector :no-selector t)
            (:name observed-local :local iso-latin-1 :observe t :selected utf-8-dos)
            (:name observed-alist :alist t :observe t :selected utf-8)
            (:name observed-default-eol :default utf-8-dos :observe t :selected utf-8)
            (:name explicit-skips-selector :explicit utf-8 :observe t :selected utf-8-dos)
            (:name explicit-warning :explicit utf-8 :warning t :observe t :selected utf-8-dos)
            (:name raw-skips-selector :local raw-text-dos :observe t :selected utf-8)
            (:name unibyte-forces-raw :unibyte t :alist t :observe t :selected utf-8)
            (:name unibyte-local :unibyte t :local utf-8 :observe t :selected utf-8-dos)
            (:name selector-nil :observe t)
            (:name selector-invalid :observe t :selected invalid-file-coding)
            (:name explicit-invalid :explicit invalid-file-coding)
            (:name mutated-buffer :observe t :selected utf-8 :mutate t)
            (:name mutated-string :observe t :selected utf-8 :mutate t :string t))))
