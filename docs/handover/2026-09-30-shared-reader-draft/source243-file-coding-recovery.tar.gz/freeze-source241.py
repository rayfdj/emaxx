from pathlib import Path
import hashlib, json, subprocess
p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/file-coding/emaxx'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
files = [*root.joinpath('src').rglob('*.rs'), *root.joinpath('tests').rglob('*')]
files += [root / name for name in ['Cargo.toml', 'Cargo.lock', 'build.rs', 'tools/ttydiff.py', 'tools/fixtures/fieldnotes.org', 'tools/fixtures/fake_lsp_server.py']]
files += list(root.joinpath('.cargo').glob('*'))
files += [root / name for name in ['compat/emacs_compat_runner.el', 'src/lisp/bytecode/fixture-oracle-30.2.elc', 'src/lisp/bytecode/fixture-oracle2-30.2.elc', 'src/lisp/bytecode/fixture-oracle3-30.2.elc']]
manifest = {str(file.relative_to(root)): sha(file) for file in sorted(set(files)) if file.is_file()}
assert len(manifest) == 460
with (p / 'source241-manifest.json').open('x') as f:
    json.dump(manifest, f, indent=2)
untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=root, text=True).splitlines()
extra = b''
for name in sorted(set(untracked) & set(manifest)):
    result = subprocess.run(['git', 'diff', '--no-index', '--binary', '--', '/dev/null', name], cwd=root, capture_output=True)
    assert result.returncode == 1 and not result.stderr
    extra += result.stdout
patches = {}
for label, base in [('incremental', '3060be47cdd76737ea1a4fbcb4b27736c92c984b'),
                    ('complete', '21d20f0eec08f3c013d5d3eb3bd6e9cfc16b3199')]:
    patch = subprocess.check_output(['git', 'diff', '--binary', base, '--', *sorted(manifest)], cwd=root) + extra
    target = p / ('source241-' + label + '.patch')
    with target.open('xb') as f:
        f.write(patch)
    patches[label] = dict(base=base, sha256=sha(target), bytes=len(patch))
for stem in ['check', 'static', 'test', 'build']:
    names = {'check': ['check-source240.py'], 'static': ['static-source240.py'],
             'test': ['test-source240-controls.py', 'test-source240-broad.py'], 'build': ['build-source240.py']}[stem]
    for name in names:
        source = (p / name).read_text().replace('coding-repair/emaxx', 'file-coding/emaxx')
        if name == 'test-source240-controls.py':
            old = 'names=sorted(set(names+coding_names+copy_names))'
            assert source.count(old) == 1
            source = source.replace(old, '''prompt_names=[name for name in inventory if name.endswith('::write_region_mustbenew_uses_gnu_short_answer_and_preserves_remaining_events')]
assert len(prompt_names)==1
names=sorted(set(names+coding_names+copy_names+prompt_names))
assert len(names)==166''')
        with (p / name.replace('240', '241')).open('x') as f:
            f.write(source)
record = dict(inputs=460, patches=patches, candidate=str(root), goal_complete=False,
              qualification='Separate file-coding draft, not yet validated. Three new GNU fixtures cover selection/callbacks/narrowing, new-file lifecycle and overwrite/exclusive creation. The original short-answer control is corrected against ordinary GNU PTY evidence, preserving declining error and original file bytes and asserting the actual remaining o RET input. Both failed batch prompt probes remain preserved; they did not exercise interactive event routing.')
with (p / 'source241-freeze.json').open('x') as f:
    json.dump(record, f, indent=2)
print(json.dumps(record, indent=2))
