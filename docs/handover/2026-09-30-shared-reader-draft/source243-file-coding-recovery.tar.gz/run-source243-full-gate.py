from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys, time

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/file-coding/emaxx'
manifest = json.loads((p / 'source243-manifest.json').read_text())
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
def unchanged():
    return all(sha(root / name) == digest for name, digest in manifest.items())
def save(name, data):
    with (p / name).open('x') as f:
        json.dump(data, f, indent=2)
assert unchanged() and len(manifest) == 462
assert json.loads((p / 'source243-broad-audit.json').read_text())['passed'] == 948
assert json.loads((p / 'source243-focused-audit.json').read_text())['passed'] == 165
gnu = p.parent / 'recovered-2026-09-30/emacs'
env = dict(CARGO_TARGET_DIR=str(root / 'target/frame-validation'), CARGO_BUILD_JOBS='1',
           EMAXX_GC_VERIFY='1', LANG='C', LC_ALL='C', EMAXX_GNU_SOURCE_DIRECTORY=str(gnu),
           EMAXX_DUMP_SOURCE_DIRECTORY=str(gnu), EMACS_TEST_DIRECTORY=str(gnu / 'test'))
artifact = p / 'full-gate-source243'
command = [sys.executable, 'tools/serial_grouped_gate.py', '--scope', 'full', '--artifact-root', str(artifact)]
save('source243-full-gate-command.json', dict(command=command, working_directory=str(root),
     base_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
     source_manifest='source243-manifest.json', environment_override=env,
     qualification='Complete unchanged macOS gate inventory on the isolated 462-input file-writing/coding/copy recovery draft. Strict checks, 165 focused and 948 affected tests, eight ordinary comparisons already pass; the prior source240 U+F8FF reporting repair remains included. Two existing TTY ignores remain. Normal executable and standard fixture cache are used. Release, terminal, Linux and frozen validation are separate.'))
start = time.monotonic()
with (p / 'source243-full-gate.log').open('x') as log:
    result = subprocess.run(command, cwd=root, env={**os.environ, **env}, stdin=subprocess.DEVNULL,
                            stdout=log, stderr=subprocess.STDOUT)
record = dict(exit_code=result.returncode, elapsed_seconds=time.monotonic() - start, source_unchanged=unchanged())
summary_path = artifact / 'summary.json'
if summary_path.exists():
    summary = json.loads(summary_path.read_text())
    record['summary'] = summary
    binary = summary.get('test_binary', {}).get('path')
    if binary and Path(binary).is_file():
        retained = p / 'source243-full-gate-libtest'
        assert not retained.exists()
        shutil.copy2(binary, retained)
        record['immutable_binary'] = dict(path=str(retained), sha256=sha(retained))
save('source243-full-gate-result.json', record)
print(json.dumps({key: value for key, value in record.items() if key != 'summary'}), flush=True)
if summary_path.exists():
    command = [sys.executable, 'tools/retain_rust_gate_artifacts.py', '--summary', str(summary_path),
               '--fixture-directory', str(root / 'target/grouped-gate/fixture-images')]
    save('source243-macos-retention-command.json', dict(command=command))
    retention = subprocess.run(command, cwd=root, stdin=subprocess.DEVNULL)
    save('source243-macos-retention-result.json', dict(exit_code=retention.returncode))
    assert retention.returncode == 0
raise SystemExit(0 if result.returncode == 0 and record['source_unchanged'] else 1)
