from pathlib import Path
import ast, hashlib, io, json, re, subprocess, tarfile, tempfile

p = Path(__file__).parent.resolve()
repository = p.parents[2]
checkout = p.parent / 'recovered-2026-09-30/bytecode-closure/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p / n).read_text())
manifest = read('source206-manifest.json')
previous = read('source204-manifest.json')
assert len(manifest) == 416 and all(sha(checkout / n) == h for n, h in manifest.items())
changed = [n for n, h in manifest.items() if n in previous and previous[n] != h]
added = [n for n in manifest if n not in previous]
assert sorted(changed) == ['src/lisp/native_comp/runtime/record_layout_tests.rs', 'src/lisp/primitives/tests.rs']
assert len(added) == 6 and all(n.startswith('tests/fixtures/bytecode-') for n in added)
assert read('source206-gate-build-result.json')['exit_code'] == 0
result = read('source206-gate-baseline-result.json')
assert result['exit_code'] == 101 and result['source_unchanged']
command = read('source206-gate-baseline-command.json')
names = command['selected_inventory']
assert len(names) == 5 and sha(p / 'source206-gate-libtest') == command['binary_sha256']
inventory = [line[:-6] for line in (p / 'source206-gate-inventory.txt').read_text().splitlines() if line.endswith(': test')]
assert len(inventory) == 2967 and all(name in inventory for name in names)
tree = ast.parse((p / 'audit-shared-reader196-fresh-selected.py').read_text())
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'audit_log')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<raw-auditor>', 'exec'))
raw = (p / 'source206-gate-baseline.log').read_text()
failed = audit_log(names, raw, 1, 4)
assert sorted(failed) == sorted(n for n in names if not n.endswith('::bytecode_closure_constants_and_clone_share_gnu_slots'))
assert 'left: 88\n right: 40' in raw and 'left: 34\n right: 31' in raw
assert 'left: "((before 41 t) (after 193 41))"' in raw
assert 'right: "((before 41 t) (after 193 67))"' in raw
assert 'left: "(41 194)"' in raw and 'right: "(67 194)"' in raw
paths = ['src', 'tests', 'Cargo.toml', 'Cargo.lock', 'build.rs', '.cargo',
         'compat/emacs_compat_runner.el', 'tools/ttydiff.py',
         'tools/fixtures/fieldnotes.org', 'tools/fixtures/fake_lsp_server.py']
archive = subprocess.check_output(['git', 'archive', read('source206-base.json')['commit'], *paths], cwd=repository)
with tempfile.TemporaryDirectory(prefix='source206-patch-', dir='/private/tmp') as temporary:
    temp = Path(temporary)
    with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
        assert all((temp / member.name).resolve().is_relative_to(temp) for member in tar.getmembers())
        tar.extractall(temp)
    apply = subprocess.run(['git', 'apply', '--unsafe-paths', '--directory=' + str(temp), str(p / 'source206-complete.patch')], cwd=repository, capture_output=True, text=True)
    assert apply.returncode == 0, apply.stderr
    assert all(sha(temp / n) == h for n, h in manifest.items())
    assert all(bool((temp / n).stat().st_mode & 0o111) == bool((checkout / n).stat().st_mode & 0o111) for n in manifest)
for fixture in ['bytecode-closure-shared-constants', 'bytecode-code-mutation-baseline', 'bytecode-code-active-mutation-baseline']:
    assert (checkout / 'tests/fixtures' / (fixture + '.el')).read_bytes() == (p / (fixture + '.el')).read_bytes()
record = dict(status='verified negative baseline', inputs=416, raw_passed=1, raw_failed=4,
              changed=changed, added=added, patch_replay_and_modes_verified=True,
              manifest_sha256=sha(p / 'source206-manifest.json'), patch_sha256=sha(p / 'source206-complete.patch'),
              binary_sha256=command['binary_sha256'], failed=failed,
              qualification='Only tests/fixtures differ from runtime204. The constructor/constant/clone/GC/rejected-aset contract passes; both representation assertions and both code-string mutation controls fail. This adds permanent differential controls, not a runtime repair.')
with (p / 'source206-baseline-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record, indent=2))
