from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
base = json.loads((out / 'source246-complete-frozen-macos-terminal-manifest.json').read_text())
present = {row['path'] for row in base['files']}
artifact = p / 'source246-linux-frozen-artifacts'
missing = {str(f.relative_to(p)): f for f in artifact.rglob('*')
           if f.is_file() and str(f.relative_to(p)) not in present}
excluded = {str(artifact.relative_to(p)) + '/oracle-inputs/' + name for name in ['emacs', 'emacs.pdmp']}
assert excluded <= set(missing)
for name in excluded:
    del missing[name]
assert len(missing) == 1039
assert sum(f.suffix == '.loaded' for f in missing.values()) == 1038
assert all(f.suffix in ['.loaded', '.apparmor'] for f in missing.values())
missing[Path(__file__).name] = Path(__file__)
package('source246-frozen-load-markers', missing, dict(
    complements=base['archive'], load_markers=1038, configuration_files=1,
    excluded_binary_paths=sorted(excluded),
    qualification='Completes the first archive extension filter: all 1038 raw loaded markers and the recorded AppArmor profile are preserved unchanged. Together the two archives retain every downloaded frozen artifact member except the explicitly excluded GNU executable and dump, whose hashes and local retained copies are verified separately. No test or verdict changes.'))
