from pathlib import Path
import importlib.util,sys,json,shutil,hashlib,ast
p=Path(__file__).parent.resolve();root=p.parents[2]
sys.path.insert(0,str(root/'tools'))
f=p/'core_runtime_perf_pair.py';ast.parse(f.read_text())
spec=importlib.util.spec_from_file_location('pair',f);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
contract=json.loads((root/'compat/core_runtime_perf.json').read_text());original=p/'source310-native-unit310-pilot-0'
valid=module.audit_pilot(original,contract);assert len(valid)==16
out=p/'source311-linux-pair-adversarial';out.mkdir()
controls={}
for name in ['wrong-result','missing-report','failed-process','incomplete-inventory','duplicate-inventory','wrong-mode']:
 target=out/name;shutil.copytree(original,target)
 records=json.loads((target/'runs.json').read_text());first=records[0]
 location=target/'round-00'/first['case_id']/first['runner']
 if name=='wrong-result':
  report=json.loads((location/'report.json').read_text());report['observations'][0]['result']='incorrect-result'
  (location/'report.json').write_text(json.dumps(report))
 elif name=='missing-report':(location/'report.json').unlink()
 elif name=='failed-process':
  process=json.loads((location/'process.json').read_text());process['exit']=1
  (location/'process.json').write_text(json.dumps(process))
 elif name=='incomplete-inventory':(target/'runs.json').write_text(json.dumps(records[:-1]))
 elif name=='duplicate-inventory':(target/'runs.json').write_text(json.dumps(records+[first]))
 elif name=='wrong-mode':
  report=json.loads((location/'report.json').read_text());report['modes']={'silent_fallback':True}
  (location/'report.json').write_text(json.dumps(report))
 try:module.audit_pilot(target,contract)
 except (ValueError,FileNotFoundError) as error:controls[name]=repr(error)
 else:raise AssertionError('corruption accepted: '+name)
result=dict(status='raw pilot audit and six corruption controls passed',helper_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),original=str(original),actual_cases=16,actual_processes=32,rejections=controls,qualification='Tests raw-evidence validation using retained actual macOS pilot data. Linux pair build/orchestration has not run yet; final runtime or performance acceptance is not established.')
(p/'source311-linux-pair-helper-audit.json').open('x').write(json.dumps(result,indent=2));print(json.dumps(result))
