from pathlib import Path

p = Path(__file__).parent.resolve()
s = (p / 'probe-string-allocation-limits-original.py').read_text()
s = s.replace('string-allocation-limits', 'string-allocation-signal-data')
s = s.replace("[('source270-original',Path(next(n for n in inputs if not n.endswith('.pdmp'))))]", "[('gnu',gnu/'src/emacs'),('source270-original',Path(next(n for n in inputs if not n.endswith('.pdmp'))))]")
with (p / 'probe-string-allocation-signal-data.py').open('x') as out:
    out.write(s)
