from pathlib import Path
import hashlib, json, os, subprocess, time

p = Path(__file__).parent.resolve()
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
original = json.loads((p / 'source276-gate-broad-command.json').read_text())
c = Path(original['working_directory'])
m = json.loads((p / 'source276-manifest.json').read_text())
assert all(sha(c / n) == h for n, h in m.items())
binary = p / 'source276-gate-libtest'
assert sha(binary) == original['binary_sha256']
name = 'lisp::primitives::tests::native_vector_and_closure_census_matches_gnu_word_layout'
assert name in original['selected_inventory']
index = original['selected_inventory'].index(name)
selected = original['selected_inventory'][index-2:index+1]
assert selected[1].endswith('::native_user_ptr_predicate_is_exhaustive_over_the_module_free_value_model')
cmd = [str(binary), *selected, '--exact', '--nocapture', '--test-threads=1']
with (p / 'source276-census-predecessors-command.json').open('x') as out:
    json.dump(dict(command=cmd, working_directory=str(c), environment_override=original['environment_override'], binary_sha256=sha(binary), source_manifest='source276-manifest.json', qualification='Diagnosis of the original broad Emaxx failure with its two immediately preceding controls in a fresh process. Same binary, fixture, expected bytes and environment; no original result is replaced.'), out, indent=2)
started = time.monotonic()
with (p / 'source276-census-predecessors.log').open('xb') as log:
    result = subprocess.run(cmd, cwd=c, env=dict(os.environ, **original['environment_override']), stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, timeout=3600)
record = dict(exit_code=result.returncode, elapsed_seconds=time.monotonic()-started, source_unchanged=all(sha(c / n) == h for n, h in m.items()), log_sha256=sha(p / 'source276-census-predecessors.log'))
with (p / 'source276-census-predecessors-result.json').open('x') as out:
    json.dump(record, out, indent=2)
print(json.dumps(record))
