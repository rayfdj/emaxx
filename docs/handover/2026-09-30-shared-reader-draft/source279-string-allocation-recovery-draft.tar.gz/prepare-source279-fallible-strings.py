from pathlib import Path
import hashlib, json, subprocess

p = Path(__file__).parent.resolve()
root = p.parents[2]
old = p.parent / 'recovered-2026-09-30/string-allocation-negative-fixed/emaxx'
c = p.parent / 'recovered-2026-09-30/string-allocation-recovery/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
m = json.loads((p / 'source278-manifest.json').read_text())
assert len(m) == 511 and all(sha(old / n) == h for n, h in m.items())
assert not c.exists()
c.parent.mkdir(parents=True)
steps = []
for label, cmd in [('checkout', ['git', 'worktree', 'add', '--detach', str(c), 'b5a1558c6b88804cecdbee04a9bdbfab34209ac8']), ('replay', ['git', 'apply', str(p / 'source278-sblocks.patch')])]:
    r = subprocess.run(cmd, cwd=root if label == 'checkout' else c, capture_output=True, text=True)
    steps.append(dict(label=label, command=cmd, exit_code=r.returncode, stdout=r.stdout, stderr=r.stderr))
    r.check_returncode()
assert all(sha(c / n) == h for n, h in m.items())
(c.parent / 'emacs').symlink_to(p.parent / 'rebuilt-2026-10-01/emacs', target_is_directory=True)

def replace(s, before, after, count=1):
    assert s.count(before) == count, (before, s.count(before), count)
    return s.replace(before, after)

f = c / 'src/lisp/alloc/strings/data.rs'
s = f.read_text()
s = replace(s, 'use std::alloc::{Layout, alloc, dealloc, handle_alloc_error};', 'use crate::lisp::types::string_data::StringError;\nuse std::alloc::{Layout, alloc, dealloc};')
s = replace(s, 'unsafe fn new_block(bytes: usize) -> *mut Block {', 'unsafe fn new_block(bytes: usize) -> Result<*mut Block, StringError> {')
s = replace(s, '        handle_alloc_error(layout);', '        return Err(StringError::AllocationFailed);')
s = replace(s, '    block\n}\n', '    Ok(block)\n}\n')
s = replace(s, 'pub(crate) unsafe fn new(owner: *mut SharedStringState, bytes: usize, pure: bool) -> Self {', 'pub(crate) unsafe fn new(owner: *mut SharedStringState, bytes: usize, pure: bool) -> Result<Self, StringError> {')
s = replace(s, 'let block = new_block(HEADER + needed);', 'let block = new_block(HEADER + needed)?;')
s = replace(s, 'let next = new_block(BLOCK_BYTES);', 'let next = new_block(BLOCK_BYTES)?;')
s = replace(s, '        Self {\n            // SAFETY: ENTRY', '        Ok(Self {\n            // SAFETY: ENTRY')
s = replace(s, '            pending: true,\n        }', '            pending: true,\n        })')
f.write_text(s)

f = c / 'src/lisp/alloc/strings.rs'
s = f.read_text()
marker = '/// Allocate the stable header before constructing its data.'
s = replace(s, marker, '''/// Return an incompletely constructed header to the arena on an allocation
/// error or unwind. The content guard is dropped first, so no reference to
/// the cell remains when its first word becomes a free-list link.
struct StringConstruction(*mut StringCell);

impl Drop for StringConstruction {
    fn drop(&mut self) {
        // SAFETY: the initializer has released its exclusive guard. The
        // initialized state owns either empty data or a complete sdata entry.
        unsafe {
            let cell = self.0;
            std::ptr::drop_in_place((*cell).state.get());
            (*cell).mark.set_raw(FREE_MARK);
            cell.cast::<*mut StringCell>()
                .write(FREE_LIST.load(Ordering::Relaxed));
            FREE_LIST.store(cell, Ordering::Relaxed);
        }
    }
}

''' + marker)
s = replace(s, 'pub(crate) fn allocate_string(', 'pub(crate) fn allocate_string<E>(')
s = replace(s, 'initialize: impl FnOnce(&mut SharedStringState),\n) -> StringObjectRef {', 'initialize: impl FnOnce(&mut SharedStringState) -> Result<(), E>,\n) -> Result<StringObjectRef, E> {')
s = replace(s, 'return empty_string(multibyte);', 'return Ok(empty_string(multibyte));')
s = replace(s, '''    let handle = unsafe {
        cell.write(StringCell::new(SharedStringState::empty(multibyte), false));
        (*cell).borrows.set(-1);''', '''    unsafe { cell.write(StringCell::new(SharedStringState::empty(multibyte), false)) };
    let construction = StringConstruction(cell);
    let handle = unsafe {
        (*cell).borrows.set(-1);''')
s = replace(s, '        initialize(&mut guard);', '        initialize(&mut guard)?;')
s = replace(s, '    drop(state);\n    handle\n}', '    drop(state);\n    std::mem::forget(construction);\n    Ok(handle)\n}')
f.write_text(s)

f = c / 'src/lisp/types/string_data.rs'
s = f.read_text()
marker = 'impl StringObjectRef {'
s = replace(s, marker, '''/// Storage construction is independent of an interpreter. Carry allocation
/// failure without allocating a replacement message; the primitive resolves
/// it to the current, preallocated `memory-signal-data` only on error.
#[derive(Debug)]
pub(crate) enum StringError {
    Condition(LispError),
    AllocationFailed,
}

impl From<LispError> for StringError {
    fn from(error: LispError) -> Self {
        Self::Condition(error)
    }
}

impl std::fmt::Display for StringError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Condition(error) => error.fmt(f),
            Self::AllocationFailed => f.write_str("Memory exhausted"),
        }
    }
}

''' + marker)
s = replace(s, '''    ) -> Self {
        crate::lisp::alloc::allocate_string(characters, multibyte, kind, |state| {''', '''    ) -> Result<Self, StringError> {
        validate_size(nbytes)?;
        crate::lisp::alloc::allocate_string(characters, multibyte, kind, |state| {''')
s = replace(s, '                return;\n            }\n            // SAFETY: STATE', '                return Ok(());\n            }\n            // SAFETY: STATE')
s = replace(s, 'unsafe { PendingStringData::new(state, nbytes, kind == StringAllocation::Pure) };', 'unsafe { PendingStringData::new(state, nbytes, kind == StringAllocation::Pure) }?;')
s = replace(s, '            state.props = props.into();\n        })', '            state.props = props.into();\n            Ok(())\n        })')
start = s.index('    fn from_slice(')
end = s.index('    /// character.c:Fstring', start)
before = s[start:end]
after = before.replace('    fn from_slice(', '    fn try_from_slice(').replace('    ) -> Self {', '    ) -> Result<Self, StringError> {')
wrapper = '''    fn from_slice(
        bytes: &[u8],
        characters: usize,
        multibyte: bool,
        props: Vec<StringPropertySpan>,
        kind: StringAllocation,
    ) -> Self {
        Self::try_from_slice(bytes, characters, multibyte, props, kind)
            .expect("infallible string copy allocation")
    }

'''
s = s[:start] + wrapper + after + s[end:]
s = replace(s, 'pub(crate) fn from_characters(characters: &[Value]) -> Result<Self, LispError>', 'pub(crate) fn from_characters(characters: &[Value]) -> Result<Self, StringError>')
# These three constructors also validate Lisp data before allocating.
for method in ['repeated_character', 'from_storage', 'from_storage_kind']:
    a = s.index('    pub(crate) fn ' + method + '(')
    b = s.index(' {', a)
    header = s[a:b]
    assert 'Result<Self, LispError>' in header
    s = s[:a] + header.replace('Result<Self, LispError>', 'Result<Self, StringError>') + s[b:]
for method, next_method in [('from_characters', 'repeated_character'), ('repeated_character', 'from_unibyte')]:
    a = s.index('    pub(crate) fn ' + method + '(')
    b = s.index('    pub(crate) fn ' + next_method + '(', a)
    part = s[a:b]
    part = replace(part, 'Ok(Self::from_data(', 'Self::from_data(')
    part = replace(part, '        ))\n    }', '        )\n    }')
    s = s[:a] + part + s[b:]
s = replace(s, '''                "String character count does not match its bytes".into(),
            ));''', '''                "String character count does not match its bytes".into(),
            ).into());''')
s = replace(s, '''        Ok(Self::from_slice(
            &bytes,
            characters,
            multibyte,
            Vec::new(),
            kind,
        ))''', '''        Self::try_from_slice(&bytes, characters, multibyte, Vec::new(), kind)''')
s = replace(s, 'pub(crate) fn store_character(&mut self, index: usize, code: u32) -> Result<bool, LispError>', 'pub(crate) fn store_character(&mut self, index: usize, code: u32) -> Result<bool, StringError>')
needle = 'let allocation = unsafe { PendingStringData::new(self, nbytes, false) };'
assert s.count(needle) == 2
s = s.replace(needle, 'let allocation = unsafe { PendingStringData::new(self, nbytes, false) }\n                    .expect("infallible string replacement allocation");', 1)
s = replace(s, needle, 'let allocation = unsafe { PendingStringData::new(self, nbytes, false) }?;')
s = replace(s, '    if length >= isize::MAX as usize - 16 {', '''    // lisp.h:STRING_BYTES_BOUND and alloc.c:STRING_BYTES_MAX. On the
    // supported 64-bit targets the 61-bit fixnum bound is the tightest.
    if length > (1usize << 61) - 1 {''')
f.write_text(s)

f = c / 'src/lisp/types/string_data/concat.rs'
s = f.read_text()
s = replace(s, 'use super::{Kind, LispError, StringObjectRef, StringPropertySpan, Value};', 'use super::{Kind, LispError, StringError, StringObjectRef, StringPropertySpan, Value};')
s = replace(s, 'pub(crate) fn concatenate(args: &[Value]) -> Result<Self, LispError>', 'pub(crate) fn concatenate(args: &[Value]) -> Result<Self, StringError>')
s = replace(s, '        Ok(Self::from_data(', '        Self::from_data(')
s = replace(s, '        ))\n    }', '        )\n    }')
f.write_text(s)

f = c / 'src/lisp/primitives/strings.rs'
s = f.read_text()
marker = '/// fns.c:validate_subarray'
s = replace(s, marker, '''/// alloc.c:memory_full signals with the existing Vmemory_signal_data. Rust
/// storage builders have no interpreter, so resolve their typed failure at
/// the primitive body, including generated direct and native dispatch.
pub(crate) fn string_storage_error(
    interp: &Interpreter,
    env: &Env,
    error: crate::lisp::types::string_data::StringError,
) -> LispError {
    use crate::lisp::types::string_data::StringError;
    match error {
        StringError::Condition(error) => error,
        StringError::AllocationFailed => LispError::SignalValue(
            interp.lookup_var("memory-signal-data", env).unwrap_or(Value::Nil),
        ),
    }
}

''' + marker)
a = s.index('pub(crate) fn aset_string_value(')
b = s.index('pub(crate) fn shared_string_props', a)
part = s[a:b]
part = replace(part, ') -> Result<Value, LispError> {', ') -> Result<Value, crate::lisp::types::string_data::StringError> {')
part = replace(part, 'return Err(LispError::WrongTypeArgument("stringp".into(), *target));', 'return Err(LispError::WrongTypeArgument("stringp".into(), *target).into());')
part = replace(part, 'return Err(args_out_of_range_for_aset(target, index));', 'return Err(args_out_of_range_for_aset(target, index).into());')
part = replace(part, '        ])));', '        ])).into());')
s = s[:a] + part + s[b:]
f.write_text(s)

f = c / 'src/lisp/primitives/dispatch/strings.rs'
s = f.read_text()
s = replace(s, '''                    args.get(2).is_some_and(Value::is_truthy),
                )?))''', '''                    args.get(2).is_some_and(Value::is_truthy),
                ).map_err(|error| string_storage_error(interp, env, error))?))''')
s = replace(s, 'StringObjectRef::concatenate(args)?', 'StringObjectRef::concatenate(args).map_err(|error| string_storage_error(interp, env, error))?')
s = replace(s, 'StringObjectRef::from_characters(args)?', 'StringObjectRef::from_characters(args).map_err(|error| string_storage_error(interp, env, error))?', 2)
f.write_text(s)

f = c / 'src/lisp/primitives/dispatch/collections.rs'
s = f.read_text()
s = replace(s, 'aset_string_value(&args[0], idx, &args[2])?;', 'aset_string_value(&args[0], idx, &args[2]).map_err(|error| string_storage_error(interp, env, error))?;')
f.write_text(s)

changed = {n for n in m if sha(c / n) != m[n]}
assert changed == {
    'src/lisp/alloc/strings/data.rs', 'src/lisp/alloc/strings.rs',
    'src/lisp/types/string_data.rs', 'src/lisp/types/string_data/concat.rs',
    'src/lisp/primitives/strings.rs', 'src/lisp/primitives/dispatch/strings.rs',
    'src/lisp/primitives/dispatch/collections.rs',
}
assert sha(c / 'src/lisp/native_comp/runtime.rs') == m['src/lisp/native_comp/runtime.rs']
with (p / 'source279-preparation.json').open('x') as out:
    json.dump(dict(candidate=str(c), steps=steps, source278_inputs_verified=len(m), changed=sorted(changed), qualification='Fallible sdata allocation and header cleanup, actual GNU byte bound and preallocated Lisp error identity. All three new negative controls and every earlier assertion remain unchanged. Process-wide actual exhaustion, reserve memory and infallible host allocation handling remain broader incomplete work.', goal_complete=False), out, indent=2)
print('Source279 repair prepared for review; not yet frozen or validated.')
