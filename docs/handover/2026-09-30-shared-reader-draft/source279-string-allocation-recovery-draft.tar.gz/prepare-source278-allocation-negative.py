from pathlib import Path
import hashlib, json, subprocess

p = Path(__file__).parent.resolve()
root = p.parents[2]
old = p.parent / 'recovered-2026-09-30/string-allocation-negative/emaxx'
c = p.parent / 'recovered-2026-09-30/string-allocation-negative-fixed/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
m = json.loads((p / 'source277-manifest.json').read_text())
assert all(sha(old / n) == h for n, h in m.items())
assert json.loads((p / 'source277-probe-result.json').read_text())['results'][-1]['exit_code'] == 101
assert not c.exists()
c.parent.mkdir(parents=True)
steps = []
for label, cmd in [('checkout', ['git', 'worktree', 'add', '--detach', str(c), 'b5a1558c6b88804cecdbee04a9bdbfab34209ac8']), ('replay', ['git', 'apply', str(p / 'source277-sblocks.patch')])]:
    r = subprocess.run(cmd, cwd=root if label == 'checkout' else c, capture_output=True, text=True)
    steps.append(dict(label=label, command=cmd, exit_code=r.returncode, stdout=r.stdout, stderr=r.stderr))
    r.check_returncode()
assert all(sha(c / n) == h for n, h in m.items())
(c.parent / 'emacs').symlink_to(p.parent / 'rebuilt-2026-10-01/emacs', target_is_directory=True)
f = c / 'src/lisp/native_comp/runtime.rs'
s = f.read_text()
before = 'assert_eq!(small.borrow().character_at(2), Some(code));'
assert s.count(before) == 1
f.write_text(s.replace(before, 'assert_eq!(small.borrow().character_at(2), Some(i64::from(code)));'))
assert all(sha(c / n) == h for n, h in m.items() if n != 'src/lisp/native_comp/runtime.rs')
t = c / 'target/string-sblock-validation'
t.parent.mkdir()
cmd = ['/bin/cp', '-cR', str(old / 'target/string-sblock-validation'), str(t)]
with (p / 'source278-cache-clone.log').open('xb') as log:
    subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, check=True)
with (p / 'source278-preparation.json').open('x') as out:
    json.dump(dict(candidate=str(c), steps=steps, source277_inputs_verified=len(m), qualification='Only change: lossless u32-to-i64 conversion in the new character assertion. Source277 compilation failure remains; production and all test semantics unchanged.', goal_complete=False), out, indent=2)
s = (p / 'run-source277-allocation-negative.py').read_text().replace('source277', 'source278').replace('recovered-2026-09-30/string-allocation-negative/emaxx', 'recovered-2026-09-30/string-allocation-negative-fixed/emaxx')
with (p / 'run-source278-allocation-negative.py').open('x') as out:
    out.write(s)
print('Source278 test-only compiler correction prepared.')
