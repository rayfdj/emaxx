from pathlib import Path
import hashlib, json, re

p = Path(__file__).parent.resolve()
c = p.parent / 'recovered-2026-09-30/string-data-pools/emaxx'
negative = p.parent / 'recovered-2026-09-30/string-allocation-negative-fixed/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p / n).read_text())
m = read('source276-manifest.json')
assert len(m) == 511 and all(sha(c / n) == h for n, h in m.items())
command = read('source276-gate-broad-command.json')
result = read('source276-gate-broad-result.json')
assert sha(p / 'source276-gate-libtest') == command['binary_sha256']
assert result['exit_code'] == 101 and result['source_unchanged']
expected = command['selected_inventory']
raw = (p / 'source276-gate-broad.log').read_text()
starts = list(re.finditer(r'^test (\S+) \.\.\. ', raw, re.M))
assert [match[1] for match in starts] == expected and len(expected) == 1064
verdicts = {}
for i, match in enumerate(starts):
    segment = raw[match.end():starts[i+1].start() if i+1 < len(starts) else raw.index('\nfailures:\n', match.end())]
    statuses = re.findall(r'(?:^|\s)(ok|FAILED|ignored)(?:,.*)?\s*\Z', segment)
    assert len(statuses) == 1, (match[1], statuses)
    verdicts[match[1]] = statuses[0]
failures = [n for n, status in verdicts.items() if status != 'ok']
assert failures == ['lisp::primitives::tests::native_vector_and_closure_census_matches_gnu_word_layout']
assert '1063 passed; 1 failed; 0 ignored;' in raw
assert '((0 -130) (1 2)' in raw
assert 'src/lisp/primitives/tests.rs:13406:5' in raw
source_lines = (c / 'src/lisp/primitives/tests.rs').read_text().splitlines()
assert source_lines[13405] == '    assert_eq!(printed, expected);'
queue = read('source276-selected-state.json')
assert len(queue['results']) == 3 and queue['results'][-1]['exit_code'] == 101
assert not (p / 'source276-release-build-command.json').exists()
n = read('source278-manifest.json')
assert all(sha(negative / path) == digest for path, digest in n.items())
assert all(n[path] == digest for path, digest in m.items() if path != 'src/lisp/native_comp/runtime.rs')
state = read('source278-probe-result.json')
assert len(state['results']) == 9
assert all(row['exit_code'] == 0 for row in state['results'][:6])
assert [row['exit_code'] for row in state['results'][6:]] == [-6, -6, -6]
for index in range(1, 4):
    log = (p / f'source278-gate-negative-{index}.log').read_text()
    assert log.count('running 1 test') == 1 and 'memory allocation of ' in log and ' bytes failed' in log
    assert 'test result:' not in log
assert sha(p / 'source278-gate-libtest') == read('source278-binary.json')['sha256']
record = dict(status='failed: isolated source276 broad GC-census difference and three source278 allocator aborts', source276_inputs_verified=511, source278_inputs_verified=511, source276_broad=dict(passed=1063, failed=1, ignored=0, failed_test=failures[0], side='Emaxx assertion after GNU passed', first_empty_vector_delta=-130, expected_delta=0, later_vector_and_closure_rows='identical', release='not started', raw_sha256=sha(p / 'source276-gate-broad.log')), source276_focused=dict(passed=208, existing_ignores=2), source278_negative=dict(controls=3, passed=0, aborts=3, exit_codes=[-6,-6,-6], production='same as source276', original_source277_compiler_error='new assertion compared Option<i64> with Option<u32>; source278 only adds lossless conversion'), qualification='The GC-census failure is in Emaxx, unlike earlier GNU reference failures. It remains unresolved and is not normalized. The abort controls run separately and retain every raw exit. Applied task runtime stays source272; main unchanged. Full validation/performance/audit remain required.', goal_complete=False)
with (p / 'source276-broad-and278-negative-audit.json').open('x') as out:
    json.dump(record, out, indent=2)
print(json.dumps(record, indent=2))
