from pathlib import Path
import hashlib, json, subprocess

p = Path(__file__).parent.resolve()
c = p.parent / 'recovered-2026-09-30/string-allocation-recovery/emaxx'
old = p.parent / 'recovered-2026-09-30/string-allocation-negative-fixed/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
state = json.loads((p / 'source278-probe-result.json').read_text())
assert all(r['exit_code'] == 0 for r in state['results'][:6])
assert [r['exit_code'] for r in state['results'][6:]] == [-6, -6, -6]
m = json.loads((p / 'source278-manifest.json').read_text())
assert all(sha(old / n) == h for n, h in m.items())
assert sha(c / 'src/lisp/native_comp/runtime.rs') == m['src/lisp/native_comp/runtime.rs']
t = c / 'target/string-sblock-validation'
t.parent.mkdir()
cmd = ['/bin/cp', '-cR', str(old / 'target/string-sblock-validation'), str(t)]
with (p / 'source279-cache-clone.log').open('xb') as log:
    subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, check=True)
s = (p / 'run-source278-allocation-negative.py').read_text().replace('source278', 'source279').replace('recovered-2026-09-30/string-allocation-negative-fixed/emaxx', 'recovered-2026-09-30/string-allocation-recovery/emaxx')
count = len(subprocess.check_output(['git', 'diff', '--name-only'], cwd=c, text=True).splitlines())
assert count == 16
s = s.replace("'gate-negative-'", "'gate-recovery-'")
with (p / 'run-source279-fallible-strings.py').open('x') as out:
    out.write(s)
with (p / 'source279-negative-precondition.json').open('x') as out:
    json.dump(dict(source278_aborts=[r for r in state['results'][6:]], source278_inputs_verified=len(m), new_tests_unchanged=True, qualification='No negative assertion changed. The predecessor aborts in each of the three controls; repair remains unvalidated.'), out, indent=2)
