from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).parent.resolve();gnu=p.parent/'rebuilt-2026-10-01/emacs'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
inputs=json.loads((p/'source270-ordinary-artifacts.json').read_text())
for original,r in inputs.items():assert sha(Path(original))==sha(Path(r['immutable_copy']))==r['sha256']
fixture=p/'string-allocation-limits.el';program='(prin1 '+fixture.read_text()+')'
records=[]
for editor,binary in [('gnu',gnu/'src/emacs'),('source270',p/'source270-ordinary-emaxx')]:
 paths=[fixture,Path(__file__),binary,binary.with_suffix('.pdmp')]
 if editor=='gnu':paths += [gnu/'src/config.h',gnu/'src/Makefile']
 hashes={str(f):sha(f) for f in paths};cmd=[str(binary),'-Q','--batch','--eval',program]
 with (p/('string-allocation-limits-'+editor+'-command.json')).open('x') as f:json.dump(dict(command=cmd,working_directory=str(p),environment_override={'LANG':'C','LC_ALL':'C','EMAXX_GC_VERIFY':'1'},inputs=hashes,timeout_seconds=120,qualification='Ordinary same-input error-path diagnosis. Requested virtual sizes exceed the supported hosts address spaces; no memory-limit/timeout or expected-output relaxation. Source276 is not executed by this baseline probe.'),f,indent=2)
 start=time.monotonic()
 try:
  r=subprocess.run(cmd,cwd=p,env=dict(os.environ,LANG='C',LC_ALL='C',EMAXX_GC_VERIFY='1'),stdin=subprocess.DEVNULL,capture_output=True,timeout=120);code,out,err,timed=r.returncode,r.stdout,r.stderr,False
 except subprocess.TimeoutExpired as e:code,out,err,timed=None,e.stdout or b'',e.stderr or b'',True
 for suffix,b in [('stdout',out),('stderr',err)]:
  with (p/('string-allocation-limits-'+editor+'.'+suffix)).open('xb') as f:f.write(b)
 record=dict(editor=editor,exit_code=code,timed_out=timed,elapsed_seconds=time.monotonic()-start,stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),inputs_unchanged=all(sha(Path(n))==h for n,h in hashes.items()))
 with (p/('string-allocation-limits-'+editor+'-result.json')).open('x') as f:json.dump(record,f,indent=2)
 records.append(record);print(editor,code,repr(out),repr(err[:800]),flush=True)
with (p/'string-allocation-limits-baseline.json').open('x') as f:json.dump(dict(results=records,goal_complete=False,qualification='Baseline error-path outputs retained without normalization. Any mismatch remains failed evidence; source276 is separate.'),f,indent=2)
