from pathlib import Path
import hashlib, json, os, subprocess, sys

p = Path(__file__).parent.resolve()
c = p.parent / 'recovered-2026-09-30/string-allocation-recovery/emaxx'
helper = p / 'queue-source279-fallible-selected.py'
command = [sys.executable, '-B', str(helper)]
with (p / 'source279-selected-driver.log').open('xb') as log:
    process = subprocess.Popen(command, cwd=c, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True, env=dict(os.environ, PYTHONUNBUFFERED='1', PYTHONDONTWRITEBYTECODE='1'))
record = dict(pid=process.pid, command=command, helper_sha256=hashlib.sha256(helper.read_bytes()).hexdigest(), source_manifest='source279-manifest.json', candidate=str(c), qualification='Launch only: 213 focused selectors and 1067 affected controls in each profile, followed by 37 ordinary GNU comparisons. Retain any failure; no broader pass is implied.', goal_complete=False)
with (p / 'source279-selected-launch.json').open('x') as out:
    json.dump(record, out, indent=2)
print(json.dumps(record, indent=2))
