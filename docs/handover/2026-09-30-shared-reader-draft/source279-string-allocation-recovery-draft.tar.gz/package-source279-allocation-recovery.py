from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda b: hashlib.sha256(b).hexdigest()
read = lambda n: json.loads((p / n).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
audit = read('source279-freeze-and-probe-audit.json')
assert audit['source_inputs_verified'] == 511
focused = read('source279-focused-audit.json')
assert focused['status'] == 'passed' and focused['counts'] == {'ok': 211, 'FAILED': 0, 'ignored': 2}
failed = read('source276-broad-and278-negative-audit.json')
assert failed['source276_broad']['failed'] == 1 and failed['source278_negative']['aborts'] == 3
tty = read('source270-macos-terminal-audit.json')
assert tty['status'] == 'passed' and tty['fully_matching_scenarios'] == 226 and tty['matching_comparisons'] == 686
state = read('source279-selected-state.json')
with (p / 'source279-selected-at-recovery-packaging.json').open('x') as f:
    json.dump(state, f, indent=2)
files = {}
allow = {'.json', '.log', '.patch', '.py', '.el', '.expected', '.stdout', '.stderr', '.txt'}
excluded = ('source279-selected-state', 'source279-selected-driver', 'source279-selected-result', 'source279-gate-broad', 'source279-release', 'source279-ordinary')
for f in p.iterdir():
    if not f.is_file() or f.suffix not in allow:
        continue
    if f.name.startswith(('source277-', 'source278-', 'source279-', 'string-allocation-limits', 'string-allocation-signal-data')) and not f.name.startswith(excluded):
        files[f.name] = f
helpers = {
    'source276-manifest.json', 'source276-binary.json', 'source276-focused-audit.json',
    'source276-gate-inventory.log', 'source276-gate-controls-command.json',
    'source276-gate-broad-command.json', 'source276-gate-broad-result.json', 'source276-gate-broad.log',
    'source276-selected-result.json', 'source276-broad-and278-negative-audit.json',
    'source276-failure-audit-parser-correction.json',
    'audit-source276-broad-and278-negative.py', 'audit-source276-broad-and278-negative-successor.py',
    'audit-source276-broad-and278-negative-final.py', 'prepare-source276-failure-audit-successor.py',
    'replay-source276-census-alone.py', 'replay-source276-census-predecessors.py',
    'source276-census-alone-command.json', 'source276-census-alone-result.json', 'source276-census-alone.log',
    'source276-census-predecessors-command.json', 'source276-census-predecessors-result.json', 'source276-census-predecessors.log',
    'prepare-source277-allocation-negative.py', 'run-source277-allocation-negative.py',
    'prepare-source278-allocation-negative.py', 'run-source278-allocation-negative.py',
    'prepare-source279-fallible-strings.py', 'prepare-source279-validation.py',
    'prepare-source279-validation-successor.py', 'run-source279-fallible-strings.py',
    'freeze-source279-fallible-strings.py', 'prepare-source279-selected.py',
    'launch-source279-selected.py', 'queue-source279-fallible-selected.py',
    'run-fallible-strings-focused.py', 'audit-fallible-strings-focused.py', 'test-fallible-strings-broad.py',
    'run-fallible-strings-release.py', 'audit-fallible-strings-release.py',
    'build-fallible-strings-ordinary.py', 'compare-fallible-string-fixtures.py',
    'probe-string-allocation-limits.py', 'probe-string-allocation-limits-original.py',
    'prepare-string-allocation-signal-probe.py', 'probe-string-allocation-signal-data.py',
    'source270-ordinary-artifacts.json', 'source270-selected-audit.json',
    'prepare-source270-terminal-audit.py', 'audit-source270-macos-terminal.py',
    'source270-macos-terminal-audit.json', 'source270-full-tty-command.json',
    'source270-full-tty-result.json', 'source270-full-tty-inventory.json', 'source270-full-tty.log',
    'source270-full-queue-result.json', 'source270-macos-frozen-audit.json',
    'audit-source272-eglot-completion-path.py', 'source272-eglot-completion-path-audit.json',
    'source272-manifest.json', 'package-source196-failure-and197-results.py', Path(__file__).name,
}
for name in helpers:
    assert (p / name).is_file(), name
    files[name] = p / name
files['gnu-eglot-tests.el'] = p.parent / 'rebuilt-2026-10-01/emacs/test/lisp/progmodes/eglot-tests.el'
package('source279-string-allocation-recovery-draft', files, dict(
    repair=audit, focused=focused, original_failures=failed, terminal=tty,
    eglot_review=read('source272-eglot-completion-path-audit.json'),
    launch=read('source279-selected-launch.json'), selected_at_packaging=state,
    dependencies=['source276-string-sblocks-draft', 'source270-complete-frozen-platforms', 'source272-complete-linux-frozen-failure'],
    qualification='Isolated, unapplied source279; task runtime remains source272 and main21d20f0e. Exact511-input replay and three previously aborting unchanged controls now pass; strict checks and211 focused gate tests pass with2 existing ignores. Source276 broader Emaxx census failure remains unresolved. Source279 affected/release/ordinary validation is running and its live logs are excluded. Original source277 compilation error, source278 aborts, source279 preparation-count error and failed raw-log parser attempts are retained. Complete source270 terminal pass is separate. Eglot review is bounded and does not certify universal absence of cheating or a speedup. Actual executables/images remain locally retained; portable archive holds their hashes and rebuild instructions. Full architecture, accounting, ownership, final validation and locked performance goals remain incomplete.', goal_complete=False))
