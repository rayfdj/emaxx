from pathlib import Path
import ast, hashlib, json

p = Path(__file__).parent.resolve()
helpers = {}
for name in ['run-string-pools-focused.py', 'audit-string-pools-focused.py', 'test-string-pools-broad.py', 'run-string-pools-release.py', 'audit-string-pools-release.py']:
    s = (p / name).read_text().replace('string-data-pools/emaxx', 'string-allocation-recovery/emaxx')
    s = s.replace('3026', '3029').replace('3025', '3028').replace('== 210', '== 213').replace('selectors=210', 'selectors=213').replace('All 210 release', 'All 213 release').replace('==1064', '==1067')
    if name == 'run-string-pools-focused.py':
        s = s.replace("len(probe['results']) == 7", "len(probe['results']) == 11")
    if 'extra_names = {' in s:
        s = s.replace('extra_names = {', "extra_names = {\n    'string_sdata_allocation_failure_keeps_header_and_block_census',\n    'string_allocation_failure_uses_bound_signal_and_native_exit',\n    'string_size_bound_is_gnu_fixnum_maximum',")
    if name == 'test-string-pools-broad.py':
        s = s.replace("print('Selected broad existing modules:'", "pools=json.loads((p/'source276-gate-broad-command.json').read_text())['selected_inventory']\nassert len(pools)==1064 and set(pools)<=set(names)\nprint('Selected broad existing modules:'")
        s = s.replace('All 1062 source272 affected-module controls remain, plus two new allocation/compaction/resize controls.', 'All 1064 source276 affected-module controls remain, plus three allocation failure and bound controls. The original source276 broad failure remains retained.')
    dest = name.replace('string-pools', 'fallible-strings')
    ast.parse(s)
    with (p / dest).open('x') as out:
        out.write(s)
    helpers[dest] = hashlib.sha256(s.encode()).hexdigest()
for source, dest in [('build-string-storage-ordinary.py', 'build-fallible-strings-ordinary.py'), ('compare-string-storage-fixtures.py', 'compare-fallible-string-fixtures.py')]:
    s = (p / source).read_text().replace('string-storage/emaxx', 'string-allocation-recovery/emaxx').replace('target/string-storage-validation', 'target/string-sblock-validation')
    ast.parse(s)
    with (p / dest).open('x') as out:
        out.write(s)
    helpers[dest] = hashlib.sha256(s.encode()).hexdigest()
names = [s[:-6] for s in (p / 'source279-gate-inventory.log').read_text().splitlines() if s.endswith(': test')]
prior = json.loads((p / 'source276-gate-controls-command.json').read_text())['selectors']
old = json.loads((p / 'source249-gate-controls-command.json').read_text())['command']
base = {n for n in old[1:] if '::' in n and not n.startswith('-')}
for helper in ['run-fallible-strings-focused.py', 'run-fallible-strings-release.py']:
    t = ast.parse((p / helper).read_text())
    extra = ast.literal_eval(next(n.value for n in t.body if isinstance(n, ast.Assign) and any(isinstance(a, ast.Name) and a.id == 'extra_names' for a in n.targets)))
    selected = base | {n for n in names if n.rsplit('::', 1)[-1] in extra}
    assert len(selected) == 213 and set(prior) <= selected and selected <= set(names)
broad = [n for n in names if n.startswith(('lisp::bytecode::', 'lisp::native_comp::runtime::', 'lisp::primitives::pdumper::', 'lisp::primitives::tests::', 'lisp::reader::', 'lisp::types::', 'lisp::primitives::compat_runtime_tests::'))]
assert len(broad) == 1067
assert set(json.loads((p / 'source276-gate-broad-command.json').read_text())['selected_inventory']) <= set(broad)
with (p / 'source279-selected-preparation.json').open('x') as out:
    json.dump(dict(helpers=helpers, focused=213, broad=1067, qualification='Every inherited selector, assertion, timeout, ignore and expected byte remains. Source276 broad failure and source278 aborts are preserved. Fresh process controls pass but do not close the broad failure.', goal_complete=False), out, indent=2)
