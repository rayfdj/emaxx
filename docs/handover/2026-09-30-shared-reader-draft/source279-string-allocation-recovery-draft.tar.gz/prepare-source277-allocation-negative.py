from pathlib import Path
import hashlib, json, subprocess, time

p = Path(__file__).parent.resolve()
root = p.parents[2]
old = p.parent / 'recovered-2026-09-30/string-data-pools/emaxx'
c = p.parent / 'recovered-2026-09-30/string-allocation-negative/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
m = json.loads((p / 'source276-manifest.json').read_text())
assert all(sha(old / n) == h for n, h in m.items())
assert not c.exists()
c.parent.mkdir(parents=True)
steps = []
for label, cmd in [('checkout', ['git', 'worktree', 'add', '--detach', str(c), 'b5a1558c6b88804cecdbee04a9bdbfab34209ac8']), ('replay', ['git', 'apply', str(p / 'source276-sblocks.patch')])]:
    r = subprocess.run(cmd, cwd=root if label == 'checkout' else c, capture_output=True, text=True)
    steps.append(dict(label=label, command=cmd, exit_code=r.returncode, stdout=r.stdout, stderr=r.stderr))
    r.check_returncode()
assert all(sha(c / n) == h for n, h in m.items())
(c.parent / 'emacs').symlink_to(p.parent / 'rebuilt-2026-10-01/emacs', target_is_directory=True)
f = c / 'src/lisp/native_comp/runtime.rs'
s = f.read_text()
marker = '    #[test]\n    fn string_sblocks_compact_unborrowed_data_and_hold_borrowed_blocks()'
assert s.count(marker) == 1
tests = r'''
    #[test]
    fn string_sdata_allocation_failure_keeps_header_and_block_census() {
        use crate::lisp::types::StringObjectRef;
        let _interpreter = Interpreter::new();
        for code in [97, 128, 0x20_0000] {
            let headers = crate::lisp::alloc::live_string_object_census();
            let blocks = crate::lisp::alloc::string_data_census();
            let error = StringObjectRef::repeated_character(code, 1usize << 58, false)
                .expect_err("an impossible address-space request must be recoverable");
            assert_eq!(error.to_string(), "Memory exhausted");
            assert_eq!(crate::lisp::alloc::live_string_object_census(), headers);
            assert_eq!(crate::lisp::alloc::string_data_census(), blocks);
            let small = StringObjectRef::repeated_character(code, 3, false)
                .expect("allocation still works after the error");
            assert_eq!(small.borrow().len(), 3);
            assert_eq!(small.borrow().character_at(2), Some(code));
        }
    }

    #[test]
    fn string_allocation_failure_uses_bound_signal_and_native_exit() {
        let mut interpreter = Interpreter::new();
        let mut environment = Env::new();
        let mut runtime = NativeRuntime::default();
        let payload = Value::list([Value::symbol("error"), Value::string("allocation-probe-47")]);
        interpreter.set_variable("memory-signal-data", payload, &mut environment);
        interpreter.set_variable("memory-full", Value::Nil, &mut environment);
        for code in [97, 128, 0x20_0000] {
            let args = [Value::Integer(1_i64 << 58), Value::Integer(code)];
            let error = crate::lisp::primitives::call(
                &mut interpreter, "make-string", &args, &mut environment,
            ).expect_err("ordinary primitive allocation failure");
            assert!(crate::lisp::eval::error_condition_value(&error).eq_value(payload));
            let error = runtime.invoke(
                &mut interpreter,
                &mut environment,
                call_funcall_two as *const c_void,
                NativeCallingConvention::Fixed,
                &[Value::symbol("make-string"), args[0], args[1]],
            ).expect_err("native nonlocal exit carries the same Lisp condition");
            assert!(crate::lisp::eval::error_condition_value(&error).eq_value(payload));
            assert_eq!(interpreter.lookup_var("memory-full", &environment), Some(Value::Nil));
        }
    }

    #[test]
    fn string_size_bound_is_gnu_fixnum_maximum() {
        use crate::lisp::types::StringObjectRef;
        let _interpreter = Interpreter::new();
        for code in [128, 0x20_0000] {
            let error = StringObjectRef::repeated_character(
                code, MOST_POSITIVE_FIXNUM as usize, false,
            ).expect_err("GNU rejects a byte count beyond its fixnum bound before allocating");
            assert_eq!(error.to_string(), "Maximum string size exceeded");
        }
    }

'''
f.write_text(s.replace(marker, tests + marker))
assert all(sha(c / n) == h for n, h in m.items() if n != 'src/lisp/native_comp/runtime.rs')
t = c / 'target/string-sblock-validation'
t.parent.mkdir()
idle_cache = p.parent / 'recovered-2026-09-30/string-sblock-layout/emaxx/target/string-sblock-validation'
cmd = ['/bin/cp', '-cR', str(idle_cache), str(t)]
with (p / 'source277-cache-clone.log').open('xb') as log:
    started = time.monotonic()
    r = subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL)
steps.append(dict(label='idle-source275-cache-clone', command=cmd, exit_code=r.returncode, elapsed_seconds=time.monotonic()-started))
r.check_returncode()
with (p / 'source277-preparation.json').open('x') as out:
    json.dump(dict(candidate=str(c), steps=steps, source276_inputs_verified=len(m), qualification='Test-only successor; all production inputs and earlier controls unchanged. Source276 selected validation is independent and continues on its frozen input.', goal_complete=False), out, indent=2)
s = (p / 'run-source276-sblocks.py').read_text().replace('source276', 'source277').replace('recovered-2026-09-30/string-data-pools/emaxx', 'recovered-2026-09-30/string-allocation-negative/emaxx').replace('== 3026', '== 3029')
a = s.index('    controls = [')
b = s.index('    state[\'status\']', a)
s = s[:a] + '''    controls = [
        'string_sdata_allocation_failure_keeps_header_and_block_census',
        'string_allocation_failure_uses_bound_signal_and_native_exit',
        'string_size_bound_is_gnu_fixnum_maximum',
    ]
    for index, name in enumerate(controls):
        selector = 'lisp::native_comp::runtime::tests::' + name
        assert selector in names
        run('gate-negative-' + str(index + 1), [str(binary), '--test-threads=1', '--nocapture', '--exact', selector])
''' + s[b:]
s = s.replace("len(state['results']) == 7", "len(state['results']) == 9")
with (p / 'run-source277-allocation-negative.py').open('x') as out:
    out.write(s)
print('Source277 test-only allocation controls prepared.')
