from pathlib import Path
import json

p = Path(__file__).parent.resolve()
s = (p / 'audit-source276-broad-and278-negative.py').read_text()
before = "statuses = re.findall(r'^(ok|FAILED|ignored)(?:,.*)?$', segment, re.M)"
assert s.count(before) == 1
s = s.replace(before, "statuses = re.findall(r'(?:^|[ ])(ok|FAILED|ignored)(?:,.*)?\\s*\\Z', segment)")
with (p / 'audit-source276-broad-and278-negative-successor.py').open('x') as out:
    out.write(s)
with (p / 'source276-failure-audit-parser-correction.json').open('x') as out:
    json.dump(dict(original_helper='audit-source276-broad-and278-negative.py', failure='Parser required a verdict at the start of its line; one existing test prints a non-newline interactive prompt before its terminal ok verdict.', correction='Require exactly one terminal verdict at the end of each test segment, allowing the existing prompt prefix. Keep original names, order, counts, failed assertion and summary requirements unchanged.'), out, indent=2)
