from pathlib import Path
import hashlib, json, subprocess

p = Path(__file__).parent.resolve()
root = p.parents[2]
raw = p / 'source272-linux-frozen-artifacts/compat/frozen-1790895076878508789-5621'
case = raw / 'test/lisp/progmodes/eglot-tests.compat'
gnu = p.parent / 'rebuilt-2026-10-01/emacs'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda f: json.loads(f.read_text())
manifest = read(p / 'source272-manifest.json')
assert all(sha(root / n) == h for n, h in manifest.items())
contract = read(raw / 'contract.json')
execution = read(case / 'execution.json')
assert execution['contract_sha256'] == sha(raw / 'contract.json')
assert all(sha(case / n) == h for n, h in execution['sha256'].items())
name = 'eglot-test-rust-completion-exit-function'
results = {}
for editor in ['emaxx', 'oracle']:
    report = read(case / (editor + '.json'))
    results[editor] = next(row for row in report['results'] if row['name'] == name)
    assert name in report['selected_tests']
    run = read(case / (editor + '.execution.json'))
    assert run['process']['command'][0] == contract['provenance']['subject_binary' if editor == 'emaxx' else 'oracle_binary']
assert results['emaxx']['status'] == 'passed' and results['emaxx']['expected']
assert results['oracle']['status'] == 'failed' and not results['oracle']['expected']
assert 'Timed out' in results['oracle']['message']
log = (case / 'emaxx.log').read_text()
a = log.index('[' + name + ']: test start')
b = log.index('[' + name + ']: OK', a)
assert "Server `rust-analyzer'" in log[a:b]
assert 'Making completion list...' in log[a:b]
fixture = gnu / 'test/lisp/progmodes/eglot-tests.el'
assert subprocess.check_output(['git', 'show', '636f166cfc86aa90d63f592fd99f3fdd9ef95ebd:test/lisp/progmodes/eglot-tests.el'], cwd=gnu) == fixture.read_bytes()
source = fixture.read_text()
a = source.index('(ert-deftest ' + name)
b = source.index('(ert-deftest ', a + 1)
body = source[a:b]
for text in ['(completion-at-point)', '(minibuffer-choose-completion t)', '(buffer-string)', 'v.count_ones.1234567890;', '(should', '(equal']:
    assert text in body
needles = [name, 'v.count_on1234.1234567890', 'v.count_ones.1234567890']
matches = []
for file in (root / 'src').rglob('*.rs'):
    contents = file.read_text()
    for needle in needles:
        if needle in contents:
            matches.append(dict(path=str(file.relative_to(root)), needle=needle))
assert not matches
tools = read(raw / 'prerequisites.json')['tools']
assert tools['rust-analyzer']['version'].startswith('rust-analyzer 1.75.0')
record = dict(status='bounded review supports the retained Emaxx pass; full audit remains open', source='eb286e230b414fc753b37b4008566950b98fc867', source_inputs_verified=len(manifest), fixture_sha256=sha(fixture), fixture_assertion='Unchanged upstream test checks actual completion UI and exact final buffer text after choosing a rust-analyzer completion.', results=results, recorded_rust_analyzer=tools['rust-analyzer'], runner_provenance=contract['provenance'], checked_execution_files=execution['sha256'], static_search=dict(needles=needles, rust_source_matches=matches), reviewed_paths=['src/bin/compat-harness/prerequisites.rs:prepare_language_servers records and links real pinned cargo/rustc/rustdoc/rust-analyzer for both editors', 'ordinary recorded Emaxx command loads upstream Eglot and the unchanged fixture through ERT', 'retained Emaxx log connects to rust-analyzer and reaches completion and the final test assertion'], qualification='A matching ERT pass is bounded evidence for its assertions, not a byte-for-byte log equality or proof of universal correctness. GNU times out before producing the corresponding result, so this run cannot establish equality or speedup for that case. No process-level syscall trace or new adversarial Eglot execution was performed by this review. The complete frozen run remains failed; no expectation, timeout, selector or runtime behavior changed. No canned result or oracle forwarding was found in these reviewed paths; the final whole-runtime de-cheating audit is incomplete.', goal_complete=False)
with (p / 'source272-eglot-completion-path-audit.json').open('x') as out:
    json.dump(record, out, indent=2)
print(json.dumps(dict(status=record['status'], source_inputs_verified=len(manifest), static_matches=matches, fixture_sha256=record['fixture_sha256'])))
