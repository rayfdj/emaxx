from pathlib import Path

p = Path(__file__).parent.resolve()
s = (p / 'audit-source261-macos-terminal.py').read_text()
s = s.replace('source261', 'source270').replace('488', '510')
s = s.replace('eddfe78223ea404714d859a9d63a9048f89a9cff', '0ecf6e1167446326e6c4006490081e7d9872028f')
with (p / 'audit-source270-macos-terminal.py').open('x') as out:
    out.write(s)
