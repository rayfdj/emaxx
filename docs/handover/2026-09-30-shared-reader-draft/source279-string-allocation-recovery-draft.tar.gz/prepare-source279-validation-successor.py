from pathlib import Path
import hashlib, json, subprocess

p = Path(__file__).parent.resolve()
c = p.parent / 'recovered-2026-09-30/string-allocation-recovery/emaxx'
old = p.parent / 'recovered-2026-09-30/string-allocation-negative-fixed/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
m = json.loads((p / 'source278-manifest.json').read_text())
assert all(sha(old / n) == h for n, h in m.items())
assert sha(c / 'src/lisp/native_comp/runtime.rs') == m['src/lisp/native_comp/runtime.rs']
assert (c / 'target/string-sblock-validation/gate').is_dir()
count = len(subprocess.check_output(['git', 'diff', '--name-only'], cwd=c, text=True).splitlines())
assert count == 17
s = (p / 'run-source278-allocation-negative.py').read_text().replace('source278', 'source279').replace('recovered-2026-09-30/string-allocation-negative-fixed/emaxx', 'recovered-2026-09-30/string-allocation-recovery/emaxx')
s = s.replace('len(changed_files) == 16', 'len(changed_files) == 17')
s = s.replace("'gate-negative-'", "'gate-recovery-'")
marker = "    state['status'] = 'finished; raw result requires audit'"
assert s.count(marker) == 1
s = s.replace(marker, '''    for index, name in enumerate([
        'native_vector_and_closure_census_matches_gnu_word_layout',
        'native_pseudovector_census_matches_gnu_word_layout',
    ]):
        selector = 'lisp::primitives::tests::' + name
        assert selector in names
        run('gate-census-' + str(index + 1), [str(binary), '--test-threads=1', '--nocapture', '--exact', selector])
''' + marker).replace("len(state['results']) == 9", "len(state['results']) == 11")
with (p / 'run-source279-fallible-strings.py').open('x') as out:
    out.write(s)
with (p / 'source279-negative-precondition.json').open('x') as out:
    json.dump(dict(source278_result=json.loads((p / 'source278-probe-result.json').read_text()), source278_inputs_verified=len(m), new_tests_unchanged=True, preparation_failure='First preparation cloned the idle cache but expected 16 changed tracked files; repair changes 17. No candidate validation or runtime ran. That helper and failure are preserved.', qualification='The same three controls aborted with SIGABRT before this repair. Two existing GC-census controls additionally diagnose the new source276 affected-module failure without changing expectations.'), out, indent=2)
