from pathlib import Path
import hashlib, io, json, os, subprocess, tarfile, tempfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
c = p.parent / 'recovered-2026-09-30/string-allocation-recovery/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p / n).read_text())
m = read('source279-manifest.json')
assert len(m) == 511 and all(sha(c / n) == h for n, h in m.items())
baseline = read('source272-manifest.json')
assert all(sha(root / n) == h for n, h in baseline.items())
negative = read('source278-manifest.json')
runtime = 'src/lisp/native_comp/runtime.rs'
assert m[runtime] == negative[runtime]
probe = read('source279-probe-result.json')
assert len(probe['results']) == 11 and all(row['exit_code'] == 0 and row['source_unchanged'] and row['published_source_unchanged'] for row in probe['results'])
for stage in ['fmt', 'check', 'clippy', 'diff', 'gate-build']:
    raw = (p / ('source279-' + stage + '.log')).read_text()
    assert not any(line.startswith('warning:') for line in raw.splitlines())
    for line in raw.splitlines():
        if line.startswith('{'):
            assert json.loads(line).get('message', {}).get('level') not in ['warning', 'error']
binary = read('source279-binary.json')
assert sha(Path(binary['path'])) == binary['sha256']
for prefix in ['gate-recovery-', 'gate-census-']:
    for index in range(1, 4 if prefix == 'gate-recovery-' else 3):
        raw = (p / f'source279-{prefix}{index}.log').read_text()
        assert 'test result: ok. 1 passed; 0 failed; 0 ignored;' in raw
patches = {}
for label, commit in [('portable-incremental', 'b5a1558c6b88804cecdbee04a9bdbfab34209ac8'), ('portable-complete', '21d20f0eec08f3c013d5d3eb3bd6e9cfc16b3199')]:
    data = subprocess.check_output(['git', 'diff', '--binary', commit, '--', *sorted(m)], cwd=c)
    added = subprocess.run(['git', 'diff', '--no-index', '--binary', '--', '/dev/null', 'src/lisp/alloc/strings/data.rs'], cwd=c, capture_output=True)
    assert added.returncode == 1 and not added.stderr
    data += added.stdout
    f = p / ('source279-' + label + '.patch')
    with f.open('xb') as out:
        out.write(data)
    patches[f.name] = dict(base=commit, sha256=sha(f), bytes=len(data))
assert (p / 'source279-portable-incremental.patch').read_bytes() == (p / 'source279-sblocks.patch').read_bytes()
replays = [(name, record['base'], m) for name, record in patches.items()]
for source in [277, 278]:
    replays.append((f'source{source}-sblocks.patch', 'b5a1558c6b88804cecdbee04a9bdbfab34209ac8', read(f'source{source}-manifest.json')))
records = []
for name, commit, inputs in replays:
    tracked = set(subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', commit], cwd=root, text=True).splitlines())
    archive = subprocess.check_output(['git', 'archive', commit, '--', *sorted(tracked & inputs.keys())], cwd=root)
    with tempfile.TemporaryDirectory(prefix='emaxx-fallible-string-replay-', dir='/private/tmp') as temporary:
        target = Path(temporary)
        with tarfile.open(fileobj=io.BytesIO(archive)) as source:
            for member in source:
                assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
                dest = target / member.name
                if member.isdir():
                    dest.mkdir(parents=True, exist_ok=True)
                else:
                    assert member.isfile()
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    dest.write_bytes(source.extractfile(member).read())
                    os.chmod(dest, 0o755 if member.mode & 0o111 else 0o644)
        subprocess.run(['git', 'apply', '--check', str(p / name)], cwd=target, check=True)
        subprocess.run(['git', 'apply', str(p / name)], cwd=target, check=True)
        assert all(sha(target / n) == h for n, h in inputs.items())
        assert all((target / n).stat().st_mode & 0o777 == (c / n).stat().st_mode & 0o777 for n in inputs)
    records.append(dict(patch=name, base=commit, inputs=len(inputs), sha256=sha(p / name), bytes_and_modes='exact'))
gnu = p.parent / 'rebuilt-2026-10-01/emacs'
record = dict(status='strict checks and five bounded controls passed; broader selection running', source_inputs_verified=511, new_tests_byte_identical_to_source278=True, gate_binary=binary, patches=patches, replays=records, gnu_mechanisms=dict(inputs={n: sha(gnu / n) for n in ['src/alloc.c', 'src/lisp.h', 'src/data.c']}, references=['lisp.h:STRING_BYTES_BOUND and alloc.c:STRING_BYTES_MAX: 61-bit fixnum bound on supported 64-bit targets', 'alloc.c:allocate_string_data and memory_full: allocation failure must signal instead of aborting the editor', 'alloc.c:memory_full: xsignal(Qnil, Vmemory_signal_data) preserves the preallocated condition identity']), rust_constraints='Result carries an allocation-failure discriminator to the primitive body because the storage layer has no interpreter. A construction guard returns uninstalled headers to the existing free list on error or unwind. Successful reads and writes gain no registry or lookup.', evidence_limits=['Original source276 broad Emaxx first-vector -130 difference remains unresolved; fresh same-binary standalone and two-predecessor replays pass, without superseding that failure.', 'Three source278 original controls abort with SIGABRT; source279 passes the exact unchanged controls, including native condition identity.', 'Source277 compiler error and first source279 preparation wrong changed-file count are preserved.', 'Process-wide actual exhaustion, reserve-memory handling, GC retuning and pre-existing infallible host allocation APIs remain incomplete; this evidence covers oversized recoverable requests.', 'Full platform validation, physical accounting, intervals, unified pure storage, public ownership, final de-cheating and performance criteria remain open.'], goal_complete=False)
with (p / 'source279-freeze-and-probe-audit.json').open('x') as out:
    json.dump(record, out, indent=2)
print(json.dumps(dict(status=record['status'], source_inputs_verified=511, replays=records), indent=2))
