from pathlib import Path
import hashlib,json,re
from native_fixed_validation_support import audit_selected
p=Path(__file__).parent.resolve();c=p.parent/'recovered-2026-10-06/native-subr-callbacks/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();read=lambda n:json.loads((p/n).read_text());tag='source308'
m=read(tag+'-manifest.json');assert len(m)==541 and all(sha(c/n)==h for n,h in m.items())
base=read('source304-manifest.json');assert all(m[n]==h for n,h in base.items() if n.startswith(('tests/','compat/','tools/')))
assert m['src/anti_cheat.rs']==base['src/anti_cheat.rs']
assert 'native_subr_dabbrev_diagnostic_trace' not in (c/'src/lisp/eval/tests/eval_05.rs').read_text()
assert not any('NativeCompiledFunction' in (c/n).read_text() for n in m if n.endswith('.rs'))
s=read(tag+'-validation-result.json');assert s['status']=='strict, selected and ordinary build passed; raw audit and ordinary comparisons required'
assert all(r['exit_code']==0 and not r['timed_out'] and r['source_unchanged'] for r in s['results'])
profiles={};new={
 'lisp::alloc::vectors::tests::native_subr_allocation_has_gnu_fields_and_direct_tagged_identity',
 'lisp::alloc::vectors::tests::native_subr_marks_all_five_fields_and_releases_unreachable_cycles',
 'lisp::native_comp::loader::tests::native_subr_calls_read_actual_target_and_arity_fields',
 'lisp::primitives::tests::native_subr_authority_preserves_gnu_metadata_calls_and_identity',
 'lisp::primitives::tests::native_subr_c_names_follow_gnu_nul_termination_without_changing_symbols',
 'lisp::primitives::tests::native_subr_consumers_preserve_commands_completion_properties_and_substitution'}
for profile in ['gate','release']:
 inventory=lambda t:[line[:-6] for line in (p/f'{t}-{profile}-inventory.log').read_text().splitlines() if line.endswith(': test')]
 names=inventory(tag);assert len(names)==len(set(names))==3048 and set(names)==set(inventory('source304'))|new
 baseline=set(read('source304-validation-result.json')['profiles'][profile]['selectors'])
 selected=[n for n in names if n in baseline or re.search(r'native|pdump|dump_|image|module|weak|thread|suspended|purecopy|hash|value_|print|command|completion|substitut|propert',n)]
 assert len(selected)==1031 and len(baseline)==506 and baseline<=set(selected)
 assert len([n for n in selected if n.startswith('anti_cheat::')])==24
 record=s['profiles'][profile];assert record['selectors']==selected
 focused=audit_selected((p/f'{tag}-{profile}-focused.log').read_text(),sorted(new));assert focused['passed']==6
 counts=audit_selected((p/f'{tag}-{profile}-selected.log').read_text(),selected)
 assert counts['passed']==record['passed']==1031 and counts['failed']==counts['ignored']==0
 assert sha(Path(record['binary']))==sha(Path(record['retained_binary']))==record['binary_sha256']
 for item in record['retained_inputs']:assert sha(Path(item['original']))==sha(Path(item['retained']))==item['sha256']
 messages=[json.loads(line) for line in (p/f'{tag}-{profile}-build.log').read_text().splitlines() if line.startswith('{')]
 artifacts=[a for a in messages if a.get('reason')=='compiler-artifact' and a['target']['name']=='emaxx' and a.get('profile',{}).get('test') and a.get('executable')]
 assert len(artifacts)==1 and artifacts[0]['fresh'] is False and artifacts[0]['executable']==record['binary']
 profiles[profile]=dict(**counts,focused=focused,selectors=selected,binary_sha256=record['binary_sha256'])
ordinary={};names=list(read('source304-selected-audit.json')['ordinary_results'])+['native-subr-authority','native-subr-c-names','native-subr-consumers'];assert len(names)==51
for name in names:
 prefix=tag+'-ordinary-'+('loaded-' if name=='native-subr-c-names' else '')+name
 result=read(prefix+'-comparison.json');assert result['passed'] and result['exact_match']
 outputs=[]
 for editor in ['gnu','emaxx']:
  stem=prefix+'-'+editor;r=read(stem+'.result.json');command=read(stem+'.command.json');assert all(sha(Path(f))==h for f,h in command['inputs'].items());assert r['exit_code']==0 and not r['timed_out'] and r['source_unchanged'] and r['inputs_unchanged'] and r['expected_output'] is not False
  out=(p/(stem+'.stdout')).read_bytes();err=(p/(stem+'.stderr')).read_bytes();assert out and not err and sha(p/(stem+'.stdout'))==r['stdout_sha256'];outputs.append(out)
 assert outputs[0]==outputs[1];ordinary[name]=result
failed=read('source308-ordinary-native-subr-c-names-comparison.json')
assert not failed['passed'] and failed['exact_match'] and all(r['expected_output'] is False for r in failed['outcomes'].values())
assert read('native-subr-selection308-result.json')['status']=='selection stopped'
fixture=c/'tests/fixtures/native-subr-c-names.el'
assert (p/'source308-native-c-names-loaded-driver.el').read_text()==' ;; -*- coding: utf-8; lexical-binding: nil; -*-\n(prin1 '.lstrip()+fixture.read_text()+')\n'
for editor in ['gnu','emaxx']:
 command=read('source308-ordinary-loaded-native-subr-c-names-'+editor+'.command.json')
 assert command['command'][-2:]==['-l',str(p/'source308-native-c-names-loaded-driver.el')]
 assert (p/('source308-ordinary-loaded-native-subr-c-names-'+editor+'.stdout')).read_bytes()==fixture.with_suffix('.expected').read_bytes().rstrip(b'\n')
assert read(tag+'-generated-loaded-comparison.json')['passed']
for editor in ['gnu','emaxx']:
 stem=tag+'-generated-loaded-'+editor;r=read(stem+'-result.json');command=read(stem+'-command.json');assert r['exit_code']==0 and not r['timed_out'] and r['inputs_unchanged'] and r['source_unchanged'];assert all(sha(Path(f))==h for f,h in command['inputs'].items());out=(p/(stem+'.stdout')).read_bytes();assert len(out)==4088269 and len(out.splitlines())==198 and out==(p/'printer-varied-v3-gnu.stdout').read_bytes() and not (p/(stem+'.stderr')).read_bytes()
for stage in ['fmt','check','clippy','diff','gate-build','release-build','ordinary-build']:
 raw=(p/f'{tag}-{stage}.log').read_text();assert not re.search(r'^warning(?:\[.*\])?:',raw,re.M)
 for line in raw.splitlines():
  if line.startswith('{'):assert json.loads(line).get('message',{}).get('level') not in ['warning','error']
artifacts=read(tag+'-ordinary-artifacts.json');assert all(sha(Path(f))==sha(Path(v['immutable_copy']))==v['sha256'] for f,v in artifacts.items())
portable=read(tag+'-portable-draft-audit.json');assert len(portable['patches'])==2
for v in portable['patches']:assert v['inputs']==541 and v['bytes_and_modes']=='exact' and sha(p/v['patch'])==v['sha256']
for earlier in ['source305-focused-failure-audit.json','source306-closed-failure-audit.json','source307-closed-failure-audit.json']:assert read(earlier)['failed']>0
assert (p/(tag+'-ordinary-buffer-lf-line-index-emaxx.stdout')).read_bytes()==(p/'source302-line-broad-gnu.stdout').read_bytes()
evidence={str(f):sha(f) for f in p.glob(tag+'-*') if f.is_file() and f.suffix in ['.json','.log','.stdout','.stderr','.patch','.el','.expected']}
result=dict(status='passed',source_inputs_verified=541,profiles=profiles,ordinary_comparisons=52,ordinary_results=ordinary,generated_rows=198,ordinary_artifacts=artifacts,portable_replays=portable['patches'],evidence_files=evidence,goal_complete=False,ordinary_c_name_runner_failure=failed,qualification='The original C-locale non-ASCII argv comparison remains failed: both editors produced identical mojibake. Normal UTF-8 file loading of the unchanged fixture matches every original expected byte. Actual GNU-layout native subrs replace detached function records and descriptor/name maps. Fresh strict checks,1031 affected passes per profile including all506 published controls and24 audit tests,6 focused controls per profile,52 actual ordinary GNU comparisons and all198 generated rows verify. All original fixtures and tests remain; representation-specific detections and suspension fixtures use actual subrs/units. The original dabbrev regression is fixed. Sources305/306/307 and development failures remain failed. This selected checkpoint does not establish full platform validation, physical accounting, public ownership/unit reclamation or final performance acceptance.')
(p/(tag+'-selected-audit.json')).open('x').write(json.dumps(result,indent=2));print(json.dumps(dict(status=result['status'],source_inputs=541,passes_per_profile=1031,ordinary_comparisons=52)))
