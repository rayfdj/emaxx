from pathlib import Path
import hashlib,json,subprocess,sys,time
p=Path(__file__).parent.resolve();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();read=lambda n:json.loads((p/n).read_text())
helpers={n:sha(p/n) for n in ['measure-native-subr308.py','audit-native-subr308-performance.py',Path(__file__).name]}
state=dict(status='waiting for selected validation and prior304 complete macOS processes',helpers=helpers,steps=[],goal_complete=False)
def save():(p/'native-subr308-performance-sequence-closed-state.json').write_text(json.dumps(state,indent=2))
def run(stage,cmd):
 assert all(sha(p/n)==h for n,h in helpers.items());state['status']='running '+stage;save();start=time.monotonic();(p/f'native-subr308-performance-sequence-closed-{stage}-command.json').open('x').write(json.dumps(dict(command=cmd,helpers=helpers),indent=2))
 with (p/f'native-subr308-performance-sequence-closed-{stage}.log').open('xb') as f:r=subprocess.run(cmd,cwd=p,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT)
 state['steps'].append(dict(stage=stage,exit_code=r.returncode,elapsed_seconds=time.monotonic()-start));save();assert r.returncode==0
save()
try:
 while not (p/'native-subr-selection308-closed-result.json').exists() or not (p/'source304-full-queue-result.json').exists():time.sleep(20)
 assert read('native-subr-selection308-closed-result.json')['status']=='selected native-subr validation audited; full validation and performance remain'
 assert read('source308-selected-audit.json')['status']=='passed'
 while not (p/'native-subr308-performance-sequence-result.json').exists():time.sleep(10)
 assert read('native-subr308-performance-sequence-result.json')['status']=='sequence stopped'
 platform=read('source304-full-queue-result.json');assert platform['status']=='complete macOS processes finished; raw evidence requires audit',platform
 assert read('source304-macos-frozen-audit.json')['mismatching_outcomes']==6
 # Prior platform failures stay failed. Neither their verdict nor a passing
 # subset certifies308; only closed processes are required for isolated timing.
 state['prior304_platform_results']=platform['results'];save()
 run('measure',[sys.executable,'-B',str(p/'measure-native-subr308.py')])
 run('audit',[sys.executable,'-B',str(p/'audit-native-subr308-performance.py')])
 state['status']='timing audited; native-object source decision pending'
except Exception as e:state.update(status='sequence stopped',error=repr(e))
finally:
 save();(p/'native-subr308-performance-sequence-closed-result.json').open('x').write(json.dumps(state,indent=2))
print(json.dumps(state),flush=True)
