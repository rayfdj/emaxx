from pathlib import Path
import hashlib, json, os, subprocess, time

p = Path(__file__).parent.resolve()
c = p.parent / 'recovered-2026-10-06/native-subr-callbacks/emaxx'
read = lambda n: json.loads((p / n).read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
manifest = read('source308-manifest.json')
unchanged = lambda: all(sha(c / n) == h for n, h in manifest.items())
fixture = c / 'tests/fixtures/native-subr-c-names.el'
expected_file = fixture.with_suffix('.expected')
expected = expected_file.read_bytes().rstrip(b'\n')
failed = read('source308-ordinary-native-subr-c-names-comparison.json')
assert not failed['passed'] and failed['exact_match']
assert all(r['exit_code'] == 0 and not r['timed_out'] and r['expected_output'] is False for r in failed['outcomes'].values())
assert (p / 'source308-ordinary-native-subr-c-names-gnu.stdout').read_bytes() == (p / 'source308-ordinary-native-subr-c-names-emaxx.stdout').read_bytes()
assert 'native-name-Î»-' in (p / 'source308-ordinary-native-subr-c-names-gnu.stdout').read_text()
assert 'native-name-λ-' in expected.decode()
driver = p / 'source308-native-c-names-loaded-driver.el'
program = ';; -*- coding: utf-8; lexical-binding: nil; -*-\n(prin1 ' + fixture.read_text() + ')\n'
driver.open('x').write(program)
results = {}
for label, binary in [('gnu', p.parent / 'rebuilt-2026-10-01/emacs/src/emacs'),
                      ('emaxx', c / 'target/vm-dispatch-validation/release/emaxx')]:
    assert unchanged()
    stem = p / ('source308-ordinary-loaded-native-subr-c-names-' + label)
    inputs = {str(f): sha(f) for f in [binary, binary.with_suffix('.pdmp'), fixture, expected_file, driver, Path(__file__)]}
    command = [str(binary), '-Q', '--batch', '-l', str(driver)]
    env = dict(EMAXX_GC_VERIFY='1', LANG='C', LC_ALL='C')
    record = dict(command=command, fixture_mode='print-unchanged-return-value-from-utf8-file', working_directory=str(p), inputs=inputs,
                  environment_override=env, timeout_seconds=120,
                  qualification='Unchanged fixture and expected bytes. Both editors read the same UTF-8 file through normal -l. The original raw non-ASCII --eval argument was decoded under C locale by both editors and remains a failed expectation comparison. No output normalization or runtime change.')
    stem.with_suffix('.command.json').open('x').write(json.dumps(record, indent=2))
    start = time.monotonic()
    try:
        run = subprocess.run(command, cwd=p, env=dict(os.environ, **env), stdin=subprocess.DEVNULL, capture_output=True, timeout=120)
        code, stdout, stderr, timeout = run.returncode, run.stdout, run.stderr, False
    except subprocess.TimeoutExpired as error:
        code, stdout, stderr, timeout = None, error.stdout or b'', error.stderr or b'', True
    stem.with_suffix('.stdout').open('xb').write(stdout)
    stem.with_suffix('.stderr').open('xb').write(stderr)
    result = dict(exit_code=code, elapsed_seconds=time.monotonic()-start, timed_out=timeout,
                  stdout_sha256=hashlib.sha256(stdout).hexdigest(), stderr_hex=stderr.hex(),
                  expected_output=stdout == expected, inputs_unchanged=all(sha(Path(f)) == h for f,h in inputs.items()), source_unchanged=unchanged())
    stem.with_suffix('.result.json').open('x').write(json.dumps(result, indent=2))
    results[label] = result
    print(label, json.dumps(result), flush=True)
exact = all(results['gnu'][key] == results['emaxx'][key] for key in ['exit_code', 'stdout_sha256', 'stderr_hex'])
passed = exact and all(r['exit_code'] == 0 and not r['timed_out'] and r['expected_output'] and not r['stderr_hex'] and r['inputs_unchanged'] and r['source_unchanged'] for r in results.values())
(p / 'source308-ordinary-loaded-native-subr-c-names-comparison.json').open('x').write(json.dumps(dict(outcomes=results, exact_match=exact, passed=passed), indent=2))
assert passed
