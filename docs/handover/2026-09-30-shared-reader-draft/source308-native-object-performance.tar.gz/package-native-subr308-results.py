from pathlib import Path
import ast, gzip, hashlib, io, json, sys, tarfile
p=Path(__file__).parent.resolve();out=p.parents[2]/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest();read=lambda n:json.loads((p/n).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
allowed={'.json','.log','.txt','.py','.patch','.stdout','.stderr','.el','.expected','.h'}
phase=sys.argv[1];assert phase in ['selected','performance','terminal304']
if phase=='selected':
 audit=read('source308-selected-audit.json')
 assert audit['status']=='passed' and audit['source_inputs_verified']==541 and audit['ordinary_comparisons']==52
 assert all(r['passed']==1031 and r['failed']==r['ignored']==0 for r in audit['profiles'].values())
 assert read('native-subr-selection308-final-result.json')['status']=='selected native-subr validation audited; full validation and performance remain'
 assert all(sha(Path(n).read_bytes())==h for n,h in audit['evidence_files'].items())
 for name in ['source305-native-object-decoder-failure','source306307-native-object-consumer-failures','source308-native-object-draft']:
  earlier=json.loads((out/(name+'-manifest.json')).read_text());assert sha((out/earlier['archive']['path']).read_bytes())==earlier['archive']['sha256']
 files={f.name:f for f in p.iterdir() if f.is_file() and f.suffix in allowed and f.name.startswith(('source308-','native-subr-selection308-'))}
 helpers=['run-source308-validation.py','native_fixed_validation_support.py','compare-vm-dispatch-fixtures.py','compare-source308-generated-loaded.py','audit-native-subr-selected308.py','finish-native-subr-selected308.py','replay-native-subr308.py','apply-native-subr308.py','setup-source308-full-macos.py','queue-source308-full-macos.py','audit-source308-selected-for-full.py','printer-varied-v3-293638f0.el','printer-varied-v3-gnu.stdout','source302-line-broad-gnu.stdout','source304-selected-audit.json','source304-manifest.json','source304-gate-inventory.log','source304-release-inventory.log','source304-validation-result.json','source305-focused-failure-audit.json','source306-closed-failure-audit.json','source307-closed-failure-audit.json','compare-native-subr308-c-names-loaded.py','audit-native-subr-selected308-closed.py','finish-native-subr-selected308-closed.py','finish-native-subr308-performance-closed.py','audit-native-subr-selected308-final.py','audit-native-subr-selected308-final-preflight.py','native-subr-selection308-final-audit2.log','finish-native-subr308-performance-final.py','update-native-object-publication308.py','package-source196-failure-and197-results.py',Path(__file__).name]
 files.update({name:p/name for name in helpers})
 package('source308-native-object-selected',files,dict(status='closed selected validation; full platform validation and final performance remain',source_inputs_verified=541,profiles={k:{n:r[n] for n in ['passed','failed','ignored']} for k,r in audit['profiles'].items()},ordinary_comparisons=52,generated_rows=198,audit=dict(path='source308-selected-audit.json',sha256=sha((p/'source308-selected-audit.json').read_bytes())),qualification=audit['qualification'],goal_complete=False))
elif phase=='performance':
 audit=read('native-subr308-combined-performance-audit.json');decision=read('source308-application-decision.json')
 assert audit['status']=='all 384 processes and actual results/modes verified'
 assert read('native-subr308-performance-sequence-final-result.json')['status']=='timing audited; native-object source decision pending'
 assert all(sha(Path(n).read_bytes())==h for n,h in audit['evidence_files'].items())
 files={}
 for tag in ['source304','source308']:
  for directory in sorted(p.glob(tag+'-native-subr308-pilot-*'))+sorted(p.glob(tag+'-native-subr308-confirm-pilot-*'))+[p/(tag+'-core-native')]:
   files.update({str(f.relative_to(p)):f for f in directory.rglob('*') if f.is_file() and f.suffix in allowed})
 files.update({f.name:f for f in p.iterdir() if f.is_file() and f.suffix in allowed and f.name.startswith(('native-subr308-performance-','native-subr308-confirm-performance-','native-subr308-combined-performance-'))})
 for name in ['measure-native-subr308-confirm.py','audit-native-subr308-confirm-performance.py','finish-native-subr308-confirm-performance.py','audit-native-subr308-combined-performance.py','source308-public-boundary-review.json','measure-native-subr308.py','audit-native-subr308-performance.py','finish-native-subr308-performance.py','source308-application-decision.json','compare-native-subr308-c-names-loaded.py','audit-native-subr-selected308-closed.py','finish-native-subr-selected308-closed.py','finish-native-subr308-performance-closed.py','audit-native-subr-selected308-final.py','audit-native-subr-selected308-final-preflight.py','native-subr-selection308-final-audit2.log','finish-native-subr308-performance-final.py','update-native-object-publication308.py','package-source196-failure-and197-results.py',Path(__file__).name]:files[name]=p/name
 package('source308-native-object-performance',files,dict(status=audit['status'],audit=dict(path='native-subr308-combined-performance-audit.json',sha256=sha((p/'native-subr308-combined-performance-audit.json').read_bytes())),application_decision=decision,qualification=audit['qualification'],goal_complete=False))
else:
 audit=read('source304-macos-terminal-audit.json');queue=read('source304-full-queue-result.json')
 assert queue['status']=='complete macOS processes finished; raw evidence requires audit'
 assert sha((p/'source304-full-tty.log').read_bytes())==audit['log_sha256']
 assert read('source304-full-oracle-verify-result.json')['exit_code']==0
 files={f.name:f for f in p.iterdir() if f.is_file() and f.suffix in allowed and f.name.startswith(('source304-full-tty','source304-full-oracle-verify','source304-full-queue'))}
 for name in ['audit-source304-macos-terminal.py','source304-macos-terminal-audit.json','source304-macos-frozen-audit.json','source304-manifest.json','source304-full-launch.json','source304-full-checkout.json','queue-source304-full-macos.py','source248-full-ttydiff-retry-command.json','source248-manifest.json','compare-native-subr308-c-names-loaded.py','audit-native-subr-selected308-closed.py','finish-native-subr-selected308-closed.py','finish-native-subr308-performance-closed.py','audit-native-subr-selected308-final.py','audit-native-subr-selected308-final-preflight.py','native-subr-selection308-final-audit2.log','finish-native-subr308-performance-final.py','update-native-object-publication308.py','package-source196-failure-and197-results.py',Path(__file__).name]:files[name]=p/name
 for file in (p/'source304-full-retained-gnu').glob('*.json'):files[str(file.relative_to(p))]=file
 package('source304-macos-terminal-results',files,dict(status=audit['status'],terminal=audit,qualification=audit['qualification'],goal_complete=False))
