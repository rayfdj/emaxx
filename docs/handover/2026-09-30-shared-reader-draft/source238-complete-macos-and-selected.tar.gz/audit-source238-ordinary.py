from pathlib import Path
import hashlib, json, re
p=Path(__file__).parent.resolve()
root=p.parent/'recovered-2026-09-30/rx-repair/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
read=lambda name:json.loads((p/name).read_text())
manifest=read('source238-manifest.json')
assert len(manifest)==446 and all(sha(root/name)==digest for name,digest in manifest.items())
for stage in ['ordinary-build','ordinary-image']:
    result=read('source238-'+stage+'-result.json')
    assert result['exit_code']==0 and result['source_unchanged']
    assert not re.search(r'^warning(?:\[.*\])?:',(p/('source238-'+stage+'.log')).read_text(),re.M)
artifacts=read('source238-ordinary-artifacts.json')
for name,entry in artifacts.items():
    assert sha(Path(name))==entry['sha256']==sha(Path(entry['immutable_copy']))
result=read('source238-ordinary-comparisons-result.json')
assert result['exit_code']==0 and result['fixtures']==57
fixtures=read('source238-ordinary-comparisons-command.json')['fixtures']
assert len(fixtures)==len(set(fixtures))==57
assert fixtures[:40]==read('source207-ordinary-comparisons-command.json')['fixtures']
self_printing={'bytecode-live-fetch','bytecode-unused-destinations','canonical-string-bytes','canonical-string-constructors'}
for fixture in fixtures:
    stem='source238-ordinary-'+fixture
    comparison=read(stem+'-comparison.json')
    assert comparison['passed'] and comparison['exact_match']
    fixture_path=root/('tests/fixtures/'+fixture+'.el')
    if not fixture_path.exists():fixture_path=p/(fixture+'.el')
    program=fixture_path.read_text()
    mode='self-printing' if fixture in self_printing else 'print-return-value'
    if fixture in self_printing:assert program.startswith('(prin1\n')
    form=program if fixture in self_printing else '(prin1 '+program+')'
    outputs=[]
    commands=[]
    for editor in ['gnu','emaxx']:
        result=read(stem+'-'+editor+'.result.json')
        command=read(stem+'-'+editor+'.command.json')
        assert result==comparison['outcomes'][editor]
        assert result['exit_code']==0 and not result['timed_out']
        assert result['source_unchanged'] and result['inputs_unchanged']
        assert result['expected_output'] is not False
        assert command['environment_override']['LANG']==command['environment_override']['LC_ALL']=='C'
        assert command['fixture_mode']==mode
        assert command['command'][1:]==['-Q','--batch','--eval',form]
        stdout=p/(stem+'-'+editor+'.stdout')
        assert sha(stdout)==result['stdout_sha256']
        assert (p/(stem+'-'+editor+'.stderr')).read_bytes()==b''
        assert all(sha(Path(name))==digest for name,digest in command['inputs'].items())
        expected=fixture_path.with_suffix('.expected')
        if expected.exists():assert stdout.read_bytes()==expected.read_bytes().rstrip(b'\n')
        outputs.append(stdout.read_bytes());commands.append(command['command'])
    assert outputs[0]==outputs[1] and commands[0][1:]==commands[1][1:]
record=dict(status='all ordinary differential comparisons pass',fixtures=fixtures,inputs_verified=len(manifest),ordinary_artifacts=artifacts,goal_complete=False,
    qualification='All 40 preceding ordinary controls plus seventeen string/bytecode/completion/reader fixtures pass through normal -Q batch entry points with each editor using its own executable/image. The four self-printing fixtures execute their original form; all other fixtures print their returned value. No runtime output is normalized. Every raw process status, output, stderr, input hash and C locale is checked. Previous source225 wrapper failures remain separate failed evidence. GNU is source/native-ABI matched, not pinned Darwin. No full-platform, stack-capacity, physical-accounting or performance claim.')
with (p/'source238-ordinary-audit.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(dict(status=record['status'],fixtures=len(fixtures),inputs_verified=len(manifest)),indent=2))
