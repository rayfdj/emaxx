from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
out = p.parents[2] / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected', '.h'}
selected = {tag: read(tag + '-selected-audit.json') for tag in ['source297', 'source298']}
performance = read('native-dispatch-performance-audit.json')
assert all(x['status'] == 'passed' for x in selected.values())
assert performance['status'] == 'all 288 processes and actual results/modes verified'
for audit in [*selected.values(), performance]:
    assert all(sha(Path(n).read_bytes()) == h for n, h in audit['evidence_files'].items())
helpers = [
    'run-source297-validation.py', 'run-source298-validation.py', 'audit-native-dispatch-selected.py',
    'compare-source297-generated-loaded.py', 'compare-source298-generated-loaded.py',
    'compare-source292-generated-loaded.py', 'compare-vm-dispatch-fixtures.py',
    'compare-buffer-line-broad-probe.py', 'native_fixed_validation_support.py',
    'verify-existing-portable-draft.py', 'replay-native-dispatch297.py', 'replay-native-empty298.py',
    'finish-native-dispatch-selected-closed.py', 'finish-native-empty-selected-closed.py',
    'source296-gate-inventory.log', 'source296-release-inventory.log',
    'prepare-native-dispatch297.py', 'prepare-native-empty298.py', 'source296-manifest.json',
    'source296-selected-audit.json', 'printer-varied-v3-293638f0.el', 'printer-varied-v3-gnu.stdout',
    'package-source196-failure-and197-results.py', 'apply-native-dispatch297.py', Path(__file__).name,
]
files = {f.name: f for f in p.iterdir() if f.is_file() and f.suffix in allowed
         and f.name.startswith(('source297-', 'source298-', 'native-dispatch-selection-', 'native-empty-selection-'))}
files.update({name: p / name for name in helpers})
package('source297-298-native-dispatch-selected', files, dict(
    status='closed fresh selected validation for source297 and correctness-only298', audits=selected,
    qualification='Both532-input portable drafts, fresh gate/release/ordinary builds,327 passes per profile and47 actual ordinary GNU comparisons verify. All original tests/fixtures remain; one null-storage boundary test is added. Both full broad probes retain60 original column-width failures. The original helper generation failure remains. Final platform/ownership/accounting/acceptance remain open.',
    goal_complete=False))
files = {}
for tag in ['source296', 'source298', 'source297']:
    for directory in sorted(p.glob(tag + '-native-dispatch-pilot-*')) + [p / (tag + '-core-native')]:
        for f in directory.rglob('*'):
            if f.is_file() and f.suffix in allowed:
                files[str(f.relative_to(p))] = f
for f in p.iterdir():
    if f.is_file() and f.suffix in allowed and f.name.startswith('native-dispatch-performance-'):
        files[f.name] = f
for name in ['measure-native-dispatch.py', 'audit-native-dispatch-performance.py',
             'finish-native-dispatch-performance-closed.py', 'source297-application-decision.json',
             'package-source196-failure-and197-results.py', Path(__file__).name]:
    files[name] = p / name
package('source297-298-native-dispatch-performance', files, dict(
    status='all288 actual process answers and modes verified', audit=performance,
    application_decision=read('source297-application-decision.json'),
    qualification='All samples/startup/total/RSS/GC reports and unavailable-allocation errors remain. Original296, corrected298, optimized297 run three rotated unchanged full16 pilots each, separately from builds/tests/profiles. Small diagnostic, no statistical acceptance. Real counters, calibration and nine-round every-case upper95% GNU ratio at most1.03 remain required.',
    goal_complete=False))
