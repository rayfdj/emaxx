from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).parent.resolve();c=p.parent/'recovered-2026-10-05/native-empty-arguments/emaxx'
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
manifest=json.loads((p/'source298-manifest.json').read_text())
unchanged=lambda:all(sha(c/name)==h for name,h in manifest.items())
fixture=p/'printer-varied-v3-293638f0.el'
expected=(p/'printer-varied-v3-gnu.stdout').read_bytes()
assert len(expected.splitlines())==198 and hashlib.sha256(expected).hexdigest()=='fead906d4b0aa20e9ef90a98b3a696c73267423190766ed0d0c188293e663960'
def save(name,value):
    with (p/('source298-generated-loaded-'+name+'.json')).open('x') as f:json.dump(value,f,indent=2)
results={}
for label,binary in [('gnu',p.parent/'rebuilt-2026-10-01/emacs/src/emacs'),('emaxx',c/'target/vm-dispatch-validation/release/emaxx')]:
    assert unchanged()
    inputs={str(f):sha(f) for f in [binary,binary.with_suffix('.pdmp'),fixture,Path(__file__)]}
    command=[str(binary),'-Q','--batch','-l',str(fixture)]
    env=dict(LANG='C',LC_ALL='C',EMAXX_GC_VERIFY='1')
    save(label+'-command',dict(command=command,working_directory=str(p),environment_override=env,inputs=inputs,timeout_seconds=120,required_rows=198,expected_sha256=hashlib.sha256(expected).hexdigest()))
    start=time.monotonic()
    try:
        run=subprocess.run(command,cwd=p,env=dict(os.environ,**env),stdin=subprocess.DEVNULL,capture_output=True,timeout=120)
        code,stdout,stderr,timed_out=run.returncode,run.stdout,run.stderr,False
    except subprocess.TimeoutExpired as e:code,stdout,stderr,timed_out=None,e.stdout or b'',e.stderr or b'',True
    for suffix,data in [('stdout',stdout),('stderr',stderr)]:
        with (p/('source298-generated-loaded-'+label+'.'+suffix)).open('xb') as f:f.write(data)
    results[label]=dict(exit_code=code,timed_out=timed_out,elapsed_seconds=time.monotonic()-start,stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest(),stdout_bytes=len(stdout),rows=len(stdout.splitlines()),matches_retained_gnu=stdout==expected,stderr_empty=not stderr,inputs_unchanged=all(sha(Path(f))==h for f,h in inputs.items()),source_unchanged=unchanged())
    save(label+'-result',results[label]);print(label,results[label],flush=True)
passed=all(r['exit_code']==0 and not r['timed_out'] and r['rows']==198 and r['matches_retained_gnu'] and r['stderr_empty'] and r['inputs_unchanged'] and r['source_unchanged'] for r in results.values())
save('comparison',dict(passed=passed,results=results,qualification='Actual complete file execution, all198 rows and every output byte required. The earlier source281 empty-output --eval run remains retained and invalid; this runner requires complete file execution. No universal correctness or performance claim.'))
assert passed
