from pathlib import Path
import ast, hashlib, json, subprocess

p = Path(__file__).parent.resolve()
root = p.parents[2]
c = p.parent / 'recovered-2026-10-05/native-funcall-dispatch/emaxx'
g = p.parent / 'rebuilt-2026-10-01/emacs'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p / n).read_text())
base = read('source296-applied-commit.json')['commit']
manifest = read('source296-manifest.json')
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == base
assert all(sha(root / n) == h for n, h in manifest.items())
assert read('native-fixed-performance-sequence-closed-result.json')['status'] == 'timing audited; source decision pending'
assert not c.exists()
c.parent.mkdir()
(c.parent / 'emacs').symlink_to(g, target_is_directory=True)
for command in [
    ['git', 'clone', '--shared', '--quiet', '--no-checkout', str(root), str(c)],
    ['git', '-C', str(c), 'sparse-checkout', 'init', '--no-cone'],
    ['git', '-C', str(c), 'sparse-checkout', 'set', '--no-cone',
     *sorted({'/' + n for n in manifest} | {'/tools/', '/compat/'})],
    ['git', '-C', str(c), 'checkout', '--detach', base],
]:
    subprocess.run(command, check=True)
assert all(sha(c / n) == h for n, h in manifest.items())
path = c / 'src/lisp/native_comp/runtime.rs'
before = path.read_text()
start = before.index('pub(crate) fn invoke_subr(index: usize, arguments: &[NativeWord])')
end = before.index('\nfn slow_unary_subr(', start)
region = before[start:end]
block = '''        if subroutine.name == "funcall"
            && let Some(result) = invoke_native_funcall(active, arguments)
        {
            return result;
        }
'''
assert region.count(block) == 1
region = region.replace(block, '')
anchor = '        if arguments.len() == 2\n'
assert region.count(anchor) == 1
region = region.replace(anchor, '''        // GNU native code enters Ffuncall directly. After synchronizing
        // handlers, use the same call path before unrelated primitive checks.
''' + block + anchor)
after = before[:start] + region + before[end:]
old = '''    // SAFETY: Generated code passes the count and pointer pair used by GNU's
    // MANY ABI.  The zero-length case permits a null pointer.
    let arguments = unsafe { std::slice::from_raw_parts(arguments, argument_count) };
    invoke_subr(index, arguments)
'''
new = '''    let arguments = if argument_count == 0 {
        // GNU's MANY ABI may supply null for no arguments. Even an empty
        // Rust slice must have a nonnull aligned address.
        &[]
    } else {
        // SAFETY: Generated code supplies the GNU MANY count/pointer pair;
        // the nonempty pointer was checked above.
        unsafe { std::slice::from_raw_parts(arguments, argument_count) }
    };
    invoke_subr(index, arguments)
'''
assert after.count(old) == 1
after = after.replace(old, new)
test = '''    #[test]
    fn native_many_empty_and_negative_list_counts_accept_null_storage() {
        extern "C" fn call_empty_list(count: NativeWord) -> NativeWord {
            let index = super::super::abi::native_subrs()
                .iter()
                .position(|subroutine| subroutine.name == "list")
                .expect("list belongs to the native ABI");
            let count = decode_fixnum(count).expect("test count is a fixnum") as isize;
            // alloc.c:Flist never reads args for any non-positive count.
            unsafe { invoke_subr_many(index, count, std::ptr::null()) }
        }

        let mut interpreter = Interpreter::new();
        let mut environment = Env::new();
        let mut runtime = NativeRuntime::default();
        for count in [0, -1, -7] {
            assert_eq!(
                runtime
                    .invoke(
                        &mut interpreter,
                        &mut environment,
                        call_empty_list as *const c_void,
                        NativeCallingConvention::Fixed,
                        &[Value::Integer(count)],
                    )
                    .expect("an empty native list does not read null storage"),
                Value::Nil,
            );
            assert_eq!(interpreter.backtrace_frames_len(), 0);
            assert_eq!(interpreter.lisp_eval_depth, 0);
            assert!(runtime.calls.is_empty());
        }
    }

'''
anchor = '    #[test]\n    fn native_funcall_builtin_error_unwinds_its_call_frame()'
assert after.count(anchor) == 1
after = after.replace(anchor, test + anchor)
assert after[after.index('mod tests {'):].replace(test, '') == before[before.index('mod tests {'):]
path.write_text(after)
assert [n for n, h in manifest.items() if sha(c / n) != h] == ['src/lisp/native_comp/runtime.rs']
review = dict(
    status='unvalidated native funcall routing and empty-slice repair', candidate=str(c), base_commit=base,
    inputs={str(f): sha(f) for f in [path, g / 'src/eval.c', g / 'src/alloc.c']},
    routing='Move the unchanged immutable funcall-descriptor guard immediately after existing handler synchronization. Every earlier primitive branch is false for this descriptor and performs only argument/name tests. Same helper, fallback, target lookup, debugger, roots, GC, arity and nonlocal exits; no new dispatch cache or ABI wrapper.',
    rust_boundary='For MANY zero count (including the existing Flist non-positive-count rule), use a real empty slice instead of constructing one from a potentially null pointer. Positive counts retain the original pointer check and read. GNU alloc.c:Flist returns nil without reading args whenever nargs is non-positive.',
    tests='All original assertions and fixtures remain byte-identical. One boundary test calls the actual native trampoline with null list storage for counts0,-1,-7 and checks nil plus balanced call state. No new Lisp correctness exploration or selector reduction.',
    goal_complete=False)
with (p / 'source297-static-review.json').open('x') as f:
    json.dump(review, f, indent=2)
runner = (p / 'run-source296-validation.py').read_text()
runner = runner.replace('source296', 'source297').replace('native-fixed-funcall/emaxx', 'native-funcall-dispatch/emaxx')
runner = runner.replace('source292', 'source296').replace('buffer-line-index/emaxx', 'native-fixed-funcall/emaxx')
old_test = "new_test = 'lisp::primitives::tests::buffer_line_indexes_preserve_gnu_lf_motion_narrowing_and_edits'"
assert runner.count(old_test) == 1
runner = runner.replace(old_test, "new_test = 'lisp::native_comp::runtime::tests::native_many_empty_and_negative_list_counts_accept_null_storage'")
ast.parse(runner)
with (p / 'run-source297-validation.py').open('x') as f:
    f.write(runner)
generated = (p / 'compare-source296-generated-loaded.py').read_text().replace('source296', 'source297').replace('native-fixed-funcall/emaxx', 'native-funcall-dispatch/emaxx')
ast.parse(generated)
with (p / 'compare-source297-generated-loaded.py').open('x') as f:
    f.write(generated)
print('Prepared source297: earlier existing funcall routing, sound empty argument slice, one boundary control')
