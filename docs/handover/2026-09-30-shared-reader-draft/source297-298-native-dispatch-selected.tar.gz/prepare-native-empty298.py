from pathlib import Path
import ast, hashlib, json, subprocess

p = Path(__file__).parent.resolve()
root = p.parents[2]
c = p.parent / 'recovered-2026-10-05/native-empty-arguments/emaxx'
g = p.parent / 'rebuilt-2026-10-01/emacs'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p / n).read_text())
base = read('source296-applied-commit.json')['commit']
manifest = read('source296-manifest.json')
assert all(sha(root / n) == h for n, h in manifest.items())
assert not c.exists()
c.parent.mkdir()
(c.parent / 'emacs').symlink_to(g, target_is_directory=True)
for command in [
    ['git', 'clone', '--shared', '--quiet', '--no-checkout', str(root), str(c)],
    ['git', '-C', str(c), 'sparse-checkout', 'init', '--no-cone'],
    ['git', '-C', str(c), 'sparse-checkout', 'set', '--no-cone',
     *sorted({'/' + n for n in manifest} | {'/tools/', '/compat/'})],
    ['git', '-C', str(c), 'checkout', '--detach', base],
]:
    subprocess.run(command, check=True)
assert all(sha(c / n) == h for n, h in manifest.items())
constants = {}
for node in ast.parse((p / 'prepare-native-dispatch297.py').read_text()).body:
    if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
        name = node.targets[0].id
        if name in ('old', 'new', 'test'):
            assert name not in constants
            constants[name] = ast.literal_eval(node.value)
assert set(constants) == {'old', 'new', 'test'}
path = c / 'src/lisp/native_comp/runtime.rs'
before = path.read_text()
assert before.count(constants['old']) == 1
after = before.replace(constants['old'], constants['new'])
anchor = '    #[test]\n    fn native_funcall_builtin_error_unwinds_its_call_frame()'
assert after.count(anchor) == 1
after = after.replace(anchor, constants['test'] + anchor)
path.write_text(after)
assert [n for n, h in manifest.items() if sha(c / n) != h] == ['src/lisp/native_comp/runtime.rs']
start = before.index('pub(crate) fn invoke_subr(')
end = before.index('\nfn slow_unary_subr(', start)
assert after[start:end] == before[start:end]
record = dict(status='unvalidated correctness-only native empty-slice baseline',
              candidate=str(c), base_commit=base,
              inputs={str(f): sha(f) for f in [path, g / 'src/alloc.c']},
              mechanism='Same null/empty MANY slice repair and native boundary test as297. Every instruction of the applied296 invoke_subr router is unchanged.',
              purpose='Keep the cost of the Rust boundary repair separately measurable from the optional early-funcall routing. Compare original296, corrected298 and optimized297 with identical locked workloads.',
              test_scope='Same single added null-storage test and all original assertions/fixtures as297. Existing native/VM/numeric/allocator/root selection stays intact.',
              goal_complete=False)
with (p / 'source298-static-review.json').open('x') as f:
    json.dump(record, f, indent=2)
runner = (p / 'run-source297-validation.py').read_text().replace('source297', 'source298').replace('native-funcall-dispatch/emaxx', 'native-empty-arguments/emaxx')
anchor = "        run(profile + '-selected', [str(binary), '--exact', '--test-threads=1', *selectors])"
assert runner.count(anchor) == 1
runner = runner.replace(anchor, '''        # Compilation can overlap; serialize actual editor/test execution.
        if profile == 'gate':
            state['status'] = 'waiting for source297 selected comparisons to close'
            save_state()
            while not (p / 'native-dispatch-selection-closed-result.json').exists():
                time.sleep(20)
            prior_selection = read(p / 'native-dispatch-selection-closed-result.json')
            assert all(row['exit_code'] == 0 for row in prior_selection['steps']) and len(prior_selection['steps']) == 5
''' + anchor)
ast.parse(runner)
with (p / 'run-source298-validation.py').open('x') as f:
    f.write(runner)
generated = (p / 'compare-source297-generated-loaded.py').read_text().replace('source297', 'source298').replace('native-funcall-dispatch/emaxx', 'native-empty-arguments/emaxx')
ast.parse(generated)
with (p / 'compare-source298-generated-loaded.py').open('x') as f:
    f.write(generated)
print('Prepared source298 correctness-only baseline; original native router retained')
