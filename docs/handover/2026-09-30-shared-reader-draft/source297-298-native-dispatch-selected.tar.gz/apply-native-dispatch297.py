from pathlib import Path
import hashlib, json, subprocess

p = Path(__file__).parent.resolve()
root = p.parents[2]
c = p.parent / 'recovered-2026-10-05/native-funcall-dispatch/emaxx'
d = root / 'docs/handover/2026-09-30-shared-reader-draft'
read = lambda n: json.loads((p / n).read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
base = read('source296-applied-commit.json')['commit']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == base
assert read('native-dispatch-performance-sequence-closed-result.json')['status'] == 'timing audited; source decision pending'
timing = read('native-dispatch-performance-audit.json')
assert timing['status'] == 'all 288 processes and actual results/modes verified'
assert not timing['short_bodies']
for tag in ['source297', 'source298']:
    selected = read(tag + '-selected-audit.json')
    assert selected['status'] == 'passed' and selected['source_inputs_verified'] == 532
    assert selected['ordinary_comparisons'] == 47
    assert all(x['passed'] == 327 and x['failed'] == x['ignored'] == 0 for x in selected['profiles'].values())
    assert selected['retained_broad_probe_failure']['exact_match'] is False
    for n, h in selected['evidence_files'].items():
        assert sha(Path(n)) == h, n
for n, h in timing['evidence_files'].items():
    assert sha(Path(n)) == h, n
for n, h in read('source296-manifest.json').items():
    assert sha(root / n) == h, n
manifest = read('source297-manifest.json')
assert all(sha(c / n) == h for n, h in manifest.items())
decision = dict(
    status='apply source297 after closed selected validation and three-way full16 diagnostic',
    applied_source='source297', corrected_baseline='source298 retained separately, unapplied',
    evidence={n: sha(p / n) for n in ['source297-selected-audit.json', 'source298-selected-audit.json', 'native-dispatch-performance-audit.json', 'source297-static-review.json']},
    geometric_mean_body_optimized_over_corrected=timing['geometric_mean_optimized_over_corrected'],
    geometric_mean_body_optimized_over_original=timing['geometric_mean_optimized_over_original'],
    geometric_mean_gnu_ratios=timing['geometric_mean_gnu_ratios'],
    cases=[{k: v for k, v in x.items() if k != 'samples'} for x in timing['cases']],
    reason='The existing guarded funcall path moves ahead of irrelevant immutable primitive-name tests, after unchanged handler synchronization. This removes concrete routing work without adding state, specialization or a new lifecycle. The separate null/empty MANY slice correction eliminates invalid Rust slice construction and preserves GNU Flist nonpositive-count behavior. Both candidates pass327 selected tests per profile and47 ordinary GNU comparisons. All288 measured process results/modes verify. Native body median is1.836% lower than corrected298; geometric body ratio0.989164. Bytecode calls, bytecode-to-native, sort and undo are0.212%,0.093%,0.928%,0.618% slower. All samples remain; the diagnostic does not establish statistical significance or explain every difference.',
    qualification='Original296, corrected298 and optimized297 each have three rotated full16 pilots, one sample/no warmup per pilot. Real allocation counters, calibrated nine-round/every-case3% acceptance, remaining architecture/ownership, complete exact-source platform validation and final audit remain required. Existing60 display-column failures and historical GNU/Emaxx census failures stay open. No workload, result, timeout, selector, GC cadence or tolerance changes.',
    goal_complete=False)
with (p / 'source297-application-decision.json').open('x') as f:
    json.dump(decision, f, indent=2)
patch = p / 'source297-portable-incremental.patch'
assert sha(patch) == read('source297-portable-draft-audit.json')['patches'][0]['sha256']
steps = []
for command in [['git', 'apply', '--check', str(patch)], ['git', 'apply', str(patch)], ['git', 'diff', '--check']]:
    run = subprocess.run(command, cwd=root, capture_output=True, text=True)
    steps.append(dict(command=command, exit_code=run.returncode, stdout=run.stdout, stderr=run.stderr))
    assert run.returncode == 0, steps[-1]
assert all(sha(root / n) == h and (root / n).stat().st_mode & 0o777 == (c / n).stat().st_mode & 0o777 for n, h in manifest.items())
record = dict(status='source297 applied; all532 validated bytes and modes verified', base_commit=base,
              patch_sha256=sha(patch), steps=steps, goal_complete=False)
with (p / 'source297-applied-source-verification.json').open('x') as f:
    json.dump(record, f, indent=2)
for name in ['source297-application-decision.json', 'source297-applied-source-verification.json']:
    with (d / name).open('xb') as f:
        f.write((p / name).read_bytes())
print(record['status'])
