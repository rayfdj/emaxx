from pathlib import Path
import ast,gzip,hashlib,io,json,re,tarfile
p=Path(__file__).parent.resolve();root=p.parents[2];candidate=p.parent/'recovered-2026-09-30/string-ops/emaxx';out=root/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest();read=lambda name:json.loads((p/name).read_text())
node=next(n for n in ast.parse((p/'audit-shared-reader196-fresh-selected.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='audit_log')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<raw-auditor>','exec'))
manifest=read('source231-manifest.json');assert len(manifest)==440
assert all(sha((candidate/name).read_bytes())==sha((root/name).read_bytes())==h for name,h in manifest.items())
command=read('source231-gate-controls-command.json');result=read('source231-gate-controls-result.json');names=command['selected_inventory']
assert len(names)==31 and names==read('source230-gate-controls-command.json')['selected_inventory']
assert result['exit_code']==0 and result['source_unchanged']
assert audit_log(names,(p/'source231-gate-controls.log').read_text(),31,0)==[]
assert sha((p/'source231-gate-libtest').read_bytes())==command['binary_sha256']
for stage in ['check','fmt','clippy','diff','gate-build']:
    result=read('source231-'+stage+'-result.json');assert result['exit_code']==0 and result['source_unchanged']
    raw=(p/('source231-'+stage+'.log')).read_text();assert not re.search(r'^warning(?:\[.*\])?:',raw,re.M)
    for line in raw.splitlines():
        try:item=json.loads(line)
        except json.JSONDecodeError:continue
        assert item.get('message',{}).get('level') not in ['warning','error']
record=dict(status='all 31 focused gate controls pass',passed=31,failed=0,ignored=0,source_inputs_verified=440,binary_sha256=command['binary_sha256'],goal_complete=False,
    qualification='Exact same focused names as source230, with the added fixture setup corrected and all original bare-reader assertions retained. Production inputs are unchanged from source230, whose 937 affected-module gate tests and 54 ordinary comparisons passed. This does not relabel the failed source230 focused run. Fresh source231 complete Rust, release and ordinary runs are active; source229 complete terminal run is separate and has a known divergence.')
with (p/'source231-focused-audit.json').open('x') as f:json.dump(record,f,indent=2)
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
names=['source231-focused-audit.json','source231-gate-controls-command.json','source231-gate-controls-result.json','source231-gate-controls.log','source231-gate-inventory.txt','source231-gate-build-command.json','source231-gate-build-result.json','source231-gate-build.log','source231-validation-result.json','source231-applied-to-task-worktree.json','source231-full-gate-launch.json','source231-release-launch.json','source231-ordinary-launch.json','run-source231-full-gate.py','run-source231-release.py','run-source231-build-and-ordinary.py',Path(__file__).name,'audit-shared-reader196-fresh-selected.py']
package('source231-focused-and-complete-launch',{name:p/name for name in names},record)
print(json.dumps(record,indent=2))
