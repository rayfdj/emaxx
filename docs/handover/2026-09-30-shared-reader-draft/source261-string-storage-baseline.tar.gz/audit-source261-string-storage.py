from pathlib import Path
import ast
import hashlib
import json
import re

p = Path(__file__).parent.resolve()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(node for node in ast.parse((p / 'audit-source261-compare-strings.py').read_text()).body
            if isinstance(node, ast.FunctionDef) and node.name == 'parse')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<lossless-token-parser>', 'exec'))
editors = ['gnu', 'source261', 'source174', 'source207', 'source249']
records = []
for fixture, count, width, key_width in [
    ('string-empty-identities', 12, 10, 1),
    ('string-pure-storage-operations', 96, 10, 3),
    ('string-pure-storage-values', 96, 10, 3),
]:
    outcomes, processes = {}, {}
    for editor in editors:
        stem = 'source261-probe-' + fixture + '-' + editor
        command, result = read(stem + '-command.json'), read(stem + '-result.json')
        assert result['exit_code'] == 0 and not result['timed_out']
        assert result['source_unchanged'] and result['inputs_unchanged']
        assert all(sha(Path(name)) == digest for name, digest in command['inputs'].items())
        assert sha(p / (stem + '.stdout')) == result['stdout_sha256']
        assert sha(p / (stem + '.stderr')) == result['stderr_sha256']
        assert not (p / (stem + '.stderr')).read_bytes()
        # Latin-1 maps each byte one-to-one. No replacement, normalization,
        # or equivalence between differently encoded strings is introduced.
        data = (p / (stem + '.stdout')).read_bytes()
        rows = parse(data.decode('latin1'))
        assert len(rows) == count and all(len(row) == width for row in rows)
        keys = [tuple(row[:key_width]) for row in rows]
        assert len(set(keys)) == count
        if key_width == 3:
            assert set(keys) == {(str(kind), pure, str(operation)) for kind in range(6)
                                 for pure in ['nil', 't'] for operation in range(8)}
            assert all('void-variable' not in str(row[5]) for row in rows)
            assert all(row[5][0] in ['ok', 'error'] for row in rows)
        else:
            assert [row[0] for row in rows] == [str(i) for i in range(12)]
            assert all(row[2:4] == ['0', '0'] for row in rows)
        if fixture != 'string-pure-storage-operations':
            assert data.decode('utf8').encode('utf8') == data
        outcomes[editor] = {key: row[key_width:] for key, row in zip(keys, rows)}
        processes[editor] = result
    gnu = outcomes['gnu']
    assert all(value.keys() == gnu.keys() for value in outcomes.values())
    assert outcomes['source174'] == outcomes['source207']
    wrong = {editor: [list(key) for key in gnu if outcomes[editor][key] != gnu[key]]
             for editor in editors[1:]}
    historical = {}
    for editor in ['source174', 'source207', 'source249']:
        historical[editor] = dict(
            newly_wrong_rows=[list(key) for key in gnu if outcomes[editor][key] == gnu[key] != outcomes['source261'][key]],
            fixed_rows=[list(key) for key in gnu if outcomes[editor][key] != gnu[key] == outcomes['source261'][key]],
            qualification='Whole-row comparison only. Other fields can improve or regress within a row already containing a difference; no general regression-absence claim.')
    differences = [dict(key=list(key), gnu=gnu[key], **{editor: outcomes[editor][key] for editor in editors[1:]})
                   for key in gnu if any(outcomes[editor][key] != gnu[key] for editor in editors[1:])]
    record = dict(fixture=fixture, fixture_sha256=sha(p / (fixture + '.el')),
                  compared_rows=count, differing_rows={editor: len(keys) for editor, keys in wrong.items()},
                  wrong_keys=wrong, historical=historical, differences=differences, processes=processes)
    if key_width == 3:
        record['wrong_operation_and_poststate_rows'] = {
            editor: sum(outcomes[editor][key][2:] != gnu[key][2:] for key in gnu) for editor in editors[1:]}
        record['wrong_identity_observations'] = {
            editor: sum(sum(a != b for a, b in zip(outcomes[editor][key][:2], gnu[key][:2])) for key in gnu)
            for editor in editors[1:]}
    records.append(record)
assert records[0]['differing_rows']['source261'] == 6
assert records[2]['differing_rows'] == dict(source261=57, source174=63, source207=63, source249=56)
assert records[2]['wrong_operation_and_poststate_rows']['source261'] == 28
assert records[2]['historical']['source249']['newly_wrong_rows'] == [
    ['0', 'nil', str(i)] for i in [0, 1, 2, 3, 4, 6, 7]]
# Keep invalid probe attempts explicitly separate from valid comparisons.
syntax = read('source261-string-pure-storage-fixture-correction.json')
scope = read('source261-string-pure-storage-scope-correction.json')
assert all(row['exit_code'] == 255 for row in syntax['processes'])
assert all(row['void_variable_errors'] == 96 for row in scope['observations'].values())
for fixture in ['string-empty-identities', 'string-pure-storage-values']:
    expected = (p / ('source261-probe-' + fixture + '-gnu.stdout')).read_bytes()
    with (p / (fixture + '.expected')).open('xb') as stream:
        stream.write(expected + b'\n')
gnu = p.parent / 'rebuilt-2026-10-01/emacs'
references = {}
for name, anchors in {
    'src/alloc.c': ['make_clear_string (EMACS_INT length', 'make_clear_multibyte_string (EMACS_INT nchars', 'make_pure_string (const char *data', 'DEFUN ("purecopy"'],
    'src/lisp.h': ['struct Lisp_String', '#define STRING_SET_UNIBYTE'],
    'src/fns.c': ['DEFUN ("fillarray"', 'DEFUN ("clear-string"'],
    'src/data.c': ['DEFUN ("aset"'],
    'src/puresize.h': ['PURE_P (void *ptr)', 'CHECK_IMPURE (Lisp_Object obj'],
}.items():
    lines = (gnu / name).read_text().splitlines()
    references[name] = dict(sha256=sha(gnu / name), anchors={
        anchor: next(i + 1 for i, line in enumerate(lines) if anchor in line) for anchor in anchors})
record = dict(status='ordinary string-storage gaps verified', fixtures=records, gnu_references=references,
              syntax_failure_retained=syntax, scope_failure_retained=scope, goal_complete=False,
              qualification='Fifteen valid ordinary processes verify complete byte-preserved outputs for three fixtures on five recorded executables. The raw pure-storage fixture and explicit-value fixture each contain all96 cases; their observations overlap and must not be added together. The original three syntax failures and three scope-invalid runs are excluded. Source261 has six wrong empty-identity rows and57 wrong pure-storage rows, with28 operation/poststate differences. Seven whole rows newly differ from source249 and six now match; all seven new whole-row regressions involve the fresh purecopy identity of an ordinary empty unibyte string. The exact introducing source between249 and261 is not established by these probes. Nonempty pure writes already differ in prior checkpoints. All frozen candidates and selectors remain unchanged. This is a correctness baseline for compact strings, not a repair, full-runtime or performance pass.')
with (p / 'source261-string-storage-negative-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps([dict(fixture=row['fixture'], rows=row['compared_rows'], wrong=row['differing_rows'], wrong_operation_and_poststate_rows=row.get('wrong_operation_and_poststate_rows')) for row in records], indent=2))
