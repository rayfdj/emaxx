from pathlib import Path
import ast
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(node for node in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(node, ast.FunctionDef) and node.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
audit = read('source261-string-storage-negative-audit.json')
assert audit['status'] == 'ordinary string-storage gaps verified'
assert len(audit['fixtures']) == 3
files = {}
for fixture in ['string-empty-identities', 'string-pure-storage', 'string-pure-storage-contract',
                'string-pure-storage-operations', 'string-pure-storage-values']:
    files[fixture + '.el'] = p / (fixture + '.el')
    expected = p / (fixture + '.expected')
    if expected.exists():
        files[expected.name] = expected
    for path in p.glob('source261-probe-' + fixture + '-*'):
        assert path.is_file() and path.suffix in ['.json', '.stdout', '.stderr']
        files[path.name] = path
for name in [
    'source261-string-storage-negative-audit.json', 'audit-source261-string-storage.py',
    'audit-source261-compare-strings.py', 'source261-string-storage-probes.json',
    'source261-string-pure-storage-contract-probes.json', 'source261-string-pure-storage-operations-probes.json',
    'source261-string-pure-storage-values-probes.json', 'source261-string-storage-origin-probes.json',
    'source261-string-pure-storage-fixture-correction.json', 'source261-string-pure-storage-scope-correction.json',
    'source261-string-pure-storage-values-fixture.json', 'probe-source261-string-storage.py',
    'probe-source261-string-pure-storage-contract.py', 'probe-source261-string-pure-storage-operations.py',
    'probe-source261-string-pure-storage-values.py', 'probe-source261-string-storage-origin.py',
    'source261-manifest.json', 'source174-ordinary-artifacts.json', 'source207-ordinary-artifacts.json',
    'source249-ordinary-artifacts.json', 'source261-ordinary-artifacts.json',
    'package-source196-failure-and197-results.py', Path(__file__).name,
]:
    assert (p / name).is_file(), name
    files[name] = p / name
package('source261-string-storage-baseline', files, dict(audit=audit,
    qualification='Ordinary GNU/C-grounded baseline for still-unfinished empty/pure string representation. Source261 differs in six of12 empty-identity rows and57 of96 pure-storage rows. The raw and explicit-value pure fixtures overlap; do not add their counts. Seven whole-row empty-purecopy regressions are bracketed after source249 and by261; six other whole rows improve. Source174/main and207 match exactly. Retain both invalid fixture attempts and all raw-byte outputs separately; no failures are relabeled or outputs normalized. Source263 is unchanged and does not repair these additional storage gaps. No runtime patch, complete validation, memory or performance result is claimed by this archive.'))
