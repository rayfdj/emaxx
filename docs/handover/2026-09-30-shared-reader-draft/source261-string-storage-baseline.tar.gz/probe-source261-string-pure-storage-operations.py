from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

p = Path(__file__).parent.resolve()
root = p.parents[2]
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
gnu = p.parent / 'rebuilt-2026-10-01/emacs'
source = json.loads((p / 'source261-manifest.json').read_text())
unchanged = lambda: len(source) == 488 and all(sha(root / name) == digest for name, digest in source.items())
binaries = {'gnu': gnu / 'src/emacs'}
for version in [261, 174]:
    artifacts = json.loads((p / ('source' + str(version) + '-ordinary-artifacts.json')).read_text())
    for name, item in artifacts.items():
        assert sha(Path(name)) == sha(Path(item['immutable_copy'])) == item['sha256']
    binaries['source' + str(version)] = Path(next(name for name in artifacts if Path(name).name == 'emaxx'))
assert sha(binaries['gnu']) == json.loads((root / 'compat/oracle.lock.json').read_text())['emacs_binary_sha256']
results = []
for fixture_name in ['string-pure-storage-operations']:
    fixture = p / (fixture_name + '.el')
    for editor, binary in binaries.items():
        assert unchanged()
        stem = 'source261-probe-' + fixture_name + '-' + editor
        inputs = {str(path): sha(path) for path in [fixture, Path(__file__), binary, binary.with_suffix('.pdmp'),
                  gnu / 'src/config.h', gnu / 'src/Makefile', gnu / 'src/fns.c', gnu / 'src/alloc.c', gnu / 'src/data.c', gnu / 'src/lisp.h']}
        command = [str(binary), '-Q', '--batch', '--eval', '(prin1 ' + fixture.read_text() + ')']
        with (p / (stem + '-command.json')).open('x') as out:
            json.dump(dict(command=command, working_directory=str(root), environment_override=dict(LANG='C', LC_ALL='C'),
                           inputs=inputs, timeout_seconds=120,
                           qualification='Same ordinary Lisp inputs in rebuilt pinned GNU, the retained source261 release and retained main/source174 release at their original locations. Does not modify any frozen runtime input or existing expectation. Historical attribution is limited to this exact probe.'), out, indent=2)
        started = time.monotonic()
        try:
            completed = subprocess.run(command, cwd=root, env=dict(os.environ, LANG='C', LC_ALL='C'),
                                       stdin=subprocess.DEVNULL, capture_output=True, timeout=120)
            code, stdout, stderr, timed_out = completed.returncode, completed.stdout, completed.stderr, False
        except subprocess.TimeoutExpired as error:
            code, stdout, stderr, timed_out = None, error.stdout or b'', error.stderr or b'', True
        for extension, data in [('stdout', stdout), ('stderr', stderr)]:
            with (p / (stem + '.' + extension)).open('xb') as out:
                out.write(data)
        result = dict(fixture=fixture_name, editor=editor, exit_code=code, timed_out=timed_out,
                      elapsed_seconds=time.monotonic() - started, stdout_sha256=sha(p / (stem + '.stdout')),
                      stderr_sha256=sha(p / (stem + '.stderr')), source_unchanged=unchanged(),
                      inputs_unchanged=all(sha(Path(name)) == digest for name, digest in inputs.items()))
        with (p / (stem + '-result.json')).open('x') as out:
            json.dump(result, out, indent=2)
        results.append(result)
        assert result['source_unchanged'] and result['inputs_unchanged']
        print(json.dumps(result), flush=True)
with (p / 'source261-string-pure-storage-operations-probes.json').open('x') as out:
    json.dump(dict(results=results, goal_complete=False,
                   qualification='Process evidence only; raw empty-identity/pure-storage outcomes still require audit. Existing selected/full validation remains separately recorded.'), out, indent=2)
