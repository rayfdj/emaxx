from pathlib import Path
import hashlib, json, re

p = Path(__file__).parent.resolve()
root = p.parents[2]
read = lambda n: json.loads((p / n).read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
selected = read('source308-selected-audit.json')
timing = read('native-subr308-performance-audit.json')
terminal = read('source304-macos-terminal-audit.json')
applied = read('source308-applied-source-verification.json')
assert applied['status'] == 'source308 applied; all541 validated bytes and modes verified'
assert selected['status'] == 'passed' and selected['ordinary_comparisons'] == 52
assert timing['status'] == 'all 192 processes and actual results/modes verified'
assert all(sha(root / n) == h for n, h in read('source308-manifest.json').items())
assert terminal['status'] == 'passed' and terminal['matching_comparisons'] == 686
changes = [(r['optimized_over_baseline'] - 1) * 100 for r in timing['cases']]
summary = f'''## Applied native function objects — 6 October 2026

**Source308 is applied; the full goal remains incomplete.** Native functions now
use one actual 88-byte GNU-layout subr for calls, metadata, identity and GC. The
old native-function record and three persistent descriptor/name maps are removed.
Direct calls read the function pointer and arities from the object. Five Lisp
fields are traced explicitly; unreachable subrs release their C names.

The [closed selected evidence](PREFIXsource308-native-object-selected-manifest.json)
verifies all 541 source inputs/modes, fresh warning-free strict checks,
**1,031 passes per profile**, including all 24 audit tests, and **52 ordinary GNU
comparisons**, including 198 generated printer rows. Original fixtures, assertions
and expected bytes remain. The original dabbrev regression is repaired by making
`commandp` recognize the native object's interactive field; native reader and
property identity and exact GNU C-name printing are covered too.

The [closed full16 diagnostic](PREFIXsource308-native-object-performance-manifest.json)
verifies all **192 actual process answers and execution modes**. The raw body
geometric ratio to304 is **{timing['geometric_mean_optimized_over_baseline']:.6f}**;
individual changes range from **{min(changes):+.3f}% to {max(changes):+.3f}%**.
308's paired GNU aggregate is **{timing['geometric_mean_gnu_ratios']['source308']:.6f}×**.
Every sample remains. These three alternating pilots do not establish statistical
significance or GNU parity. Real counters, calibration, nine rounds and every-case
upper95% ratio at most1.03 remain required.

Predecessor304 platform results are closed and preserved: Linux frozen passes
519 files /7,928 equal outcomes; macOS Rust passes3,139 tests with two existing
ignores; [macOS terminal](PREFIXsource304-macos-terminal-results-manifest.json)
passes all226 scenarios /686 screen and filesystem comparisons. Linux Rust stays
failed after2,291 passes at the GNU first-record census (-7 instead of2), leaving
758 library names and both Cargo stages unstarted. macOS frozen stays failed with
7,915 exact matches and six existing build-feature skip-diagnostic differences.
These results certify304 only. Exact308 full platform checks are next.

Main remains `21d20f0e`, PR79 stays draft. Symbol/unit authority, real intervals and
pure storage, physical accounting, public runtime ownership, final adversarial
review, complete final-source validation and the full performance criterion remain
open. See the native continuation for failed drafts and exact-source launch receipts.

'''
for name in ['HANDOVER.md', 'docs/runtime-representation-progress.md',
             'docs/runtime-representation-native-fixed-calls.md']:
    path = root / name
    text = path.read_text()
    prefix = 'docs/handover/2026-09-30-shared-reader-draft/' if name == 'HANDOVER.md' else 'handover/2026-09-30-shared-reader-draft/'
    start = text.index('## Native object draft and closed platform results — 6 October 2026')
    end_marker = '## Source308 draft continuation' if 'native-fixed-calls' in name else '## Applied column and native-audit repair'
    end = text.index(end_marker, start)
    text = text[:start] + summary.replace('PREFIX', prefix) + text[end:]
    if 'native-fixed-calls' in name:
        text = text.replace('## Source308 draft continuation', '## Source308 implementation and preserved failures', 1)
        text = text.replace('The unapplied checkout is', 'The validated source remains frozen at', 1)
        text = text.replace('have not yet been measured.', 'are included in the ordinary full16 timing above; their separate contribution has not been isolated.', 1)
        start = text.index('Resume the existing coordinators under')
        end = text.index('## Applied column and native-audit repair', start)
        rows = '\n'.join(f"| {r['case']} | {r['median_gnu_ratios']['source304']:.4f}× | {r['median_gnu_ratios']['source308']:.4f}× | {(r['optimized_over_baseline'] - 1) * 100:+.3f}% |" for r in timing['cases'])
        continuation = '''All selected and timing coordinators are closed under
`target/runtime-goal/resume-2026-09-28`. Inspect `source308-applied-commit.json`,
`source308-full-validation-launch.json` and `source308-full-launch.json` before
continuing exact-source Linux/macOS work. Do not restart write-once jobs or edit
frozen checkouts. A launch is not a validation result. The native units' host
ownership and public Rust API serialization remain unfinished; this subr change
does not certify them. Earlier GNU census failures and source276's Emaxx negative
remain unresolved.

| Workload | Published304 / GNU | Native-object308 / GNU | 308 body vs304 |
| --- | ---: | ---: | ---: |
''' + rows + '\n\n'
        text = text[:start] + continuation + text[end:]
    path.write_text(text)
progress = root / 'docs/runtime-representation-progress.md'
text = progress.read_text()
start = text.index('This map reflects applied source304 (534 inputs).')
end = text.index('| Full-goal requirement', start)
text = text[:start] + '''This map reflects applied source308 (541 inputs). Its warning-free selected
validation and paired full16 diagnostic are closed. All338 original column probe
rows still match GNU. Source304 platform results and failures remain explicit
above; exact308 full platform validation follows. A checkpoint does not complete
the goal.

''' + text[end:]
text = text.replace('Required live-root and reclamation controls remain and pass selected source304.', 'Required live-root and reclamation controls remain and pass selected source308; actual native subrs add five-field survival and cyclic reclamation coverage.', 1)
text = text.replace('Real intervals, unified pure storage, allocated-symbol authority and remaining host adapters are unfinished.', 'Source308 replaces native function records and three descriptor/name maps with one actual GNU-layout subr. Real intervals, unified pure storage, allocated-symbol authority, native-unit ownership and remaining host adapters are unfinished.', 1)
replacements = {
    '7. Equivalent performance': f"All16 workloads and the3% ceiling remain locked. The304/308 diagnostic verifies192 actual answers/modes; raw body geometric ratio is{timing['geometric_mean_optimized_over_baseline']:.6f}, paired GNU aggregate for308 is{timing['geometric_mean_gnu_ratios']['source308']:.6f}×. Every original/corrected baseline, unfavorable sample and rejected candidate remains. Real counters, calibration, prescribed repetitions/distributions and every-case acceptance remain open.",
    '8. Complete validation': 'Source308 strict checks are warning-free;1031 selected tests/profile and52 actual GNU comparisons pass, including198 generated printer rows and all338 original column rows.304 Linux frozen and macOS Rust/TTY pass their complete inventories; Linux Rust retains a GNU census failure and758 unstarted library names, and macOS frozen retains six existing strict skip-diagnostic differences. Exact308 full platform validation follows. Final-source platform/release/frozen/terminal validation remains required.',
    '9. Independently checkable delivery': 'Portable308 patches, raw commands/results and all192 timing answers/modes are retained.305/306/307 and308 development failures are separately preserved.308 is applied; exact-source platform validation follows. Main remains21d20f0e and PR79 is draft. Final source/evidence review and the remaining architecture/performance requirements are open.'
}
for label, value in replacements.items():
    text, count = re.subn(r'^\| ' + re.escape(label) + r' \|[^\n]*$', '| ' + label + ' | ' + value + ' |', text, count=1, flags=re.M)
    assert count == 1, label
progress.write_text(text)
print('Updated applied308 continuation and complete requirement map from closed evidence')
