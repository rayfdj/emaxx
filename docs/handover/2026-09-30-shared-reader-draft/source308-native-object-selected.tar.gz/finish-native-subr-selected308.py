from pathlib import Path
import hashlib,json,subprocess,sys,time
p=Path(__file__).parent.resolve();c=p.parent/'recovered-2026-10-06/native-subr-callbacks/emaxx';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();read=lambda n:json.loads((p/n).read_text())
helpers={n:sha(p/n) for n in ['run-source308-validation.py','native_fixed_validation_support.py','compare-vm-dispatch-fixtures.py','compare-source308-generated-loaded.py','audit-native-subr-selected308.py',Path(__file__).name]}
state=dict(status='waiting for source308 validation',steps=[],helpers=helpers,goal_complete=False)
def save():(p/'native-subr-selection308-state.json').write_text(json.dumps(state,indent=2))
def run(stage,cmd):
 assert all(sha(p/n)==h for n,h in helpers.items());state['status']='running '+stage;save();start=time.monotonic();(p/f'native-subr-selection308-{stage}-command.json').open('x').write(json.dumps(dict(command=cmd,cwd=str(p),helpers=helpers),indent=2))
 with (p/f'native-subr-selection308-{stage}.log').open('xb') as f:r=subprocess.run(cmd,cwd=p,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT)
 state['steps'].append(dict(stage=stage,exit_code=r.returncode,elapsed_seconds=time.monotonic()-start,helpers_unchanged=all(sha(p/n)==h for n,h in helpers.items())));save();assert r.returncode==0
save()
try:
 while not (p/'source308-validation-result.json').exists():time.sleep(20)
 assert read('source308-validation-result.json')['status']=='strict, selected and ordinary build passed; raw audit and ordinary comparisons required'
 assert read('source308-portable-draft-audit.json')['patches'][0]['inputs']==541
 names=list(read('source304-selected-audit.json')['ordinary_results'])+['native-subr-authority','native-subr-c-names','native-subr-consumers'];assert len(names)==51
 run('ordinary',[sys.executable,'-B',str(p/'compare-vm-dispatch-fixtures.py'),'source308',str(c),*names])
 run('generated',[sys.executable,'-B',str(p/'compare-source308-generated-loaded.py')])
 run('audit',[sys.executable,'-B',str(p/'audit-native-subr-selected308.py')])
 state['status']='selected native-subr validation audited; full validation and performance remain'
except Exception as e:state.update(status='selection stopped',error=repr(e))
finally:
 save();(p/'native-subr-selection308-result.json').open('x').write(json.dumps(state,indent=2))
print(json.dumps(state),flush=True)
