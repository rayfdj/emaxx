from pathlib import Path
import json, re, subprocess

p=Path(__file__).parent.resolve()
root=p.parents[2]
head=json.loads((p/'source284-applied-commit.json').read_text())['commit']
def save(name,value):
    with (p/name).open('x') as f:json.dump(value,f,indent=2)
assert json.loads((p/'source284-applied-push.json').read_text())['exit_code']==0
assert subprocess.check_output(['git','ls-remote','--heads','origin','refs/heads/runtime-char-tables'],cwd=root,text=True).split()[0]==head
launches=[]
for validation in ['rust','frozen']:
    command=['gh','workflow','run','frozen-run.yml','--repo','rayfdj/emaxx','--ref','runtime-char-tables','-f','validation='+validation]
    result=subprocess.run(command,cwd=root,stdin=subprocess.DEVNULL,capture_output=True,text=True)
    prefix='source284-linux-'+validation
    save(prefix+'-dispatch.json',dict(command=command,commit=head,exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr))
    result.check_returncode()
    match=re.fullmatch(r'https://github.com/rayfdj/emaxx/actions/runs/(\d+)\s*',result.stdout)
    assert match,result.stdout
    run_id=int(match[1])
    state=json.loads(subprocess.check_output(['gh','run','view',str(run_id),'--repo','rayfdj/emaxx','--json','status,conclusion,headSha,url'],cwd=root,text=True))
    assert state['headSha']==head
    launch=dict(run_id=run_id,state=state,source_commit=head,runtime_source='source284',
                qualification='Exact pushed source284 canonical printer/reader checkpoint. Requires audited520 inputs, zero-warning strict checks, six targeted contracts in both profiles and42 ordinary GNU comparisons. Source282217/1073 selected passes are predecessor evidence, and this full run must validate final source284. Repairs the actual native constant wrong-output negative; retains original missing-path/helper failures and all earlier negatives, including the unresolved source276 census failure. No full-platform, process-wide OOM, ownership/accounting or performance completion is inferred from dispatch.')
    save(prefix+'-launch.json',launch)
    launches.append(launch)
print(json.dumps(launches))
