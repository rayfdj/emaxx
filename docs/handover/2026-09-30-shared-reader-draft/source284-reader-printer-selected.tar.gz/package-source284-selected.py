from pathlib import Path
import ast
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).parent.resolve()
out = p / 'source284-publication-stage'
out.mkdir(exist_ok=True)
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))

audit = read('source284-selected-audit.json')
assert audit['status'] == 'passed' and audit['ordinary_comparisons'] == 42
assert all(r['passed'] == 6 and r['failed'] == r['ignored'] == 0 for r in audit['profiles'].values())
applied = read('source284-applied-commit.json')
assert applied['source_inputs'] == 520
assert read('source284-applied-push.json')['exit_code'] == 0
assert not read('source282-bounds-matrix.json')['matches_gnu']
assert read('source284-bounds-gnu.json')['matches_original_test_helper_gnu']
allowed = {'.json', '.log', '.txt', '.py', '.h', '.el', '.expected', '.stdout', '.stderr', '.patch'}
files = {}
for f in p.iterdir():
    if not f.is_file() or f.suffix not in allowed:
        continue
    if f.name.startswith(('source282-', 'source283-', 'source284-', 'reader-actual-codes')):
        # Full-platform and performance results belong in separate closed bundles.
        # Their prepared scripts are retained below, but no live state/log is certified here.
        if any(f.name.startswith('source' + str(n) + prefix)
               for n in (282, 283, 284) for prefix in ('-full-', '-performance-')):
            continue
        files[f.name] = f
    if f.suffix == '.py' and any(tag in f.name for tag in ('source282', 'source283', 'source284', 'reader-actual-codes', 'reader-characters-')):
        files[f.name] = f
for name in ('package-source196-failure-and197-results.py', 'printer-varied-v3-293638f0.el',
             'printer-varied-v3-gnu.stdout', 'printer-native-literals-83729.el'):
    assert (p / name).is_file(), name
    files[name] = p / name
c = p.parent / 'recovered-2026-10-03/reader-bounds-ascii/emaxx'
for stem in ('printer-full-range-streams', 'reader-internal-character-codes',
             'native-printed-string-constants', 'read-from-string-range-errors'):
    for suffix in ('.el', '.expected'):
        files['fixtures/' + stem + suffix] = c / 'tests/fixtures' / (stem + suffix)
scope = dict(
    status='selected checkpoint applied and pushed; full-platform validation and performance remain open',
    applied=applied, selected=audit,
    predecessor_selected=read('source282-selected-audit.json'),
    predecessor_portable_replay=read('source282-freeze-source-audit.json'),
    predecessor_bounds_failure=read('source282-bounds-matrix.json'),
    fixture_correction=read('source284-bounds-gnu.json'),
    dependencies=['source281-canonical-printer-unfinished', 'source279-string-allocation-selected',
                  'source279-varied-output-and-eglot-retry'],
    qualification=(
        'Source284 passes zero-warning strict checks, six targeted contracts per profile and 42 ordinary exact GNU comparisons. '
        'All 198 generated rows/4,088,269 bytes and 679 bounds cases match. All 520 inputs and modes replay from d64040a7 and main21d20f0e. '
        'Source282 passes 217 focused/two existing ignores and1073 affected tests per profile, but has a subsequently confirmed bounds error; '
        'it was never applied. Those predecessor counts do not certify source284. Source283 production repairs the bounds using the existing GNU-compatible '
        'validator; its added test fails at the GNU reference assertion because literal Unicode argv was decoded under a different locale. '
        'Source284 changes only that fixture to numeric character construction and exactly reproduces the actual test-helper GNU output. '
        'The source282 missing GNU path, interrupted affected run, first retry helper log-path errors, source283 failed reference assertion, and all prior negatives remain. '
        'Prepared apply/push/full helpers for unselected sources are not evidence of execution. Large binaries/images are identified by retained hashes but excluded. '
        'Full-platform and performance logs are excluded from this closed selected bundle; launch receipts establish starts only. '
        'Symbol/positioning/formatting adapters, ownership/accounting, intervals/pure storage, VM work and locked performance remain open.'),
    goal_complete=False)
package('source284-reader-printer-selected', files, scope)
