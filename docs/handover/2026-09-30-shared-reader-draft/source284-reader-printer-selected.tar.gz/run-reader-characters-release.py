from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/reader-internal-characters/emaxx'
gnu = p.parent / 'rebuilt-2026-10-01/emacs'
prefix = 'source' + sys.argv[1]
assert sys.argv[1].isdecimal()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
manifest = json.loads((p / (prefix + '-manifest.json')).read_text())
unchanged = lambda: all(sha(root / name) == digest for name, digest in manifest.items())

def save(suffix, data):
    with (p / (prefix + '-' + suffix + '.json')).open('x') as stream:
        json.dump(data, stream, indent=2)

env = dict(CARGO_TARGET_DIR=str(root / 'target/reader-character-validation'), CARGO_BUILD_JOBS='1',
           LANG='C', LC_ALL='C', RUST_MIN_STACK='134219728', RUST_TEST_THREADS='1',
           EMAXX_GC_VERIFY='1', EMAXX_IMAGE_TEMPLATE='1', EMAXX_FIXTURE_IMAGE_DIR=str(p / ('fixture-images-' + prefix)),
           EMAXX_GNU_SOURCE_DIRECTORY=str(gnu), EMAXX_DUMP_SOURCE_DIRECTORY=str(gnu), EMACS_TEST_DIRECTORY=str(gnu / 'test'))
assert unchanged()
for stage in ['check', 'fmt', 'clippy', 'diff']:
    receipt = json.loads((p / (prefix + '-' + stage + '-result.json')).read_text())
    assert receipt['exit_code'] == 0 and receipt['source_unchanged']
    log = (p / (prefix + '-' + stage + '.log')).read_text()
    assert not any(line.startswith('warning:') for line in log.splitlines())

def run(stage, command, metadata=None):
    record = dict(command=command, working_directory=str(root), environment_override=env,
                  source_manifest=prefix + '-manifest.json', helper_sha256=sha(Path(__file__)))
    record.update(metadata or {})
    save(stage + '-command', record)
    started = time.monotonic()
    with (p / (prefix + '-' + stage + '.log')).open('xb') as log:
        result = subprocess.run(command, cwd=root, env=dict(os.environ, **env), stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
    save(stage + '-result', dict(exit_code=result.returncode, elapsed_seconds=time.monotonic() - started, source_unchanged=unchanged()))
    assert unchanged()
    return result.returncode

command = ['cargo', 'test', '--locked', '--all-features', '--profile', 'release', '--lib', '--no-run', '--message-format=json-render-diagnostics']
if run('release-build', command):
    sys.exit(1)
artifacts = []
for line in (p / (prefix + '-release-build.log')).read_text().splitlines():
    if line.startswith('{'):
        message = json.loads(line)
        if message.get('reason') == 'compiler-artifact' and message.get('profile', {}).get('test') and message.get('executable') and message['target']['name'] == 'emaxx':
            artifacts.append(Path(message['executable']))
assert len(artifacts) == 1
binary = p / (prefix + '-release-libtest')
assert not binary.exists()
shutil.copy2(artifacts[0], binary)
assert sha(binary) == sha(artifacts[0])
if run('release-inventory', [str(binary), '--list', '--format', 'terse']):
    sys.exit(1)
inventory = [line[:-6] for line in (p / (prefix + '-release-inventory.log')).read_text().splitlines() if line.endswith(': test')]
assert len(inventory) == len(set(inventory)) == 3031
old = json.loads((p / 'source249-gate-controls-command.json').read_text())['command']
selectors = {name for name in old[1:] if '::' in name and not name.startswith('-')}
assert len(selectors) == 174
extra_names = {
    'reader_consumes_internal_character_bytes_without_host_text_loss',
    'native_printed_string_constants_keep_full_character_codes_and_sharing',
    'printer_preserves_full_character_codes_in_strings_buffers_and_callbacks',
    'print_preprocess_numbers_repeated_objects_in_second_encounter_order',
    'print_preprocess_respects_existing_states_and_resets_new_numbering',
    'print_preprocess_terminates_and_numbers_a_materialized_cycle',

    'string_sdata_allocation_failure_keeps_header_and_block_census',
    'string_allocation_failure_uses_bound_signal_and_native_exit',
    'string_size_bound_is_gnu_fixnum_maximum',
    'string_sblocks_compact_unborrowed_data_and_hold_borrowed_blocks',
    'string_sdata_resize_reuses_alignment_slop_and_preserves_contents',
    'borrowed_string_properties_survive_off_stack_guards_and_are_reclaimed_after_release',
    'off_stack_string_borrows_enter_the_weak_table_fixed_point',
    'exclusive_string_borrows_reject_gc_before_marking_or_sweeping',
    'string_empty_constructors_preserve_gnu_storage_identities',
    'pure_strings_preserve_gnu_identity_write_protection_and_error_order',
    'pure_string_properties_preserve_gnu_noop_and_readonly_behavior',
    'pure_string_headers_survive_unrooted_gc_outside_the_ordinary_census',
    'string_images_preserve_empty_roots_distinct_headers_and_restored_mutability',
    'subr_frontier_compare_strings_uses_gnu_simple_upcase_canonicalization',

    'compare_strings_preserves_gnu_range_errors_and_validation_order',
    'compare_strings_promotes_bytes_before_casing_actual_characters',
    'compare_strings_observes_live_case_table_mutation_and_gc',
    'numeric_casing_uses_exact_character_table_keys',
    'char_table_casing_preserves_gnu_modifier_and_integer_semantics',
    'string_ordering_uses_canonical_storage_and_lisp_symbol_names',
    'string_versions_follow_gnu_filenvercmp',
    'string_version_lessp_matches_upstream_cases',
    'native_funcall_dispatches_bytecode_like_eval_c',
    'image_freezes_and_thaws_hash_tables_as_pdumper_c_does',
    'string_property_hashes_follow_equal_through_nested_mutation_and_lookup',
    'string_equality_compares_actual_storage_with_and_without_properties',
    'string_equality_uses_lisp_symbol_names_and_positioned_symbol_policy',
    'string_property_values_use_equal_across_mutation_gc_and_interval_boundaries',
    'string_value_equality_uses_bytes_and_character_counts',
    'host_created_strings_preserve_mutation_properties_and_fill_errors',
    'vector_held_host_strings_preserve_binding_identity_and_mutation',
    'from_slots_parses_genuine_object',
    'cloning_string_reuses_the_text_allocation',
    'shared_text_equality_covers_shared_and_distinct_equal_allocations',
    'interned_symbol_names_reuse_one_text_allocation',
    'uninterned_symbol_names_remain_reclaimable',
    'uninterned_symbol_keeps_its_supplied_lisp_name',
    'native_strings_share_object_words_for_both_storage_forms',
    'native_gc_traces_string_properties_and_reclaims_string_cycles',
}
extra = [name for name in inventory if name.rsplit('::', 1)[-1] in extra_names]
assert {name.rsplit('::', 1)[-1] for name in extra} == extra_names
selectors.update(extra)
assert selectors <= set(inventory) and len(selectors) == 219
prior_common = json.loads((p / 'source255-gate-controls-command.json').read_text())['selectors']
assert len(prior_common) == 184 and set(prior_common) <= selectors
save('release-focused-inventory', dict(selectors=sorted(selectors), full_inventory_count=len(inventory), binary_sha256=sha(binary), prior_controls_preserved=174, common_string_controls_preserved=184))
status = run('release-controls', [str(binary), *sorted(selectors), '--exact', '--test-threads=1', '--nocapture'],
             dict(selectors=sorted(selectors), binary_sha256=sha(binary), expected_tests=len(selectors), existing_ignores=2))
retained = p / (prefix + '-release-focused-retained-inputs')
retained.mkdir()
files = [binary, *sorted((p / ('fixture-images-' + prefix)).glob('*.pdmp'))]
records = []
for path in files:
    destination = retained / path.name
    shutil.copy2(path, destination)
    assert sha(path) == sha(destination)
    records.append(dict(original=str(path), artifact=str(destination), sha256=sha(path), bytes=path.stat().st_size))
save('release-focused-retained-inputs', dict(files=records, qualification='Retains executable and every post-run image. Raw test verdicts require a separate audit; no pass is inferred from retention.'))
print(json.dumps(dict(prefix=prefix, exit_code=status, tests=len(selectors), source_unchanged=unchanged())), flush=True)
sys.exit(status)
