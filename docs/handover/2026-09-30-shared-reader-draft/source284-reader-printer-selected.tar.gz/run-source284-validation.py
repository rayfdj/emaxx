from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time

p=Path(__file__).parent.resolve();root=p.parents[2]
c=p.parent/'recovered-2026-10-03/reader-bounds-ascii/emaxx';g=p.parent/'rebuilt-2026-10-01/emacs'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
read=lambda n:json.loads((p/n).read_text())
base=read('source282-manifest.json')
assert read('source282-selected-audit.json')['status']=='passed'
assert read('source284-cache-clone.json')['exit_code']==0
assert (c.parent/'emacs').resolve()==g.resolve()
env=dict(CARGO_TARGET_DIR=str(c/'target/reader-character-validation'),CARGO_BUILD_JOBS='1',LANG='C',LC_ALL='C',
         RUST_MIN_STACK='134217728',RUST_TEST_THREADS='1',EMAXX_GC_VERIFY='1',EMAXX_IMAGE_TEMPLATE='1',
         EMAXX_FIXTURE_IMAGE_DIR=str(p/'fixture-images-source284'),EMAXX_GNU_SOURCE_DIRECTORY=str(g),
         EMAXX_DUMP_SOURCE_DIRECTORY=str(g),EMACS_TEST_DIRECTORY=str(g/'test'))
def save(name,value):
    with (p/('source284-'+name+'.json')).open('x') as f:json.dump(value,f,indent=2)
subprocess.run(['cargo','fmt','--all'],cwd=c,check=True)
files=set(base)|{'tests/fixtures/read-from-string-range-errors.el','tests/fixtures/read-from-string-range-errors.expected'}
m={n:sha(c/n) for n in sorted(files)};assert len(m)==520
changed={n for n,h in m.items() if base.get(n)!=h}
assert changed=={'src/lisp/primitives/dispatch/misc.rs','src/lisp/primitives/strings.rs','src/lisp/primitives/tests.rs',
                 'tests/fixtures/read-from-string-range-errors.el','tests/fixtures/read-from-string-range-errors.expected'}
assert (c/'src/lisp/primitives/strings.rs').read_text()==(p.parent/'recovered-2026-09-30/reader-internal-characters/emaxx/src/lisp/primitives/strings.rs').read_text().replace('fn validate_subarray(', 'pub(crate) fn validate_subarray(',1)
with (p/'source284-manifest.json').open('x') as f:json.dump(m,f,indent=2)
new=set(m)-set(read('source279-manifest.json'));assert len(new)==9
patch=subprocess.check_output(['git','diff','--binary','d64040a7efe9a5039750b7c0b8feb7796c57fe79','--',*sorted(m)],cwd=c)
for n in sorted(new):
    r=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',n],cwd=c,capture_output=True)
    assert r.returncode==1 and not r.stderr;patch+=r.stdout
with (p/'source284-reader.patch').open('xb') as f:f.write(patch)
unchanged=lambda:all(sha(c/n)==h for n,h in m.items())
state=dict(status='starting strict and targeted validation',source_manifest='source284-manifest.json',changes_from282=sorted(changed),results=[],profiles={},goal_complete=False)
def save_state():(p/'source284-validation-state.json').write_text(json.dumps(state,indent=2)+'\n')
def run(name,cmd,extra=None,environment=None):
    assert unchanged();actual_env=env if environment is None else environment
    save(name+'-command',dict(command=cmd,working_directory=str(c),environment_override=actual_env,source_manifest='source284-manifest.json',helper_sha256=sha(Path(__file__)),**(extra or {})))
    state.update(status='running '+name);save_state();start=time.monotonic()
    with (p/('source284-'+name+'.log')).open('xb') as log:
        result=subprocess.run(cmd,cwd=c,env=dict(os.environ,**actual_env),stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,timeout=1800)
    row=dict(stage=name,exit_code=result.returncode,elapsed_seconds=time.monotonic()-start,source_unchanged=unchanged())
    save(name+'-result',row);state['results'].append(row);save_state();assert row['source_unchanged']
    print(json.dumps(row),flush=True);return result.returncode
controls=sorted('lisp::primitives::tests::'+n for n in [
    'read_from_string_preserves_gnu_range_error_arguments_and_order',
    'reader_consumes_internal_character_bytes_without_host_text_loss',
    'native_printed_string_constants_keep_full_character_codes_and_sharing',
    'printer_preserves_full_character_codes_in_strings_buffers_and_callbacks',
    'substring_reversed_bounds_signal_without_host_panics',
    'compare_strings_preserves_gnu_range_errors_and_validation_order'])
try:
    for name,cmd in [('fmt',['cargo','fmt','--all','--','--check']),('check',['cargo','check','--locked','--all-targets','--all-features']),
                     ('clippy',['cargo','clippy','--locked','--all-targets','--all-features','--','-D','warnings']),('diff',['git','diff','--check'])]:
        assert run(name,cmd)==0
        assert not re.search(r'^warning(?:\[.*\])?:',(p/('source284-'+name+'.log')).read_text(),re.M)
    for profile,count in [('gate',3033),('release',3032)]:
        assert run(profile+'-fresh-crate',['cargo','clean','--package','emaxx','--profile',profile])==0
        assert run(profile+'-build',['cargo','test','--locked','--all-features','--profile',profile,'--lib','--no-run','--message-format=json-render-diagnostics'])==0
        artifacts=[]
        raw=(p/('source284-'+profile+'-build.log')).read_text()
        assert not re.search(r'^warning(?:\[.*\])?:',raw,re.M)
        for line in raw.splitlines():
            if line.startswith('{'):
                row=json.loads(line);assert row.get('message',{}).get('level') not in ['warning','error']
                if row.get('reason')=='compiler-artifact' and row.get('profile',{}).get('test') and row.get('executable') and row['target']['name']=='emaxx':artifacts.append(Path(row['executable']))
        assert len(artifacts)==1
        binary=p/('source284-'+profile+'-libtest');assert not binary.exists();shutil.copy2(artifacts[0],binary)
        assert sha(binary)==sha(artifacts[0]);save(profile+'-binary',dict(original=str(artifacts[0]),retained=str(binary),sha256=sha(binary)))
        assert run(profile+'-inventory',[str(binary),'--list','--format','terse'])==0
        inventory=[s[:-6] for s in (p/('source284-'+profile+'-inventory.log')).read_text().splitlines() if s.endswith(': test')]
        assert len(inventory)==len(set(inventory))==count and set(controls)<=set(inventory)
        assert run(profile+'-controls',[str(binary),*controls,'--exact','--test-threads=1','--nocapture'],dict(selectors=controls,binary_sha256=sha(binary)))==0
        raw=(p/('source284-'+profile+'-controls.log')).read_text()
        assert re.findall(r'^test (\S+) \.\.\. ok$',raw,re.M)==controls
        assert 'test result: ok. 6 passed; 0 failed; 0 ignored;' in raw
        target=p/('source284-'+profile+'-retained-inputs');target.mkdir();retained=[]
        for original in [binary,*sorted(Path(env['EMAXX_FIXTURE_IMAGE_DIR']).glob('*.pdmp'))]:
            dest=target/original.name;shutil.copy2(original,dest);assert sha(original)==sha(dest)
            retained.append(dict(original=str(original),artifact=str(dest),sha256=sha(original),bytes=original.stat().st_size))
        save(profile+'-retained-inputs',dict(files=retained));state['profiles'][profile]=dict(passed=6,failed=0,ignored=0,selectors=controls,retained_inputs=retained)
    assert run('ordinary-driver',[sys.executable,'-B',str(p/'build-source284-reader-ordinary.py'),'284'],environment={})==0
    names=list(read('source279-selected-audit.json')['ordinary_results'])+['printer-full-range-streams','reader-internal-character-codes','native-printed-string-constants','read-from-string-range-errors']
    assert len(names)==41
    assert run('ordinary-comparisons',[sys.executable,'-B',str(p/'compare-source282-reader-fixtures.py'),'source284',str(c),*names],environment={})==0
    assert run('generated-comparison',[sys.executable,'-B',str(p/'compare-source284-generated-loaded.py')],environment={})==0
    state['status']='strict, targeted and ordinary processes passed; raw audit required'
except Exception as error:state.update(status='failed or incomplete',error=repr(error))
finally:save_state();save('validation-result',state)
print(json.dumps(dict(status=state['status'],profiles={k:{n:v for n,v in r.items() if n!='retained_inputs'} for k,r in state['profiles'].items()})),flush=True)
sys.exit(0 if state['status']=='strict, targeted and ordinary processes passed; raw audit required' else 1)
