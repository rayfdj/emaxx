from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

p=Path(__file__).parent.resolve();root=p.parents[2]
c=p.parent/'recovered-2026-09-30/reader-internal-characters/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
read=lambda n:json.loads((p/n).read_text())
m,base=read('source282-manifest.json'),read('source279-manifest.json')
unchanged=lambda:all(sha(c/n)==h for n,h in m.items())
published_unchanged=lambda:all(sha(root/n)==h for n,h in base.items())
prep=read('source282-path-preparation.json');stages=prep['stages']
helpers={str(p/s[0]):sha(p/s[0]) for s in stages}
for r in prep['helpers']:
    assert sha(p/r['source'])==r['source_sha256'] and sha(p/r['successor'])==r['successor_sha256']
state=dict(status='starting corrected-path validation',source_manifest='source282-manifest.json',helpers=helpers,stages=stages,results=[],goal_complete=False)
def save_state():(p/'source282-path-selected-state.json').write_text(json.dumps(state,indent=2)+'\n')
try:
    for stage in stages:
        assert unchanged() and published_unchanged()
        assert Path(prep['gnu_link']).resolve()==Path(prep['gnu_target']).resolve()
        assert all(sha(Path(n))==h for n,h in helpers.items())
        command=[sys.executable,'-B',str(p/stage[0]),*stage[1:]]
        state.update(status='running '+stage[0],current_command=command);save_state()
        start=time.monotonic()
        run=subprocess.run(command,cwd=c,stdin=subprocess.DEVNULL,env=dict(os.environ,PYTHONUNBUFFERED='1',PYTHONDONTWRITEBYTECODE='1'))
        row=dict(command=command,exit_code=run.returncode,elapsed_seconds=time.monotonic()-start,source_unchanged=unchanged(),published_source_unchanged=published_unchanged())
        state['results'].append(row)
        assert row['source_unchanged'] and row['published_source_unchanged']
    state['status']='corrected-path selected processes finished; raw audit required'
except Exception as error:state.update(status='failed',error=repr(error))
finally:
    save_state()
    with (p/'source282-path-selected-result.json').open('x') as f:json.dump(state,f,indent=2)
print(json.dumps(state),flush=True)
sys.exit(0 if len(state['results'])==len(stages) and all(r['exit_code']==0 for r in state['results']) else 1)
