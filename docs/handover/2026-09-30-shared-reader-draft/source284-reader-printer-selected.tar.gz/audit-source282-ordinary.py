from pathlib import Path
import hashlib
import json
import re

p=Path(__file__).parent.resolve()
c=p.parent/'recovered-2026-09-30/reader-internal-characters/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
read=lambda n:json.loads((p/n).read_text())
m=read('source282-manifest.json')
assert len(m)==518 and all(sha(c/n)==h for n,h in m.items())
names=list(read('source279-selected-audit.json')['ordinary_results'])
assert len(names)==37
ordinary={}
for name in names+['printer-full-range-streams','reader-internal-character-codes','native-printed-string-constants']:
    comparison=read('source282-ordinary-'+name+'-comparison.json')
    pair=[];programs=[]
    for editor in ['gnu','emaxx']:
        stem='source282-ordinary-'+name+'-'+editor
        command,result=read(stem+'.command.json'),read(stem+'.result.json')
        assert result==comparison['outcomes'][editor]
        assert all(sha(Path(n))==h for n,h in command['inputs'].items())
        stdout,stderr=[(p/(stem+'.'+s)).read_bytes() for s in ['stdout','stderr']]
        assert sha(p/(stem+'.stdout'))==result['stdout_sha256'] and stderr.hex()==result['stderr_hex']
        assert result['exit_code']==0 and not result['timed_out'] and result['source_unchanged'] and result['inputs_unchanged']
        assert stdout and not stderr and result['expected_output'] is not False
        programs.append(command['command'][-1]);pair.append(stdout)
        if name in names:assert stdout==(p/('source279-ordinary-'+name+'-'+editor+'.stdout')).read_bytes()
    assert programs[0]==programs[1] and pair[0]==pair[1] and comparison['exact_match'] and comparison['passed']
    if name=='native-printed-string-constants':
        assert pair[0]==(p/'printer-native-literals-gnu.stdout').read_bytes()
        assert pair[0].startswith(b'(t t t ')
    if name=='reader-internal-character-codes':
        assert pair[0]==(p/'reader-actual-codes-v2-gnu.stdout').read_bytes()
    ordinary[name]=dict(stdout_sha256=hashlib.sha256(pair[0]).hexdigest(),stdout_bytes=len(pair[0]))
generated=read('source282-generated-loaded-comparison.json');assert generated['passed']
for editor in ['gnu','emaxx']:
    stem='source282-generated-loaded-'+editor
    command,result=read(stem+'-command.json'),read(stem+'-result.json')
    assert all(sha(Path(n))==h for n,h in command['inputs'].items())
    assert command['command'][-2:]==['-l',str(p/'printer-varied-v3-293638f0.el')]
    assert result['exit_code']==0 and not result['timed_out'] and result['source_unchanged'] and result['inputs_unchanged']
    output=(p/(stem+'.stdout')).read_bytes()
    assert len(output.splitlines())==198 and len(output)==4088269
    assert output==(p/'printer-varied-v3-gnu.stdout').read_bytes()==(p/'source279-varied-strings-v2-gnu.stdout').read_bytes()
    assert not (p/(stem+'.stderr')).read_bytes() and sha(p/(stem+'.stdout'))==result['stdout_sha256']
artifacts=read('source282-ordinary-artifacts.json');assert len(artifacts)==2
for original,row in artifacts.items():assert sha(Path(original))==sha(Path(row['immutable_copy']))==row['sha256']
for stage in ['ordinary-build','ordinary-image']:
    r=read('source282-'+stage+'-result.json');assert r['exit_code']==0 and r['source_unchanged']
    assert not re.search(r'^warning(?:\[.*\])?:',(p/('source282-'+stage+'.log')).read_text(),re.M)
record=dict(status='passed',source_inputs_verified=518,ordinary_comparisons=41,ordinary_results=ordinary,
            generated_rows=198,generated_bytes=4088269,generated_sha256='fead906d4b0aa20e9ef90a98b3a696c73267423190766ed0d0c188293e663960',
            ordinary_artifacts=artifacts,qualification='Actual ordinary executable/image and same programs in both editors; all raw outputs and zero stderr checked.37 earlier outputs unchanged. Original native negative now matches the retained GNU answer, including actual native status, sharing, properties and post-GC codes. Generated fixture is loaded in full, with198 nonempty rows required. Earlier failed native outputs and invalid empty invocation remain preserved. No full-platform, universal no-cheating or performance claim.',goal_complete=False)
with (p/'source282-ordinary-audit.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps({k:record[k] for k in ['status','ordinary_comparisons','generated_rows','generated_bytes']}))
