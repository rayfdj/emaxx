from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time

p = Path(__file__).parent.resolve()
root = p.parents[2]
c = p.parent / 'recovered-2026-09-30/reader-internal-characters/emaxx'
g = p.parent / 'rebuilt-2026-10-01/emacs'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p / n).read_text())
m, base = read('source282-manifest.json'), read('source279-manifest.json')
prefix = 'source282-rerun'
unchanged = lambda: all(sha(c / n) == h for n, h in m.items())
published_unchanged = lambda: all(sha(root / n) == h for n, h in base.items())
assert len(m) == 518 and unchanged() and published_unchanged()
assert (c.parent / 'emacs').resolve() == g.resolve()
assert read('source282-missing-gnu-path-withdrawal.json')['remaining'] == []
assert (p / 'source282-path-selected-result.json').is_file()
assert read('source282-path-gate-broad-result.json')['source_unchanged']
focused = read('source282-gate-controls-command.json')['selectors']
broad = read('source282-path-gate-broad-command.json')['selected_inventory']
assert len(focused) == len(set(focused)) == 219
assert len(broad) == len(set(broad)) == 1073
assert set(read('source279-gate-controls-command.json')['selectors']) <= set(focused)
assert set(read('source279-gate-broad-command.json')['selected_inventory']) <= set(broad)
env = dict(CARGO_TARGET_DIR=str(c / 'target/reader-character-validation'), CARGO_BUILD_JOBS='1',
           LANG='C', LC_ALL='C', RUST_MIN_STACK='134217728', RUST_TEST_THREADS='1',
           EMAXX_GC_VERIFY='1', EMAXX_IMAGE_TEMPLATE='1',
           EMAXX_FIXTURE_IMAGE_DIR=str(p / 'fixture-images-source282-path'),
           EMAXX_GNU_SOURCE_DIRECTORY=str(g), EMAXX_DUMP_SOURCE_DIRECTORY=str(g), EMACS_TEST_DIRECTORY=str(g / 'test'))
state = dict(status='starting selected rerun', source_manifest='source282-manifest.json', results=[], profiles={}, goal_complete=False)
def save(name, value):
    with (p / (prefix + '-' + name + '.json')).open('x') as f: json.dump(value, f, indent=2)
def save_state(): (p / (prefix + '-state.json')).write_text(json.dumps(state, indent=2) + '\n')
def verify():
    assert unchanged() and published_unchanged()
    assert (c.parent / 'emacs').resolve() == g.resolve()
def run(name, command, extra=None, timeout=3600):
    verify()
    save(name + '-command', dict(command=command, working_directory=str(c), environment_override=env,
                                source_manifest='source282-manifest.json', helper_sha256=sha(Path(__file__)),
                                timeout_seconds=timeout, **(extra or {})))
    state.update(status='running ' + name); save_state()
    start = time.monotonic(); timed_out = False
    with (p / (prefix + '-' + name + '.log')).open('xb') as log:
        try:
            result = subprocess.run(command, cwd=c, env=dict(os.environ, **env), stdin=subprocess.DEVNULL,
                                    stdout=log, stderr=subprocess.STDOUT, timeout=timeout)
            code = result.returncode
        except subprocess.TimeoutExpired: code, timed_out = None, True
    result = dict(stage=name, exit_code=code, timed_out=timed_out, elapsed_seconds=time.monotonic()-start,
                  source_unchanged=unchanged(), published_source_unchanged=published_unchanged())
    save(name + '-result', result); state['results'].append(result); save_state(); verify()
    print(json.dumps(result), flush=True)
    return result
def audit(stem, names, ignored_names):
    command, result = read(stem + '-command.json'), read(stem + '-result.json')
    assert sha(Path(command['command'][0])) == command['binary_sha256']
    assert command['command'][1:] in [names + ['--exact','--nocapture','--test-threads=1'],
                                      names + ['--exact','--test-threads=1','--nocapture']]
    raw = (p / (stem + '.log')).read_text()
    starts = list(re.finditer(r'^test (\S+) \.\.\. ', raw, re.M))
    assert [r[1] for r in starts] == names
    observed = {}
    for i, match in enumerate(starts):
        end = starts[i+1].start() if i+1 < len(starts) else raw.find('\nfailures:',match.end())
        if end < 0: end = raw.index('\ntest result:',match.end())
        verdict = re.findall(r'(?:^|\s)(ok|FAILED|ignored)(?:,[^\n]*)?\s*\Z',raw[match.end():end])
        assert len(verdict) == 1, (match[1],raw[match.end():end][-500:])
        observed[match[1]] = verdict[0]
    counts = {v:list(observed.values()).count(v) for v in ['ok','FAILED','ignored']}
    summary = re.search(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; 0 measured;',raw,re.M)
    assert summary and tuple(map(int,summary.group(2,3,4))) == tuple(counts.values())
    assert {n for n,v in observed.items() if v=='ignored'} == set(ignored_names)
    assert result['source_unchanged'] and result['exit_code'] == (101 if counts['FAILED'] else 0)
    value = dict(status='failed' if counts['FAILED'] else 'passed', counts=counts, raw_verdicts=observed,
                 source_inputs_verified=518, command_file=stem+'-command.json', log_sha256=sha(p/(stem+'.log')),
                 binary_sha256=command['binary_sha256'], ignored_tests=sorted(ignored_names),
                 qualification='Every original selected name, order and raw verdict checked. Earlier setup/helper failures remain separate. No full-platform or performance claim.')
    with (p/(stem+'-audit.json')).open('x') as f: json.dump(value,f,indent=2)
    return value
def retain(profile, binary):
    target = p/(prefix+'-'+profile+'-retained-inputs'); target.mkdir()
    records = []
    for original in [binary,*sorted(Path(env['EMAXX_FIXTURE_IMAGE_DIR']).glob('*.pdmp'))]:
        destination = target/original.name; shutil.copy2(original,destination)
        assert sha(original) == sha(destination)
        records.append(dict(original=str(original),artifact=str(destination),sha256=sha(original),bytes=original.stat().st_size))
    save(profile+'-retained-inputs',dict(files=records))
    return records
try:
    ignored = ['tty::tty_differential_end_to_end','tty::tty_smoke_end_to_end']
    gate = p/'source282-gate-libtest'
    assert sha(gate) == read('source282-binary.json')['sha256']
    gate_affected = audit('source282-path-gate-broad',broad,[])
    run('gate-controls',[str(gate),*focused,'--exact','--test-threads=1','--nocapture'],dict(selectors=focused,binary_sha256=sha(gate)))
    gate_focused = audit(prefix+'-gate-controls',focused,ignored)
    state['profiles']['gate'] = dict(focused=gate_focused['counts'],affected=gate_affected['counts'],
                                    focused_status=gate_focused['status'],affected_status=gate_affected['status'],
                                    affected_evidence='source282-path-gate-broad-audit.json',retained_inputs=retain('gate',gate))
    build = run('release-build',['cargo','test','--locked','--all-features','--profile','release','--lib','--no-run','--message-format=json-render-diagnostics'])
    assert build['exit_code'] == 0
    artifacts = []
    raw = (p/(prefix+'-release-build.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:',raw,re.M)
    for line in raw.splitlines():
        if line.startswith('{'):
            message = json.loads(line)
            assert message.get('message',{}).get('level') not in ['warning','error']
            if message.get('reason')=='compiler-artifact' and message.get('profile',{}).get('test') and message.get('executable') and message['target']['name']=='emaxx':
                artifacts.append(Path(message['executable']))
    assert len(artifacts)==1
    binary = p/(prefix+'-release-libtest'); assert not binary.exists()
    shutil.copy2(artifacts[0],binary); assert sha(binary)==sha(artifacts[0])
    assert run('release-inventory',[str(binary),'--list','--format','terse'])['exit_code']==0
    inventory = [s[:-6] for s in (p/(prefix+'-release-inventory.log')).read_text().splitlines() if s.endswith(': test')]
    assert len(inventory)==len(set(inventory))==3031 and set(focused)|set(broad)<=set(inventory)
    run('release-controls',[str(binary),*focused,'--exact','--test-threads=1','--nocapture'],dict(selectors=focused,binary_sha256=sha(binary)))
    release_focused = audit(prefix+'-release-controls',focused,ignored)
    run('release-broad',[str(binary),*broad,'--exact','--nocapture','--test-threads=1'],dict(selected_inventory=broad,binary_sha256=sha(binary)))
    release_affected = audit(prefix+'-release-broad',broad,[])
    state['profiles']['release'] = dict(focused=release_focused['counts'],affected=release_affected['counts'],
                                       focused_status=release_focused['status'],affected_status=release_affected['status'],
                                       affected_evidence=prefix+'-release-broad-audit.json',retained_inputs=retain('release',binary))
    state['status'] = 'passed' if all(x[k]=='passed' for x in state['profiles'].values() for k in ['focused_status','affected_status']) else 'failed'
except Exception as error: state.update(status='failed or incomplete',error=repr(error))
finally:
    save_state(); save('result',state)
print(json.dumps(dict(status=state['status'],profiles={k:{n:v for n,v in row.items() if n!='retained_inputs'} for k,row in state['profiles'].items()})),flush=True)
sys.exit(0 if state['status']=='passed' else 1)
