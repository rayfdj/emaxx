from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import time

p = Path(__file__).parent.resolve()
c = p.parent / 'recovered-2026-09-30/reader-internal-characters/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
assert not (c.parent / 'emacs').exists()
state = json.loads((p / 'source282-selected-state.json').read_text())
assert state['status'] == 'running test-reader-characters-broad.py'
rows = {}
for line in subprocess.check_output(['ps', '-axo', 'pid=,ppid=,command='], text=True).splitlines():
    pid, parent, command = line.strip().split(None, 2)
    rows[int(pid)] = dict(parent=int(parent), command=command)
pid = 40493
assert rows[pid]['command'].endswith('-B target/runtime-goal/resume-2026-09-28/queue-source282-reader-validation.py')
descendants = {pid}
while True:
    extended = descendants | {child for child, row in rows.items() if row['parent'] in descendants}
    if extended == descendants: break
    descendants = extended
# Stop the supervisor first so no new validation stage can start.
os.kill(pid, signal.SIGTERM)
for child in descendants - {pid}:
    try: os.kill(child, signal.SIGTERM)
    except ProcessLookupError: pass
time.sleep(1)
remaining = []
for child in descendants:
    check = subprocess.run(['ps', '-p', str(child), '-o', 'stat=,command='], capture_output=True, text=True)
    if check.returncode == 0 and check.stdout.strip() and not check.stdout.lstrip().startswith('Z'):
        remaining.append(dict(pid=child, command=check.stdout.strip()))
record = dict(status='withdrawn for missing canonical GNU sibling path', source_unchanged=all(sha(c/n)==h for n,h in json.loads((p/'source282-manifest.json').read_text()).items()),
              missing_path=str(c.parent/'emacs'), stopped={str(n):rows[n] for n in descendants}, remaining=remaining,
              previous_state=state, focused_audit=json.loads((p/'source282-focused-audit.json').read_text()),
              log_hashes={name:sha(p/name) for name in ['source282-gate-controls.log','source282-gate-broad.log']},
              qualification='The original focused207 passes/10 setup failures/two ignores and interrupted affected run remain failures/incomplete. No runtime source, selector, assertion, timeout or expected answer changes. Release has not started. Repair the local GNU source path and use separately named rerun receipts.', goal_complete=False)
with (p/'source282-missing-gnu-path-withdrawal.json').open('x') as f: json.dump(record,f,indent=2)
assert not remaining and record['source_unchanged']
print(json.dumps(dict(status=record['status'], stopped=len(descendants), remaining=remaining)))
