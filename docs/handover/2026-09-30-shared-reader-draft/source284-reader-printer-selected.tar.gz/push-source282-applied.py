from pathlib import Path
import json
import subprocess

p=Path(__file__).parent.resolve();root=p.parents[2]
head=json.loads((p/'source282-applied-commit.json').read_text())['commit']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()=='runtime-char-tables'
assert subprocess.check_output(['git','remote','get-url','origin'],cwd=root,text=True).strip() in ['https://github.com/rayfdj/emaxx.git','git@github.com:rayfdj/emaxx.git']
command=['git','push','origin','HEAD:refs/heads/runtime-char-tables']
run=subprocess.run(command,cwd=root,capture_output=True,text=True)
record=dict(command=command,commit=head,exit_code=run.returncode,stdout=run.stdout,stderr=run.stderr,
            authorization='Standing user approval for this and later validated updates on runtime-char-tables at github.com/rayfdj/emaxx',goal_complete=False)
with (p/'source282-applied-push.json').open('x') as f:json.dump(record,f,indent=2)
run.check_returncode()
assert subprocess.check_output(['git','ls-remote','--heads','origin','refs/heads/runtime-char-tables'],cwd=root,text=True).split()[0]==head
print(json.dumps(record,indent=2))
