from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).parent.resolve();fixture=p/'reader-actual-codes-v2-83941.el'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
binaries={'gnu':p.parent/'rebuilt-2026-10-01/emacs/src/emacs','source281':p.parent/'recovered-2026-09-30/string-print-decoder/emaxx/target/printer-character-validation/release/emaxx'}
for label,binary in binaries.items():
    stem=p/('reader-actual-codes-v2-'+label)
    command=[str(binary),'-Q','--batch','--eval','(prin1 '+fixture.read_text()+')']
    inputs={str(f):sha(f) for f in [binary,binary.with_suffix('.pdmp'),fixture,Path(__file__)]}
    env=dict(LANG='C',LC_ALL='C',EMAXX_GC_VERIFY='1')
    with stem.with_suffix('.command.json').open('x') as f:json.dump(dict(command=command,inputs=inputs,environment_override=env,timeout_seconds=120),f,indent=2)
    start=time.monotonic()
    run=subprocess.run(command,cwd=p,env=dict(os.environ,**env),stdin=subprocess.DEVNULL,capture_output=True,timeout=120)
    for suffix,data in [('stdout',run.stdout),('stderr',run.stderr)]:
        with stem.with_suffix('.'+suffix).open('xb') as f:f.write(data)
    result=dict(exit_code=run.returncode,elapsed_seconds=time.monotonic()-start,stdout_sha256=hashlib.sha256(run.stdout).hexdigest(),stderr_sha256=hashlib.sha256(run.stderr).hexdigest(),inputs_unchanged=all(sha(Path(f))==h for f,h in inputs.items()))
    with stem.with_suffix('.result.json').open('x') as f:json.dump(result,f,indent=2)
    print(label,result,run.stdout[:160],run.stderr[:300],flush=True)
