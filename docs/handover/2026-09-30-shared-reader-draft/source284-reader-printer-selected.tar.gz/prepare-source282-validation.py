from pathlib import Path
import ast
import hashlib
import json

p = Path(__file__).parent.resolve()
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p / n).read_text())
c = p.parent / 'recovered-2026-09-30/reader-internal-characters/emaxx'
m = read('source282-manifest.json')
assert len(m) == 518 and all(sha(c / n) == h for n, h in m.items())
records = []

def prepare(old, new, replacements=()):
    source = (p / old).read_text()
    base_changes = [('string-print-decoder/emaxx', 'reader-internal-characters/emaxx'),
                    ('printer-character-validation', 'reader-character-validation')]
    changes = [(a, b) for a, b in base_changes if a in source] + list(replacements)
    used = []
    for before, after in changes:
        count = source.count(before)
        assert count, (old, before)
        source = source.replace(before, after)
        used.append(dict(before=before, after=after, count=count))
    ast.parse(source)
    with (p / new).open('x') as f:
        f.write(source)
    records.append(dict(source=old, source_sha256=sha(p / old), successor=new,
                        successor_sha256=sha(p / new), replacements=used))

prepare('build-source281-printer-ordinary.py', 'build-source282-reader-ordinary.py')
# The generated multi-form fixture has a separate, whole-file runner below.
prepare('compare-printer-character-fixtures.py', 'compare-source282-reader-fixtures.py', [
    ("root = Path(directory)", "root = Path(directory)\nassert 'printer-varied-v3-293638f0' not in names"),
    (", 'printer-varied-v3-293638f0'", ''),
    ("r['exit_code'] == 0 and r['stderr_hex'] == ''", "r['exit_code'] == 0 and r['stdout_sha256'] != hashlib.sha256(b'').hexdigest() and r['stderr_hex'] == ''"),
])
prepare('compare-source281-generated-loaded.py', 'compare-source282-generated-loaded.py', [
    ('source281', 'source282'),
    ('Empty-output --eval run is retained and explicitly invalidated.',
     'The earlier source281 empty-output --eval run remains retained and invalid; this runner requires complete file execution.'),
])
extra = "    'reader_consumes_internal_character_bytes_without_host_text_loss',\n    'native_printed_string_constants_keep_full_character_codes_and_sharing',\n"
for profile, old, new in [
    ('gate', 'run-printer-characters-focused.py', 'run-reader-characters-focused.py'),
    ('release', 'run-printer-characters-release.py', 'run-reader-characters-release.py'),
]:
    replacements = [('3030' if profile == 'gate' else '3029', '3032' if profile == 'gate' else '3031'),
                    ('217', '219'), ('extra_names = {\n', 'extra_names = {\n' + extra)]
    prepare(old, new, replacements)
for old, new in [('audit-printer-characters-focused.py', 'audit-reader-characters-focused.py'),
                 ('audit-printer-characters-release.py', 'audit-reader-characters-release.py')]:
    # These auditors have no target-directory reference.
    source = (p / old).read_text()
    changes = [('string-print-decoder/emaxx', 'reader-internal-characters/emaxx'), ('514', '518'), ('217', '219')]
    for before, after in changes:
        assert before in source
        source = source.replace(before, after)
    ast.parse(source)
    with (p / new).open('x') as f: f.write(source)
    records.append(dict(source=old, source_sha256=sha(p / old), successor=new, successor_sha256=sha(p / new), replacements=changes))
prepare('test-printer-characters-broad.py', 'test-reader-characters-broad.py', [
    ('1071', '1073'),
    ('plus the new full-range printer control and all three existing print-preprocess tests.',
     'plus the full-range printer control, all three existing print-preprocess tests, and two new internal-reader/native-constant controls.'),
])
names = list(read('source279-selected-audit.json')['ordinary_results'])
assert len(names) == 37
names += ['printer-full-range-streams', 'reader-internal-character-codes', 'native-printed-string-constants']
assert len(names) == len(set(names)) == 40
assert (c / 'tests/fixtures/native-printed-string-constants.el').read_bytes() == (p / 'printer-native-literals-83729.el').read_bytes()
assert (c / 'tests/fixtures/native-printed-string-constants.expected').read_bytes().rstrip(b'\n') == (p / 'printer-native-literals-gnu.stdout').read_bytes()
assert (c / 'tests/fixtures/reader-internal-character-codes.el').read_bytes() == (p / 'reader-actual-codes-v2-83941.el').read_bytes()
stages = [
    ['build-source282-reader-ordinary.py', '282'],
    ['compare-source282-reader-fixtures.py', 'source282', str(c), *names],
    ['compare-source282-generated-loaded.py'],
    ['run-reader-characters-focused.py', '282'],
    ['audit-reader-characters-focused.py', '282'],
    ['test-reader-characters-broad.py', '282', 'gate'],
    ['run-reader-characters-release.py', '282'],
    ['audit-reader-characters-release.py', '282'],
    ['test-reader-characters-broad.py', '282', 'release'],
]
with (p / 'source282-validation-preparation.json').open('x') as f:
    json.dump(dict(source_manifest='source282-manifest.json', helpers=records, stages=stages,
                   ordinary_comparisons=41, focused_selectors=219, affected_selectors=1073,
                   original_native_negative_and_gnu_answer='byte-identical',
                   qualification='Preparation only. No broader result inferred. Prior failures remain unchanged.', goal_complete=False), f, indent=2)
print(json.dumps(dict(helpers=len(records), stages=len(stages), ordinary_comparisons=41)))
