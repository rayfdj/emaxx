from pathlib import Path
import hashlib
import json

p=Path(__file__).parent.resolve();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
c=p.parent/'recovered-2026-09-30/reader-internal-characters/emaxx'
read=lambda n:json.loads((p/n).read_text())
m=read('source282-manifest.json');audit=read('source282-selected-audit.json')
assert len(m)==518 and all(sha(c/n)==h for n,h in m.items())
assert audit['status']=='passed' and audit['ordinary_comparisons']==41
assert all(sha(Path(n))==h for n,h in audit['evidence_files'].items())
for inputs in audit['retained_inputs'].values():
    for r in inputs:assert sha(Path(r['original']))==sha(Path(r['artifact']))==r['sha256']
for n,r in audit['ordinary_artifacts'].items():assert sha(Path(n))==sha(Path(r['immutable_copy']))==r['sha256']
assert all(r['focused']=={'ok':217,'FAILED':0,'ignored':2} and r['affected']=={'ok':1073,'FAILED':0,'ignored':0} for r in audit['profiles'].values())
record=dict(status='passed',source_inputs_verified=518,profiles=audit['profiles'],ordinary_comparisons=41,
            selected_audit_sha256=sha(p/'source282-selected-audit.json'),
            qualification='Rechecks frozen source and the closed selected evidence/retained artifacts before full validation. All original setup/helper/runtime failures remain recorded.',goal_complete=False)
with (p/'source282-full-selected-audit.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(record,indent=2))
