from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

p = Path(__file__).parent.resolve()
root = p.parents[2]
c = p.parent / 'recovered-2026-09-30/reader-internal-characters/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p / n).read_text())
m, baseline = read('source282-manifest.json'), read('source279-manifest.json')
unchanged = lambda: all(sha(c / n) == h for n, h in m.items())
applied_unchanged = lambda: all(sha(root / n) == h for n, h in baseline.items())
checks = read('source282-printer-checks-result.json')
assert len(checks['results']) == 8 and all(r['exit_code'] == 0 and r['source_unchanged'] for r in checks['results'])
preparation = read('source282-validation-preparation.json')
stages = preparation['stages']
assert len(stages) == 9
helpers = {str(p / s[0]): sha(p / s[0]) for s in stages}
for record in preparation['helpers']:
    assert sha(p / record['source']) == record['source_sha256']
    assert sha(p / record['successor']) == record['successor_sha256']
state = dict(status='starting ordinary and selected validation', source_manifest='source282-manifest.json',
             helpers=helpers, stages=stages, results=[], goal_complete=False)
def save_state():
    (p / 'source282-selected-state.json').write_text(json.dumps(state, indent=2) + '\n')
try:
    for stage in stages:
        assert unchanged() and applied_unchanged()
        assert all(sha(Path(n)) == h for n, h in helpers.items())
        command = [sys.executable, '-B', str(p / stage[0]), *stage[1:]]
        state.update(status='running ' + stage[0], current_command=command)
        save_state()
        started = time.monotonic()
        result = subprocess.run(command, cwd=c, stdin=subprocess.DEVNULL,
                                env=dict(os.environ, PYTHONUNBUFFERED='1', PYTHONDONTWRITEBYTECODE='1'))
        row = dict(command=command, exit_code=result.returncode, elapsed_seconds=time.monotonic()-started,
                   source_unchanged=unchanged(), published_source_unchanged=applied_unchanged())
        state['results'].append(row)
        assert row['source_unchanged'] and row['published_source_unchanged']
    state['status'] = 'selected processes finished; raw audit required'
except Exception as error:
    state.update(status='failed', error=repr(error))
finally:
    save_state()
    with (p / 'source282-selected-result.json').open('x') as out:
        json.dump(state, out, indent=2)
print(json.dumps(state), flush=True)
sys.exit(0 if len(state['results']) == len(stages) and all(r['exit_code'] == 0 for r in state['results']) else 1)
