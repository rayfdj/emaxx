from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

p=Path(__file__).parent.resolve();root=p.parents[2]
c=p.parent/'recovered-2026-09-30/reader-internal-characters/emaxx'
old=p.parent/'recovered-2026-09-30/string-allocation-recovery/emaxx'
g=p.parent/'rebuilt-2026-10-01/emacs'
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
prior=json.loads((p/'source279-manifest.json').read_text())
added={'src/lisp/primitives/print/output.rs','tests/fixtures/printer-full-range-streams.el','tests/fixtures/printer-full-range-streams.expected','tests/fixtures/reader-internal-character-codes.el','tests/fixtures/reader-internal-character-codes.expected','tests/fixtures/native-printed-string-constants.el','tests/fixtures/native-printed-string-constants.expected'}
changed=set(subprocess.check_output(['git','diff','--name-only'],cwd=c,text=True).splitlines())
assert len(changed)==11 and all((c/name).is_file() for name in added)
assert all(sha(root/name)==sha(old/name)==digest for name,digest in prior.items())
assert all(sha(c/name)==digest for name,digest in prior.items() if name not in changed)
def save(name,value):
    with (p/('source282-'+name+'.json')).open('x') as stream:json.dump(value,stream,indent=2)
def patch():
    result=subprocess.check_output(['git','diff','--binary'],cwd=c)
    for name in sorted(added):
        diff=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',name],cwd=c,capture_output=True)
        assert diff.returncode==1 and not diff.stderr
        result+=diff.stdout
    return result
with (p/'source282-unformatted.patch').open('xb') as stream:stream.write(patch())
command=['cargo','fmt','--all']
result=subprocess.run(command,cwd=c,capture_output=True,text=True)
save('format',dict(command=command,exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr))
result.check_returncode()
assert set(subprocess.check_output(['git','diff','--name-only'],cwd=c,text=True).splitlines())==changed
manifest={name:sha(c/name) for name in sorted(set(prior)|added)}
assert len(manifest)==518
save('manifest',manifest)
with (p/'source282-printer.patch').open('xb') as stream:stream.write(patch())
unchanged=lambda:all(sha(c/name)==digest for name,digest in manifest.items())
target=c/'target/reader-character-validation'
assert target.is_dir()
env=dict(CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='1',LANG='C',LC_ALL='C',RUST_MIN_STACK='134217728',RUST_TEST_THREADS='1',EMAXX_GC_VERIFY='1',EMAXX_GNU_SOURCE_DIRECTORY=str(g),EMAXX_DUMP_SOURCE_DIRECTORY=str(g),EMACS_TEST_DIRECTORY=str(g/'test'))
state=dict(status='starting',candidate=str(c),source_manifest='source282-manifest.json',results=[],goal_complete=False)
def run(stage,command):
    assert unchanged()
    state.update(status='running '+stage,current_command=command)
    (p/'source282-printer-checks-state.json').write_text(json.dumps(state,indent=2)+'\n')
    save(stage+'-command',dict(command=command,environment_override=env,working_directory=str(c),source_manifest='source282-manifest.json',helper_sha256=sha(Path(__file__))))
    start=time.monotonic()
    with (p/('source282-'+stage+'.log')).open('xb') as log:
        process=subprocess.run(command,cwd=c,env=dict(os.environ,**env),stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
    record=dict(stage=stage,exit_code=process.returncode,elapsed_seconds=time.monotonic()-start,source_unchanged=unchanged(),published_source_unchanged=all(sha(root/name)==digest for name,digest in prior.items()))
    save(stage+'-result',record);state['results'].append(record)
    assert record['source_unchanged'] and record['published_source_unchanged']
    assert process.returncode==0,stage
    assert not any(line.startswith('warning:') for line in (p/('source282-'+stage+'.log')).read_text().splitlines()),stage+' warnings'
try:
    for stage,command in [('fmt',['cargo','fmt','--all','--check']),('check',['cargo','check','--locked','--all-targets','--all-features']),('clippy',['cargo','clippy','--locked','--all-targets','--all-features','--','-D','warnings']),('diff',['git','diff','--check']),('fresh-gate',['cargo','clean','--package','emaxx','--profile','gate']),('gate-build',['cargo','test','--locked','--all-features','--profile','gate','--lib','--no-run','--message-format=json-render-diagnostics'])]:run(stage,command)
    binaries=[]
    for line in (p/'source282-gate-build.log').read_text().splitlines():
        if line.startswith('{'):
            row=json.loads(line)
            if row.get('reason')=='compiler-artifact' and row.get('profile',{}).get('test') and row.get('executable') and row['target']['name']=='emaxx':binaries.append(Path(row['executable']))
    assert len(binaries)==1
    binary=p/'source282-gate-libtest';assert not binary.exists();shutil.copy2(binaries[0],binary)
    save('binary',dict(original=str(binaries[0]),retained=str(binary),sha256=sha(binary)))
    run('gate-inventory',[str(binary),'--list','--format','terse'])
    names=[line[:-6] for line in (p/'source282-gate-inventory.log').read_text().splitlines() if line.endswith(': test')]
    assert len(names)==len(set(names))==3032
    selectors=['lisp::primitives::tests::'+name for name in ['printer_preserves_full_character_codes_in_strings_buffers_and_callbacks','reader_consumes_internal_character_bytes_without_host_text_loss','native_printed_string_constants_keep_full_character_codes_and_sharing']]
    assert set(selectors)<=set(names)
    run('reader-native-controls',[str(binary),'--test-threads=1','--nocapture','--exact',*selectors])
    state['status']='strict checks and three reader/printer/native controls finished; audit required'
except Exception as error:
    state.update(status='failed',error=repr(error))
finally:
    (p/'source282-printer-checks-state.json').write_text(json.dumps(state,indent=2)+'\n')
    save('printer-checks-result',state)
print(json.dumps(state),flush=True)
sys.exit(0 if state['status']=='strict checks and three reader/printer/native controls finished; audit required' else 1)
