from pathlib import Path
import ast
import gzip
import hashlib
import io
import json
import tarfile

p=Path(__file__).parent.resolve();root=p.parents[2]
out=p/'source282-publication-stage';out.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda n:json.loads((p/n).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
audit=read('source282-selected-audit.json');assert audit['status']=='passed' and audit['ordinary_comparisons']==41
assert all(r['focused']=={'ok':217,'FAILED':0,'ignored':2} and r['affected']=={'ok':1073,'FAILED':0,'ignored':0} for r in audit['profiles'].values())
applied=read('source282-applied-commit.json');assert applied['source_inputs']==518
allowed={'.json','.log','.txt','.py','.h','.el','.expected','.stdout','.stderr','.patch'}
files={}
for f in p.iterdir():
    if not f.is_file() or f.suffix not in allowed:continue
    if f.name.startswith(('source282-','reader-actual-codes')):
        if f.name.startswith('source282-full-') and f.name not in ['source282-full-checkout.json','source282-full-checkout-command.json','source282-full-launch.json','source282-full-validation-preparation.json']:continue
        files[f.name]=f
helpers=['run-source282-reader-checks.py','prepare-source282-validation.py','queue-source282-reader-validation.py',
         'build-source282-reader-ordinary.py','compare-source282-reader-fixtures.py','compare-source282-generated-loaded.py',
         'freeze-source282-reader.py','audit-source282-ordinary.py','audit-source282-selected.py',
         'withdraw-source282-missing-gnu-path.py','prepare-source282-path-rerun.py','queue-source282-path-validation.py',
         'run-source282-confirmed-selection.py','prepare-source282-full-validation.py','audit-source282-selected-for-full.py',
         'setup-source282-full-macos.py','queue-source282-full-macos.py','dispatch-source282-linux.py',
         'apply-source282-selected.py','push-source282-applied.py','probe-reader-actual-codes.py','probe-reader-actual-codes-v2.py',
         'package-source196-failure-and197-results.py',Path(__file__).name]
helpers += [f.name for f in p.glob('*reader-characters-*.py')]
for name in sorted(set(helpers)):
    assert (p/name).is_file(),name
    files[name]=p/name
c=p.parent/'recovered-2026-09-30/reader-internal-characters/emaxx'
for stem in ['printer-full-range-streams','reader-internal-character-codes','native-printed-string-constants']:
    for suffix in ['.el','.expected']:files['fixtures/'+stem+suffix]=c/'tests/fixtures'/(stem+suffix)
scope=dict(status='selected checkpoint applied; full validation pending',applied=applied,selected=audit,
           source_freeze=read('source282-freeze-source-audit.json'),ordinary=read('source282-ordinary-audit.json'),
           dependencies=['source281-canonical-printer-unfinished','source279-string-allocation-selected','source279-varied-output-and-eglot-retry'],
           qualification='518 input bytes/modes replay from d64040a7 and main21d20f0e. Strict checks are warning-free;217 focused passes/two existing ignores and1073 affected passes in each profile;41 ordinary outputs match actual GNU, including all198 generated rows/4088269 bytes and the unchanged native negative. Initial207-pass/10-missing-source-path-failure/two-ignore run and interrupted affected run stay failed/incomplete. The first corrected-path helper has log-name errors; its independently completed1073-test gate run is verified and reused. A separate runner completes both focused profiles and affected release with all names/results audited. Full Linux/macOS launch receipts are starts only; live full-run logs are excluded from this selected archive. Symbol/positioning/legacy formatting adapters, ownership/accounting, intervals/pure storage, VM work and locked performance remain open.',goal_complete=False)
package('source282-reader-printer-selected',files,scope)
print(json.dumps(dict(files=len(files),archive='source282-reader-printer-selected.tar.gz')))
