from pathlib import Path
import ast
import hashlib
import json

p = Path(__file__).parent.resolve()
c = p.parent / 'recovered-2026-09-30/reader-internal-characters/emaxx'
g = p.parent / 'rebuilt-2026-10-01/emacs'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p/n).read_text())
withdrawal = read('source282-missing-gnu-path-withdrawal.json')
assert not withdrawal['remaining'] and withdrawal['source_unchanged']
assert len(withdrawal['previous_state']['results']) == 5
assert not (c.parent/'emacs').exists()
assert sha(g/'src/emacs') == '29cfb20de2474c040d439d4bdf69b4dfcfb7921464f1f686b6e1f6bcca7c74e5'
(c.parent/'emacs').symlink_to(g, target_is_directory=True)
assert (c.parent/'emacs').resolve() == g.resolve()
assert (c.parent/'emacs/lisp/emacs-lisp/debug-early.el').is_file()
records = []
def prepare(old, new, changes):
    source = (p/old).read_text()
    used = []
    for before, after in changes:
        count = source.count(before)
        assert count, (old,before)
        source = source.replace(before,after)
        used.append(dict(before=before,after=after,count=count))
    ast.parse(source)
    with (p/new).open('x') as f: f.write(source)
    records.append(dict(source=old,source_sha256=sha(p/old),successor=new,successor_sha256=sha(p/new),replacements=used))
shared = [("prefix = 'source' + sys.argv[1]", "prefix = 'source282-path'"),
          ("(prefix + '-manifest.json')", "('source282-manifest.json')")]
strict = [("(prefix + '-' + stage + '-result.json')", "('source282-' + stage + '-result.json')"),
          ("(prefix + '-' + stage + '.log')", "('source282-' + stage + '.log')")]
prepare('run-reader-characters-focused.py','run-reader-characters-path-focused.py',shared+strict+[
    ("(prefix + '-gate-libtest')", "('source282-gate-libtest')"),
    ("(prefix + '-binary.json')", "('source282-binary.json')"),
    ("(prefix + '-printer-checks-result.json')", "('source282-printer-checks-result.json')"),
    ("(prefix + '-gate-inventory.log')", "('source282-gate-inventory.log')"),
])
prepare('run-reader-characters-release.py','run-reader-characters-path-release.py',shared+strict)
prepare('audit-reader-characters-focused.py','audit-reader-characters-path-focused.py',shared+strict)
prepare('audit-reader-characters-release.py','audit-reader-characters-path-release.py',shared+[
    ("    stage_result = read(prefix + '-' + stage + '-result.json')", "    stage_prefix = prefix if stage == 'release-build' else 'source282'\n    stage_result = read(stage_prefix + '-' + stage + '-result.json')"),
    ("(prefix + '-' + stage + '.log')", "(stage_prefix + '-' + stage + '.log')"),
])
prepare('test-reader-characters-broad.py','test-reader-characters-path-broad.py',[
    ("tag='source'+sys.argv[1]", "tag='source282-path'"),
    ("(tag+'-manifest.json')", "('source282-manifest.json')"),
    ("binary=p/(tag+'-'+profile+'-libtest')", "artifact_tag='source282' if profile=='gate' else tag\nbinary=p/(artifact_tag+'-'+profile+'-libtest')"),
    ("(tag+'-'+profile+'-inventory.log')", "(artifact_tag+'-'+profile+'-inventory.log')"),
])
stages = [['run-reader-characters-path-focused.py','282'],
          ['audit-reader-characters-path-focused.py','282'],
          ['test-reader-characters-path-broad.py','282','gate'],
          ['run-reader-characters-path-release.py','282'],
          ['audit-reader-characters-path-release.py','282'],
          ['test-reader-characters-path-broad.py','282','release']]
record = dict(status='canonical GNU sibling source link repaired; rerun not started',
              source_manifest='source282-manifest.json',gnu_link=str(c.parent/'emacs'),gnu_target=str(g),
              helpers=records,stages=stages,original_failure='source282-missing-gnu-path-withdrawal.json',
              qualification='Same frozen source and gate binary. Reuses strict and ordinary evidence without relabeling it. Fresh isolated test-image directory; all219/1073 selectors and both profiles retained.',goal_complete=False)
with (p/'source282-path-preparation.json').open('x') as f: json.dump(record,f,indent=2)
print(json.dumps(dict(status=record['status'],helpers=len(records))))
