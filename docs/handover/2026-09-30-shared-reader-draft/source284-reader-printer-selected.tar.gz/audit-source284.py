from pathlib import Path
import hashlib, io, json, os, re, subprocess, tarfile, tempfile

p=Path(__file__).parent.resolve();root=p.parents[2];c=p.parent/'recovered-2026-10-03/reader-bounds-ascii/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();read=lambda n:json.loads((p/n).read_text())
m=read('source284-manifest.json');prior=read('source279-manifest.json');assert len(m)==520 and all(sha(c/n)==h for n,h in m.items())
previous=read('source282-manifest.json')
assert all(m[n]==h for n,h in previous.items() if n.startswith('tests/'))
test_source,count=re.subn(r'#\[test\]\nfn read_from_string_preserves_gnu_range_error_arguments_and_order\(\) \{\n.*?\n\}\n\n','',(c/'src/lisp/primitives/tests.rs').read_text(),flags=re.S)
assert count==1 and test_source==(p.parent/'recovered-2026-09-30/reader-internal-characters/emaxx/src/lisp/primitives/tests.rs').read_text()
state=read('source284-validation-result.json')
assert state['status']=='strict, targeted and ordinary processes passed; raw audit required'
assert len(state['results'])==15 and all(r['exit_code']==0 and r['source_unchanged'] for r in state['results'])
evidence={};profiles={}
for profile in ['gate','release']:
    names=state['profiles'][profile]['selectors'];assert len(names)==6
    stem='source284-'+profile+'-controls';command=read(stem+'-command.json');result=read(stem+'-result.json')
    binary=Path(command['command'][0]);assert sha(binary)==command['binary_sha256']
    raw=(p/(stem+'.log')).read_text();assert re.findall(r'^test (\S+) \.\.\. ok$',raw,re.M)==names
    assert 'test result: ok. 6 passed; 0 failed; 0 ignored;' in raw
    assert result['exit_code']==0 and result['source_unchanged']
    for r in state['profiles'][profile]['retained_inputs']:assert sha(Path(r['original']))==sha(Path(r['artifact']))==r['sha256']
    profiles[profile]=dict(passed=6,failed=0,ignored=0,selectors=names,retained_inputs=state['profiles'][profile]['retained_inputs'])
    for suffix in ['.log','-command.json','-result.json']:evidence[str(p/(stem+suffix))]=sha(p/(stem+suffix))
ordinary={};names=list(read('source282-ordinary-audit.json')['ordinary_results'])+['read-from-string-range-errors'];assert len(names)==41
for name in names:
    comparison=read('source284-ordinary-'+name+'-comparison.json');assert comparison['passed'] and comparison['exact_match']
    outputs=[];programs=[]
    for editor in ['gnu','emaxx']:
        stem='source284-ordinary-'+name+'-'+editor;command,result=read(stem+'.command.json'),read(stem+'.result.json')
        assert all(sha(Path(n))==h for n,h in command['inputs'].items())
        assert result==comparison['outcomes'][editor] and result['exit_code']==0 and not result['timed_out'] and result['inputs_unchanged'] and result['source_unchanged']
        out,err=(p/(stem+'.stdout')).read_bytes(),(p/(stem+'.stderr')).read_bytes()
        assert out and not err and hashlib.sha256(out).hexdigest()==result['stdout_sha256'] and err.hex()==result['stderr_hex']
        assert result['expected_output'] is not False
        if name!='read-from-string-range-errors':assert out==(p/('source282-ordinary-'+name+'-'+editor+'.stdout')).read_bytes()
        else:assert out==(p/'source284-bounds-gnu.stdout').read_bytes()
        outputs.append(out);programs.append(command['command'][-1])
    assert outputs[0]==outputs[1] and programs[0]==programs[1]
    ordinary[name]=dict(passed=True,stdout_sha256=hashlib.sha256(outputs[0]).hexdigest(),stdout_bytes=len(outputs[0]))
assert read('source284-generated-loaded-comparison.json')['passed']
for editor in ['gnu','emaxx']:
    stem='source284-generated-loaded-'+editor;command,result=read(stem+'-command.json'),read(stem+'-result.json')
    assert all(sha(Path(n))==h for n,h in command['inputs'].items())
    assert result['exit_code']==0 and not result['timed_out'] and result['source_unchanged'] and result['inputs_unchanged']
    assert command['command'][-2:]==['-l',str(p/'printer-varied-v3-293638f0.el')]
    out=(p/(stem+'.stdout')).read_bytes();assert len(out)==4088269 and len(out.splitlines())==198
    assert out==(p/'printer-varied-v3-gnu.stdout').read_bytes() and not (p/(stem+'.stderr')).read_bytes()
artifacts=read('source284-ordinary-artifacts.json')
assert all(sha(Path(n))==sha(Path(r['immutable_copy']))==r['sha256'] for n,r in artifacts.items())
assert not read('source282-bounds-matrix.json')['matches_gnu']
patches=[];new=set(m)-set(prior);assert len(new)==9
for label,commit in [('incremental','d64040a7efe9a5039750b7c0b8feb7796c57fe79'),('complete','21d20f0eec08f3c013d5d3eb3bd6e9cfc16b3199')]:
    data=subprocess.check_output(['git','diff','--binary',commit,'--',*sorted(m)],cwd=c)
    for n in sorted(new):
        r=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',n],cwd=c,capture_output=True);assert r.returncode==1 and not r.stderr;data+=r.stdout
    name='source284-portable-'+label+'.patch'
    with (p/name).open('xb') as f:f.write(data)
    if label=='incremental':assert data==(p/'source284-reader.patch').read_bytes()
    tracked=set(subprocess.check_output(['git','ls-tree','-r','--name-only',commit],cwd=root,text=True).splitlines())
    archive=subprocess.check_output(['git','archive',commit,'--',*sorted(tracked&m.keys())],cwd=root)
    with tempfile.TemporaryDirectory(prefix='emaxx-reader-range-replay-',dir='/private/tmp') as temp:
        target=Path(temp)
        with tarfile.open(fileobj=io.BytesIO(archive)) as source:
            for item in source:
                assert not Path(item.name).is_absolute() and '..' not in Path(item.name).parts
                dest=target/item.name
                if item.isdir():dest.mkdir(parents=True,exist_ok=True)
                else:
                    assert item.isfile();dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(source.extractfile(item).read());os.chmod(dest,0o755 if item.mode&0o111 else 0o644)
        subprocess.run(['git','apply','--check',str(p/name)],cwd=target,check=True);subprocess.run(['git','apply',str(p/name)],cwd=target,check=True)
        assert all(sha(target/n)==h for n,h in m.items())
        assert all((target/n).stat().st_mode&0o777==(c/n).stat().st_mode&0o777 for n in m)
    patches.append(dict(patch=name,sha256=sha(p/name),base=commit,verified_inputs=520,bytes_and_modes='exact'))
for stage in ['fmt','check','clippy','diff','gate-build','release-build','ordinary-build']:
    result=read('source284-'+stage+'-result.json');assert result['exit_code']==0 and result['source_unchanged']
    raw=(p/('source284-'+stage+'.log')).read_text();assert not re.search(r'^warning(?:\[.*\])?:',raw,re.M)
    for line in raw.splitlines():
        if line.startswith('{'):assert json.loads(line).get('message',{}).get('level') not in ['warning','error']
    evidence[str(p/('source284-'+stage+'.log'))]=sha(p/('source284-'+stage+'.log'))
assert read('source284-bounds-gnu.json')['matches_original_test_helper_gnu']
record=dict(predecessor_fixture_failure='Source283: five controls pass, new matrix fails in GNU reference assertion due to literal Unicode argv decoded under a different locale; Emaxx matrix is not reached. Source284 constructs the same characters by numeric codes and exactly matches that helper GNU output. Production bytes are unchanged from283.',status='passed',source_inputs_verified=520,profiles=profiles,ordinary_comparisons=42,ordinary_results=ordinary,
            generated_rows=198,generated_bytes=4088269,bounds_rows=679,ordinary_artifacts=artifacts,portable_replays=patches,evidence_files=evidence,
            predecessor=read('source282-selected-audit.json')['profiles'],predecessor_manifest='source282-manifest.json',
            qualification='Source284 passes zero-warning strict checks, six targeted contracts per profile and42 ordinary exact GNU comparisons. The679-case matrix now matches unchanged GNU; source282 negative remains. Source282217/1073 selected passes per profile are predecessor evidence, not final-source full certification. Source284 changes only reader validation to reuse the unchanged GNU-compatible subarray validator, its visibility, and a new test/fixture. All prior fixtures/tests remain. Full Linux/macOS validation, architecture/de-cheating completion and locked performance remain open. User directs performance measurement next without further unrelated correctness expansion.',goal_complete=False)
with (p/'source284-selected-audit.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(dict(status=record['status'],profiles={k:r['passed'] for k,r in profiles.items()},ordinary_comparisons=42,bounds_rows=679),indent=2))
