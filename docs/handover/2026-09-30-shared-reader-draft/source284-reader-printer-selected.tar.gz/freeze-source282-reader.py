from pathlib import Path
import hashlib
import io
import json
import os
import re
import subprocess
import tarfile
import tempfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
c = p.parent / 'recovered-2026-09-30/reader-internal-characters/emaxx'
g = p.parent / 'rebuilt-2026-10-01/emacs'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p / n).read_text())
current, prior, predecessor = [read('source' + str(n) + '-manifest.json') for n in [282, 279, 281]]
assert len(current) == 518 and len(prior) == 511 and len(predecessor) == 514
assert all(sha(c / n) == h for n, h in current.items())
assert all(sha(root / n) == h for n, h in prior.items())
new = set(current) - set(prior)
assert new == {'src/lisp/primitives/print/output.rs',
               'tests/fixtures/printer-full-range-streams.el', 'tests/fixtures/printer-full-range-streams.expected',
               'tests/fixtures/reader-internal-character-codes.el', 'tests/fixtures/reader-internal-character-codes.expected',
               'tests/fixtures/native-printed-string-constants.el', 'tests/fixtures/native-printed-string-constants.expected'}
assert all(current[n] == h for n, h in predecessor.items() if n.startswith('tests/'))
new_test_names = ['reader_consumes_internal_character_bytes_without_host_text_loss',
                  'native_printed_string_constants_keep_full_character_codes_and_sharing',
                  'printer_preserves_full_character_codes_in_strings_buffers_and_callbacks']
test_source = (c / 'src/lisp/primitives/tests.rs').read_text()
for name in new_test_names:
    pattern = r'#\[test\]\nfn ' + name + r'\(\) \{\n.*?\n\}\n\n'
    test_source, count = re.subn(pattern, '', test_source, flags=re.S)
    assert count == 1
assert test_source == (root / 'src/lisp/primitives/tests.rs').read_text()
inventory = lambda tag: {s[:-6] for s in (p / (tag + '-gate-inventory.log')).read_text().splitlines() if s.endswith(': test')}
assert inventory('source282') - inventory('source279') == {'lisp::primitives::tests::' + n for n in new_test_names}
assert inventory('source279') < inventory('source282') and len(inventory('source282')) == 3032
for stage in ['fmt', 'check', 'clippy', 'diff', 'gate-build', 'reader-native-controls']:
    result = read('source282-' + stage + '-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
    raw = (p / ('source282-' + stage + '.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
    for line in raw.splitlines():
        if line.startswith('{'):
            assert json.loads(line).get('message', {}).get('level') not in ['warning', 'error']
control = (p / 'source282-reader-native-controls.log').read_text()
observed = re.findall(r'^test (\S+) \.\.\. ok$', control, re.M)
assert set(observed) == {'lisp::primitives::tests::' + n for n in new_test_names}
assert 'test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 3029 filtered out;' in control
binary = read('source282-binary.json')
assert sha(Path(binary['retained'])) == binary['sha256']
base = 'd64040a7efe9a5039750b7c0b8feb7796c57fe79'
main = '21d20f0eec08f3c013d5d3eb3bd6e9cfc16b3199'
patches = []
for label, commit in [('incremental', base), ('complete', main)]:
    data = subprocess.check_output(['git', 'diff', '--binary', commit, '--', *sorted(current)], cwd=c)
    for name in sorted(new):
        added = subprocess.run(['git', 'diff', '--no-index', '--binary', '--', '/dev/null', name], cwd=c, capture_output=True)
        assert added.returncode == 1 and not added.stderr
        data += added.stdout
    name = 'source282-portable-' + label + '.patch'
    with (p / name).open('xb') as stream: stream.write(data)
    if label == 'incremental': assert data == (p / 'source282-printer.patch').read_bytes()
    tracked = set(subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', commit], cwd=root, text=True).splitlines())
    archive = subprocess.check_output(['git', 'archive', commit, '--', *sorted(tracked & current.keys())], cwd=root)
    with tempfile.TemporaryDirectory(prefix='emaxx-reader-replay-', dir='/private/tmp') as temp:
        target = Path(temp)
        with tarfile.open(fileobj=io.BytesIO(archive)) as source:
            for item in source:
                assert not Path(item.name).is_absolute() and '..' not in Path(item.name).parts
                dest = target / item.name
                if item.isdir(): dest.mkdir(parents=True, exist_ok=True)
                else:
                    assert item.isfile()
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    dest.write_bytes(source.extractfile(item).read())
                    os.chmod(dest, 0o755 if item.mode & 0o111 else 0o644)
        subprocess.run(['git', 'apply', '--check', str(p / name)], cwd=target, check=True)
        subprocess.run(['git', 'apply', str(p / name)], cwd=target, check=True)
        assert all(sha(target / n) == h for n, h in current.items())
        assert all((target / n).stat().st_mode & 0o777 == (c / n).stat().st_mode & 0o777 for n in current)
    patches.append(dict(patch=name, sha256=sha(p / name), base=commit, inputs=len(current), bytes_and_modes='exact'))
record = dict(status='portable source, strict checks and three bounded controls verified', source_inputs=518,
              original_tests_and_fixtures='all source279 test bodies and source281 fixtures unchanged; three new tests relative to279',
              gate_inventory=3032, controls=observed, binary=binary, portable_replays=patches,
              gnu_mechanisms=dict(inputs={n: sha(g / n) for n in ['src/print.c', 'src/character.h', 'src/character.c', 'src/comp.c', 'src/alloc.c', 'src/lread.c']},
                                  references=['comp.c:load_static_obj calls Fread(make_string(blob->data, blob->len))',
                                              'alloc.c:make_string and character.c:parse_str_as_multibyte classify the entire C byte sequence',
                                              'lread.c:read_string_literal and read_char_literal consume actual Emacs character codes',
                                              'print.c:print_object fetches actual character codes before choosing escapes']),
              changes=['Reader borrows actual Lisp string bytes and consumes internal character widths; removes whole-source host-text and Vec<char> copies from read-from-string.',
                       'Native loading allocates the real temporary Lisp string and uses the same reader; removes the fictional allocation charge and lossy UTF-8 decoding.',
                       'Preceding printer migration carries canonical bytes through actual string/buffer/callback/native destinations.'],
              limits=['No broader, platform or performance result is inferred from these three controls.',
                      'Symbol tokens still use host strings, and positioning/buffer reader adapters remain; full-range symbol names are not certified.',
                      'Legacy formatting, echo/message capture, unreadable-object names and callback mutation timing remain open.',
                      'Source280 compilation failure and source281 native wrong output/partial socket failures remain preserved.',
                      'Full architecture, ownership, GC accounting, adversarial review and locked performance criteria remain required.'], goal_complete=False)
with (p / 'source282-freeze-source-audit.json').open('x') as f: json.dump(record, f, indent=2)
print(json.dumps({k: record[k] for k in ['status', 'source_inputs', 'gate_inventory', 'portable_replays']}, indent=2))
