from pathlib import Path
import hashlib
import json
import subprocess

p=Path(__file__).parent.resolve();root=p.parents[2]
c=p.parent/'recovered-2026-10-03/reader-bounds-ascii/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
read=lambda n:json.loads((p/n).read_text())
m,base=read('source284-manifest.json'),read('source279-manifest.json')
audit=read('source284-selected-audit.json')
assert audit['status']=='passed' and audit['ordinary_comparisons']==42
assert all(r['passed']==6 and r['failed']==0 and r['ignored']==0 for r in audit['profiles'].values())
assert len(m)==520 and all(sha(c/n)==h for n,h in m.items())
assert len(base)==511 and all(sha(root/n)==h for n,h in base.items())
assert all(sha(Path(n))==h for n,h in audit['evidence_files'].items())
assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()=='runtime-char-tables'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head=='54be5a1ef21913c259a35e2ad2e909ccac0908c9'
patch=p/'source284-portable-incremental.patch'
assert sha(patch)==next(r['sha256'] for r in audit['portable_replays'] if r['patch']==patch.name)
for i,command in enumerate([['git','apply','--check',str(patch)],['git','apply',str(patch)],['git','diff','--check']]):
    run=subprocess.run(command,cwd=root,capture_output=True,text=True)
    with (p/('source284-apply-stage-'+str(i)+'.json')).open('x') as f:json.dump(dict(command=command,exit_code=run.returncode,stdout=run.stdout,stderr=run.stderr),f,indent=2)
    run.check_returncode()
assert all(sha(root/n)==h for n,h in m.items())
assert all((root/n).stat().st_mode&0o777==(c/n).stat().st_mode&0o777 for n in m)
expected={n for n,h in m.items() if base.get(n)!=h};assert len(expected)==21
subprocess.run(['git','add','--',*sorted(m)],cwd=root,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root,text=True).splitlines())==expected
command=['git','-c','user.name=Ray','-c','user.email=26018378+rayfdj@users.noreply.github.com','commit','-m','Preserve full Emacs character codes through reading and printing']
run=subprocess.run(command,cwd=root,capture_output=True,text=True)
with (p/'source284-apply-commit-command.json').open('x') as f:json.dump(dict(command=command,exit_code=run.returncode,stdout=run.stdout,stderr=run.stderr),f,indent=2)
run.check_returncode()
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
record=dict(commit=commit,parent=head,source_inputs=520,source_manifest='source284-manifest.json',candidate=str(c),selected_audit_sha256=sha(p/'source284-selected-audit.json'),
            qualification='Validated checkpoint: six targeted contracts per profile and42 ordinary exact GNU comparisons, including679 bounds cases. Source282217/1073 selected passes are predecessor evidence; all prior fixtures/tests remain. Existing setup/helper failures remain recorded. Actual native constant failure repaired. Full-platform validation and the broader architecture/performance goal remain incomplete.',goal_complete=False)
with (p/'source284-applied-commit.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(record,indent=2))
