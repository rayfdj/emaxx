from pathlib import Path
import hashlib
import json
import re

p=Path(__file__).parent.resolve();c=p.parent/'recovered-2026-09-30/reader-internal-characters/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
read=lambda n:json.loads((p/n).read_text())
m=read('source282-manifest.json');assert len(m)==518 and all(sha(c/n)==h for n,h in m.items())
freeze=read('source282-freeze-source-audit.json')
for row in freeze['portable_replays']:assert sha(p/row['patch'])==row['sha256']
ordinary=read('source282-ordinary-audit.json');assert ordinary['status']=='passed' and ordinary['ordinary_comparisons']==41
selection=read('source282-rerun-result.json');assert selection['status']=='passed' and set(selection['profiles'])=={'gate','release'}
assert len(selection['results'])==5 and all(r['exit_code']==0 and r['source_unchanged'] and r['published_source_unchanged'] for r in selection['results'])
profiles={};files={}
for profile in ['gate','release']:
    row=selection['profiles'][profile]
    assert row['focused']=={'ok':217,'FAILED':0,'ignored':2} and row['affected']=={'ok':1073,'FAILED':0,'ignored':0}
    focused_name='source282-rerun-'+profile+'-controls-audit.json'
    affected_name=row['affected_evidence']
    for name in [focused_name,affected_name]:
        result=read(name);assert result['status']=='passed'
        command=read(result['command_file']);binary=Path(command['command'][0])
        assert sha(binary)==result['binary_sha256']==command['binary_sha256']
        log=p/result['command_file'].replace('-command.json','.log')
        assert sha(log)==result['log_sha256'];files[str(log)]=sha(log)
        files[str(p/name)]=sha(p/name)
    for item in row['retained_inputs']:
        assert sha(Path(item['original']))==sha(Path(item['artifact']))==item['sha256']
    profiles[profile]={k:row[k] for k in ['focused','affected','focused_status','affected_status']}
original=read('source282-focused-audit.json')
assert original['counts']=={'ok':207,'FAILED':10,'ignored':2}
withdrawal=read('source282-missing-gnu-path-withdrawal.json');assert not withdrawal['remaining']
raw=(p/'source282-gate-broad.log').read_text()
names=read('source282-gate-broad-command.json')['selected_inventory']
starts=list(re.finditer(r'^test (\S+) \.\.\. ',raw,re.M))
assert [m[1] for m in starts]==names[:len(starts)]
partial={};interrupted=[]
for i,match in enumerate(starts):
    end=starts[i+1].start() if i+1<len(starts) else len(raw)
    verdict=re.findall(r'(?:^|\s)(ok|FAILED|ignored)(?:,[^\n]*)?\s*\Z',raw[match.end():end])
    if verdict:partial[match[1]]=verdict[0]
    else:interrupted.append(match[1])
assert len(interrupted)<=1
partial_record=dict(counts={v:list(partial.values()).count(v) for v in ['ok','FAILED','ignored']},raw_verdicts=partial,
                    interrupted=interrupted,unstarted=names[len(starts):],log_sha256=sha(p/'source282-gate-broad.log'))
failed_helpers=read('source282-path-selected-result.json')
assert [r['exit_code'] for r in failed_helpers['results']]==[1,1,0,1,1,1]
for name,h in failed_helpers['helpers'].items():assert sha(Path(name))==h
for stem in ['source282-freeze-source-audit.json','source282-ordinary-audit.json','source282-rerun-result.json',
             'source282-focused-audit.json','source282-missing-gnu-path-withdrawal.json','source282-path-selected-result.json']:
    files[str(p/stem)]=sha(p/stem)
record=dict(status='passed',source_inputs_verified=518,profiles=profiles,ordinary_comparisons=41,
            ordinary_results=ordinary['ordinary_results'],generated_rows=198,generated_bytes=4088269,
            ordinary_artifacts=ordinary['ordinary_artifacts'],retained_inputs={k:r['retained_inputs'] for k,r in selection['profiles'].items()},
            evidence_files=files,original_focused_failure=original['counts'],original_partial_affected=partial_record,
            corrected_path_helper_failures='focused log collision prevented execution; release compiled successfully but helper read the wrong log filename, so its release tests did not start',
            corrected_path_affected='all1073 gate names pass and are audited independently; reused without rerunning unchanged successful checks',
            qualification='Frozen source282 passes zero-warning strict checks,217 focused passes/two existing ignores and1073 affected passes in both profiles, plus41 ordinary exact GNU comparisons. Every earlier assertion, fixture, expected answer and selector remains. Initial missing-GNU-path failures, partial run and helper errors stay separately recorded. Native wrong-output negative now matches unchanged GNU. Full platform/native artifact identity, extended-symbol/positioned-reader migration, public ownership, accounting, architecture and locked performance criteria remain open.',goal_complete=False)
with (p/'source282-selected-audit.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps({k:record[k] for k in ['status','profiles','ordinary_comparisons','original_focused_failure']},indent=2))
