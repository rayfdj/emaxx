from pathlib import Path
import ast
import hashlib
import json

p=Path(__file__).parent.resolve();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
records=[]
def write(old,new,source):
    ast.parse(source)
    with (p/new).open('x') as f:f.write(source)
    records.append(dict(source=old,source_sha256=sha(p/old),successor=new,successor_sha256=sha(p/new)))
common=[('source279','source282'),('string-allocation-recovery/emaxx','reader-internal-characters/emaxx'),
        ('string-allocation-full/emaxx','reader-characters-full/emaxx'),('string-sblock-validation','reader-character-validation'),
        ('511','518')]
old='setup-source279-full-macos.py';source=(p/old).read_text()
for a,b in common:source=source.replace(a,b)
write(old,'setup-source282-full-macos.py',source)
old='queue-source279-full-macos.py';source=(p/old).read_text()
for a,b in common:source=source.replace(a,b)
obsolete="launch = json.loads((p / 'source282-selected-launch.json').read_text())\nprior_pid = str(launch['pid'])\n"
assert source.count(obsolete)==1;source=source.replace(obsolete,'')
source=source.replace("status='waiting for source282 selected validation', prior_pid=int(prior_pid),", "status='starting full source282 validation',")
start=source.index('    while True:\n')
end=source.index("    assert run('selected-audit'",start)
source=source[:start]+"    assert json.loads((p / 'source282-selected-audit.json').read_text())['status'] == 'passed'\n"+source[end:]
source=source.replace("selected['ordinary_comparisons'] == 37","selected['ordinary_comparisons'] == 41")
source=source.replace("{'ok': 211, 'FAILED': 0, 'ignored': 2}","{'ok': 217, 'FAILED': 0, 'ignored': 2}")
source=source.replace("{'ok': 1067, 'FAILED': 0, 'ignored': 0}","{'ok': 1073, 'FAILED': 0, 'ignored': 0}")
assert 'prior_pid' not in source and 'source279' not in source
write(old,'queue-source282-full-macos.py',source)
old='dispatch-source279-linux.py';source=(p/old).read_text().replace('source279','source282')
source=source.replace('pooled-string/error-recovery checkpoint','canonical printer/reader checkpoint')
source=source.replace('audited511 inputs','audited518 inputs').replace('211 focused','217 focused').replace('1067 affected','1073 affected').replace('plus37 ordinary','plus41 ordinary')
source=source.replace('Preserves source278 three-abort negative and unexplained source276 broad Emaxx census failure.',
                      'Repairs the actual native constant wrong-output negative; retains original missing-path/helper failures and all earlier negatives, including the unresolved source276 census failure.')
write(old,'dispatch-source282-linux.py',source)
with (p/'source282-full-validation-preparation.json').open('x') as f:json.dump(dict(helpers=records,qualification='Preparation only. Full runs require the applied exact518-input checkpoint and closed selected audit; no current full-platform pass is inferred.',goal_complete=False),f,indent=2)
print(json.dumps(dict(prepared=len(records))))
