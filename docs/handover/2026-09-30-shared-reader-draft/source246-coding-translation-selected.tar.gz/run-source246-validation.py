from pathlib import Path
import json, subprocess, sys, time
p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/coding-translation/emaxx'
stages = [
    ['check-source246.py', '246'], ['static-source246.py', '246'],
    ['test-source246-controls.py', '246', 'gate'], ['build-source246.py', '246'],
    ['compare-source230-fixtures.py', 'source246', str(root),
     'coding-candidate-translation', 'coding-candidate-character-identities', 'coding-candidate-inventory', 'file-write-coding-selection', 'new-file-coding-lifecycle', 'file-write-order',
     'canonical-coding-character-storage', 'canonical-coding-identity-storage',
     'canonical-coding-conversion-storage', 'copied-canonical-string-storage', 'coding-error-object-storage'],
    ['probe-source246-compiler-load.py'],
    ['test-source246-broad.py', '246', 'gate'],
]
results = []
for name, *args in stages:
    command = [sys.executable, str(p / name), *args]
    start = time.monotonic()
    result = subprocess.run(command, stdin=subprocess.DEVNULL)
    results.append(dict(command=command, exit_code=result.returncode, elapsed_seconds=time.monotonic()-start))
    if result.returncode:
        break
with (p / 'source246-validation-result.json').open('x') as f:
    json.dump(results, f, indent=2)
raise SystemExit(results[-1]['exit_code'])
