evidence_status=0
if [ -f target/frozen-ci/oracle-inputs/manifest.json ]; then
  python3 tools/retain_oracle_artifacts.py verify \
    --output target/frozen-ci/oracle-inputs || evidence_status=$?
fi
if [ -f target/frozen-ci/rust/summary.json ]; then
  python3 tools/retain_rust_gate_artifacts.py \
    --summary target/frozen-ci/rust/summary.json \
    --fixture-directory target/grouped-gate/fixture-images || evidence_status=$?
fi
python3 - <<'PY'
import re, shutil
from pathlib import Path
root = Path('target/frozen-ci')
for name in ('module', 'eglot', 'affected', 'remaining', 'frozen', 'ordinary-perf'):
    log = root / f'{name}.log'
    if not log.exists():
        continue
    for value in re.findall(r'^Artifacts: (.+)$', log.read_text(), re.M):
        source = Path(value)
        if source.is_dir():
            shutil.copytree(source, root / 'compat' / source.name,
                ignore=lambda directory, names: [n for n in names if n == 'tools' or n.startswith('runtime-')])
PY
exit "$evidence_status"
