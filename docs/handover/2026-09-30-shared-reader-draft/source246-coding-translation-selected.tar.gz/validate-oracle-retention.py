from pathlib import Path
import hashlib
import json
import subprocess
import sys

p = Path(__file__).parent.resolve()
root = p.parents[2]
work = p / 'oracle-retention-validation'
work.mkdir()
tool = root / 'tools/retain_oracle_artifacts.py'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
records = []

def run(label, command, expected, cwd=root):
    result = subprocess.run(command, cwd=cwd, stdin=subprocess.DEVNULL, capture_output=True)
    for suffix, data in [('stdout', result.stdout), ('stderr', result.stderr)]:
        with (work / (label + '.' + suffix)).open('xb') as stream:
            stream.write(data)
    row = dict(label=label, command=command, cwd=str(cwd), exit_code=result.returncode,
               expected_success=expected == 0, stdout_sha256=hashlib.sha256(result.stdout).hexdigest(),
               stderr_sha256=hashlib.sha256(result.stderr).hexdigest())
    records.append(row)
    with (work / (label + '.json')).open('x') as stream:
        json.dump(row, stream, indent=2)
    assert (result.returncode == 0) == (expected == 0), row
    return result

def capture(label, source, destination, expected=0):
    return run(label, [sys.executable, str(tool), 'capture', '--oracle-source', str(source),
                       '--output', str(destination)], expected)

def verify(label, destination, expected=0):
    return run(label, [sys.executable, str(tool), 'verify', '--output', str(destination)], expected)

gnu = p.parent / 'recovered-2026-09-30/emacs'
real = work / 'real-gnu'
capture('real-capture', gnu, real)
verify('real-verify', real)
actual = json.loads((real / 'manifest.json').read_text())
assert actual['source_commit'] == '636f166cfc86aa90d63f592fd99f3fdd9ef95ebd'
assert json.loads((real / 'verification.json').read_text())['files_verified'] == 4

fake = work / 'synthetic-source'
(fake / 'src').mkdir(parents=True)
run('synthetic-init', ['git', 'init', '-q'], 0, fake)
run('synthetic-commit', ['git', '-c', 'user.name=Ray', '-c', 'user.email=26018378+rayfdj@users.noreply.github.com',
    'commit', '-q', '--allow-empty', '-m', 'Oracle retention validation input'], 0, fake)
for case in ['unchanged', 'changed-original', 'changed-retained', 'missing-original',
             'incomplete-inventory', 'malformed-manifest', 'duplicate-capture']:
    for name in ['emacs', 'emacs.pdmp', 'config.h', 'Makefile']:
        (fake / 'src' / name).write_bytes(('synthetic ' + name).encode())
    destination = work / case
    capture(case + '-capture', fake, destination)
    before = sha(destination / 'manifest.json')
    if case == 'changed-original':
        (fake / 'src/emacs').write_bytes(b'changed original')
    elif case == 'changed-retained':
        (destination / 'emacs.pdmp').write_bytes(b'changed copy')
    elif case == 'missing-original':
        (fake / 'src/config.h').unlink()
    elif case == 'incomplete-inventory':
        manifest = json.loads((destination / 'manifest.json').read_text())
        manifest['files'].pop()
        (destination / 'manifest.json').write_text(json.dumps(manifest))
    elif case == 'malformed-manifest':
        (destination / 'manifest.json').write_text('{invalid')
    elif case == 'duplicate-capture':
        capture(case + '-rejected', fake, destination, 1)
        assert sha(destination / 'manifest.json') == before
    verify(case + '-verify', destination, 0 if case in ['unchanged', 'duplicate-capture'] else 1)
    if case not in ['unchanged', 'duplicate-capture', 'malformed-manifest']:
        assert json.loads((destination / 'verification.json').read_text())['status'] == 'failed'

compile(tool.read_text(), str(tool), 'exec')
workflow = root / '.github/workflows/frozen-run.yml'
parsed = run('workflow-yaml', ['ruby', '-rjson', '-rpsych', '-e',
    'puts JSON.generate(Psych.load_file(ARGV[0]))', str(workflow)], 0)
jobs = json.loads(parsed.stdout)['jobs']
shell_blocks = 0
for job in jobs.values():
    for step in job['steps']:
        if 'run' in step:
            block = work / ('workflow-shell-' + str(shell_blocks) + '.sh')
            block.write_text(step['run'])
            run('workflow-shell-' + str(shell_blocks), ['bash', '-n', str(block)], 0)
            shell_blocks += 1
run('diff-check', ['git', 'diff', '--check'], 0)
summary = dict(status='passed', tool_sha256=sha(tool), workflow_sha256=sha(workflow),
    real_gnu=actual, commands=len(records), shell_blocks=shell_blocks,
    negative_controls=['changed original', 'changed retained copy', 'missing original',
        'incomplete inventory', 'malformed manifest', 'duplicate capture'],
    qualification='Real configured GNU bytes captured and verified. Synthetic corruptions reject with nonzero exit; duplicate capture preserves the original manifest. No real GNU file is modified and no runtime verdict is changed. Workflow YAML and all shell blocks parse; remote execution remains separate.')
with (p / 'oracle-retention-validation-audit.json').open('x') as stream:
    json.dump(summary, stream, indent=2)
print(json.dumps({k:summary[k] for k in ['status','commands','shell_blocks','negative_controls']}, indent=2))
