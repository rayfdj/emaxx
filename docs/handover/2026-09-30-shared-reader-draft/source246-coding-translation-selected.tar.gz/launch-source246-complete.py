from pathlib import Path
import hashlib, json, subprocess, sys

p = Path(__file__).parent.resolve()
read = lambda name: json.loads((p / name).read_text())
stages = read('source246-validation-result.json')
assert len(stages) == 7 and all(stage['exit_code'] == 0 for stage in stages)
assert read('source246-gate-focused-audit.json')['passed'] == 168
selected = read('source246-selected-audit.json')
assert selected['affected_passes'] == 951 and selected['ordinary_comparisons'] == 11
assert read('source246-upstream-compiler-raw-audit.json')['outcomes_per_editor'] == 177
records = []
for label, name in [('full-gate', 'run-source246-full-gate.py'),
                    ('release-and-ordinary', 'run-source246-release-and-ordinary.py'),
                    ('full-ttydiff', 'run-source246-full-tty.py')]:
    helper = p / name
    with (p / ('source246-' + label + '-driver.log')).open('x') as log:
        child = subprocess.Popen([sys.executable, '-B', str(helper)], stdin=subprocess.DEVNULL,
                                 stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    record = dict(pid=child.pid, command=[sys.executable, '-B', str(helper)],
                  helper_sha256=hashlib.sha256(helper.read_bytes()).hexdigest(),
                  source_manifest='source246-manifest.json', qualification='Launch is not a passing result.')
    with (p / ('source246-' + label + '-launch.json')).open('x') as stream:json.dump(record, stream, indent=2)
    records.append(record)
with (p / 'source246-complete-launch-result.json').open('x') as stream:json.dump(records, stream, indent=2)
print(json.dumps(records, indent=2), flush=True)
