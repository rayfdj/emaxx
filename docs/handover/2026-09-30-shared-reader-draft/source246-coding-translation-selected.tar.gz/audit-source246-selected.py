from pathlib import Path
import ast, hashlib, json, re

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/coding-translation/emaxx'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'audit-source238-release.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'audit_log')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<raw-verdict-auditor>', 'exec'))
manifest = read('source246-manifest.json')
assert len(manifest) == 468 and all(sha(root / name) == digest for name, digest in manifest.items())
stages = read('source246-validation-result.json')
assert len(stages) == 7 and all(stage['exit_code'] == 0 for stage in stages)
assert read('source246-gate-focused-audit.json')['passed'] == 168
command, result = read('source246-gate-broad-command.json'), read('source246-gate-broad-result.json')
assert result['exit_code'] == 0 and result['source_unchanged']
assert sha(p / 'source246-gate-libtest') == command['binary_sha256']
inventory = [line[:-6] for line in (p / 'source246-gate-inventory.txt').read_text().splitlines() if line.endswith(': test')]
assert len(inventory) == len(set(inventory)) == 2999
prefixes = ('lisp::bytecode::', 'lisp::native_comp::runtime::', 'lisp::primitives::pdumper::',
            'lisp::primitives::tests::', 'lisp::reader::', 'lisp::types::')
names = command['selected_inventory']
assert len(names) == 951 and names == [name for name in inventory if name.startswith(prefixes)]
previous = set(read('source244-gate-broad-command.json')['selected_inventory'])
assert previous <= set(names)
assert set(names) - previous == {'lisp::primitives::tests::coding_candidates_apply_live_translation_tables_and_registration_lists', 'lisp::primitives::tests::coding_candidates_preserve_private_use_characters_and_symbol_identity'}
assert command['command'][1:] == names + ['--exact', '--nocapture', '--test-threads=1']
audit_log(names, (p / 'source246-gate-broad.log').read_text(), [])
for stage in ['ordinary-build', 'ordinary-image']:
    result = read('source246-' + stage + '-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
    assert not re.search(r'^warning(?:\[.*\])?:', (p / ('source246-' + stage + '.log')).read_text(), re.M)
artifacts = read('source246-ordinary-artifacts.json')
for name, entry in artifacts.items():
    assert sha(Path(name)) == entry['sha256'] == sha(Path(entry['immutable_copy']))
fixtures = ['canonical-coding-character-storage', 'canonical-coding-identity-storage',
            'canonical-coding-conversion-storage', 'copied-canonical-string-storage',
            'file-write-coding-selection', 'new-file-coding-lifecycle', 'file-write-order',
            'coding-error-object-storage', 'coding-candidate-inventory', 'coding-candidate-translation', 'coding-candidate-character-identities']
for fixture in fixtures:
    stem = 'source246-ordinary-' + fixture
    comparison = read(stem + '-comparison.json')
    assert comparison['passed'] and comparison['exact_match']
    program = (root / ('tests/fixtures/' + fixture + '.el')).read_text()
    expected = (root / ('tests/fixtures/' + fixture + '.expected')).read_bytes().rstrip(b'\n')
    for editor in ['gnu', 'emaxx']:
        result = read(stem + '-' + editor + '.result.json')
        command = read(stem + '-' + editor + '.command.json')
        assert result == comparison['outcomes'][editor]
        assert result['exit_code'] == 0 and not result['timed_out'] and result['expected_output']
        assert result['source_unchanged'] and result['inputs_unchanged']
        assert command['environment_override']['LANG'] == command['environment_override']['LC_ALL'] == 'C'
        assert command['command'][1:] == ['-Q', '--batch', '--eval', '(prin1 ' + program + ')']
        assert command['fixture_mode'] == 'print-return-value'
        assert all(sha(Path(name)) == digest for name, digest in command['inputs'].items())
        stdout = p / (stem + '-' + editor + '.stdout')
        assert stdout.read_bytes() == expected and sha(stdout) == result['stdout_sha256']
        assert (p / (stem + '-' + editor + '.stderr')).read_bytes() == b''
load = read('source246-compiler-load-result.json')
assert len(load) == 2
for result in load:
    stem = 'source246-compiler-load-' + result['editor']
    command = read(stem + '-command.json')
    assert result['exit_code'] == 0 and not result['timed_out'] and result['source_unchanged'] and result['inputs_unchanged']
    assert all(sha(Path(name)) == digest for name, digest in command['inputs'].items())
    assert (p / (stem + '.stdout')).read_bytes() == b'loaded'
    assert sha(p / (stem + '.stdout')) == result['stdout_sha256']
    assert sha(p / (stem + '.stderr')) == result['stderr_sha256']
record = dict(status='passed', affected_passes=951, affected_names=names, inventory=2999,
              ordinary_comparisons=len(fixtures), fixtures=fixtures, compiler_load='both editors succeed',
              inputs_verified=468, artifacts=artifacts,
              qualification='All preceding affected-module controls remain, plus the two new unchanged GNU fixtures. All eleven ordinary coding/file-writing fixtures match exactly. The unchanged upstream compiler-file load that fails on source244 now succeeds in both normal editors. Compiler test outcomes, full gates, final pinned Darwin and performance remain separate. No assertion, selector, timeout or expected-output change.')
with (p / 'source246-selected-audit.json').open('x') as stream:json.dump(record, stream, indent=2)
print(json.dumps({key: record[key] for key in ['status', 'affected_passes', 'ordinary_comparisons', 'compiler_load']}, indent=2))
