from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected', '.loaded', '.h', '.sh'}

def collect(patterns, directories=()):
    files = {str(f.relative_to(p)): f for pattern in patterns for f in p.glob(pattern)
             if f.is_file() and f.suffix in allowed}
    for directory in directories:
        files.update({str(f.relative_to(p)): f for f in (p / directory).rglob('*')
                      if f.is_file() and (f.suffix in allowed or f.name == 'Makefile')})
    files[Path(__file__).name] = Path(__file__)
    return files

mac = read('source244-macos-rust-complete-audit.json')
release = read('source244-release-audit.json')
rust = read('source244-linux-rust-failure-audit.json')
frozen = read('source244-linux-frozen-failure-audit.json')
tty = read('source244-terminal-failure-audit.json')
assert mac['total_passed'] == 3094 and rust['library_passed'] == 2258 and rust['library_failed'] == 2
assert frozen['verified_outcomes'] == 7928 and frozen['matching_outcomes'] == 7927
assert tty['fully_matching_scenarios'] == 80 and tty['unexecuted_comparisons'] == 606
for label in ['rust', 'frozen']:
    download = read('source244-linux-' + label + '-download.json')
    archive = p / ('source244-linux-' + label + '-artifact.zip')
    assert sha(archive.read_bytes()) == download['archive_sha256']
    assert 'sha256:' + download['archive_sha256'] == download['artifact']['digest']
    for name, digest in download['files'].items():
        assert sha((p / ('source244-linux-' + label + '-artifacts') / name).read_bytes()) == digest
files = collect([
    'source244-full-*', 'source244-macos-*', 'source244-release-*',
    'source244-terminal-failure-audit.json', 'source244-linux-*',
    'source244-manifest.json', 'source244-ordinary-artifacts.json',
    'audit-source244-*.py', 'verify-source244-macos-rust.py',
    'download-source244-linux-*.py', 'run-source244-full-*.py',
    'run-source244-release-and-ordinary.py', 'audit-source238-release.py',
], ['full-gate-source244', 'source244-release-focused-retained-inputs',
    'source244-linux-rust-artifacts', 'source244-linux-frozen-artifacts'])
package('source244-closed-validation', files, dict(
    macos=mac, release=release, linux_rust=rust, linux_frozen=frozen, terminal=tty,
    qualification='All source244 full supervisors are closed. Full macOS and selected release pass; Linux Rust, Linux frozen and full terminal remain failed exactly as recorded. The frozen compiler load regression is repaired, but one unexpected GNU Eglot JSON-RPC timeout differs from an Emaxx pass. Both Linux Rust failures are GNU reference assertions before Emaxx comparison; GNU executable/dump were not retained by that job. No final-source or performance certification.'))

selected = read('source246-selected-audit.json')
focused = read('source246-gate-focused-audit.json')
compiler = read('source246-upstream-compiler-raw-audit.json')
assert selected['affected_passes'] == 951 and focused['passed'] == 168
assert selected['ordinary_comparisons'] == 11 and compiler['outcomes_per_editor'] == 177
patterns = ['source245-*', '*source245*.py', 'source246-manifest.json', 'source246-*.patch',
    'source246-freeze.json', 'source246-patch-replay-audit.json', 'source246-validation-*',
    'source246-gate-*', 'source246-selected-audit.json', 'source246-ordinary-artifacts.json',
    'source246-ordinary-build*', 'source246-ordinary-image*', 'source246-compiler-load-*',
    'source246-upstream-compiler-*', 'source246-task-checkout-applied.json',
    'source246-complete-launch-result.json', 'source246-full-gate-launch.json',
    'source246-full-gate-command.json', 'source246-full-ttydiff-launch.json',
    'source246-full-ttydiff-command.json', 'source246-release-and-ordinary-launch.json',
    '*source246*.py', 'source244-coding-translation-*', 'source244-coding-character-identities-*',
    'source243-coding-character-identities-*', 'probe-source244-coding-*.py',
    'probe-source243-coding-character-identities.py', 'coding-candidate-translation*',
    'coding-candidate-character-identities*', 'compare-source230-fixtures.py',
    'audit-source238-release.py', 'validate-oracle-retention.py',
    'oracle-retention-validation-audit.json']
for stage in ['check', 'fmt', 'clippy', 'diff']:
    patterns.append('source246-' + stage + '*')
for fixture in selected['fixtures']:
    patterns.append('source246-ordinary-' + fixture + '-*')
files = collect(patterns, ['source246-compiler-load', 'source246-upstream-compiler',
                            'oracle-retention-validation'])
assert not any(name in files for name in ['source246-full-gate.log', 'source246-full-ttydiff.log',
    'source246-release-and-ordinary-driver.log', 'source246-ordinary-comparisons.log'])
package('source246-coding-translation-selected', files, dict(
    patch_replay=read('source246-patch-replay-audit.json'), focused=focused, selected=selected,
    compiler=compiler, prior_compile_failure=read('source245-compile-failure-audit.json'),
    full_launches=read('source246-complete-launch-result.json'),
    retention=read('oracle-retention-validation-audit.json'),
    qualification='Source244 negative probes and source243 character control remain unchanged. Source245 compile failure is preserved. Source246 repairs coding safety translation/registration-list handling and preserves actual private-use character numbers. All 468 inputs/modes replay, strict checks have zero warnings, 168 focused tests and 951 affected tests pass, eleven ordinary comparisons match and all original 177 compiler tests pass in both editors. Full macOS/release/terminal are running; active logs are excluded. Remaining general coding/translation/registry authority and final platform/performance requirements are open. GNU artifact capture is independently validated with the real configured GNU and synthetic rejection controls; it changes no runtime verdict.'))
