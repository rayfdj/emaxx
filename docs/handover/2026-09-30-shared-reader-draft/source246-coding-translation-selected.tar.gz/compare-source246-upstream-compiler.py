from pathlib import Path
from collections import Counter
import hashlib, json, os, shutil, subprocess, time

p = Path(__file__).parent.resolve()
root = p.parents[2]
recovered = p.parent / 'recovered-2026-09-30'
candidate = recovered / 'coding-translation/emaxx'
gnu = recovered / 'emacs'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
manifest = json.loads((p / 'source246-manifest.json').read_text())
unchanged = lambda: all(sha(candidate / name) == digest for name, digest in manifest.items())
assert len(manifest) == 468 and unchanged()
assert json.loads((p / 'source246-ordinary-image-result.json').read_text())['exit_code'] == 0
work = p / 'source246-upstream-compiler'
work.mkdir()
selector = '(not (or (tag :expensive-test) (tag :unstable)))'
records, reports = {}, {}
for editor, binary in [('gnu', gnu / 'src/emacs'), ('emaxx', candidate / 'target/frame-validation/release/emaxx')]:
    directory = work / editor
    directory.mkdir()
    source = directory / 'comp-tests.el'
    shutil.copy2(gnu / 'test/src/comp-tests.el', source)
    shutil.copytree(gnu / 'test/src/comp-resources', directory / 'comp-resources')
    original_inputs = [source, *(directory / 'comp-resources').rglob('*.el')]
    assert sha(source) == sha(gnu / 'test/src/comp-tests.el')
    assert all(sha(file) == sha(gnu / 'test/src' / file.relative_to(directory)) for file in original_inputs)
    runner = candidate / 'compat/emacs_compat_runner.el'
    inputs = {str(file): sha(file) for file in [binary, binary.with_suffix('.pdmp'), runner, Path(__file__), *original_inputs]}
    report_file = directory / 'report.json'
    overrides = {'LANG': 'C', 'LC_ALL': 'C', 'EMAXX_GC_VERIFY': '1',
                 'EMAXX_COMPAT_RUNNER': editor, 'EMAXX_BATCH_RESULT_FILE': str(report_file),
                 'EMAXX_COMPAT_RELATIVE_FILE': 'test/src/comp-tests.el',
                 'EMAXX_COMPAT_SELECTOR': '(quote ' + selector + ')',
                 'EMACS_TEST_DIRECTORY': str(gnu / 'test')}
    command = [str(binary), '--eval', f'(startup-redirect-eln-cache {json.dumps(str(directory / "eln-cache"))})',
               '--no-init-file', '--no-site-file', '--no-site-lisp', '--batch',
               '-L', str(gnu / 'test'), '-l', 'ert', '-l', str(runner), '-l', str(source),
               '--eval', '(emaxx-compat-run (quote ' + selector + '))']
    stem = p / ('source246-upstream-compiler-' + editor)
    with Path(str(stem) + '-command.json').open('x') as stream:
        json.dump(dict(command=command, working_directory=str(root), environment_override=overrides,
                       inputs=inputs, timeout_seconds=3600,
                       qualification='Complete original compiler test file, original resources and unchanged default selector/reporter through normal editors with separate native caches. Source/ABI-matched Darwin GNU is not the frozen Darwin executable. This selected-file comparison does not replace the complete frozen inventory.'), stream, indent=2)
    start = time.monotonic()
    try:
        result = subprocess.run(command, cwd=root, env={**os.environ, **overrides},
                                stdin=subprocess.DEVNULL, capture_output=True, timeout=3600)
        code, stdout, stderr, timed_out = result.returncode, result.stdout, result.stderr, False
    except subprocess.TimeoutExpired as error:
        code, stdout, stderr, timed_out = None, error.stdout or b'', error.stderr or b'', True
    for suffix, data in [('stdout', stdout), ('stderr', stderr)]:
        with Path(str(stem) + '.' + suffix).open('xb') as stream:stream.write(data)
    record = dict(exit_code=code, timed_out=timed_out, elapsed_seconds=time.monotonic()-start,
                  stdout_sha256=hashlib.sha256(stdout).hexdigest(), stderr_sha256=hashlib.sha256(stderr).hexdigest(),
                  source_unchanged=unchanged(), inputs_unchanged=all(sha(Path(name)) == digest for name, digest in inputs.items()),
                  report_sha256=sha(report_file) if report_file.exists() else None)
    with Path(str(stem) + '-result.json').open('x') as stream:json.dump(record, stream, indent=2)
    records[editor] = record
    reports[editor] = json.loads(report_file.read_text()) if report_file.exists() else None
    print(editor, json.dumps(record), flush=True)
valid_processes = all(record['exit_code'] == 0 and not record['timed_out'] and record['source_unchanged'] and record['inputs_unchanged'] for record in records.values())
complete = valid_processes and all(report and report['file_status'] == 'loaded' and
                                  sorted(report['selected_tests']) == sorted(row['name'] for row in report['results'])
                                  for report in reports.values())
outcomes = lambda report: {row['name']: (row['status'], row['expected']) for row in report['results']}
matched = complete and all(reports['gnu'][field] == reports['emaxx'][field]
                           for field in ['selector', 'file', 'discovered_tests', 'selected_tests']) and outcomes(reports['gnu']) == outcomes(reports['emaxx'])
expected = matched and all(row['expected'] or row['status'] == 'skipped' for row in reports['gnu']['results'])
audit = dict(status='passed' if expected else 'failed', processes=records,
             same_inventories_and_outcomes=bool(matched),
             counts={editor: dict(Counter(row['status'] for row in report['results'])) if report else None for editor, report in reports.items()},
             qualification='Original compiler-file comparison only. Every selected test must run in both editors and match its expected outcome; missing reports or unsuccessful processes fail. No frozen Darwin, complete-gate or performance claim.')
with (p / 'source246-upstream-compiler-audit.json').open('x') as stream:json.dump(audit, stream, indent=2)
print(json.dumps(audit, indent=2), flush=True)
raise SystemExit(0 if expected else 1)
