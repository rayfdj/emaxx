from pathlib import Path
import hashlib, json, subprocess
p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/coding-translation/emaxx'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
files = [*root.joinpath('src').rglob('*.rs'), *root.joinpath('tests').rglob('*')]
files += [root / name for name in ['Cargo.toml', 'Cargo.lock', 'build.rs', 'tools/ttydiff.py', 'tools/fixtures/fieldnotes.org', 'tools/fixtures/fake_lsp_server.py']]
files += list(root.joinpath('.cargo').glob('*'))
files += [root / name for name in ['compat/emacs_compat_runner.el', 'src/lisp/bytecode/fixture-oracle-30.2.elc', 'src/lisp/bytecode/fixture-oracle2-30.2.elc', 'src/lisp/bytecode/fixture-oracle3-30.2.elc']]
manifest = {str(file.relative_to(root)): sha(file) for file in sorted(set(files)) if file.is_file()}
assert len(manifest) == 468
with (p / 'source245-manifest.json').open('x') as f:
    json.dump(manifest, f, indent=2)
untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=root, text=True).splitlines()
extra = b''
for name in sorted(set(untracked) & set(manifest)):
    result = subprocess.run(['git', 'diff', '--no-index', '--binary', '--', '/dev/null', name], cwd=root, capture_output=True)
    assert result.returncode == 1 and not result.stderr
    extra += result.stdout
patches = {}
for label, base in [('incremental', '0f5e6ff8e6d7662d2eb648ee9f872ad4a96ef489'),
                    ('complete', '21d20f0eec08f3c013d5d3eb3bd6e9cfc16b3199')]:
    patch = subprocess.check_output(['git', 'diff', '--binary', base, '--', *sorted(manifest)], cwd=root) + extra
    target = p / ('source245-' + label + '.patch')
    with target.open('xb') as f:
        f.write(patch)
    patches[label] = dict(base=base, sha256=sha(target), bytes=len(patch))
record = dict(inputs=468, patches=patches, candidate=str(root), goal_complete=False,
              qualification='Separate safe-coding translation and identity repair, not yet validated. Uses the Lisp-visible registration list with its actual order, duplicates and bindings; resolves live coding translation tables and standard encode tables; preserves actual private-use character numbers instead of the legacy regex sentinel conversion. Two new ordinary negative source244 fixtures retain unchanged GNU expected outputs. Existing legacy-text callers retain their wrapper while the safety helper uses actual character numbers. Actual encoder translation and full registration-list representation are separate remaining review areas; no complete coding or performance claim. Source244 full runs remain unchanged.')
with (p / 'source245-freeze.json').open('x') as f:
    json.dump(record, f, indent=2)
print(json.dumps(record, indent=2))
