from pathlib import Path
import hashlib
import json
import re
import runpy

p = Path(__file__).resolve().parent
prior = p.parent / "resume-2026-09-28"
read = lambda f: json.loads(f.read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
command = read(p / "terminal-diagnostic-command.json")
results = read(p / "terminal-diagnostic-results.json")
root = Path(command["working_directory"])
source = read(prior / "source312-final-manifest.json")
assert len(source) == 552 and all(sha(root / n) == h for n, h in source.items())
assert all(sha(Path(n)) == h for n, h in command["inputs"].items())
assert [r["scenario"] for r in results] == command["selection"]
assert len(results) == 42
module = runpy.run_path(str(root / "tools/ttydiff.py"), run_name="inventory_only")


def labels(scenario):
    name, keys = scenario[0], scenario[2]
    result, final_label, final_fs = [], name, False
    for index, item in enumerate(keys):
        action = module["normalize_action"](item, index)
        if not action.checkpoint:
            continue
        label = f"{name}::{index+1}:{action.name}"
        if index + 1 == len(keys):
            final_label, final_fs = label, action.filesystem
        else:
            result.append(label)
            if action.filesystem:
                result.append(label + " filesystem")
    result.append(final_label)
    if final_fs:
        result.append(final_label + " filesystem")
    return result


all_scenarios = module["select_scenarios"]([])
expected = {s[0]: labels(s) for s in all_scenarios}
assert len(expected) == 226 and sum(map(len, expected.values())) == 686
matches, failures, unexecuted = [], [], []
screens = 0
for result in results:
    name = result["scenario"]
    log = p / ("terminal-" + name + ".log")
    assert sha(log) == result["log_sha256"]
    raw = log.read_text()
    assert re.findall(r"^RUN \[(.+)\] (.+)$", raw, re.M) == [("1/1", name)]
    verdicts = re.findall(r"^(MATCH|DIVERGE) \[(.+)\]: (.+)$", raw, re.M)
    observed = [v[1] for v in verdicts]
    assert observed == expected[name][:len(observed)]
    snapshots = [json.loads(line) for line in log.with_suffix(".screens.jsonl").read_text().splitlines()]
    original = [x for x in snapshots if ":diagnostic-" not in x["label"] and not x["label"].startswith("startup-failed:")]
    assert [x["label"] for x in original] == [x for x in observed if not x.endswith(" filesystem")]
    screen_verdicts = {v[1]: v[0] for v in verdicts}
    for snapshot in original:
        assert len(snapshot["sessions"]) == 2
        gnu, candidate = snapshot["sessions"]
        # Check all 24 raw rows, every cell attribute and both cursor coordinates;
        # this is independent of the harness's reported 22-row text-area count.
        identical = all(gnu[k] == candidate[k] for k in ("lines", "attrs", "cursor"))
        if screen_verdicts[snapshot["label"]] == "MATCH":
            assert identical, snapshot["label"]
        screens += 1
    ok = observed == expected[name] and all(v[0] == "MATCH" for v in verdicts)
    assert (result["exit_code"] == 0) == ok
    assert ("PASS: all scenarios match" in raw) == ok
    matches += [v[1] for v in verdicts if v[0] == "MATCH"]
    failures += [v[1] for v in verdicts if v[0] != "MATCH"]
    unexecuted += expected[name][len(observed):]

ordinary = read(p / "package-ordinary-result.json")
assert ordinary["exit_code"] == 0 and ordinary["inputs_unchanged"]
assert re.findall(r"^MATCH \[(.+)\]:", (p / "package-ordinary.log").read_text(), re.M) == expected["package-menu-install-refresh-remove"]
old_logs = [prior / "source312-terminal-retry.log", prior / "source312-terminal-tail.log"]
assert sha(old_logs[0]) == read(prior / "source312-macos-terminal-audit.json")["log_sha256"]
assert sha(old_logs[1]) == read(prior / "source312-terminal-tail-audit.json")["log_sha256"]
old_matches = {label for f in old_logs for label in re.findall(r"^MATCH \[(.+)\]:", f.read_text(), re.M)}
all_labels = {label for ls in expected.values() for label in ls}
matching_union = old_matches | set(matches)
assert matching_union <= all_labels

record = dict(status="passed" if not failures and not unexecuted else "failed",
    selected_scenarios=42, selected_comparisons=sum(len(expected[n]) for n in command["selection"]),
    matching_comparisons=len(matches), observed_screen_snapshots=screens,
    divergent_labels=failures, unexecuted_labels=unexecuted,
    original_source_inputs_verified=len(source), execution_inputs_verified=len(command["inputs"]),
    ordinary_package_comparisons=11,
    distinct_matching_labels_across_separate_attempts=len(matching_union),
    labels_without_any_matching_observation=sorted(all_labels-matching_union),
    previous_failures_preserved=["package-menu-install-refresh-remove::5:confirm-install", "GNU dired startup readiness", "GNU Org startup readiness"],
    qualification="The original full run and first tail remain failed. Separate matching observations, including one unchanged ordinary package replay and this full-screen diagnostic cohort, do not diagnose the intermittent package failure or constitute one complete passing ordinary run. No production change, performance acceptance or full-goal completion is claimed.")
(p / "terminal-audit.json").open("x").write(json.dumps(record, indent=2))
print(json.dumps(record, indent=2))
