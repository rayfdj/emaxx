from pathlib import Path
import gzip
import hashlib
import json
import tarfile

p = Path(__file__).resolve().parent
repo = p.parents[2]
previous = p.parent / "resume-2026-09-28"
destination = repo / "docs/handover/2026-09-30-shared-reader-draft"
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
audit = json.loads((p / "terminal-audit.json").read_text())
source = json.loads((previous / "source313-manifest.json").read_text())
assert len(source) == 552 and all(sha(repo / n) == h for n, h in source.items())
files = {p.name + "/" + f.name: f for f in p.iterdir() if f.is_file()}
for name in (
    "source312-final-manifest.json", "source313-manifest.json",
    "source312-terminal-tail-command.json", "source312-terminal-tail-audit.json",
    "source312-macos-terminal-audit.json",
    "source312-terminal-retry.log", "source312-terminal-tail.log",
):
    files[previous.name + "/" + name] = previous / name
name = "source313-postmerge-terminal-results"
archive = destination / (name + ".tar.gz")
with archive.open("xb") as raw, gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as compressed, tarfile.open(fileobj=compressed, mode="w|") as bundle:
    for path, file in sorted(files.items()):
        info = bundle.gettarinfo(str(file), arcname=path)
        info.uid = info.gid = 0
        info.uname = info.gname = ""
        info.mtime = 0
        with file.open("rb") as data:
            bundle.addfile(info, data)
expected = {name: {"sha256": sha(file), "bytes": file.stat().st_size} for name, file in sorted(files.items())}
with tarfile.open(archive) as bundle:
    assert set(bundle.getnames()) == set(expected)
    for member in bundle.getmembers():
        data = bundle.extractfile(member).read()
        assert len(data) == expected[member.name]["bytes"]
        assert hashlib.sha256(data).hexdigest() == expected[member.name]["sha256"]
manifest = dict(archive=archive.name, sha256=sha(archive), bytes=archive.stat().st_size,
    main_merge="6ff4931467fa70acfe837d91245e5c76ddc6515f", runtime_test_inputs_unchanged=552,
    result=audit, files=expected,
    reproduction="The ordinary package command is in package-ordinary-command.json. continue_terminal.py invokes the unchanged retained tools/ttydiff.py through terminal_diagnostic.py for all 42 previously incomplete scenarios. audit_terminal.py checks raw reports and complete screens against the original inventory. Paths record this machine's retained artifacts; executables/images are excluded. A rebuilt artifact requires its own validation and identity record. The previous failed logs are retained alongside the new results.")
(destination / (name + "-manifest.json")).open("x").write(json.dumps(manifest, indent=2))
print(json.dumps({k:manifest[k] for k in ("archive", "sha256", "bytes", "runtime_test_inputs_unchanged")}))
