from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

p = Path(__file__).resolve().parent
old_dir = p.parent / "resume-2026-09-28"
previous = json.loads((old_dir / "source312-terminal-tail-command.json").read_text())
audit = json.loads((old_dir / "source312-terminal-tail-audit.json").read_text())
selection = [case["scenario"] for case in audit["partial_scenarios"]] + audit["unstarted_scenarios"]
assert len(selection) == 42 and len(set(selection)) == 42
sha = lambda f: hashlib.sha256(Path(f).read_bytes()).hexdigest()
inputs = previous["inputs"] | {str(p / "terminal_diagnostic.py"): sha(p / "terminal_diagnostic.py"), str(Path(__file__).resolve()): sha(Path(__file__).resolve())}
assert all(sha(n) == h for n, h in inputs.items())
record = {k: previous[k] for k in ("candidate_commit", "working_directory", "environment_override")}
record.update(inputs=inputs, selection=selection,
    qualification="Separate diagnostics of all 42 incomplete scenarios. Original harness, binaries, image, actions and timeouts unchanged. Observer stores full screens; any extra wait or editor command happens only after an original failure and cannot change that verdict. Earlier failures remain failed.")
(p / "terminal-diagnostic-command.json").open("x").write(json.dumps(record, indent=2))
results = []
for index, name in enumerate(selection):
    prefix = p / ("terminal-" + name)
    command = ["/usr/bin/caffeinate", "-i", sys.executable, "-u", str(p / "terminal_diagnostic.py"), str(prefix)] + previous["command"][4:7] + [name]
    print(f"RUN {index+1}/{len(selection)} {name}", flush=True)
    started = time.monotonic()
    with prefix.with_suffix(".log").open("xb") as log:
        child = subprocess.run(command, cwd=previous["working_directory"],
            env=dict(os.environ, **previous["environment_override"]), stdin=subprocess.DEVNULL,
            stdout=log, stderr=subprocess.STDOUT)
    result = dict(scenario=name, command=command, exit_code=child.returncode,
        elapsed_seconds=time.monotonic()-started, log_sha256=sha(prefix.with_suffix(".log")))
    prefix.with_suffix(".result.json").open("x").write(json.dumps(result, indent=2))
    results.append(result)
    print(json.dumps(result), flush=True)
assert all(sha(n) == h for n, h in inputs.items())
(p / "terminal-diagnostic-results.json").open("x").write(json.dumps(results, indent=2))
