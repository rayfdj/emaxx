"""Observe the retained harness without changing its actions or verdicts.

Extra waits and Lisp inspection happen only after the original verdict fails.
They are diagnostic observations and cannot turn a failed verdict into a pass.
"""
from pathlib import Path
import importlib.util
import json
import os
import subprocess
import sys
import time

output = Path(sys.argv[1]).resolve()
spec = importlib.util.spec_from_file_location("retained_ttydiff", "tools/ttydiff.py")
tty = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = tty
spec.loader.exec_module(tty)
sessions = []
events = (output.with_suffix(".screens.jsonl")).open("x")


def snapshot(label):
    events.write(json.dumps({"label": label, "monotonic": time.monotonic(),
        "sessions": [{"pid": s.pid, "argv": s.observed_argv,
            "lines": s.screen.lines(), "attrs": s.screen.attr_rows(),
            "cursor": [s.screen.row, s.screen.col]} for s in sessions]}) + "\n")
    events.flush()


original_init = tty.Session.__init__


def observe_init(self, argv, env):
    original_init(self, argv, env)
    self.observed_argv = argv
    sessions.append(self)


tty.Session.__init__ = observe_init
original_report = tty.report_comparison


def report(label, gnu, emaxx):
    snapshot(label)
    verdict = original_report(label, gnu, emaxx)
    if not verdict:
        # Capture whether the same untouched editors finish later, then their
        # actual message buffers.  Preserve the original failed verdict.
        for s in sessions:
            s.drain(10.0, minimum=10.0)
        snapshot(label + ":diagnostic-extra-10s")
        for s in sessions:
            s.send(b"\x1b:(switch-to-buffer \"*Messages*\")\r",
                   settle=3.0, quiet=1.0, explicit_settle=True)
        snapshot(label + ":diagnostic-messages")
    return verdict


tty.report_comparison = report
original_wait = tty.Session.wait_for_screen_text


def wait(self, text, timeout, minimum=0.5):
    try:
        return original_wait(self, text, timeout, minimum)
    except RuntimeError:
        snapshot("startup-failed:" + text)
        sample = subprocess.run(["/usr/bin/sample", str(self.pid), "1", "1",
            "-file", str(output.with_suffix(".startup.sample.txt"))],
            capture_output=True, timeout=10)
        output.with_suffix(".sample-result.json").open("x").write(json.dumps({
            "exit_code": sample.returncode,
            "stdout": sample.stdout.decode(errors="replace"),
            "stderr": sample.stderr.decode(errors="replace")}, indent=2))
        self.send(b"\x07", settle=2.0, explicit_settle=True)
        self.send(b"\x1b:(switch-to-buffer \"*Messages*\")\r",
                  settle=3.0, quiet=1.0, explicit_settle=True)
        snapshot("startup-failed:diagnostic-messages")
        raise


tty.Session.wait_for_screen_text = wait
sys.argv = ["tools/ttydiff.py"] + sys.argv[2:]
try:
    tty.main()
finally:
    events.close()
