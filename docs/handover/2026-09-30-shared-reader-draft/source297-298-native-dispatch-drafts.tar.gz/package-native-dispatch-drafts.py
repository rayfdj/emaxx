from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda n: json.loads((p / n).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
selected = read('source297-selected-audit.json')
assert selected['status'] == 'passed' and selected['ordinary_comparisons'] == 47
assert all(r['passed'] == 327 and r['failed'] == r['ignored'] == 0 for r in selected['profiles'].values())
assert all(sha(Path(n).read_bytes()) == h for n, h in selected['evidence_files'].items())
files = {}
for tag, folder in [('source297', 'native-funcall-dispatch'), ('source298', 'native-empty-arguments')]:
    candidate = p.parent / 'recovered-2026-10-05' / folder / 'emaxx'
    manifest = read(tag + '-manifest.json')
    assert len(manifest) == 532 and all(sha((candidate / n).read_bytes()) == h for n, h in manifest.items())
    portable = read(tag + '-portable-draft-audit.json')
    assert len(portable['patches']) == 2
    for kind, row in zip(('incremental', 'complete'), portable['patches']):
        assert row['inputs'] == 532 and row['bytes_and_modes'] == 'exact'
        assert sha((p / row['patch']).read_bytes()) == row['sha256']
        replay = p / (tag + '-replay-' + kind)
        assert all(sha((replay / n).read_bytes()) == h
                   and (replay / n).stat().st_mode & 0o777 == (candidate / n).stat().st_mode & 0o777
                   for n, h in manifest.items())
    for suffix in ['-manifest.json', '-static-review.json', '-draft.patch',
                   '-portable-incremental.patch', '-portable-complete.patch', '-portable-draft-audit.json']:
        files[tag + suffix] = p / (tag + suffix)
allowed = {'.json', '.log', '.stdout', '.stderr', '.patch'}
for f in p.glob('source297-*'):
    if f.is_file() and f.suffix in allowed:
        files[f.name] = f
helpers = [
    'prepare-native-dispatch297.py', 'prepare-native-empty298.py',
    'run-source297-validation.py', 'run-source298-validation.py',
    'replay-native-dispatch297.py', 'replay-native-empty298.py',
    'verify-existing-portable-draft.py', 'native_fixed_validation_support.py',
    'compare-vm-dispatch-fixtures.py', 'compare-source296-generated-loaded.py',
    'compare-source297-generated-loaded.py', 'compare-source298-generated-loaded.py',
    'compare-buffer-line-broad-probe.py', 'audit-native-dispatch-selected.py',
    'finish-native-dispatch-selected-closed.py', 'finish-native-empty-selected-closed.py',
    'measure-native-dispatch.py', 'audit-native-dispatch-performance.py',
    'finish-native-dispatch-performance-closed.py', 'source296-full-validation-launch.json',
    'source296-applied-commit.json', 'source296-applied-push.json',
    'package-source196-failure-and197-results.py', Path(__file__).name,
]
files.update({n: p / n for n in helpers})
snapshots = {}
for name in ['source297-validation-state.json', 'source298-validation-state.json',
             'native-dispatch-selection-closed-state.json', 'native-empty-selection-closed-state.json',
             'native-dispatch-performance-sequence-closed-state.json']:
    data = read(name)
    destination = p / (name.removesuffix('.json') + '-draft-snapshot.json')
    with destination.open('x') as f:
        json.dump(data, f, indent=2)
    files[destination.name] = destination
    snapshots[name] = dict(status=data['status'], completed_stages=len(data.get('results', data.get('steps', []))),
                           profiles={k: {n: r[n] for n in ['passed', 'failed', 'ignored']}
                                     for k, r in data.get('profiles', {}).items()})
prerequisites = {n: sha((out / n).read_bytes()) for n in [
    'source296-native-fixed-selected-manifest.json', 'source296-native-fixed-performance-manifest.json',
    'source294-buffer-line-selected-manifest.json']}
package('source297-298-native-dispatch-drafts', files, dict(
    status='portable unapplied native dispatch297 and correctness-only298 drafts',
    source297_selected=dict(passed_per_profile=327, failed=0, ignored=0, ordinary_comparisons=47,
                            source_inputs=532, raw_audit_sha256=sha((p / 'source297-selected-audit.json').read_bytes())),
    snapshots=snapshots, prerequisites=prerequisites,
    qualification='Both drafts replay exact bytes and modes from applied68ca5d88 and main21d20f0e. Source297 moves the unchanged funcall guard after handler synchronization and repairs null/empty native arguments; correctness-only298 retains the original router. One shared null-storage control is added; all original tests/fixtures remain. Source297 selected/ordinary evidence is closed. Source298 validation and the queued three-way full16 diagnostic remain unfinished at capture. Do not infer performance or full validation. The helper preparation assertion failure,60 original width failures and prior GNU census failures remain. Binaries are retained locally by hash; rebuild for reproduction.',
    goal_complete=False))
