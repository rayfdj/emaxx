from pathlib import Path
import hashlib, json, subprocess, sys, time

p = Path(__file__).parent.resolve()
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
fixed = {n: sha(p / n) for n in ['measure-native-dispatch.py', 'audit-native-dispatch-performance.py', Path(__file__).name]}
state = dict(status='waiting for dispatch297 and correctness-only298 selected audits', helpers=fixed, steps=[], goal_complete=False)
def save():
    (p / 'native-dispatch-performance-sequence-closed-state.json').write_text(json.dumps(state, indent=2) + '\n')
save()
success = False
try:
    names = ['native-dispatch-selection-closed-result.json', 'native-empty-selection-closed-result.json']
    while not all((p / n).exists() for n in names):
        print(state['status'], flush=True)
        time.sleep(20)
    for name in names:
        selected = json.loads((p / name).read_text())
        assert selected['status'] == 'native-dispatch selected audit closed; 60 original display-column failures retained separately; performance pending', selected
        assert len(selected['steps']) == 5 and all(r['exit_code'] == 0 and r['helpers_unchanged'] for r in selected['steps'])
    for name in ['measure-native-dispatch.py', 'audit-native-dispatch-performance.py']:
        assert all(sha(p / n) == h for n, h in fixed.items())
        state['status'] = 'running ' + name
        save()
        start = time.monotonic()
        command = [sys.executable, '-B', str(p / name)]
        with (p / ('native-dispatch-performance-step-closed-' + name + '.log')).open('xb') as log:
            result = subprocess.run(command, cwd=p, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
        row = dict(command=command, exit_code=result.returncode, elapsed_seconds=time.monotonic()-start)
        state['steps'].append(row)
        save()
        print(json.dumps(row), flush=True)
        assert result.returncode == 0
    state['status'] = 'timing audited; source decision pending'
    success = True
except Exception as error:
    state.update(status='sequence stopped', error=repr(error))
finally:
    save()
    with (p / 'native-dispatch-performance-sequence-closed-result.json').open('x') as f:
        json.dump(state, f, indent=2)
print(json.dumps(dict(status=state['status'], error=state.get('error'))), flush=True)
sys.exit(0 if success else 1)
