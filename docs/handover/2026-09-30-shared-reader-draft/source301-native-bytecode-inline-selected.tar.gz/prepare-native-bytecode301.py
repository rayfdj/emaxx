from pathlib import Path
import ast, hashlib, json, subprocess

p = Path(__file__).parent.resolve()
root = p.parents[2]
c = p.parent / 'recovered-2026-10-05/native-bytecode-inline/emaxx'
prior = p.parent / 'recovered-2026-10-05/native-bytecode-entry-formatted/emaxx'
g = p.parent / 'rebuilt-2026-10-01/emacs'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p / n).read_text())
base = read('source297-applied-commit.json')['commit']
manifest = read('source300-manifest.json')
assert read('source300-selected-audit.json')['status'] == 'passed'
assert read('native-bytecode-performance-sequence-closed-result.json')['status'] == 'timing audited; source decision pending'
assert read('source300-application-decision.json')['status'].startswith('hold source300 unapplied')
assert all(sha(prior / n) == h for n, h in manifest.items())
assert not c.exists()
c.parent.mkdir()
(c.parent / 'emacs').symlink_to(g, target_is_directory=True)
for command in [
    ['git', 'clone', '--shared', '--quiet', '--no-checkout', str(root), str(c)],
    ['git', '-C', str(c), 'sparse-checkout', 'init', '--no-cone'],
    ['git', '-C', str(c), 'sparse-checkout', 'set', '--no-cone', *sorted({'/' + n for n in manifest} | {'/tools/', '/compat/'})],
    ['git', '-C', str(c), 'checkout', '--detach', base],
]:
    subprocess.run(command, check=True)
path = c / 'src/lisp/eval/core.rs'
before = (prior / 'src/lisp/eval/core.rs').read_text()
old = '    #[inline]\n    fn funcall_native_subr('
new = '    #[inline(always)]\n    fn funcall_native_subr('
assert before.count(old) == 1
path.write_text(before.replace(old, new))
subprocess.run(['cargo', 'fmt', '--all'], cwd=c, check=True)
assert path.read_text() == before.replace(old, new)
assert [n for n, h in manifest.items() if sha(c / n) != h] == ['src/lisp/eval/core.rs']
with (p / 'source301-static-review.json').open('x') as f:
    json.dump(dict(status='unvalidated inline-only variant of source300', candidate=str(c), base_commit=base,
                   input_sha256={str(path): sha(path), str(prior / 'src/lisp/eval/core.rs'): sha(prior / 'src/lisp/eval/core.rs')},
                   mechanism='Only the extracted funcall_native_subr helper changes from inline hint to inline(always). The body, Bcall guard, all fallback paths, tests and fixtures are byte-identical to300. The variant tests whether out-of-line helper overhead explains the retained native-transition regressions; no cause or speedup is inferred.',
                   qualification='Applied297 and held300 remain frozen. Preserve the complete first192-process diagnostic. Compare all16 workloads on297/300/301 with actual answers/modes and original criteria. All full-goal requirements remain open.', goal_complete=False), f, indent=2)
runner = (p / 'run-source300-validation.py').read_text().replace('source300', 'source301').replace('source297', 'source300')
runner = runner.replace('native-bytecode-entry-formatted/emaxx', 'native-bytecode-inline/emaxx').replace('native-funcall-dispatch/emaxx', 'native-bytecode-entry-formatted/emaxx')
ast.parse(runner)
with (p / 'run-source301-validation.py').open('x') as f:
    f.write(runner)
generated = (p / 'compare-source300-generated-loaded.py').read_text().replace('source300', 'source301').replace('native-bytecode-entry-formatted/emaxx', 'native-bytecode-inline/emaxx')
ast.parse(generated)
with (p / 'compare-source301-generated-loaded.py').open('x') as f:
    f.write(generated)
print('Prepared source301: only helper inlining differs from300; no tests/fixtures changed')
