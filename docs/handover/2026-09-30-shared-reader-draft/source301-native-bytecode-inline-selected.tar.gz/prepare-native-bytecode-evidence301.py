from pathlib import Path
import ast, re

p = Path(__file__).parent.resolve()

def write(name, source):
    ast.parse(source)
    with (p / name).open('x') as f:
        f.write(source)

source = (p / 'replay-native-bytecode300.py').read_text()
old = next(n.value for n in ast.walk(ast.parse(source)) if isinstance(n, ast.Constant)
           and isinstance(n.value, str) and n.value.startswith('Source300 shares'))
source = source.replace(repr(old), repr('Source301 changes only the shared native helper inline attribute from held300. All532 input bytes/modes reconstruct from applied4af440a9 and main. Original tests/fixtures/selectors/timeouts/criteria remain. Selected validation and timing are separate.'))
write('replay-native-bytecode301.py', source)
source = (p / 'audit-native-bytecode-selected.py').read_text().replace('source300', 'source301').replace('source297', 'source300')
source = source.replace('native-funcall-dispatch/emaxx', 'native-bytecode-entry-formatted/emaxx')
anchor = "state = read(tag + '-validation-result.json')"
check = '''previous_core = (p.parent / 'recovered-2026-10-05/native-bytecode-entry-formatted/emaxx/src/lisp/eval/core.rs').read_text()
assert previous_core.count('    #[inline]\\n    fn funcall_native_subr(') == 1
assert (c / 'src/lisp/eval/core.rs').read_text() == previous_core.replace('    #[inline]\\n    fn funcall_native_subr(', '    #[inline(always)]\\n    fn funcall_native_subr(')
'''
assert source.count(anchor) == 1
source = source.replace(anchor, check + anchor)
old = next(n.value for n in ast.walk(ast.parse(source)) if isinstance(n, ast.Constant)
           and isinstance(n.value, str) and n.value.startswith('Source300 reuses'))
source = source.replace(repr(old), repr('Source301 differs from held300 only in the shared helper inline attribute. All532 inputs/modes, fresh builds, unchanged complete inventories and all tests/fixtures verify.327 selected passes per profile and47 actual GNU comparisons; broad probe retains60 original width failures. No source301 performance result is implied by selected correctness. Full-platform/ownership/accounting/final acceptance remain open.'))
write('audit-native-bytecode-inline-selected.py', source)
source = (p / 'finish-native-bytecode-selected-closed.py').read_text().replace('source300', 'source301').replace('source297', 'source300')
source = source.replace('native-bytecode-entry-formatted', 'native-bytecode-inline')
source = source.replace('native-bytecode-selection', 'native-bytecode-inlining-selection').replace('native-bytecode selected audit', 'native-bytecode-inlining selected audit')
source = source.replace('audit-native-bytecode-selected.py', 'audit-native-bytecode-inline-selected.py')
write('finish-native-bytecode-inlining-selected-closed.py', source)

mapping = {'source296':'source297', 'source298':'source300', 'source297':'source301'}
translate = lambda s: re.sub(r'source(?:296|298|297)', lambda m:mapping[m[0]], s)
source = translate((p / 'measure-native-dispatch.py').read_text())
paths = {'native-fixed-funcall/emaxx':'native-funcall-dispatch/emaxx',
         'native-empty-arguments/emaxx':'native-bytecode-entry-formatted/emaxx',
         'native-funcall-dispatch/emaxx':'native-bytecode-inline/emaxx'}
source = re.sub('|'.join(re.escape(x) for x in paths), lambda m:paths[m[0]], source)
source = source.replace('native-dispatch', 'native-bytecode-inlining')
source = source.replace("for tag in ('source300','source301'):", "for tag in ('source301',):")
old = next(n.value for n in ast.walk(ast.parse(source)) if isinstance(n, ast.Constant)
           and isinstance(n.value, str) and n.value.startswith('Three rotated repetitions'))
source = source.replace(repr(old), repr('Three rotated unchanged full16 pilots,288 actual processes, for applied297, held300 with compiler-chosen helper inlining, and inline-only301. The original192-process300 comparison remains preserved. No build/test/profile work overlaps timing; every sample and unfavorable result remains. This diagnostic does not certify final nine-round acceptance.'))
write('measure-native-bytecode-inlining.py', source)
source = translate((p / 'audit-native-dispatch-performance.py').read_text()).replace('native-dispatch', 'native-bytecode-inlining')
source = source.replace("len(state['results'])==11", "len(state['results'])==10")
source = source.replace('optimized_over_corrected', 'inline_over_default').replace('corrected_over_original', 'default_over_baseline').replace('optimized_over_original', 'inline_over_baseline')
old = next(n.value for n in ast.walk(ast.parse(source)) if isinstance(n, ast.Constant)
           and isinstance(n.value, str) and n.value.startswith('Three rotated repetitions'))
source = source.replace(repr(old), repr('Three rotated unchanged full16 pilots for297/300/301 verify all288 actual results/modes. Original300 timing and all unfavorable samples remain. Compare default/forced helper inlining without changing tests, selectors, workload sizes, modes, GC or tolerance. Counters remain unavailable; this is not final calibrated nine-round every-case acceptance.'))
write('audit-native-bytecode-inlining-performance.py', source)
source = (p / 'finish-native-bytecode-performance-closed.py').read_text().replace('native-bytecode', 'native-bytecode-inlining').replace('source300 selected audit', 'source301 selected audit')
write('finish-native-bytecode-inlining-performance-closed.py', source)
print('Prepared source301 selected validation and three-way timing helpers')
