from pathlib import Path
import hashlib, json, os, re, subprocess, sys, time

p = Path(__file__).parent.resolve()
tag, directory = sys.argv[1:]
c = Path(directory)
read = lambda n: json.loads((p / n).read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
manifest = read(tag + '-manifest.json')
fixture = c / 'tests/fixtures/buffer-lf-line-index.el'
original = p.parent / 'recovered-2026-10-05/buffer-line-index/emaxx/tests/fixtures/buffer-lf-line-index.el'
assert fixture.read_bytes() == original.read_bytes()
form = '(prin1 ' + fixture.read_text() + ')'

def parse(text):
    tokens = iter(re.findall(r'\(|\)|[^\s()]+', text))
    def one(token):
        if token != '(':
            return int(token) if re.fullmatch('-?[0-9]+', token) else token
        result = []
        for token in tokens:
            if token == ')':
                return result
            result.append(one(token))
        raise ValueError('truncated result')
    result = one(next(tokens))
    assert next(tokens, None) is None
    return result

outputs = {}; outcomes = {}
for editor, binary in dict(gnu=p.parent / 'rebuilt-2026-10-01/emacs/src/emacs', emaxx=c / 'target/vm-dispatch-validation/release/emaxx').items():
    stem = p / (tag + '-line-broad-' + editor)
    command = [str(binary), '-Q', '--batch', '--eval', form]
    inputs = {str(f): sha(f) for f in [fixture, binary, binary.with_suffix('.pdmp'), Path(__file__)]}
    with stem.with_suffix('.command.json').open('x') as f:
        json.dump(dict(command=command, inputs=inputs, cwd=str(p), environment_overrides=dict(LANG='C', LC_ALL='C', EMAXX_GC_VERIFY='1'), timeout_seconds=120), f, indent=2)
    start = time.monotonic()
    r = subprocess.run(command, cwd=p, env=dict(os.environ, LANG='C', LC_ALL='C', EMAXX_GC_VERIFY='1'), stdin=subprocess.DEVNULL, capture_output=True, timeout=120)
    with stem.with_suffix('.stdout').open('xb') as f: f.write(r.stdout)
    with stem.with_suffix('.stderr').open('xb') as f: f.write(r.stderr)
    outcome = dict(exit_code=r.returncode, elapsed_seconds=time.monotonic()-start, stdout_sha256=hashlib.sha256(r.stdout).hexdigest(), stderr_sha256=hashlib.sha256(r.stderr).hexdigest(), inputs_unchanged=all(sha(Path(n))==h for n,h in inputs.items()), source_unchanged=all(sha(c/n)==h for n,h in manifest.items()))
    with stem.with_suffix('.result.json').open('x') as f: json.dump(outcome, f, indent=2)
    assert outcome['inputs_unchanged'] and outcome['source_unchanged'] and r.returncode == 0 and not r.stderr
    outputs[editor] = r.stdout; outcomes[editor] = outcome
assert outputs['gnu'] == (p/'source290-line-index-baseline-gnu.stdout').read_bytes()
gnu, emaxx = (parse(outputs[e].decode()) for e in ('gnu', 'emaxx'))
prior = parse((p/'source290-line-index-baseline-emaxx.stdout').read_text())
assert gnu[0] == emaxx[0] == prior[0] == 338
differences = []
for i, (a,b,old) in enumerate(zip(gnu[1], emaxx[1], prior[1])):
    assert len(a) == len(b) == len(old) == 13
    fields = [k for k,(x,y) in enumerate(zip(a,b)) if x != y]
    # Diagnose retained failures; do not rewrite outputs or label them passes.
    assert all(k == 10 for k in fields), (i,a,b)
    assert b[10] == old[10], (i,b,old)
    if fields: differences.append(dict(row=i, gnu=a, emaxx=b, fields=fields))
assert len(differences) == 60 and outputs['gnu'] != outputs['emaxx']
record = dict(status='failed: 60 existing display-column differences remain; all line/motion fields match', exact_match=False, rows=338, different_rows=60, outcomes=outcomes, differences=differences, qualification='Original broad probe and GNU output unchanged. Line counts are repaired. Every display-column result remains byte-for-value equal to source290, whose column_after counts visible non-tab characters as one. This diagnostic remains failed; dedicated LF motion validation does not certify display widths or full correctness.', goal_complete=False)
with (p / (tag+'-line-broad-diagnosis.json')).open('x') as f: json.dump(record, f, indent=2)
print(json.dumps({k:v for k,v in record.items() if k not in ('differences','outcomes')}))
