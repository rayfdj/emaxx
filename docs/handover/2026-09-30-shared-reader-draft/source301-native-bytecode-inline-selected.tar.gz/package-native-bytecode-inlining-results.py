from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
out = p.parents[2] / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected', '.h'}
selected = read('source301-selected-audit.json')
performance = read('native-bytecode-inlining-performance-audit.json')
decision = read('source301-application-decision.json')
assert selected['status'] == 'passed' and selected['source_inputs_verified'] == 532
assert selected['ordinary_comparisons'] == 47
assert all(x['passed'] == 327 and x['failed'] == x['ignored'] == 0 for x in selected['profiles'].values())
assert performance['status'] == 'all 288 processes and actual results/modes verified'
assert read('native-bytecode-inlining-performance-sequence-closed-result.json')['status'] == 'timing audited; source decision pending'
for audit in [selected, performance]:
    assert all(sha(Path(n).read_bytes()) == h for n, h in audit['evidence_files'].items())
helpers = ['prepare-native-bytecode301.py', 'prepare-native-bytecode-evidence301.py',
           'run-source301-validation.py', 'replay-native-bytecode301.py',
           'audit-native-bytecode-inline-selected.py', 'compare-source301-generated-loaded.py',
           'compare-source300-generated-loaded.py', 'compare-source292-generated-loaded.py',
           'compare-vm-dispatch-fixtures.py', 'compare-buffer-line-broad-probe.py',
           'native_fixed_validation_support.py', 'verify-existing-portable-draft.py',
           'finish-native-bytecode-inlining-selected-closed.py',
           'source300-manifest.json', 'source300-selected-audit.json',
           'source300-gate-inventory.log', 'source300-release-inventory.log',
           'printer-varied-v3-293638f0.el', 'printer-varied-v3-gnu.stdout',
           'package-source196-failure-and197-results.py', Path(__file__).name]
files = {f.name: f for f in p.iterdir() if f.is_file() and f.suffix in allowed
         and f.name.startswith(('source301-', 'native-bytecode-inlining-selection-'))}
files.update({name: p / name for name in helpers})
package('source301-native-bytecode-inline-selected', files, dict(
    status='closed fresh source301 selected validation',
    audit=dict(path='source301-selected-audit.json', sha256=sha((p / 'source301-selected-audit.json').read_bytes())),
    profiles={k: {f: v[f] for f in ['passed', 'failed', 'ignored']} for k, v in selected['profiles'].items()},
    source_inputs_verified=532, ordinary_comparisons=47,
    qualification='Source301 changes only the helper inline attribute from300. All original tests/fixtures remain.532 byte/mode replays, fresh builds and327 selected passes/profile plus47 actual GNU comparisons verify. The full broad probe retains60 original width failures. Earlier299/300 failures/measurements remain in their published archives. Full-goal requirements remain open; complete raw evidence is inside this archive.', goal_complete=False))
files = {}
for tag in ['source297', 'source300', 'source301']:
    for directory in sorted(p.glob(tag + '-native-bytecode-inlining-pilot-*')) + [p / (tag + '-core-native')]:
        for f in directory.rglob('*'):
            if f.is_file() and f.suffix in allowed:
                files[str(f.relative_to(p))] = f
for f in p.iterdir():
    if f.is_file() and f.suffix in allowed and f.name.startswith('native-bytecode-inlining-performance-'):
        files[f.name] = f
for name in ['measure-native-bytecode-inlining.py', 'audit-native-bytecode-inlining-performance.py',
             'finish-native-bytecode-inlining-performance-closed.py', 'source300-application-decision.json',
             'source301-application-decision.json', 'package-source196-failure-and197-results.py', Path(__file__).name]:
    files[name] = p / name
package('source301-native-bytecode-inline-performance', files, dict(
    status='all288 actual process answers and execution modes verified',
    audit=dict(path='native-bytecode-inlining-performance-audit.json', sha256=sha((p / 'native-bytecode-inlining-performance-audit.json').read_bytes())),
    application_decision=decision,
    qualification='Applied297, default-inlining300 and inline301 each run three rotated unchanged full16 pilots. The original192-process300 comparison is retained separately and is not overwritten. All samples/startup/total/RSS/GC and missing-counter errors remain. Builds/tests/profiles are separate. This small diagnostic does not certify calibrated nine-round/every-case3% acceptance or full-goal completion.', goal_complete=False))
