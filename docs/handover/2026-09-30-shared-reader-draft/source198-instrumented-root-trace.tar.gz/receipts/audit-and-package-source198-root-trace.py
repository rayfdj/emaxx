from pathlib import Path
import ast
import gzip
import hashlib
import io
import json
import re
import subprocess
import sys
import tarfile
import tempfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda file: json.loads(file.read_text())
directory, = (p / 'linux-source198-root-trace-artifacts').rglob('rust-root-trace')
summary = read(directory / 'summary.json')
replay = read(directory / 'replay/summary.json')
state = read(p / 'source198-linux-root-trace-final-state.json')
head = '7e45db47438a39e97658bddaceba903e0e41c186'
assert state['headSha'] == head and state['status'] == 'completed' and state['conclusion'] == 'success'
assert summary['base_commit'] == head and summary['exit_code'] == 0 and summary['instrumented_source_unchanged']
assert summary['instrumentation_sha256'] == sha((root / 'tools/diagnostics/weak-root-trace.patch').read_bytes())
before = read(directory / 'source-before.json')
after = read(directory / 'source-instrumented.json')
manifest = read(p / 'source198-manifest.json')
assert len(before) == len(after) == 398 and set(before) == set(after)
assert all(manifest[name] == digest for name, digest in before.items())
changed = sorted(name for name in before if before[name] != after[name])
assert changed == ['src/lisp/alloc.rs', 'src/lisp/eval.rs']
with tempfile.TemporaryDirectory(prefix='emaxx-root-trace-replay-') as temp:
    checkout = Path(temp)
    for name in changed:
        data = (root / name).read_bytes()
        assert sha(data) == before[name]
        file = checkout / name
        file.parent.mkdir(parents=True, exist_ok=True)
        file.write_bytes(data)
    subprocess.run(['git', 'apply', '--check', str(directory / 'instrumentation.patch')], cwd=checkout, check=True)
    subprocess.run(['git', 'apply', str(directory / 'instrumentation.patch')], cwd=checkout, check=True)
    assert all(sha((checkout / name).read_bytes()) == after[name] for name in changed)

name = 'lisp::primitives::tests::suspended_bytecode_retains_operand_and_unwind_roots'
assert replay['git'] == replay['source_after'] == {'head': head, 'dirty': True}
assert replay['status'] == 'selected diagnostic passed' and replay['exit_code'] == 0 and not replay['timed_out']
assert replay['expected_tests'] == replay['executed_tests'] == [name]
assert replay['ignored_tests'] == [] and replay['fixture_images_before'] == []
assert replay['result']['passed'] == 1 and replay['result']['failed'] == replay['result']['ignored'] == 0
binary = directory / 'replay' / replay['test_binary']['artifact']
assert sha(binary.read_bytes()) == replay['test_binary']['sha256']
assert replay['test_binary']['sha256'] != '89058fe557e1d3138199c8c6d905c9ca502b03af38b218a6485c723254d19a65'
for entry in replay['fixture_images']:
    file = directory / 'replay' / entry['artifact']
    assert sha(file.read_bytes()) == entry['sha256'] and file.stat().st_size == entry['bytes']
sys.path.insert(0, str(root / 'tools'))
import grouped_gate
inventory = grouped_gate.parse_inventory((directory / 'replay/full-inventory.log').read_text())
assert len(inventory) == replay['total_tests'] == 2962
assert grouped_gate.parse_inventory((directory / 'replay/selected-inventory.log').read_text()) == [name]
assert (directory / 'replay/ignored-inventory.log').read_text().strip() == '0 tests, 0 benchmarks'
namespace = {'re': re}
tree = ast.parse((p / 'audit-shared-reader196-fresh-selected.py').read_text())
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'audit_log')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<raw-log-audit>', 'exec'), namespace)
namespace['audit_log']([name], (directory / 'replay/replay.log').read_text(), 1, 0)

traces = []
root_files = []
for file in sorted((directory / 'roots').glob('*.log')):
    lines = file.read_text().splitlines()
    assert lines and all(line.startswith(('GC_WEAK ', 'GC_EDGE ')) for line in lines)
    root_files.append({'path': str(file.relative_to(directory)), 'lines': len(lines), 'sha256': sha(file.read_bytes())})
    for i, line in enumerate(lines):
        if 'head=Some("runtime-key")' not in line:
            continue
        match = re.fullmatch(r'GC_WEAK epoch=(\d+) table=([0-9a-f]+) key=([0-9a-f]+) live=(true|false) head=Some\("runtime-key"\)', line)
        assert match
        end = i + 1
        while end < len(lines) and lines[end].startswith('GC_EDGE '):
            end += 1
        traces.append({'epoch': int(match[1]), 'table': match[2], 'key': match[3],
                       'live': match[4] == 'true', 'root_edges': lines[i + 1:end]})
assert len(traces) == 4 and [item['live'] for item in traces] == [True, False, True, False]
assert traces[0]['key'] == traces[1]['key'] and traces[2]['key'] == traces[3]['key']
assert traces[0]['key'] != traces[2]['key']
assert all('parked coroutine stack' in '\n'.join(traces[index]['root_edges']) for index in [0, 2])
audit = {'status': 'instrumented selected pass', 'raw_passed': 1, 'raw_failed': 0,
         'source_inputs_verified': len(before), 'instrumented_files': changed,
         'instrumentation_patch_replayed': True,
         'binary_sha256': replay['test_binary']['sha256'],
         'root_files': root_files, 'runtime_key_trace': traces,
         'qualification': 'Both original live-key and dead-key assertions pass in the instrumented executable; child trace records parked coroutine roots followed by reclamation. The executable and fresh startup image differ from the original failed full run. This establishes no retaining root in the failed ordinary executable and does not clear that failure.'}
with (p / 'source198-linux-root-trace-audit.json').open('x') as stream:
    json.dump(audit, stream, indent=2)
    stream.write('\n')

tree = ast.parse((p / 'package-source196-failure-and197-results.py').read_text())
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-package>', 'exec'), globals())
files = {str(file.relative_to(directory)): file for file in directory.rglob('*')
         if file.is_file() and file.suffix in {'.json', '.log', '.patch'}}
for name in [Path(__file__).name, 'audit-shared-reader196-fresh-selected.py',
             'package-source196-failure-and197-results.py', 'source198-linux-root-trace-audit.json',
             'source198-linux-root-trace-final-state.json', 'source198-linux-root-trace-download.json',
             'audit-and-package-source198-root-trace-original.py',
             'source198-root-trace-audit-invocation-failure.json']:
    files['receipts/' + name] = p / name
package('source198-instrumented-root-trace', files, audit)
