from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected', '.h'}
def collect(patterns, directories=()):
    files = {str(f.relative_to(p)): f for pattern in patterns for f in p.glob(pattern)
             if f.is_file() and f.suffix in allowed}
    for directory in directories:
        files.update({str(f.relative_to(p)): f for f in (p / directory).rglob('*')
                      if f.is_file() and (f.suffix in allowed or f.name == 'Makefile')})
    files[Path(__file__).name] = Path(__file__)
    return files

release = read('source246-release-audit.json')
linux = read('source246-linux-rust-failure-audit.json')
assert [row['passed'] for row in release['groups']] == [168, 951]
assert linux['library_passed'] == 2260 and linux['library_failed'] == 2
files = collect(['source246-release-*', 'source246-manifest.json', 'source246-linux-rust-*',
    'source246-linux-gnu-census-*', 'source246-gate-controls-command.json',
    'source246-gate-broad-command.json', 'source246-gate-inventory.txt',
    'source246-check*', 'source246-fmt*', 'source246-clippy*', 'source246-diff*',
    'source246-darwin-oracle-candidate-search.json', 'source244-eglot-timeout-trace-audit.json',
    'audit-source246-release.py', 'audit-source246-focused.py', 'audit-source246-linux-rust-failure.py',
    'audit-source246-macos-names.py', 'verify-source246-macos-rust.py',
    'download-source246-linux-rust-failure.py', 'audit-source238-release.py'],
    ['source246-release-focused-retained-inputs', 'source246-release-retained-inputs',
     'source246-linux-rust-artifacts'])
package('source246-release-and-linux-rust-failure', files, dict(release=release, linux_rust=linux,
    gnu_diagnosis_launch=read('source246-linux-gnu-census-launch.json'),
    qualification='Closed source246 release and full Linux Rust evidence. All 168 focused and 951 affected release controls pass, with two existing ignores. Full Linux retains 2260 passes and two unchanged GNU reference failures, leaving 745 library tests and both Cargo stages unexecuted. The exact configured GNU binary/dump/configuration/Makefile are captured and verified unchanged; binary and dump match the earlier passing source243 GNU diagnosis. The new bounded diagnosis is launched, not completed. Full macOS/terminal/frozen remain active. Source244 Eglot trace retains an actual completion reply in a process-buffer dump despite the timed-out request; its connection/timing and root cause remain unresolved.'))

focused = read('source247-gate-focused-audit.json')
assert focused['passed'] == 169 and focused['inputs_verified'] == 470
files = collect(['coding-candidate-symbol-properties.el', 'overriding-property-identity.el',
    'source246-coding-symbol-properties-*', 'source246-overriding-property-identity-*',
    'probe-source246-coding-symbol-properties.py', 'probe-source246-overriding-property-identity.py',
    'source247-worktree-preparation.json', 'source247-manifest.json', 'source247-*.patch',
    'source247-freeze.json', 'source247-patch-replay-audit.json', 'source247-validation-launch.json',
    'source247-check*', 'source247-fmt*', 'source247-clippy*', 'source247-diff*', 'source247-gate-*',
    '*source247*.py', 'source248-worktree-preparation.json', 'source248-manifest.json',
    'source248-*.patch', 'source248-freeze.json', 'source248-patch-replay-audit.json',
    'source248-validation-queue-launch.json', '*source248*.py', 'compare-source230-fixtures.py',
    'audit-source238-release.py'], ['source247-gate-focused-retained-inputs'])
# The affected group and both validation supervisors are still active.
for name in list(files):
    if name.startswith('source247-gate-broad'):
        del files[name]
assert not any(name in files for name in ['source247-validation-driver.log',
    'source248-validation-queue-state.json', 'source248-validation-queue-driver.log',
    'source248-validation-driver.log'])
package('source248-property-drafts', files, dict(source247_focused=focused,
    source247_patch=read('source247-patch-replay-audit.json'),
    source248_patch=read('source248-patch-replay-audit.json'),
    source248_queue=read('source248-validation-queue-launch.json'),
    qualification='Both same-input source246/GNU negative probes are retained. Source247 shares actual Fget for safety translations, covering nil/t and dynamic property overrides; strict checks and 169 focused passes/two existing ignores are audited, but its complete selected pipeline is still running. Source248 adds the GNU first-match rule when an overriding property has nil before a duplicate; 472 inputs/modes replay exactly, but no source248 runtime result exists. Its validation waits for the real source247 supervisor to exit successfully and for selected evidence auditing before cloning that completed cache. Root runtime remains source246; neither draft is applied there. Active logs are excluded. No complete coding/platform/performance claim.'))
