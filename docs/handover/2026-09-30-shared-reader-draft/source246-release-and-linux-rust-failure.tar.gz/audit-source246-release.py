from pathlib import Path
import ast, hashlib, json, re, shutil
p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/coding-translation/emaxx'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'audit-source238-release.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'audit_log')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<raw-verdict-auditor>', 'exec'))
manifest = read('source246-manifest.json')
assert len(manifest) == 468 and all(sha(root / name) == digest for name, digest in manifest.items())
stages = read('source246-release-and-ordinary-result.json')
assert len(stages) == 3 and all(stage['exit_code'] == 0 for stage in stages)
inventories = {}
for profile, total in [('gate', 2999), ('release', 2998)]:
    names = [line[:-6] for line in (p / ('source246-' + profile + '-inventory.txt')).read_text().splitlines() if line.endswith(': test')]
    assert len(names) == len(set(names)) == total
    inventories[profile] = names
assert set(inventories['gate']) - set(inventories['release']) == {'file_system::posix::tests::posix_file_drop_rejects_an_externally_closed_descriptor'}
assert not set(inventories['release']) - set(inventories['gate'])
binary = p / 'source246-release-libtest'
groups = []
for group, count, ignored in [('controls', 170, ['tty::tty_differential_end_to_end', 'tty::tty_smoke_end_to_end']), ('broad', 951, [])]:
    command, result = read('source246-release-' + group + '-command.json'), read('source246-release-' + group + '-result.json')
    names = command['selected_inventory']
    assert len(names) == len(set(names)) == count and names == read('source246-gate-' + group + '-command.json')['selected_inventory']
    assert command['binary_sha256'] == sha(binary)
    assert result['exit_code'] == 0 and result['source_unchanged']
    assert command['environment_override']['LANG'] == command['environment_override']['LC_ALL'] == 'C'
    assert command['command'][1:] == names + ['--exact', '--nocapture', '--test-threads=1']
    audit_log(names, (p / ('source246-release-' + group + '.log')).read_text(), ignored)
    groups.append(dict(group=group, passed=count-len(ignored), failed=0, ignored=ignored))
build = read('source246-release-build-result.json')
assert build['exit_code'] == 0 and build['source_unchanged']
raw = (p / 'source246-release-build.log').read_text()
assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
for line in raw.splitlines():
    try:
        row = json.loads(line)
    except json.JSONDecodeError:
        continue
    assert row.get('message', {}).get('level') not in ['warning', 'error']
images = list((p / 'fixture-images-source246').glob('loadup-' + sha(binary)[:8] + '-*.pdmp'))
assert len(images) == 1
retained = p / 'source246-release-retained-inputs'
retained.mkdir()
files = []
for source in [binary, *images]:
    target = retained / source.name
    digest = sha(source)
    shutil.copy2(source, target)
    assert sha(target) == sha(source) == digest
    files.append(dict(original=str(source), retained=str(target), sha256=digest, bytes=target.stat().st_size))
record = dict(status='all focused and affected release controls pass', inputs_verified=468, groups=groups,
              retained_files=files, goal_complete=False,
              qualification='168 focused release passes with two pre-existing ignores, plus 951 affected-module passes. Raw inventories, names, verdicts, binary and retained image identities are verified. The single existing debug-only file-descriptor ownership control accounts for the gate/release inventory difference. No other inventory difference or new exclusion is allowed. Complete macOS/Linux/frozen/terminal results and the performance goal remain separate.')
with (p / 'source246-release-audit.json').open('x') as f:
    json.dump(record, f, indent=2)
print(json.dumps(dict(status=record['status'], groups=groups), indent=2))
