from pathlib import Path
import ast, hashlib, json, re

p = Path(__file__).parent.resolve()
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda f: json.loads(f.read_text())
commit = '2680b9575527e84dad1a73fc6585baf3e3a09812'
failed_name = 'anti_cheat::gate_tests::native_comp_fast_paths_are_audited_against_gnu_c'
message = 'native C fast paths changed without updating the exact-contract or explicitly-approved-deviation inventory'

def missing_entries(raw):
    assert message in raw
    left = [ast.literal_eval(s) for s in re.findall(r'^  left: (\{.*\})$', raw, re.M)]
    right = [ast.literal_eval(s) for s in re.findall(r'^ right: (\{.*\})$', raw, re.M)]
    assert left and len(left) == len(right)
    assert all(a - b == {'+', '-'} and not b - a for a, b in zip(left, right))
    return dict(actual=sorted(left[0]), declared=sorted(right[0]), missing=['+', '-'])

def oracle(directory, platform):
    m = read(directory / 'manifest.json')
    v = read(directory / 'verification.json')
    assert m['status'] == 'captured' and m['source_tracked_changes'] == []
    assert m['source_commit'] == '636f166cfc86aa90d63f592fd99f3fdd9ef95ebd'
    assert v['status'] == 'unchanged' and v['files_verified'] == 4
    assert v['capture_manifest_sha256'] == sha(directory / 'manifest.json')
    assert [x['artifact'] for x in m['files']] == ['emacs', 'emacs.pdmp', 'config.h', 'Makefile']
    for entry in m['files']:
        f = directory / entry['artifact']
        assert sha(f) == entry['sha256'] and f.stat().st_size == entry['bytes']
    expected = {
        'macos': ['29cfb20de2474c040d439d4bdf69b4dfcfb7921464f1f686b6e1f6bcca7c74e5', 'ce5651aaa28de23a59f61aa1200bf8b6434bf2dc72ef0ac8f6f8abe3406eaa67'],
        'linux': ['5e1721732427d69d8af63211f1e3833ec21e40f97f4b7f6cd4cb224b72cebfcf', 'bf4974228f3b3ea4374cec75a38eeb2bd0e7dd944da5bec4e6ad0387092502ae'],
    }
    assert [e['sha256'] for e in m['files'][:2]] == expected[platform]
    return dict(manifest=m, verification=v)

def rust(directory, count):
    s = read(directory / 'summary.json')
    assert s['status'] == 'failed' and s['scope'] == 'full'
    assert s['git'] == dict(head=commit, dirty=False)
    assert s['runs'] == s['cargo_stages'] == []
    inventory = [s[:-6] for s in (directory / 'inventory.txt').read_text().splitlines() if s.endswith(': test')]
    assert len(inventory) == len(set(inventory)) == count == s['inventory']['scheduled_tests']
    assert hashlib.sha256(('\n'.join(inventory) + '\n').encode()).hexdigest() == s['inventory']['sha256']
    ignored = {'tty::tty_differential_end_to_end', 'tty::tty_smoke_end_to_end'}
    assert set(s['inventory']['ignored_tests']) == ignored
    verdicts, groups = {}, []
    for group, expected in s['inventory']['groups'].items():
        raw = (directory / ('repeat-01-' + group + '.log')).read_text()
        starts = list(re.finditer(r'^test (\S+) \.\.\. ', raw, re.M))
        assert len(starts) == expected
        found = []
        for index, match in enumerate(starts):
            end = starts[index + 1].start() if index + 1 < len(starts) else raw.rindex('test result:')
            block = raw[match.end():end].split('\n\nfailures:')[0].strip()
            if match[1] in ignored:
                assert block.startswith('ignored')
                verdict = 'ignored'
            else:
                final = re.search(r'(?:^|\s)(ok|FAILED)$', block)
                assert final, (match[1], block)
                verdict = final[1]
            assert match[1] not in verdicts and match[1] in inventory
            verdicts[match[1]] = verdict
            found.append(verdict)
        passed, failed, ignore = (found.count(x) for x in ['ok', 'FAILED', 'ignored'])
        summaries = re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', raw, re.M)
        assert summaries == [('FAILED' if failed else 'ok', str(passed), str(failed), str(ignore))]
        result = read(directory / ('repeat-01-' + group + '.json'))
        assert result['exit_code'] == (101 if failed else 0)
        groups.append(dict(group=group, passed=passed, failed=failed, ignored=ignore))
    assert set(verdicts) == set(inventory)
    assert [n for n,v in verdicts.items() if v == 'FAILED'] == [failed_name]
    assert sum(v == 'ok' for v in verdicts.values()) == count - 3
    retained = directory / 'retained-inputs'
    m = read(retained / 'manifest.json')
    assert m['status'] == 'retained' and m['gate_status'] == 'failed'
    assert m['gate_summary_sha256'] == sha(directory / 'summary.json')
    for entry in m['files']:
        f = retained / entry['artifact']
        assert f.stat().st_size == entry['bytes'] and sha(f) == entry['sha256']
    assert sha(retained / 'libtest') == s['test_binary']['sha256']
    return dict(status='failed', library_passed=count-3, library_failed=1, library_ignored=2,
                groups=groups, raw_verdicts=verdicts, failed_tests=[failed_name],
                inventory_mismatch=missing_entries((directory / 'repeat-01-lightweight.log').read_text()),
                unstarted_library_tests=[], unstarted_cargo_stages=['bins', 'integration'],
                retained_inputs=m, binary_sha256=s['test_binary']['sha256'])

result = dict(status='three complete source302 validation attempts failed the unchanged exact-contract audit',
              source_commit=commit, goal_complete=False, platforms={})
mac = rust(p / 'full-gate-source302', 3040)
mac['oracle'] = oracle(p / 'source302-full-retained-gnu', 'macos')
mac['frozen'] = dict(status='failed before cases', files_executed=0, inventory_mismatch=missing_entries((p / 'source302-full-frozen.log').read_text()))
mac['tty'] = dict(status='unstarted', scenarios_executed=0)
queue = read(p / 'source302-full-queue-result.json')
assert queue['status'] == 'queue or validation setup failed' and queue['error'] == 'AssertionError()'
assert [(r['stage'], r['exit_code']) for r in queue['results']] == [('selected-audit',0),('cache-clone',0),('fresh-gate-crate',0),('oracle-capture',0),('rust',1),('rust-retention',0),('runner-build',0),('frozen',2)]
assert all(not r['timed_out'] and r['source_unchanged'] and r['fixed_inputs_unchanged'] for r in queue['results'])
assert not (p / 'source302-full-tty-result.json').exists()
mac['queue'] = queue
result['platforms']['macos'] = mac
for kind, run in [('rust',37295657550), ('frozen',37295678456)]:
    directory = p / ('source302-linux-' + kind + '-failure-artifacts') / ('ordinary-linux-' + commit)
    terminal = read(p / ('source302-linux-' + kind + '-terminal.json'))
    assert terminal['status'] == 'completed' and terminal['conclusion'] == 'failure' and terminal['headSha'] == commit
    row = rust(directory / 'rust', 3048) if kind == 'rust' else dict(status='failed before cases', files_executed=0, inventory_mismatch=missing_entries((directory / 'frozen.log').read_text()))
    if kind == 'frozen':
        assert not (directory / 'frozen').exists()
    row.update(run_id=run, terminal=terminal, oracle=oracle(directory / 'oracle-inputs', 'linux'))
    result['platforms']['linux_' + kind] = row
result['qualification'] = 'Linux Rust:3045 passes/one failure/two existing ignores; macOS Rust:3037 passes/one failure/two existing ignores. All scheduled library names ran; bins and integration stages did not. Both frozen attempts stopped before any file. TTY never started. The only observed Rust failure is missing + and - in the native exact-contract inventory. The checks and empty deviation policy remain intact in304, which adds GNU owners and a real ABI contract test. No full compatibility pass is claimed, and prior census/semantic failures remain independently preserved.'
files = {}
for directory in [p/'full-gate-source302', p/'source302-full-retained-gnu', p/'source302-linux-rust-failure-artifacts', p/'source302-linux-frozen-failure-artifacts']:
    files.update({str(f):sha(f) for f in directory.rglob('*') if f.is_file()})
for f in p.glob('source302-full-*'):
    if f.is_file(): files[str(f)] = sha(f)
for f in p.glob('source302-linux-*'):
    if f.is_file(): files[str(f)] = sha(f)
result['evidence_files'] = files
with (p / 'source302-full-failure-audit.json').open('x') as f:
    json.dump(result, f, indent=2)
print(json.dumps(dict(status=result['status'], macos_passed=3037, linux_passed=3045, frozen_files_executed=0, failed_test=failed_name)))
