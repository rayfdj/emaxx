from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
out = p.parents[2] / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected', '.h', '.apparmor'}
assert read('native-audit-performance-sequence-closed-result.json')['status'] == 'timing audited; source decision pending'
failure = read('source302-full-failure-audit.json')
assert all(sha(Path(n).read_bytes()) == h for n,h in failure['evidence_files'].items())
files = {str(f.relative_to(p)): f for name in ['full-gate-source302', 'source302-full-retained-gnu', 'source302-linux-rust-failure-artifacts', 'source302-linux-frozen-failure-artifacts']
         for f in (p / name).rglob('*') if f.is_file() and (f.suffix in allowed or f.name == 'Makefile')}
files.update({f.name:f for f in p.iterdir() if f.is_file() and f.suffix in allowed and f.name.startswith(('source302-full-', 'source302-linux-'))})
for name in ['audit-source302-full-failures.py', 'queue-source302-full-macos.py', 'setup-source302-full-macos.py', 'audit-source302-selected-for-full.py', 'source302-manifest.json', 'package-source196-failure-and197-results.py', Path(__file__).name]:
    files[name] = p / name
package('source302-full-validation-failures', files, dict(
    status=failure['status'], source_commit=failure['source_commit'],
    macos_rust=dict(passed=3037, failed=1, ignored=2), linux_rust=dict(passed=3045, failed=1, ignored=2),
    frozen_files_executed=0, tty_scenarios_executed=0,
    audit=dict(path='source302-full-failure-audit.json', sha256=sha((p / 'source302-full-failure-audit.json').read_bytes())),
    qualification=failure['qualification'], goal_complete=False))

selected = read('source303-selected-audit.json')
assert selected['status'] == 'passed' and selected['ordinary_comparisons'] == 49
assert all(r['passed'] == 482 and r['failed'] == r['ignored'] == 0 for r in selected['profiles'].values())
assert all(sha(Path(n).read_bytes()) == h for n,h in selected['evidence_files'].items())
assert selected['closed_broad_probe_failure']['different_rows'] == 0
stopped = read('buffer-columns-performance-sequence-closed-result.json')
assert stopped['status'] == 'sequence stopped' and stopped['steps'] == []
assert not (p / 'buffer-columns-performance-result.json').exists()
files = {f.name:f for f in p.iterdir() if f.is_file() and f.suffix in allowed and f.name.startswith(('source303-', 'buffer-columns-selection-', 'buffer-columns-performance-'))}
helpers = ['prepare-buffer-columns303.py', 'run-source303-validation.py', 'prepare-buffer-columns-evidence303.py', 'prepare-buffer-columns-evidence303-fixed.py', 'prepare-buffer-columns-performance303.py', 'replay-buffer-columns303.py', 'audit-buffer-columns-selected.py', 'finish-buffer-columns-selected-closed.py', 'measure-buffer-columns.py', 'audit-buffer-columns-performance.py', 'finish-buffer-columns-performance-closed.py', 'compare-source303-generated-loaded.py', 'compare-source302-generated-loaded.py', 'compare-vm-dispatch-fixtures.py', 'compare-buffer-line-broad-probe.py', 'native_fixed_validation_support.py', 'verify-existing-portable-arithmetic-draft.py', 'source302-manifest.json', 'source302-selected-audit.json', 'source302-gate-inventory.log', 'source302-release-inventory.log', 'source302-line-broad-diagnosis.json', 'source302-line-broad-gnu.stdout', 'source302-line-broad-emaxx.stdout', 'printer-varied-v3-293638f0.el', 'printer-varied-v3-gnu.stdout', 'package-source196-failure-and197-results.py', Path(__file__).name]
files.update({name:p/name for name in helpers})
package('source303-buffer-columns-selected', files, dict(
    status='selected validation passed; unapplied draft; timing queue stopped before measurement',
    source_inputs_verified=534, profiles={k:{n:r[n] for n in ['passed','failed','ignored']} for k,r in selected['profiles'].items()},
    ordinary_comparisons=49, closed_broad_probe_failure=selected['closed_broad_probe_failure'],
    audit=dict(path='source303-selected-audit.json',sha256=sha((p/'source303-selected-audit.json').read_bytes())),
    qualification='This isolated GNU width repair closes all60 recorded differences in the unchanged338-row probe. It inherits302 missing native audit declarations and was not applied. Its timing queue stopped on302 full-validation failure before any native preparation or measurement.304 carries the width repair with the exact-contract inventory repair; its results are separate. No original failure is erased.', goal_complete=False))
