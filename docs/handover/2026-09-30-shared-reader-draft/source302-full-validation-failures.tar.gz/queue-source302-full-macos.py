from pathlib import Path
import hashlib
import json
import os
import re
import runpy
import shutil
import subprocess
import sys
import time

p = Path(__file__).parent.resolve()
checkout = json.loads((p / 'source302-full-checkout.json').read_text())
root = Path(checkout['candidate'])
selected_root = p.parent / 'recovered-2026-10-05/native-binary-arithmetic/emaxx'
gnu = p.parent / 'rebuilt-2026-10-01/emacs'
manifest = json.loads((p / 'source302-manifest.json').read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
unchanged = lambda directory: all(sha(directory / name) == digest for name, digest in manifest.items())
selected_auditor = p / 'audit-source302-selected-for-full.py'
fixed_inputs = {str(path): sha(path) for path in [Path(__file__), selected_auditor,
               p / 'source302-manifest.json', p / 'source302-full-checkout.json',
               gnu / 'src/emacs', gnu / 'src/emacs.pdmp', gnu / 'src/config.h', gnu / 'src/Makefile']}
target = root / 'target/vm-dispatch-validation'
env = dict(CARGO_TARGET_DIR=str(target), CARGO_BUILD_JOBS='1', EMAXX_GC_VERIFY='1',
           LANG='C', LC_ALL='C', EMAXX_GNU_SOURCE_DIRECTORY=str(gnu),
           EMAXX_DUMP_SOURCE_DIRECTORY=str(gnu), EMACS_TEST_DIRECTORY=str(gnu / 'test'))
state = dict(status='starting full source302 validation',
             source_manifest='source302-manifest.json', candidate=str(root),
             candidate_commit=checkout['validation_commit'], fixed_inputs=fixed_inputs,
             goal_complete=False, results=[])


def save(name, data):
    with (p / ('source302-full-' + name + '.json')).open('x') as stream:
        json.dump(data, stream, indent=2)


def save_state():
    (p / 'source302-full-queue-state.json').write_text(json.dumps(state, indent=2) + '\n')


def verify_inputs():
    assert len(manifest) == 534 and unchanged(root) and unchanged(selected_root)
    assert all(sha(Path(name)) == digest for name, digest in fixed_inputs.items())
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == checkout['validation_commit']


def run(name, command, overrides=None, extra=None, timeout=None):
    verify_inputs()
    environment = env if overrides is None else overrides
    record = dict(command=command, working_directory=str(root), environment_override=environment,
                  source_manifest='source302-manifest.json', candidate_commit=checkout['validation_commit'],
                  timeout_seconds=timeout, **(extra or {}))
    save(name + '-command', record)
    state.update(status='running ' + name, current_command=command)
    save_state()
    started = time.monotonic()
    timed_out = False
    with (p / ('source302-full-' + name + '.log')).open('xb') as log:
        try:
            completed = subprocess.run(command, cwd=root, env=dict(os.environ, **environment),
                                       stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                                       timeout=timeout)
            code = completed.returncode
        except subprocess.TimeoutExpired:
            code, timed_out = None, True
    result = dict(stage=name, exit_code=code, timed_out=timed_out,
                  elapsed_seconds=time.monotonic() - started, source_unchanged=unchanged(root),
                  selected_source_unchanged=unchanged(selected_root),
                  fixed_inputs_unchanged=all(sha(Path(path)) == digest for path, digest in fixed_inputs.items()))
    save(name + '-result', result)
    state['results'].append(result)
    save_state()
    verify_inputs()
    print(json.dumps(result), flush=True)
    return result


save_state()
try:
    verify_inputs()
    assert json.loads((p / 'source302-selected-audit.json').read_text())['status'] == 'passed'
    assert run('selected-audit', [sys.executable, '-B', str(selected_auditor)], {})['exit_code'] == 0
    selected = json.loads((p / 'source302-full-selected-audit.json').read_text())
    assert selected['status'] == 'passed' and selected['ordinary_comparisons'] == 48
    assert all(row['passed'] == 328 and row['failed'] == 0 and row['ignored'] == 0 for row in selected['profiles'].values())
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True).strip()
    local = root / 'compat/oracle.local.json'
    assert not local.exists()
    with local.open('x') as stream:
        json.dump(dict(format_version=1, emacs_binary=str(gnu / 'src/emacs'), emacs_repo=str(gnu)), stream, indent=2)
    assert json.loads((root / 'compat/oracle.lock.json').read_text())['emacs_binary_sha256'] == sha(gnu / 'src/emacs')
    # The source cache is idle: its supervisor and every child have completed.
    # Clone only into a new destination, then force the target crate to rebuild.
    # Leave target/compat-subject absent so the unchanged harness owns its setup.
    assert not target.exists() and not (root / 'target/compat-subject').exists()
    target.parent.mkdir(exist_ok=True)
    assert run('cache-clone', ['/bin/cp', '-cR', str(selected_root / 'target/vm-dispatch-validation'), str(target)], {})['exit_code'] == 0
    assert run('fresh-gate-crate', ['cargo', 'clean', '--package', 'emaxx', '--profile', 'gate'])['exit_code'] == 0
    oracle = p / 'source302-full-retained-gnu'
    assert run('oracle-capture', [sys.executable, 'tools/retain_oracle_artifacts.py', 'capture', '--oracle-source', str(gnu), '--output', str(oracle)])['exit_code'] == 0
    artifact = p / 'full-gate-source302'
    run('rust', [sys.executable, 'tools/serial_grouped_gate.py', '--scope', 'full', '--artifact-root', str(artifact)])
    summary_path = artifact / 'summary.json'
    if summary_path.exists():
        summary = json.loads(summary_path.read_text())
        binary = summary.get('test_binary', {}).get('path')
        if binary and Path(binary).is_file():
            retained = p / 'source302-full-rust-libtest'
            assert not retained.exists()
            shutil.copy2(binary, retained)
            save('rust-binary', dict(original=binary, retained=str(retained), sha256=sha(retained)))
        assert run('rust-retention', [sys.executable, 'tools/retain_rust_gate_artifacts.py', '--summary', str(summary_path),
                   '--fixture-directory', str(root / 'target/grouped-gate/fixture-images')])['exit_code'] == 0
    # Full frozen and terminal validation are independent of Rust's verdict.
    # A failed Rust result is retained and never converted to a pass by later stages.
    assert run('runner-build', ['cargo', 'build', '--locked', '--profile', 'gate', '--bin', 'compat-harness'], timeout=1800)['exit_code'] == 0
    run('frozen', [str(target / 'gate/compat-harness'), 'frozen'],
        dict(LANG='C', LC_ALL='C', CARGO_BUILD_JOBS='1', RUST_MIN_STACK='134217728', RUST_TEST_THREADS='1'),
        timeout=21600)
    subject = root / 'target/compat-subject/gate/emaxx'
    assert subject.is_file() and subject.with_suffix('.pdmp').is_file()
    retained = p / 'source302-full-frozen-subject'
    retained.mkdir()
    subject_inputs = {}
    for path in [subject, subject.with_suffix('.pdmp')]:
        copy = retained / path.name
        shutil.copy2(path, copy)
        assert sha(copy) == sha(path)
        subject_inputs[str(path)] = dict(sha256=sha(path), artifact=str(copy), bytes=path.stat().st_size)
    save('frozen-subject-inputs', subject_inputs)
    module = runpy.run_path(str(root / 'tools/ttydiff.py'), run_name='inventory_only')
    inventory = [entry[0] for entry in module['select_scenarios']([])]
    assert len(inventory) == len(set(inventory)) == 226
    tty_inputs = {str(path): sha(path) for path in [subject, subject.with_suffix('.pdmp'),
                  gnu / 'src/emacs', gnu / 'src/emacs.pdmp', gnu / 'src/config.h', gnu / 'src/Makefile',
                  root / 'tools/ttydiff.py', root / 'tools/fixtures/fieldnotes.org',
                  root / 'tools/fixtures/fake_lsp_server.py', Path(__file__)]}
    tty = run('tty', ['/usr/bin/caffeinate', '-i', sys.executable, 'tools/ttydiff.py',
              str(subject), str(gnu / 'src/emacs'), str(gnu / 'lisp')],
              dict(EMAXX_TTYDIFF_REQUIRE='1', LANG='C', LC_ALL='C'),
              dict(inputs=tty_inputs, inventory=inventory,
                   qualification='Complete unchanged terminal inventory after full local Rust and frozen exit. Exact frozen gate executable/image. Both editors use normal -Q entry points and inherit HOME. No earlier or later verdict certifies this run.'))
    assert all(sha(Path(path)) == digest for path, digest in tty_inputs.items())
    raw = (p / 'source302-full-tty.log').read_text(errors='replace')
    started = re.findall(r'^RUN \[(\d+)/(\d+)\] (.+)$', raw, re.M)
    save('tty-inventory', dict(expected_scenarios=226, started_scenarios=len(started),
         complete_start_inventory=len(started) == len(inventory) and all(
             int(a) == index + 1 and int(b) == len(inventory) and name == inventory[index]
             for index, (a, b, name) in enumerate(started)), inputs_unchanged=True,
         qualification='Started-scenario inventory only; every comparison verdict still requires audit.'))
    assert run('oracle-verify', [sys.executable, 'tools/retain_oracle_artifacts.py', 'verify', '--output', str(oracle)])['exit_code'] == 0
    state.update(status='complete macOS processes finished; raw evidence requires audit')
except Exception as error:
    state.update(status='queue or validation setup failed', error=repr(error))
finally:
    save_state()
    save('queue-result', state)
print(json.dumps(state), flush=True)
sys.exit(0 if state['status'] == 'complete macOS processes finished; raw evidence requires audit'
         and all(row['exit_code'] == 0 for row in state['results']) else 1)
