from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys,time
p=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28')
root=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/display-tables/emaxx')
tag='source'+sys.argv[1]
profile=sys.argv[2]
manifest=json.loads((p/(tag+'-manifest.json')).read_text())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def unchanged():return all(sha(root/name)==value for name,value in manifest.items())
def save(suffix,data):
    with (p/(tag+'-'+suffix+'.json')).open('x') as stream:json.dump(data,stream,indent=2);stream.write('\n')
env={'CARGO_TARGET_DIR':'/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/display-tables/emaxx/target/frame-validation','CARGO_BUILD_JOBS':'1',
     'LANG':'C','LC_ALL':'C','RUST_MIN_STACK':'134217728','RUST_TEST_THREADS':'1','EMAXX_GC_VERIFY':'1','EMAXX_IMAGE_TEMPLATE':'1',
     'EMAXX_FIXTURE_IMAGE_DIR':str(p/('fixture-images-'+tag)),
     'EMAXX_GNU_SOURCE_DIRECTORY':'/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/emacs',
     'EMAXX_DUMP_SOURCE_DIRECTORY':'/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/emacs',
     'EMACS_TEST_DIRECTORY':'/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/emacs/test'}
def run(stage,command,extra=None):
    assert unchanged()
    save(stage+'-command',{'command':command,'working_directory':str(root),'environment_override':env,**(extra or {})})
    start=time.monotonic()
    with (p/(tag+'-'+stage+'.log')).open('x') as log:
        result=subprocess.run(command,cwd=root,env={**os.environ,**env},stdout=log,stderr=subprocess.STDOUT,timeout=3600)
    record={'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,'source_unchanged':unchanged()}
    save(stage+'-result',record)
    print(stage,json.dumps(record),flush=True)
    return result.returncode or (0 if record['source_unchanged'] else 2)
code=run(profile+'-build',['cargo','test','--locked','--all-features','--profile',profile,'--lib','--no-run','--message-format=json-render-diagnostics'])
if code:sys.exit(code)
artifacts=[]
for line in (p/(tag+'-'+profile+'-build.log')).read_text().splitlines():
    try:item=json.loads(line)
    except json.JSONDecodeError:continue
    if item.get('reason')=='compiler-artifact' and item.get('profile',{}).get('test') and item.get('executable'):artifacts.append(item['executable'])
assert len(artifacts)==1
binary=p/(tag+'-'+profile+'-libtest');assert not binary.exists();shutil.copy2(artifacts[0],binary)
listed=subprocess.run([str(binary),'--list','--format','terse'],cwd=root,env={**os.environ,**env},capture_output=True,text=True,check=True)
(p/(tag+'-'+profile+'-inventory.txt')).write_text(listed.stdout)
inventory=[line[:-6] for line in listed.stdout.splitlines() if line.endswith(': test')]
names=[name for name in inventory if name.endswith(('::substring_copies_canonical_bytes_properties_and_vector_fields','::substring_validates_gnu_array_types_and_index_error_order','::substring_reversed_bounds_signal_without_host_panics','::substring_of_completion_result_accepts_text_properties','::quoted_bytecode_reader_forms_are_materialized_as_records','::bytecode_constructor_preserves_gnu_field_validation_and_sharing','::bytecode_closure_header_and_words_are_the_native_payload','::bytecode_closure_allocation_is_header_and_actual_lisp_slots','::bytecode_code_mutation_between_calls_matches_gnu','::bytecode_code_mutation_during_active_call_matches_gnu','::bytecode_closure_constants_and_clone_share_gnu_slots','::bytecode_closure_copy_counts_both_actual_allocations','::make_byte_code_object_is_callable','::byte_code_argument_prologue_preserves_string_identity','::byte_code_direct_string_arguments_are_mutable_lisp_objects','::canonical_string_bytes_preserve_gnu_characters_mutation_and_clear','::shared_string_bytes_are_the_authoritative_unibyte_payload','::string_constructors_preserve_gnu_full_character_range_and_errors','::make_string_and_aset_share_the_internal_character_encoding','::make_string_follows_alloc_c_for_the_multibyte_flag','::bytecode_live_fetch_preserves_changed_widths_operands_and_suspended_callers','::canonical_bytecode_entry_borrows_the_actual_bytes_without_predecoding','::byte_code_primitive_executes_program','::unused_bytecode_destinations_follow_actual_control_flow','::taken_bytecode_branch_outside_storage_errors_without_leaking_a_frame','::concat_preserves_canonical_bytes_properties_and_sequence_characters','::completion_results_preserve_gnu_encoding_properties_and_identity','::file_remote_p_parses_tramp_style_names','::case_folded_try_completion_preserves_unextended_input_spelling','::completion_predicates_preserve_string_list_membership','::all_completions_preserves_propertized_string_candidate_identity'))]
assert len(names)==31
extra = [name for name in inventory if name.endswith(('::interactive_closures_use_the_gnu_metadata_environment', '::call_interactively_preserves_interactive_form_closure_mutations', '::edebug_global_break_condition_preserves_the_complete_minibuffer_expression', '::edebug_instrumented_cl_macrolet_preserves_expander_arguments', '::edebug_step_into_generic_method_uses_the_correct_source_stop_points', '::edebug_recursive_command_loop_timer_and_macro_minibuffer_state_stay_coherent'))]
assert len(extra) == 6
names = sorted(set(names + extra))
assert len(names) == 37
code=run(profile+'-controls',[str(binary),*names,'--exact','--nocapture','--test-threads=1'],{'binary_sha256':sha(binary),'selected_inventory':names})
print((p/(tag+'-'+profile+'-controls.log')).read_text(),flush=True)
sys.exit(code)
