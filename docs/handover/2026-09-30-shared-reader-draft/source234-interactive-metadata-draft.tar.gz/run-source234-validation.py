from pathlib import Path
import json
import subprocess
import sys
import time

p = Path(__file__).parent.resolve()
stages = [
    ('check', 'check-source233.py', ['234']),
    ('strict', 'static-source233.py', ['234']),
    ('gate-controls', 'test-source233-controls.py', ['234', 'gate']),
    ('release-controls', 'test-source233-controls.py', ['234', 'release']),
]
results = []
for label, helper, arguments in stages:
    command = [sys.executable, str(p / helper), *arguments]
    print('START', label, flush=True)
    start = time.monotonic()
    result = subprocess.run(command, stdin=subprocess.DEVNULL)
    record = dict(stage=label, command=command, exit_code=result.returncode,
                  elapsed_seconds=time.monotonic() - start)
    results.append(record)
    print('END', label, json.dumps(record), flush=True)
    if result.returncode:
        break
with (p / 'source234-validation-result.json').open('x') as stream:
    json.dump(results, stream, indent=2)
raise SystemExit(results[-1]['exit_code'])
