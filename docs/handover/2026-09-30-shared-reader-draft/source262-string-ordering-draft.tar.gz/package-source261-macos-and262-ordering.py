from pathlib import Path
import ast
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(node for node in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(node, ast.FunctionDef) and node.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected'}
macos = read('source261-macos-rust-audit.json')
assert macos['status'] == 'passed' and macos['total_passed'] == 3107 and macos['library_ignored'] == 2
assert macos['retained_files_verified'] == 4
assert read('source261-macos-rust-name-audit.json')['raw_names_verified'] == 3010
assert len(read('source261-macos-rust-oracle-audit.json')['files']) == 4
full = p / 'full-gate-source261'
files = {str(path.relative_to(p)): path for path in full.rglob('*') if path.is_file() and path.suffix in allowed}
for name in ['source261-manifest.json', 'source261-full-checkout.json', 'source261-full-rust-command.json',
             'source261-full-rust-result.json', 'source261-full-rust.log', 'source261-full-rust-binary.json',
             'source261-full-rust-retention-command.json', 'source261-full-rust-retention-result.json',
             'source261-full-rust-retention.log', 'source261-macos-rust-audit.json',
             'source261-macos-rust-name-audit.json', 'source261-macos-rust-oracle-audit.json',
             'source261-full-retained-gnu/manifest.json', 'source261-full-retained-gnu/config.h',
             'source261-full-retained-gnu/Makefile', 'queue-source261-full-macos.py',
             'audit-source261-macos-rust-names.py', 'verify-source261-macos-rust.py',
             'audit-source261-macos-gnu-inputs.py', 'package-source196-failure-and197-results.py', Path(__file__).name]:
    assert (p / name).is_file(), name
    files[name] = p / name
package('source261-complete-macos-rust', files, dict(
    macos_rust=macos, gnu_inputs=read('source261-macos-rust-oracle-audit.json'),
    qualification='Complete source261 macOS Rust passes at clean pushed commit eddfe782: 3008 library, 60 binary and 39 integration passes, with two existing ignores. All 3010 library names, native artifact identity, four retained Rust inputs, four actual GNU inputs and all 488 source inputs are verified. Frozen/terminal and Linux runs are separate and active. The preceding inline GNU evidence-check KeyError wrote no pass receipt; the corrected helper verifies the original field. No full-platform, memory, ownership or performance completion is inferred.'))
review = read('source262-c-reference-review.json')
assert review['source_inputs_verified'] == 492
assert all(row['exit_code'] == 0 and row['source_unchanged'] for row in review['strict_checks'].values())
negative = read('source261-string-ordering-negative-audit.json')
assert [(row['compared_rows'], row['current_wrong'], row['main_wrong']) for row in negative['comparisons']] == [(1024, 154, 154), (400, 56, 56)]
helpers = {
    'string-ordering-draft-checkout.json', 'string-ordering-symbol-storage.el', 'string-version-ordering.el',
    'probe-source261-string-ordering.py', 'probe-source261-string-ordering-origins.py',
    'audit-source261-string-ordering.py', 'audit-string-equality-symbol-names-positioned-negative.py',
    'source261-string-ordering-probes.json', 'source261-string-ordering-origin-probes.json',
    'source261-string-ordering-negative-audit.json', 'source261-string-ordering-origin-audit.json',
    'check-string-ordering-draft.py', 'freeze-string-ordering.py', 'audit-source262-string-ordering-patches.py',
    'run-string-ordering-focused.py', 'run-string-ordering-release.py',
    'audit-string-ordering-focused.py', 'audit-string-ordering-release.py',
    'test-string-ordering-broad.py', 'build-string-ordering-ordinary.py', 'compare-string-ordering-fixtures.py',
    'queue-string-ordering262-validation.py', 'source261-manifest.json',
    'source261-gate-controls-command.json', 'source261-gate-broad-command.json', 'source261-release-broad-command.json',
    'source249-gate-controls-command.json', 'source249-gate-broad-command.json', 'source249-release-broad-command.json',
    'source255-gate-controls-command.json', 'source255-gate-inventory.log',
    'source174-ordinary-artifacts.json', 'source207-ordinary-artifacts.json',
    'source249-ordinary-artifacts.json', 'source261-ordinary-artifacts.json',
    'package-source196-failure-and197-results.py', Path(__file__).name,
}
files = {}
for path in p.iterdir():
    if not path.is_file() or path.suffix not in allowed:
        continue
    name = path.name
    include = name in helpers or name.startswith('source261-probe-')
    include |= name.startswith('source262-') and name not in ['source262-validation-driver.log', 'source262-validation-queue-state.json']
    if include:
        files[name] = path
assert helpers <= files.keys(), sorted(helpers - files.keys())
candidate = p.parent / 'recovered-2026-09-30/string-ordering/emaxx'
for fixture in ['string-ordering-symbol-storage', 'string-version-ordering']:
    for suffix in ['.el', '.expected']:
        name = 'tests/fixtures/' + fixture + suffix
        files[name] = candidate / name
package('source262-string-ordering-draft', files, dict(
    source_review=review, negative_probes=negative,
    historical_controls=read('source261-string-ordering-origin-audit.json'),
    launch=read('source262-validation-launch.json'),
    qualification='Unapplied 492-input source262 ordering repair follows actual GNU string_cmp and filenvercmp. Both patches replay exactly and strict checks have zero warnings. The unchanged GNU matrices retain 154 wrong symbol/storage results and 56 wrong version results in source261. All 1024 symbol rows match source249; source207 matches main. Four wrong and four repaired rows changed between source207 and source249; exact introducing commit is not established. Version negatives match main exactly. Runtime queue38430 waits for complete source261 macOS exit, then runs 194 focused/1050 affected controls in each profile and 24 ordinary comparisons. No runtime pass or performance claim for the draft.'))
