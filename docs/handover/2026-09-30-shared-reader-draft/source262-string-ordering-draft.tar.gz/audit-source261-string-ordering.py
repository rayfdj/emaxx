from pathlib import Path
import ast
from collections import Counter
import hashlib
import json
import re

p = Path(__file__).parent.resolve()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
node = next(node for node in ast.parse((p / 'audit-string-equality-symbol-names-positioned-negative.py').read_text()).body
            if isinstance(node, ast.FunctionDef) and node.name == 'parse')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<ordinary-matrix-parser>', 'exec'))
records = []
for fixture, count, width in [('string-ordering-symbol-storage', 1024, 5), ('string-version-ordering', 400, 3)]:
    observations, inputs = {}, {}
    for editor in ['gnu', 'source261', 'source174']:
        stem = 'source261-probe-' + fixture + '-' + editor
        command = json.loads((p / (stem + '-command.json')).read_text())
        result = json.loads((p / (stem + '-result.json')).read_text())
        assert result['exit_code'] == 0 and not result['timed_out']
        assert result['source_unchanged'] and result['inputs_unchanged']
        assert not (p / (stem + '.stderr')).read_bytes()
        assert sha(p / (stem + '.stdout')) == result['stdout_sha256']
        assert sha(p / (stem + '.stderr')) == result['stderr_sha256']
        assert all(sha(Path(name)) == digest for name, digest in command['inputs'].items())
        rows = parse((p / (stem + '.stdout')).read_text())
        assert len(rows) == count and all(len(row) == width for row in rows)
        observations[editor] = {tuple(row[:-1]): row[-1] for row in rows}
        assert len(observations[editor]) == count
        inputs[editor] = command['inputs']
    oracle = observations['gnu']
    assert all(row.keys() == oracle.keys() for row in observations.values())
    if width == 5:
        assert {key[0] for key in oracle} == {'string-lessp', 'string-version-lessp'}
        assert {key[1] for key in oracle} == {'nil', 't'}
        left = {key[2] for key in oracle}
        right = {key[3] for key in oracle}
        assert len(left) == len(right) == 16 and left == right
        assert set(oracle) == {(function, enabled, a, b) for function in ['string-lessp', 'string-version-lessp']
                               for enabled in ['nil', 't'] for a in left for b in right}
    else:
        left, right = {key[0] for key in oracle}, {key[1] for key in oracle}
        assert len(left) == len(right) == 20 and left == right
        assert set(oracle) == {(a, b) for a in left for b in right}
        assert all(value in ['nil', 't'] for values in observations.values() for value in values.values())
    differences = {}
    for editor in ['source261', 'source174']:
        differences[editor] = {key: value for key, value in observations[editor].items() if value != oracle[key]}
    introduced = set(differences['source261']) - set(differences['source174'])
    fixed = set(differences['source174']) - set(differences['source261'])
    changed_wrong = {key for key in differences['source261'].keys() & differences['source174'].keys()
                     if differences['source261'][key] != differences['source174'][key]}
    record = dict(fixture=fixture, fixture_sha256=sha(p / (fixture + '.el')), compared_rows=count,
                  current_wrong=len(differences['source261']), main_wrong=len(differences['source174']),
                  newly_wrong_rows=[list(key) for key in sorted(introduced)],
                  repaired_rows=[list(key) for key in sorted(fixed)],
                  changed_wrong_rows=[list(key) for key in sorted(changed_wrong)], inputs=inputs,
                  differences=[dict(key=list(key), gnu=oracle[key], source261=observations['source261'][key],
                                    source174=observations['source174'][key])
                               for key in oracle if key in differences['source261'] or key in differences['source174']])
    if width == 5:
        record['current_wrong_by_primitive'] = dict(Counter(key[0] for key in differences['source261']))
        record['main_wrong_by_primitive'] = dict(Counter(key[0] for key in differences['source174']))
    records.append(record)
gnu = p.parent / 'rebuilt-2026-10-01/emacs'
references = {}
for file, anchors in {'src/fns.c': ['DEFUN ("string-lessp"', 'DEFUN ("string-version-lessp"'],
                      'lib/filevercmp.c': ['file_prefixlen (', 'order (', 'verrevcmp (', 'filenvercmp (']}.items():
    raw = (gnu / file).read_text().splitlines()
    references[file] = dict(sha256=sha(gnu / file), anchors={anchor: next(i + 1 for i, line in enumerate(raw) if anchor in line) for anchor in anchors})
report = dict(status='ordinary GNU ordering gaps confirmed', comparisons=records, gnu_references=references,
              goal_complete=False,
              qualification='All six ordinary processes exited zero with empty stderr; every input/output hash and complete matrix is verified. Historical attribution applies only to these rows on the retained source174/main executable/image. No full compatibility, general regression absence or performance claim. Source261 selected validation and active complete runs remain separate; no existing selector, expectation or runtime input changes.')
with (p / 'source261-string-ordering-negative-audit.json').open('x') as stream:
    json.dump(report, stream, indent=2)
print(json.dumps([dict(fixture=row['fixture'], rows=row['compared_rows'], current_wrong=row['current_wrong'],
                       main_wrong=row['main_wrong'], newly_wrong=len(row['newly_wrong_rows']), repaired=len(row['repaired_rows']),
                       changed_wrong=len(row['changed_wrong_rows'])) for row in records], indent=2))
