from pathlib import Path
import hashlib, json, subprocess, sys
p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/string-ordering/emaxx'
tag = 'source' + sys.argv[1]
assert sys.argv[1].isdecimal()
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
files = [*root.joinpath('src').rglob('*.rs'), *root.joinpath('tests').rglob('*')]
files += [root / name for name in ['Cargo.toml', 'Cargo.lock', 'build.rs', 'tools/ttydiff.py', 'tools/fixtures/fieldnotes.org', 'tools/fixtures/fake_lsp_server.py']]
files += list(root.joinpath('.cargo').glob('*'))
files += [root / name for name in ['compat/emacs_compat_runner.el', 'src/lisp/bytecode/fixture-oracle-30.2.elc', 'src/lisp/bytecode/fixture-oracle2-30.2.elc', 'src/lisp/bytecode/fixture-oracle3-30.2.elc']]
manifest = {str(file.relative_to(root)): sha(file) for file in sorted(set(files)) if file.is_file()}
assert len(manifest) == 492
assert json.loads((p / (tag + '-manifest.json')).read_text()) == manifest
untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=root, text=True).splitlines()
extra = b''
for name in sorted(set(untracked) & set(manifest)):
    result = subprocess.run(['git', 'diff', '--no-index', '--binary', '--', '/dev/null', name], cwd=root, capture_output=True)
    assert result.returncode == 1 and not result.stderr
    extra += result.stdout
patches = {}
for label, base in [('portable-incremental', '7c6bb8ce11b44e7d63f165a502c27c6ae5ee3891'),
                    ('portable-complete', '21d20f0eec08f3c013d5d3eb3bd6e9cfc16b3199')]:
    patch = subprocess.check_output(['git', 'diff', '--binary', base, '--', *sorted(manifest)], cwd=root) + extra
    target = p / (tag + '-' + label + '.patch')
    with target.open('xb') as f:
        f.write(patch)
    patches[label] = dict(base=base, sha256=sha(target), bytes=len(patch))
record = dict(inputs=492, patches=patches, candidate=str(root), goal_complete=False,
              qualification='Isolated ordering repair atop source261. string-lessp compares actual canonical bytes/characters and actual Lisp symbol names; string-version-lessp follows GNU lib/filevercmp.c on the original byte slices, including suffix, dot, tilde and zero handling. The old host-text comparison helper is removed. Two unchanged ordinary GNU fixtures retain 1024 symbol/storage rows and 400 version rows. Original main/source207/source249/source261 negatives are retained. Strict and runtime results remain separate; no complete validation, performance or goal-completion claim.')
with (p / (tag + '-freeze.json')).open('x') as f:
    json.dump(record, f, indent=2)
print(json.dumps(record, indent=2))
