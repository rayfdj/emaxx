from pathlib import Path
import hashlib
import json
import re

p = Path(__file__).parent.resolve()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def parse(text):
    tokens = iter(re.findall(r'[()]|[^()\s]+', text))

    def one(token):
        if token != '(':
            assert token != ')'
            return token
        values = []
        for token in tokens:
            if token == ')':
                return values
            values.append(one(token))
        raise AssertionError('Unclosed result list')

    result = one(next(tokens))
    assert next(tokens, None) is None
    return result


rows = {}
inputs = {}
for editor in ['gnu', 'emaxx']:
    stem = 'source249-string-equality-symbol-names-positioned-' + editor
    command = json.loads((p / (stem + '-command.json')).read_text())
    result = json.loads((p / (stem + '-result.json')).read_text())
    assert result['exit_code'] == 0
    assert not (p / (stem + '.stderr')).read_bytes()
    assert sha(p / (stem + '.stdout')) == result['stdout_sha256']
    assert all(sha(Path(name)) == digest for name, digest in command['inputs'].items())
    inputs[editor] = command['inputs']
    parsed = parse((p / (stem + '.stdout')).read_text())
    assert len(parsed) == 512 and all(len(row) == 4 for row in parsed)
    rows[editor] = {tuple(row[:3]): row[3] for row in parsed}
    assert len(rows[editor]) == 512
    assert {key[0] for key in rows[editor]} == {'nil', 't'}
    assert len({key[1] for key in rows[editor]}) == 16
    assert len({key[2] for key in rows[editor]}) == 16
assert rows['gnu'].keys() == rows['emaxx'].keys()
differences = [
    dict(enabled=key[0], left=key[1], right=key[2], gnu=expected, emaxx=rows['emaxx'][key])
    for key, expected in rows['gnu'].items() if expected != rows['emaxx'][key]
]
assert len(differences) == 92
positioned = [row for row in differences if any(row[k].startswith('positioned-') for k in ['left', 'right'])]
assert len(positioned) == 56 and all(row['enabled'] == 't' for row in positioned)
storage = [row for row in differences if row not in positioned]
assert len(storage) == 36
assert all(row['gnu'] in ['nil', 't'] and row['emaxx'] in ['nil', 't'] for row in storage)
assert sum(row['gnu'] == 'nil' for row in storage) == 32
record = dict(
    status='confirmed source249 negative', fixture='string-equality-symbol-names-positioned.el',
    fixture_sha256=sha(p / 'string-equality-symbol-names-positioned.el'),
    pairs=512, distinct_argument_cases=16, flag_values=['nil', 't'], inputs=inputs,
    differences=differences, storage_boolean_differences=36, positioned_policy_differences=56,
    qualification='Both ordinary processes exited successfully with empty stderr and unchanged retained inputs. GNU Fstring_equal reads the actual SYMBOL_NAME and SYMBOLP follows symbols_with_pos_enabled. This does not establish the historical origin or validate a repair. The preceding nonexistent-constructor fixture is retained separately as a setup failure.'
)
with (p / 'source249-string-equality-symbol-names-positioned-negative-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps({key: record[key] for key in ['status', 'pairs', 'storage_boolean_differences', 'positioned_policy_differences']}))
