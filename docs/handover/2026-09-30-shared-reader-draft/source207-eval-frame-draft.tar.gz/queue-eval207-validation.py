from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/eval-frames/emaxx'
manifest = json.loads((p / 'source207-manifest.json').read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
unchanged = lambda: all(sha(root / f) == h for f, h in manifest.items())
steps = [
    ['check-eval207.py', '207'],
    ['static-eval207.py', '207'],
    ['test-eval207.py', '207', 'gate'],
    ['test-eval207.py', '207', 'release'],
    ['build-eval207.py', '207'],
]
results = []
for args in steps:
    assert unchanged()
    started = time.monotonic()
    completed = subprocess.run([sys.executable, str(p / args[0]), *args[1:]], stdin=subprocess.DEVNULL)
    result = dict(script=args, exit_code=completed.returncode, source_unchanged=unchanged(),
                  elapsed_seconds=time.monotonic()-started)
    results.append(result)
    if completed.returncode or not result['source_unchanged']:
        break
passed = len(results) == len(steps) and all(r['exit_code'] == 0 and r['source_unchanged'] for r in results)
with (p / 'source207-selected-build-validation-result.json').open('x') as f:
    json.dump(dict(steps=results, passed=passed, all_completed=len(results)==len(steps),
                   source_unchanged=unchanged(), completed_unix=time.time(),
                   qualification='Selected macOS runtime and fresh ordinary artifact validation. Linux, full gates, ordinary differential comparisons and performance remain separate requirements.'), f, indent=2)
raise SystemExit(0 if passed else 1)
