from pathlib import Path
import ast,hashlib,json,re
p=Path(__file__).parent.resolve()
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
read=lambda n:json.loads((p/n).read_text())
selected=read('source270-selected-audit.json')
assert selected['status']=='passed' and selected['ordinary_comparisons']==33
node=next(n for n in ast.parse((p/'audit-source261-compare-strings.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='parse')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<retained-lossless-lisp-parser>','exec'))
fixtures=[('string-ordering-symbol-storage',1024,154),('string-version-ordering',400,56),('compare-strings-ranges',22,12),('compare-strings-character-storage',1024,134),('string-case-character-identities',30,9),('string-empty-identities',12,6),('string-pure-storage-values',96,57),('string-pure-property-storage',144,106)]
records=[]
for fixture,count,old_wrong in fixtures:
    gnu=p/('source261-probe-'+fixture+'-gnu.stdout')
    old=p/('source261-probe-'+fixture+'-source261.stdout')
    current=p/('source270-ordinary-'+fixture+'-emaxx.stdout')
    actual_gnu=p/('source270-ordinary-'+fixture+'-gnu.stdout')
    assert sha(gnu)==sha(current)==sha(actual_gnu)==selected['ordinary_expected_sha256'][fixture]
    old_result=read('source261-probe-'+fixture+'-source261-result.json')
    assert old_result['exit_code']==0 and not old_result['timed_out'] and old_result['inputs_unchanged'] and old_result['source_unchanged']
    assert sha(old)==old_result['stdout_sha256']
    rows={name:parse(f.read_bytes().decode('latin1')) for name,f in [('gnu',gnu),('source261',old),('source270',current)]}
    assert all(len(value)==count for value in rows.values())
    before=sum(a!=b for a,b in zip(rows['gnu'],rows['source261']))
    after=sum(a!=b for a,b in zip(rows['gnu'],rows['source270']))
    assert before==old_wrong and after==0
    records.append(dict(fixture=fixture,rows=count,source261_wrong_rows=before,source270_wrong_rows=after,gnu_expected_sha256=sha(gnu),source261_stdout_sha256=sha(old),source270_stdout_sha256=sha(current)))
record=dict(status='all recorded rows match unchanged ordinary GNU output on source270',fixtures=records,qualification='Same-input ordinary executable/image comparisons for these eight recorded matrices only. Counts overlap in behavior and are not summed. Live-table/prefix/original fixtures are additionally checked in the33-comparison selected audit. This proves closure of the recorded negatives, not universal correctness,full-platform completion or performance parity.')
with (p/'source270-closed-string-negatives-audit.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(record,indent=2))
