from pathlib import Path
import ast,difflib,hashlib,json
p=Path(__file__).parent.resolve()
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
original=(p/'queue-source263-full-macos.py').read_text()
s=original.replace('source263','source270').replace("'recovered-2026-09-30/string-ranges/emaxx'", "'recovered-2026-09-30/string-storage/emaxx'").replace("'target/string-range-validation'", "'target/string-storage-validation'")
s=s.replace("'source270-boundary-fixtures-launch.json'", "'source270-validation-launch.json'").replace('queue-source270-boundary-fixtures.py','queue-string-storage270-validation.py')
s=s.replace('waiting for source270 selected and boundary validation','waiting for source270 selected validation').replace('len(manifest) == 500','len(manifest) == 510')
start=s.index("    prior = json.loads((p / 'source270-boundary-fixtures-queue-result.json')")
stop=s.index("    assert run('selected-audit'",start)
s=s[:start]+"    prior = json.loads((p / 'source270-validation-result.json').read_text())\n    assert prior['status'] == 'selected processes finished; raw evidence requires audit'\n    assert len(prior['results']) == len(prior['stages']) == 8\n    assert all(row['exit_code'] == 0 and row['source_unchanged'] and row['prior_source_unchanged'] and row['published_source_unchanged'] and row['helper_unchanged'] for row in prior['results'])\n"+s[stop:]
s=s.replace("selected['ordinary_comparisons'] == 28", "selected['ordinary_comparisons'] == 33").replace("row['focused_passes'] == 197 and row['affected_passes'] == 1054", "row['focused_passes'] == 203 and row['affected_passes'] == 1059")
assert 'source263' not in s and 'boundary-fixtures' not in s and 'string-range-validation' not in s
ast.parse(s)
with (p/'queue-source270-full-macos.py').open('x') as f:f.write(s)
a=(p/'audit-source270-selected.py').read_text()
needle="with (p / 'source270-selected-audit.json').open('x') as stream:"
assert a.count(needle)==1
a=a.replace(needle,"with (p / 'source270-full-selected-audit.json').open('x') as stream:")
ast.parse(a)
with (p/'audit-source270-selected-for-full.py').open('x') as f:f.write(a)
d=(p/'dispatch-source261-linux.py').read_text().replace('source261','source270').replace('488-input','510-input').replace('488-input','510-input').replace('189 focused','203 focused').replace('962 affected','1059 affected').replace('twenty-two ordinary','thirty-three ordinary').replace('Complete source249 passes are historical.','Complete source261 results remain historical and include six strict Darwin frozen skip-diagnostic differences.')
ast.parse(d)
with (p/'dispatch-source270-linux.py').open('x') as f:f.write(d)
record=dict(status='prepared; not launched',macos_helper_sha256=sha(p/'queue-source270-full-macos.py'),selected_auditor_sha256=sha(p/'audit-source270-selected-for-full.py'),linux_dispatch_sha256=sha(p/'dispatch-source270-linux.py'),changes=''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='source263-full-preparation',tofile='source270-full-preparation')),goal_complete=False,qualification='Syntax-checked preparation only. Requires actual successful source270 selected results, validated runtime publication and a clean exact-commit checkout. Original full Rust,519 frozen files,226 terminal scenarios and oracle verification remain unchanged. No full source270 validation has started.')
with (p/'source270-full-validation-preparation.json').open('x') as f:json.dump(record,f,indent=2)
print('Prepared full macOS and Linux helpers; not launched.')
