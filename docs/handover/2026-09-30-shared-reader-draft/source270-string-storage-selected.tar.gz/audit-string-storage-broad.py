from pathlib import Path
import ast,hashlib,json,re,sys
p=Path(__file__).parent.resolve();candidate=p.parent/'recovered-2026-09-30/string-storage/emaxx'
tag='source'+sys.argv[1];profile=sys.argv[2]
assert sys.argv[1].isdecimal() and profile in ['gate','release']
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
read=lambda n:json.loads((p/n).read_text())
manifest=read(tag+'-manifest.json');assert len(manifest)==510 and all(sha(candidate/n)==h for n,h in manifest.items())
command=read(tag+'-'+profile+'-broad-command.json');result=read(tag+'-'+profile+'-broad-result.json')
selected=command['selected_inventory'];assert len(selected)==len(set(selected))==1059
assert command['command'][1:]==selected+['--exact','--nocapture','--test-threads=1']
prior=read('source263-gate-broad-command.json')['selected_inventory']
assert len(prior)==1054 and set(prior)<=set(selected)
assert result['exit_code']==0 and result['source_unchanged']
node=next(n for n in ast.parse((p/'audit-source270-selected.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='audit_log')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<complete-named-test-block-verifier>','exec'))
raw=p/(tag+'-'+profile+'-broad.log');audit_log(selected,raw.read_text(),[])
binary=p/(tag+'-'+profile+'-libtest');assert sha(binary)==command['binary_sha256']
# The per-profile focused auditor verifies its full retained input list.
focused=read(tag+'-focused-audit.json' if profile=='gate' else tag+'-release-focused-audit.json')
for item in focused['retained_inputs']:
    assert sha(Path(item['original']))==sha(Path(item['artifact']))==item['sha256']
record=dict(status='passed',profile=profile,counts=dict(ok=1059,FAILED=0,ignored=0),source_inputs_verified=510,all_selected_names=selected,prior_source263_selectors_preserved=1054,binary_sha256=command['binary_sha256'],raw_log_sha256=sha(raw),elapsed_seconds=result['elapsed_seconds'],qualification='Complete affected raw named verdicts and exact executable/source identities only. Full platform correctness,ordinary comparisons and performance are separate requirements; all earlier failures remain retained.')
with (p/(tag+'-'+profile+'-broad-audit.json')).open('x') as f:json.dump(record,f,indent=2)
print(json.dumps({k:record[k] for k in ['status','profile','counts','source_inputs_verified']},indent=2))
