from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve();root=p.parents[2]
candidate=p.parent/'recovered-2026-09-30/string-storage/emaxx'
out=root/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda n:json.loads((p/n).read_text())
audit=read('source270-selected-audit.json')
assert audit['status']=='passed' and audit['source_inputs_verified']==510 and audit['ordinary_comparisons']==33
assert all(r['focused_passes']==203 and r['affected_passes']==1059 for r in audit['profiles'].values())
state=read('source270-validation-result.json')
assert len(state['results'])==len(state['stages'])==8 and all(r['exit_code']==0 for r in state['results'])
manifest=read('source270-manifest.json');assert len(manifest)==510 and all(sha((candidate/n).read_bytes())==h for n,h in manifest.items())
for name in ['source268-focused-audit.json','source269-focused-audit.json']:
    assert read(name)['status']=='failed'
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
allowed={'.json','.log','.txt','.py','.el','.expected','.patch','.stdout','.stderr'}
files={f.name:f for f in p.iterdir() if f.is_file() and f.name.startswith('source270-') and not f.name.startswith('source270-full-') and f.suffix in allowed}
names=[Path(__file__).name,'package-source196-failure-and197-results.py','audit-source270-selected.py','audit-source270-closed-string-negatives.py','audit-source270-raw-report-adversarial.py','audit-source270-storage-patches.py','check-string-storage-callers.py','freeze-string-storage-callers.py','queue-string-storage270-validation.py','launch-source270-validation.py','run-string-storage-focused.py','run-string-storage-release.py','audit-string-storage-focused.py','audit-string-storage-release.py','audit-string-storage-broad.py','test-string-storage-broad.py','build-string-storage-ordinary.py','compare-string-storage-fixtures.py','prepare-source270-full-validation.py','queue-source270-full-macos.py','audit-source270-selected-for-full.py','dispatch-source270-linux.py','apply-source270-selected.py','setup-source270-full-macos.py','source268-focused-audit.json','source268-fixture-framing-audit.json','source269-focused-audit.json','source269-storage-failure-audit.json','audit-source269-storage-failure.py','audit-source261-compare-strings.py','source261-manifest.json','source261-selected-audit.json','source261-gate-inventory.log','source261-release-inventory.log','source261-gate-controls-command.json','source261-release-controls-command.json','source261-gate-broad-command.json','source261-release-broad-command.json','source249-gate-controls-command.json','source255-gate-controls-command.json','source263-gate-broad-command.json','source261-string-prefix-audit.json','source256-native-bytecode-constructor-gnu.stdout']
names += ['source270-full-checkout.json','source270-full-checkout-command.json','source270-full-launch.json','source270-full-selected-audit.json','source270-full-selected-audit-command.json','source270-full-selected-audit-result.json','source270-full-cache-clone-command.json','source270-full-cache-clone-result.json','source270-full-fresh-gate-crate-command.json','source270-full-fresh-gate-crate-result.json','source270-full-oracle-capture-command.json','source270-full-oracle-capture-result.json']
for fixture in ['string-ordering-symbol-storage','string-version-ordering','compare-strings-ranges','compare-strings-character-storage','string-case-character-identities','string-empty-identities','string-pure-storage-values','string-pure-property-storage']:
    for editor in ['gnu','source261']:
        names += ['source261-probe-'+fixture+'-'+editor+suffix for suffix in ['-command.json','-result.json','.stdout','.stderr']]
for n in names:
    assert (p/n).is_file(),n
    files[n]=p/n
for fixture in state['stages'][-1][3:]:
    for extension in ['.el','.expected']:
        n=fixture+extension
        choices=[candidate/'tests/fixtures'/n,p/n]
        found=next((f for f in choices if f.is_file()),None)
        if found is None:
            assert fixture=='native-bytecode-unibyte-constructor' and extension=='.expected'
        else:files['fixtures/'+n]=found
package('source270-string-storage-selected',files,dict(selected=audit,closed_negatives=read('source270-closed-string-negatives-audit.json'),raw_report_adversarial=read('source270-raw-report-adversarial-audit.json'),publication=read('source270-applied-commit.json'),full_macos_launch=read('source270-full-launch.json'),linux_launches=[read('source270-linux-'+mode+'-launch.json') for mode in ['rust','frozen']],qualification='Closed selected source270 gate/release and33 ordinary exact GNU comparisons, all510source inputs, original controls and expected bytes verified. The complete12600prefix matrix is retained. Source268/269 focused failures and earlier source263/264/265/266 failures remain preserved in separate linked archives. This archive does not certify full Linux/macOS Rust,frozen,terminal,public ownership,physical accounting,architecture completion or performance. Full-validation preparation is included; only its actual launch and audited results can establish later progress.'))
