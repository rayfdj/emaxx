from pathlib import Path
import hashlib,json,subprocess
p=Path(__file__).parent.resolve();root=p.parents[2];candidate=p.parent/'recovered-2026-09-30/string-storage/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
read=lambda n:json.loads((p/n).read_text())
manifest=read('source270-manifest.json');prior=read('source261-manifest.json');audit=read('source270-selected-audit.json')
assert len(manifest)==510 and all(sha(candidate/n)==h for n,h in manifest.items())
assert len(prior)==488 and all(sha(root/n)==h for n,h in prior.items())
assert audit['status']=='passed' and audit['source_inputs_verified']==510 and audit['ordinary_comparisons']==33
assert all(r['focused_passes']==203 and r['affected_passes']==1059 for r in audit['profiles'].values())
assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()=='runtime-char-tables'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
assert not (p/'source270-applied-commit.json').exists()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
patch=p/'source270-portable-incremental.patch'
assert sha(patch)==read('source270-freeze.json')['patches']['portable-incremental']['sha256']
commands=[['git','apply','--check',str(patch)],['git','apply',str(patch)],['git','diff','--check']]
for i,command in enumerate(commands):
    result=subprocess.run(command,cwd=root,capture_output=True,text=True)
    with (p/('source270-apply-stage-'+str(i)+'.json')).open('x') as f:json.dump(dict(command=command,exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr),f,indent=2)
    result.check_returncode()
assert all(sha(root/n)==h for n,h in manifest.items())
subprocess.run(['git','add','--',*sorted(manifest)],cwd=root,check=True)
result=subprocess.run(['git','-c','user.name=Ray','-c','user.email=26018378+rayfdj@users.noreply.github.com','commit','-m','Use compact strings and GNU comparison and allocation semantics'],cwd=root,capture_output=True,text=True)
with (p/'source270-apply-commit-command.json').open('x') as f:json.dump(dict(exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr),f,indent=2)
result.check_returncode()
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
record=dict(commit=commit,parent=head,source_inputs=510,source_manifest='source270-manifest.json',candidate=str(candidate),selected_audit_sha256=sha(p/'source270-selected-audit.json'),goal_complete=False,qualification='Applies the exact independently validated source270 runtime. Full platform validation and architecture/performance requirements remain open; original failures are retained.')
with (p/'source270-applied-commit.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(record,indent=2))
