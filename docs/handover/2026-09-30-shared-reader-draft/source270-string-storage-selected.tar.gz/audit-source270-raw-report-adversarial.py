from pathlib import Path
import ast,hashlib,json,re
p=Path(__file__).parent.resolve()
read=lambda n:json.loads((p/n).read_text())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
helper=p/'audit-source270-selected.py'
node=next(n for n in ast.parse(helper.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='audit_log')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<actual-selected-report-parser>','exec'))
command=read('source270-gate-broad-command.json');names=command['selected_inventory'];raw=(p/'source270-gate-broad.log').read_text()
assert read('source270-gate-broad-audit.json')['counts']==dict(ok=1059,FAILED=0,ignored=0)
audit_log(names,raw,[])
blocks=list(re.finditer(r'^test (\S+) \.\.\. ',raw,re.M));assert len(blocks)==1059
first=raw[blocks[0].start():blocks[1].start()]
assert first.rstrip().endswith('ok')
wrong_verdict=first.rstrip()[:-2]+'FAILED\n'
corruptions={
 'missing_named_test':raw[:blocks[0].start()]+raw[blocks[1].start():],
 'renamed_test':raw.replace('test '+names[0]+' ... ','test omitted-contract ... ',1),
 'duplicate_named_test':raw[:blocks[0].start()]+first+raw[blocks[0].start():],
 'failed_test_under_green_summary':raw.replace(first,wrong_verdict,1),
 'new_ignore_under_green_summary':raw.replace(first,first.rstrip()[:-2]+'ignored\n',1),
 'wrong_summary_count':raw.replace('1059 passed; 0 failed;', '1058 passed; 0 failed;',1),
 'missing_summary':raw[:raw.index('\ntest result:')],
 'missing_last_verdict':raw[:raw.index('\ntest result:')].rstrip()[:-2]+'\n'+raw[raw.index('\ntest result:'):],
}
assert all(corrupt!=raw for corrupt in corruptions.values())
verdicts=[]
for label,corrupt in corruptions.items():
    try:audit_log(names,corrupt,[])
    except (AssertionError,ValueError) as error:
        verdicts.append(dict(corruption=label,rejected=True,error_type=type(error).__name__))
    else:raise AssertionError('Corrupt report accepted: '+label)
record=dict(status='all eight corruptions rejected',original_report_accepted=True,raw_log_sha256=sha(p/'source270-gate-broad.log'),actual_parser_sha256=sha(helper),selected_names=1059,negative_controls=verdicts,qualification='In-memory adversarial checks of the exact selected raw-verdict parser. Original source,helpers,logs and results are unchanged. This covers named verdict/inventory/summary consistency only, not measurement integrity,semantic code audit,process provenance or final-goal completion.')
with (p/'source270-raw-report-adversarial-audit.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(record,indent=2))
