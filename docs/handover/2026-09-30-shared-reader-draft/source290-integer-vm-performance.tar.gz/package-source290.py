from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve();out=p/'source290-publication-stage';out.mkdir(exist_ok=True)
sha=lambda data:hashlib.sha256(data).hexdigest();read=lambda n:json.loads((p/n).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
allowed={'.json','.log','.txt','.py','.patch','.stdout','.stderr','.el','.expected','.h'}
selected=read('source290-selected-closed-audit.json');assert selected['status']=='passed' and selected['source_inputs_verified']==528
perf=read('vm-integer-performance-audit.json');assert perf['status']=='all 192 processes and actual results/modes verified'
assert all(sha(Path(n).read_bytes())==h for n,h in selected['evidence_files'].items())
assert all(sha(Path(n).read_bytes())==h for n,h in perf['evidence_files'].items())
files={f.name:f for f in p.iterdir() if f.is_file() and f.suffix in allowed and (f.name.startswith('source290-') or f.suffix=='.py' and 'source290' in f.name)}
for n in ['source289-manifest.json','source289-selected-audit.json','source289-gate-inventory.log','source289-release-inventory.log','source289-run-fast-disassembly.txt','compare-vm-dispatch-fixtures.py','printer-varied-v3-293638f0.el','printer-varied-v3-gnu.stdout','package-source196-failure-and197-results.py',Path(__file__).name]:files[n]=p/n
package('source290-integer-vm-selected',files,dict(status='bounded source290 selected validation closed',selected=selected,static_review=read('source290-static-review.json'),qualification='528 exact inputs and both portable replays. All selected gate/release tests and46 ordinary actual GNU comparisons pass, including588 numeric boundary rows and198 generated reader/printer rows. All prior assertions/fixtures remain. Original edit-generator preparation error and stale wrapper exit predicate are retained; all raw child verdicts are separately verified. The closed evidence audit supersedes its provisional snapshot of live pipeline state. Application and complete-platform status are separate. Full architecture/accounting/ownership and performance acceptance remain open.',goal_complete=False))
files={}
for tag in ['source289','source290']:
 for directory in sorted(p.glob(tag+'-vm-integer-pilot-*')):
  for f in directory.rglob('*'):
   if f.is_file():files[str(f.relative_to(p))]=f
 for f in (p/(tag+'-core-native')).rglob('*'):
  if f.is_file() and f.suffix in allowed:files[str(f.relative_to(p))]=f
mixed=read('source290-mixed-profile-result.json');assert mixed['inputs_unchanged'] and all(r['validation']=='completed' and r['samples']==20 for r in mixed['results'])
for n,h in mixed['inputs'].items():assert sha(Path(n).read_bytes())==h
for f in (p/'source290-mixed-profiles').rglob('*'):
 if f.is_file() and f.suffix in allowed:files[str(f.relative_to(p))]=f
profiles=read('source290-call-profile-result.json');assert profiles['inputs_unchanged'] and all(r['validation']=='completed' and r['samples']==20 for r in profiles['results'])
for n,h in profiles['inputs'].items():assert sha(Path(n).read_bytes())==h
for f in (p/'source290-call-profiles').rglob('*'):
 if f.is_file() and f.suffix in allowed:files[str(f.relative_to(p))]=f
for f in p.iterdir():
 if f.is_file() and f.suffix in allowed and (f.name.startswith(('vm-integer-performance-','source290-performance-sequence-','source290-sequence-')) or f.name in ['source290-call-profile-result.json','source290-mixed-profile-result.json','profile-source290-mixed.py','measure-vm-integer.py','audit-vm-integer-performance.py','profile-source290-calls.py','finish-source290-performance.py',Path(__file__).name]):files[f.name]=f
package('source290-integer-vm-performance',files,dict(status='all192 diagnostic process answers/modes verified',audit=perf,profiles=profiles,mixed_profiles=mixed,application_decision=read('source290-application-decision.json'),qualification='Three interleaved full16 diagnostic pilots per unchanged source289 baseline and source290 candidate, each using its own valid executable/image/native artifact. All samples, unfavorable results, startup/total/RSS/GC and unavailable-allocation reports remain. Build/tests/profiles do not run during timing. Calibration, real counters and the unchanged nine-round3% every-case acceptance remain required.',goal_complete=False))
