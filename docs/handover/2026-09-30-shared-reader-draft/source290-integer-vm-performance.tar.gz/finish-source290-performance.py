from pathlib import Path
import hashlib,json,os,subprocess,sys,time
p=Path(__file__).parent.resolve()
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
names=['measure-vm-integer.py','audit-vm-integer-performance.py','profile-source290-calls.py',Path(__file__).name]
fixed={n:sha(p/n) for n in names};state=dict(status='waiting for audited selected validation',results=[],helpers=fixed,goal_complete=False)
def save(): (p/'source290-performance-sequence-state.json').write_text(json.dumps(state,indent=2)+'\n')
save()
try:
 while not (p/'source290-finish-finish-result.json').exists():
  print('waiting for audited source290 selected validation',flush=True);time.sleep(30)
 selected=json.loads((p/'source290-finish-finish-result.json').read_text());assert selected['status']=='candidate selected correctness audited; performance and application pending',selected
 for name in names[:-1]:
  assert all(sha(p/n)==h for n,h in fixed.items())
  state['status']='running '+name;save();start=time.monotonic()
  command=[sys.executable,'-B',str(p/name)]
  with (p/('source290-sequence-'+name+'.log')).open('xb') as log:
   result=subprocess.run(command,cwd=p,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
  state['results'].append(dict(command=command,exit_code=result.returncode,elapsed_seconds=time.monotonic()-start));save()
  print(json.dumps(state['results'][-1]),flush=True);assert result.returncode==0
 state['status']='diagnostic timing and profiles audited; application requires result review'
except Exception as error:state.update(status='sequence stopped',error=repr(error))
finally:
 save()
 with (p/'source290-performance-sequence-result.json').open('x') as f:json.dump(state,f,indent=2)
print(json.dumps(dict(status=state['status'],error=state.get('error'))),flush=True)
sys.exit(0 if state['status'].startswith('diagnostic timing') else 1)
