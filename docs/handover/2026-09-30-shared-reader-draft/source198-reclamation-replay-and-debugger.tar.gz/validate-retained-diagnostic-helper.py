from pathlib import Path
import ast
import hashlib
import json
import os
import shutil
import sys
import tempfile

root = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(root / 'tools'))
import diagnose_exact_weak_roots as driver

original = Path(sys.argv[1]).resolve()
revision = '7e45db47438a39e97658bddaceba903e0e41c186'
selector = 'suspended_bytecode_retains_operand_and_unwind_roots'
record, _ = driver.retained_full_gate(original, revision, selector)
assert record['test_binary']['sha256'] == driver.FULL_GATE_BINARY
assert len(record['fixture_images']) == len(record['expected_tests']) == 1
controls = []

def reject(label, directory, revision_value=revision):
    try:
        driver.retained_full_gate(directory, revision_value, selector)
    except RuntimeError as error:
        controls.append({'case': label, 'rejected': True, 'reason': str(error)})
    else:
        raise AssertionError(label + ' unexpectedly accepted')

reject('wrong source revision', original, '0' * 40)
for case in ['corrupt inventory', 'wrong artifact size', 'unknown executable ABI', 'summary hash mismatch']:
    with tempfile.TemporaryDirectory(prefix='emaxx-retained-negative-') as directory:
        temporary = Path(directory)
        for source in original.rglob('*'):
            if not source.is_file():
                continue
            if source.name not in ['summary.json', 'manifest.json', 'inventory.txt', 'libtest'] and source.suffix != '.pdmp':
                continue
            target = temporary / source.relative_to(original)
            target.parent.mkdir(parents=True, exist_ok=True)
            if source.name == 'libtest' or source.suffix == '.pdmp':
                os.link(source, target)
            else:
                shutil.copy2(source, target)
        summary = temporary / 'summary.json'
        manifest = temporary / 'retained-inputs/manifest.json'
        if case == 'corrupt inventory':
            (temporary / 'inventory.txt').write_text('changed: test\n')
        elif case == 'wrong artifact size':
            data = json.loads(manifest.read_text())
            data['files'][0]['bytes'] += 1
            manifest.write_text(json.dumps(data))
        elif case == 'unknown executable ABI':
            data = json.loads(summary.read_text())
            data['test_binary']['sha256'] = '0' * 64
            summary.write_text(json.dumps(data))
            data = json.loads(manifest.read_text())
            data['gate_summary_sha256'] = driver.sha(summary)
            manifest.write_text(json.dumps(data))
        else:
            summary.write_text(summary.read_text() + '\n')
        reject(case, temporary)

names = ['tools/diagnose_exact_weak_roots.py', 'tools/diagnostics/exact-weak-root-watch.py']
for name in names:
    ast.parse((root / name).read_text())
result = {'retained_full_gate_inputs_accepted': True, 'negative_controls': controls,
          'source_hashes': {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in names},
          'qualification': 'Artifact validation and syntax only; GDB execution requires Linux CI.'}
with Path(sys.argv[2]).open('x') as stream:
    json.dump(result, stream, indent=2)
print(json.dumps(result, indent=2))
