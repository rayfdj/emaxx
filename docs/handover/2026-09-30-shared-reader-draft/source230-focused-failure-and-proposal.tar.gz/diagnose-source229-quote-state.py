from pathlib import Path
import hashlib,json,os,runpy,time
p=Path(__file__).parent.resolve();root=p.parent/'recovered-2026-09-30/string-bytes/emaxx';gnu=p.parent/'recovered-2026-09-30/emacs'
module=runpy.run_path(str(root/'tools/ttydiff.py'),run_name='diagnostic_only')
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
subject=root/'target/frame-validation/release/emaxx'
fixture=p/'source229-quote-state.dat'
with fixture.open('x') as f:f.write('Quote state diagnostic\n')
expression='(list noninteractive (text-quoting-style) internal--text-quoting-flag (char-table-p standard-display-table) (and (char-table-p standard-display-table) (aref standard-display-table 8216)) (and (char-table-p standard-display-table) (aref standard-display-table 8217)) (append (substitute-command-keys "Here\'s the first part of its description:") nil) (terminal-coding-system) locale-coding-system)'
inputs={str(f):sha(f) for f in [subject,subject.with_suffix('.pdmp'),gnu/'src/emacs',gnu/'src/emacs.pdmp',root/'tools/ttydiff.py',Path(__file__)]}
records=[]
for label,binary in [('gnu',gnu/'src/emacs'),('emaxx',subject)]:
    output=p/('source229-quote-state-'+label+'.el')
    assert not output.exists()
    form='(progn (with-temp-file '+json.dumps(str(output))+' (prin1 '+expression+' (current-buffer))) (kill-emacs))'
    argv=[str(binary),'-Q','-nw']
    env={'LANG':'C','LC_ALL':'C'}
    if label=='gnu':argv+=['--eval',module['gnu_no_window_setup'](str(gnu/'lisp'))]
    else:env['EMACSLOADPATH']=os.pathsep.join([str(gnu/'lisp')]+sorted(str(f) for f in (gnu/'lisp').iterdir() if f.is_dir()))
    argv.append(str(fixture))
    command={'command':argv,'environment_override':env,'form':form,'inputs':inputs,'qualification':'Separate interactive quoting diagnosis; normal -Q startup and inherited HOME, same C locale and xterm environment as complete ttydiff. Not a terminal-pass or performance claim.'}
    with (p/('source229-quote-state-'+label+'-command.json')).open('x') as f:json.dump(command,f,indent=2)
    session=module['Session'](argv,env)
    start=time.monotonic()
    try:
        session.wait_boot(module['STARTUP_WAIT_SECONDS'])
        session.wait_for_screen_text(fixture.name[:16],module['STARTUP_WAIT_SECONDS'])
        session.send(b'\x1b:'+form.encode()+b'\r',settle=30,quiet=0.5)
        record={'editor':label,'elapsed_seconds':time.monotonic()-start,'output_exists':output.is_file(),'screen':session.screen.lines(),'inputs_unchanged':all(sha(Path(f))==h for f,h in inputs.items())}
        if output.exists():record.update(output=output.read_text(),output_sha256=sha(output))
        with (p/('source229-quote-state-'+label+'-result.json')).open('x') as f:json.dump(record,f,indent=2)
        records.append(record)
        print(label,record.get('output',record['screen']),flush=True)
    finally:session.close()
with (p/'source229-quote-state-results.json').open('x') as f:json.dump(records,f,indent=2)
