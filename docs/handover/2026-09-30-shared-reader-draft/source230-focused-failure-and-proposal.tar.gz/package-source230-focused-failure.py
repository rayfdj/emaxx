from pathlib import Path
import ast,gzip,hashlib,io,json,re,tarfile
p=Path(__file__).parent.resolve();root=p.parents[2];out=root/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest();read=lambda name:json.loads((p/name).read_text())
node=next(n for n in ast.parse((p/'audit-shared-reader196-fresh-selected.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='audit_log')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<raw-auditor>','exec'))
command=read('source230-gate-controls-command.json');result=read('source230-gate-controls-result.json');raw=(p/'source230-gate-controls.log').read_text()
assert result['exit_code']==101 and result['source_unchanged']
assert len(command['selected_inventory'])==31
failures=audit_log(command['selected_inventory'],raw,30,1)
assert failures==['lisp::eval::tests::eval_02::quoted_bytecode_reader_forms_are_materialized_as_records']
assert "evaluation failed: Symbol's function definition is void: cadr" in raw
binary=p/'source230-gate-libtest';assert sha(binary.read_bytes())==command['binary_sha256']
record=dict(status='30 focused passes; added bare-interpreter fixture setup fails',passed=30,failed=1,ignored=0,failures=failures,binary_sha256=command['binary_sha256'],
    qualification='All three canonical substring controls and every preceding string/bytecode/completion control pass. The original quoted-reader macro and new closure-kind assertions execute before the added normal-GNU fixture fails because Interpreter::new has not loaded Lisp cadr. The fixture and GNU output remain unchanged. Proposed source231 supplies the normal batch preload only for that added contract; it is unexecuted. The 937-test broader run and fresh ordinary build/comparisons remain active; no broad, release or full-platform pass is assigned.')
with (p/'source230-focused-audit.json').open('x') as f:json.dump(record,f,indent=2)
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
names=['source230-gate-controls-command.json','source230-gate-controls-result.json','source230-gate-controls.log','source230-gate-build-command.json','source230-gate-build-result.json','source230-gate-build.log','source230-gate-inventory.txt','source230-focused-audit.json','source230-ordinary-launch.json','run-source230-build-and-ordinary.py','build-string230.py','run-source230-ordinary.py','compare-source230-fixtures.py','source231-proposal.json','source231-proposed/src/lisp/eval/tests/eval_02.rs',Path(__file__).name,'audit-shared-reader196-fresh-selected.py']
files={name:p/name for name in names}
files.update({f.name:f for f in p.glob('source229-quote-state*') if f.is_file()})
files['diagnose-source229-quote-state.py']=p/'diagnose-source229-quote-state.py'
package('source230-focused-failure-and-proposal',files,record)
