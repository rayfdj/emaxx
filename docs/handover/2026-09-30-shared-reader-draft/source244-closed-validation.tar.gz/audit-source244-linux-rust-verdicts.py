from pathlib import Path
import hashlib, json, re

p = Path(__file__).parent.resolve()
root = p / 'source244-linux-rust-artifacts/rust'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
read = lambda file: json.loads(file.read_text())
s = read(root / 'summary.json')
assert s['status'] == 'failed' and s['scope'] == 'full'
assert s['git'] == {'head': '578955b36bedd6afc986f969efec76571fefcbfd', 'dirty': False}
assert s['runs'] == s['cargo_stages'] == []
inventory = [line[:-6] for line in (root / 'inventory.txt').read_text().splitlines() if line.endswith(': test')]
assert len(inventory) == len(set(inventory)) == 3005 == s['inventory']['scheduled_tests']
assert hashlib.sha256(('\n'.join(inventory) + '\n').encode()).hexdigest() == s['inventory']['sha256']
verdicts = {}
groups = []
for group in ['eval_01', 'eval_02', 'eval_03', 'eval_04', 'eval_05', 'primitives']:
    raw = (root / ('repeat-01-' + group + '.log')).read_text()
    starts = list(re.finditer(r'^test (\S+) \.\.\. ', raw, re.M))
    assert len(starts) == s['inventory']['groups'][group]
    found = []
    for index, match in enumerate(starts):
        end = starts[index + 1].start() if index + 1 < len(starts) else raw.rindex('test result:')
        block = raw[match.end():end].split('\n\nfailures:')[0].strip()
        final = re.search(r'(?:^|\s)(ok|FAILED)$', block)
        assert final, (match[1], block)
        assert match[1] not in verdicts and match[1] in inventory
        verdicts[match[1]] = final[1]
        found.append(final[1])
    passed, failed = found.count('ok'), found.count('FAILED')
    summary = re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', raw, re.M)
    assert summary == [('FAILED' if failed else 'ok', str(passed), str(failed), '0')]
    groups.append(dict(group=group, passed=passed, failed=failed, ignored=0))
failed = [name for name, verdict in verdicts.items() if verdict == 'FAILED']
assert failed == ['lisp::primitives::tests::native_pseudovector_census_matches_gnu_word_layout', 'lisp::primitives::tests::native_vector_and_closure_census_matches_gnu_word_layout']
assert sum(row['passed'] for row in groups) == 2258 and len(verdicts) == 2260
raw = (root / 'repeat-01-primitives.log').read_text()
assert 'oracle disagreed; program sent was:' in raw
actual = [json.loads(value) for value in re.findall(r'^  left: (".*")$', raw, re.M)]
expected = [json.loads(value) for value in re.findall(r'^ right: (".*")$', raw, re.M)]
assert len(actual) == len(expected) == 2
assert actual[0].startswith('(((0 -7)') and expected[0].startswith('(((0 2)')
assert actual[0].replace('(((0 -7)', '(((0 2)', 1) == expected[0]
assert actual[1].startswith('(((0 -9)') and expected[1].startswith('(((0 0)')
assert actual[1].replace('(((0 -9)', '(((0 0)', 1) == expected[1]
retained = root / 'retained-inputs'
record = read(retained / 'manifest.json')
assert record['status'] == 'retained' and record['gate_status'] == 'failed'
assert record['gate_summary_sha256'] == sha(root / 'summary.json')
assert len(record['files']) == 2
for entry in record['files']:
    file = retained / entry['artifact']
    assert file.stat().st_size == entry['bytes'] and sha(file) == entry['sha256']
assert sha(retained / 'libtest') == s['test_binary']['sha256']
download = read(p / 'source244-linux-rust-download.json')
assert sha(p / 'source244-linux-rust-artifact.zip') == download['archive_sha256']
for name, digest in download['files'].items():
    assert sha(root.parent / name) == digest
unstarted = sorted(set(inventory) - set(verdicts))
assert len(unstarted) == 745
audit = dict(status='failed', source_commit=s['git']['head'], run_id=36830879269,
             library_passed=2258, library_failed=2, library_ignored=0,
             unstarted_library_tests=unstarted, unstarted_cargo_stages=['bins', 'integration'],
             failed_tests=failed, groups=groups, raw_verdicts=verdicts,
             actual_gnu_output=actual, expected_fixture_output=expected,
             binary_sha256=s['test_binary']['sha256'], retained_files=record['files'],
             goal_complete=False,
             qualification='The helper asserts GNU output before creating or evaluating the Emaxx interpreter. Both failures are GNU reference assertions: the first empty-record sample is -7 rather than 2 slots, and the first empty-vector sample is -9 rather than 0. All later samples match. Neither control reaches its Emaxx comparison. The actual GNU executable and dump were not retained by this full job; the cause is unresolved. Its expectation is unchanged. Four later library groups (including two existing ignores) and both Cargo stages never run. A fresh selected replay is diagnosis only and cannot change this failed full-run result.')
with (p / 'source244-linux-rust-failure-audit.json').open('x') as f:
    json.dump(audit, f, indent=2)
print(json.dumps({key: audit[key] for key in ['status', 'library_passed', 'library_failed', 'failed_tests']}, indent=2))
