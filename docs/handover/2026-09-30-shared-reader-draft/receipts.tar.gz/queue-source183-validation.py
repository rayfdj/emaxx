from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

p = Path(__file__).parent.resolve()
root = p.parent / "recovered-2026-09-30/frontend-reader/emaxx"
manifest = json.loads((p / "source183-manifest.json").read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
unchanged = lambda: all(sha(root / name) == digest for name, digest in manifest.items())
steps = [["check-reader183.py", "183"], ["static-reader183.py", "183"],
         ["test-reader183.py", "183", "gate"], ["test-reader183.py", "183", "release"],
         ["build-reader183.py", "183"],
         ["compare-recovered-continuation-fixtures.py", "source183", str(root),
          "input-decode-general", "input-decode-extra", "input-decode-pipeline",
          "input-decode-reader-contract", "input-decode-case-state", "input-decode-xt-setup", "input-decode-case-variants", "input-decode-command-reader", "input-decode-macro-shared", "input-decode-autoload-prefix", "input-decode-first-unbound", "input-decode-shift-tab-variants"]]
results = []
for args in steps:
    assert unchanged()
    result = subprocess.run([sys.executable, str(p / args[0]), *args[1:]], check=False)
    results.append({"script": args, "exit_code": result.returncode, "source_unchanged": unchanged()})
    if result.returncode or not unchanged():
        break
with (p / "source183-selected-validation-result.json").open("x") as stream:
    json.dump({"steps": results, "all_completed": len(results) == len(steps),
               "source_unchanged": unchanged(), "completed_unix": time.time(),
               "qualification": "Selected common-reader integration only; full-source compatibility, broader reader contracts and complete goal requirements remain open."}, stream, indent=2)
raise SystemExit(0 if len(results) == len(steps) and all(item["exit_code"] == 0 and item["source_unchanged"] for item in results) else 1)
