from pathlib import Path
import hashlib, json, os, subprocess, sys, time

p = Path(__file__).parent.resolve()
runtime = p.parent / 'recovered-2026-09-30/frontend-reader/emaxx'
harness = p.parent / 'recovered-2026-09-30/macro-reader/emaxx'
tag = 'source185-prompt-corrected-tty'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
manifests = {runtime: json.loads((p / 'source185-manifest.json').read_text()),
             harness: json.loads((p / 'source188-manifest.json').read_text())}
unchanged = lambda: all(sha(root / name) == digest for root, manifest in manifests.items()
                        for name, digest in manifest.items())
assert unchanged()
binary = runtime / 'target/frame-validation/release/emaxx'
gnu = p.parent / 'recovered-2026-09-30/emacs/src/emacs'
stage = p / 'tty-prompt-correction'
inputs = {str(f): sha(f) for f in [binary, binary.with_suffix('.pdmp'), gnu,
          gnu.with_suffix('.pdmp'), stage / 'tools/ttydiff.py', stage / 'tools/fixtures/fieldnotes.org', stage / 'tools/fixtures/fake_lsp_server.py', Path(__file__)]}
names = ['reader-minibuffer-input-translation']
command = ['/usr/bin/caffeinate', '-i', sys.executable, '-B', str(stage / 'tools/ttydiff.py'),
           str(binary), str(gnu), str(gnu.parent.parent / 'lisp'), *names]
with (p / (tag + '-command.json')).open('x') as f:
    json.dump({'command': command, 'working_directory': str(harness), 'inputs': inputs,
               'runtime_source': 'source185-manifest.json', 'harness_source': 'source188-manifest.json',
               'environment_overrides': {'EMAXX_TTYDIFF_REQUIRE': '1'}, 'inventory': names, 'harness_patch': 'reader-minibuffer-prompt-correction.patch',
               'qualification': 'Supplemental source185 minibuffer terminal comparison using a staged copy of source188 harness plus the recorded new-test prompt correction. Original failed startup and failed presence assertion are preserved. No source188 runtime, full-terminal or performance claim.'}, f, indent=2)
start = time.monotonic()
with (p / (tag + '.log')).open('x') as log:
    run = subprocess.run(command, cwd=harness,
                         env={**os.environ, 'EMAXX_TTYDIFF_REQUIRE': '1'},
                         stdout=log, stderr=subprocess.STDOUT)
result = {'exit_code': run.returncode, 'elapsed_seconds': time.monotonic() - start,
          'source_unchanged': unchanged(),
          'inputs_unchanged': all(sha(Path(f)) == h for f, h in inputs.items())}
with (p / (tag + '-result.json')).open('x') as f:
    json.dump(result, f, indent=2)
print(json.dumps(result), flush=True)
raise SystemExit(run.returncode or (0 if result['source_unchanged'] and result['inputs_unchanged'] else 2))
