
                (let* ((map (make-sparse-keymap))
                       (origin (selected-window))
                       (other-window
                        (split-window-internal origin 12 nil 0.5))
                       (other-buffer (get-buffer-create "*command-window*"))
                       shifted-tab-ran)
                  (set-window-buffer other-window other-buffer)
                  (define-key map [backtab]
                    (lambda ()
                      (interactive)
                      (setq shifted-tab-ran t)))
                  (use-local-map map)
                  (execute-kbd-macro (kbd "S-TAB"))
                  (define-key map "x"
                    (lambda ()
                      (interactive)
                      (select-window other-window)
                      (save-current-buffer (set-buffer (window-buffer origin)))))
                  (execute-kbd-macro "x")
                  (list shifted-tab-ran
                        (eq (current-buffer)
                            (window-buffer (selected-window)))))
                