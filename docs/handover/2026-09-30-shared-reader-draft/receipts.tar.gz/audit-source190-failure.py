from pathlib import Path
import hashlib
import json
import re

p = Path(__file__).parent.resolve()
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())


def audit_log(names, log, expected_passed, expected_failed):
    assert len(names) == len(set(names))
    summaries = re.findall(
        r"^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;",
        log, re.M)
    assert summaries == [("FAILED" if expected_failed else "ok",
                          str(expected_passed), str(expected_failed), "0")]
    starts = list(re.finditer(r"^test (\S+) \.\.\. ", log, re.M))
    assert sorted(item[1] for item in starts) == sorted(names)
    counts = {"ok": 0, "FAILED": 0}
    failures = []
    for index, item in enumerate(starts):
        end = starts[index + 1].start() if index + 1 < len(starts) else log.index("\n\nfailures:") if expected_failed else log.rindex("test result:")
        verdict = re.search(r"(?:^|\s)(ok|FAILED)$", log[item.end():end].strip())
        assert verdict, item[1]
        counts[verdict[1]] += 1
        if verdict[1] == "FAILED":
            failures.append(item[1])
    assert counts == {"ok": expected_passed, "FAILED": expected_failed}
    return failures


command = read('source190-gate-selected-command.json')
result = read('source190-gate-selected-result.json')
assert result['exit_code'] == 101 and result['source_unchanged']
names = command['selected_inventory']
failures = audit_log(names, (p / 'source190-gate-selected.log').read_text(), 428, 1)
assert failures == ['batch::tests::xt_mouse_read_key_discards_the_unbound_down_event']
assert sha((p / 'source190-gate-libtest').read_bytes()) == command['binary_sha256']
new = [name for name in names if name.endswith(('input_decode_mouse_menu_uses_unchanged_lisp_translation', 'input_decode_mouse_translation_preserves_raw_spine_and_live_event_kind', 'input_decode_non_mouse_menu_events_mark_the_shared_position'))]
assert len(new) == 3 and not set(new).intersection(failures)
for required in ['threads_retain_lexical_caller_roots_across_separate_callee_environments', 'suspended_bytecode_retains_operand_and_unwind_roots']:
    assert any(name.endswith('::' + required) for name in names)
with (p / 'source190-failed-gate-evidence-audit.json').open('x') as f:
    json.dump({'raw_passed': 428, 'raw_failed': 1, 'raw_ignored': 0, 'failures': failures, 'new_mouse_controls_passed': new, 'inventory_and_binary_verified': True, 'qualification': 'The gate remains failed. Release, ordinary and terminal validation did not run.'}, f, indent=2)
print('Verified source190 failed gate: 428 pass, 1 original XTerm failure, all three new controls pass.')
