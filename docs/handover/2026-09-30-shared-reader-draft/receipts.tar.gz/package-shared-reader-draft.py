from pathlib import Path
import hashlib
import json
import re
import tarfile
import time

p = Path(__file__).parent.resolve()
repository = p.parents[2]
destination = repository / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()

# Only package terminal runs. A failure is preserved, not turned into a pass.
validation = json.loads((p / 'source191-selected-validation-result.json').read_text())
terminal = next((f for f in [p / 'source191-selected-tty-result.json',
                            p / 'source191-selected-tty-not-run.json'] if f.exists()), None)
assert terminal is not None
patterns = [
    r'^source(?:178|179|18[0-9]|19[01])-',
    r'^source192-(?:base|manifest|patch-replay-and-modes-audit)\.json$',
    r'^source192-complete\.patch$',
    r'^(?:check|static|test|build)-(?:frontend|reader18[3-8]|reader19[0-2])',
    r'^(?:queue|run)-source(?:179|18[0-9]|19[0-2])-',
    r'^audit-(?:frontend|shared-reader|minibuffer|source18[89]|source19[0-2])',
    r'^(?:frontend|minibuffer)-patches-',
    r'^shared-reader.*-evidence-audit',
    r'^terminal-fixture-supplemental-',
    r'^reader-minibuffer-prompt-correction',
    r'^input-decode-',
    r'^(?:ding|mouse)-probe-premise-correction',
    r'^compare-recovered-continuation-fixtures\.py$',
    r'^package-shared-reader-draft\.py$',
    r'^snapshot-reader-candidate\.py$',
]
extensions = {'.json', '.log', '.txt', '.py', '.el', '.expected', '.patch',
              '.stdout', '.stderr', '.d'}
files = sorted(f for f in p.iterdir() if f.is_file() and f.suffix in extensions
               and any(re.search(pattern, f.name) for pattern in patterns))
assert files
inventory = [{'path': f.name, 'bytes': f.stat().st_size,
              'sha256': sha(f.read_bytes())} for f in files]
destination.mkdir(parents=True, exist_ok=False)
archive = destination / 'receipts.tar.gz'
with tarfile.open(archive, 'w:gz', format=tarfile.PAX_FORMAT) as bundle:
    for f in files:
        bundle.add(f, arcname=f.name, recursive=False)
with tarfile.open(archive, 'r:gz') as bundle:
    assert sorted(bundle.getnames()) == sorted(item['path'] for item in inventory)
    for item in inventory:
        assert sha(bundle.extractfile(item['path']).read()) == item['sha256']
        assert sha((p / item['path']).read_bytes()) == item['sha256']
record = {
    'status': 'Unfinished source192 shared command reader; source190 gate and source191 compiler failures preserved. Source192 validation is running and its live logs are excluded.',
    'base_commit': '21d20f0eec08f3c013d5d3eb3bd6e9cfc16b3199',
    'complete_patch': 'source192-complete.patch',
    'source_manifest': 'source192-manifest.json',
    'source_inputs': 391,
    'last_closed_source': 'source191',
    'last_closed_selected_validation': validation,
    'last_closed_terminal_validation': json.loads(terminal.read_text()),
    'captured_unix': time.time(),
    'qualification': 'Closed receipts only. Retains all failed compiler/test/helper/terminal attempts and negative comparisons. Exact patch replay is not runtime validation. Local original binaries/images remain in target; archive includes their hashes, build commands and raw results. GNU matches source/native ABI but is not the frozen Darwin executable. Complete final-source validation, remaining architecture and allocation work, adversarial audit and locked performance parity are not established.',
    'archive': {'path': archive.name, 'bytes': archive.stat().st_size,
                'sha256': sha(archive.read_bytes())},
    'files': inventory,
}
with (destination / 'manifest.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps({'files': len(inventory), 'archive': record['archive'],
                  'destination': str(destination)}))
