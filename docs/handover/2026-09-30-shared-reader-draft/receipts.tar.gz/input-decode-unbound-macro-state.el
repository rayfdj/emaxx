(let* ((saved-map (current-global-map))
      (overriding-terminal-local-map nil)
      (inhibit-message t)
      (ring-bell-function (lambda () nil))
      (trace nil)
      (pre-command-hook (list (lambda () (push this-command trace)))))
  (unwind-protect
      (progn
        (use-global-map (make-sparse-keymap))
        (execute-kbd-macro "x")
        (list (nreverse trace) this-command last-command))
    (use-global-map saved-map)))
