from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).parent.resolve()
read=lambda name:json.loads((p/name).read_text())
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
prior=read('source281-gate-controls-command.json')
binary=Path(prior['command'][0])
assert sha(binary)==prior['binary_sha256']
root=Path(prior['working_directory'])
manifest=read('source281-manifest.json')
unchanged=lambda:all(sha(root/name)==h for name,h in manifest.items())
name='lisp::primitives::tests::make_network_process_coding_precedence_matches_gnu'
command=[str(binary),name,'--exact','--test-threads=1','--nocapture']
assert unchanged() and name in prior['selectors']
with (p/'source281-socket-permitted-command.json').open('x') as f:json.dump(dict(command=command,working_directory=str(root),environment_override=prior['environment_override'],binary_sha256=sha(binary),helper_sha256=sha(Path(__file__)),timeout_seconds=120,qualification='Exact original test and binary with permission for loopback sockets. Retains original214-pass/one-failure focused result; this separate replay cannot replace complete focused or affected coverage.'),f,indent=2)
started=time.monotonic()
with (p/'source281-socket-permitted.log').open('xb') as f:
    run=subprocess.run(command,cwd=root,env=dict(os.environ,**prior['environment_override']),stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,timeout=120)
result=dict(exit_code=run.returncode,source_unchanged=unchanged(),binary_unchanged=sha(binary)==prior['binary_sha256'],elapsed_seconds=time.monotonic()-started)
with (p/'source281-socket-permitted-result.json').open('x') as f:json.dump(result,f,indent=2)
assert run.returncode==0 and result['source_unchanged'] and result['binary_unchanged']
assert 'test result: ok. 1 passed; 0 failed; 0 ignored;' in (p/'source281-socket-permitted.log').read_text()
print(json.dumps(result))
