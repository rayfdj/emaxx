from pathlib import Path
import hashlib,json,os,subprocess,time

p=Path(__file__).parent.resolve()
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
fixture=p/'printer-native-literals-83729.el'
binaries={'gnu':p.parent/'rebuilt-2026-10-01/emacs/src/emacs','source279':p.parent/'recovered-2026-09-30/string-allocation-recovery/emaxx/target/string-sblock-validation/release/emaxx','source281':p.parent/'recovered-2026-09-30/string-print-decoder/emaxx/target/printer-character-validation/release/emaxx'}
results={}
for label,binary in binaries.items():
    stem=p/('printer-native-literals-'+label)
    inputs={str(f):sha(f) for f in [binary,binary.with_suffix('.pdmp'),fixture,Path(__file__)]}
    command=[str(binary),'-Q','--batch','--eval','(prin1 '+fixture.read_text()+')']
    env=dict(LANG='C',LC_ALL='C',EMAXX_GC_VERIFY='1')
    with stem.with_suffix('.command.json').open('x') as f:json.dump(dict(command=command,working_directory=str(p),inputs=inputs,environment_override=env,timeout_seconds=120),f,indent=2)
    started=time.monotonic()
    try:
        run=subprocess.run(command,cwd=p,env=dict(os.environ,**env),stdin=subprocess.DEVNULL,capture_output=True,timeout=120)
        code,stdout,stderr,timed_out=run.returncode,run.stdout,run.stderr,False
    except subprocess.TimeoutExpired as error:code,stdout,stderr,timed_out=None,error.stdout or b'',error.stderr or b'',True
    for suffix,data in [('stdout',stdout),('stderr',stderr)]:
        with stem.with_suffix('.'+suffix).open('xb') as f:f.write(data)
    result=dict(exit_code=code,timed_out=timed_out,elapsed_seconds=time.monotonic()-started,stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest(),inputs_unchanged=all(sha(Path(f))==h for f,h in inputs.items()))
    with stem.with_suffix('.result.json').open('x') as f:json.dump(result,f,indent=2)
    results[label]=result
    print(label,result,stdout[:200],stderr[:300],flush=True)
oracle=(p/'printer-native-literals-gnu.stdout').read_bytes()
assert results['gnu']['exit_code']==0 and not (p/'printer-native-literals-gnu.stderr').read_bytes() and oracle.startswith(b'(t t t ')
matches={label:(p/('printer-native-literals-'+label+'.stdout')).read_bytes()==oracle and not (p/('printer-native-literals-'+label+'.stderr')).read_bytes() and row['exit_code']==0 and not row['timed_out'] and row['inputs_unchanged'] for label,row in results.items()}
with (p/'printer-native-literals-comparison.json').open('x') as f:json.dump(dict(results=results,matches_gnu=matches,qualification='Ordinary native compilation of an actual quoted shared vector with full-range string constants and properties; checks native execution, post-GC values and shared identity. No execution fallback or output normalization.'),f,indent=2)
assert matches['source281']
