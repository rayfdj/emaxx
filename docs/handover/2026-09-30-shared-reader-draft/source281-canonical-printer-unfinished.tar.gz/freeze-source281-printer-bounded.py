from pathlib import Path
import hashlib, io, json, os, re, subprocess, tarfile, tempfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
c = p.parent / 'recovered-2026-09-30/string-print-decoder/emaxx'
failed = p.parent / 'recovered-2026-09-30/string-print-characters/emaxx'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
current, prior, predecessor = [read('source' + str(n) + '-manifest.json') for n in [281,279,280]]
assert len(current) == len(predecessor) == 514 and len(prior) == 511
assert all(sha(c / name) == digest for name,digest in current.items())
assert all(sha(root / name) == digest for name,digest in prior.items())
assert all(sha(failed / name) == digest for name,digest in predecessor.items())
assert [n for n in current if current[n] != predecessor[n]] == ['src/lisp/types/string_data.rs']
old = (failed / 'src/lisp/types/string_data.rs').read_text()
assert old.replace('fn decode_character(', 'pub(crate) fn decode_character(', 1) == (c / 'src/lisp/types/string_data.rs').read_text()
new = {'src/lisp/primitives/print/output.rs','tests/fixtures/printer-full-range-streams.el','tests/fixtures/printer-full-range-streams.expected'}
assert set(current) - set(prior) == new
assert all(current[n] == h for n,h in prior.items() if n.startswith('tests/'))
test_addition = '''#[test]
fn printer_preserves_full_character_codes_in_strings_buffers_and_callbacks() {
    assert_oracle_contract_matches_interpreter(
        include_str!("../../../tests/fixtures/printer-full-range-streams.el"),
        include_str!("../../../tests/fixtures/printer-full-range-streams.expected").trim_end(),
        "printer codes, escaping, round-trip reading and real output destinations",
    );
}

'''
test_source = (c / 'src/lisp/primitives/tests.rs').read_text()
assert test_source.count(test_addition) == 1
assert test_source.replace(test_addition, '', 1) == (root / 'src/lisp/primitives/tests.rs').read_text()
inventory = lambda tag: {s[:-6] for s in (p / (tag + '-gate-inventory.log')).read_text().splitlines() if s.endswith(': test')}
assert inventory('source281') - inventory('source279') == {'lisp::primitives::tests::printer_preserves_full_character_codes_in_strings_buffers_and_callbacks'}
assert inventory('source279') < inventory('source281') and len(inventory('source281')) == 3030
for stage in ['fmt','check','clippy','diff','gate-build','streams-control']:
    result = read('source281-' + stage + '-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
    raw = (p / ('source281-' + stage + '.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
    for line in raw.splitlines():
        if line.startswith('{'):
            assert json.loads(line).get('message', {}).get('level') not in ['warning','error']
assert 'test result: ok. 1 passed; 0 failed; 0 ignored;' in (p / 'source281-streams-control.log').read_text()
names = list(read('source279-selected-audit.json')['ordinary_results'])
assert len(names) == 37
ordinary = {}
for name in names + ['printer-full-range-streams']:
    comparison = read('source281-ordinary-' + name + '-comparison.json')
    assert comparison['passed'] and comparison['exact_match']
    pair = []
    for editor in ['gnu','emaxx']:
        stem = 'source281-ordinary-' + name + '-' + editor
        command = read(stem + '.command.json')
        result = read(stem + '.result.json')
        assert all(sha(Path(n)) == h for n,h in command['inputs'].items())
        assert result['exit_code'] == 0 and not result['timed_out'] and result['source_unchanged'] and result['inputs_unchanged']
        stdout,stderr = [(p / (stem + '.' + suffix)).read_bytes() for suffix in ['stdout','stderr']]
        assert stdout and not stderr
        assert hashlib.sha256(stdout).hexdigest() == result['stdout_sha256'] and stderr.hex() == result['stderr_hex']
        if name in names:
            assert stdout == (p / ('source279-ordinary-' + name + '-' + editor + '.stdout')).read_bytes()
        pair.append(stdout)
    assert pair[0] == pair[1]
    ordinary[name] = hashlib.sha256(pair[0]).hexdigest()
generated = read('source281-generated-loaded-comparison.json')
assert generated['passed']
for editor in ['gnu','emaxx']:
    stem = 'source281-generated-loaded-' + editor
    command,result = read(stem + '-command.json'),read(stem + '-result.json')
    assert all(sha(Path(n)) == h for n,h in command['inputs'].items())
    assert command['command'][-2:] == ['-l',str(p / 'printer-varied-v3-293638f0.el')]
    output = (p / (stem + '.stdout')).read_bytes()
    assert len(output.splitlines()) == 198 and len(output) == 4088269
    assert output == (p / 'printer-varied-v3-gnu.stdout').read_bytes()
    assert output == (p / 'source279-varied-strings-v2-gnu.stdout').read_bytes()
    assert not (p / (stem + '.stderr')).read_bytes()
    assert sha(p / (stem + '.stdout')) == result['stdout_sha256']
assert read('source281-ordinary-generated-runner-correction.json')['status'] == 'invalid generated-case coverage; not a pass'
for path,record in read('source281-ordinary-artifacts.json').items():
    assert sha(Path(path)) == sha(Path(record['immutable_copy'])) == record['sha256']
patches = []
base = 'd64040a7efe9a5039750b7c0b8feb7796c57fe79'
main = '21d20f0eec08f3c013d5d3eb3bd6e9cfc16b3199'
for tag,directory,manifest in [('source280',failed,predecessor),('source281',c,current)]:
    for label,commit in [('incremental',base),('complete',main)]:
        data = subprocess.check_output(['git','diff','--binary',commit,'--',*sorted(manifest)],cwd=directory)
        for name in sorted(new):
            added = subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',name],cwd=directory,capture_output=True)
            assert added.returncode == 1 and not added.stderr
            data += added.stdout
        name = tag + '-portable-' + label + '.patch'
        with (p / name).open('xb') as stream: stream.write(data)
        if label == 'incremental': assert data == (p / (tag + '-printer.patch')).read_bytes()
        tracked = set(subprocess.check_output(['git','ls-tree','-r','--name-only',commit],cwd=root,text=True).splitlines())
        archive = subprocess.check_output(['git','archive',commit,'--',*sorted(tracked & manifest.keys())],cwd=root)
        with tempfile.TemporaryDirectory(prefix='emaxx-printer-replay-',dir='/private/tmp') as temp:
            target = Path(temp)
            with tarfile.open(fileobj=io.BytesIO(archive)) as source:
                for item in source:
                    assert not Path(item.name).is_absolute() and '..' not in Path(item.name).parts
                    dest = target / item.name
                    if item.isdir(): dest.mkdir(parents=True,exist_ok=True)
                    else:
                        assert item.isfile()
                        dest.parent.mkdir(parents=True,exist_ok=True)
                        dest.write_bytes(source.extractfile(item).read())
                        os.chmod(dest,0o755 if item.mode & 0o111 else 0o644)
            subprocess.run(['git','apply','--check',str(p / name)],cwd=target,check=True)
            subprocess.run(['git','apply',str(p / name)],cwd=target,check=True)
            assert all(sha(target / n) == h for n,h in manifest.items())
            assert all((target/n).stat().st_mode & 0o777 == (directory/n).stat().st_mode & 0o777 for n in manifest)
        patches.append(dict(patch=name,sha256=sha(p/name),base=commit,inputs=len(manifest),bytes_and_modes='exact'))
g = p.parent / 'rebuilt-2026-10-01/emacs'
record = dict(status='bounded strict/stream/ordinary checks pass; native literal probe and selected focused run remain failed',source_inputs=514,original_tests_and_fixtures='unchanged; one additional stream fixture/control',prior_ordinary=37,new_stream_fixture=1,generated_rows=198,ordinary_sha256=ordinary,generated=generated,portable_replays=patches,gnu_mechanisms=dict(inputs={n:sha(g/n) for n in ['src/print.c','src/character.h','src/comp.c']},references=['print.c:print_object Lisp_String fetch_string_char_advance before escaping; full Emacs code range and BYTE8 handling','print.c:print_string/strout/printchar preserve codes through string, buffer, callback and stdout destinations','comp.c static relocation serialization uses Lisp printer output']),rust_constraint='Rust str cannot represent every Emacs character. The transient printer output now holds canonical bytes and uses existing encode/decode routines. It replaces transient host text; no retained object mirror, cache or per-access registry is added. Existing buffer API still requires a Unicode view plus exact extended-character positions.',limits=['Independent native-literal probe fails: source279 native compilation errors; source281 compiles but extended string constants reload as individual raw UTF-8 bytes. Loader uses decode_utf8_bytes instead of GNU internal character decoding. This is real wrong output and source281 remains unapplied.', 'Source281 focused run214 passes/one failure/two ignores: loopback bind Operation not permitted in the sandbox. Supervisor85186 is withdrawn; preserve partial affected log and do not count unrun release stages. A permitted successor must rerun the required selection.', 'Source280 compilation failed on private decoder visibility; no runtime control ran. Source281 changes only that visibility from280.','Initial ordinary generated comparison executed only its first form with --eval; empty results explicitly invalidate that row. Whole-file successor executes all198 rows and compares4088269 bytes.','Original source279 generated53 wrong rows and source27058 wrong rows remain preserved; v3 retains and checks temporary allocation lengths, removing the unused-result warning without changing expected output.','Legacy formatting, echo/message capture, symbol and unreadable object names still use host text. Callback mutation timing and broader native serialization require separate review.','No measured performance claim; full architecture, ownership, physical accounting, final platform checks and locked16 workload criteria remain open.'],goal_complete=False)
with (p / 'source281-freeze-and-ordinary-bounded-audit.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps({k:record[k] for k in ['status','source_inputs','prior_ordinary','new_stream_fixture','generated_rows','portable_replays']},indent=2))
