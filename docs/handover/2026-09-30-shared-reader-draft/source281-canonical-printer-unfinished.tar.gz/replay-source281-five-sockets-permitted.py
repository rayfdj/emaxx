from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).parent.resolve()
read=lambda name:json.loads((p/name).read_text())
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
prior=read('source281-gate-broad-command.json')
binary=Path(prior['command'][0])
assert sha(binary)==prior['binary_sha256']
root=Path(prior['working_directory'])
manifest=read('source281-manifest.json')
unchanged=lambda:all(sha(root/name)==h for name,h in manifest.items())
names=['lisp::primitives::tests::localhost_family_fallback_opens_without_polluting_the_process_buffer', 'lisp::primitives::tests::make_network_process_coding_precedence_matches_gnu', 'lisp::primitives::tests::make_network_process_ipv4_family_prefers_an_ipv4_listener', 'lisp::primitives::tests::make_network_process_nowait_opens_on_the_next_event_pump', 'lisp::primitives::tests::native_datagram_addresses_track_udp_peer_state_and_contact_metadata']
command=[str(binary),*names,'--exact','--test-threads=1','--nocapture']
assert unchanged() and set(names)<=set(prior['selected_inventory'])
with (p/'source281-five-sockets-permitted-command.json').open('x') as f:json.dump(dict(command=command,working_directory=str(root),environment_override=prior['environment_override'],binary_sha256=sha(binary),helper_sha256=sha(Path(__file__)),timeout_seconds=120,qualification='All five original socket tests and the identical binary with permission for loopback sockets. Retains original incomplete affected result with690 passes/five failures; this separate replay cannot replace complete focused or affected coverage.'),f,indent=2)
started=time.monotonic()
with (p/'source281-five-sockets-permitted.log').open('xb') as f:
    run=subprocess.run(command,cwd=root,env=dict(os.environ,**prior['environment_override']),stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,timeout=120)
result=dict(exit_code=run.returncode,source_unchanged=unchanged(),binary_unchanged=sha(binary)==prior['binary_sha256'],elapsed_seconds=time.monotonic()-started)
with (p/'source281-five-sockets-permitted-result.json').open('x') as f:json.dump(result,f,indent=2)
assert run.returncode==0 and result['source_unchanged'] and result['binary_unchanged']
assert 'test result: ok. 5 passed; 0 failed; 0 ignored;' in (p/'source281-five-sockets-permitted.log').read_text()
print(json.dumps(result))
