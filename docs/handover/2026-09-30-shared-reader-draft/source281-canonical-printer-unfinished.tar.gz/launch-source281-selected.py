from pathlib import Path
import hashlib, json, os, subprocess, sys

p = Path(__file__).parent.resolve()
c = p.parent / 'recovered-2026-09-30/string-print-decoder/emaxx'
helper = p / 'queue-source281-printer-selected.py'
command = [sys.executable, '-B', str(helper)]
with (p / 'source281-selected-driver.log').open('xb') as log:
    process = subprocess.Popen(command, cwd=c, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True, env=dict(os.environ, PYTHONUNBUFFERED='1', PYTHONDONTWRITEBYTECODE='1'))
record = dict(pid=process.pid, command=command, helper_sha256=hashlib.sha256(helper.read_bytes()).hexdigest(), source_manifest='source281-manifest.json', candidate=str(c), qualification='Launch only: 217 focused selectors and1071 affected controls in each profile. The37 prior ordinary fixtures,new stream fixture and correctly loaded198-row generated comparison already pass independently; the empty-output invocation is invalid coverage. Retain any failure; no broader pass is implied.', goal_complete=False)
with (p / 'source281-selected-launch.json').open('x') as out:
    json.dump(record, out, indent=2)
print(json.dumps(record, indent=2))
