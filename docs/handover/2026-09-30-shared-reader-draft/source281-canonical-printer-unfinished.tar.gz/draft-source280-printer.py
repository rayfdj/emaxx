from pathlib import Path
import re

p = Path(__file__).parent.resolve()
c = p.parent / 'recovered-2026-09-30/string-print-characters/emaxx'
path = c / 'src/lisp/primitives/print.rs'
s = path.read_text()
assert not s.startswith('mod output;')
s = 'mod output;\npub(crate) use output::PrintOutput;\n\n' + s
a = s.index('pub(crate) fn render_prin1_string(')
b = s.index('#[derive(Clone, Debug, PartialEq, Eq, Hash)]', a)
s = s[:a] + r'''pub(crate) fn render_prin1_string(
    interp: &Interpreter,
    state: &crate::lisp::types::SharedStringState,
    env: &Env,
) -> PrintOutput {
    let enabled = |name| interp.lookup_var(name, env).is_some_and(|value| value.is_truthy());
    let escape_multibyte = enabled("print-escape-multibyte");
    let escape_newlines = enabled("print-escape-newlines");
    let escape_control = enabled("print-escape-control-characters");
    let escape_nonascii = enabled("print-escape-nonascii");
    let multibyte = state.is_multibyte();
    let mut rendered = PrintOutput::with_capacity(state.bytes().len() + 2);
    rendered.push('"');
    let mut offset = 0;
    let mut need_nonhex = false;
    while offset < state.bytes().len() {
        // print.c:fetch_string_char_advance, before any escaping decision.
        let (code, width) = if multibyte {
            crate::lisp::types::string_data::decode_character(&state.bytes()[offset..])
                .expect("stored string character")
        } else {
            (u32::from(state.bytes()[offset]), 1)
        };
        offset += width;
        let raw = if multibyte && (0x3fff80..=0x3fffff).contains(&code) {
            Some(code - 0x3fff00)
        } else if !multibyte && code >= 128 && escape_nonascii {
            Some(code)
        } else { None };
        if let Some(byte) = raw {
            rendered.push_str(&format!("\\{byte:03o}"));
            need_nonhex = false;
        } else if multibyte && code >= 128 && escape_multibyte {
            rendered.push_str(&format!("\\x{code:04x}"));
            need_nonhex = true;
        } else {
            if code <= 127 && (code as u8).is_ascii_hexdigit() && need_nonhex {
                rendered.push_str("\\ ");
            }
            need_nonhex = false;
            match code {
                34 => rendered.push_str("\\\""),
                92 => rendered.push_str("\\\\"),
                10 if escape_newlines => rendered.push_str("\\n"),
                12 if escape_newlines => rendered.push_str("\\f"),
                code if escape_control && (code < 32 || code == 127) => {
                    let next_is_octal = state.bytes().get(offset).is_some_and(|next| (b'0'..=b'7').contains(next));
                    let digits = if code > 0o77 || next_is_octal { 3 } else if code > 0o7 { 2 } else { 1 };
                    rendered.push('\\');
                    for shift in (0..digits).rev() {
                        rendered.push_code(u32::from(b'0') + ((code >> (3 * shift)) & 7));
                    }
                }
                code if !multibyte && code >= 128 => rendered.push_code(0x3fff00 + code),
                code => rendered.push_code(code),
            }
        }
    }
    rendered.push('"');
    rendered
}

''' + s[b:]
a = s.index('fn render_princ_string(')
b = s.index('#[derive(Clone)]', a)
s = s[:a] + r'''fn render_princ_string(
    interp: &Interpreter,
    state: &crate::lisp::types::SharedStringState,
    env: &Env,
    output_is_function: bool,
) -> PrintOutput {
    let escape_nonascii = !output_is_function
        && interp.lookup_var("print-escape-nonascii", env).is_some_and(|value| value.is_truthy());
    let mut rendered = PrintOutput::with_capacity(state.bytes().len());
    let mut offset = 0;
    while offset < state.bytes().len() {
        let (code, width) = if state.is_multibyte() {
            crate::lisp::types::string_data::decode_character(&state.bytes()[offset..])
                .expect("stored string character")
        } else { (u32::from(state.bytes()[offset]), 1) };
        offset += width;
        let raw = if (0x3fff80..=0x3fffff).contains(&code) { Some(code - 0x3fff00) }
                  else if !state.is_multibyte() && code >= 128 { Some(code) }
                  else { None };
        if let Some(byte) = raw {
            if escape_nonascii { rendered.push_str(&format!("\\{byte:03o}")); }
            else if output_is_function && !state.is_multibyte() { rendered.push_code(byte); }
            else { rendered.push_code(0x3fff00 + byte); }
        } else { rendered.push_code(code); }
    }
    rendered
}

''' + s[b:]
# The recursive renderer carries canonical bytes. Existing explicitly host-text
# entry points remain wrappers, while actual Lisp streams use the output type.
split = s.index('pub(crate) fn render_prin1(\n')
prefix, suffix = s[:split], s[split:]
assert prefix.count('Result<String, LispError>') == 4
prefix = prefix.replace('Result<String, LispError>', 'Result<PrintOutput, LispError>')
prefix = prefix.replace('Result<Option<String>, LispError>', 'Result<Option<PrintOutput>, LispError>')
prefix = prefix.replace('Ok(value.to_string())', 'Ok(value.to_string().into())')
prefix = prefix.replace('return Ok(print_ref_placeholder(outer_depth));', 'return Ok(print_ref_placeholder(outer_depth).into());')
prefix = prefix.replace('format!("({} . {})", rendered.join(" "), tail_rendered)', 'PrintOutput::dotted(&rendered, tail_rendered)')
prefix = prefix.replace('format!("({} . #{})", rendered.join(" "), tortoise_index)', 'PrintOutput::dotted(&rendered, format!("#{tortoise_index}").into())')
for variable in ['rendered','rendered_items','rendered_slots','fields','rendered_fields']:
    for before,after in [('(',')'),('#(',')'),('[',']'),('#[',']'),('#^[',']'),('#^^[',']'),('#s(',')')]:
        prefix = prefix.replace('format!("'+before+'{}'+after+'", '+variable+'.join(" "))',
                                'PrintOutput::join(&'+variable+', " ").enclosed("'+before+'", "'+after+'")')
prefix = prefix.replace('rendered.map(|body| format!("#{number}={body}"))', 'rendered.map(|body| body.enclosed(&format!("#{number}="), ""))')
prefix = prefix.replace('Ok(format!("{prefix}{}", rendered?))', 'Ok(rendered?.enclosed(prefix, ""))')
prefix = prefix.replace('format!("#<symbol {rendered_symbol} at {position}>")', 'rendered_symbol.enclosed("#<symbol ", &format!(" at {position}>"))')
prefix = re.sub(r'Ok\((format!\([^\n]+\))\)', r'Ok(\1.into())', prefix)
prefix = prefix.replace('let mut rendered = String::from("#s(hash-table");', 'let mut rendered = PrintOutput::from("#s(hash-table");')
prefix = prefix.replace('rendered.push_str(&render_prin1_with_context(', 'rendered.append(&render_prin1_with_context(')
prefix = prefix.replace('rendered.push_str(&data_parts.join(" "));', 'rendered.append(&PrintOutput::join(&data_parts, " "));')
prefix = prefix.replace('let mut fields = vec![table.depth().to_string(), table.min_char().to_string()];',
                        'let mut fields = vec![PrintOutput::from(table.depth().to_string()), PrintOutput::from(table.min_char().to_string())];')
prefix = prefix.replace('Ok(render_prin1_symbol(&symbol, context.options))', 'Ok(render_prin1_symbol(&symbol, context.options).into())')
prefix = prefix.replace('Some(String::new())', 'Some(PrintOutput::default())')
prefix = prefix.replace('Ok(Some(string_text(&rendered)?))', '''let Kind::StringObject(string) = rendered.kind() else {
            return Err(LispError::WrongTypeArgument("stringp".into(), rendered));
        };
        Ok(Some(render_princ_string(interp, &string.borrow(), env, false)))''')
prefix = prefix.replace('&& let Some(text) = string_like(&replacement)', '&& let Kind::StringObject(text) = replacement.kind()')
prefix = prefix.replace('return Ok(Some(text.text));', 'return Ok(Some(render_princ_string(interp, &text.borrow(), env, false)));')
prefix = prefix.replace('''                &state.text(),
                state.is_multibyte(),''', '''                &state,''')
old = '''            let (text, props, multibyte) = {
                let state = state.borrow();
                (state.text(), state.props.to_vec(), state.is_multibyte())
            };
            if props.is_empty() {
                return Ok(render_prin1_string(interp, &text, multibyte, env));
            }
            let mut rendered = vec![render_prin1_string(interp, &text, multibyte, env)];
            let mut field_values = Vec::new();
            let keep_charset = charset_text_properties_print(interp, env, &text, multibyte, &props);'''
new = '''            let (literal, props, keep_charset) = {
                let state = state.borrow();
                let literal = render_prin1_string(interp, &state, env);
                let props = state.props.to_vec();
                let keep_charset = props.iter().any(|span| span.props.iter().any(|(name, _)| name == "charset"))
                    && charset_text_properties_print(interp, env, &state.text(), state.is_multibyte(), &props);
                (literal, props, keep_charset)
            };
            if props.is_empty() { return Ok(literal); }
            let mut rendered = vec![literal];
            let mut field_values = Vec::new();'''
assert old in prefix
prefix = prefix.replace(old,new)
prefix = prefix.replace('return Ok(render_prin1_string(interp, &text, multibyte, env));', 'return Ok(rendered.remove(0));')
# Host-only unreadable object renderers still produce ordinary Rust text.
prefix = prefix.replace('Kind::Buffer(buffer) => Ok(match interp.get_buffer_by_id(buffer.id) {', 'Kind::Buffer(buffer) => Ok(PrintOutput::from(match interp.get_buffer_by_id(buffer.id) {')
prefix = prefix.replace('None => "#<killed buffer>".into(),\n                }),', 'None => "#<killed buffer>".into(),\n                })),')
prefix = prefix.replace('Kind::Marker(marker) => Ok(match marker.buffer() {', 'Kind::Marker(marker) => Ok(PrintOutput::from(match marker.buffer() {')
prefix = prefix.replace('None => "#<marker in no buffer>".into(),\n                }),', 'None => "#<marker in no buffer>".into(),\n                })),')
prefix = prefix.replace('Ok(if state.live {', 'Ok(PrintOutput::from(if state.live {')
prefix = prefix.replace('format!("#<terminal {}>", terminal.id)\n            })', 'format!("#<terminal {}>", terminal.id)\n            }))')
prefix = prefix.replace('crate::lisp::modules::print_function(interp, id.id)', 'PrintOutput::from(crate::lisp::modules::print_function(interp, id.id))')
prefix = prefix.replace('crate::lisp::modules::print_user_pointer(interp, id.id)', 'PrintOutput::from(crate::lisp::modules::print_user_pointer(interp, id.id))')
for kind in ['thread','mutex','condvar']:
    ending = f'.unwrap_or_else(|| format!("#<{kind} 0x{{:x}}>", id.identity()))'
    assert ending in prefix
    prefix = prefix.replace(ending,ending+'.into()')
prefix = prefix.replace('render_bool_vector_prin1(interp, env, &bits, context.options)', 'render_bool_vector_prin1(interp, env, &bits, context.options).into()')
prefix = prefix.replace('format!("#<process {name}>")\n                        } else {\n                            name', 'PrintOutput::from(format!("#<process {name}>"))\n                        } else {\n                            name.into()')
prefix = prefix.replace('format!("#<obarray n={count}>")', 'PrintOutput::from(format!("#<obarray n={count}>"))')
s = prefix + suffix
# Keep the old host API explicit; ordinary Lisp streams use the new canonical API.
signature = '''pub(crate) fn render_printer_object(
    interp: &mut Interpreter,
    value: &Value,
    env: &mut Env,
    escape: bool,
    output_is_function: bool,
) -> Result<String, LispError> {'''
assert signature in s
replacement = signature + '''
    render_printer_output(interp, value, env, escape, output_is_function).map(|output| output.host_text())
}

pub(crate) fn render_printer_output(
    interp: &mut Interpreter,
    value: &Value,
    env: &mut Env,
    escape: bool,
    output_is_function: bool,
) -> Result<PrintOutput, LispError> {'''
s = s.replace(signature,replacement)
extra = '''pub(crate) fn render_prin1_output(
    interp: &mut Interpreter,
    value: &Value,
    env: &mut Env,
) -> Result<PrintOutput, LispError> {
    with_printer_buffer_escape(interp, env, Some(true), |interp, env| {
        render_printer_output(interp, value, env, true, false)
    })
}

'''
index = s.index('pub(crate) fn render_prin1(\n')
s = s[:index]+extra+s[index:]
path.write_text(s)
print('Drafted canonical recursive printer; not compiled or validated.')
