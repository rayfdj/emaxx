from pathlib import Path
import hashlib, json, re, sys

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/string-print-decoder/emaxx'
prefix = 'source' + sys.argv[1]
assert sys.argv[1].isdecimal()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read(prefix + '-manifest.json')
assert len(manifest) == 514 and all(sha(root / name) == digest for name, digest in manifest.items())
command = read(prefix + '-release-controls-command.json')
names = command['selectors']
assert len(names) == len(set(names)) == 217
assert command['command'][1:] == names + ['--exact', '--test-threads=1', '--nocapture']
prior = set(read('source249-gate-controls-command.json')['selected_inventory'])
assert len(prior) == 174 and prior <= set(names)
common_prior = read('source255-gate-controls-command.json')['selectors']
assert len(common_prior) == 184 and set(common_prior) <= set(names)
log = (p / (prefix + '-release-controls.log')).read_text()
blocks = list(re.finditer(r'^test (\S+) \.\.\. ', log, re.M))
observed = {}
for index, match in enumerate(blocks):
    stop = blocks[index + 1].start() if index + 1 < len(blocks) else log.find('\nfailures:', match.end())
    if stop < 0:
        stop = log.find('\ntest result:', match.end())
    body = log[match.end():stop]
    verdicts = re.findall(r'(?:^|[ \t\n])(ok|FAILED|ignored)(?:,[^\n]*)?\n+\Z', body)
    assert len(verdicts) == 1, (match[1], body[-500:])
    assert match[1] not in observed
    observed[match[1]] = verdicts[0]
assert set(observed) == set(names)
counts = {verdict: list(observed.values()).count(verdict) for verdict in ['ok', 'FAILED', 'ignored']}
summary = re.search(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; 0 measured; (\d+) filtered out;', log, re.M)
assert summary and tuple(map(int, summary.group(2, 3, 4))) == tuple(counts.values())
ignored = [name for name, verdict in observed.items() if verdict == 'ignored']
assert set(ignored) == {'tty::tty_differential_end_to_end', 'tty::tty_smoke_end_to_end'}
result = read(prefix + '-release-controls-result.json')
assert result['source_unchanged'] and result['exit_code'] == (101 if counts['FAILED'] else 0)
for stage in ['check', 'fmt', 'clippy', 'diff', 'release-build']:
    stage_result = read(prefix + '-' + stage + '-result.json')
    assert stage_result['exit_code'] == 0 and stage_result['source_unchanged']
    raw = (p / (prefix + '-' + stage + '.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
    for line in raw.splitlines():
        if line.startswith('{'):
            message = json.loads(line)
            assert message.get('message', {}).get('level') not in ['warning', 'error']
retained = read(prefix + '-release-focused-retained-inputs.json')['files']
assert len(retained) == 3
binary_digest = command['binary_sha256']
release_images = [item for item in retained if Path(item['original']).name.startswith('loadup-' + binary_digest[:8] + '-')]
assert len(release_images) == 1
previous = read(prefix + '-focused-retained-inputs.json')['files']
gate_images = [item for item in previous if Path(item['original']).suffix == '.pdmp']
assert len(gate_images) == 1
extra_images = [item for item in retained[1:] if item not in release_images]
assert len(extra_images) == 1
assert extra_images[0]['original'] == gate_images[0]['original']
assert extra_images[0]['sha256'] == gate_images[0]['sha256']
for item in retained:
    assert sha(Path(item['original'])) == sha(Path(item['artifact'])) == item['sha256']
assert retained[0]['sha256'] == command['binary_sha256']
record = dict(status='failed' if counts['FAILED'] else 'passed', counts=counts, raw_verdicts=observed,
              source_inputs_verified=514, prior_selectors_preserved=174, common_string_selectors_preserved=184, all_selectors=217,
              strict_checks='zero-warning pass', retained_inputs=retained,
              failed_tests=[name for name, verdict in observed.items() if verdict == 'FAILED'],
              qualification='All 217 release names and raw verdicts verified. The release binary and its exact image are retained; the third retained input is the preceding gate image, also hash-verified. The preceding source261 retention-auditor failure remains separately preserved; this source verifies the two cached images explicitly. No full Rust, frozen, terminal or performance result is inferred.')
with (p / (prefix + '-release-focused-audit.json')).open('x') as out:
    json.dump(record, out, indent=2)
print(json.dumps({key: record[key] for key in ['status', 'counts', 'failed_tests']}, indent=2))
