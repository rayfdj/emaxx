from pathlib import Path
import hashlib,json,re
p=Path(__file__).parent.resolve()
read=lambda n:json.loads((p/n).read_text())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
withdrawal=read('source281-selected-withdrawal.json')
assert withdrawal['status']=='withdrawn' and withdrawal['remaining_processes']==''
for name,digest in withdrawal['closed_logs'].items():assert sha(p/name)==digest
focused=read('source281-focused-audit.json')
assert focused['counts']==dict(ok=214,FAILED=1,ignored=2)
assert focused['failed_tests']==['lisp::primitives::tests::make_network_process_coding_precedence_matches_gnu']
raw=(p/'source281-gate-controls.log').read_text()
assert 'Cannot bind server socket' not in raw  # Lisp string payload is logged as canonical bytes.
assert '79, 112, 101, 114, 97, 116, 105, 111, 110, 32, 110, 111, 116, 32, 112, 101, 114, 109, 105, 116, 116, 101, 100' in raw
replay=read('source281-socket-permitted-result.json')
assert replay['exit_code']==0 and replay['source_unchanged'] and replay['binary_unchanged']
assert 'test result: ok. 1 passed; 0 failed; 0 ignored;' in (p/'source281-socket-permitted.log').read_text()
command=read('source281-gate-broad-command.json')
expected=command['selected_inventory'];assert len(expected)==1071
raw=(p/'source281-gate-broad.log').read_text()
assert 'test result:' not in raw and not (p/'source281-gate-broad-result.json').exists()
blocks=list(re.finditer(r'^test (\S+) \.\.\. ',raw,re.M))
completed={};incomplete=[]
for i,match in enumerate(blocks):
    end=blocks[i+1].start() if i+1<len(blocks) else len(raw)
    body=raw[match.end():end]
    verdicts=re.findall(r'(?:^|[ \t\n])(ok|FAILED|ignored)(?:,[^\n]*)?\n+\Z',body)
    assert match[1] in expected and match[1] not in completed
    if not verdicts:incomplete.append(match[1])
    else:
        assert len(verdicts)==1
        completed[match[1]]=verdicts[0]
assert len(incomplete)==1 and incomplete[0]==blocks[-1][1]
assert not (p/'source281-release-build-command.json').exists()
native=read('printer-native-literals-comparison.json')
assert native['matches_gnu']==dict(gnu=True,source279=False,source281=False)
for editor,result in native['results'].items():
    stem='printer-native-literals-'+editor
    command=read(stem+'.command.json')
    assert all(sha(Path(n))==h for n,h in command['inputs'].items())
    assert sha(p/(stem+'.stdout'))==result['stdout_sha256']
    assert sha(p/(stem+'.stderr'))==result['stderr_sha256']
assert (p/'printer-native-literals-gnu.stdout').read_bytes().startswith(b'(t t t ')
assert (p/'printer-native-literals-source281.stdout').read_bytes().startswith(b'(t t nil ')
assert native['results']['source279']['exit_code']==255
assert native['results']['source281']['exit_code']==0
counts={v:list(completed.values()).count(v) for v in ['ok','FAILED','ignored']}
result=dict(status='closed incomplete candidate; do not apply',focused=focused['counts'],focused_failure=focused['failed_tests'],socket_replay='same binary and test pass with loopback permission; original failed run remains failed',affected=dict(expected=len(expected),completed=len(completed),counts=counts,raw_verdicts=completed,incomplete=incomplete,never_started=sorted(set(expected)-set(completed)-set(incomplete))),release='never started',native=native,qualification='Partial affected outcomes are not a complete suite result. Source281 fixes198 ordinary output rows but native constants still corrupt during reload;279 compilation errors on the same control. Both original source280 compilation failure and empty-output runner mistake remain preserved. Main and applied runtime are unchanged. Broader permitted validation and native reader repair remain required.',goal_complete=False)
with (p/'source281-closed-partial-audit.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps(dict(status=result['status'],focused=result['focused'],affected=dict(expected=len(expected),completed=len(completed),counts=counts,incomplete=incomplete,never_started=len(result['affected']['never_started']))),indent=2))
