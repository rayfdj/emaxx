from pathlib import Path

p = Path(__file__).parent.resolve()
c = p.parent / 'recovered-2026-09-30/string-print-characters/emaxx'
path = c / 'src/lisp/primitives/file_io.rs'
s = path.read_text()
s = s.replace('let rendered = render_printer_object(interp, value, env, escape, output_is_function)?;',
              'let rendered = render_printer_output(interp, value, env, escape, output_is_function)?;')
s = s.replace('format!("\\n{rendered}\\n")', 'rendered.enclosed("\\n", "\\n")')
s = s.replace('let Some(last) = rendered.chars().last()', 'let Some(last) = rendered.codes().last()')
s = s.replace('write_prepared_printer_output(interp, text, stream, env)',
              'write_prepared_printer_output(interp, &PrintOutput::from(text), stream, env)')
start=s.index('fn write_prepared_printer_output(\n')
end=s.index('/// Record output that GNU',start)
s=s[:start]+'''fn write_prepared_printer_output(
    interp: &mut Interpreter,
    output: &PrintOutput,
    stream: Option<&Value>,
    env: &mut Env,
) -> Result<(), LispError> {
    match stream.map(|value| value.kind()) {
        Some(Kind::T) => {
            // Existing echo/message-capture APIs still accept host text.
            // Actual batch output consumes the canonical bytes directly.
            let text = output.host_text();
            interp.append_message_capture(&text, false, env);
            if interp.lookup_var("noninteractive", env).is_some_and(|value| value.is_truthy()) {
                crate::lisp::primitives::batch_stdout::write(output.bytes())
                    .map_err(|error| LispError::Signal(error.to_string()))?;
                interp.batch_stdout_need_newline = true;
            } else {
                crate::lisp::primitives::echo_area_print(&text);
            }
            Ok(())
        }
        None | Some(Kind::Nil | Kind::Buffer(_) | Kind::Marker(_)) => {
            let (text, extended) = output.text_parts();
            insert_text_with_hooks(interp, &text, &[], &extended, false, false, env)
        }
        Some(Kind::Symbol(name)) if name == "external-debugging-output" => {
            match interp.external_debugging_output_target.as_deref() {
                Some(path) => {
                    let mut file = fs::OpenOptions::new().create(true).append(true).open(path)
                        .map_err(|error| LispError::Signal(error.to_string()))?;
                    file.write_all(output.bytes()).map_err(|error| LispError::Signal(error.to_string()))
                }
                None => {
                    let buffer_id = interp.find_buffer(" *external-debugging-output*")
                        .map(|(id, _)| id)
                        .unwrap_or_else(|| interp.create_buffer(" *external-debugging-output*").0);
                    let mut buffer = interp.get_buffer_by_id_mut(buffer_id)
                        .ok_or_else(|| LispError::Signal(format!("No buffer with id {buffer_id}")))?;
                    let end = buffer.point_max();
                    buffer.goto_char(end);
                    let (text, extended) = output.text_parts();
                    buffer.insert(&text);
                    buffer.set_inserted_extended_chars(end, &extended);
                    Ok(())
                }
            }
        }
        Some(_) => {
            let function = *stream.expect("matched Some");
            for code in output.codes() {
                call_function_value(interp, &function, &[Value::Integer(i64::from(code))], env)?;
            }
            Ok(())
        }
    }
}

'''+s[end:]
start=s.index('pub(crate) fn record_batch_standard_output_char(')
end=s.index('/// Whether native',start)
part=s[start:end].replace('ch: char,','ch: u32,')
s=s[:start]+part+s[end:]
path.write_text(s)

path=c/'src/lisp/eval.rs'
s=path.read_text();assert s.count('batch_standard_output_last_char: Option<char>')==1
s=s.replace('batch_standard_output_last_char: Option<char>','batch_standard_output_last_char: Option<u32>')
path.write_text(s)

path=c/'src/lisp/primitives/dispatch/display.rs'
s=path.read_text()
s=s.replace("interp.batch_standard_output_last_char == Some('\\n')", "interp.batch_standard_output_last_char == Some(u32::from(b'\\n'))")
s=s.replace("record_batch_standard_output_char(interp, stream.as_ref(), env, '\\n');", "record_batch_standard_output_char(interp, stream.as_ref(), env, u32::from(b'\\n'));" )
s=s.replace('record_batch_standard_output_char(interp, stream.as_ref(), env, last);', 'record_batch_standard_output_char(interp, stream.as_ref(), env, last as u32);')
start=s.index('            "prin1-to-string" => {')
end=s.index('            "write-char" => {',start)
part=s[start:end]
part=part.replace('render_princ_object(interp, &args[0], env)', 'render_printer_output(interp, &args[0], env, false, false)')
part=part.replace('return Ok(Value::String(rendered.into()));','return rendered.into_value(interp, env);')
part=part.replace('return Ok(Value::String(render_prin1(interp, &args[0], env)?.into()));', 'return render_prin1_output(interp, &args[0], env)?.into_value(interp, env);')
part=part.replace('let rendered = render_prin1(interp, &args[0], &mut print_env)?;', 'let rendered = render_prin1_output(interp, &args[0], &mut print_env)?;')
part=part.replace('Ok(Value::String(rendered.into()))','rendered.into_value(interp, env)')
s=s[:start]+part+s[end:]
path.write_text(s)

path=c/'src/lisp/native_comp/lisp.rs'
s=path.read_text()
s=s.replace('use crate::lisp::primitives::{encode_internal_multibyte_bytes, render_prin1, string_like};',
            'use crate::lisp::primitives::{render_prin1_output, string_like};')
s=s.replace('let rendered = render_prin1(interp, value, env);','let rendered = render_prin1_output(interp, value, env);')
s=s.replace('encode_internal_multibyte_bytes(&rendered)','Ok(rendered.into_bytes())')
path.write_text(s)
print('Drafted printer destinations; no build or correctness result inferred.')
