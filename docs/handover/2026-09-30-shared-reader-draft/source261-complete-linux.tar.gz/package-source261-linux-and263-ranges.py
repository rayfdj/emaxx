from pathlib import Path
import ast
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(node for node in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(node, ast.FunctionDef) and node.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected'}
rust = read('source261-linux-rust-audit.json')
frozen = read('source261-linux-frozen-raw-integrity-audit.json')
assert rust['status'] == 'passed' and rust['total_passed'] == 3119 and rust['library_ignored'] == 2
assert read('source261-linux-rust-name-audit.json')['raw_names_verified'] == 3018
assert frozen['files'] == 519 and frozen['outcomes'] == 7928 and frozen['successful_processes'] == 1038
files = {}
for dirname in ['source261-linux-rust-artifacts', 'source261-linux-frozen-artifacts']:
    directory = p / dirname
    for file in directory.rglob('*'):
        if not file.is_file():
            continue
        name = str(file.relative_to(directory))
        if file.suffix == '.pdmp' or name in ['oracle-inputs/emacs', 'rust/retained-inputs/libtest']:
            continue
        assert not file.is_symlink()
        files[dirname + '/' + name] = file
helpers = {
    'retain-source261-linux.py', 'dispatch-source261-linux.py', 'audit-source261-linux-rust-names.py',
    'verify-source261-linux-rust.py', 'audit-source261-frozen.py', 'verify-complete-frozen-receipts.py',
    'source261-manifest.json', 'package-source196-failure-and197-results.py', Path(__file__).name,
}
for file in p.iterdir():
    if file.is_file() and file.suffix in allowed and (
        file.name.startswith(('source261-linux-rust-', 'source261-linux-frozen-')) or file.name in helpers
    ):
        files[file.name] = file
assert helpers <= files.keys()
assert sum(name.endswith('.loaded') and name.startswith('source261-linux-frozen-artifacts/') for name in files) == 1038
package('source261-complete-linux', files, dict(
    linux_rust=rust, linux_names=read('source261-linux-rust-name-audit.json'), linux_frozen=frozen,
    qualification='Exact pushed runtime eddfe782 passes complete Linux Rust with3119 tests/two existing ignores and full frozen with519 files/7928 matching outcomes/1038 successful processes. Every raw name/verdict, execution hash and actual GNU executable/dump/configuration/Makefile is verified. Expected failures/skips remain distinct. Large executable/image bytes and original CI ZIPs remain locally retained by hash. The generic historical frozen auditor retains an outdated Darwin-pin qualification; Darwin adopted29cfb20d at3dcf5351, and its current frozen/terminal results remain pending. New ordinary ordering/range/case negatives, historical failures, architecture and performance requirements remain open.'))
review = read('source263-c-reference-review.json')
assert review['source_inputs_verified'] == 500
assert all(row['exit_code'] == 0 and row['source_unchanged'] for row in review['strict_checks'].values())
assert read('source262-validation-withdrawal.json')['status'] == 'withdrawn while waiting before runtime execution'
negative = read('source261-compare-strings-negative-audit.json')
assert [row['differing_rows'] for row in negative['fixtures']] == [12, 134, 3]
assert read('source261-string-case-character-negative-audit.json')['differing_rows'] == 9
helpers = {
    'string-ranges-draft-checkout.json', 'source262-validation-withdrawal.json',
    'source262-validation-launch.json', 'source262-validation-at-packaging.json',
    'queue-string-ordering262-validation.py', 'source262-manifest.json',
    'source261-compare-strings-probes.json', 'source261-compare-strings-negative-audit.json',
    'source261-string-case-character-probes.json', 'source261-string-case-character-negative-audit.json',
    'probe-source261-compare-strings.py', 'probe-source261-string-case-character.py',
    'audit-source261-compare-strings.py',
    'check-string-ranges-draft.py', 'freeze-string-ranges.py', 'audit-source263-string-ranges-patches.py',
    'queue-string-ranges263-validation.py', 'run-string-ranges-focused.py', 'run-string-ranges-release.py',
    'audit-string-ranges-focused.py', 'audit-string-ranges-release.py', 'test-string-ranges-broad.py',
    'build-string-ranges-ordinary.py', 'compare-string-ranges-fixtures.py', 'audit-source263-selected.py',
    'audit-source262-selected.py', 'audit-source238-release.py',
    'source261-manifest.json', 'source261-selected-audit.json',
    'source261-gate-controls-command.json', 'source261-release-controls-command.json',
    'source261-gate-inventory.log', 'source261-release-inventory.log',
    'source261-gate-broad-command.json', 'source261-release-broad-command.json',
    'source249-gate-controls-command.json', 'source249-gate-broad-command.json', 'source249-release-broad-command.json',
    'source255-gate-controls-command.json', 'source255-gate-inventory.log',
    'source174-ordinary-artifacts.json', 'source261-ordinary-artifacts.json',
    'package-source196-failure-and197-results.py', Path(__file__).name,
}
fixtures = ['compare-strings-ranges', 'compare-strings-character-storage',
            'compare-strings-live-case-table', 'string-case-character-identities']
helpers.update(name + '.el' for name in fixtures)
files = {}
for path in p.iterdir():
    if not path.is_file() or path.suffix not in allowed:
        continue
    name = path.name
    include = name in helpers or any(name.startswith('source261-probe-' + fixture + '-') for fixture in fixtures)
    include |= name.startswith('source263-') and name not in ['source263-validation-driver.log', 'source263-validation-queue-state.json']
    if include:
        files[name] = path
assert helpers <= files.keys(), sorted(helpers - files.keys())
candidate = p.parent / 'recovered-2026-09-30/string-ranges/emaxx'
for fixture in fixtures + ['string-ordering-symbol-storage', 'string-version-ordering']:
    for suffix in ['.el', '.expected']:
        name = 'tests/fixtures/' + fixture + suffix
        files[name] = candidate / name
package('source263-string-ranges-draft', files, dict(
    source_review=review, comparison_negatives=negative,
    numeric_casing_negatives=read('source261-string-case-character-negative-audit.json'),
    withdrawal=read('source262-validation-withdrawal.json'), launch=read('source263-validation-launch.json'),
    qualification='Unapplied500-input successor retains all source262 ordering code/tests and repairs GNU-confirmed range validation, byte promotion, live case-table use and exact numeric character keys. Strict checks pass and both patches replay exactly. All four unchanged GNU fixtures and original negatives are retained, including main/source174 failure before its full character matrix. Source262 queue38430 was withdrawn while waiting, before any runtime stage; its source/helpers/evidence remain unchanged. Source263 queue64601 waits for full source261 macOS exit, then runs199 focused selectors/1054 affected tests per profile and28 ordinary comparisons. No runtime, complete-platform, memory or performance pass is claimed for this draft.'))
