from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
out = p.parents[2] / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
mac = read('source310-macos-rust-audit.json')
assert mac['status'] == 'passed' and mac['total_passed'] == 3150 and mac['library_ignored'] == 2
assert read('source310-macos-rust-oracle-audit.json')['status'] == 'passed'
files, excluded = {}, []
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.h', '.apparmor', '.loaded'}
for name in ['full-gate-source310', 'source310-full-retained-gnu']:
    for f in (p / name).rglob('*'):
        if not f.is_file():
            continue
        if f.suffix in allowed or f.name == 'Makefile':
            files[str(f.relative_to(p))] = f
        else:
            excluded.append(dict(path=str(f.relative_to(p)), bytes=f.stat().st_size, sha256=sha(f.read_bytes())))
for f in p.iterdir():
    if f.is_file() and f.suffix in allowed and f.name.startswith(('source310-macos-rust-',)):
        files[f.name] = f
for name in [
    'source310-full-launch.json', 'source310-full-checkout.json',
    'source310-full-rust-command.json', 'source310-full-rust-result.json', 'source310-full-rust-binary.json',
    'source310-full-rust-retention-result.json', 'source310-full-oracle-capture-command.json',
    'source310-full-oracle-capture-result.json', 'source310-full-oracle-capture.log',
    'source310-manifest.json', 'source310-applied-commit.json', 'source310-push-result.json',
    'source310-portable-complete.patch', 'source310-validation-input-recovery.json',
    'audit-source310-macos-rust-names.py', 'verify-source310-macos-rust.py',
    'package-source196-failure-and197-results.py', Path(__file__).name,
]:
    files[name] = p / name
assert all(f.is_file() for f in files.values())
package('source310-macos-rust-results', files, dict(
    status='complete source310 macOS Rust validation passed',
    source_commit='5e6f6fc89654b5e695161f5e1713d06ff8ca1f3c', macos_rust=mac,
    excluded_binaries=excluded, goal_complete=False,
    qualification='Every scheduled Rust library name and Cargo result is audited. Native artifact identity passes. macOS frozen and terminal remain separate active runs. Linux Rust still has its preserved GNU reference failure. This checkpoint does not certify source311 or the full architecture/performance goal.'))
