from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
tree = ast.parse((p / 'package-source196-failure-and197-results.py').read_text())
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected'}

def collect(directory, prefix):
    return {prefix + str(f.relative_to(directory)): f for f in directory.rglob('*') if f.is_file() and f.suffix in allowed}

files = collect(p / 'full-gate-source204', 'full-gate-source204/')
for name in ['source204-macos-rust-complete-audit.json', 'source204-macos-rust-name-audit.json',
             'source204-full-gate-command.json', 'source204-full-gate-result.json',
             'source204-full-gate.log', 'source204-manifest.json',
             'run-source204-full-gate.py', 'verify-source204-macos-rust.py',
             'audit-source204-macos-names.py', Path(__file__).name]:
    files[name] = p / name
scope = json.loads((p / 'source204-macos-rust-complete-audit.json').read_text())
scope['name_audit'] = json.loads((p / 'source204-macos-rust-name-audit.json').read_text())
package('source204-macos-complete-rust', files, scope)

linux = p / 'linux-source204-rust-artifacts'
files = collect(linux, 'linux/')
for name in ['source204-linux-rust-failure-audit.json', 'source204-linux-rust-final-state.json',
             'source204-linux-rust-ci.log', 'source204-linux-rust-download.json',
             'audit-source204-linux-failure.py', 'check-source204-census-diagnosis.py',
             'source204-census-inspected-abi.txt', 'source204-census-diagnosis-local-checks.json', Path(__file__).name]:
    files[name] = p / name
package('source204-linux-rust-failure', files, json.loads((p / 'source204-linux-rust-failure-audit.json').read_text()))

files = {}
for pattern in ['source205-*', 'source204-closure-baseline-*', 'source204-closure-controls-*',
                'source204-code-mutation-*', 'source204-active-code-mutation-*']:
    for f in p.glob(pattern):
        if f.is_file() and f.suffix in allowed:
            files[f.name] = f
for name in ['closure-representation-transitions.el', 'bytecode-closure-shared-constants.el',
             'bytecode-code-mutation-baseline.el', 'bytecode-code-active-mutation-baseline.el',
             'freeze-bytecode-candidate.py', 'test-bytecode-baseline205.py',
             'audit-source205-baseline.py', 'compare-recovered-continuation-fixtures.py', Path(__file__).name]:
    files[name] = p / name
audit = json.loads((p / 'source205-baseline-audit.json').read_text())
assert audit['raw_passed'] == 0 and audit['raw_failed'] == 2
assert len(audit['ordinary']) == 4
package('source205-bytecode-negative-baseline', files, audit)
