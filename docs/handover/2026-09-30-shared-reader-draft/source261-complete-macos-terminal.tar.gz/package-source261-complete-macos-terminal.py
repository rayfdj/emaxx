from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
audit = read('source261-macos-terminal-audit.json')
assert audit['status'] == 'passed'
assert audit['fully_matching_scenarios'] == 226 and audit['matching_comparisons'] == 686
assert audit['unexecuted_comparisons'] == 0 and not audit['divergent_labels']
files = {}
names = {
    'source261-manifest.json', 'source248-manifest.json', 'source261-macos-terminal-audit.json',
    'source261-macos-frozen-audit.json', 'source248-full-ttydiff-retry-command.json',
    'queue-source261-full-macos.py', 'audit-source261-macos-terminal.py',
    'source261-full-queue-result.json', 'source261-full-queue-state.json',
    'package-source196-failure-and197-results.py', Path(__file__).name,
}
for file in p.iterdir():
    if file.is_file() and file.suffix in ['.json', '.log', '.py']:
        if file.name in names or file.name.startswith('source261-full-tty'):
            files[file.name] = file
assert names <= files.keys()
command = read('source261-full-tty-command.json')
for name in ['tools/ttydiff.py', 'tools/fixtures/fieldnotes.org', 'tools/fixtures/fake_lsp_server.py']:
    file = Path(command['working_directory']) / name
    assert sha(file.read_bytes()) == read('source261-manifest.json')[name]
    files['execution-source/' + name] = file
for name in ['manifest.json','verification.json']:
    files['retained-gnu/'+name]=p/'source261-full-retained-gnu'/name
verification=read('source261-full-retained-gnu/verification.json')
assert verification['status']=='unchanged' and verification['files_verified']==4
package('source261-complete-macos-terminal', files, dict(
    terminal=audit,
    qualification='Complete rebuilt-GNU source261 terminal validation: 226 scenarios, 658 screen and 28 filesystem comparisons all match, ten execution inputs and 488 source inputs unchanged. Supervisor31023 has exited and final GNU retention verification reports allfour inputs unchanged. The exact gate executable/image also produced the separately retained macOS frozen result with six skip-diagnostic mismatches; those remain failures. This archive does not certify the later comparison/storage drafts or full-goal/performance completion.'))
