from pathlib import Path
import hashlib, json, os, subprocess, sys, time
p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/macro-reader/emaxx'
tag = 'source196-fresh'
manifest = json.loads((p / (tag + '-manifest.json')).read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
unchanged = lambda: all(sha(root / f) == h for f, h in manifest.items())
queue = json.loads((p / (tag + '-selected-supervisor.json')).read_text())
result_file = p / (tag + '-selected-validation-result.json')
while not result_file.exists():
    os.kill(queue['pid'], 0)
    time.sleep(5)
validation = json.loads(result_file.read_text())
if not (validation['all_completed'] and validation['source_unchanged'] and
        all(step['exit_code'] == 0 for step in validation['steps'])):
    with (p / (tag + '-selected-tty-not-run.json')).open('x') as f:
        json.dump({'status': 'not_run', 'reason': 'Prerequisite selected validation failed', 'prerequisite': str(result_file)}, f, indent=2)
    raise SystemExit(1)
assert unchanged()
names = ['type-one-line', 'prefix-arguments', 'm-x-round-trip', 'quit-key',
         'isearch-other-key-exit', 'mx-tab-completion', 'recursive-minibuffer',
         'keyboard-macro-minibuffer', 'f10-open', 'f10-select', 'f10-dismiss',
         'mouse-bar-click', 'mouse-bar-click-dismiss', 'mouse-cmenu',
         'reader-live-prefix-filters', 'reader-translation-pipeline-raw-keys',
         'reader-minibuffer-input-translation']
binary = root / 'target/frame-validation/release/emaxx'
gnu = p.parent / 'recovered-2026-09-30/emacs/src/emacs'
inputs = {str(f): sha(f) for f in [binary, binary.with_suffix('.pdmp'), gnu,
          gnu.with_suffix('.pdmp'), root / 'tools/ttydiff.py', root / 'tools/fixtures/fieldnotes.org', root / 'tools/fixtures/fake_lsp_server.py', Path(__file__)]}
command = ['/usr/bin/caffeinate', '-i', sys.executable, '-B', 'tools/ttydiff.py',
           str(binary), str(gnu), str(gnu.parent.parent / 'lisp'), *names]
overrides = {'EMAXX_TTYDIFF_REQUIRE': '1'}
with (p / (tag + '-selected-tty-command.json')).open('x') as f:
    json.dump({'command': command, 'working_directory': str(root), 'inputs': inputs,
               'environment_overrides': overrides, 'source_manifest': tag + '-manifest.json',
               'inventory': names, 'qualification': 'Selected ordinary terminal comparisons including three new reader contracts. Existing selectors, assertions and timeouts unchanged. Source/ABI-matched GNU is not the Darwin frozen executable. Not performance evidence.'}, f, indent=2)
start = time.monotonic()
with (p / (tag + '-selected-tty.log')).open('x') as log:
    run = subprocess.run(command, cwd=root, env={**os.environ, **overrides}, stdout=log, stderr=subprocess.STDOUT)
result = {'exit_code': run.returncode, 'elapsed_seconds': time.monotonic() - start,
          'source_unchanged': unchanged(), 'inputs_unchanged': all(sha(Path(f)) == h for f, h in inputs.items())}
with (p / (tag + '-selected-tty-result.json')).open('x') as f:
    json.dump(result, f, indent=2)
print(json.dumps(result), flush=True)
raise SystemExit(run.returncode or (0 if result['source_unchanged'] and result['inputs_unchanged'] else 2))
