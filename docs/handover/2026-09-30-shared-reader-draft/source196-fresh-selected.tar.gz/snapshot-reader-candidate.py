from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys

p = Path(__file__).parent.resolve()
root = p.parents[2]
isolated = p.parent / 'recovered-2026-09-30/macro-reader/emaxx'
previous, version, description = sys.argv[1:]
old_tag, tag = 'source' + previous, 'source' + version
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
old = json.loads((p / (old_tag + '-manifest.json')).read_text())
assert (p / (old_tag + '-selected-validation-result.json')).exists()
assert any((p / (old_tag + suffix)).exists() for suffix in
           ['-selected-tty-result.json', '-selected-tty-not-run.json'])
for suffix in ['-selected-supervisor.json', '-selected-tty-supervisor.json']:
    record = json.loads((p / (old_tag + suffix)).read_text())
    result = subprocess.run(['ps', '-p', str(record['pid']), '-o', 'pid=,command='],
                            capture_output=True, text=True)
    assert result.returncode == 1 and not result.stdout.strip() and not result.stderr, result
# Complete validation also owns the frozen checkout and artifacts. A
# successful selected run alone is no longer sufficient to reuse it.
full_supervisor = p / (old_tag + '-full-local-supervisor.json')
if full_supervisor.exists():
    assert (p / (old_tag + '-full-local-supervisor-result.json')).exists()
    for suffix in ['-full-local-supervisor.json', '-full-gate-launch.json', '-full-tty-launch.json']:
        handle = p / (old_tag + suffix)
        if not handle.exists():
            continue
        record = json.loads(handle.read_text())
        result = subprocess.run(['ps', '-p', str(record['pid']), '-o', 'pid=,command='],
                                capture_output=True, text=True)
        assert result.returncode == 1 and not result.stdout.strip() and not result.stderr, result
assert all(sha(isolated / name) == digest for name, digest in old.items())
base = '21d20f0eec08f3c013d5d3eb3bd6e9cfc16b3199'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == base
files = [*root.joinpath('src').rglob('*.rs'), *root.joinpath('tests').rglob('*'),
         *root.joinpath('.cargo').glob('*')]
files += [root / name for name in [
    'Cargo.toml', 'Cargo.lock', 'build.rs', 'tools/ttydiff.py',
    'tools/fixtures/fieldnotes.org', 'tools/fixtures/fake_lsp_server.py',
    'compat/emacs_compat_runner.el', 'src/lisp/bytecode/fixture-oracle-30.2.elc',
    'src/lisp/bytecode/fixture-oracle2-30.2.elc', 'src/lisp/bytecode/fixture-oracle3-30.2.elc']]
manifest = {str(f.relative_to(root)): sha(f) for f in sorted(set(files)) if f.is_file()}
paths = ['src', 'tests', 'Cargo.toml', 'Cargo.lock', 'build.rs', '.cargo',
         'compat/emacs_compat_runner.el', 'tools/ttydiff.py',
         'tools/fixtures/fieldnotes.org', 'tools/fixtures/fake_lsp_server.py']
patch = subprocess.check_output(['git', 'diff', '--binary', base, '--', *paths], cwd=root)
untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard',
                                     '--', *paths], cwd=root, text=True).splitlines()
for name in untracked:
    result = subprocess.run(['git', 'diff', '--no-index', '--binary', '--', '/dev/null', name],
                            cwd=root, capture_output=True)
    assert result.returncode == 1 and not result.stderr
    patch += result.stdout
with (p / (tag + '-complete.patch')).open('xb') as stream:
    stream.write(patch)
base_record = {'commit': base, 'worktree': str(isolated), 'inputs': len(manifest),
               'complete_patch_includes_untracked': untracked,
               'changed_from_previous': [name for name, digest in manifest.items()
                                         if old.get(name) != digest],
               'previous_source': old_tag, 'changes': description}
for suffix, data in [('-manifest.json', manifest), ('-base.json', base_record)]:
    with (p / (tag + suffix)).open('x') as stream:
        json.dump(data, stream, indent=2)
        stream.write('\n')
for name, digest in manifest.items():
    destination = isolated / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    if not destination.exists() or sha(destination) != digest:
        shutil.copy(root / name, destination)
    assert sha(destination) == digest
helpers = [(part + '-reader' + previous + '.py', part + '-reader' + version + '.py')
           for part in ['check', 'static', 'test', 'build']]
helpers += [(prefix + old_tag + suffix, prefix + tag + suffix)
            for prefix, suffix in [('queue-', '-validation.py'),
                                   ('run-', '-selected-tty.py'), ('audit-', '-patch.py')]]
for source, destination in helpers:
    content = (p / source).read_text().replace(old_tag, tag)
    content = content.replace('reader' + previous + '.py', 'reader' + version + '.py')
    content = content.replace('"' + previous + '"', '"' + version + '"')
    with (p / destination).open('x') as stream:
        stream.write(content)
print(json.dumps({'source': tag, 'inputs': len(manifest),
                  'changes': base_record['changed_from_previous'],
                  'patch_sha256': sha(p / (tag + '-complete.patch'))}))
