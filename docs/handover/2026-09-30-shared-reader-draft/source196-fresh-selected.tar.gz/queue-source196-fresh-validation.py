from pathlib import Path
import os
import hashlib
import json
import subprocess
import sys
import time

p = Path(__file__).parent.resolve()
root = p.parent / "recovered-2026-09-30/macro-reader/emaxx"
manifest = json.loads((p / "source196-fresh-manifest.json").read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
unchanged = lambda: all(sha(root / name) == digest for name, digest in manifest.items())
steps = [["check-reader196-fresh.py", "196-fresh"], ["static-reader196-fresh.py", "196-fresh"],
         ["test-reader196-fresh.py", "196-fresh", "gate"], ["test-reader196-fresh.py", "196-fresh", "release"],
         ["build-reader196-fresh.py", "196-fresh"],
         ["compare-recovered-continuation-fixtures.py", "source196-fresh", str(root),
          "input-decode-general", "input-decode-extra", "input-decode-pipeline",
          "input-decode-reader-contract", "input-decode-case-state", "input-decode-xt-setup", "input-decode-case-variants", "input-decode-command-reader", "input-decode-macro-shared", "input-decode-autoload-prefix", "input-decode-first-unbound", "input-decode-shift-tab-variants", "input-decode-remapped-undefined", "input-decode-map-authority", "input-decode-tab-map-installation", "input-decode-minibuffer-shared", "input-decode-minibuffer-queue", "input-decode-mouse-menu-cases", "input-decode-mouse-raw-mutation", "input-decode-menu-bar", "input-decode-position-lookup", "input-decode-macro-live-array", "input-decode-macro-raw-array", "input-decode-macro-nested-roots", "input-decode-macro-read-order", "input-decode-unread-wrapper"]]
results = []
clean_env = {**os.environ, "CARGO_TARGET_DIR": str(root / "target/frame-validation")}
for profile in ["dev", "gate", "release"]:
    command = ["cargo", "clean", "--package", "emaxx", "--profile", profile]
    with (p / ("source196-fresh-clean-" + profile + "-command.json")).open("x") as f:
        json.dump({"command": command, "working_directory": str(root), "environment_override": {"CARGO_TARGET_DIR": clean_env["CARGO_TARGET_DIR"]}}, f, indent=2)
    with (p / ("source196-fresh-clean-" + profile + ".log")).open("x") as f:
        cleaned = subprocess.run(command, cwd=root, env=clean_env, stdout=f, stderr=subprocess.STDOUT)
    with (p / ("source196-fresh-clean-" + profile + "-result.json")).open("x") as f:
        json.dump({"exit_code": cleaned.returncode, "source_unchanged": unchanged()}, f, indent=2)
    assert cleaned.returncode == 0 and unchanged()
for args in steps:
    assert unchanged()
    result = subprocess.run([sys.executable, str(p / args[0]), *args[1:]], check=False)
    results.append({"script": args, "exit_code": result.returncode, "source_unchanged": unchanged()})
    if result.returncode or not unchanged():
        break
with (p / "source196-fresh-selected-validation-result.json").open("x") as stream:
    json.dump({"steps": results, "all_completed": len(results) == len(steps),
               "source_unchanged": unchanged(), "completed_unix": time.time(),
               "qualification": "Selected common-reader integration only; full-source compatibility, broader reader contracts and complete goal requirements remain open."}, stream, indent=2)
raise SystemExit(0 if len(results) == len(steps) and all(item["exit_code"] == 0 and item["source_unchanged"] for item in results) else 1)
