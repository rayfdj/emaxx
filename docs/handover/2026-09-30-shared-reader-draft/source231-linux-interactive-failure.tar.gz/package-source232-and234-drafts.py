from pathlib import Path
from collections import Counter
import ast
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected'}

def matching(patterns):
    files = {}
    for pattern in patterns:
        for file in p.glob(pattern):
            if file.is_file() and file.suffix in allowed:
                files[str(file.relative_to(p))] = file
    return files

linux = read('source231-linux-failure-audit.json')
assert linux['rust']['passed'] == 1380
frozen = next((p / 'source231-linux-frozen-artifacts/compat').glob('frozen-*'))
counts = Counter()
for file in frozen.rglob('comparison.json'):
    report = json.loads((file.parent / 'oracle.json').read_text())
    for outcome in report['results']:
        assert outcome['expected']
        counts[{'passed': 'passed', 'failed': 'expected_failure', 'skipped': 'skipped'}[outcome['status']]] += 1
assert counts == dict(passed=1901, expected_failure=5, skipped=5)
linux['frozen']['classified_outcomes_per_editor'] = dict(counts)
files = matching(['source231-linux-*', 'source231-linux-rust-artifacts/**/*',
                  'source231-linux-frozen-artifacts/**/*', 'audit-source231-linux-failures.py',
                  'source231-interactive-metadata-*', 'diagnose-source231-interactive-metadata.py',
                  'interactive-metadata-probe.el'])
files[Path(__file__).name] = Path(__file__)
files['compat/oracle_tests_all_linux.txt'] = root / 'compat/oracle_tests_all_linux.txt'
package('source231-linux-interactive-failure', files, linux)

selected = read('source232-selected-audit.json')
assert selected['status'] == 'selected gate and release validation passes'
files = matching(['source232-*', 'audit-source232-*.py', 'run-source232-validation.py',
                  'test-source232-lightweight.py', 'check-string230.py', 'static-string230.py',
                  'test-string-controls230.py', 'audit-shared-reader196-fresh-selected.py',
                  'source231-diagnosis-*', 'diagnose-source231-full-failures*.py',
                  'source231-reader-slot-data*', 'diagnose-source231-reader-slot-data*.py'])
# Fresh full validation is still running. Only its immutable launch is included.
files = {name: file for name, file in files.items()
         if 'full-gate' not in name or name == 'source232-full-gate-fresh-launch.json'}
files[Path(__file__).name] = Path(__file__)
selected['reader_gnu_probe'] = read('source231-reader-slot-data-v3-gnu-result.json')
selected['reader_emaxx_probe'] = read('source231-reader-slot-data-v3-emaxx-result.json')
selected['qualification'] += ' Earlier failed diagnosis wrappers, including a presence-based template flag and malformed Lisp quoting, remain preserved alongside their separate corrected probes. Source232 first full run and fresh-image rerun are separate evidence.'
package('source232-library-control-repair', files, selected)

manifest = read('source234-manifest.json')
assert len(manifest) == 442
assert all(sha((root / name).read_bytes()) == digest for name, digest in manifest.items())
files = matching(['source233-base.json', 'source233-manifest.json', 'source233-complete.patch',
                  'source233-patch-replay-and-modes-audit.json', 'source233-check-*',
                  'source233-check.log', 'source233-fmt-*', 'source233-fmt.log',
                  'source233-clippy-*', 'source233-clippy.log', 'source233-diff-*',
                  'source233-diff.log', 'source233-validation-result.json', 'source233-driver.log',
                  'source233-launch.json', 'source233-interactive-fixture-gnu*',
                  'source234-base.json', 'source234-manifest.json', 'source234-complete.patch',
                  'source234-patch-replay-and-modes-audit.json', 'source234-check-*',
                  'source234-check.log', 'source234-fmt-*', 'source234-fmt.log',
                  'source234-clippy-*', 'source234-clippy.log', 'source234-diff-*',
                  'source234-diff.log', 'source234-launch.json',
                  'audit-source233-patches.py', 'audit-source234-patches.py',
                  'check-source233.py', 'static-source233.py', 'test-source233-controls.py',
                  'run-source233-validation.py', 'run-source234-validation.py'])
files[Path(__file__).name] = Path(__file__)
for name in ['interactive-closure-environments.el', 'interactive-closure-environments.expected']:
    files['tests/fixtures/' + name] = root / 'tests/fixtures' / name
for stage in ['check', 'fmt', 'clippy', 'diff']:
    result = read('source234-' + stage + '-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
reference = p.parent / 'recovered-2026-09-30/emacs/src/callint.c'
scope = dict(status='source234 portable interactive-metadata repair; runtime validation active',
             goal_complete=False, source_inputs_replayed=442, strict_checks='passed',
             gnu_reference=dict(path='src/callint.c', function='Fcall_interactively',
                                source_revision='636f166cfc86aa90d63f592fd99f3fdd9ef95ebd',
                                sha256=sha(reference.read_bytes())),
             change='Use CLOSURE_CONSTANTS as the interactive form environment only for a cons CLOSURE_CODE; use nil for all other commands. Delegate to existing Feval implementation. No new representation, cache or root registry.',
             prior_failure='Source233 passes compiler and Clippy but fails the new test line wrapping; no runtime tests run. Source234 changes only that formatting.',
             evidence_limit='GNU validates the new full fixture. The retained source231 ordinary probe fails with a constants-vector listp error. Neither a source234 runtime pass nor a Linux crash repair is claimed here. Both profile controls are active. Renderer, final architecture/accounting/ownership review and locked performance remain open.')
package('source234-interactive-metadata-draft', files, scope)
