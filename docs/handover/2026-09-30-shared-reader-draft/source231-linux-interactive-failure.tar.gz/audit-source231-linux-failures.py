from pathlib import Path
from collections import Counter
import hashlib
import json
import re
import sys

p = Path(__file__).parent.resolve()
project = p.parents[2]
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda f: json.loads(f.read_text())
head = '7cb2cae395e776726b4bbb7bd15c1a763e47e8c2'
for kind in ['rust', 'frozen']:
    state = read(p / ('source231-linux-' + kind + '-final-state.json'))
    assert state['status'] == 'completed' and state['conclusion'] == 'failure'
    assert state['headSha'] == head
    download = read(p / ('source231-linux-' + kind + '-download.json'))
    directory = p / ('source231-linux-' + kind + '-artifacts')
    assert all(sha(directory / name) == digest for name, digest in download['files'].items())
    assert sha(p / ('source231-linux-' + kind + '-artifact.zip')) == download['archive_sha256']

sys.path.insert(0, str(project / 'tools'))
import grouped_gate

rust = p / 'source231-linux-rust-artifacts/rust'
summary = read(rust / 'summary.json')
assert summary['git'] == dict(head=head, dirty=False)
assert summary['status'] == 'failed' and summary['cargo_stages'] == []
inventory = grouped_gate.parse_inventory((rust / 'inventory.txt').read_text())
assert len(inventory) == summary['inventory']['total_tests'] == 2989
assert hashlib.sha256(('\n'.join(inventory) + '\n').encode()).hexdigest() == summary['inventory']['sha256']
groups, _ = grouped_gate.classify_inventory(inventory, 'full')
started, passed = [], []
for group in ['eval_01', 'eval_02', 'eval_03', 'eval_04', 'eval_05']:
    report = read(rust / ('repeat-01-' + group + '.json'))
    raw = (rust / ('repeat-01-' + group + '.log')).read_text()
    matches = list(re.finditer(r'^test (\S+) \.\.\. ', raw, re.M))
    names = [match[1] for match in matches]
    assert names == groups[group][:len(names)]
    assert report['expected_tests'] == len(groups[group]) and not report['timed_out']
    completed_count = len(matches) - (group == 'eval_05')
    for index, match in enumerate(matches[:completed_count]):
        end = matches[index + 1].start() if index + 1 < len(matches) else raw.rindex('test result:')
        assert re.search(r'(?:^|\s)ok$', raw[match.end():end].strip()), match[1]
        passed.append(match[1])
    if group == 'eval_05':
        assert report['exit_code'] == -6 and len(names) == 125
        assert 'test result:' not in raw and 'host environment must be well formed' in raw
        assert names[-1].endswith('::edebug_global_break_condition_preserves_the_complete_minibuffer_expression')
    else:
        assert report['exit_code'] == 0 and names == groups[group]
        result = grouped_gate.parse_test_result(raw)
        assert result['passed'] == len(names) and result['failed'] == result['ignored'] == 0
    started.extend(names)
assert len(passed) == len(set(passed)) == 1380
assert len(started) == len(set(started)) == 1381
for group in ['primitives', 'compat_runtime', 'tty', 'batch', 'lightweight']:
    assert not (rust / ('repeat-01-' + group + '.json')).exists()
retained = read(rust / 'retained-inputs/manifest.json')
assert retained['gate_summary_sha256'] == sha(rust / 'summary.json')
for item in retained['files']:
    assert sha(rust / 'retained-inputs' / item['artifact']) == item['sha256']

frozen = next((p / 'source231-linux-frozen-artifacts/compat').glob('frozen-*'))
contract = read(frozen / 'contract.json')
assert read(frozen / 'head.json')['commit'] == head
assert contract['provenance']['subject_git_head'] == head
assert not contract['provenance']['subject_git_dirty']
manifest = project / 'compat/oracle_tests_all_linux.txt'
assert sha(manifest) == contract['manifest_sha256']
expected, counts = {}, {}
current = None
for line in manifest.read_text().splitlines():
    match = re.fullmatch(r'([^ ].*): discovered=(\d+) selected=(\d+)', line)
    if match:
        current = match[1]
        assert current not in expected
        expected[current], counts[current] = [], int(match[3])
    elif line.startswith('  '):
        assert current is not None
        expected[current].append(line[2:])
    elif ': load-error ' in line:
        current = None
    else:
        assert not line.strip(), line
assert all(len(set(names)) == len(names) == counts[file] for file, names in expected.items())
assert len(contract['files']) == 519
comparisons = sorted(frozen.rglob('comparison.json'))
assert len(comparisons) == 79
completed, outcomes = [], Counter()
for file in contract['files'][:80]:
    directory = frozen / Path(file).with_suffix('.compat')
    execution = read(directory / 'execution.json')
    assert execution['contract_sha256'] == sha(frozen / 'contract.json')
    assert all(sha(directory / name) == digest for name, digest in execution['sha256'].items())
    reports = {editor: read(directory / (editor + '.json')) for editor in ['oracle', 'emaxx']}
    for editor in reports:
        process = read(directory / (editor + '.execution.json'))['process']
        assert not process['timed_out']
        if file.endswith('/edebug-tests.el') and editor == 'emaxx':
            assert process['exit_code'] is None and process['test_started']
            assert 'host environment must be well formed' in process['stderr']
            assert reports[editor]['results'] == []
            continue
        assert process['exit_code'] == 0 and reports[editor]['file_status'] == 'loaded'
        assert sorted(reports[editor]['selected_tests']) == sorted(expected[file])
        assert sorted(row['name'] for row in reports[editor]['results']) == sorted(expected[file])
    if file.endswith('/edebug-tests.el'):
        assert not (directory / 'comparison.json').exists()
        assert len(expected[file]) == 46
        continue
    comparison = read(directory / 'comparison.json')
    assert comparison['matches'] and not comparison['issues'] and not comparison['execution_issues']
    assert comparison['matching_outcomes'] == len(expected[file]) and comparison['mismatching_outcomes'] == 0
    left = {row['name']: (row['status'], row['expected']) for row in reports['oracle']['results']}
    right = {row['name']: (row['status'], row['expected']) for row in reports['emaxx']['results']}
    assert left == right
    outcomes.update(status for status, _ in left.values())
    completed.append(file)
assert completed == contract['files'][:79]
assert contract['files'][79] == 'test/lisp/emacs-lisp/edebug-tests.el'
assert not (frozen / 'summary.json').exists()
record = dict(status='both source231 Linux runs fail during Edebug interactive metadata evaluation',
              goal_complete=False, source_commit=head,
              rust=dict(passed=1380, aborted_test=started[-1], unstarted=2989 - 1381,
                        ignored_tests_unexecuted=summary['inventory']['ignored_tests'],
                        unexecuted_cargo_stages=['bins', 'integration'], retained_files=retained['files']),
              frozen=dict(completed_matching_files=79, matching_outcomes=sum(outcomes.values()),
                          outcomes_per_editor=dict(outcomes), failed_file=contract['files'][79],
                          missing_emaxx_outcomes=46, unstarted_files=519 - 80,
                          qualification='GNU completes the edebug file; Emaxx aborts after test execution starts without a report. Its fallback load_error label is not evidence of a source-load failure. Earlier printed Edebug activity is not counted as test verdicts.'),
              diagnosis='Both raw traces reach the same host-environment assertion. The independent same-input ordinary probe shows that an interactive bytecode closure wrongly uses its constants vector as a lexical environment. GNU callint.c selects CLOSURE_CONSTANTS only when CLOSURE_CODE is a cons; otherwise Feval receives nil. Source234 implements that rule, but no Linux repair verdict is inferred from this failed-run audit.')
with (p / 'source231-linux-failure-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps({key: value for key, value in record.items() if key != 'rust'}, indent=2))
print('Rust: 1380 passed, one aborted test, 1608 unstarted; both Cargo stages unexecuted.')
