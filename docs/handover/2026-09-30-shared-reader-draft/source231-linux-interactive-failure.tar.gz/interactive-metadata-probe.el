(progn
  (set 'runtime-metadata-global 17)
  (let ((command (make-byte-code
                  257 (unibyte-string 135) [unrelated] 1 nil
                  '(list runtime-metadata-global))))
    (list
     (byte-code-function-p command)
     (condition-case failure
         (call-interactively command)
       (error (list (car failure) (cadr failure)
                    (vectorp (caddr failure))))))))
