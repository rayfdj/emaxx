from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/string-ops/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
program = '(prin1 ' + (p / 'interactive-metadata-probe.el').read_text() + ')'
binaries = {'gnu': p.parent / 'recovered-2026-09-30/emacs/src/emacs',
            'emaxx': root / 'target/frame-validation/release/emaxx'}
for editor, binary in binaries.items():
    original = json.loads((p / ('source231-ordinary-quoted-bytecode-reader-closure-' + editor + '.command.json')).read_text())
    inputs = {str(path): sha(path) for path in [binary, Path(str(binary) + '.pdmp')]}
    assert all(original['inputs'][name] == digest for name, digest in inputs.items())
    inputs[str(p / 'interactive-metadata-probe.el')] = sha(p / 'interactive-metadata-probe.el')
    command = [str(binary), '-Q', '--batch', '--eval', program]
    stem = 'source231-interactive-metadata-' + editor
    with (p / (stem + '-command.json')).open('x') as stream:
        json.dump(dict(command=command, working_directory=str(root), inputs=inputs,
                       environment_override={'LANG': 'C', 'LC_ALL': 'C'},
                       qualification='Same input through ordinary executables retained from source231. Current source232 test-only edits do not change those executables. GNU is source/native-ABI matched, not pinned Darwin.'), stream, indent=2)
    start = time.monotonic()
    result = subprocess.run(command, cwd=root, env={**os.environ, 'LANG': 'C', 'LC_ALL': 'C'},
                            capture_output=True, timeout=120)
    for suffix, data in [('stdout', result.stdout), ('stderr', result.stderr)]:
        with (p / (stem + '.' + suffix)).open('xb') as stream:
            stream.write(data)
    record = dict(exit_code=result.returncode, elapsed_seconds=time.monotonic() - start,
                  stdout=result.stdout.decode(), stderr=result.stderr.decode(),
                  inputs_unchanged=all(sha(Path(name)) == digest for name, digest in inputs.items()))
    with (p / (stem + '-result.json')).open('x') as stream:
        json.dump(record, stream, indent=2)
    assert record['inputs_unchanged']
    print(editor, json.dumps(record), flush=True)
