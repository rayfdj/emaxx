from pathlib import Path
import ast,gzip,hashlib,io,json,shutil,tarfile
p=Path(__file__).parent.resolve();out=p.parents[2]/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest();read=lambda n:json.loads((p/n).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
audit=read('source290-linux-frozen-raw-integrity-audit.json');assert audit['status']=='passed' and audit['outcomes']==7928
artifact=Path(audit['raw_artifact_directory']);assert all(sha((artifact/n).read_bytes())==h for n,h in audit['raw_files'].items())
allowed={'.json','.log','.txt','.py','.h','.apparmor','.loaded','.stdout','.stderr','.patch'}
files={};excluded=[]
for f in artifact.rglob('*'):
    if not f.is_file():continue
    if f.suffix in allowed or f.name=='Makefile':files[str(f.relative_to(p))]=f
    else:excluded.append(dict(path=str(f.relative_to(p)),bytes=f.stat().st_size,sha256=sha(f.read_bytes())))
for f in p.glob('source290-linux-frozen-*'):
    if f.is_file() and f.suffix in allowed:files[f.name]=f
for n in ['audit-source290-linux-frozen.py','verify-complete-frozen-receipts279.py','source290-manifest.json','package-source196-failure-and197-results.py',Path(__file__).name]:files[n]=p/n
package('source290-complete-linux-frozen',files,dict(status='closed source290 Linux frozen validation',audit=audit,excluded_binaries=excluded,qualification='519 files,7928 equal outcomes and1038 successful processes verify, including pinned oracle bytes and all177 compiler controls. The separate Linux Rust GNU reference failure remains failed. No later candidate or macOS/performance/full-goal result is certified.',goal_complete=False))
names=['source294-application-decision.json','source295-manifest.json','source295-preparation.json','source295-static-review.json',
       'source295-draft.patch','source295-portable-incremental.patch','source295-portable-complete.patch','source295-portable-draft-audit.json',
       'run-source295-validation.py','compare-source295-generated-loaded.py','audit-single-line-selected.py',
       'finish-single-line-selected.py','finish-single-line-selected-closed.py','verify-existing-portable-draft.py',
       'single-line-coordinator-requeue.json','measure-single-line.py','audit-single-line-performance.py',
       'finish-single-line-performance.py','finish-single-line-performance-closed.py',
       'buffer_line_validation_support.py','compare-vm-dispatch-fixtures.py','compare-buffer-line-broad-probe.py',
       'replay-buffer-line-drafts.py','buffer-line-measurement-setup-review.json','source292-existing-ordinary-verification.json',
       'run-buffer-line-finalize-closed.py','verify-existing-line-ordinary.py','finish-buffer-line-performance-restored.py',
       'line-cache-prior-build-review.json','package-source196-failure-and197-results.py',Path(__file__).name]
files={n:p/n for n in names}
for name in ['source295-validation-state.json','single-line-selection-closed-state.json','single-line-performance-sequence-closed-state.json']:
    copy=p/(name.removesuffix('.json')+'-launch-snapshot.json')
    with copy.open('x') as f:json.dump(read(name),f,indent=2)
    files[copy.name]=copy
package('source294-review-and295-single-line-draft',files,dict(status='reject slower294; portable295 is still under validation',decision=read('source294-application-decision.json'),source295_snapshot=read('source295-validation-state-launch-snapshot.json'),qualification='Source295 starts from corrected292, retaining its original scan. Only a whole-buffer no-LF proof through existing O(1) metadata returns the accessible beginning early. All532 inputs/modes replay exactly; no new fixture or selector. Fresh profile compilation is mandatory. Selected validation/ordinary comparisons/performance remain pending at capture. All rejected294 measurements,60 original column-width mismatches and setup/cache failures remain. No runtime application or speed claim.',goal_complete=False))
for name in ['source294-application-decision.json']:
    target=out/name;assert not target.exists();shutil.copy2(p/name,target);assert sha(target.read_bytes())==sha((p/name).read_bytes())
