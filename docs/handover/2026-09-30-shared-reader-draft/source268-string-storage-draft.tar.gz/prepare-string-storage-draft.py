from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import time

root = Path.cwd()
p = root / 'target/runtime-goal/resume-2026-09-28'
previous = root / 'target/runtime-goal/recovered-2026-09-30/string-ranges/emaxx'
parent = root / 'target/runtime-goal/recovered-2026-09-30/string-storage'
candidate = parent / 'emaxx'
gnu = root / 'target/runtime-goal/rebuilt-2026-10-01/emacs'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
manifest = json.loads((p / 'source263-manifest.json').read_text())
assert len(manifest) == 500 and all(sha(previous / name) == digest for name, digest in manifest.items())
base = subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert base == 'e6120bcee99206d0b0c2f29d3429280bd7ad7024'
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
assert not parent.exists()
parent.mkdir()
subprocess.run(['git','worktree','add','--detach',str(candidate),base],check=True)
for name in manifest:
    target = candidate / name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(previous / name,target)
assert all(sha(candidate / name) == digest for name,digest in manifest.items())
(parent / 'emacs').symlink_to(gnu,target_is_directory=True)
with (p / 'string-storage-draft-checkout.json').open('x') as stream:
    json.dump(dict(candidate=str(candidate),base=base,source263_inputs_verified=500,source263_manifest_sha256=sha(p/'source263-manifest.json'),source263_unchanged=True,created_at_unix=time.time(),goal_complete=False,qualification='Separate editable storage draft initialized with all500 frozen source263 inputs. Published source261 and both running/queued candidates remain unchanged. No build cache is copied while the terminal run is active; no implementation or validation result is inferred from setup.'),stream,indent=2)
print(candidate)
