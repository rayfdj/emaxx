from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).parent.resolve()
gnu=p.parent/'rebuilt-2026-10-01/emacs'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
fixture=p/'string-comparison-initialization.el'
for mode,flags in [('bare-loadup',['--temacs=pdump','--batch'])]:
    stem='source263-case-initialization-'+mode
    command=[str(gnu/'src/emacs'),*flags]
    fixture=p/'case-initialization-loadup/loadup.el'
    environment=dict(LANG='C',LC_ALL='C',EMACSLOADPATH=str(fixture.parent))
    inputs={str(f):sha(f) for f in [Path(__file__),fixture,gnu/'src/emacs',gnu/'src/emacs.pdmp',gnu/'src/config.h',gnu/'src/Makefile',gnu/'src/casetab.c',gnu/'src/emacs.c',gnu/'lisp/loadup.el',gnu/'lisp/international/characters.el']}
    with (p/(stem+'-command.json')).open('x') as f:json.dump(dict(command=command,cwd=str(gnu),environment_override=environment,inputs=inputs,timeout_seconds=120),f,indent=2)
    start=time.monotonic()
    try:
        result=subprocess.run(command,cwd=gnu,env=dict(os.environ,**environment),stdin=subprocess.DEVNULL,capture_output=True,timeout=120)
        code,out,err,timeout=result.returncode,result.stdout,result.stderr,False
    except subprocess.TimeoutExpired as exc:
        code,out,err,timeout=None,exc.stdout or b'',exc.stderr or b'',True
    for ext,data in [('stdout',out),('stderr',err)]:
        with (p/(stem+'.'+ext)).open('xb') as f:f.write(data)
    result=dict(exit_code=code,timed_out=timeout,elapsed_seconds=time.monotonic()-start,stdout_sha256=sha(p/(stem+'.stdout')),stderr_sha256=sha(p/(stem+'.stderr')),inputs_unchanged=all(sha(Path(n))==h for n,h in inputs.items()))
    with (p/(stem+'-result.json')).open('x') as f:json.dump(result,f,indent=2)
    print(mode,json.dumps(result),repr(out),repr(err),flush=True)
