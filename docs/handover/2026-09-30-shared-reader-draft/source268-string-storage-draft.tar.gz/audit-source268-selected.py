from pathlib import Path
import ast
import hashlib
import json
import re

p = Path(__file__).parent.resolve()
candidate = p.parent / 'recovered-2026-09-30/string-storage/emaxx'
previous = p.parent / 'recovered-2026-09-30/string-comparisons/emaxx'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
state = read('source268-validation-result.json')
assert state['status'] == 'selected processes finished; raw evidence requires audit'
assert len(state['stages']) == len(state['results']) == 8
assert all(row['exit_code'] == 0 and row['source_unchanged']
           and row['prior_source_unchanged'] and row['helper_unchanged'] for row in state['results'])
assert all(sha(Path(name)) == digest for name, digest in state['helper_sha256'].items())
manifest = read('source268-manifest.json')
assert len(manifest) == 510 and all(sha(candidate / name) == digest for name, digest in manifest.items())
prior_manifest = read('source261-manifest.json')
assert len(prior_manifest) == 488 and all(sha(previous / name) == digest for name, digest in prior_manifest.items())
node = next(node for node in ast.parse((p / 'audit-source238-release.py').read_text()).body
            if isinstance(node, ast.FunctionDef) and node.name == 'audit_log')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<unchanged-raw-verdict-auditor>', 'exec'))
added_names = {
    'lisp::primitives::tests::string_empty_constructors_preserve_gnu_storage_identities',
    'lisp::primitives::tests::pure_strings_preserve_gnu_identity_write_protection_and_error_order',
    'lisp::primitives::tests::pure_string_properties_preserve_gnu_noop_and_readonly_behavior',
    'lisp::native_comp::runtime::tests::pure_string_headers_survive_unrooted_gc_outside_the_ordinary_census',
    'lisp::primitives::pdumper::tests::string_images_preserve_empty_roots_distinct_headers_and_restored_mutability',

    'lisp::primitives::tests::compare_strings_preserves_gnu_range_errors_and_validation_order',
    'lisp::primitives::tests::compare_strings_promotes_bytes_before_casing_actual_characters',
    'lisp::primitives::tests::compare_strings_observes_live_case_table_mutation_and_gc',
    'lisp::primitives::tests::numeric_casing_uses_exact_character_table_keys',
    'lisp::primitives::tests::string_ordering_uses_canonical_storage_and_lisp_symbol_names',
    'lisp::primitives::tests::string_versions_follow_gnu_filenvercmp',
}
version_name = 'lisp::primitives::compat_runtime_tests::compat_03::string_version_lessp_matches_upstream_cases'
ignored = ['tty::tty_differential_end_to_end', 'tty::tty_smoke_end_to_end']
inventories, profiles = {}, {}
for profile, count in [('gate', 3021), ('release', 3020)]:
    names = [line[:-6] for line in (p / ('source268-' + profile + '-inventory.log')).read_text().splitlines()
             if line.endswith(': test')]
    prior_names = [line[:-6] for line in (p / ('source261-' + profile + '-inventory.log')).read_text().splitlines()
                   if line.endswith(': test')]
    assert len(names) == len(set(names)) == count
    assert set(prior_names) <= set(names) and set(names) - set(prior_names) == added_names
    inventories[profile] = names
    audit = read('source268-focused-audit.json' if profile == 'gate' else 'source268-release-focused-audit.json')
    assert audit['status'] == 'passed' and audit['counts'] == {'ok': 203, 'FAILED': 0, 'ignored': 2}
    for item in audit['retained_inputs']:
        assert sha(Path(item['original'])) == sha(Path(item['artifact'])) == item['sha256']
    focused = read('source268-' + profile + '-controls-command.json')
    prior_focused = read('source261-' + profile + '-controls-command.json')['selectors']
    assert len(focused['selectors']) == 205 and len(prior_focused) == 191
    assert set(prior_focused) <= set(focused['selectors'])
    assert set(focused['selectors']) - set(prior_focused) == added_names | {version_name, 'lisp::primitives::tests::char_table_casing_preserves_gnu_modifier_and_integer_semantics', 'lisp::primitives::tests::subr_frontier_compare_strings_uses_gnu_simple_upcase_canonicalization'}
    audit_log(focused['selectors'], (p / ('source268-' + profile + '-controls.log')).read_text(), ignored)
    command = read('source268-' + profile + '-broad-command.json')
    result = read('source268-' + profile + '-broad-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
    selected = command['selected_inventory']
    assert len(selected) == len(set(selected)) == 1059
    assert command['command'][1:] == selected + ['--exact', '--nocapture', '--test-threads=1']
    prior_selected = read('source261-' + profile + '-broad-command.json')['selected_inventory']
    compatibility = {name for name in names if name.startswith('lisp::primitives::compat_runtime_tests::')}
    assert len(prior_selected) == 962 and len(compatibility) == 86
    assert set(selected) == set(prior_selected) | compatibility | added_names
    assert sha(p / ('source268-' + profile + '-libtest')) == command['binary_sha256'] == focused['binary_sha256']
    audit_log(selected, (p / ('source268-' + profile + '-broad.log')).read_text(), [])
    profiles[profile] = dict(focused_passes=203, existing_ignores=ignored, affected_passes=1059,
                             complete_library_inventory=len(names), binary_sha256=command['binary_sha256'])
assert set(inventories['gate']) - set(inventories['release']) == {
    'file_system::posix::tests::posix_file_drop_rejects_an_externally_closed_descriptor'}
assert not set(inventories['release']) - set(inventories['gate'])
compat_file = 'src/lisp/primitives/compat_runtime_tests/compat_03.rs'
assert sha(candidate / compat_file) == prior_manifest[compat_file]
for stage in ['check', 'fmt', 'clippy', 'diff', 'gate-build', 'release-build', 'ordinary-build', 'ordinary-image']:
    result = read('source268-' + stage + '-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
    raw = (p / ('source268-' + stage + '.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
    for line in raw.splitlines():
        if line.startswith('{'):
            assert json.loads(line).get('message', {}).get('level') not in ['error', 'warning']
fixtures = state['stages'][-1][3:]
assert len(fixtures) == len(set(fixtures)) == 33
prior_ordinary = read('source261-selected-audit.json')['ordinary_expected_sha256']
assert len(prior_ordinary) == 22 and set(prior_ordinary) <= set(fixtures)
ordinary = {}
for fixture in fixtures:
    result = read('source268-ordinary-' + fixture + '-comparison.json')
    assert result['passed'] and result['exact_match']
    if fixture == 'native-bytecode-unibyte-constructor':
        expected = (p / 'source256-native-bytecode-constructor-gnu.stdout').read_bytes()
    else:
        expected_path = candidate / ('tests/fixtures/' + fixture + '.expected')
        if not expected_path.exists():
            expected_path = p / (fixture + '.expected')
        expected = expected_path.read_bytes().rstrip(b'\n')
    digest = hashlib.sha256(expected).hexdigest()
    if fixture in prior_ordinary:
        assert digest == prior_ordinary[fixture]
    if fixture in ['string-ordering-symbol-storage', 'string-version-ordering', 'compare-strings-ranges', 'compare-strings-character-storage', 'compare-strings-live-case-table', 'string-case-character-identities', 'string-empty-identities', 'string-pure-storage-values', 'string-pure-property-storage', 'string-comparison-case-table-initialization']:
        assert expected == (p / ('source261-probe-' + fixture + '-gnu.stdout')).read_bytes()
    for editor in ['gnu', 'emaxx']:
        prefix = 'source268-ordinary-' + fixture + '-' + editor
        command, row = read(prefix + '.command.json'), read(prefix + '.result.json')
        assert row['exit_code'] == 0 and not row['timed_out']
        assert row['source_unchanged'] and row['inputs_unchanged'] and row['expected_output'] is not False
        assert all(sha(Path(name)) == value for name, value in command['inputs'].items())
        assert sha(p / (prefix + '.stdout')) == row['stdout_sha256'] == digest
        assert (p / (prefix + '.stderr')).read_bytes() == b'' and row['stderr_hex'] == ''
    ordinary[fixture] = digest
artifacts = read('source268-ordinary-artifacts.json')
assert len(artifacts) == 2
for name, info in artifacts.items():
    assert sha(Path(name)) == sha(Path(info['immutable_copy'])) == info['sha256']
record = dict(status='passed', source_inputs_verified=510, profiles=profiles,
              ordinary_comparisons=len(ordinary), ordinary_expected_sha256=ordinary,
              ordinary_artifacts=artifacts, added_test_names=sorted(added_names),
              original_failures_preserved=True, goal_complete=False,
              qualification='Selected gate/release and 33 ordinary same-input GNU comparisons only. All source261 controls and expected bytes remain, with all compatibility-runtime tests added to affected coverage. All original ordering/range/casing/storage negatives are compared to unchanged GNU output. The prefix fixture repeats all12,600 original pairs. Source263 broad and source264 through266 strict failures remain failures. Complete platform validation, performance, memory, public ownership and architecture completion remain separate requirements.')
with (p / 'source268-selected-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps({key: record[key] for key in ['status', 'source_inputs_verified', 'profiles', 'ordinary_comparisons']}, indent=2))
