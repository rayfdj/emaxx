from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve();root=p.parents[2]
out=root/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda n:json.loads((p/n).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
files={}
for path in p.iterdir():
    if not path.is_file():continue
    n=path.name
    strict_history=any(n.startswith('source'+str(v)+'-') for v in range(264,268)) and path.suffix in ['.json','.log','.patch']
    current_strict=any(n.startswith('source268-'+stage) for stage in ['format','manifest','freeze','unformatted','incremental','portable','check','fmt','clippy','diff','storage','validation-launch','validation-state-at-preparation']) and path.suffix in ['.json','.log','.patch']
    ranges=any(n.startswith('source263-'+stage) for stage in ['gate-','focused-','fixture-validation','boundary-fixtures','broad-','case-initialization']) and path.suffix in ['.json','.log','.stdout','.stderr']
    probes=n.startswith('source261-probe-string-pure-property-storage-') or n.startswith('source261-probe-string-comparison-case-table-initialization-')
    if strict_history or current_strict or ranges or probes:files[n]=path
names=[
 'source261-pure-property-negative-audit.json','source261-string-pure-property-storage-probes.json',
 'source261-string-comparison-case-table-initialization-probes.json',
 'source263-manifest.json','source263-focused-audit.json','source263-focused-retained-inputs.json',
 'audit-source263-broad-failure.py','audit-source263-broad-verdicts.py',
 'audit-source268-storage-patches.py','audit-source268-storage-preparation.py','audit-source268-selected.py',
 'audit-source261-compare-strings.py','audit-source238-release.py',
 'prepare-string-storage-draft.py','string-storage-draft-checkout.json','string-storage-cache-clone.json','string-storage-cache-clone.log',
 'check-string-storage-draft.py','check-string-storage-callers.py','freeze-string-storage.py','freeze-string-storage-callers.py',
 'run-string-storage-focused.py','run-string-storage-release.py','audit-string-storage-focused.py','audit-string-storage-release.py',
 'test-string-storage-broad.py','build-string-storage-ordinary.py','compare-string-storage-fixtures.py','queue-string-storage268-validation.py',
 'run-string-ranges-focused.py','audit-string-ranges-focused.py','test-string-ranges-broad.py',
 'queue-string-ranges263-fixtures.py','queue-source263-boundary-fixtures.py',
 'probe-source261-string-pure-property-storage.py','probe-source261-string-comparison-case-table-initialization.py',
 'probe-source263-case-initialization.py','probe-source263-case-initialization-loadup.py','probe-source263-case-initialization-ordered.py',
 'string-comparison-initialization.el','case-initialization-loadup/loadup.el',
 'source261-manifest.json','source261-selected-audit.json','source261-string-storage-negative-audit.json',
 'source261-string-prefix-audit.json','source261-ordinary-artifacts.json',
 'package-source196-failure-and197-results.py',Path(__file__).name,
]
for fixture in ['string-empty-identities','string-pure-storage-values','string-pure-property-storage','string-comparison-case-table-initialization','string-ordering-prefix-boundaries']:
    names += [fixture+'.el',fixture+'.expected']
for fixture in ['string-empty-identities','string-pure-storage-values']:
    names += ['source261-probe-'+fixture+'-gnu'+suffix for suffix in ['.stdout','.stderr','-command.json','-result.json']]
for name in names:
    assert (p/name).is_file(),name
    files[name]=p/name
preparation=read('source268-storage-preparation-audit.json')
assert preparation['source_inputs_verified']==510
assert read('source263-broad-failure-audit.json')['counts']==dict(ok=1053,FAILED=1,ignored=0)
package('source268-string-storage-draft',files,dict(
 preparation=preparation,comparison_failure=read('source263-broad-failure-audit.json'),
 patch_replay=read('source268-storage-patch-replay-audit.json'),
 qualification='Portable unapplied source268 storage repair and the complete failed source263 selected stage. Source263 focused passes197/two existing ignores; broad fails with1053passes/one failure; release and ordinary stages did not execute. Source264/265 compiler failures,source266 Clippy failure,three failed GNU bare-startup diagnostics and the first broad-log audit rejection are retained. Source267 strict passes but did not run. Source268 strict passes;205 focused selectors,1059 affected tests/profile and33 ordinary comparisons are running under96501. Only immutable preparation/launch snapshots are packaged; no running build/test log is presented as completed. GNU empty/pure identity, readonly/no-op order,32byte header+16byte allocator/borrow metadata,packed property spans and dump/template identities are implemented but runtime validation is pending. Data sblocks,actual interval trees,symbol authority,physical accounting,public ownership,complete platform validation and the locked performance criteria remain unfinished.'))
