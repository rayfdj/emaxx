from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

OUT = Path(__file__).parent.resolve()
ROOT = OUT.parent / 'recovered-2026-09-30/string-storage/emaxx'
ID = sys.argv[1]
assert ID.isdecimal()
PREFIX = 'source' + ID

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(suffix, value):
    with (OUT / (PREFIX + suffix + '.json')).open('x') as stream:
        json.dump(value, stream, indent=2)

def patch(suffix):
    result = subprocess.check_output(['git', 'diff', '--binary'], cwd=ROOT)
    with (OUT / (PREFIX + suffix + '.patch')).open('xb') as stream:
        stream.write(result)

patch('-unformatted')
env = dict(os.environ, CARGO_TARGET_DIR=str(ROOT / 'target/string-storage-validation'), CARGO_BUILD_JOBS='1')
with (OUT / (PREFIX + '-format.log')).open('xb') as log:
    result = subprocess.run(['cargo', 'fmt', '--all'], cwd=ROOT, env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
save('-format-result', {'exit_code': result.returncode})
if result.returncode:
    sys.exit(result.returncode)
patch('-incremental')
paths = set(json.loads((OUT / 'source263-manifest.json').read_text()))
for stem in ['string-empty-identities', 'string-pure-storage-values', 'string-pure-property-storage']:
    paths.update('tests/fixtures/' + stem + suffix for suffix in ['.el', '.expected'])
paths.update(['src/lisp/alloc/strings.rs', 'src/lisp/types/string_data/properties.rs'])
manifest = {path: sha(ROOT / path) for path in sorted(paths)}
assert len(manifest) == 508
save('-manifest', manifest)
commands = [
    ('check', ['cargo', 'check', '--locked', '--all-targets', '--all-features']),
    ('fmt', ['cargo', 'fmt', '--all', '--', '--check']),
    ('clippy', ['cargo', 'clippy', '--locked', '--all-targets', '--all-features', '--', '-D', 'warnings']),
    ('diff', ['git', 'diff', '--check']),
]
for stage, command in commands:
    save('-' + stage + '-command', {
        'command': command, 'cwd': str(ROOT), 'manifest': PREFIX + '-manifest.json',
        'environment_override': {'CARGO_TARGET_DIR': env['CARGO_TARGET_DIR'], 'CARGO_BUILD_JOBS': '1'},
        'helper_sha256': sha(Path(__file__)),
    })
    started = time.monotonic()
    with (OUT / (PREFIX + '-' + stage + '.log')).open('xb') as log:
        result = subprocess.run(command, cwd=ROOT, env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
    unchanged = all(sha(ROOT / path) == digest for path, digest in manifest.items())
    save('-' + stage + '-result', {'exit_code': result.returncode, 'elapsed_seconds': time.monotonic() - started, 'source_unchanged': unchanged})
    if result.returncode or not unchanged:
        sys.exit(result.returncode or 2)
print(PREFIX + ' strict checks finished', flush=True)
