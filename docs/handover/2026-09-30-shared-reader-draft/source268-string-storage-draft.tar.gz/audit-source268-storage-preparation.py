from pathlib import Path
import ast, hashlib, json, re
p = Path(__file__).parent.resolve()
root = p.parents[2]
candidate = p.parent / 'recovered-2026-09-30/string-storage/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p/n).read_text())
node = next(n for n in ast.parse((p/'audit-source261-compare-strings.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'parse')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<lossless-parser>', 'exec'))
rows = {}
for editor in ['gnu', 'source261']:
    stem = 'source261-probe-string-pure-property-storage-' + editor
    command, result = read(stem+'-command.json'), read(stem+'-result.json')
    assert result['exit_code'] == 0 and not result['timed_out'] and result['inputs_unchanged'] and result['source_unchanged']
    assert all(sha(Path(n)) == h for n,h in command['inputs'].items())
    for ext in ['stdout', 'stderr']:
        assert sha(p/(stem+'.'+ext)) == result[ext+'_sha256']
    assert not (p/(stem+'.stderr')).read_bytes()
    data = parse((p/(stem+'.stdout')).read_text())
    assert len(data) == 144 and all(len(row) == 11 for row in data)
    assert {tuple(row[:3]) for row in data} == {(str(i), pure, str(op)) for i in range(6) for pure in ['nil','t'] for op in range(12)}
    assert all('void-variable' not in str(row[5]) for row in data)
    rows[editor] = data
negative = read('source261-pure-property-negative-audit.json')
assert negative['wrong_rows'] == sum(a != b for a,b in zip(rows['gnu'],rows['source261'])) == 106
assert negative['wrong_operation_poststate_rows'] == sum(a[5:] != b[5:] for a,b in zip(rows['gnu'],rows['source261'])) == 84
for fixture in ['string-empty-identities','string-pure-storage-values','string-pure-property-storage','string-comparison-case-table-initialization']:
    assert (candidate/'tests/fixtures'/(fixture+'.el')).read_bytes() == (p/(fixture+'.el')).read_bytes()
    assert (candidate/'tests/fixtures'/(fixture+'.expected')).read_bytes() == (p/('source261-probe-'+fixture+'-gnu.stdout')).read_bytes() + b'\n'
manifest = read('source268-manifest.json')
assert len(manifest) == 510 and all(sha(candidate/n) == h for n,h in manifest.items())
published = read('source261-manifest.json')
assert len(published) == 488 and all(sha(root/n) == h for n,h in published.items())
assert read('source264-check-result.json')['exit_code'] == 101
assert read('source265-check-result.json')['exit_code'] == 101
assert 'due to 5 previous errors' in (p/'source264-check.log').read_text()
assert 'src/lisp/reader.rs:2386:13' in (p/'source265-check.log').read_text()
assert read('source266-check-result.json')['exit_code'] == 0
assert read('source266-clippy-result.json')['exit_code'] == 101
assert 'Box<Vec<..>>' in (p/'source266-clippy.log').read_text()
for version in [267,268]:
    for stage in ['fmt','check','clippy','diff']:
        result = read('source'+str(version)+'-'+stage+'-result.json')
        assert result['exit_code'] == 0 and result['source_unchanged']
        assert not re.search(r'^warning(?:\[.*\])?:', (p/('source'+str(version)+'-'+stage+'.log')).read_text(), re.M)
assert not (p/'source267-gate-build-command.json').exists()
assert read('source268-storage-patch-replay-audit.json')['status'] == 'exact'
assert len(read('source268-storage-patch-replay-audit.json')['replays']) == 10
assert read('source263-broad-failure-audit.json')['counts'] == dict(ok=1053,FAILED=1,ignored=0)
launch = read('source268-validation-launch.json')
assert sha(Path(launch['command'][-1])) == launch['helper_sha256']
state = read('source268-validation-queue-state.json')
assert len(state['stages']) == 8 and len(state['stages'][-1][3:]) == 33
assert all(sha(Path(n)) == h for n,h in state['helper_sha256'].items())
with (p/'source268-validation-state-at-preparation.json').open('x') as f: json.dump(state,f,indent=2)
record = dict(status='draft bytes, strict checks and preparation verified',source_inputs_verified=510,
              published_source261_unchanged=True, property_baseline=dict(rows=144,wrong_rows=106,wrong_operation_poststate_rows=84),
              strict_failures=dict(source264='five stale RefCell callers',source265='old Vec type in unchanged reader assertion',source266='Box<Vec> creates extra property allocation'),
              strict_passes=[267,268], source267_runtime='not run', selected_launch=launch,
              qualification='Source268 is an unapplied selected-validation candidate. No selected runtime pass is inferred. Five earlier frozen sources replay exactly. The property pointer now owns count plus packed spans in one allocation, resolving the extra Box<Vec> allocation rather than allowing the lint. Source268 additionally preserves pure/empty identities in template cloning. Data sblocks, full interval trees, physical accounting, public ownership and final validation/performance remain open.',goal_complete=False)
with (p/'source268-storage-preparation-audit.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps({k:record[k] for k in ['status','source_inputs_verified','property_baseline','strict_passes']}))
