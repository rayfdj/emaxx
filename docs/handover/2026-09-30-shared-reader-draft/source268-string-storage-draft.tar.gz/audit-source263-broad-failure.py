from pathlib import Path
import hashlib, json, re

p = Path(__file__).parent.resolve()
candidate = p.parent / 'recovered-2026-09-30/string-ranges/emaxx'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read('source263-manifest.json')
assert len(manifest) == 500 and all(sha(candidate / name) == digest for name, digest in manifest.items())
command = read('source263-gate-broad-command.json')
result = read('source263-gate-broad-result.json')
assert result['exit_code'] == 101 and result['source_unchanged']
names = command['selected_inventory']
assert len(names) == len(set(names)) == 1054
assert command['command'][1:] == names + ['--exact', '--nocapture', '--test-threads=1']
prior = read('source249-gate-broad-command.json')['selected_inventory']
assert len(prior) == 955 and set(prior) <= set(names)
common = read('source256-gate-broad-command.json')['selected_inventory']
assert len(common) == 957 and set(common) <= set(names)
raw = (p / 'source263-gate-broad.log').read_text()
blocks = list(re.finditer(r'^test (\S+) \.\.\. ', raw, re.M))
observed = {}
for index, match in enumerate(blocks):
    stop = blocks[index + 1].start() if index + 1 < len(blocks) else raw.find('\nfailures:', match.end())
    assert stop >= match.end()
    verdicts = re.findall(r'^(ok|FAILED|ignored)(?:,.*)?$', raw[match.end():stop], re.M)
    assert len(verdicts) == 1 and match[1] not in observed
    observed[match[1]] = verdicts[0]
assert set(observed) == set(names)
counts = {key: list(observed.values()).count(key) for key in ['ok', 'FAILED', 'ignored']}
assert counts == {'ok': 1053, 'FAILED': 1, 'ignored': 0}
failed = [name for name, verdict in observed.items() if verdict == 'FAILED']
assert failed == ['lisp::primitives::tests::subr_frontier_compare_strings_uses_gnu_simple_upcase_canonicalization']
assert 'test result: FAILED. 1053 passed; 1 failed; 0 ignored; 0 measured; 1962 filtered out;' in raw
assert 'value: Integer(2)' in raw and 'value: Integer(1)' in raw
retained = read('source263-focused-retained-inputs.json')['files']
assert len(retained) == 2 and retained[0]['sha256'] == command['binary_sha256']
for item in retained:
    assert sha(Path(item['artifact'])) == sha(Path(item['original'])) == item['sha256']
queue = read('source263-fixture-validation-result.json')
assert len(queue['results']) == 3
assert [row['exit_code'] for row in queue['results']] == [0, 0, 101]
assert all(row['source_unchanged'] and row['helper_unchanged'] for row in queue['results'])

preceding = read('source261-gate-broad-command.json')['selected_inventory']
assert len(preceding) == 962 and set(preceding) <= set(names)
ordinary = {}
for editor, expected in [('gnu', b'((t t) (2 1))'), ('source261', b'((t t) (t t))')]:
    stem = 'source261-probe-string-comparison-case-table-initialization-' + editor
    cmd, res = read(stem + '-command.json'), read(stem + '-result.json')
    assert res['exit_code'] == 0 and not res['timed_out'] and res['inputs_unchanged'] and res['source_unchanged']
    assert all(sha(Path(n)) == h for n, h in cmd['inputs'].items())
    assert (p / (stem + '.stdout')).read_bytes() == expected
    assert sha(p / (stem + '.stdout')) == res['stdout_sha256']
    assert not (p / (stem + '.stderr')).read_bytes()
    ordinary[editor] = res
failed_diagnostics = {}
for mode in ['bare', 'bare-loadup', 'bare-ordered']:
    stem = 'source263-case-initialization-' + mode
    cmd, res = read(stem + '-command.json'), read(stem + '-result.json')
    assert res['exit_code'] == 255 and res['inputs_unchanged'] and not res['timed_out']
    assert all(sha(Path(n)) == h for n, h in cmd['inputs'].items())
    for ext in ['stdout', 'stderr']:
        assert sha(p / (stem + '.' + ext)) == res[ext + '_sha256']
    failed_diagnostics[mode] = res
boundary = read('source263-boundary-fixtures-queue-result.json')
assert boundary['status'] == 'stopped without passing boundary validation'
assert not boundary['results']
gnu = p.parent / 'rebuilt-2026-10-01/emacs'
references = {n: sha(gnu / n) for n in ['src/casetab.c','src/fns.c','src/buffer.h','lisp/loadup.el','lisp/international/characters.el']}
record = dict(status='failed', counts=counts, failed_tests=failed, raw_verdicts=observed,
 source_inputs_verified=500, prior_selectors_preserved=962, selected=1054, retained_inputs=retained,
 unexecuted_stages=queue['stages'][3:], boundary=boundary, ordinary_case_tables=ordinary,
 excluded_bare_startup_diagnostics=failed_diagnostics, gnu_reference_sha256=references,
 raw_log_sha256=sha(p/'source263-gate-broad.log'), goal_complete=False,
 diagnosis='The original Unicode test uses Interpreter::new, whose case tables have only the ASCII C initialization of casetab.c:init_casetab_once. Actual characters.el installs Unicode entries during loadup. Source263 follows live tables and returns2/1 in bare state. Ordinary GNU returns(t t) with its dump and(2 1) after installing an empty case table; source261 wrongly returns(t t) in both states. Preserve the original Unicode assertions in an initialized interpreter and add explicit bare/empty-table coverage. Three unsuccessful direct-bare launch diagnostics are retained and excluded as behavioral evidence.',
 qualification='All1054 raw names/verdicts and retained executable/image checked. This broad group remains failed. Release,28 ordinary fixture comparisons and the extra boundary comparison did not run. No candidate pass or full-goal completion inferred.')
with (p/'source263-broad-failure-audit.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps({k:record[k] for k in ['status','counts','failed_tests','selected']}))
