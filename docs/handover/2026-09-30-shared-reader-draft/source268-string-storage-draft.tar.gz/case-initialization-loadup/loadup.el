(prin1 (list
  (compare-strings "\u038c\u03c3\u03bf\u03c2" nil nil "\u038c\u03a3\u039f\u03a3" nil nil t)
  (compare-strings "\u1e9e" nil nil "\u00df" nil nil t)
  (aref (char-table-extra-slot (current-case-table) 0) #x3c3)
  (aref (char-table-extra-slot (current-case-table) 0) #xdf)))
(kill-emacs 0)
