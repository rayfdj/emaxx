(progn
  (setq reader-macro-weak (make-hash-table :test 'eq :weakness 'key)
        reader-macro-root-trace nil)
  (fset 'reader-drop-macro
        (lambda ()
          (interactive)
          (setq executing-kbd-macro t)
          (garbage-collect)
          (push (list 'inside (hash-table-count reader-macro-weak))
                reader-macro-root-trace)
          (when reader-macro-raise (error "macro reclamation control"))))
  (mapcar
   (lambda (reader-macro-raise)
     (clrhash reader-macro-weak)
     (setq reader-macro-root-trace nil)
     (let ((overriding-terminal-local-map (make-sparse-keymap))
           (kbd-macro-termination-hook
            (list (lambda ()
                    (garbage-collect)
                    (push (list 'termination (hash-table-count reader-macro-weak))
                          reader-macro-root-trace)))))
       (define-key overriding-terminal-local-map [f35] 'reader-drop-macro)
       (funcall
        (lambda ()
          (let ((macro (vector 'f35)))
            (puthash macro t reader-macro-weak)
            (condition-case nil
                (execute-kbd-macro macro)
              (error (push 'caught reader-macro-root-trace)))))))
     (garbage-collect)
     (garbage-collect)
     (list (nreverse reader-macro-root-trace)
           (hash-table-count reader-macro-weak)))
   '(nil t)))
