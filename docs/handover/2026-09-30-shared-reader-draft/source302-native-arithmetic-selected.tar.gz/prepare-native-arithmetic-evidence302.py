from pathlib import Path
import ast

p = Path(__file__).parent.resolve()
pending = {}

def write(name, source):
    ast.parse(source)
    assert name not in pending and not (p / name).exists()
    pending[name] = source

def replace(source, old, new):
    assert source.count(old) == 1, (old, source.count(old))
    return source.replace(old, new)

source = (p / 'replay-native-bytecode301.py').read_text().replace('len(m) == 532', 'len(m) == 534')
old = next(n.value for n in ast.walk(ast.parse(source)) if isinstance(n, ast.Constant)
           and isinstance(n.value, str) and n.value.startswith('Source301 changes'))
source = replace(source, repr(old), repr('Source302 adds a native two-fixnum +/− direct path after existing handler synchronization.534 input bytes/modes reconstruct from applied4af440a9 and main. All original tests/fixtures remain; a new actual-native arithmetic fixture uses pinned GNU output. Existing workloads, selectors, timeouts and criteria remain unchanged.'))
write('replay-native-arithmetic302.py', source)
source = (p / 'verify-existing-portable-draft.py').read_text().replace('len(m)==532', 'len(m)==534')
write('verify-existing-portable-arithmetic-draft.py', source)

source = (p / 'audit-native-bytecode-selected.py').read_text().replace('source300', 'source302')
source = source.replace('len(manifest) == 532', 'len(manifest) == 534').replace("row['inputs'] == 532", "row['inputs'] == 534").replace('source_inputs_verified=532', 'source_inputs_verified=534').replace('source_inputs=532', 'source_inputs=534')
source = replace(source, "assert [n for n,h in manifest.items() if prior_manifest.get(n)!=h] == ['src/lisp/eval/core.rs']", "assert [n for n,h in manifest.items() if prior_manifest.get(n)!=h] == ['src/lisp/native_comp/runtime.rs', 'src/lisp/primitives/tests.rs', 'tests/fixtures/native-binary-arithmetic.el', 'tests/fixtures/native-binary-arithmetic.expected']")
source = replace(source, "assert (c / 'src/lisp/primitives/tests.rs').read_bytes() == (p.parent / 'recovered-2026-10-05/native-funcall-dispatch/emaxx/src/lisp/primitives/tests.rs').read_bytes()", "prior_tests = (p.parent / 'recovered-2026-10-05/native-funcall-dispatch/emaxx/src/lisp/primitives/tests.rs').read_bytes()\ncurrent_tests = (c / 'src/lisp/primitives/tests.rs').read_bytes()\nassert current_tests.startswith(prior_tests) and current_tests[len(prior_tests):].count(b'#[test]') == 1\nnew_arithmetic_test = 'lisp::primitives::tests::native_binary_arithmetic_preserves_gnu_boundaries_types_and_errors'")
source = replace(source, 'set(inventory) == set(prior)', 'set(inventory) == set(prior) | {new_arithmetic_test}')
source = replace(source, 'assert names == record[\'selectors\']', "assert names == record['selectors'] and new_arithmetic_test in names")
source = replace(source, "names = list(read('source297-selected-audit.json')['ordinary_results'])\nassert len(names) == 46", "names = list(read('source297-selected-audit.json')['ordinary_results']) + ['native-binary-arithmetic']\nassert len(names) == 47")
source = replace(source, "('bytecode-integer-boundaries', 'buffer-lf-line-motion')", "('bytecode-integer-boundaries', 'buffer-lf-line-motion', 'native-binary-arithmetic')")
source = source.replace('ordinary_comparisons=47', 'ordinary_comparisons=48')
old = next(n.value for n in ast.walk(ast.parse(source)) if isinstance(n, ast.Constant)
           and isinstance(n.value, str) and n.value.startswith('Source300 reuses'))
source = replace(source, repr(old), repr('Source302 extends existing native two-fixnum dispatch for +/−.534 input bytes/modes and fresh builds verify; every original test, fixture and complete-inventory name remains.328 selected tests/profile and48 ordinary actual GNU comparisons pass, including the added forced-native arithmetic boundaries. Broad probing retains60 original column-width failures. No performance or full-goal completion is inferred.'))
source = source.replace('ordinary_comparisons=47', 'ordinary_comparisons=48')
write('audit-native-arithmetic-selected.py', source)

source = (p / 'finish-native-bytecode-selected-closed.py').read_text().replace('source300', 'source302')
source = source.replace('native-bytecode-entry-formatted', 'native-binary-arithmetic')
source = source.replace('native-bytecode-selection', 'native-arithmetic-selection').replace('native-bytecode selected audit', 'native-arithmetic selected audit')
source = source.replace('audit-native-bytecode-selected.py', 'audit-native-arithmetic-selected.py').replace('verify-existing-portable-draft.py', 'verify-existing-portable-arithmetic-draft.py')
source = replace(source, "names=list(read('source297-selected-audit.json')['ordinary_results'])\n    assert len(names)==46", "names=list(read('source297-selected-audit.json')['ordinary_results'])+['native-binary-arithmetic']\n    assert len(names)==47")
write('finish-native-arithmetic-selected-closed.py', source)

source = (p / 'measure-native-bytecode.py').read_text().replace('source300', 'source302').replace('native-bytecode-entry-formatted/emaxx', 'native-binary-arithmetic/emaxx').replace('native-bytecode', 'native-arithmetic')
old = next(n.value for n in ast.walk(ast.parse(source)) if isinstance(n, ast.Constant)
           and isinstance(n.value, str) and n.value.startswith('Three alternating repetitions'))
source = replace(source, repr(old), repr('Three alternating repetitions of unchanged full16 pilot,192 normal editor processes. Applied297 is baseline;302 avoids redundant argument staging and primitive numeric conversion for native two-fixnum +/− after existing handler synchronization. All unfavorable samples and original width failures remain. No build/test/profile work overlaps timing. This diagnostic does not certify calibrated nine-round every-case3% acceptance.'))
write('measure-native-arithmetic.py', source)
source = (p / 'audit-native-bytecode-performance.py').read_text().replace('source300', 'source302').replace('native-bytecode', 'native-arithmetic')
old = next(n.value for n in ast.walk(ast.parse(source)) if isinstance(n, ast.Constant)
           and isinstance(n.value, str) and n.value.startswith('Three alternating repetitions'))
source = replace(source, repr(old), repr('Three alternating unchanged full16 pilots verify all192 actual answers/modes for297 and302. Every sample, regression, startup/total/RSS/GC result and unavailable-counter error remains. This is not final calibrated nine-round/three-sample/every-case3% acceptance. Prior GNU census/Emaxx negatives,60 width failures, architecture/ownership/counters and final validation remain open.'))
write('audit-native-arithmetic-performance.py', source)
source = (p / 'finish-native-bytecode-performance-closed.py').read_text().replace('native-bytecode', 'native-arithmetic').replace('source300 selected audit', 'source302 selected audit')
write('finish-native-arithmetic-performance-closed.py', source)
for name, source in pending.items():
    with (p / name).open('x') as f:
        f.write(source)
print('Prepared source302 evidence helpers; no original helper or criterion changed')
