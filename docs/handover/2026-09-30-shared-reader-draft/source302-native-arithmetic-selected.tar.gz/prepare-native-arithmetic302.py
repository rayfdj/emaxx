from pathlib import Path
import ast, hashlib, json, os, subprocess, time

p = Path(__file__).parent.resolve()
root = p.parents[2]
c = p.parent / 'recovered-2026-10-05/native-binary-arithmetic/emaxx'
g = p.parent / 'rebuilt-2026-10-01/emacs'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p / n).read_text())
base = read('source297-applied-commit.json')['commit']
manifest = read('source297-manifest.json')
assert all(sha(root / n) == h for n, h in manifest.items())
assert read('source301-application-decision.json')['status'] == 'reject source300 and source301; retain applied source297'
assert not c.exists()
c.parent.mkdir()
(c.parent / 'emacs').symlink_to(g, target_is_directory=True)
for command in [
    ['git', 'clone', '--shared', '--quiet', '--no-checkout', str(root), str(c)],
    ['git', '-C', str(c), 'sparse-checkout', 'init', '--no-cone'],
    ['git', '-C', str(c), 'sparse-checkout', 'set', '--no-cone', *sorted({'/' + n for n in manifest} | {'/tools/', '/compat/'})],
    ['git', '-C', str(c), 'checkout', '--detach', base],
]:
    subprocess.run(command, check=True)
assert all(sha(c / n) == h for n, h in manifest.items())
path = c / 'src/lisp/native_comp/runtime.rs'
before = path.read_text()
old = '''            if let Some(result) = result {
                return native_boolean(result);
            }
        }
        if subroutine.name == "cons" && arguments.len() == 2 {
'''
new = '''            if let Some(result) = result {
                return native_boolean(result);
            }
            // data.c:arith_driver keeps integer addition/subtraction in its
            // machine accumulator. Two fixnums cannot overflow i64; return
            // their immediate result without staging or decoding Values.
            // Bignum results and every other operand use the general path.
            let integer = match subroutine.name {
                "+" => Some(left + right),
                "-" => Some(left - right),
                _ => None,
            };
            if let Some(integer) = integer
                && (MOST_NEGATIVE_FIXNUM..=MOST_POSITIVE_FIXNUM).contains(&integer)
            {
                return ((integer as NativeWord) << FIXNUM_BITS) | TAG_FIXNUM_LOW;
            }
        }
        if subroutine.name == "cons" && arguments.len() == 2 {
'''
assert before.count(old) == 1
path.write_text(before.replace(old, new))
assert path.read_text()[path.read_text().index('mod tests {'):] == before[before.index('mod tests {'):]
fixture = c / 'tests/fixtures/native-binary-arithmetic.el'
fixture.write_text('''(progn
  (require 'comp)
  (let* ((lexical-binding t)
         (plus (native-compile '(lambda (left right) (+ left right))))
         (minus (native-compile '(lambda (left right) (- left right))))
         (lo most-negative-fixnum)
         (hi most-positive-fixnum)
         (values (list lo (1+ lo) -47 -1 0 1 83 (1- hi) hi
                       (1- lo) (1+ hi) (- (ash 1 63)) (1- (ash 1 63))
                       1.5 'native-arithmetic-error nil))
         (pairs (append (mapcar (lambda (x) (list x 1)) values)
                        (mapcar (lambda (x) (list -1 x)) values)
                        (mapcar (lambda (x) (list x 0)) values)
                        (list (list hi hi) (list lo lo) (list lo hi)
                              (list hi lo) (list hi -1) (list lo 1))))
         rows)
    (unless (and (native-comp-function-p plus) (native-comp-function-p minus))
      (error "Arithmetic workers must execute native code"))
    (dolist (operator '(+ -))
      (dolist (pair pairs)
        (let ((answer (condition-case error
                          (apply (if (eq operator '+) plus minus) pair)
                        (error error))))
          (garbage-collect)
          (push (list operator pair answer (integerp answer) (fixnump answer)) rows))))
    (list (native-comp-function-p plus) (native-comp-function-p minus)
          (nreverse rows)
          (with-temp-buffer
            (insert "abcdefgh")
            (let ((marker (copy-marker 3)))
              (list (funcall plus marker 5)
                    (funcall minus marker 2)
                    (funcall plus 11 marker)
                    (funcall minus 11 marker)))))))
''')
# Record the real pinned GNU result before accepting any expected output.
binary = g / 'src/emacs'
command = [str(binary), '-Q', '--batch', '--eval', '(prin1 ' + fixture.read_text() + ')']
inputs = {str(f): sha(f) for f in [binary, binary.with_suffix('.pdmp'), fixture, g / 'src/data.c', Path(__file__)]}
stem = p / 'source302-arithmetic-reference'
with stem.with_suffix('.command.json').open('x') as f:
    json.dump(dict(command=command, working_directory=str(p), inputs=inputs, timeout_seconds=120,
                   environment_override=dict(LANG='C', LC_ALL='C')), f, indent=2)
start = time.monotonic()
try:
    outcome = subprocess.run(command, cwd=p, env=dict(os.environ, LANG='C', LC_ALL='C'),
                             stdin=subprocess.DEVNULL, capture_output=True, timeout=120)
    code, out, err, timed_out = outcome.returncode, outcome.stdout, outcome.stderr, False
except subprocess.TimeoutExpired as error:
    code, out, err, timed_out = None, error.stdout or b'', error.stderr or b'', True
for suffix, data in [('stdout', out), ('stderr', err)]:
    with stem.with_suffix('.' + suffix).open('xb') as f:
        f.write(data)
record = dict(exit_code=code, timed_out=timed_out, elapsed_seconds=time.monotonic()-start,
              stdout_sha256=hashlib.sha256(out).hexdigest(), stderr_sha256=hashlib.sha256(err).hexdigest(),
              inputs_unchanged=all(sha(Path(n)) == h for n, h in inputs.items()))
with stem.with_suffix('.result.json').open('x') as f:
    json.dump(record, f, indent=2)
assert code == 0 and not timed_out and not err and out.startswith(b'(t t ') and record['inputs_unchanged'], record
fixture.with_suffix('.expected').write_bytes(out + b'\n')
test = '''
#[test]
fn native_binary_arithmetic_preserves_gnu_boundaries_types_and_errors() {
    assert_oracle_contract_matches_interpreter(
        include_str!("../../../tests/fixtures/native-binary-arithmetic.el"),
        include_str!("../../../tests/fixtures/native-binary-arithmetic.expected").trim_end(),
        "native addition and subtraction across fixnum, bignum, float, marker and error boundaries",
    );
}
'''
test_path = c / 'src/lisp/primitives/tests.rs'
original_tests = test_path.read_text()
test_path.write_text(original_tests + test)
subprocess.run(['cargo', 'fmt', '--all'], cwd=c, check=True)
assert test_path.read_text() == original_tests + test
assert [n for n,h in manifest.items() if sha(c / n) != h] == ['src/lisp/native_comp/runtime.rs', 'src/lisp/primitives/tests.rs']
with (p / 'source302-static-review.json').open('x') as f:
    json.dump(dict(status='unvalidated native two-fixnum addition/subtraction', candidate=str(c), base_commit=base,
        inputs={str(f): sha(f) for f in [path, test_path, fixture, fixture.with_suffix('.expected'), g / 'src/data.c']},
        mechanism='Extend the existing two-fixnum numeric dispatch after unchanged handler synchronization. GNU data.c:arith_driver uses a machine integer accumulator and make_int. Two signed62-bit fixnums add/subtract within signed64 bits. Only an in-range fixnum result returns directly; every bignum result/nonfixnum/other arity uses the unchanged general path.',
        removed_work='Avoid SmallVec argument staging, decode_live, repeated primitive dispatch, numeric coercion and normalization for two-fixnum +/-. Two arguments already fit inline; no removed heap-allocation claim. No new cache, registry, representation or unsafe access.',
        preserved='Existing handler synchronization, descriptor identity and ABI, other arities, GC entry, roots, debugger/backtrace, nonlocal exits and all fallback/error behavior remain. All original tests/fixtures are preserved. One differential fixture forces actual native workers, varied fixnum boundaries and promotion, invalid operands, floats, markers and collection after every result.',
        limits='Does not resolve known column widths, census failures, public ownership, real counters, remaining representation or final performance requirements.', goal_complete=False), f, indent=2)

runner = (p / 'run-source301-validation.py').read_text().replace('source301', 'source302').replace('source300', 'source297')
runner = runner.replace('native-bytecode-inline/emaxx', 'native-binary-arithmetic/emaxx').replace('native-bytecode-entry-formatted/emaxx', 'native-funcall-dispatch/emaxx')
runner = runner.replace("'tests/fixtures/buffer-lf-line-index.el', 'tests/fixtures/buffer-lf-line-index.expected', 'tests/fixtures/buffer-lf-line-motion.el', 'tests/fixtures/buffer-lf-line-motion.expected'", "'tests/fixtures/native-binary-arithmetic.el', 'tests/fixtures/native-binary-arithmetic.expected'")
runner = runner.replace('len(manifest) == 532', 'len(manifest) == 534')
runner = runner.replace("assert changes == ['src/lisp/eval/core.rs']", "assert changes == ['src/lisp/native_comp/runtime.rs', 'src/lisp/primitives/tests.rs', 'tests/fixtures/native-binary-arithmetic.el', 'tests/fixtures/native-binary-arithmetic.expected']")
runner = runner.replace("assert set(inventory) == set(prior) and len(inventory) == len(set(inventory))", "new_test = 'lisp::primitives::tests::native_binary_arithmetic_preserves_gnu_boundaries_types_and_errors'\n        assert set(inventory) == set(prior) | {new_test} and len(inventory) == len(set(inventory))")
runner = runner.replace('assert required_boundary_test in selectors', 'assert required_boundary_test in selectors and new_test in selectors')
ast.parse(runner)
with (p / 'run-source302-validation.py').open('x') as f:
    f.write(runner)
generated = (p / 'compare-source301-generated-loaded.py').read_text().replace('source301', 'source302').replace('native-bytecode-inline/emaxx', 'native-binary-arithmetic/emaxx')
ast.parse(generated)
with (p / 'compare-source302-generated-loaded.py').open('x') as f:
    f.write(generated)
print('Prepared source302: shared two-fixnum dispatch and pinned-GNU native arithmetic control', flush=True)
