from pathlib import Path
import hashlib, json, subprocess

p = Path(__file__).parent.resolve()
root = p.parents[2]
c = p.parent / 'recovered-2026-10-05/native-binary-arithmetic/emaxx'
d = root / 'docs/handover/2026-09-30-shared-reader-draft'
read = lambda n: json.loads((p / n).read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
pre_apply_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert pre_apply_head == read('source301-closed-publication.json')['commit']
assert read('source302-application-decision.json')['status'].startswith('apply source302')
assert read('native-arithmetic-performance-sequence-closed-result.json')['status'] == 'timing audited; source decision pending'
timing = read('native-arithmetic-performance-audit.json')
assert timing['status'] == 'all 192 processes and actual results/modes verified' and not timing['short_bodies']
selected = read('source302-selected-audit.json')
assert selected['status'] == 'passed' and selected['source_inputs_verified'] == 534
assert selected['ordinary_comparisons'] == 48
assert all(x['passed'] == 328 and x['failed'] == x['ignored'] == 0 for x in selected['profiles'].values())
assert selected['retained_broad_probe_failure']['exact_match'] is False
for audit in [selected, timing]:
    assert all(sha(Path(n)) == h for n, h in audit['evidence_files'].items())
assert all(sha(root / n) == h for n,h in read('source297-manifest.json').items())
manifest = read('source302-manifest.json')
assert all(sha(c / n) == h for n,h in manifest.items())
patch = p / 'source302-portable-incremental.patch'
portable = read('source302-portable-draft-audit.json')['patches'][0]
assert sha(patch) == portable['sha256'] and portable['base'] == read('source297-applied-commit.json')['commit']
steps = []
for command in [['git', 'apply', '--check', str(patch)], ['git', 'apply', str(patch)], ['git', 'diff', '--check']]:
    run = subprocess.run(command, cwd=root, capture_output=True, text=True)
    steps.append(dict(command=command, exit_code=run.returncode, stdout=run.stdout, stderr=run.stderr))
    assert run.returncode == 0, steps[-1]
assert all(sha(root / n) == h and (root / n).stat().st_mode & 0o777 == (c / n).stat().st_mode & 0o777 for n,h in manifest.items())
record = dict(status='source302 applied; all534 validated bytes and modes verified', pre_apply_head=pre_apply_head,
              portable_patch_base=portable['base'], patch_sha256=sha(patch), steps=steps, goal_complete=False)
with (p / 'source302-applied-source-verification.json').open('x') as f:
    json.dump(record, f, indent=2)
for name in ['source302-application-decision.json', 'source302-applied-source-verification.json']:
    with (d / name).open('xb') as f:
        f.write((p / name).read_bytes())
print(record['status'])
