from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda b: hashlib.sha256(b).hexdigest()
read = lambda n: json.loads((p / n).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
audit = read('source279-gate-broad-audit.json')
assert audit['status'] == 'passed' and audit['counts'] == {'ok': 1067, 'FAILED': 0, 'ignored': 0}
names = ['source279-gate-broad-audit.json', 'source279-gate-broad-command.json', 'source279-gate-broad-result.json', 'source279-gate-broad.log', 'audit-source279-broad.py', 'package-source196-failure-and197-results.py', Path(__file__).name]
package('source279-string-allocation-gate-broad', {n: p / n for n in names}, dict(audit=audit, qualification='Supplement to source279-string-allocation-recovery-draft. All1067 affected gate tests execute and pass. Original source276 Emaxx -130 first-vector result remains unexplained and preserved; this does not claim its cause fixed. Release, ordinary, full-platform and performance validation remain separate.', goal_complete=False))
