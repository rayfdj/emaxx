from pathlib import Path
import hashlib, json, math, runpy, statistics
p=Path(__file__).parent.resolve(); root=p.parents[2]
read=lambda f:json.loads(f.read_text())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
module=runpy.run_path(str(root/'tools/core_runtime_perf.py'),run_name='audit_only')
state=read(p/'native-audit-performance-result.json')
assert state['status']=='all diagnostic comparisons finished; raw audit required'
assert len(state['results'])==7 and all(r['exit_code']==0 and r['source_unchanged'] for r in state['results'])
contract=read(root/'compat/core_runtime_perf.json')
assert len(contract['cases'])==16 and contract['parity_ratio_limit']==1.03
variants=['source302','source304']
rows={case['id']:{tag:[] for tag in variants} for case in contract['cases']}
evidence={}; processes=0; short_bodies=[]
for repeat in range(3):
    for tag in variants:
        directory=p/(tag+'-native-audit-pilot-'+str(repeat))
        assert read(directory/'contract.json')==contract
        provenance=read(directory/'provenance.json')
        assert provenance['frozen_oracle_identity']
        assert all(sha(Path(n))==h for n,h in provenance['input_sha256'].items())
        assert read(directory/'final-inputs.json')==dict(unchanged=True,input_sha256=provenance['input_sha256'])
        records=read(directory/'runs.json');assert len(records)==32
        assert {(r['round'],r['runner'],r['case_id']) for r in records}=={(0,runner,case['id']) for runner in ('oracle','emaxx') for case in contract['cases']}
        for case in contract['cases']:
            paired={}
            for runner in ('oracle','emaxx'):
                location=directory/'round-00'/case['id']/runner
                record=read(location/'validation.json');process=read(location/'process.json');report=read(location/'report.json')
                assert record==next(r for r in records if r['case_id']==case['id'] and r['runner']==runner)
                observations=module['validate_report'](report,process,case,contract,(location/'stdout.txt').read_text(),0,1)
                assert record['validation']=='completed' and record['process']==process and record['observations']==observations
                assert report['modes']==record['modes']==case['modes']
                assert len(observations)==1 and observations[0]['result']==case['result']
                paired[runner]=dict(observation=observations[0],modes=report['modes'],process=process)
                if observations[0]['seconds']<contract['minimum_body_seconds']:
                    short_bodies.append(dict(source=tag,repeat=repeat,case=case['id'],runner=runner,seconds=observations[0]['seconds']))
                processes+=1
            assert paired['oracle']['observation']['result']==paired['emaxx']['observation']['result']
            assert paired['oracle']['modes']==paired['emaxx']['modes']
            rows[case['id']][tag].append(dict(repeat=repeat,ratio=paired['emaxx']['observation']['seconds']/paired['oracle']['observation']['seconds'],**paired))
        summary=read(directory/'summary.json')
        recomputed=module['summarize'](records,contract['cases'],dict(contract,rounds=1),['oracle','emaxx'],False,False)
        recomputed.update(action='pilot',certification_eligible=False,inputs_unchanged=True)
        assert recomputed==summary and summary['complete_inventory'] and not summary['criterion_satisfied']
        assert all(r['same_modes'] and not r['allocation_counters_available'] for r in summary['cases'])
        evidence.update({str(f):sha(f) for f in directory.rglob('*') if f.is_file()})
assert processes==192
cases=[]
for case in contract['cases']:
    samples=rows[case['id']]
    medians={tag:statistics.median(r['emaxx']['observation']['seconds'] for r in samples[tag]) for tag in variants}
    ratios={tag:statistics.median(r['ratio'] for r in samples[tag]) for tag in variants}
    cases.append(dict(case=case['id'],emaxx_median_seconds=medians,median_gnu_ratios=ratios,
                      optimized_over_baseline=medians['source304']/medians['source302'],
                      samples=samples))
result=dict(status='all 192 processes and actual results/modes verified',cases=cases,short_bodies=short_bodies,
            geometric_mean_gnu_ratios={tag:math.exp(statistics.mean(math.log(r['median_gnu_ratios'][tag]) for r in cases)) for tag in variants},
            geometric_mean_optimized_over_baseline=math.exp(statistics.mean(math.log(r['optimized_over_baseline']) for r in cases)),
            evidence_files=evidence,goal_complete=False,
            qualification='Three alternating unchanged full16 pilots verify all192 actual results/modes for original302 and width-corrected304. Preserve original60 column failures and all timing samples, including the cost of correctness. Builds/tests/profiles are separate. Real counters, full architecture/ownership, calibrated nine-round/every-case3% performance and final validation/audit remain required.')
with (p/'native-audit-performance-audit.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps(dict(status=result['status'],geometric_mean_gnu_ratios=result['geometric_mean_gnu_ratios'],optimized_over_baseline=result['geometric_mean_optimized_over_baseline'],cases=[{k:r[k] for k in ('case','median_gnu_ratios','optimized_over_baseline')} for r in cases],short_bodies=short_bodies),indent=2))
