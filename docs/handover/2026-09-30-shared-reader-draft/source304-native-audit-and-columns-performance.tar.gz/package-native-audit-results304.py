from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
out = p.parents[2] / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected', '.h'}
selected = read('source304-selected-audit.json')
timing = read('native-audit-performance-audit.json')
decision = read('source304-application-decision.json')
assert selected['status'] == 'passed' and selected['source_inputs_verified'] == 534
assert selected['ordinary_comparisons'] == 49
assert all(r['passed'] == 506 and r['failed'] == r['ignored'] == 0 for r in selected['profiles'].values())
assert selected['closed_broad_probe_failure']['different_rows'] == 0
assert timing['status'] == 'all 192 processes and actual results/modes verified'
assert read('native-audit-performance-sequence-closed-result.json')['status'] == 'timing audited; source decision pending'
for audit in [selected, timing]:
    assert all(sha(Path(n).read_bytes()) == h for n,h in audit['evidence_files'].items())
for name in ['source302-full-validation-failures', 'source303-buffer-columns-selected']:
    m = json.loads((out / (name + '-manifest.json')).read_text())
    assert sha((out / m['archive']['path']).read_bytes()) == m['archive']['sha256']
helpers = ['record-native-audit304.py', 'prepare-native-audit304.py', 'prepare-native-audit-evidence304.py', 'prepare-native-audit-performance304.py', 'prepare-native-audit-publication304.py', 'run-source304-validation.py', 'replay-native-audit304.py', 'audit-native-audit-selected.py', 'finish-native-audit-selected-closed.py', 'apply-native-audit304.py', 'setup-source304-full-macos.py', 'queue-source304-full-macos.py', 'audit-source304-selected-for-full.py', 'compare-source304-generated-loaded.py', 'compare-source303-generated-loaded.py', 'compare-source302-generated-loaded.py', 'compare-vm-dispatch-fixtures.py', 'compare-buffer-line-broad-probe.py', 'native_fixed_validation_support.py', 'verify-existing-portable-arithmetic-draft.py', 'source303-manifest.json', 'source303-selected-audit.json', 'source303-gate-inventory.log', 'source303-release-inventory.log', 'source302-line-broad-diagnosis.json', 'source302-line-broad-gnu.stdout', 'source302-line-broad-emaxx.stdout', 'printer-varied-v3-293638f0.el', 'printer-varied-v3-gnu.stdout', 'package-source196-failure-and197-results.py', Path(__file__).name]
files = {f.name:f for f in p.iterdir() if f.is_file() and f.suffix in allowed and f.name.startswith(('source304-', 'native-audit-selection-'))}
files.update({name:p/name for name in helpers})
package('source304-native-audit-and-columns-selected', files, dict(
    status='closed fresh selected validation; full platform validation next', source_inputs_verified=534,
    profiles={k:{n:r[n] for n in ['passed','failed','ignored']} for k,r in selected['profiles'].items()},
    ordinary_comparisons=49, closed_broad_probe_failure=selected['closed_broad_probe_failure'],
    audit=dict(path='source304-selected-audit.json', sha256=sha((p/'source304-selected-audit.json').read_bytes())),
    qualification=selected['qualification'], goal_complete=False))
files = {}
for tag in ['source302', 'source304']:
    for directory in sorted(p.glob(tag + '-native-audit-pilot-*')) + [p/(tag+'-core-native')]:
        files.update({str(f.relative_to(p)):f for f in directory.rglob('*') if f.is_file() and f.suffix in allowed})
files.update({f.name:f for f in p.iterdir() if f.is_file() and f.suffix in allowed and f.name.startswith('native-audit-performance-')})
for name in ['measure-native-audit.py', 'audit-native-audit-performance.py', 'finish-native-audit-performance-closed.py', 'source304-application-decision.json', 'package-source196-failure-and197-results.py', Path(__file__).name]:
    files[name] = p/name
package('source304-native-audit-and-columns-performance', files, dict(
    status=timing['status'], audit=dict(path='native-audit-performance-audit.json',sha256=sha((p/'native-audit-performance-audit.json').read_bytes())),
    application_decision=decision, qualification=timing['qualification'], goal_complete=False))
