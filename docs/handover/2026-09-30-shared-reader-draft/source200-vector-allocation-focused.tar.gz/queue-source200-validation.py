from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/macro-reader/emaxx'
manifest = json.loads((p / 'source200-manifest.json').read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
unchanged = lambda: all(sha(root / f) == h for f, h in manifest.items())
fixtures = json.loads((p / 'source196-fresh-selected-validation-result.json').read_text())['steps'][-1]['script'][3:]
fixtures += ['input-decode-macro-reclamation', 'input-decode-down-event-binding']
fixtures += ['vector-closure-rounded-census', 'vector-pseudovector-word-census', 'shared-vector-native-words', 'shared-positioned-symbol-native-words', 'shared-string-native-words', 'char-table-identity', 'char-table-authoritative-values', 'char-table-range-uniprop']
assert len(fixtures) == len(set(fixtures)) == 36
steps = [
    ['check-reader200.py', '200'],
    ['static-reader200.py', '200'],
    ['test-reader200.py', '200', 'gate'],
    ['test-reader200.py', '200', 'release'],
    ['build-reader200.py', '200'],
    ['compare-recovered-continuation-fixtures.py', 'source200', str(root), *fixtures],
]
results = []
for args in steps:
    assert unchanged()
    started = time.monotonic()
    completed = subprocess.run([sys.executable, str(p / args[0]), *args[1:]], stdin=subprocess.DEVNULL)
    result = {'script': args, 'exit_code': completed.returncode,
              'source_unchanged': unchanged(), 'elapsed_seconds': time.monotonic() - started}
    results.append(result)
    if completed.returncode or not result['source_unchanged']:
        break
passed = len(results) == len(steps) and all(item['exit_code'] == 0 and item['source_unchanged'] for item in results)
with (p / 'source200-selected-validation-result.json').open('x') as stream:
    json.dump({'steps': results, 'passed': passed, 'all_completed': len(results) == len(steps),
               'source_unchanged': unchanged(), 'completed_unix': time.time(),
               'qualification': 'Selected combined-source validation. Preserves the failed source198 Linux reclamation gate and the source200 baseline footprint/counter failures. Complete final-source and performance validation remain required.'}, stream, indent=2)
raise SystemExit(0 if passed else 1)
