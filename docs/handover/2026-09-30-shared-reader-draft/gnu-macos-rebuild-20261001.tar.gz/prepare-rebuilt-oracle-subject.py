from pathlib import Path
import hashlib, json, os, subprocess, sys, time

p=Path(__file__).parent.resolve()
root=p.parents[2]
subject=p.parent/'rebuilt-2026-10-01/emaxx'
gnu=subject.parent/'emacs'
previous=p.parent/'recovered-2026-09-30/coding-property-order/emaxx'
manifest=json.loads((p/'source249-manifest.json').read_text())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
patch=p/'source249-incremental.patch'
assert not subject.exists()
assert sha(patch)=='18b86ffbac957e614ed8dbd87e447488c8d25a5ad54f62e2958a91e604206a65'
commands=[]
record=dict(status='preparing isolated rebuilt-oracle subject',source_manifest='source249-manifest.json',goal_complete=False)
def run(name,command,cwd,environment=None,timeout=1800):
    command=list(map(str,command))
    start=time.monotonic()
    with (p/('rebuilt-oracle-subject-'+name+'-command.json')).open('x') as f:
        json.dump(dict(command=command,working_directory=str(cwd),environment_override=environment or {},timeout_seconds=timeout),f,indent=2)
    with (p/('rebuilt-oracle-subject-'+name+'.log')).open('x') as log:
        result=subprocess.run(command,cwd=cwd,env={**os.environ,**(environment or {})},stdin=subprocess.DEVNULL,
                              stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
    row=dict(name=name,exit_code=result.returncode,elapsed_seconds=time.monotonic()-start)
    commands.append(row)
    assert result.returncode==0,(name,result.returncode)
try:
    run('checkout',['git','worktree','add','--detach',subject,'1d187ba63e485ec4ecfe0227c148287a230f8f09'],root)
    run('patch-check',['git','apply','--check',patch],subject)
    run('patch',['git','apply',patch],subject)
    assert len(manifest)==476 and all(sha(subject/n)==h for n,h in manifest.items())
    assert gnu.is_dir() and (subject/'../emacs').resolve()==gnu.resolve()
    (subject/'target').mkdir(exist_ok=True)
    run('completed-cache-copy',['cp','-cR',previous/'target/frame-validation',subject/'target/oracle-validation'],root)
    environment={'CARGO_TARGET_DIR':str(subject/'target/oracle-validation'),'CARGO_BUILD_JOBS':'1',
                 'LANG':'C','LC_ALL':'C','EMAXX_GNU_SOURCE_DIRECTORY':str(gnu)}
    run('build',['cargo','build','--locked','--all-features','--profile','gate',
                 '--bin','emaxx','--bin','make-fingerprint','--bin','compat-harness'],subject,environment)
    assert all(sha(subject/n)==h for n,h in manifest.items())
    binaries=[subject/'target/oracle-validation/gate'/n for n in ['emaxx','make-fingerprint','compat-harness']]
    record.update(status='isolated source249 subject built against rebuilt GNU installation',source_unchanged=True,
                  artifacts={str(f):{'sha256':sha(f),'bytes':f.stat().st_size} for f in binaries},
                  qualification='Build preparation only. The isolated source249 candidate remains under selected validation; oracle pin, image, canonical inventory and frozen comparison are not yet validated.')
except Exception as error:
    record.update(status='failed',error=repr(error))
finally:
    record['commands']=commands
    with (p/'rebuilt-oracle-subject-prepare-result.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps({k:record[k] for k in ['status','error','source_unchanged'] if k in record}),flush=True)
raise SystemExit(0 if record['status'].startswith('isolated') else 1)
