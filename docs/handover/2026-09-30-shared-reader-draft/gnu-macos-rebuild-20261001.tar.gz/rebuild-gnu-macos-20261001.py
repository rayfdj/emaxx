from pathlib import Path
import hashlib, json, os, subprocess, sys, time

p = Path(__file__).parent.resolve()
root = p.parents[2]
source = p.parent / 'recovered-2026-09-30/emacs'
destination = p.parent / 'rebuilt-2026-10-01/emacs'
recipe = root / 'tools/build_macos_oracle.py'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
def save(name, data):
    with (p / ('gnu-macos-rebuild-20261001-' + name + '.json')).open('x') as f:
        json.dump(data, f, indent=2)
        f.write('\n')
def git(*args):
    return subprocess.check_output(['git', '-C', str(source), *args], text=True).strip()
assert not destination.exists()
assert git('rev-parse', 'HEAD') == '636f166cfc86aa90d63f592fd99f3fdd9ef95ebd'
assert git('status', '--porcelain') == ''
inputs = [recipe, Path(__file__).resolve(), root / 'compat/oracle.lock.json',
          root / 'src/lisp/native_comp/generated_native_subrs_aarch64_apple_darwin.rs',
          source / 'src/emacs', source / 'src/config.h', source / 'src/Makefile',
          *sorted((source / 'src').glob('*.pdmp'))]
before = {str(f): {'sha256': sha(f), 'bytes': f.stat().st_size} for f in inputs}
command = [sys.executable, '-B', str(recipe), str(source), str(destination), '--jobs', '2']
environment = {'LANG': 'C', 'LC_ALL': 'C'}
save('command', dict(command=command, working_directory=str(root), environment_override=environment,
                     inherited_home=os.environ.get('HOME'), input_files=before, source_revision=git('rev-parse','HEAD'),
                     purpose='Rebuild the recorded GNU macOS oracle without changing the committed pin or ABI'))
started = time.monotonic()
record = {'command': command, 'exit_code': None}
try:
    with (p / 'gnu-macos-rebuild-20261001-build.log').open('x') as log:
        result = subprocess.run(command, cwd=root, env={**os.environ, **environment},
                                stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, timeout=10800)
    record['exit_code'] = result.returncode
    if result.returncode == 0:
        record['build_metadata'] = json.loads((destination.parent / 'emacs-build.json').read_text())
        outputs = [destination / 'src/emacs', destination / 'src/config.h', destination / 'src/Makefile',
                   *sorted((destination / 'src').glob('*.pdmp'))]
        record['output_files'] = {str(f): {'sha256': sha(f), 'bytes': f.stat().st_size} for f in outputs}
except Exception as error:
    record['error'] = repr(error)
finally:
    record.update(elapsed_seconds=time.monotonic()-started,
                  input_files_unchanged=all(f.is_file() and sha(f)==before[str(f)]['sha256'] for f in inputs),
                  source_clean=git('status','--porcelain')=='')
    save('result', record)
print(json.dumps({k:v for k,v in record.items() if k not in ('output_files','build_metadata','command')}), flush=True)
raise SystemExit(0 if record['exit_code']==0 and record['input_files_unchanged'] and record['source_clean'] else 1)
