from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p=Path(__file__).parent.resolve()
root=p.parents[2]
gnu=p.parent/'rebuilt-2026-10-01/emacs'
out=root/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda name:json.loads((p/name).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body
          if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
build=read('gnu-macos-rebuild-20261001-result.json')
verification=read('gnu-macos-rebuild-20261001-verification.json')
assert build['exit_code']==0 and build['input_files_unchanged'] and build['source_clean']
assert verification['status'].startswith('passed') and verification['inputs_unchanged'] and verification['artifacts_unchanged']
assert all(item['byte_identical'] for item in verification['manifests'])
assert all(sha(Path(n).read_bytes())==info['sha256'] for n,info in build['output_files'].items())
files={f.name:f for f in p.iterdir() if f.is_file() and f.name.startswith('gnu-macos-rebuild-20261001-')
       and f.suffix in {'.json','.log'}}
for name in ['rebuild-gnu-macos-20261001.py','verify-gnu-macos-rebuild-20261001.py',
             'package-source196-failure-and197-results.py',Path(__file__).name]:files[name]=p/name
for f in p.iterdir():
    if f.is_file() and f.suffix in {'.json','.log'} and f.name.startswith(('rebuilt-oracle-subject-','rebuilt-oracle-frozen-')):
        if f.name.startswith('rebuilt-oracle-frozen-empty-target-') or f.name=='rebuilt-oracle-frozen-empty-target.log':
            continue
        files[f.name]=f
for name in ['prepare-rebuilt-oracle-subject.py','run-rebuilt-oracle-frozen-candidate.py',
             'retry-rebuilt-oracle-frozen-empty-target.py','rebuilt-oracle-frozen-empty-target-launch.json',
             'rebuilt-oracle-frozen-empty-target-setup.json','rebuilt-oracle-frozen-empty-target-command.json']:
    files[name]=p/name
for name in ['manifest.json','verification.json']:
    files['rebuilt-oracle-frozen-gnu-inputs/'+name]=p/'rebuilt-oracle-frozen-gnu-inputs'/name
files['rebuilt-oracle-frozen-empty-target-gnu-inputs/manifest.json']=p/'rebuilt-oracle-frozen-empty-target-gnu-inputs/manifest.json'
files['tools/build_macos_oracle.py']=root/'tools/build_macos_oracle.py'
files['tools/generate_native_subrs.rs']=root/'tools/generate_native_subrs.rs'
files['emacs-build.json']=gnu.parent/'emacs-build.json'
for name in ['config.h','Makefile']:files['gnu/src/'+name]=gnu/'src'/name
for f in (gnu.parent/'verification').iterdir():
    if f.is_file() and f.suffix in {'.json','.stdout','.stderr','.rs','.diff'}:
        files['verification/'+f.name]=f
package('gnu-macos-rebuild-20261001',files,
        dict(build=build,verification=verification,
             qualification='The requested rebuild uses pristine GNU revision 636f166c and the recorded Apple-libxml2 recipe. Finished capabilities match the retained source/ABI-matched build, and regenerated native ABI, C primitives and DEFSYM manifests are byte-identical to the committed files. Actual executable/dump/configuration/Makefile identities are retained. This verifies the build, not the frozen compatibility inventory or the full runtime/performance goal. A replacement pin is committed only in isolated candidate 1c0898fc; the original lock is retained. Its first frozen launch exits 2 before tests because a copied Cargo target has no ownership marker. The failed raw launch is preserved, all four GNU inputs remain unchanged, and retry58661 uses the same command with a fresh target. The active retry log and any eventual result are excluded from this snapshot.'))
