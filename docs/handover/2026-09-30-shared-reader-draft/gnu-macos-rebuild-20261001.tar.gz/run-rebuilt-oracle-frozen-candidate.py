from pathlib import Path
import hashlib, json, os, subprocess, sys, time

p=Path(__file__).parent.resolve()
root=p.parents[2]
subject=p.parent/'rebuilt-2026-10-01/emaxx'
gnu=subject.parent/'emacs'
harness=subject/'target/oracle-validation/gate/compat-harness'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
manifest=json.loads((p/'source249-manifest.json').read_text())
unchanged=lambda:all((subject/n).is_file() and sha(subject/n)==h for n,h in manifest.items())
environment={'LANG':'C','LC_ALL':'C','CARGO_BUILD_JOBS':'1','RUST_MIN_STACK':'134217728','RUST_TEST_THREADS':'1'}
state=dict(status='waiting for completed GNU verification and subject build',goal_complete=False,
           qualification='Isolated replacement-oracle candidate. No existing frozen inventory, selector or timeout is changed. A local commit makes the comparison addressable; it does not certify the candidate.')
commands=[]
capture=p/'rebuilt-oracle-frozen-gnu-inputs'
captured=False
def save_state():
    (p/'rebuilt-oracle-frozen-state.json').write_text(json.dumps(state,indent=2)+'\n')
def save(name,data):
    with (p/('rebuilt-oracle-frozen-'+name+'.json')).open('x') as f:json.dump(data,f,indent=2)
def wait_result(name):
    deadline=time.monotonic()+10800
    while not (p/name).exists():
        assert time.monotonic()<deadline, 'missing result: '+name
        time.sleep(5)
    return json.loads((p/name).read_text())
def run(name,command,timeout=1800,check=True):
    command=list(map(str,command))
    state.update(status='running '+name,current_command=command)
    save_state()
    save(name+'-command',dict(command=command,working_directory=str(subject),environment_override=environment,timeout_seconds=timeout))
    start=time.monotonic()
    with (p/('rebuilt-oracle-frozen-'+name+'.log')).open('x') as log:
        result=subprocess.run(command,cwd=subject,env={**os.environ,**environment},stdin=subprocess.DEVNULL,
                              stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
    row=dict(name=name,exit_code=result.returncode,elapsed_seconds=time.monotonic()-start,source_unchanged=unchanged())
    commands.append(row)
    save(name+'-result',row)
    if check:assert result.returncode==0 and row['source_unchanged'],(name,row)
    return result.returncode
save_state()
try:
    verification=wait_result('gnu-macos-rebuild-20261001-verification.json')
    assert verification['status'].startswith('passed') and verification['inputs_unchanged'] and verification['artifacts_unchanged']
    prepared=wait_result('rebuilt-oracle-subject-prepare-result.json')
    assert prepared['status'].startswith('isolated') and prepared['source_unchanged']
    assert all(sha(Path(n))==info['sha256'] for n,info in prepared['artifacts'].items())
    assert len(manifest)==476 and unchanged()
    for suffix in ['check','fmt','clippy','diff','gate-controls-setup-replay','gate-broad']:
        result=json.loads((p/('source249-'+suffix+'-result.json')).read_text())
        assert result['exit_code']==0 and result['source_unchanged']
    before=json.loads((subject/'compat/oracle.lock.json').read_text())
    assert before==json.loads((root/'compat/oracle.lock.json').read_text())
    save('prior-lock',before)
    original_inventory=sha(subject/'compat/oracle_tests_all.txt')
    assert original_inventory=='a1f87443aad516a128001595d7c69fbbaace40b420d8cd1e9e5ec178aa2fd615'
    run('capture',[sys.executable,'-B',root/'tools/retain_oracle_artifacts.py','capture','--oracle-source',gnu,'--output',capture])
    captured=True
    run('propose-pin',[harness,'oracle','pin','--emacs',gnu/'src/emacs','--repo',gnu])
    proposed=json.loads((subject/'compat/oracle.lock.json').read_text())
    save('proposed-lock',proposed)
    assert proposed['emacs_binary_sha256']==verification['binary_sha256']==sha(gnu/'src/emacs')
    assert {k:v for k,v in before.items() if k!='emacs_binary_sha256'}=={k:v for k,v in proposed.items() if k!='emacs_binary_sha256'}
    assert sha(subject/'compat/oracle_tests_all.txt')==original_inventory and unchanged()
    paths=['src/lisp/primitives/coding.rs','src/lisp/primitives/dispatch/search_coding.rs','src/lisp/primitives/tests.rs',
           'tests/fixtures/coding-post-read-character-count.el','tests/fixtures/coding-post-read-character-count.expected',
           'tests/fixtures/coding-post-read-fast-path.el','tests/fixtures/coding-post-read-fast-path.expected']
    if before!=proposed:paths.append('compat/oracle.lock.json')
    assert subprocess.check_output(['git','diff','--cached','--name-only'],cwd=subject,text=True).strip()==''
    run('diff-check',['git','diff','--check'])
    run('stage',['git','add','--',*paths])
    staged=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=subject,text=True).splitlines()
    assert set(staged)==set(paths)
    run('commit',['git','-c','user.name=Ray','-c','user.email=26018378+rayfdj@users.noreply.github.com',
                  'commit','-m','Prepare post-read repair with rebuilt Darwin oracle for validation'])
    commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=subject,text=True).strip()
    assert subprocess.check_output(['git','status','--porcelain'],cwd=subject,text=True).strip()==''
    save('candidate-commit',dict(commit=commit,paths=paths,inputs_verified=476,prior_lock=before,proposed_lock=proposed,
                               frozen_inventory_sha256=original_inventory,qualification='Local isolated candidate only; frozen validation has not run yet.'))
    state['candidate_commit']=commit
    target=subject/'target/compat-subject'
    assert not target.exists()
    run('completed-cache-copy',['cp','-cR',subject/'target/oracle-validation',target])
    status=run('comparison',[harness,'frozen'],timeout=21600,check=False)
    state.update(status='frozen process finished; raw evidence requires audit',exit_code=status,
                 frozen_inventory_unchanged=sha(subject/'compat/oracle_tests_all.txt')==original_inventory)
except Exception as error:
    state.update(status='failed',error=repr(error))
finally:
    final_status=state.copy()
    if captured:
        try:
            run('verify-gnu-inputs',[sys.executable,'-B',root/'tools/retain_oracle_artifacts.py','verify','--output',capture])
            final_status['gnu_inputs_unchanged']=True
        except Exception as error:
            final_status.update(gnu_inputs_unchanged=False,verification_error=repr(error))
    state=final_status
    state.update(commands=commands,source_unchanged=subject.is_dir() and unchanged())
    save_state()
    save('result',state)
print(json.dumps({k:state[k] for k in ['status','error','exit_code','candidate_commit','source_unchanged','gnu_inputs_unchanged'] if k in state}),flush=True)
raise SystemExit(0 if state.get('exit_code')==0 and state.get('gnu_inputs_unchanged') and state['source_unchanged'] else 1)
