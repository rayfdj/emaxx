from pathlib import Path
import difflib, hashlib, json, os, subprocess, sys, time

p = Path(__file__).parent.resolve()
root = p.parents[2]
gnu = p.parent / 'rebuilt-2026-10-01/emacs'
old = p.parent / 'recovered-2026-09-30/emacs'
out = gnu.parent / 'verification'
out.mkdir()
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
env = {**os.environ, 'LANG':'C', 'LC_ALL':'C'}
results = []
record = dict(status='running', goal_complete=False, pin_changed=False)
def run(name, command, timeout=600):
    command = list(map(str, command))
    with (out / (name+'-command.json')).open('x') as f:
        json.dump(dict(command=command, working_directory=str(root), environment_override={'LANG':'C','LC_ALL':'C'}, timeout_seconds=timeout),f,indent=2)
    start=time.monotonic()
    result=subprocess.run(command,cwd=root,env=env,stdin=subprocess.DEVNULL,capture_output=True,timeout=timeout)
    for suffix,data in [('stdout',result.stdout),('stderr',result.stderr)]:
        with (out/(name+'.'+suffix)).open('xb') as f:f.write(data)
    row=dict(name=name,exit_code=result.returncode,elapsed_seconds=time.monotonic()-start,
             stdout_sha256=hashlib.sha256(result.stdout).hexdigest(),stderr_sha256=hashlib.sha256(result.stderr).hexdigest())
    results.append(row)
    with (out/(name+'-result.json')).open('x') as f:json.dump(row,f,indent=2)
    assert result.returncode==0, (name,result.returncode,result.stderr.decode(errors='replace')[-2000:])
    return result.stdout
def equal_files(fresh, committed):
    same=fresh.read_bytes()==committed.read_bytes()
    if not same:
        (out/(fresh.name+'.diff')).write_text(''.join(difflib.unified_diff(
            committed.read_text().splitlines(True),fresh.read_text().splitlines(True),
            fromfile=str(committed),tofile=str(fresh))))
    return dict(fresh=str(fresh),committed=str(committed),fresh_sha256=sha(fresh),committed_sha256=sha(committed),byte_identical=same)

inputs=[Path(__file__).resolve(),root/'tools/generate_native_subrs.rs',
        root/'compat/generate_gnu_c_primitive_manifest.el',root/'compat/generate_gnu_c_defsym_manifest.el',
        root/'src/lisp/native_comp/generated_native_subrs_aarch64_apple_darwin.rs',
        root/'src/lisp/primitives/generated_gnu_c_primitives.rs',root/'src/lisp/primitives/generated_gnu_c_defsyms.rs',
        root/'compat/oracle.lock.json',root/'compat/oracle_tests_all.txt']
before={str(f):sha(f) for f in inputs}
try:
    run('rust-toolchain',['rustc','--version','--verbose'])
    run('generator-build',['rustc','--edition','2024','-O','-D','warnings',root/'tools/generate_native_subrs.rs','-o',out/'generate-native-subrs'])
    deadline=time.monotonic()+10800
    receipt=p/'gnu-macos-rebuild-20261001-result.json'
    while not receipt.exists():
        assert time.monotonic()<deadline, 'build result did not arrive'
        time.sleep(5)
    build=json.loads(receipt.read_text())
    assert build['exit_code']==0 and build['input_files_unchanged'] and build['source_clean']
    artifacts=build['output_files']
    assert all(sha(Path(n))==info['sha256'] for n,info in artifacts.items())
    record['build_receipt']=str(receipt)
    record['binary_sha256']=sha(gnu/'src/emacs')
    record['historical_pinned_binary_sha256']=json.loads((root/'compat/oracle.lock.json').read_text())['emacs_binary_sha256']
    probe="""(progn (require 'json)
      (princ (json-encode
       `((version . ,emacs-version) (revision . ,emacs-repository-version)
         (configuration . ,system-configuration) (options . ,system-configuration-options)
         (features . ,system-configuration-features)
         (native . ,(if (native-comp-available-p) t :false))
         (gnutls . ,(if (and (fboundp 'gnutls-available-p) (gnutls-available-p)) t :false))
         (libxml . ,(if (and (fboundp 'libxml-available-p) (libxml-available-p)) t :false))
         (sqlite . ,(if (and (fboundp 'sqlite-available-p) (sqlite-available-p)) t :false))
         (sqlite_extension . ,(if (fboundp 'sqlite-load-extension) t :false))
         (modules . ,(if (fboundp 'module-load) t :false))
         (treesit . ,(if (and (fboundp 'treesit-available-p) (treesit-available-p)) t :false))
         (lcms_feature . ,(if (featurep 'lcms2) t :false))
         (lcms . ,(if (and (fboundp 'lcms2-available-p) (lcms2-available-p)) t :false))))))"""
    actual=json.loads(run('rebuilt-capabilities',[gnu/'src/emacs','-Q','--batch','--eval',probe],120))
    previous=json.loads(run('retained-capabilities',[old/'src/emacs','-Q','--batch','--eval',probe],120))
    record['capabilities']=actual
    record['same_capabilities_as_retained_source_abi_matched_build']=actual==previous
    assert actual==previous
    assert actual['version']=='30.2' and actual['revision']=='636f166cfc86aa90d63f592fd99f3fdd9ef95ebd'
    assert all(actual[n] is True for n in ['native','gnutls','libxml','sqlite','sqlite_extension','modules','treesit','lcms_feature','lcms'])
    expected='ACL GLIB GNUTLS LCMS2 LIBXML2 MODULES NATIVE_COMP NOTIFY KQUEUE NS PDUMPER PNG RSVG SQLITE3 THREADS TOOLKIT_SCROLL_BARS TREE_SITTER WEBP XIM ZLIB'
    assert actual['features']==expected
    dependencies=run('dependencies',['otool','-L',gnu/'src/emacs']).decode()
    assert '/usr/lib/libxml2.2.dylib' in dependencies
    run('native-abi',[out/'generate-native-subrs',gnu/'src',gnu/'src/emacs',out/'native-subrs.rs'])
    run('native-abi-format',['rustfmt','--edition','2024',out/'native-subrs.rs'])
    manifests=[equal_files(out/'native-subrs.rs',root/'src/lisp/native_comp/generated_native_subrs_aarch64_apple_darwin.rs')]
    for label,helper,function,filename,formatting in [
        ('primitives','generate_gnu_c_primitive_manifest.el','emaxx-generate-gnu-c-primitive-manifest','generated_gnu_c_primitives.rs',True),
        ('defsyms','generate_gnu_c_defsym_manifest.el','emaxx-generate-gnu-c-defsym-manifest','generated_gnu_c_defsyms.rs',False)]:
        fresh=out/filename
        expression='('+function+' '+json.dumps(str(gnu/'src'))+' '+json.dumps(str(fresh))+')'
        run(label,[gnu/'src/emacs','-Q','--batch','-l',root/'compat'/helper,'--eval',expression])
        if formatting: run(label+'-format',['rustfmt','--edition','2024',fresh])
        manifests.append(equal_files(fresh,root/'src/lisp/primitives'/filename))
    record['manifests']=manifests
    assert all(row['byte_identical'] for row in manifests)
    assert run('gnu-source-clean',['git','-C',gnu,'status','--porcelain'])==b''
    record['artifacts_unchanged']=all(sha(Path(n))==info['sha256'] for n,info in artifacts.items())
    assert record['artifacts_unchanged']
    record['status']='passed build configuration, capabilities and generated ABI/primitive checks'
except Exception as error:
    record.update(status='failed',error=repr(error))
finally:
    record.update(commands=results,input_files=before,inputs_unchanged=all(sha(Path(n))==h for n,h in before.items()))
    with (p/'gnu-macos-rebuild-20261001-verification.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps({k:record[k] for k in ['status','error','binary_sha256','inputs_unchanged'] if k in record}),flush=True)
raise SystemExit(0 if record['status'].startswith('passed') and record['inputs_unchanged'] else 1)
