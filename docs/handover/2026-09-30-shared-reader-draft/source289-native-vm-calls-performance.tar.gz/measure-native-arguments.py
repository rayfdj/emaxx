from pathlib import Path
import hashlib, json, os, subprocess, sys, time

p = Path(__file__).parent.resolve()
g = p.parent / 'rebuilt-2026-10-01/emacs'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
variants = {
    'source286': p.parent / 'recovered-2026-10-03/vm-opcode-dispatch/emaxx',
    'source288': p.parent / 'recovered-2026-10-05/native-argument-words/emaxx',
}
inputs = {}
measurement = read('source284-performance-result.json')['measurement_inputs']
for tag, checkout in variants.items():
    assert read(tag + '-selected-audit.json')['status'] == 'passed'
    manifest = read(tag + '-manifest.json')
    assert all(sha(checkout / name) == digest for name, digest in manifest.items())
    for path, row in read(tag + '-ordinary-artifacts.json').items():
        assert sha(Path(path)) == sha(Path(row['immutable_copy'])) == row['sha256']
    for name in ('tools/core_runtime_perf.py', 'compat/core_runtime_perf.json', 'compat/core_runtime_perf.el'):
        assert sha(checkout / name) == measurement[str(p.parents[2] / name)]
    inputs[tag] = dict(root=checkout, binary=checkout / 'target/vm-dispatch-validation/release/emaxx',
                       native=p / (tag + '-core-native'), manifest=manifest)
state = dict(status='starting native preparation', rounds=4,
             schedule=[['source286', 'source288'], ['source288', 'source286'],
                       ['source286', 'source288'], ['source288', 'source286']],
             qualification='Four alternated repetitions of the unchanged full16 diagnostic pilot: 256 ordinary editor processes, actual GNU answers required. No builds, tests or profiling during timing. This cannot establish the unchanged calibrated nine-round acceptance contract. All timings, including regressions, retained.',
             results=[], goal_complete=False)

def save():
    (p / 'native-arguments-performance-state.json').write_text(json.dumps(state, indent=2) + '\n')

def run(stage, tag, args):
    item = inputs[tag]
    command = [sys.executable, '-B', 'tools/core_runtime_perf.py', *args, '--source', str(g),
               '--oracle', str(g / 'src/emacs'), '--emaxx', str(item['binary']), '--diagnostic']
    with (p / ('native-arguments-performance-' + stage + '-command.json')).open('x') as stream:
        json.dump(dict(command=command, working_directory=str(item['root']), source_manifest=tag + '-manifest.json',
                       environment_overrides=dict(LANG='C', LC_ALL='C')), stream, indent=2)
    state['status'] = 'running ' + stage
    save()
    start = time.monotonic()
    with (p / ('native-arguments-performance-' + stage + '.log')).open('xb') as log:
        result = subprocess.run(command, cwd=item['root'], env=dict(os.environ, LANG='C', LC_ALL='C'),
                                stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
    record = dict(stage=stage, source=tag, exit_code=result.returncode, elapsed_seconds=time.monotonic() - start,
                  source_unchanged=all(sha(item['root'] / name) == digest for name, digest in item['manifest'].items()))
    with (p / ('native-arguments-performance-' + stage + '-result.json')).open('x') as stream:
        json.dump(record, stream, indent=2)
    state['results'].append(record)
    save()
    print(json.dumps(record), flush=True)
    assert record['exit_code'] == 0 and record['source_unchanged']

try:
    run('source288-prepare', 'source288', ['prepare', '--output', str(inputs['source288']['native'])])
    for item in inputs.values():
        for editor in ('oracle', 'emaxx'):
            artifact = json.loads((item['native'] / editor / 'artifact.json').read_text())
            assert artifact['completed'] and sha(item['native'] / editor / 'comp-test-funcs.eln') == artifact['sha256']
    state['status'] = 'waiting for full source286 macOS validation to exit before timing'
    save()
    while not (p / 'source286-full-queue-result.json').exists():
        print(state['status'], flush=True)
        time.sleep(30)
    full_result = read('source286-full-queue-result.json')
    assert full_result['status'] == 'complete macOS processes finished; raw evidence requires audit'
    assert full_result['results'][-1]['stage'] == 'oracle-verify' and full_result['results'][-1]['exit_code'] == 0
    for attempt in range(30):
        process = subprocess.run(['/bin/ps', '-p', '10785', '-o', 'command='], capture_output=True, text=True)
        if 'queue-source286-full-macos.py' not in process.stdout:
            break
        time.sleep(1)
    assert 'queue-source286-full-macos.py' not in process.stdout
    process_list = subprocess.check_output(['/bin/ps', '-axo', 'pid,ppid,command'], text=True)
    with (p / 'native-arguments-performance-processes-before.txt').open('x') as stream:
        stream.write(process_list)
    competing = [line for line in process_list.splitlines()
                 if any(token in line for token in ('cargo build ', 'cargo test ', '/rustc ', 'tools/ttydiff.py',
                                                    'tools/serial_grouped_gate.py', '/usr/bin/sample '))]
    assert not competing, competing
    for repeat, order in enumerate(state['schedule']):
        for tag in order:
            output = p / (tag + '-native-arguments-pilot-' + str(repeat))
            run(tag + '-pilot-' + str(repeat), tag,
                ['pilot', '--pilot-runner', 'both', '--native-dir', str(inputs[tag]['native']), '--output', str(output)])
    state['status'] = 'all diagnostic comparisons finished; raw audit required'
except Exception as error:
    state.update(status='diagnostic comparison stopped', error=repr(error))
finally:
    save()
    with (p / 'native-arguments-performance-result.json').open('x') as stream:
        json.dump(state, stream, indent=2)
sys.exit(0 if state['status'].startswith('all diagnostic') else 1)
