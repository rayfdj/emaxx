from pathlib import Path
import ast, hashlib, json, re, sys

p = Path(__file__).parent.resolve()
repository = p.parents[2]
root = p / 'linux-source204-rust-artifacts/ordinary-linux-d186d40bf014ca53d0a2652b4e2f2d921c5cb009/rust'
sys.path.insert(0, str(repository / 'tools'))
import grouped_gate
from diagnose_exact_census import read_retained, TESTS

tree = ast.parse((p / 'audit-shared-reader196-fresh-selected.py').read_text())
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'audit_log')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<raw-auditor>', 'exec'))
s, inventory, binary, image = read_retained(root)
groups, _ = grouped_gate.classify_inventory(inventory, 'full')
assert s['cargo_stages'] == [] and s['runs'] == []
executed = []
for group in ['eval_01', 'eval_02', 'eval_03', 'eval_04', 'eval_05', 'primitives']:
    failed = 2 if group == 'primitives' else 0
    passed = len(groups[group]) - failed
    log = (root / ('repeat-01-' + group + '.log')).read_text()
    result = json.loads((root / ('repeat-01-' + group + '.json')).read_text())
    assert result['exit_code'] == (101 if failed else 0) and not result['timed_out']
    failures = audit_log(groups[group], log, passed, failed)
    assert failures == (TESTS if failed else [])
    executed.append(dict(group=group, passed=passed, failed=failed, failures=failures))
missing = ['compat_runtime', 'tty', 'batch', 'lightweight']
assert all(not (root / ('repeat-01-' + group + '.log')).exists() for group in missing)
raw = (root / 'repeat-01-primitives.log').read_text()
contracts = ['threads_retain_lexical_caller_roots_across_separate_callee_environments',
             'suspended_bytecode_retains_operand_and_unwind_roots']
assert all('test lisp::primitives::tests::' + name + ' ... ok' in raw for name in contracts)
assert sum(item['passed'] for item in executed) == 2232
result = dict(status='verified failed gate', source_commit=s['git']['head'],
              total_inventory=len(inventory), groups=executed, raw_passed=2232, raw_failed=2,
              original_reclamation_assertions_passed=contracts,
              unexecuted={group: len(groups[group]) for group in missing},
              cargo_stages_unexecuted=['bins', 'integration'], retained_binary=binary,
              retained_image=image, summary_sha256=hashlib.sha256((root / 'summary.json').read_bytes()).hexdigest(),
              qualification='Both first deltas are 47 vector slots below expected. Later deltas match. No cause or repair established; no new cons lightweight controls ran in this failed gate.')
with (p / 'source204-linux-rust-failure-audit.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(result, indent=2))
