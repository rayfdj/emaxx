from pathlib import Path
import ast
import gzip
import hashlib
import io
import json
import tarfile

p=Path(__file__).parent.resolve();root=p.parents[2]
out=p/'source282-publication-stage';out.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda n:json.loads((p/n).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
frozen,terminal=read('source279-macos-frozen-audit.json'),read('source279-macos-terminal-audit.json')
assert frozen['verified_files']==519 and frozen['matching_outcomes']==7915 and frozen['mismatching_outcomes']==6 and frozen['successful_processes']==1038
assert terminal['status']=='failed' and terminal['fully_matching_scenarios']==164 and terminal['matching_comparisons']==318 and terminal['unexecuted_comparisons']==368
retry=read('source279-revert-bounded-result.json')
assert retry['exit_code']==0 and not retry['timed_out'] and retry['inputs_unchanged']
command=read('source279-revert-bounded-command.json')
for name,h in command['inputs'].items():assert sha(Path(name).read_bytes())==h
retry_raw=(p/'source279-revert-bounded.log').read_text()
assert [line for line in retry_raw.splitlines() if line.startswith('MATCH ')] == ['MATCH [revert-buffer-decline::1:insert-change]: text area identical (22 rows)', 'MATCH [revert-buffer-decline::2:request-revert-buffer]: text area identical (21 rows)', 'MATCH [revert-buffer-decline::4:verify-declined-buffer]: text area identical (22 rows)']
assert retry_raw.splitlines()[-1]=='PASS: all scenarios match'
files={};excluded=[];raw=Path(frozen['raw_root'])
allowed={'.json','.log','.txt','.py','.h','.el','.expected','.stdout','.stderr','.patch','.loaded','.apparmor'}
for f in raw.rglob('*'):
    if not f.is_file():continue
    rel=str(f.relative_to(raw));data=f.read_bytes()
    if f.suffix in allowed or data.startswith(b'#!'):
        files['frozen-raw/'+rel]=f
    else:
        excluded.append(dict(path=str(f),relative_path=rel,bytes=len(data),sha256=sha(data),reason='binary tool retained locally; rebuild from recorded inputs'))
for f in p.iterdir():
    if f.is_file() and f.suffix in allowed and f.name.startswith(('source279-full-','source279-macos-frozen-','source279-macos-terminal-','source279-revert-bounded-')):
        files[f.name]=f
for name in ['source279-manifest.json','source279-final-macos-audit-preparation.json',
             'audit-source279-macos-frozen.py','audit-source279-macos-terminal.py',
             'retry-source279-revert-bounded.py','queue-source279-full-macos.py',
             'package-source279-macos-closure.py','source279-macos-package-correction.json',
             'package-source196-failure-and197-results.py',Path(__file__).name]:files[name]=p/name
for name in ['config.h','Makefile','oracle-inputs.json']:
    f=p/'source279-full-retained-gnu'/name
    if f.is_file():files['source279-full-retained-gnu/'+name]=f
scope=dict(status='original macOS frozen and terminal runs failed; separate bounded terminal retry passed',
           frozen=frozen,terminal=terminal,bounded_retry=retry,excluded_binary_inputs=excluded,
           dependencies=['source279-complete-rust-platforms'],
           qualification='Original519-file frozen run has7915 matching and six existing feature-reporting skip-diagnostic differences. Original terminal run completes164 scenarios/318 comparisons before GNU startup times out at120s;368 comparisons remain unexecuted. Separate unchanged revert-buffer-decline scenario uses180s startup/300s overall diagnostic bounds for both editors, finishes in14.224s and matches all three screen checkpoints. This retry does not complete the original226-scenario inventory or erase the timeout. No fabricated answer, matching timeout, performance claim or goal completion.',goal_complete=False)
package('source279-macos-frozen-terminal-and-retry',files,scope)
print(json.dumps(dict(files=len(files),excluded_binaries=len(excluded),archive='source279-macos-frozen-terminal-and-retry.tar.gz')))
