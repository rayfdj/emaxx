from pathlib import Path
import hashlib,json,os,subprocess,sys,time
p=Path(__file__).parent.resolve()
original=json.loads((p/'source279-full-tty-command.json').read_text())
root=Path(original['working_directory'])
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
assert all(sha(Path(f))==h for f,h in original['inputs'].items())
script='''import importlib.util,sys
from pathlib import Path
path=Path("tools/ttydiff.py").resolve()
spec=importlib.util.spec_from_file_location("bounded_ttydiff",path)
module=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=module
spec.loader.exec_module(module)
assert module.STARTUP_WAIT_SECONDS==120.0
module.STARTUP_WAIT_SECONDS=180.0
sys.argv=[str(path),*sys.argv[1:],"revert-buffer-decline"]
module.main()
'''
wrapper=p/'source279-revert-bounded-wrapper.py'
with wrapper.open('x') as f:f.write(script)
command=[sys.executable,str(wrapper),*original['command'][4:]]
inputs={**original['inputs'],str(wrapper):sha(wrapper),str(Path(__file__)):sha(Path(__file__))}
record=dict(command=command,working_directory=str(root),environment_override=original['environment_override'],inputs=inputs,timeout_seconds=300,startup_seconds=180,original_startup_seconds=120,qualification='Separate bounded same-scenario diagnostic after GNU startup timeout in full run. Original fixture,actions,comparison strictness and failures retained; both editors receive the same longer startup bound. Does not replace the incomplete full terminal result.')
with (p/'source279-revert-bounded-command.json').open('x') as f:json.dump(record,f,indent=2)
started=time.monotonic()
with (p/'source279-revert-bounded.log').open('xb') as f:
    try:
        run=subprocess.run(command,cwd=root,env=dict(os.environ,**original['environment_override']),stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,timeout=300)
        code,timed_out=run.returncode,False
    except subprocess.TimeoutExpired:code,timed_out=None,True
result=dict(exit_code=code,timed_out=timed_out,elapsed_seconds=time.monotonic()-started,inputs_unchanged=all(sha(Path(f))==h for f,h in inputs.items()))
with (p/'source279-revert-bounded-result.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps(result))
sys.exit(0 if code==0 and not timed_out and result['inputs_unchanged'] else 1)
