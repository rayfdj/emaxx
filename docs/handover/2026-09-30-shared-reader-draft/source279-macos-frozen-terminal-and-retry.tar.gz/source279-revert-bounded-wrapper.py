import importlib.util,sys
from pathlib import Path
path=Path("tools/ttydiff.py").resolve()
spec=importlib.util.spec_from_file_location("bounded_ttydiff",path)
module=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=module
spec.loader.exec_module(module)
assert module.STARTUP_WAIT_SECONDS==120.0
module.STARTUP_WAIT_SECONDS=180.0
sys.argv=[str(path),*sys.argv[1:],"revert-buffer-decline"]
module.main()
