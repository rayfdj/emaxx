from pathlib import Path
import ast

p = Path(__file__).parent.resolve()
pending = {}

def save(name, source):
    ast.parse(source)
    assert not (p / name).exists()
    pending[name] = source

for name in ['setup-source302-full-macos.py', 'queue-source302-full-macos.py', 'audit-source302-selected-for-full.py']:
    source = (p / name).read_text().replace('source302', 'source304')
    source = source.replace('native-arithmetic-full/emaxx', 'native-audit-full/emaxx')
    source = source.replace('native-binary-arithmetic/emaxx', 'native-arithmetic-audit/emaxx')
    source = source.replace('native-arithmetic-performance', 'native-audit-performance')
    source = source.replace("ordinary_comparisons'] == 48", "ordinary_comparisons'] == 49")
    source = source.replace("ordinary_comparisons']==48", "ordinary_comparisons']==49")
    source = source.replace('ordinary_comparisons=48', 'ordinary_comparisons=49')
    source = source.replace("['passed'] == 328", "['passed'] == 506").replace("['passed']==328", "['passed']==506")
    if name.startswith('queue-'):
        old = 'finally:\n    save_state()\n'
        new = '''finally:
    # Retain post-run GNU verification even if an earlier stage stopped before TTY.
    if (p / 'source304-full-retained-gnu/manifest.json').exists() and not (p / 'source304-full-retained-gnu/verification.json').exists():
        try:
            run('oracle-verify-after-early-failure', [sys.executable, 'tools/retain_oracle_artifacts.py', 'verify', '--output', str(p / 'source304-full-retained-gnu')])
        except Exception as verify_error:
            state['oracle_verification_error'] = repr(verify_error)
    save_state()
'''
        assert source.count(old) == 1
        source = source.replace(old, new)
    save(name.replace('source302', 'source304'), source)

source = (p / 'apply-native-arithmetic302.py').read_text().replace('source302', 'source304').replace('source297', 'source302')
source = source.replace('native-binary-arithmetic/emaxx', 'native-arithmetic-audit/emaxx').replace('native-arithmetic-performance', 'native-audit-performance')
source = source.replace("read('source301-closed-publication.json')['commit']", "read('source302-applied-commit.json')['commit']")
source = source.replace("ordinary_comparisons'] == 48", "ordinary_comparisons'] == 49").replace("['passed'] == 328", "['passed'] == 506")
source = source.replace("assert selected['retained_broad_probe_failure']['exact_match'] is False", "assert selected['closed_broad_probe_failure']['different_rows'] == 0 and selected['closed_broad_probe_failure']['rows'] == 338")
save('apply-native-audit304.py', source)
for name, source in pending.items():
    with (p / name).open('x') as f:
        f.write(source)
print('Prepared304 application and exact-source full macOS validation helpers')
