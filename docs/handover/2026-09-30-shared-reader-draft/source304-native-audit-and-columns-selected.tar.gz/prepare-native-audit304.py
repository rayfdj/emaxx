from pathlib import Path
import ast, hashlib, json, subprocess

p = Path(__file__).parent.resolve()
root = p.parents[2]
c = p.parent / 'recovered-2026-10-05/native-arithmetic-audit/emaxx'
prior = p.parent / 'recovered-2026-10-05/buffer-display-columns/emaxx'
g = p.parent / 'rebuilt-2026-10-01/emacs'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p / n).read_text())
base = read('source302-applied-commit.json')['commit']
manifest = read('source303-manifest.json')
assert all(sha(prior / n) == h for n,h in manifest.items())
assert all(sha(root / n) == h for n,h in read('source302-manifest.json').items())
assert all(r['passed'] == 482 and r['failed'] == r['ignored'] == 0
           for r in read('source303-validation-state.json')['profiles'].values())
assert len(read('source303-validation-state.json')['profiles']) == 2
assert not c.exists()
c.parent.mkdir()
(c.parent / 'emacs').symlink_to(g, target_is_directory=True)
for command in [
    ['git', 'clone', '--shared', '--quiet', '--no-checkout', str(root), str(c)],
    ['git', '-C', str(c), 'sparse-checkout', 'init', '--no-cone'],
    ['git', '-C', str(c), 'sparse-checkout', 'set', '--no-cone', *sorted({'/' + n for n in manifest} | {'/tools/', '/compat/'})],
    ['git', '-C', str(c), 'checkout', '--detach', base],
]:
    subprocess.run(command, check=True)
for name in ['src/lisp/primitives/buffers.rs', 'src/lisp/primitives/tests.rs']:
    (c / name).write_bytes((prior / name).read_bytes())
assert all(sha(c / n) == h for n,h in manifest.items())

path = c / 'src/lisp/native_comp/runtime.rs'
before = path.read_text()
test = '''    #[test]
    fn native_arithmetic_follows_data_c_fixnum_and_fallback_paths() {
        // data.c:Fplus/Fminus/arith_driver: all arities, immediate results,
        // promotion, existing bignums and floats use the installed MANY ABI.
        // The separate native-binary-arithmetic GNU fixture checks 108 actual
        // native results and condition values, plus marker coercion and GC.
        let cases = [
            ("+", vec![], Value::Integer(0)),
            ("-", vec![], Value::Integer(0)),
            ("+", vec![Value::Integer(17)], Value::Integer(17)),
            ("-", vec![Value::Integer(17)], Value::Integer(-17)),
            (
                "+",
                vec![Value::Integer(MOST_NEGATIVE_FIXNUM), Value::Integer(MOST_POSITIVE_FIXNUM)],
                Value::Integer(-1),
            ),
            (
                "+",
                vec![Value::Integer(MOST_POSITIVE_FIXNUM), Value::Integer(1)],
                Value::Integer(2_305_843_009_213_693_952),
            ),
            (
                "-",
                vec![Value::Integer(MOST_NEGATIVE_FIXNUM), Value::Integer(1)],
                Value::Integer(-2_305_843_009_213_693_953),
            ),
            (
                "+",
                vec![Value::Integer(2_305_843_009_213_693_952), Value::Integer(MOST_NEGATIVE_FIXNUM)],
                Value::Integer(0),
            ),
            (
                "+",
                vec![Value::Integer(31), Value::Integer(-7), Value::Integer(13)],
                Value::Integer(37),
            ),
            (
                "-",
                vec![Value::Integer(31), Value::Integer(-7), Value::Integer(13)],
                Value::Integer(25),
            ),
            ("+", vec![Value::float(1.25), Value::Integer(2)], Value::float(3.25)),
            ("-", vec![Value::float(3.5), Value::float(1.25)], Value::float(2.25)),
        ];
        let mut roots = crate::lisp::alloc::RootedVec::new();
        for (_, arguments, expected) in &cases {
            for argument in arguments {
                roots.push(*argument);
            }
            roots.push(*expected);
        }
        let mut interpreter = Interpreter::new();
        let mut environment = Env::new();
        let mut runtime = NativeRuntime::default();
        for (name, arguments, expected) in cases {
            let index = super::super::abi::native_subrs()
                .iter()
                .position(|subroutine| subroutine.name == name)
                .expect("arithmetic belongs to the native ABI");
            let actual = runtime
                .invoke(
                    &mut interpreter,
                    &mut environment,
                    native_subr_address(index).cast_const(),
                    NativeCallingConvention::Many,
                    &arguments,
                )
                .expect("native arithmetic result");
            assert_eq!(actual, expected, "{name} {arguments:?}");
            assert_eq!(actual.word() & 3 == TAG_FIXNUM_LOW, expected.word() & 3 == TAG_FIXNUM_LOW);
            assert_eq!(interpreter.backtrace_frames_len(), 0);
            assert_eq!(interpreter.lisp_eval_depth, 0);
            assert!(runtime.calls.is_empty());
        }
        let invalid = Value::symbol("native-arithmetic-error");
        for name in ["+", "-"] {
            let index = super::super::abi::native_subrs()
                .iter()
                .position(|subroutine| subroutine.name == name)
                .expect("arithmetic belongs to the native ABI");
            for arguments in [[invalid, Value::Integer(1)], [Value::Integer(1), invalid]] {
                let error = runtime
                    .invoke(
                        &mut interpreter,
                        &mut environment,
                        native_subr_address(index).cast_const(),
                        NativeCallingConvention::Many,
                        &arguments,
                    )
                    .expect_err("invalid operands retain the general signaling path");
                assert_eq!(
                    crate::lisp::eval::error_condition_value(&error),
                    Value::list([
                        Value::symbol("wrong-type-argument"),
                        Value::symbol("number-or-marker-p"),
                        invalid,
                    ]),
                );
                assert_eq!(interpreter.backtrace_frames_len(), 0);
                assert_eq!(interpreter.lisp_eval_depth, 0);
                assert!(runtime.calls.is_empty());
            }
        }
    }

'''
anchor = '    #[test]\n    fn native_numeric_comparisons_follow_data_c_fixnum_path()'
assert before.count(anchor) == 1
path.write_text(before.replace(anchor, test + anchor))
audit_path = c / 'src/anti_cheat.rs'
old_audit = audit_path.read_text()
anchor = 'const EXACT_NATIVE_C_FAST_PATHS: &[NativeCFastPathContract] = &[\n'
entries = '''    NativeCFastPathContract {
        primitive: "+",
        owner: "data.c:Fplus",
        contract_test: "native_arithmetic_follows_data_c_fixnum_and_fallback_paths",
    },
    NativeCFastPathContract {
        primitive: "-",
        owner: "data.c:Fminus",
        contract_test: "native_arithmetic_follows_data_c_fixnum_and_fallback_paths",
    },
'''
assert old_audit.count(anchor) == 1
audit_path.write_text(old_audit.replace(anchor, anchor + entries))
subprocess.run(['cargo', 'fmt', '--all'], cwd=c, check=True)
assert path.read_text().split('mod tests {')[0] == before.split('mod tests {')[0]
assert audit_path.read_text() == old_audit.replace(anchor, anchor + entries)
assert 'const APPROVED_NATIVE_C_DEVIATIONS: &[ApprovedNativeCDeviation] = &[];' in audit_path.read_text()
assert [n for n,h in manifest.items() if sha(c / n) != h] == ['src/anti_cheat.rs', 'src/lisp/native_comp/runtime.rs']
with (p / 'source304-static-review.json').open('x') as f:
    json.dump(dict(status='unvalidated exact-contract inventory completion over width303', candidate=str(c), base_commit=base,
        inputs={str(f):sha(f) for f in [path,audit_path,g/'src/data.c',p/'source302-linux-frozen-failed-log.stdout']},
        omission='Source302 Linux frozen37295678456 stopped before any frozen case: detected native +/− had no EXACT_NATIVE_C_FAST_PATHS entries. Source303 inherits that omission; its selected results do not certify the audit gate.',
        repair='Declare the actual GNU owners data.c:Fplus/Fminus and a real native MANY ABI contract test. The test verifies0/1/2/3 arguments, immediate and promoted results, bignum cancellation, float fallback, operand condition data and balanced call state. The existing108-case actual-native GNU fixture remains unchanged.',
        preserved='No production native arithmetic byte changes from302/303. The exact-set assertion, owner existence, primitive availability, contract-test presence checks and all executable negative controls remain byte-identical. APPROVED_NATIVE_C_DEVIATIONS remains empty; no exception, skip or weakened gate. Source303 width repair and every original test/fixture remain.',
        validation='Add all24 anti_cheat tests to the complete existing482-test width/native/VM/allocator selection plus the new ABI contract. Strict,fresh gate/release and ordinary GNU comparisons are required before application. Failed302 run stays failed; the frozen inventory never began.',
        goal_complete=False), f, indent=2)
runner = (p / 'run-source303-validation.py').read_text().replace('source303', 'source304').replace('source302', 'source303')
runner = runner.replace('buffer-display-columns/emaxx', 'native-arithmetic-audit/emaxx').replace('native-binary-arithmetic/emaxx', 'buffer-display-columns/emaxx')
old = "assert changes == ['src/lisp/primitives/buffers.rs', 'src/lisp/primitives/tests.rs']"
assert runner.count(old) == 1
runner = runner.replace(old, "assert changes == ['src/anti_cheat.rs', 'src/lisp/native_comp/runtime.rs']")
runner = runner.replace('buffer_display_columns_match_gnu_original_line_motion_probe', 'native_arithmetic_follows_data_c_fixnum_and_fallback_paths')
runner = runner.replace("new_test = 'lisp::primitives::tests::native_arithmetic_follows_data_c_fixnum_and_fallback_paths'", "new_test = 'lisp::native_comp::runtime::tests::native_arithmetic_follows_data_c_fixnum_and_fallback_paths'")
old = r'|^buffer::|column|indent|line|narrow|invisib|buffer.*(?:edit|multibyte)'
assert runner.count(old) == 1
runner = runner.replace(old, old + r'|^anti_cheat::')
ast.parse(runner)
with (p / 'run-source304-validation.py').open('x') as f:
    f.write(runner)
generated = (p / 'compare-source303-generated-loaded.py').read_text().replace('source303', 'source304').replace('buffer-display-columns/emaxx', 'native-arithmetic-audit/emaxx')
ast.parse(generated)
with (p / 'compare-source304-generated-loaded.py').open('x') as f:
    f.write(generated)
print('Prepared304: exact GNU audit entries and real ABI control; no gate exception or native production change')
