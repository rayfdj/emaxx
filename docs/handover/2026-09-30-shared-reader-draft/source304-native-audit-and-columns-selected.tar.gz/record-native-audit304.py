from pathlib import Path
import hashlib, json, sys

p = Path(__file__).parent.resolve()
root = p.parents[2]
read = lambda name: json.loads((p / name).read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
selected = read('source304-selected-audit.json')
timing = read('native-audit-performance-audit.json')
assert selected['status'] == 'passed' and selected['ordinary_comparisons'] == 49
assert all(r['passed'] == 506 and r['failed'] == r['ignored'] == 0 for r in selected['profiles'].values())
assert timing['status'] == 'all 192 processes and actual results/modes verified' and not timing['short_bodies']
assert read('native-audit-performance-sequence-closed-result.json')['status'] == 'timing audited; source decision pending'

if sys.argv[1] == 'decision':
    for audit in [selected, timing]:
        assert all(sha(Path(n)) == h for n,h in audit['evidence_files'].items())
    decision = dict(status='apply source304 GNU column and exact-contract inventory repairs',
        source_inputs=534, selected_audit_sha256=sha(p/'source304-selected-audit.json'),
        performance_audit_sha256=sha(p/'native-audit-performance-audit.json'),
        reasons=['All338 original probe rows now match actual GNU; the60 original width differences remain in302 evidence.',
                 'Missing native + and - declarations now identify their GNU C owners and a real installed-ABI boundary test. Exact-set equality and approved-deviation policy are unchanged.',
                 '506 selected tests/profile including all24 audit tests,49 ordinary GNU comparisons, fresh builds and warning-free strict checks pass.'],
        timing=dict(raw_geometric_ratio=timing['geometric_mean_optimized_over_baseline'],
                    paired_gnu_geometric_ratios=timing['geometric_mean_gnu_ratios'],
                    cases=[{k:r[k] for k in ['case','optimized_over_baseline','median_gnu_ratios']} for r in timing['cases']]),
        qualification='Mandatory correctness repairs, with original302 and corrected304 timing costs visible. All192 diagnostic process answers/modes verify. Three pilots do not establish statistical significance or final GNU parity.302 full validation failed; no certification transfers from it. Exact304 full platform validation follows. Architecture, real counters, ownership and final calibrated every-case3% criterion remain required.',
        goal_complete=False)
    with (p/'source304-application-decision.json').open('x') as f:
        json.dump(decision,f,indent=2)
    print(json.dumps(dict(status=decision['status'],timing=decision['timing']),indent=2))
elif sys.argv[1] == 'docs':
    assert read('source304-applied-source-verification.json')['status'].startswith('source304 applied;')
    ratio = timing['geometric_mean_optimized_over_baseline']
    gnu = timing['geometric_mean_gnu_ratios']['source304']
    changes = [(r['optimized_over_baseline']-1)*100 for r in timing['cases']]
    text = f'''## Applied column and native-audit repair — 6 October 2026

**Source304 is applied; the full goal is incomplete.** Ordinary buffer columns
now follow GNU `indent.c:scan_for_column` and `buffer.h:CHARACTER_WIDTH`: ASCII
controls honor `ctl-arrow`, unibyte non-ASCII characters occupy four columns,
and multibyte widths come from the live `char-width-table` with GNU sanitization.
All **338 rows of the original probe match actual GNU**, closing its recorded
60 column differences. No original fixture or expected byte changed. This does
not establish complete overlay, display-table or composition semantics.

Source302's full checks found an omission: its native `+`/`-` paths were absent
from the exact-contract inventory.304 adds the GNU owners and a real installed-ABI
boundary test; every audit assertion, negative control and the empty deviation
list remain. Native arithmetic production code is unchanged. The
[failed302 evidence](PREFIXsource302-full-validation-failures-manifest.json)
retains macOS **3,037 passes/one failure/two existing ignores** and Linux
**3,045 passes/one failure/two existing ignores**. All library names ran, but bins
and integration did not. Both frozen attempts stopped before any case; TTY never
started. The sole Rust failure was the inventory omission. Those runs stay failed.

[Source304 selected evidence](PREFIXsource304-native-audit-and-columns-selected-manifest.json)
verifies all **534 inputs and modes**, fresh builds, zero-warning strict checks,
**506 passes per profile**, including all24 audit tests, and **49 ordinary GNU
comparisons**. The prior [303 draft](PREFIXsource303-buffer-columns-selected-manifest.json)
remains unapplied: it passed482 tests/profile but inherited the inventory omission;
its timing queue stopped before measuring anything.

The [302/304 full16 diagnostic](PREFIXsource304-native-audit-and-columns-performance-manifest.json)
verifies all **192 actual process answers and execution modes**. The raw body
geometric ratio is **{ratio:.6f}**; per-case changes range from
**{min(changes):+.3f}% to {max(changes):+.3f}%**.304's paired GNU aggregate is
**{gnu:.6f}×**. Every sample and unfavorable case remains. These three-pilot
results establish neither statistical significance nor GNU parity; real counters,
calibration, nine rounds and every-case upper95% ratio at most1.03 remain required.

All selected/timing coordinators are closed. Exact304 Linux and full macOS checks
are next: inspect `source304-full-validation-launch.json` and
`source304-full-launch.json` under `target/runtime-goal/resume-2026-09-28`, then
their raw audits. Do not restart write-once jobs. Earlier GNU census failures and
source276's Emaxx negative remain unresolved. Main remains `21d20f0e`, PR79 is draft,
and authoritative symbols/native objects, intervals/pure storage, physical
accounting, public ownership, final validation and adversarial audit remain open.
The following sections preserve historical states.

'''
    for name, prefix in [('HANDOVER.md','docs/handover/2026-09-30-shared-reader-draft/'),
                         ('docs/runtime-representation-native-fixed-calls.md','handover/2026-09-30-shared-reader-draft/'),
                         ('docs/runtime-representation-progress.md','handover/2026-09-30-shared-reader-draft/')]:
        path = root/name
        source = path.read_text()
        assert '## Applied column and native-audit repair — 6 October 2026' not in source
        location = source.index('## Applied native arithmetic checkpoint')
        source = source[:location] + text.replace('PREFIX',prefix) + source[location:]
        if name.endswith('progress.md'):
            start = source.index('This map reflects applied source302')
            end = source.index('\n| Full-goal requirement', start)
            source = source[:start] + 'This map reflects applied source304 (534 inputs). Its warning-free selected\nvalidation and paired full16 diagnostic are closed. All338 original column probe\nrows match GNU. Source302 full platform attempts failed the exact-contract audit;\n304 repairs the omission without relaxing that gate. Exact304 Linux and full macOS\nvalidation follow. Earlier failures remain. A checkpoint does not complete the goal.\n' + source[end:]
            source = source.replace('pass selected source302.', 'pass selected source304.')
            lines = source.splitlines()
            for i,line in enumerate(lines):
                if line.startswith('| 7. Equivalent performance |'):
                    lines[i] = f'| 7. Equivalent performance | All16 workloads and the3% ceiling remain locked. The302/304 diagnostic verifies192 actual answers/modes; raw body geometric ratio is{ratio:.6f}, paired GNU aggregate for304 is{gnu:.6f}×. Every original/corrected baseline, unfavorable sample and rejected candidate remains. Real counters, calibration, prescribed repetitions/distributions and every-case acceptance remain open. |'
                elif line.startswith('| 8. Complete validation |'):
                    lines[i] = '| 8. Complete validation | Source304 strict checks are warning-free;506 selected tests/profile and49 actual GNU comparisons pass. All338 original probe rows match.302 full Rust attempts fail only the missing native audit inventory (macOS3037pass/1fail/2ignore; Linux3045pass/1fail/2ignore); bins/integration and all frozen/TTY cases did not run.304 restores that contract inventory; exact-source full Linux/macOS validation follows. Predecessor297 Linux3148passes/2ignores and519frozen files/7928matches do not certify304. Prior census negatives remain unresolved. Final-source platform/release/frozen/terminal validation remains required. |'
                elif line.startswith('| 9. Independently checkable delivery |'):
                    lines[i] = '| 9. Independently checkable delivery | Portable304 patches, raw commands/results and timing samples are retained;302 full failures and303 unapplied draft/stopped timing are separately packaged.304 is applied; exact-source platform validation follows. Main remains21d20f0e and PR79 is draft. Final source/evidence review and every architectural/performance requirement remain outstanding. |'
            source = '\n'.join(lines)+'\n'
        path.write_text(source)
    print('Updated handover, native continuation and current full requirement map')
else:
    raise AssertionError(sys.argv[1])
