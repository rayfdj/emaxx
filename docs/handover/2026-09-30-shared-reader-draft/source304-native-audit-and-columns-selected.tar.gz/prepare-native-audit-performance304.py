from pathlib import Path
import ast

p = Path(__file__).parent.resolve()
pending = {}
for old, new in [('measure-buffer-columns.py', 'measure-native-audit.py'),
                 ('audit-buffer-columns-performance.py', 'audit-native-audit-performance.py')]:
    source = (p / old).read_text().replace('source303', 'source304')
    source = source.replace('buffer-display-columns/emaxx', 'native-arithmetic-audit/emaxx')
    source = source.replace('buffer-columns', 'native-audit')
    source = source.replace('corrected303', 'corrected304').replace('width-corrected303', 'width-corrected304')
    source = source.replace('303 must pass', '304 must pass')
    ast.parse(source)
    assert not (p / new).exists()
    pending[new] = source
source = (p / 'finish-buffer-columns-performance-closed.py').read_text().replace('source303', 'source304').replace('buffer-columns', 'native-audit')
old = "assert platform['status']=='complete macOS processes finished; raw evidence requires audit',platform['status']"
new = """assert platform['status']=='queue or validation setup failed' and platform['error']=='AssertionError()',platform['status']
 assert [(r['stage'],r['exit_code']) for r in platform['results']][-3:]==[('rust-retention',0),('runner-build',0),('frozen',2)]
 launch=json.loads((p/'source302-full-launch.json').read_text())
 import os
 try:
  os.kill(launch['pid'],0)
 except ProcessLookupError:
  pass
 else:
  raise AssertionError('prior302 supervisor PID remains present; inspect before timing')
 stopped=json.loads((p/'buffer-columns-performance-sequence-closed-result.json').read_text())
 assert stopped['status']=='sequence stopped' and not stopped['steps']
 assert not (p/'buffer-columns-performance-result.json').exists()
 state['prior_platform_failure_preserved']=True
 state['prior303_timing_never_started']=True"""
assert source.count(old) == 1
source = source.replace(old, new)
ast.parse(source)
name = 'finish-native-audit-performance-closed.py'
assert not (p / name).exists()
pending[name] = source
for name, source in pending.items():
    with (p / name).open('x') as f:
        f.write(source)
print('Prepared302/304 complete16 timing; original302 failures and stopped303 queue retained')
