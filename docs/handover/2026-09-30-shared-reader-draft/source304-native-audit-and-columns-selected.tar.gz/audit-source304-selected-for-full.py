from pathlib import Path
import hashlib,json
p=Path(__file__).parent.resolve()
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
read=lambda n:json.loads((p/n).read_text())
audit=read('source304-selected-audit.json');m=read('source304-manifest.json')
assert audit['status']=='passed' and audit['ordinary_comparisons']==49
assert all(r['passed']==506 and r['failed']==r['ignored']==0 for r in audit['profiles'].values())
assert len(m)==534
for root in [Path(read('source304-full-checkout.json')['candidate']),p.parent/'recovered-2026-10-05/native-arithmetic-audit/emaxx']:
    assert all(sha(root/n)==h for n,h in m.items())
assert all(sha(Path(n))==h for n,h in audit['evidence_files'].items())
assert all(sha(Path(n))==sha(Path(r['immutable_copy']))==r['sha256'] for n,r in audit['ordinary_artifacts'].items())
for patch in audit['portable_replays']:assert sha(p/patch['patch'])==patch['sha256']
with (p/'source304-full-selected-audit.json').open('x') as f:json.dump(audit,f,indent=2)
print(json.dumps(dict(status='passed',verified_inputs=534,profiles={n:r['passed'] for n,r in audit['profiles'].items()},ordinary_comparisons=49)))
