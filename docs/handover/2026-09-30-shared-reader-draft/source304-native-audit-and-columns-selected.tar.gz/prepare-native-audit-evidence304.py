from pathlib import Path
import ast, re

p = Path(__file__).parent.resolve()
pending = {}

def write(name, source):
    ast.parse(source)
    assert name not in pending and not (p / name).exists()
    pending[name] = source

def replace(source, old, new):
    assert source.count(old) == 1, (old, source.count(old))
    return source.replace(old, new)

def translate(source):
    tags = {'source302': 'source303', 'source303': 'source304'}
    return re.sub(r'source(?:302|303)', lambda m: tags[m[0]], source)

source = (p / 'replay-buffer-columns303.py').read_text()
old = next(n.value for n in ast.walk(ast.parse(source)) if isinstance(n, ast.Constant)
           and isinstance(n.value, str) and n.value.startswith('Source303 repairs'))
source = replace(source, repr(old), repr('Source304 carries the GNU column repair and supplies the missing exact-contract inventory for native addition/subtraction with an installed-ABI boundary test. All534 bytes/modes reconstruct from applied2680b957 and main. Original tests, fixtures, strict exact-set checks and the empty deviation list remain. Source302 failed full validations are retained.'))
write('replay-native-audit304.py', source)

source = translate((p / 'audit-buffer-columns-selected.py').read_text())
source = replace(source, "assert [n for n,h in manifest.items() if prior_manifest.get(n)!=h] == ['src/lisp/primitives/buffers.rs', 'src/lisp/primitives/tests.rs']", "assert [n for n,h in manifest.items() if prior_manifest.get(n)!=h] == ['src/anti_cheat.rs', 'src/lisp/native_comp/runtime.rs']")
start = source.index('prior_tests = ')
end = source.index("state = read(tag + '-validation-result.json')", start)
source = source[:start] + '''prior_source = p.parent / 'recovered-2026-10-05/buffer-display-columns/emaxx'
assert (c / 'src/lisp/primitives/tests.rs').read_bytes() == (prior_source / 'src/lisp/primitives/tests.rs').read_bytes()
before = (prior_source / 'src/lisp/native_comp/runtime.rs').read_text()
after = (c / 'src/lisp/native_comp/runtime.rs').read_text()
start = after.index('    #[test]\\n    fn native_arithmetic_follows_data_c_fixnum_and_fallback_paths()')
end = after.index('    #[test]\\n    fn native_numeric_comparisons_follow_data_c_fixnum_path()', start)
assert after[:start] + after[end:] == before
assert after[start:end].count('#[test]') == 1
audit_before = (prior_source / 'src/anti_cheat.rs').read_text()
audit_after = (c / 'src/anti_cheat.rs').read_text()
anchor = 'const EXACT_NATIVE_C_FAST_PATHS: &[NativeCFastPathContract] = &[\\n'
inserted = ''.join('    NativeCFastPathContract {\\n        primitive: "' + op + '",\\n        owner: "data.c:' + owner + '",\\n        contract_test: "native_arithmetic_follows_data_c_fixnum_and_fallback_paths",\\n    },\\n' for op, owner in [('+', 'Fplus'), ('-', 'Fminus')])
assert audit_after == audit_before.replace(anchor, anchor + inserted)
new_column_test = 'lisp::primitives::tests::buffer_display_columns_match_gnu_original_line_motion_probe'
new_audit_test = 'lisp::native_comp::runtime::tests::native_arithmetic_follows_data_c_fixnum_and_fallback_paths'
''' + source[end:]
source = source.replace('buffer.*(?:edit|multibyte)\'', 'buffer.*(?:edit|multibyte)|^anti_cheat::\'')
source = replace(source, "record['passed'] == 482", "record['passed'] == 506")
source = replace(source, 'set(prior) | {new_column_test}', 'set(prior) | {new_audit_test}')
source = replace(source, "assert names == record['selectors'] and new_column_test in names", "assert names == record['selectors'] and new_column_test in names and new_audit_test in names\n    assert len([n for n in names if n.startswith('anti_cheat::')]) == 24\n    assert set(read('source303-validation-result.json')['profiles'][profile]['selectors']) <= set(names)")
source = replace(source, "names = list(read('source303-selected-audit.json')['ordinary_results']) + ['buffer-lf-line-index']", "names = list(read('source303-selected-audit.json')['ordinary_results'])")
old = next(n.value for n in ast.walk(ast.parse(source)) if isinstance(n, ast.Constant)
           and isinstance(n.value, str) and n.value.startswith('Source303 repairs'))
source = replace(source, repr(old), repr('Source304 carries the GNU column repair and completes the missing native + and - exact-contract inventory. All534 inputs/modes, fresh builds, warning-free strict checks,506 selected passes/profile including all24 anti-cheat tests and49 actual GNU comparisons verify. Original tests/fixtures and every exact-set and negative-control audit assertion are unchanged; no approved deviation is added. The original338 rows match actual GNU, closing60 prior width mismatches. This is selected evidence, not full platform certification or final correctness/performance.'))
# The negative belongs to source302, before either width repair.
source = source.replace('source303-line-broad', 'source302-line-broad')
write('audit-native-audit-selected.py', source)

source = translate((p / 'finish-buffer-columns-selected-closed.py').read_text())
source = source.replace('buffer-columns-selection', 'native-audit-selection').replace('audit-buffer-columns-selected.py', 'audit-native-audit-selected.py').replace('buffer-display-columns', 'native-arithmetic-audit')
source = replace(source, "names=list(read('source303-selected-audit.json')['ordinary_results'])+['buffer-lf-line-index']", "names=list(read('source303-selected-audit.json')['ordinary_results'])")
source = source.replace('buffer-columns selected audit closed', 'native-audit selected audit closed')
write('finish-native-audit-selected-closed.py', source)

for name, source in pending.items():
    with (p / name).open('x') as f:
        f.write(source)
print('Prepared304: unchanged303 test selection plus all audit tests and one installed-ABI test')
