from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
state = read('source249-validation-queue-state.json')
assert state['status'] == 'waiting for source248 full terminal retry to exit'
with (p / 'source249-queued-state-snapshot.json').open('x') as f:
    json.dump(state, f, indent=2)
names = [
    'source249-manifest.json', 'source249-freeze.json',
    'source249-incremental.patch', 'source249-complete.patch',
    'source249-patch-replay-audit.json', 'source249-c-reference-review.json',
    'source249-original-fixtures.json', 'source249-validation-launch.json',
    'source249-queued-state-snapshot.json',
    'freeze-source249.py', 'audit-source249-patches.py', 'audit-source249-c-reference.py',
    'queue-source249-validation.py', 'check-source249.py', 'static-source249.py',
    'build-source249.py', 'test-source249-controls.py', 'test-source249-broad.py',
    'audit-source249-focused.py', 'audit-source249-selected.py',
    'compare-source230-fixtures.py', 'audit-source238-release.py',
    'package-source196-failure-and197-results.py', Path(__file__).name,
    'source174-ordinary-artifacts.json', 'source207-ordinary-artifacts.json',
]
files = {name: p / name for name in names}
for tag in ['count', 'fast']:
    for pattern in ['source248-post-read-' + tag + '-*',
                    'source174-post-read-' + tag + '-original-location*',
                    'source207-post-read-' + tag + '-original-location*']:
        for path in p.glob(pattern):
            assert path.is_file() and path.suffix in {'.json', '.stdout', '.stderr'}
            files[path.name] = path
    for name in ['probe-source248-post-read-' + tag + '.py',
                 'probe-coding-post-read-' + tag + '-history.py',
                 'coding-post-read-' + tag + '-history-original-location-audit.json']:
        files[name] = p / name
for name in ['coding-post-read-character-count.el', 'coding-post-read-fast-path.el']:
    files[name] = p / name
package('source249-post-read-draft', files,
        dict(c_reference=read('source249-c-reference-review.json'),
             frozen=read('source249-freeze.json'), queue_snapshot=state,
             qualification='Unapplied source249 draft with both exact negative fixtures, GNU output bytes, original-location source174/main and source207 reproductions, C mappings and replayable patches. Queue15814 waits for terminal14540 before strict checks, gate/release selected validation and fifteen ordinary comparisons. Mutable/live logs are excluded. Build and runtime validation have not started in this snapshot; prepared auditors are not passing evidence. Root source248 and all prior failures remain unchanged. General translation-table, hook/destination, architecture, ownership, accounting, pinned Darwin and performance requirements remain open.'))
