from pathlib import Path
import ast,hashlib,json,re
p=Path(__file__).parent.resolve()
root=p.parent/'recovered-2026-09-30/bytecode-closure/emaxx'
read=lambda name:json.loads((p/name).read_text())
sha=lambda file:hashlib.sha256(file.read_bytes()).hexdigest()
manifest=read('source214-manifest.json')
assert len(manifest)==418 and all(sha(root/name)==digest for name,digest in manifest.items())
tree=ast.parse((p/'audit-shared-reader196-fresh-selected.py').read_text())
node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='audit_log')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<raw-auditor>','exec'))
command=read('source214-gate-controls-command.json')
result=read('source214-gate-controls-result.json')
assert result['exit_code']==101 and result['source_unchanged']
assert sha(p/'source214-gate-libtest')==command['binary_sha256']
names=command['selected_inventory'];assert len(names)==6
failed=audit_log(names,(p/'source214-gate-controls.log').read_text(),5,1)
assert [name.rsplit('::',1)[1] for name in failed]==['bytecode_code_mutation_during_active_call_matches_gnu']
for label in ['check','fmt','clippy','diff','gate-build']:
    outcome=read('source214-'+label+'-result.json')
    assert outcome['exit_code']==0 and outcome['source_unchanged']
    raw=(p/('source214-'+label+'.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:',raw,re.M)
    for line in raw.splitlines():
        try:item=json.loads(line)
        except json.JSONDecodeError:continue
        assert item.get('message',{}).get('level') not in ['error','warning']
    if label in ['fmt','diff']:assert not raw
assert read('source214-controls-result.json')[-1]['exit_code']==101
record=dict(status='partial bytecode repair; active-call mutation still fails',inputs_verified=418,
    binary_sha256=command['binary_sha256'],strict_checks='passed with zero warnings',passed=5,failed=1,ignored=0,
    passing_names=[name for name in names if name not in failed],failing_names=failed,
    raw_libtest_exit_code=101,supervisor_exit_code=101,
    review_finding='VectorRef::shallow_copy initializes the actual vector but calls census_on_allocate, whose Normal arm is empty. Its missing live-vector increment requires repair and a dedicated clone-census control. The six executed controls do not cover this increment.',
    qualification='Both original layout controls now run through all 4/5/6-slot assertions, native field writes and current-child tracing. Constructor fields, sharing/cloning and code mutation between calls pass. Active-call mutation still returns (41 194), expected (67 194). This is a separate unfinished draft, not full validation or a performance claim.',
    raw_hashes={name:sha(p/name) for name in ['source214-gate-controls.log','source214-gate-controls-command.json','source214-gate-controls-result.json','source214-controls-driver.log']})
with (p/'source214-controls-audit.json').open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps(record,indent=2))
