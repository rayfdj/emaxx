from pathlib import Path
root=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/bytecode-closure/emaxx')
def change(name, old, new, count=1):
    path=root/name
    text=path.read_text()
    assert text.count(old)==count,(name,old[:100],text.count(old),count)
    path.write_text(text.replace(old,new))
def section(name,start,end,replacement):
    path=root/name
    text=path.read_text(); a=text.index(start); b=text.index(end,a)
    path.write_text(text[:a]+replacement+text[b:])

change('src/lisp/primitives/dispatch/predicates.rs',
       'Kind::Record(id) if interp.is_genuine_bytecode_function(id.id)',
       'Kind::Closure(closure) if closure.is_bytecode()')
change('src/lisp/primitives/dispatch/predicates.rs',
       'matches!(args[0].kind(), Kind::Closure(_))\n                        || record_type_name(interp, &args[0]) == Some("byte-code-function")',
       'matches!(args[0].kind(), Kind::Closure(_))')
change('src/lisp/primitives/dispatch/predicates.rs',
       'Ok(if matches!(args[0].kind(), Kind::Closure(_)) {',
       'Ok(if matches!(args[0].kind(), Kind::Closure(closure) if !closure.is_bytecode()) {')
for name in ['src/lisp/primitives/buffers.rs','src/lisp/primitives/dispatch/misc_keymaps.rs']:
    change(name,'Kind::Closure(_) => "interpreted-function",',
           'Kind::Closure(closure) => if closure.is_bytecode() { "byte-code-function" } else { "interpreted-function" },')
change('src/lisp/types.rs','Kind::Closure(_) => "lambda".into(),',
       'Kind::Closure(closure) => if closure.is_bytecode() { "byte-code-function" } else { "lambda" }.into(),')
change('src/lisp/primitives/buffers.rs','                crate::lisp::eval::RecordKind::Closure => "byte-code-function",\n','')
section('src/lisp/primitives/values.rs','''        Kind::Record(id) => {
            let record = interp.find_record(id).ok_or_else(|| {
                LispError::TypeError("record".into(), format!("record<{}>", id.id))
            })?;
            match record.kind {
                // GNU Lisp_Closure slots''','''        _ => Err(LispError::WrongTypeArgument("sequencep".into(), *value)),''','')
# The section end above is the inner wildcard; remove its obsolete closing block.
change('src/lisp/primitives/values.rs','''        _ => Err(LispError::WrongTypeArgument("sequencep".into(), *value)),
            }
        }
        _ => Err(LispError::WrongTypeArgument("sequencep".into(), *value)),''','''        _ => Err(LispError::WrongTypeArgument("sequencep".into(), *value)),''')
change('src/lisp/primitives/values.rs','crate::lisp::eval::RecordKind::Closure\n        | crate::lisp::eval::RecordKind::Font','crate::lisp::eval::RecordKind::Font')
change('src/lisp/primitives/values.rs','crate::lisp::eval::RecordKind::Closure | crate::lisp::eval::RecordKind::Font','crate::lisp::eval::RecordKind::Font')
change('src/lisp/primitives/values.rs','crate::lisp::eval::RecordKind::Closure\n                        | crate::lisp::eval::RecordKind::NativeCompiledFunction','crate::lisp::eval::RecordKind::NativeCompiledFunction')
change('src/lisp/primitives/dispatch/collections.rs','crate::lisp::eval::RecordKind::Closure\n                        | crate::lisp::eval::RecordKind::BoolVector','crate::lisp::eval::RecordKind::BoolVector')
section('src/lisp/primitives/dispatch/collections.rs','''                        if record.kind == crate::lisp::eval::RecordKind::Closure {''','''                        unreachable!("array check admitted only closure and bool-vector adapters")''','')
change('src/lisp/primitives/dispatch/collections.rs','array check admitted only closure and bool-vector adapters','array check admitted only a bool-vector adapter')
section('src/lisp/primitives/dispatch/lists.rs','''                        Kind::Record(id) => {
                            if let Some(record) = interp.find_record(id)
                                && record.kind == crate::lisp::eval::RecordKind::Closure''','''                        _ => {}''','')
change('src/lisp/primitives/dispatch/lists.rs','items.extend(interp.interpreted_closure_slots(&lambda));','items.extend(lambda.slots());')
section('src/lisp/primitives/dispatch/buffer_meta.rs','''                    Kind::Record(id) => interp
                        .find_record(id)
                        .filter(|record| record.kind == crate::lisp::eval::RecordKind::Closure)''','''                    _ => Value::Nil,''','')
section('src/lisp/primitives/dispatch/misc.rs','''                    Kind::Record(record)
                        if record.kind == crate::lisp::eval::RecordKind::Closure =>''','''                    _ =>''','')
section('src/lisp/primitives/interactive.rs','''    if let Kind::Record(id) = value.kind()
        && let Some(record) = interp.find_record(id)
        && record.kind == crate::lisp::eval::RecordKind::Closure''','''    if let Kind::Record(id) = value.kind()
        && let Some(record) = interp.find_record(id)
        && record.kind == crate::lisp::eval::RecordKind::ModuleFunction''','')
section('src/lisp/primitives/numeric_time.rs','''        Kind::Record(id)
            if interp
                .find_record(id)
                .is_some_and(|record| record.kind == crate::lisp::eval::RecordKind::Closure) =>''','''        Kind::Record(id)
            if interp.find_record(id).is_some_and(|record| {''','')
section('src/lisp/primitives/completion.rs','''        if record.kind != crate::lisp::eval::RecordKind::Closure {''','''    // callint.c's cons-lambda branch:''','''    }
''')
section('src/lisp/primitives/print.rs','''                    crate::lisp::eval::RecordKind::Closure => {''','''                    // print.c:1930''','')
change('src/lisp/primitives/print.rs','pending.extend(interp.interpreted_closure_slots(&lambda).into_iter().rev());','pending.extend(lambda.slots().rev());')
change('src/lisp/primitives/print.rs','let slots = interp.interpreted_closure_slots(&lambda_value);','let slots = lambda_value.slots();')
change('src/lisp/primitives/print.rs','for (index, slot) in slots.iter().enumerate() {','for (index, slot) in slots.enumerate() {')
change('src/lisp/primitives/print.rs','''                    slot,
                    env,
                    context,
                    depth + 1,
                )?);
            }
            Ok(format!("#[{}]"''','''                    &slot,
                    env,
                    context,
                    depth + 1,
                )?);
            }
            Ok(format!("#[{}]"''')
section('src/lisp/primitives/purecopy.rs','''    if record.kind != crate::lisp::eval::RecordKind::Closure {''','''fn purecopy_inner(''','''    Err(LispError::Signal(format!(
        "Don't know how to purify: {} ({:?}, {:?})",
        source.type_name(), record.kind, record.type_tag,
    )))
}

''')
section('src/lisp/primitives/purecopy.rs','''        Kind::Closure(lambda) => {''','''        Kind::LispRecord(record) => {''','''        Kind::Closure(closure) => {
            let copy = closure.shallow_copy();
            let copied = Value::Closure(copy);
            interp.with_lisp_stack_roots(&copied, |interp| {
                for (index, field) in copy.slots().enumerate() {
                    copy.initialize_slot(index, purecopy_inner(interp, &field, env)?);
                }
                Ok::<Value, LispError>(copied)
            })?
        }
''')
section('src/lisp/eval/macros.rs','''    /// Store the reader's interpreted-closure slots verbatim.''','''    /// eval.c:Fmake_interpreted_closure:''','')
change('src/lisp/primitives/pdumper/context.rs','        RecordKind::Closure => 3,\n','')
change('src/lisp/primitives/pdumper/context.rs','        3 => RecordKind::Closure,\n','        // Former detached byte-code record code 3 is unsupported.\n')
change('src/lisp/primitives/pdumper/context.rs','RecordKind::Closure | RecordKind::Font','RecordKind::Font')
change('src/lisp/primitives/pdumper/load.rs','if !(3..=6).contains(&size) {','if !(3..=0xfff).contains(&size) {')
change('src/lisp/primitives/pdumper/load.rs','Value::allocated_closure(&[Value::Nil; 6][..size])','Value::Closure(crate::lisp::types::ClosureRef::filled(size, Value::Nil))')
change('src/lisp/primitives/pdumper/load.rs','if !matches!(closure.body().kind(), Kind::Cons(_)) {','if !closure.is_bytecode() && !matches!(closure.body().kind(), Kind::Cons(_)) {')
change('src/lisp/primitives/pdumper/load.rs','invalid interpreted closure body at','invalid closure code at')
print('public closure consumers and portable dumping migrated')
