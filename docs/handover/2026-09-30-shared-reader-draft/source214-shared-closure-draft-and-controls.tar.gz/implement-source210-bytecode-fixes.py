from pathlib import Path
root=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/bytecode-closure/emaxx')
def change(name,old,new,count=1):
    path=root/name; text=path.read_text()
    assert text.count(old)==count,(name,old[:100],text.count(old),count)
    path.write_text(text.replace(old,new))

change('src/lisp/eval/macros.rs','primitives::strings::string_argument_multibyte','primitives::string_argument_multibyte')
change('src/lisp/eval.rs','    ReaderClosureKind, ReaderForm, SymbolName, Value,','    ReaderForm, SymbolName, Value,')
change('src/lisp/eval/core.rs','Kind::Symbol(name) => self.globals.function(&name)?,','Kind::Symbol(name) => *self.globals.function(&name)?,')
change('src/lisp/bytecode.rs','''    #[cfg(test)]
    pub fn from_slots(slots: &[Value])''','''    pub fn from_slots(slots: &[Value])''')
change('src/lisp/bytecode.rs','    pub interactive: Option<Value>,\n','')
change('src/lisp/bytecode.rs','            interactive: field(5),\n','')
change('src/lisp/bytecode/vm.rs','''        Kind::Record(_) => LispError::SignalValue(Value::list([''','''        Kind::Closure(_) => LispError::SignalValue(Value::list([''')
change('src/lisp/bytecode/vm.rs','            Ok(Kind::Record(_))','            Ok(Kind::Closure(_))')
change('src/lisp/bytecode/vm.rs','            Some(Kind::Record(_))','            Some(Kind::Closure(_))')

# Keep one actual function word for every active VM frame. The constants and
# code are reachable through that closure even when Lisp redefines its symbol.
for name in ['src/lisp/eval.rs','src/lisp/bytecode/vm.rs']:
    path=root/name; text=path.read_text()
    assert 'bc_live_programs' in text
    path.write_text(text.replace('bc_live_programs','bc_functions'))
change('src/lisp/eval.rs','pub(crate) bc_functions: Vec<crate::lisp::types::VectorRef>,','pub(crate) bc_functions: Vec<Value>,')
change('src/lisp/eval.rs','''        for constants in &self.bc_functions {
            marked.mark(self, &Value::Vector(*constants));
        }''','''        for function in &self.bc_functions {
            marked.mark(self, function);
        }''')
change('src/lisp/bytecode/vm.rs','''    interp.bc_functions.push(program.constants);
    let result = run_frames(interp, program, function, args, env);
    interp.bc_functions.pop();''','''    let functions_at_entry = interp.bc_functions.len();
    interp.bc_functions.push(if function.is_nil() {
        // The raw byte-code primitive has no closure object.
        Value::Vector(program.constants)
    } else {
        function
    });
    let result = run_frames(interp, program, function, args, env);''')
change('src/lisp/bytecode/vm.rs','''    interp.bc_stack.truncate(base);
    result
}''','''    interp.bc_stack.truncate(base);
    interp.bc_functions.truncate(functions_at_entry);
    result
}''')
change('src/lisp/bytecode/vm.rs','''                        crate::lisp::native_comp::maybe_gc(interp, env);
                        frames.push(BcFrame {''','''                        interp.bc_functions.push(callee_function);
                        crate::lisp::native_comp::maybe_gc(interp, env);
                        frames.push(BcFrame {''')
change('src/lisp/bytecode/vm.rs','''                    program = frame.program;''','''                    interp.bc_functions.pop();
                    program = frame.program;''',3)

change('src/lisp/eval/core.rs','''            // Ffuncall's maybe_gc, after record_in_backtrace.
            crate::lisp::native_comp::maybe_gc(interp, env);
            let result = interp.execute_bytecode_funcall_body(closure, args, env);''','''            // A collecting finalizer can redefine the named function. Keep
            // the resolved closure itself live through that entry boundary.
            let result = interp.with_lisp_stack_roots(&Value::Closure(closure), |interp| {
                crate::lisp::native_comp::maybe_gc(interp, env);
                interp.execute_bytecode_funcall_body(closure, args, env)
            });''')

# Remove stale claims about a per-record program cache and executable facades.
change('src/lisp/bytecode/vm.rs','''/// A byte-code function decoded and validated once:
/// instructions, an O(1) byte-offset -> instruction-index table for
/// jumps, and live constants.  Cached per record so repeated calls skip
/// instruction decoding (GNU decodes inside its dispatch loop). Constants
/// remain the original live vector supplied by the reader or make-byte-code.''','''/// Transitional decoded VM activation, with the original live constants.
/// Closure fields are read afresh at entry and are never cached by identity.
/// Direct dispatch from mutable code bytes must replace decoded instructions
/// before the bytecode architecture or active-call mutation repair is complete.''')
change('src/lisp/bytecode/vm.rs','''                    // The fast path for a lexbound byte-code function whose
                    // program is cached: its frame is laid out above the''','''                    // A packed byte-code function's frame lies above the''')
change('src/lisp/eval/core.rs','''                    // holds a byte-code object already decoded once.''','''                    // holds a byte-code object's authoritative fields.''')
print('compiler integration and active closure roots corrected')
