from pathlib import Path
root=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/bytecode-closure/emaxx')
def change(name, old, new, count=1):
    path=root/name
    text=path.read_text()
    assert text.count(old)==count,(name,old[:100],text.count(old),count)
    path.write_text(text.replace(old,new))
def section(name,start,end,replacement):
    path=root/name
    text=path.read_text(); a=text.index(start); b=text.index(end,a)
    path.write_text(text[:a]+replacement+text[b:])

change('src/lisp/primitives/print.rs','let slots = lambda_value.slots();\n            let mut rendered_slots = Vec::new();\n            for (index, slot) in slots.iter().enumerate() {','let slots = lambda_value.slots();\n            let mut rendered_slots = Vec::new();\n            for (index, slot) in slots.enumerate() {')
change('src/lisp/primitives/print.rs','''                    slot,
                    env,
                    context,
                    depth + 1,
                )?);
            }
            Ok(format!("#[{}]"''','''                    &slot,
                    env,
                    context,
                    depth + 1,
                )?);
            }
            Ok(format!("#[{}]"''')
section('src/lisp/primitives/purecopy.rs','''    if record.kind != crate::lisp::eval::RecordKind::Closure {''','''fn purecopy_inner(''','''    Err(LispError::Signal(format!(
        "Don't know how to purify: {} ({:?}, {:?})",
        source.type_name(), record.kind, record.type_tag,
    )))
}

''')
section('src/lisp/primitives/purecopy.rs','''        Kind::Closure(lambda) => {''','''        Kind::LispRecord(record) => {''','''        Kind::Closure(closure) => {
            let copy = closure.shallow_copy();
            let copied = Value::Closure(copy);
            interp.with_lisp_stack_roots(&copied, |interp| {
                for (index, field) in copy.slots().enumerate() {
                    copy.initialize_slot(index, purecopy_inner(interp, &field, env)?);
                }
                Ok::<Value, LispError>(copied)
            })?
        }
''')
section('src/lisp/eval/macros.rs','''    /// Store the reader's interpreted-closure slots verbatim.''','''    /// eval.c:Fmake_interpreted_closure:''','')
change('src/lisp/primitives/pdumper/context.rs','        RecordKind::Closure => 3,\n','')
change('src/lisp/primitives/pdumper/context.rs','        3 => RecordKind::Closure,\n','        // Former detached byte-code record code 3 is unsupported.\n')
change('src/lisp/primitives/pdumper/context.rs','RecordKind::Closure | RecordKind::Font','RecordKind::Font')
change('src/lisp/primitives/pdumper/load.rs','if !(3..=6).contains(&size) {','if !(3..=0xfff).contains(&size) {')
change('src/lisp/primitives/pdumper/load.rs','Value::allocated_closure(&[Value::Nil; 6][..size])','Value::Closure(crate::lisp::types::ClosureRef::filled(size, Value::Nil))')
change('src/lisp/primitives/pdumper/load.rs','if !matches!(closure.body().kind(), Kind::Cons(_)) {','if !closure.is_bytecode() && !matches!(closure.body().kind(), Kind::Cons(_)) {')
change('src/lisp/primitives/pdumper/load.rs','invalid interpreted closure body at','invalid closure code at')
print('public closure consumers and portable dumping migrated')
