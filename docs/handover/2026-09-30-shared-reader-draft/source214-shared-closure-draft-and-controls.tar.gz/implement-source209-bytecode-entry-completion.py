from pathlib import Path
root = Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/bytecode-closure/emaxx')
def change(name, old, new, count=1):
    path = root / name
    text = path.read_text()
    assert text.count(old) == count, (name, old[:100], text.count(old), count)
    path.write_text(text.replace(old, new))
def section(name, start, end, replacement):
    path = root / name
    text = path.read_text()
    a = text.index(start)
    b = text.index(end, a)
    path.write_text(text[:a] + replacement + text[b:])

change('src/lisp/eval/core.rs', 'RecordKind::Closure\n                                | RecordKind::NativeCompiledFunction', 'RecordKind::NativeCompiledFunction')

change('src/lisp/eval.rs', '''            if let Some(slot) = self.bytecode_program_cache.get_mut(index) {
                *slot = None;
            }
''', '')
change('src/lisp/eval.rs', '        clone.bytecode_program_cache.clear();\n', '')
section('src/lisp/eval.rs', '    /// Decoded byte-code programs indexed by record ID minus one', '    /// Recycled operand stacks', '')
change('src/lisp/eval.rs', '            bytecode_program_cache: Vec::new(),\n', '')
section('src/lisp/eval/runtime.rs', '        let id = record.id;\n        // The caller may rewrite the slots,', '        // SAFETY: as ', '')

change('src/lisp/native_comp/runtime.rs', '''    ByteCode {
        record_id: u64,
    },''', '''    ByteCode {
        closure: crate::lisp::types::ClosureRef,
    },''')
change('src/lisp/native_comp/runtime.rs', 'if let Self::ByteCode { record_id } = self {', 'if let Self::ByteCode { closure } = self {')
change('src/lisp/native_comp/runtime.rs', '''.execute_bytecode_funcall_body(
                record_id,''', '''.execute_bytecode_funcall_body(
                closure,''')
section('src/lisp/native_comp/runtime.rs', '''        Kind::Record(record_id) => super::loader::active_direct_function(record_id.id)''', '        _ => None,\n    }\n}', '''        Kind::Record(record_id) => super::loader::active_direct_function(record_id.id)
            .map(|function| DirectFuncallTarget::Native { record_id: record_id.id, function }),
        Kind::Closure(closure) if closure.is_bytecode() => Some(DirectFuncallTarget::ByteCode { closure }),
''')
print('bytecode entry and native dispatch now use closure fields, without record cache')
