from pathlib import Path
root = Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/bytecode-closure/emaxx')
def change(name, old, new, count=1):
    path = root / name
    text = path.read_text()
    assert text.count(old) == count, (name, old[:100], text.count(old), count)
    path.write_text(text.replace(old, new))
def section(name, start, end, replacement):
    path = root / name
    text = path.read_text()
    a = text.index(start)
    b = text.index(end, a)
    path.write_text(text[:a] + replacement + text[b:])

# A transient decoded activation still exists pending the direct-byte VM work.
# It reads closure fields directly; no record-ID cache or mutation notices remain.
change('src/lisp/bytecode.rs', 'pub fn slots_are_genuine_bytecode(slots: &[Value]) -> bool {',
       '#[cfg(test)]\npub fn slots_are_genuine_bytecode(slots: &[Value]) -> bool {')
change('src/lisp/bytecode.rs', '''    pub fn from_slots(slots: &[Value]) -> Result<Option<ByteCodeObject>, ByteCodeError> {
        if !slots_are_genuine_bytecode(slots) {''', '''    #[cfg(test)]
    pub fn from_slots(slots: &[Value]) -> Result<Option<ByteCodeObject>, ByteCodeError> {
        Self::from_fields(slots.len(), |index| slots.get(index).copied())
    }

    pub(crate) fn from_closure(closure: crate::lisp::types::ClosureRef) -> Result<Option<Self>, ByteCodeError> {
        Self::from_fields(closure.public_len(), |index| closure.get(index))
    }

    fn from_fields(len: usize, field: impl Fn(usize) -> Option<Value>) -> Result<Option<Self>, ByteCodeError> {
        if len < 4
            || !matches!(field(0).map(|value| value.kind()), Some(Kind::Integer(_) | Kind::Nil | Kind::Cons(_)))
            || !field(1).is_some_and(|value| value.is_string())
            || !matches!(field(2).map(|value| value.kind()), Some(Kind::Vector(_)))
            || !matches!(field(3).map(|value| value.kind()), Some(Kind::Integer(_)))
        {''')
change('src/lisp/bytecode.rs', '''        let argspec = ArgSpec::from_value(&slots[0])?;
        let code_text = string_text(&slots[1])''', '''        let argspec = ArgSpec::from_value(&field(0).expect("validated argument slot"))?;
        let code_slot = field(1).expect("validated code slot");
        let code_text = string_text(&code_slot)''')
change('src/lisp/bytecode.rs', 'constant_vector(&slots[2])', 'constant_vector(&field(2).expect("validated constants slot"))')
change('src/lisp/bytecode.rs', 'let Kind::Integer(depth) = slots[3].kind()', 'let Kind::Integer(depth) = field(3).expect("validated depth slot").kind()')
change('src/lisp/bytecode.rs', 'decoded_code(&slots[1], &code, constants.len())', 'decoded_code(&code_slot, &code, constants.len())')
change('src/lisp/bytecode.rs', 'interactive: slots.get(5).cloned(),', 'interactive: field(5),')

section('src/lisp/bytecode/vm.rs', '/// Execute the genuine byte-code function stored in RECORD_ID', '/// Execute OBJECT with ARGS,', '''pub(crate) fn closure_program(closure: crate::lisp::types::ClosureRef) -> Result<Rc<CachedProgram>, LispError> {
    let object = ByteCodeObject::from_closure(closure)
        .map_err(|error| LispError::Signal(error.to_string()))?
        .ok_or_else(|| LispError::SignalValue(Value::list([
            Value::symbol("invalid-function"), Value::Closure(closure),
        ])))?;
    Ok(Rc::new(build_cached(&object)?))
}

/// Read the actual PVEC_CLOSURE fields at entry. The decoded activation is
/// temporary until dispatch fetches directly from authoritative string bytes.
#[inline(always)]
pub fn execute_closure(
    interp: &mut Interpreter,
    closure: crate::lisp::types::ClosureRef,
    args: &[Value],
    env: &mut Env,
) -> Result<Value, LispError> {
    let program = closure_program(closure)?;
    run(interp, program, Value::Closure(closure), args, env)
}

''')
change('src/lisp/bytecode/vm.rs', 'if let Some((callee, callee_id)) = interp.bytecode_callee(&func) {',
       'if let Some((callee, callee_function)) = interp.bytecode_callee(&func) {')
change('src/lisp/bytecode/vm.rs', '_ => interp.record_value(callee_id),', '_ => callee_function,')

section('src/lisp/eval/core.rs', 'fn byte_code_function_uses_dynamic_binding(', '// eval_sub\'s CHECK_LIST', '')
change('src/lisp/eval/core.rs', 'execute_bytecode_record_named', 'execute_bytecode_closure_named', 6)
change('src/lisp/eval/core.rs', '''        record_id: u64,
        original_name: Option<CallName<'_>>,''', '''        closure: crate::lisp::types::ClosureRef,
        original_name: Option<CallName<'_>>,''')
change('src/lisp/eval/core.rs', '.unwrap_or(self.record_value(record_id));', '.unwrap_or(Value::Closure(closure));')
change('src/lisp/eval/core.rs', 'interp.execute_bytecode_funcall_body(record_id, args, env)', 'interp.execute_bytecode_funcall_body(closure, args, env)')
change('src/lisp/eval/core.rs', '''    pub(crate) fn execute_bytecode_funcall_body(
        &mut self,
        record_id: u64,''', '''    pub(crate) fn execute_bytecode_funcall_body(
        &mut self,
        closure: crate::lisp::types::ClosureRef,''')
change('src/lisp/eval/core.rs', 'vm::execute_record(self, record_id, args, env)', 'vm::execute_closure(self, closure, args, env)')
section('src/lisp/eval/core.rs', '    /// Only execute_record fills this cache,', '    fn call_function_value_inner(', '''    /// Bcall can enter packed byte-code closures without a host function
    /// registry. Classification reads the shared closure's actual code slot.
    pub(crate) fn bytecode_callee(
        &self,
        func: &Value,
    ) -> Option<(std::rc::Rc<crate::lisp::bytecode::vm::CachedProgram>, Value)> {
        if profile_path().is_some() {
            return None;
        }
        let function = match func.kind() {
            Kind::Symbol(name) => self.globals.function(&name)?,
            _ => *func,
        };
        let Kind::Closure(closure) = function.kind() else { return None; };
        if !closure.is_bytecode() || !matches!(closure.parameters().kind(), Kind::Integer(_)) {
            return None;
        }
        let program = crate::lisp::bytecode::vm::closure_program(closure).ok()?;
        Some((program, function))
    }

''')
change('src/lisp/eval/core.rs', 'Kind::Record(id) if self.has_cached_bytecode_program(id.id)', 'Kind::Closure(closure) if closure.is_bytecode()', 4)
change('src/lisp/eval/core.rs', 'self.execute_bytecode_closure_named(id.id, None, args, env)', 'self.execute_bytecode_closure_named(closure, None, args, env)')
change('src/lisp/eval/core.rs', '''                            let Kind::Record(id) = value.kind() else {
                                unreachable!("matched above")
                            };
                            self.execute_bytecode_closure_named(
                                id.id,''', '''                            let Kind::Closure(closure) = value.kind() else {
                                unreachable!("matched above")
                            };
                            self.execute_bytecode_closure_named(
                                closure,''')
section('src/lisp/eval/core.rs', '        // A record with a cached program is a genuine byte-code function', '        let mut owned_name:', '''        if let Kind::Closure(closure) = func.kind()
            && closure.is_bytecode()
        {
            return self.execute_bytecode_closure_named(closure, original_name, args, env);
        }
''')
change('src/lisp/eval/core.rs', '''                        let Kind::Record(id) = value.kind() else {
                            unreachable!("matched above")
                        };
                        let call_name = original_name.or(Some(CallName::Symbol(&name)));
                        return self.execute_bytecode_closure_named(id.id, call_name, args, env);''', '''                        let Kind::Closure(closure) = value.kind() else {
                            unreachable!("matched above")
                        };
                        let call_name = original_name.or(Some(CallName::Symbol(&name)));
                        return self.execute_bytecode_closure_named(closure, call_name, args, env);''')
section('src/lisp/eval/core.rs', '''            Kind::Record(id)
                if self
                    .find_record(id)
                    .is_some_and(|record| record.kind == RecordKind::Closure) =>''', '            Kind::Closure(_) => self.funcall_interpreted_lambda', '''            Kind::Closure(closure) if closure.is_bytecode() => {
                self.execute_bytecode_closure_named(closure, original_name, args, env)
            }
''')
change('src/lisp/eval/core.rs', 'RecordKind::Closure | RecordKind::NativeCompiledFunction', 'RecordKind::NativeCompiledFunction')

change('src/lisp/eval.rs', '''            if let Some(slot) = self.bytecode_program_cache.get_mut(index) {
                *slot = None;
            }
''', '')
change('src/lisp/eval.rs', '        clone.bytecode_program_cache.clear();\n', '')
section('src/lisp/eval.rs', '    /// Decoded byte-code programs indexed by record ID minus one', '    /// Recycled operand stacks', '')
change('src/lisp/eval.rs', '            bytecode_program_cache: Vec::new(),\n', '')
section('src/lisp/eval/runtime.rs', '        let id = record.id;\n        // The caller may rewrite the slots,', '        // SAFETY: as `find_record`', '')

change('src/lisp/native_comp/runtime.rs', '''    ByteCode {
        record_id: u64,
    },''', '''    ByteCode {
        closure: crate::lisp::types::ClosureRef,
    },''')
change('src/lisp/native_comp/runtime.rs', 'if let Self::ByteCode { record_id } = self {', 'if let Self::ByteCode { closure } = self {')
change('src/lisp/native_comp/runtime.rs', '''.execute_bytecode_funcall_body(
                record_id,''', '''.execute_bytecode_funcall_body(
                closure,''')
section('src/lisp/native_comp/runtime.rs', '''        Kind::Record(record_id) => super::loader::active_direct_function(record_id.id)''', '        _ => None,\n    }\n}', '''        Kind::Record(record_id) => super::loader::active_direct_function(record_id.id)
            .map(|function| DirectFuncallTarget::Native { record_id: record_id.id, function }),
        Kind::Closure(closure) if closure.is_bytecode() => Some(DirectFuncallTarget::ByteCode { closure }),
''')
print('bytecode entry and native dispatch now use closure fields, without record cache')
