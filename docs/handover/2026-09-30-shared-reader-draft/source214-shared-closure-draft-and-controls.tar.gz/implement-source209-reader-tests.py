from pathlib import Path
root=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/bytecode-closure/emaxx')
def change(name,old,new,count=1):
    path=root/name; text=path.read_text()
    assert text.count(old)==count,(name,old[:100],text.count(old),count)
    path.write_text(text.replace(old,new))
def section(name,start,end,replacement):
    path=root/name; text=path.read_text(); a=text.index(start); b=text.index(end,a)
    path.write_text(text[:a]+replacement+text[b:])

section('src/lisp/eval/macros.rs','fn validate_interpreted_closure_literal(', 'struct CircularReadMaterializer', '''fn prepare_closure_literal(
    interp: &mut Interpreter,
    slots: &mut [Value],
    env: &mut Env,
) -> Result<(), LispError> {
    // lread.c accepts both execution modes under the same PVEC_CLOSURE tag.
    if !(3..=6).contains(&slots.len())
        || !matches!(slots[0].kind(), Kind::Integer(_) | Kind::Cons(_) | Kind::Nil)
        || !((matches!(slots[1].kind(), Kind::Cons(_))
              && matches!(slots[2].kind(), Kind::Cons(_) | Kind::Nil))
             || (slots[1].is_string() && matches!(slots[2].kind(), Kind::Vector(_))
                 && slots.get(3).is_some_and(|depth| matches!(depth.kind(), Kind::Integer(n) if n >= 0))))
    {
        return Err(LispError::ReadError("Invalid byte-code object".into()));
    }
    if slots[1].is_string() && crate::lisp::primitives::strings::string_argument_multibyte(&slots[1]) {
        slots[1] = crate::lisp::primitives::call(interp, "string-as-unibyte", &[slots[1]], env)?;
    }
    Ok(())
}

''')
change('src/lisp/eval/macros.rs','closure_kind == Some(ReaderClosureKind::Interpreted)', 'closure_kind.is_some()', 2)
change('src/lisp/eval/macros.rs','Value::allocated_closure(&[Value::Nil; 6][..slots.len()])','Value::Closure(crate::lisp::types::ClosureRef::filled(slots.len(), Value::Nil))',2)
change('src/lisp/eval/macros.rs','''        } else if ordinary_record {
            self.interpreter.create_record_with_type(
                Value::Nil,
                vec![Value::Nil; slots.len().saturating_sub(1)],
            )
        } else {
            self.interpreter.create_pseudovector(
                RecordKind::Closure,
                "byte-code-function",
                vec![Value::Nil; slots.len()],
            )
        };''','''        } else {
            self.interpreter.create_record_with_type(
                Value::Nil,
                vec![Value::Nil; slots.len().saturating_sub(1)],
            )
        };''')
change('src/lisp/eval/macros.rs','validate_interpreted_closure_literal(&resolved)?;',
       'prepare_closure_literal(self.interpreter, &mut resolved, self.environment)?;')
section('src/lisp/eval/macros.rs','''        let Kind::Record(record_id) = placeholder.kind() else {''', '''    fn fill_cons(''', '''        unreachable!("reader allocated an inline closure or record")
    }

''')
change('src/lisp/eval/macros.rs','''                Some(ReaderClosureKind::Interpreted) => {
                    validate_interpreted_closure_literal(&materialized)?;
                    let value = closure.expect("allocated interpreted closure");''','''                Some(_) => {
                    prepare_closure_literal(self, &mut materialized, env)?;
                    let value = closure.expect("allocated closure");''')
change('src/lisp/eval/macros.rs','''                Some(ReaderClosureKind::ByteCode) => self.create_pseudovector(
                    RecordKind::Closure,
                    "byte-code-function",
                    materialized,
                ),
''','')

change('src/lisp/alloc/vectors.rs','''    /// # Safety
    /// HEADER is an allocated ordinary vector's header.''','''    pub(crate) fn shallow_copy(&self) -> Self {
        let len = self.len();
        if len == 0 {
            return *self;
        }
        let nbytes = HEADER_SIZE + len * WORD_SIZE;
        crate::lisp::native_comp::note_lisp_allocation(nbytes);
        let header = allocate_vectorlike(nbytes);
        // SAFETY: fresh word-aligned storage for this header and LEN cells.
        // Read each source Cell without exposing a shared Value reference.
        unsafe {
            (*header).size = len;
            (*header).mark_bit().mark(super::super::types::current_mark_epoch());
            let target = payload(header).cast::<Cell<Value>>();
            for (index, field) in self.cells().iter().enumerate() {
                target.add(index).write(Cell::new(field.get()));
            }
            census_on_allocate(header);
            Self(NonNull::new_unchecked(header))
        }
    }

    /// # Safety
    /// HEADER is an allocated ordinary vector's header.''')

# Adapt internal fixtures to the shared allocation; retain their semantic checks.
change('src/lisp/primitives/tests.rs','''    let Some(Kind::Record(decoder_id)) =''','''    let Some(Kind::Closure(decoder)) =''')
change('src/lisp/primitives/tests.rs','''    assert_eq!(
        interp.find_record(decoder_id).map(|record| record.kind),
        Some(crate::lisp::eval::RecordKind::Closure)
    );''','''    assert!(decoder.is_bytecode());''')
change('src/lisp/primitives/tests.rs','''    let closure = interp.create_pseudovector(
        crate::lisp::eval::RecordKind::Closure,
        "byte-code-function",
        vec![Value::list([optional, argument])],
    );''','''    let closure = Value::allocated_closure(&[
        Value::list([optional, argument]),
        Value::string("unexecuted argument descriptor probe"),
        Value::vector([]),
        Value::Integer(1),
    ]);''')
change('src/lisp/native_comp/runtime.rs','''        let closure = interpreter.create_pseudovector(
            crate::lisp::eval::RecordKind::Closure,
            "closure",
            slots,
        );''','''        let closure = Value::allocated_closure(&slots);''')
change('src/lisp/native_comp/runtime.rs','''        let Kind::Record(id) = closure.kind() else {
            panic!("closure is a pseudovector")
        };
        assert!(interpreter.is_genuine_bytecode_function(id.id));
        interpreter.find_record_mut(id).expect("closure").slots[1] =
            Value::list([Value::Integer(42)]);
        assert!(!interpreter.is_genuine_bytecode_function(id.id));''','''        let Kind::Closure(fields) = closure.kind() else {
            panic!("closure is a pseudovector")
        };
        assert!(fields.is_bytecode());
        fields.initialize_slot(1, Value::list([Value::Integer(42)]));
        assert!(!fields.is_bytecode());''')
change('src/lisp/native_comp/runtime.rs','''            Value::Record(id),
            Value::Nil,
        );
    }

    extern "C" fn call_memq''','''            closure,
            Value::Nil,
        );
    }

    extern "C" fn call_memq''')
change('src/lisp/native_comp/runtime.rs','''        let prototype = interpreter.create_pseudovector(
            crate::lisp::eval::RecordKind::Closure,
            "byte-code-function",
            vec![
                Value::Nil,
                Value::string("bytecode"),
                prototype_constants,
                Value::Integer(2),
            ],
        );''','''        let prototype = Value::allocated_closure(&[
            Value::Nil,
            Value::string("bytecode"),
            prototype_constants,
            Value::Integer(2),
        ]);''')
section('src/lisp/native_comp/runtime.rs','''        let Kind::Record(closure_id) = closure.kind() else {
            panic!("make-closure returns a closure record")''','''        assert_eq!(constants, vec![captured, retained]);''','''        let Kind::Closure(closure) = closure.kind() else {
            panic!("make-closure returns an inline closure")
        };
        assert!(closure.is_bytecode());
        let constants_value = closure.get(2).expect("constant field");
        let constants = crate::lisp::primitives::vector_items(&constants_value)
            .expect("fresh constants vector");
''')
change('src/lisp/native_comp/runtime.rs','(closure.slots[2].kind(), prototype_constants.kind())','(constants_value.kind(), prototype_constants.kind())')
path=root/'src/lisp/native_comp/runtime.rs'; text=path.read_text()
a=text.index('''        let function = interpreter.create_pseudovector(
            crate::lisp::eval::RecordKind::Closure,''')
b=text.index('\n        assert!',a)
old=text[a:b]
new=old.replace('interpreter.create_pseudovector(\n            crate::lisp::eval::RecordKind::Closure,\n            "byte-code-function",\n            vec![','Value::allocated_closure(&[').replace('            ],\n        );', '        ]);')
assert new!=old
path.write_text(text[:a]+new+text[b:])
change('src/lisp/primitives/pdumper/image.rs',"/// An interpreted closure (`Value::Lambda').", "/// An interpreted or byte-code closure (`Value::Closure').")
print('reader and existing internal bytecode fixtures use inline closures')
