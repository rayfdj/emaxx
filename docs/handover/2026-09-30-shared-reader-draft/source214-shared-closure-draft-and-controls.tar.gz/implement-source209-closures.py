from pathlib import Path

root = Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/bytecode-closure/emaxx')

def change(name, old, new, count=1):
    path = root / name
    text = path.read_text()
    assert text.count(old) == count, (name, old[:120], text.count(old), count)
    path.write_text(text.replace(old, new))

# PVEC_CLOSURE is shared by interpreted and byte-code functions in GNU.
# Name the Rust view for that header, rather than one execution mode.
for path in root.joinpath('src').rglob('*.rs'):
    text = path.read_text()
    updated = text.replace('Kind::Lambda(', 'Kind::Closure(').replace('Value::Lambda(', 'Value::Closure(')
    updated = updated.replace('allocated_lambda', 'allocated_closure')
    updated = updated.replace('LambdaRef', 'ClosureRef').replace('LambdaValue', 'ClosureRef')
    if updated != text:
        path.write_text(updated)

change('src/lisp/types.rs', 'pub type ClosureRef = crate::lisp::alloc::ClosureRef;',
       'pub use crate::lisp::alloc::ClosureRef;', 2)
change('src/lisp/types.rs', "/// The pseudovector kinds' handles (alloc.c's `allocate_pseudovector').\npub use crate::lisp::alloc::ClosureRef;",
       "/// The pseudovector kinds' handles (alloc.c's `allocate_pseudovector').")
change('src/lisp/types.rs', '/// Interpreted closures keep their GNU slots in the vector allocation.',
       '/// Interpreted and byte-code closures share their inline GNU fields.')
change('src/lisp/types.rs', '    /// A lambda or closure: params, immutable shared body, captured env.\n    Lambda(ClosureRef),',
       '    /// GNU PVEC_CLOSURE: argument descriptor, code/body, constants/environment.\n    Closure(ClosureRef),')
change('src/lisp/types.rs', 'pub fn Lambda(lambda: ClosureRef)', 'pub fn Closure(lambda: ClosureRef)')

change('src/lisp/alloc/vectors.rs', '/// An interpreted PVEC_CLOSURE: its header followed by the actual Lisp\n/// slots. No copied parameter/body representation accompanies the object.',
       '/// GNU PVEC_CLOSURE: its header followed by the authoritative Lisp slots.\n/// Interpreted and byte-code functions use this same allocation.')
change('src/lisp/alloc/vectors.rs', '''        assert!((3..=6).contains(&slots.len()));
        let nbytes = vroundup(HEADER_SIZE + slots.len() * WORD_SIZE);''', '''        Self::from_fields(slots.len(), |index| slots[index])
    }

    pub(crate) fn filled(len: usize, value: Value) -> Self {
        Self::from_fields(len, |_| value)
    }

    pub(crate) fn shallow_copy(&self) -> Self {
        Self::from_fields(self.public_len(), |index| self.cells()[index].get())
    }

    fn from_fields(len: usize, mut field: impl FnMut(usize) -> Value) -> Self {
        assert!(len <= PSEUDOVECTOR_SIZE_MASK);
        let nbytes = vroundup(HEADER_SIZE + len * WORD_SIZE);''')
change('src/lisp/alloc/vectors.rs', 'VectorHeader::pseudovector_slots_word(VectorTag::Closure, nbytes, slots.len());',
       'VectorHeader::pseudovector_slots_word(VectorTag::Closure, nbytes, len);')
change('src/lisp/alloc/vectors.rs', '''            for (index, value) in slots.iter().enumerate() {
                target.add(index).write(Cell::new(*value));
            }''', '''            for index in 0..len {
                target.add(index).write(Cell::new(field(index)));
            }''')
change('src/lisp/alloc/vectors.rs', '/// HEADER names a live interpreted closure allocated by this allocator.',
       '/// HEADER names a live PVEC_CLOSURE allocated by this allocator.')
change('src/lisp/alloc/vectors.rs', '''    /// Fill a slot while reconstructing an object graph. Lisp cannot aset''', '''    #[inline]
    pub(crate) fn is_bytecode(&self) -> bool {
        // data.c:Fbyte_code_function_p checks the actual code field only.
        self.get(1).is_some_and(|code| code.is_string())
    }

    /// Fill a slot while reconstructing an object graph. Lisp cannot aset''')

change('src/lisp/primitives/dispatch/predicates.rs', '''                Ok(interp.create_pseudovector(
                    crate::lisp::eval::RecordKind::Closure,
                    "byte-code-function",
                    args.to_vec(),
                ))''', '''                Ok(Value::allocated_closure(args))''')

path = root / 'src/lisp/eval/runtime.rs'
text = path.read_text()
start = text.index('        let Kind::Record(id) = prototype.kind() else {', text.index('pub(crate) fn make_closure('))
end = text.index('\n    fn create_record_with_kind(', start)
text = text[:start] + '''        let Kind::Closure(closure) = prototype.kind() else {
            return Err(LispError::WrongTypeArgument(
                "byte-code-function-p".into(),
                *prototype,
            ));
        };
        let constants = closure.get(2).ok_or_else(|| {
            LispError::Signal("make-closure prototype has no constants vector".into())
        })?;
        let Kind::Vector(constants) = constants.kind() else {
            return Err(LispError::WrongTypeArgument("vectorp".into(), constants));
        };
        if closure_vars.len() > constants.len() {
            return Err(LispError::Signal("Closure vars do not fit in constvec".into()));
        }
        // alloc.c:Fmake_closure copies the actual constant vector and closure
        // slots. No host record, registry entry or detached slot array exists.
        let copied_constants = constants.shallow_copy();
        for (index, value) in closure_vars.iter().enumerate() {
            copied_constants.set(index, *value);
        }
        let copied = closure.shallow_copy();
        copied.initialize_slot(2, Value::Vector(copied_constants));
        Ok(Value::Closure(copied))
    }
''' + text[end:]
path.write_text(text)

change('src/lisp/eval.rs', '    Closure,\n', '')
change('src/lisp/eval.rs', '''            // Both interpreted and byte-code closures are ordinary vectors
            // retagged PVEC_CLOSURE.
            Self::Closure => logical_slots.saturating_add(1),
''', '')

# The shared collector and graph copier already traverse every closure field.
change('src/lisp/eval.rs', 'Value::allocated_closure(&vec![Value::Nil; lambda.public_len()])',
       'Value::Closure(crate::lisp::alloc::ClosureRef::filled(lambda.public_len(), Value::Nil))')
print('shared closure allocation and constructors written')
