from pathlib import Path
import json
import subprocess
import sys
import time

p=Path(__file__).parent.resolve()
stages=[
    ('check',['python3',str(p/'check-bytecode208.py'),'213']),
    ('strict',['python3',str(p/'static-bytecode208.py'),'213']),
    ('gate-controls',['python3',str(p/'test-bytecode-controls-next.py'),'213','gate']),
]
results=[]
for stage,command in stages:
    start=time.monotonic()
    print('START',stage,flush=True)
    completed=subprocess.run(command,cwd=p.parents[2])
    results.append({'stage':stage,'command':command,'exit_code':completed.returncode,
                    'elapsed_seconds':time.monotonic()-start})
    print('END',stage,results[-1],flush=True)
    if completed.returncode:
        break
with (p/'source213-controls-result.json').open('x') as stream:
    json.dump(results,stream,indent=2)
    stream.write('\n')
sys.exit(results[-1]['exit_code'])
