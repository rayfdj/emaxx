from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve();root=p.parents[2];out=root/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest()
tree=ast.parse((p/'package-source196-failure-and197-results.py').read_text())
node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
names=['source215-controls-audit.json','audit-source215-controls.py','source214-gate-controls-command.json',
       'source215-gate-inventory.txt','source215-gate-broad-command.json','test-bytecode-controls215.py','test-bytecode-broad215.py',Path(__file__).name]
for label in ['check','fmt','clippy','diff','gate-build','gate-controls']:
    names += ['source215-'+label+suffix for suffix in ['-command.json','-result.json','.log']]
package('source215-shared-closure-controls',{name:p/name for name in names},json.loads((p/'source215-controls-audit.json').read_text()))
