from pathlib import Path
import ast,hashlib,json,re
p=Path(__file__).parent.resolve();root=p.parent/'recovered-2026-09-30/bytecode-closure/emaxx'
read=lambda name:json.loads((p/name).read_text())
sha=lambda file:hashlib.sha256(file.read_bytes()).hexdigest()
manifest=read('source215-manifest.json')
assert len(manifest)==418 and all(sha(root/name)==digest for name,digest in manifest.items())
tree=ast.parse((p/'audit-shared-reader196-fresh-selected.py').read_text())
node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='audit_log')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<raw-auditor>','exec'))
command=read('source215-gate-controls-command.json');result=read('source215-gate-controls-result.json')
assert result['exit_code']==101 and result['source_unchanged']
assert sha(p/'source215-gate-libtest')==command['binary_sha256']
names=command['selected_inventory']
old_names=read('source214-gate-controls-command.json')['selected_inventory']
assert set(names)==set(old_names)|{'lisp::native_comp::runtime::record_layout_tests::bytecode_closure_copy_counts_both_actual_allocations'}
failed=audit_log(names,(p/'source215-gate-controls.log').read_text(),6,1)
assert [name.rsplit('::',1)[1] for name in failed]==['bytecode_code_mutation_during_active_call_matches_gnu']
for label in ['check','fmt','clippy','diff','gate-build']:
    outcome=read('source215-'+label+'-result.json')
    assert outcome['exit_code']==0 and outcome['source_unchanged']
    raw=(p/('source215-'+label+'.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:',raw,re.M)
    for line in raw.splitlines():
        try:item=json.loads(line)
        except json.JSONDecodeError:continue
        assert item.get('message',{}).get('level') not in ['error','warning']
    if label in ['fmt','diff']:assert not raw
inventory=[line[:-6] for line in (p/'source215-gate-inventory.txt').read_text().splitlines() if line.endswith(': test')]
broad=read('source215-gate-broad-command.json')
expected=[name for name in inventory if name.startswith(('lisp::bytecode::','lisp::native_comp::runtime::','lisp::primitives::pdumper::','lisp::primitives::tests::'))]
assert broad['selected_inventory']==expected and len(expected)==848
assert set(names)<=set(expected)
record=dict(status='partial bytecode repair; active-call mutation still fails',inputs_verified=418,
    binary_sha256=command['binary_sha256'],strict_checks='passed with zero warnings',passed=6,failed=1,ignored=0,
    passing_names=[name for name in names if name not in failed],failing_names=failed,raw_libtest_exit_code=101,
    broad_inventory_verified=848,
    qualification='All six original controls plus the new twenty-case closure/constant-copy census and identity test execute. The reviewed live-vector census omission is repaired. Active-call code mutation remains (41 194), expected (67 194). Broader modules are launched separately; this focused audit does not assign their outcome or certify complete closure/VM architecture or performance.',
    raw_hashes={name:sha(p/name) for name in ['source215-gate-controls.log','source215-gate-controls-command.json','source215-gate-controls-result.json','source215-gate-broad-command.json']})
with (p/'source215-controls-audit.json').open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps(record,indent=2))
