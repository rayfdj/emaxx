from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve();out=p.parents[2]/'docs/handover/2026-09-30-shared-reader-draft';sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda n:json.loads((p/n).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package');exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
allowed={'.json','.log','.txt','.py','.patch','.stdout','.stderr','.el','.expected','.h','.loaded','.c'}
for kind,dirname in [('rust','source311-linux-rust-artifacts'),('stack-performance','source311-linux-core-runtime-pair-artifacts')]:
 files={};excluded=[]
 for f in (p/dirname).rglob('*'):
  if f.is_file():
   if f.suffix in allowed or f.name=='Makefile':files[str(f.relative_to(p))]=f
   else:excluded.append(dict(path=str(f.relative_to(p)),bytes=f.stat().st_size,sha256=sha(f.read_bytes())))
 if kind=='rust':
  audit=read('source311-linux-rust-audit.json');assert audit['status']=='passed' and audit['total_passed']==3164
  names=['source311-linux-rust-audit.json','source311-linux-rust-name-audit.json','source311-linux-rust-oracle-audit.json','source311-linux-rust-download-files.json','source311-linux-rust-terminal.json','source311-linux-rust-download.json','audit-source311-linux-rust.py','verify-source311-linux-rust.py','source310-validation-input-recovery.json','source311-modes.json','source311-portable-complete.patch']
  scope=dict(status='complete source311 Linux Rust validation passed',source_commit=audit['source_commit'],rust=audit,excluded_binaries=excluded,goal_complete=False,qualification='All 3063 library names and Cargo results verified; 3164 passes and two existing ignores. Exact source bytes/modes and retained inputs are checked. This run does not erase older GNU census failures; source311 frozen/macOS and draft312 are separate.')
 else:
  audit=read('source311-linux-pair-performance-audit.json');assert audit['status']=='192 actual Linux process results and modes independently verified'
  names=['source311-linux-pair-performance-audit.json','audit-source311-linux-pair.py','source311-linux-core-runtime-pair-terminal.json','source311-linux-core-runtime-pair-download.json','source311-linux-pair-installation.json','source311-linux-pair-helper-audit.json','source311-linux-pair-consistent-corruption-audit.json','test-core-runtime-perf-pair.py']
  scope={k:audit[k] for k in ['status','run_id','source_revisions','raw_body_geometric_ratio','paired_gnu_geometric_ratios','qualification','goal_complete']};scope['excluded_binaries']=excluded
 for n in names+['source311-full-validation-launch.json','source311-manifest.json','source311-applied-commit.json',Path(__file__).name,'package-source196-failure-and197-results.py']:files[n]=p/n
 assert all(f.is_file() for f in files.values());package('source311-linux-'+kind+'-results',files,scope)
