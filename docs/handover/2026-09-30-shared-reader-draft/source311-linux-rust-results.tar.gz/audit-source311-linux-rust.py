from pathlib import Path
import hashlib,json,re,subprocess,sys
p=Path(__file__).parent.resolve();head='447c84c13017f47878855273a2a0609f9f9edeb1';artifact=p/('source311-linux-rust-artifacts/ordinary-linux-'+head);root=artifact/'rust';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();read=lambda f:json.loads(f.read_text())
terminal=read(p/'source311-linux-rust-terminal.json');assert terminal['headSha']==head and terminal['status']=='completed' and terminal['conclusion']=='success'
files={str(f.relative_to(p/'source311-linux-rust-artifacts')):sha(f) for f in artifact.rglob('*') if f.is_file()}
(p/'source311-linux-rust-download-files.json').open('x').write(json.dumps(dict(files=files,run_id=37437608126,goal_complete=False),indent=2))
s=read(root/'summary.json');assert s['status']=='passed' and s['git']==dict(dirty=False,head=head)
inventory=[x[:-6] for x in (root/'inventory.txt').read_text().splitlines() if x.endswith(': test')]
prior=p/'source310-linux-rust-artifacts/ordinary-linux-5e6f6fc89654b5e695161f5e1713d06ff8ca1f3c/rust/inventory.txt'
old={x[:-6] for x in prior.read_text().splitlines() if x.endswith(': test')}
assert len(old)==3061
added={'lisp::bytecode::vm::bytecode_stack_footers_share_storage_and_preserve_borrowed_caller_arguments',
       'lisp::primitives::tests::bytecode_stack_capacity_and_nested_reservations_match_gnu'}
assert not old.intersection(added)
assert len(inventory)==len(set(inventory))==3063 and set(inventory)==old|added
seen={}
for group in s['runs'][0]['groups']:
 raw=(root/Path(group['log']).name).read_text();starts=list(re.finditer(r'^test (\S+) \.\.\. ',raw,re.M));assert len(starts)==group['expected_tests']
 for i,m in enumerate(starts):
  end=starts[i+1].start() if i+1<len(starts) else raw.rindex('test result:');verdict=raw[m.end():end].strip();assert m[1] not in seen
  if m[1] in s['inventory']['ignored_tests']:assert verdict.startswith('ignored');seen[m[1]]='ignored'
  else:assert re.search(r'(?:^|\s)ok$',verdict),(m[1],verdict);seen[m[1]]='passed'
assert set(seen)==set(inventory)
(p/'source311-linux-rust-name-audit.json').open('x').write(json.dumps(dict(status='passed',raw_names_verified=len(seen),added_tests=sorted(added),raw_verdicts=seen,inventory_sha256=sha(root/'inventory.txt'),goal_complete=False),indent=2))
helper=p/'verify-source311-linux-rust.py'
subprocess.run([sys.executable,str(helper),str(root),head,str(p/'source311-linux-rust-audit.json')],check=True)
cap=artifact/'oracle-inputs';m=read(cap/'manifest.json');v=read(cap/'verification.json')
assert m['status']=='captured' and m['source_commit']=='636f166cfc86aa90d63f592fd99f3fdd9ef95ebd' and m['source_tracked_changes']==[]
assert v['status']=='unchanged' and v['files_verified']==4 and v['capture_manifest_sha256']==sha(cap/'manifest.json')
for item in m['files']:
 f=cap/item['artifact'];assert sha(f)==item['sha256'] and f.stat().st_size==item['bytes']
assert m['files'][0]['sha256']=='5e1721732427d69d8af63211f1e3833ec21e40f97f4b7f6cd4cb224b72cebfcf'
assert m['files'][1]['sha256']=='bf4974228f3b3ea4374cec75a38eeb2bd0e7dd944da5bec4e6ad0387092502ae'
(p/'source311-linux-rust-oracle-audit.json').open('x').write(json.dumps(dict(status='passed',capture=m,verification=v,goal_complete=False,qualification='The pinned Linux GNU inputs were retained before this run and verified unchanged after it. The full-source311 Rust pass, including its GNU census assertion, does not erase the prior GNU census failures or establish their cause.'),indent=2))
print('Complete Linux source311 raw names, counts, artifact identities and retained GNU inputs verified')
