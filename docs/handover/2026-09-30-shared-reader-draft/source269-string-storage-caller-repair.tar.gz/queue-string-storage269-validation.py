from pathlib import Path
import hashlib,json,os,subprocess,sys,time
p=Path(__file__).parent.resolve()
candidate=p.parent/'recovered-2026-09-30/string-storage/emaxx'
prior=p.parent/'recovered-2026-09-30/string-ranges/emaxx'
root=p.parents[2]
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
read=lambda n:json.loads((p/n).read_text())
manifest=read('source269-manifest.json')
previous=read('source263-manifest.json')
published=read('source261-manifest.json')
unchanged=lambda:len(manifest)==510 and all(sha(candidate/n)==h for n,h in manifest.items())
previous_unchanged=lambda:len(previous)==500 and all(sha(prior/n)==h for n,h in previous.items())
published_unchanged=lambda:len(published)==488 and all(sha(root/n)==h for n,h in published.items())
stages=[['run-string-storage-focused.py', '269'], ['audit-string-storage-focused.py', '269'], ['test-string-storage-broad.py', '269', 'gate'], ['run-string-storage-release.py', '269'], ['audit-string-storage-release.py', '269'], ['test-string-storage-broad.py', '269', 'release'], ['build-string-storage-ordinary.py', '269'], ['compare-string-storage-fixtures.py', 'source269', '/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/string-storage/emaxx', 'coding-post-read-character-count', 'coding-post-read-fast-path', 'overriding-property-identity', 'coding-candidate-symbol-properties', 'coding-candidate-translation', 'coding-candidate-character-identities', 'coding-candidate-inventory', 'file-write-coding-selection', 'new-file-coding-lifecycle', 'file-write-order', 'canonical-coding-character-storage', 'canonical-coding-identity-storage', 'canonical-coding-conversion-storage', 'copied-canonical-string-storage', 'coding-error-object-storage', 'host-string-mutation', 'host-string-vector-mutation', 'string-equality-storage', 'string-equality-symbol-names-positioned', 'string-equality-property-values', 'string-equality-property-hashes', 'native-bytecode-unibyte-constructor', 'string-ordering-symbol-storage', 'string-version-ordering', 'compare-strings-ranges', 'compare-strings-character-storage', 'compare-strings-live-case-table', 'string-case-character-identities', 'string-ordering-prefix-boundaries', 'string-empty-identities', 'string-pure-storage-values', 'string-pure-property-storage', 'string-comparison-case-table-initialization']]
helpers={str(p/s[0]):sha(p/s[0]) for s in stages}
state=dict(status='starting isolated string-storage selected validation',source_manifest='source269-manifest.json',helper_sha256=helpers,stages=stages,results=[],goal_complete=False)
def save_state():
    (p/'source269-validation-queue-state.json').write_text(json.dumps(state,indent=2)+'\n')
try:
    assert read('source263-broad-failure-audit.json')['counts']==dict(ok=1053,FAILED=1,ignored=0)
    assert read('source261-macos-terminal-audit.json')['status']=='passed'
    assert unchanged() and previous_unchanged() and published_unchanged()
    for check in ['fmt','check','clippy','diff']:
        result=read('source269-'+check+'-result.json')
        assert result['exit_code']==0 and result['source_unchanged']
    for name,*arguments in stages:
        helper=p/name
        assert unchanged() and previous_unchanged() and published_unchanged() and sha(helper)==helpers[str(helper)]
        command=[sys.executable,'-B',str(helper),*arguments]
        state.update(status='running isolated string-storage selected validation',current_command=command)
        save_state()
        started=time.monotonic()
        result=subprocess.run(command,cwd=candidate,stdin=subprocess.DEVNULL,env=dict(os.environ,PYTHONUNBUFFERED='1',PYTHONDONTWRITEBYTECODE='1'))
        record=dict(command=command,exit_code=result.returncode,elapsed_seconds=time.monotonic()-started,source_unchanged=unchanged(),prior_source_unchanged=previous_unchanged(),published_source_unchanged=published_unchanged(),helper_unchanged=sha(helper)==helpers[str(helper)])
        state['results'].append(record)
        if result.returncode or not all(record[k] for k in ['source_unchanged','prior_source_unchanged','published_source_unchanged','helper_unchanged']):break
    state['status']='selected processes finished; raw evidence requires audit'
except Exception as error:
    state.update(status='queue or validation failed',error=repr(error))
finally:
    save_state()
    with (p/'source269-validation-result.json').open('x') as f:json.dump(state,f,indent=2)
print(json.dumps(state),flush=True)
sys.exit(0 if len(state['results'])==len(stages) and all(r['exit_code']==0 and all(r[k] for k in ['source_unchanged','prior_source_unchanged','published_source_unchanged','helper_unchanged']) for r in state['results']) else 1)
