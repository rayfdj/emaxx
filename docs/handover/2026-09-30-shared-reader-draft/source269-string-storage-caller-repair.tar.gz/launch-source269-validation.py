from pathlib import Path
import hashlib,json,os,subprocess,sys,time
p=Path(__file__).parent.resolve()
helper=p/'queue-string-storage269-validation.py'
read=lambda n:json.loads((p/n).read_text())
assert read('source268-focused-audit.json')['counts']==dict(ok=199,FAILED=4,ignored=2)
assert len(read('source268-fixture-framing-audit.json')['findings'])==4
assert read('source269-storage-patch-replay-audit.json')['status']=='exact'
assert not (p/'source269-validation-launch.json').exists()
command=[sys.executable,'-B',str(helper)]
with (p/'source269-validation-driver.log').open('xb') as log:
    proc=subprocess.Popen(command,cwd=p.parents[2],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env=dict(os.environ,PYTHONUNBUFFERED='1',PYTHONDONTWRITEBYTECODE='1'))
record=dict(pid=proc.pid,command=command,helper_sha256=hashlib.sha256(helper.read_bytes()).hexdigest(),launched_at_unix=time.time(),stdin='DEVNULL',start_new_session=True,log=str(p/'source269-validation-driver.log'),goal_complete=False,qualification='Isolated source269 selected validation:205 focused selectors,1059 affected tests per profile,33 ordinary GNU comparisons. Only four test expectation callers changed from failed268; GNU fixtures unchanged. Runtime root261 remains unchanged.')
with (p/'source269-validation-launch.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(record,indent=2))
