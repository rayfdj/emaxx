from pathlib import Path
import ast, hashlib, json, re

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/string-storage/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p / n).read_text())
manifest = read('source268-manifest.json')
assert len(manifest) == 510 and all(sha(root / n) == h for n, h in manifest.items())
audit = read('source268-focused-audit.json')
assert audit['counts'] == dict(ok=199, FAILED=4, ignored=2)
fixtures = {
    'pure_string_properties_preserve_gnu_noop_and_readonly_behavior': 'string-pure-property-storage',
    'pure_strings_preserve_gnu_identity_write_protection_and_error_order': 'string-pure-storage-values',
    'string_empty_constructors_preserve_gnu_storage_identities': 'string-empty-identities',
    'subr_frontier_compare_strings_uses_gnu_simple_upcase_canonicalization': 'string-comparison-case-table-initialization',
}
assert set(audit['failed_tests']) == {'lisp::primitives::tests::' + n for n in fixtures}
raw = (p / 'source268-gate-controls.log').read_text()
blocks = list(re.finditer(r'^test (\S+) \.\.\. ', raw, re.M))
findings = []
for index, match in enumerate(blocks):
    name = match[1].removeprefix('lisp::primitives::tests::')
    if name not in fixtures:
        continue
    stop = blocks[index + 1].start() if index + 1 < len(blocks) else raw.find('\nfailures:', match.end())
    block = raw[match.end():stop]
    assert 'src/lisp/primitives/tests.rs:409:' in block and 'oracle disagreed; program sent was:' in block
    lefts = re.findall(r'^\s*left: (".*")$', block, re.M)
    rights = re.findall(r'^\s*right: (".*")$', block, re.M)
    assert len(lefts) == len(rights) == 1
    actual, expected = ast.literal_eval(lefts[0]), ast.literal_eval(rights[0])
    fixture = root / 'tests/fixtures' / (fixtures[name] + '.expected')
    assert expected == fixture.read_text() and expected == actual + '\n'
    findings.append(dict(test=match[1], fixture=str(fixture.relative_to(root)),
                         expected_sha256=sha(fixture), actual_characters=len(actual),
                         expected_characters=len(expected), only_difference='one trailing newline',
                         failed_stage='GNU precondition before corresponding Emaxx fixture execution'))
assert len(findings) == 4
record = dict(status='four fixture-caller framing failures verified', source_inputs=510,
              focused_counts=audit['counts'], raw_log_sha256=sha(p / 'source268-gate-controls.log'),
              findings=findings,
              correction='Use the existing trim_end convention only at these four new Rust expected-output call sites. Preserve GNU fixture files and the shared comparison helper.',
              qualification='This does not establish an Emaxx pass for any of these four fixture assertions. All raw failures and source268 artifacts remain unchanged.')
with (p / 'source268-fixture-framing-audit.json').open('x') as f:
    json.dump(record, f, indent=2)
print(json.dumps(record, indent=2))
