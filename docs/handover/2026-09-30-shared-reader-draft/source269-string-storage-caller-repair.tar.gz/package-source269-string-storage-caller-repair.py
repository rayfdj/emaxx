from pathlib import Path
import ast,gzip,hashlib,io,json,re,tarfile
p=Path(__file__).parent.resolve();root=p.parents[2]
candidate=p.parent/'recovered-2026-09-30/string-storage/emaxx'
out=root/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda n:json.loads((p/n).read_text())
old,new=read('source268-manifest.json'),read('source269-manifest.json')
assert len(old)==len(new)==510 and old.keys()==new.keys()
assert all(sha((candidate/n).read_bytes())==h for n,h in new.items())
changed=[n for n in new if old[n]!=new[n]]
assert changed==['src/lisp/primitives/tests.rs']
text=(candidate/changed[0]).read_text()
for fixture in ['string-empty-identities','string-pure-storage-values','string-pure-property-storage']:
    before='include_str!("../../../tests/fixtures/'+fixture+'.expected").trim_end(),'
    after=before.replace('.trim_end()','')
    assert text.count(before)==1
    text=text.replace(before,after)
before='include_str!(\n            "../../../tests/fixtures/string-comparison-case-table-initialization.expected"\n        )\n        .trim_end(),'
after=before.replace(')\n        .trim_end(),', '),')
assert text.count(before)==1
text=text.replace(before,after)
assert sha(text.encode())==old[changed[0]]
for stage in ['check','fmt','clippy','diff']:
    result=read('source269-'+stage+'-result.json')
    assert result['exit_code']==0 and result['source_unchanged']
    assert not re.search(r'^warning(?:\[.*\])?:',(p/('source269-'+stage+'.log')).read_text(),re.M)
assert read('source268-focused-audit.json')['counts']==dict(ok=199,FAILED=4,ignored=2)
assert len(read('source268-fixture-framing-audit.json')['findings'])==4
assert read('source269-storage-patch-replay-audit.json')['status']=='exact'
for item in read('source268-focused-retained-inputs.json')['files']:
    assert sha(Path(item['original']).read_bytes())==sha(Path(item['artifact']).read_bytes())==item['sha256']
published=read('source261-manifest.json')
assert len(published)==488 and all(sha((root/n).read_bytes())==h for n,h in published.items())
launch=read('source269-validation-launch.json')
assert sha((p/'queue-string-storage269-validation.py').read_bytes())==launch['helper_sha256']
preparation=dict(source_inputs_verified=510,changed_from268=changed,change='exactly four trim_end calls at newly added expected-output callers',gnu_fixture_bytes_unchanged=True,shared_comparison_helper_unchanged=True,strict_checks='zero-warning pass',patches='both exact',published_source261_unchanged=True,prior_failed_counts=dict(ok=199,FAILED=4,ignored=2),launch=launch,qualification='Preparation only. Source268 failed at four GNU preconditions before their Emaxx fixture executions; these tests must run again. All failures remain preserved. No runtime pass inferred for269.')
with (p/'source269-storage-caller-preparation-audit.json').open('x') as f:json.dump(preparation,f,indent=2)
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
files={}
for path in p.iterdir():
    n=path.name
    if not path.is_file():continue
    failed=n.startswith('source268-') and any(n.startswith('source268-'+s) for s in ['gate-','focused-','fixture-framing','validation-']) and path.suffix in ['.json','.log']
    prepared=n.startswith('source269-') and any(n.startswith('source269-'+s) for s in ['format','manifest','freeze','unformatted','incremental','portable','check','fmt','clippy','diff','storage','validation-launch']) and path.suffix in ['.json','.log','.patch']
    if failed or prepared:files[n]=path
for n in ['source268-manifest.json','source268-storage-patch-replay-audit.json','audit-source268-fixture-framing.py','audit-source269-storage-patches.py','audit-source269-selected.py','launch-source269-validation.py','queue-string-storage269-validation.py','check-string-storage-callers.py','freeze-string-storage-callers.py','run-string-storage-focused.py','audit-string-storage-focused.py','run-string-storage-release.py','audit-string-storage-release.py','test-string-storage-broad.py','build-string-storage-ordinary.py','compare-string-storage-fixtures.py','package-source196-failure-and197-results.py',Path(__file__).name]:
    assert (p/n).is_file(),n
    files[n]=p/n
package('source269-string-storage-caller-repair',files,dict(preparation=preparation,failed_source268=read('source268-focused-audit.json'),diagnosis=read('source268-fixture-framing-audit.json'),qualification='Closed failed source268 focused result plus portable strict-checked source269 continuation. Source268 is199pass/fourfail/twoexistingignores; no broad,release,ordinary stage ran. Source269 preserves all510 inputs except the four new test-caller trim_end calls;205focused selectors,1059affected tests/profile and33ordinary fixtures run under97120. Only immutable strict/launch evidence is packaged for269. Runtime root261 unchanged. Full architecture,platform correctness and locked performance requirements remain open.'))
