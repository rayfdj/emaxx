from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve();root=p.parents[2]
out=root/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda n:json.loads((p/n).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
macos=read('source270-macos-rust-audit.json');linux=read('source270-linux-rust-audit.json')
assert macos['status']==linux['status']=='passed'
assert macos['total_passed']==3118 and linux['total_passed']==3130
assert macos['library_ignored']==linux['library_ignored']==2
assert read('source270-macos-rust-name-audit.json')['raw_names_verified']==3021
assert read('source270-linux-rust-name-audit.json')['raw_names_verified']==3029
allowed={'.json','.log','.txt','.py','.h'}
files={}
for dirname in ['full-gate-source270','source270-linux-rust-artifacts']:
    for file in (p/dirname).rglob('*'):
        if file.is_file() and (file.suffix in allowed or file.name=='Makefile'):
            assert not file.is_symlink()
            files[str(file.relative_to(p))]=file
helpers={
    'source270-manifest.json','source270-full-checkout.json','source270-full-rust-command.json',
    'source270-full-rust-result.json','source270-full-rust.log','source270-full-rust-binary.json',
    'source270-full-rust-retention-command.json','source270-full-rust-retention-result.json','source270-full-rust-retention.log',
    'source270-macos-rust-audit.json','source270-macos-rust-name-audit.json','source270-macos-rust-oracle-audit.json',
    'source270-full-retained-gnu/manifest.json','source270-full-retained-gnu/config.h','source270-full-retained-gnu/Makefile',
    'queue-source270-full-macos.py','audit-source270-macos-rust-names.py','verify-source270-macos-rust.py',
    'audit-source270-macos-gnu-inputs.py','retain-source270-linux.py','audit-source270-linux-rust-names.py',
    'verify-source270-linux-rust.py','dispatch-source270-linux.py',
    'source270-macos-rust-audit-preparation.json','source270-linux-retention-preparation.json',
    'package-source196-failure-and197-results.py',Path(__file__).name,
}
for file in p.iterdir():
    if file.is_file() and file.suffix in allowed and file.name.startswith('source270-linux-rust-'):
        files[file.name]=file
for name in helpers:
    assert (p/name).is_file(),name
    files[name]=p/name
package('source270-complete-rust-platforms',files,dict(
    macos=macos,linux=linux,macos_gnu=read('source270-macos-rust-oracle-audit.json'),linux_gnu=read('source270-linux-rust-oracle-audit.json'),
    qualification='Exact source270 commit0ecf6e11 passes complete Rust validation on both platforms: macOS3118/Linux3130 passes, with two existing ignores each. All3021/3029 library names, native artifact identity, every retained Rust/GNU input and all510 source inputs are verified. Frozen and terminal validations are separate and still active. The independently confirmed off-stack string-borrow property-root failure remains failed evidence in source271; source272 is its separate repair under selected validation. No universal correctness, performance, memory, public-ownership or goal completion is inferred.'))
