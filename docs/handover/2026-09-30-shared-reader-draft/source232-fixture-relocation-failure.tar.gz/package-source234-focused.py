from pathlib import Path
import ast
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).parent.resolve()
out = p.parents[2] / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
audit = json.loads((p / 'source234-focused-audit.json').read_text())
assert audit['passed'] == 37 and audit['failed'] == 0
names = ['source234-focused-audit.json', 'audit-source234-focused.py',
         'source234-manifest.json', 'source234-gate-controls-command.json',
         'source234-gate-controls-result.json', 'source234-gate-controls.log',
         'source234-gate-inventory.txt', 'source234-gate-build-command.json',
         'source234-gate-build-result.json', 'source234-gate-build.log',
         'source234-full-gate-launch.json', 'run-source234-full-gate.py',
         'run-source234-release-and-ordinary.py', 'run-source234-ordinary.py',
         'test-source234-broad.py', 'build-source234.py', 'compare-source230-fixtures.py',
         'audit-shared-reader196-fresh-selected.py', Path(__file__).name]
package('source234-focused-validation', {name: p / name for name in names}, audit)

audit = json.loads((p / 'source232-full-gate-relocation-failure-audit.json').read_text())
assert audit['library_passed'] == 232 and audit['library_failed'] == 154
names = ['source232-full-gate-relocation-failure-audit.json', 'source232-full-gate-command.json',
         'source232-full-gate-result.json', 'source232-full-gate.log', 'source232-full-gate-launch.json',
         'source232-full-gate-driver.log', 'run-source232-full-gate.py', 'source232-manifest.json',
         'source232-full-gate-fresh-launch.json', 'run-source232-full-gate-fresh.py', Path(__file__).name]
files = {name: p / name for name in names}
files.update({str(file.relative_to(p)): file for file in (p / 'full-gate-source232').rglob('*') if file.is_file()})
package('source232-fixture-relocation-failure', files, audit)
