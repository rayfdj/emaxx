from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import time

root = Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/string-ops/emaxx')
out = Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28')
manifest = json.loads((out / 'source232-manifest.json').read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def unchanged():
    return all(sha(root / name) == digest for name, digest in manifest.items())


def save(name, data):
    with (out / name).open('x') as stream:
        json.dump(data, stream, indent=2)
        stream.write('\n')


assert unchanged()
audit = json.loads((out / 'source232-selected-audit.json').read_text())
assert audit['status'] == 'selected gate and release validation passes'
assert len(audit['groups']) == 4 and all(group['failed'] == 0 for group in audit['groups'])
assert (out / 'source232-complete.patch').is_file()
env = os.environ.copy()
overrides = {
    'CARGO_TARGET_DIR': str((root / 'target/frame-validation').resolve()),
    'CARGO_BUILD_JOBS': '1', 'EMAXX_GC_VERIFY': '1', 'LANG': 'C', 'LC_ALL': 'C',
    'EMAXX_GNU_SOURCE_DIRECTORY': '/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/emacs',
    'EMAXX_DUMP_SOURCE_DIRECTORY': '/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/emacs',
    'EMACS_TEST_DIRECTORY': '/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/emacs/test',
}
env.update(overrides)
artifact = out / 'full-gate-source232'
command = ['python3', 'tools/serial_grouped_gate.py', '--scope', 'full',
           '--artifact-root', str(artifact)]
save('source232-full-gate-command.json', {
    'command': command, 'working_directory': str(root),
    'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'source_manifest': 'source232-manifest.json',
    'environment_override': overrides,
    'qualification': 'Complete unchanged macOS grouped gate for source232. The three changed files repair stale bytecode-root metadata, the reader closure-kind assertion and allocation-independent bitmap-word coverage; all original semantic assertions remain. All 31 focused controls and the original complete lightweight selectors pass in both profiles (545 gate and 544 release). Exact 440-input manifest and patch identify this candidate over main. Linux source231 has separately failed in eval_05 and the edebug frozen fixture; those failures are not repaired or relabeled by this launch. Socket permissions enabled. No pinned compatibility or performance certification.'
})
start = time.monotonic()
with (out / 'source232-full-gate.log').open('x') as log:
    completed = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
result = {'exit_code': completed.returncode, 'elapsed_seconds': time.monotonic() - start,
          'source_unchanged': unchanged()}
summary_path = artifact / 'summary.json'
if summary_path.exists():
    summary = json.loads(summary_path.read_text())
    result['summary'] = summary
    binary = summary.get('test_binary')
    if binary:
        if isinstance(binary, dict):
            binary = binary.get('path')
        if binary and Path(binary).is_file():
            saved = out / 'source232-full-gate-libtest'
            assert not saved.exists()
            shutil.copy2(binary, saved)
            result['immutable_binary'] = {'path': str(saved), 'sha256': sha(saved)}
save('source232-full-gate-result.json', result)
print(json.dumps({k: v for k, v in result.items() if k != 'summary'}), flush=True)
raise SystemExit(0 if completed.returncode == 0 and result['source_unchanged'] else 1)
