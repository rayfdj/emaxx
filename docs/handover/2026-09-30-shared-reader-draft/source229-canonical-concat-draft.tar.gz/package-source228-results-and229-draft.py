from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile
p=Path(__file__).parent.resolve();root=p.parents[2]
out=root/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda name:json.loads((p/name).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
allowed={'.json','.log','.txt','.py','.patch','.stdout','.stderr','.el','.expected'}
audit=read('source228-results-audit.json')
assert [(g['passed'],g['failed']) for g in audit['groups']]==[(24,1),(932,1)]
for file in audit['retained_files']:
    assert sha(Path(file['retained']).read_bytes())==file['sha256']
files={f.name:f for f in p.iterdir() if f.is_file() and f.suffix in allowed and f.name.startswith('source228-')}
helpers=['audit-source228-results.py','run-string-validation228.py','test-string-controls228.py','test-string-broad219.py','check-string217.py','static-string217.py','audit-shared-reader196-fresh-selected.py',Path(__file__).name]
files.update({name:p/name for name in helpers})
package('source228-completion-results',files,audit)
manifest=read('source229-manifest.json')
candidate=p.parent/'recovered-2026-09-30/string-bytes/emaxx'
assert len(manifest)==432 and all(sha((candidate/name).read_bytes())==digest for name,digest in manifest.items())
for stage in ['check','fmt','clippy','diff','gate-build','gate-controls']:
    result=read('source229-'+stage+'-result.json')
    assert result['exit_code']==0 and result['source_unchanged']
names=['source229-base.json','source229-manifest.json','source229-complete.patch','source229-launch.json','source229-release-launch.json','source229-ordinary-launch.json','source229-patch-replay-and-modes-audit.json','source229-gate-inventory.txt',
       'audit-source229-patches.py','run-string-validation229.py','test-string-controls229.py','test-string-broad219.py','check-string217.py','static-string217.py','run-source229-release.py','build-string225.py','run-source229-build-and-ordinary.py','run-source229-ordinary.py','compare-source229-fixtures.py','canonical-concat-storage.el',Path(__file__).name]
for stage in ['check','fmt','clippy','diff','gate-build','gate-controls']:
    names += ['source229-'+stage+suffix for suffix in ['-command.json','-result.json','.log']]
files={name:p/name for name in names}
files.update({f.name:f for f in p.glob('canonical-concat-storage-gnu.*')})
package('source229-canonical-concat-draft',files,dict(status='strict checks and all 26 focused gate controls pass; broader, release and ordinary validation running',source_inputs=432,
    focused_result=read('source229-gate-controls-result.json'),
    supervisors={name:read('source229-'+name+'launch.json')['pid'] for name in ['', 'release-', 'ordinary-']},
    qualification='Following fns.c concat_to_string, canonical strings copy actual encoded bytes and validate list/vector characters over the full GNU range. The original completion character-loss assertion and a new mixed-encoding/property/sequence/GC fixture pass. Patch and modes replay exactly; no full, release, Linux, pinned compatibility or performance certification is assigned. Source228 failures and full source225 aborts remain preserved. Active-stage logs and images are excluded.'))
