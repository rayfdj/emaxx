from pathlib import Path
import hashlib, json, subprocess, time
p=Path(__file__).parent.resolve()
control=json.loads((p/'source229-gate-controls-result.json').read_text())
assert control['exit_code']==0 and control['source_unchanged']
commands=[['python3',str(p/'build-string225.py'),'229'], ['python3',str(p/'run-source229-ordinary.py')]]
results=[]
for command in commands:
    print('START',command,flush=True)
    start=time.monotonic()
    run=subprocess.run(command,stdin=subprocess.DEVNULL)
    record=dict(command=command,exit_code=run.returncode,elapsed_seconds=time.monotonic()-start)
    results.append(record);print('END',record,flush=True)
    if run.returncode:break
with (p/'source229-ordinary-driver-result.json').open('x') as f:json.dump(results,f,indent=2)
raise SystemExit(next((entry['exit_code'] for entry in results if entry['exit_code']),0))
