from pathlib import Path
import hashlib,json
p=Path(__file__).parent;c=p.parent/'recovered-2026-10-06/native-subr-callbacks/emaxx'
f=c/'src/lisp/eval/tests/eval_05.rs';s=f.read_text();marker='\n// Temporary diagnostic only; removed before the validated candidate is frozen.';assert s.count(marker)==1;f.write_text(s[:s.index(marker)])
f=c/'src/lisp/primitives/tests.rs';s=f.read_text();old='#[test]\nfn native_subr_authority_preserves_gnu_metadata_calls_and_identity()';new='''#[test]
fn native_subr_consumers_preserve_commands_completion_properties_and_substitution() {
    assert_oracle_contract_matches_interpreter(
        include_str!("../../../tests/fixtures/native-subr-consumers.el"),
        include_str!("../../../tests/fixtures/native-subr-consumers.expected").trim(),
        "native command recognition, direct completion tables, property identity and reader substitution",
    );
}

'''+old;assert s.count(old)==1;f.write_text(s.replace(old,new))
s=(p/'run-native-subr-development308.py').read_text().replace('development1','development3');s=s.replace("m={n:sha(c/n) for n in json.loads((p/'source307-manifest.json').read_text())}","m={n:sha(c/n) for n in sorted(set(json.loads((p/'source307-manifest.json').read_text()))|{'tests/fixtures/native-subr-consumers.el','tests/fixtures/native-subr-consumers.expected'})}")
s=s.replace(" assert not target.exists();target.parent.mkdir(exist_ok=True)\n assert run('cache',['/bin/cp','-cR',str(p.parent/'recovered-2026-10-06/native-subr-names/emaxx/target/vm-dispatch-validation'),str(target)])==0\n", " assert target.is_dir()\n")
s=s.replace("command+=['lisp::eval::tests::eval_05::dabbrev_cross_buffer_cases_remain_order_independent_in_native_runner']", "command+=['lisp::eval::tests::eval_05::dabbrev_cross_buffer_cases_remain_order_independent_in_native_runner','lisp::primitives::tests::native_subr_consumers_preserve_commands_completion_properties_and_substitution']")
(p/'run-native-subr-development3.py').open('x').write(s)
print('Permanent differential consumer test added; temporary diagnostic removed')
