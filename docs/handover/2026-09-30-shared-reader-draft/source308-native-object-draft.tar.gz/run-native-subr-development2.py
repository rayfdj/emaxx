from pathlib import Path
import hashlib,json,os,subprocess,time,shutil
p=Path(__file__).parent.resolve();c=p.parent/'recovered-2026-10-06/native-subr-callbacks/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
m={n:sha(c/n) for n in json.loads((p/'source307-manifest.json').read_text())}
(p/'source308-development2-manifest.json').open('x').write(json.dumps(m,indent=2))
target=c/'target/native-subr-development'
env=json.loads((p/'source307-gate-focused-command.json').read_text())['environment_overrides'];env['CARGO_TARGET_DIR']=str(target);env['EMAXX_FIXTURE_IMAGE_DIR']=str(p/'fixture-images-source308-development2');env['EMAXX_DIAGNOSTIC_FORMS']=str(p/'native-subr-dabbrev-trace.el')
state=dict(status='starting development diagnosis only',candidate=str(c),manifest='source308-development2-manifest.json',results=[],goal_complete=False)
def save(): (p/'source308-development2-state.json').write_text(json.dumps(state,indent=2))
def run(name,command):
 assert all(sha(c/n)==h for n,h in m.items());state['status']='running '+name;save()
 (p/('source308-development2-'+name+'-command.json')).open('x').write(json.dumps(dict(command=command,cwd=str(c),environment_overrides=env),indent=2))
 start=time.monotonic()
 with (p/('source308-development2-'+name+'.log')).open('xb') as f:r=subprocess.run(command,cwd=c,env={**os.environ,**env},stdout=f,stderr=subprocess.STDOUT,timeout=1800)
 d=dict(stage=name,exit_code=r.returncode,elapsed_seconds=time.monotonic()-start,source_unchanged=all(sha(c/n)==h for n,h in m.items()));state['results'].append(d);save();print(json.dumps(d),flush=True);return r.returncode
try:
 assert target.is_dir()
 assert run('build',['cargo','test','--locked','--profile','gate','--all-features','--lib','--no-run','--message-format=json'])==0
 messages=[json.loads(l) for l in (p/'source308-development2-build.log').read_text().splitlines() if l.startswith('{')]
 bs=[Path(d['executable']) for d in messages if d.get('reason')=='compiler-artifact' and d.get('executable') and d.get('profile',{}).get('test') and d['target']['name']=='emaxx'];assert len(bs)==1
 b=bs[0];state['binary']=str(b);state['binary_sha256']=sha(b)
 command=[str(b),'--exact','--test-threads=1','--nocapture','lisp::eval::tests::eval_05::native_subr_dabbrev_diagnostic_trace']
 run('trace',command)
 state['status']='development diagnosis closed; raw results require audit, no full validation claim'
except Exception as error:state.update(status='development diagnosis stopped',error=repr(error))
finally:
 save();(p/'source308-development2-result.json').open('x').write(json.dumps(state,indent=2))
