from pathlib import Path
import hashlib,json,tarfile
p=Path(__file__).parent;c=p.parent/'recovered-2026-10-06/native-subr-callbacks/emaxx';m=json.loads((p/'source308-development2-manifest.json').read_text());sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();assert all(sha(c/n)==h for n,h in m.items())
a=p/'source308-development2-source.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for n in sorted(m):t.add(c/n,arcname=n,recursive=False)
(p/'source308-development2-snapshot.json').open('x').write(json.dumps(dict(archive=a.name,sha256=sha(a),manifest='source308-development2-manifest.json',qualification='Temporary diagnostic test, not a validation pass; actual native commandp returned nil and caused isearch exit after first character.'),indent=2))
def replace(n,a,b):
 f=c/n;s=f.read_text();assert s.count(a)==1,(n,s.count(a));f.write_text(s.replace(a,b))
replace('src/lisp/primitives/dispatch/predicates.rs','''                    Kind::Cons(_) => {
                        if autoload_parts(&function).is_some() {''','''                    Kind::NativeFunction(function) => {
                        // eval.c:Fcommandp tests the actual subr interactive field.
                        if function.interactive().is_truthy() {
                            return Ok(Value::T);
                        }
                    }
                    Kind::Cons(_) => {
                        if autoload_parts(&function).is_some() {''')
replace('src/lisp/primitives/completion.rs','''        (Kind::BuiltinFunc(a), Kind::BuiltinFunc(b)) => a == b,
''','''        (Kind::BuiltinFunc(a), Kind::BuiltinFunc(b)) => a == b,
        (Kind::NativeFunction(a), Kind::NativeFunction(b)) => a.ptr_eq(&b),
''')
replace('src/lisp/primitives/completion.rs','''        Kind::Symbol(_) | Kind::Closure(_) | Kind::BuiltinFunc(_) => true,
''','''        Kind::Symbol(_) | Kind::Closure(_) | Kind::BuiltinFunc(_) | Kind::NativeFunction(_) => true,
''')
replace('src/buffer.rs','''        (Kind::BuiltinFunc(left), Kind::BuiltinFunc(right)) => left == right,
''','''        (Kind::BuiltinFunc(left), Kind::BuiltinFunc(right)) => left == right,
        (Kind::NativeFunction(left), Kind::NativeFunction(right)) => left.ptr_eq(&right),
''')
print('Four native function consumers repaired; original tests unchanged')
