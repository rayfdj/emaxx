from pathlib import Path
import ast,hashlib,json,shutil,subprocess
p=Path(__file__).parent.resolve();root=p.parents[2]
old=p.parent/'recovered-2026-10-06/native-subr-names/emaxx';c=p.parent/'recovered-2026-10-06/native-subr-callbacks/emaxx';g=p.parent/'rebuilt-2026-10-01/emacs'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
m=json.loads((p/'source307-manifest.json').read_text());assert len(m)==539 and all(sha(old/n)==h for n,h in m.items())
assert json.loads((p/'source307-validation-result.json').read_text())['status']=='validation stopped'
assert not c.exists();c.parent.mkdir();(c.parent/'emacs').symlink_to(g,target_is_directory=True)
for cmd in [['git','clone','--shared','--quiet','--no-checkout',str(root),str(c)],['git','-C',str(c),'sparse-checkout','init','--no-cone'],['git','-C',str(c),'sparse-checkout','set','--no-cone',*sorted({'/'+n for n in m}|{'/tools/','/compat/'})],['git','-C',str(c),'checkout','--detach','2b561470516c519f2198d2551c7b85b474defcfc']]:subprocess.run(cmd,check=True)
for n in m:(c/n).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(old/n,c/n)
def replace(f,a,b):
 s=f.read_text();assert s.count(a)==1,(f,a,s.count(a));f.write_text(s.replace(a,b))
f=c/'src/lisp/primitives/print/output.rs'
replace(f,'    multibyte: bool,\n}', '''    multibyte: bool,
    // strout's C char -> int -> unsigned printchar conversion can pass
    // values outside the Lisp character range to a function stream. These
    // sparse callback arguments are not encoded into Lisp string storage.
    function_codes: Vec<(usize, u32)>,
}''')
replace(f,'            multibyte: false,\n', '            multibyte: false,\n            function_codes: Vec::new(),\n')
# The From<String> initializer has different indentation.
replace(f,'                multibyte: false,\n', '                multibyte: false,\n                function_codes: Vec::new(),\n')
replace(f,'''    pub(crate) fn append(&mut self, other: &Self) {
        self.multibyte |= other.multibyte;
        self.bytes.extend_from_slice(other.bytes());
    }''','''    pub(crate) fn push_c_function_byte(&mut self, byte: u8) {
        let argument = byte as std::ffi::c_char as i32 as u32;
        if argument != u32::from(byte) {
            self.function_codes.push((self.bytes.len(), argument));
        }
        self.push_code(u32::from(byte));
    }

    pub(crate) fn append(&mut self, other: &Self) {
        self.multibyte |= other.multibyte;
        self.function_codes.extend(other.function_codes.iter().map(|(offset, code)| {
            (self.bytes.len() + offset, *code)
        }));
        self.bytes.extend_from_slice(other.bytes());
    }''')
replace(f,'''        let mut remaining = self.bytes();
        std::iter::from_fn(move || {''','''        let mut remaining = self.bytes();
        let mut function_codes = self.function_codes.iter().peekable();
        std::iter::from_fn(move || {''')
replace(f,'''            let (code, width) = decode_character(remaining).expect("canonical printer output");
            remaining = &remaining[width..];
            Some(code)''','''            let offset = self.bytes.len() - remaining.len();
            let (code, width) = decode_character(remaining).expect("canonical printer output");
            remaining = &remaining[width..];
            Some(if function_codes.peek().is_some_and(|(at, _)| *at == offset) {
                function_codes.next().expect("matching C byte position").1
            } else {
                code
            })''')
f=c/'src/lisp/primitives/print.rs';replace(f,'rendered.push_code(u32::from(byte));','rendered.push_c_function_byte(byte);')
subprocess.run(['cargo','fmt','--all'],cwd=c,check=True)
assert [n for n,h in m.items() if sha(c/n)!=h]==['src/lisp/primitives/print.rs','src/lisp/primitives/print/output.rs']
s=(p/'run-source307-validation.py').read_text().replace('source307','source308').replace('native-subr-names/emaxx','native-subr-callbacks/emaxx')
s=s.replace("base = read(p / 'source306-manifest.json')", "base = read(p / 'source307-manifest.json')")
a="assert changes == ['src/lisp/native_comp/loader.rs', 'src/lisp/primitives/print.rs', 'src/lisp/primitives/print/output.rs', 'src/lisp/primitives/tests.rs', 'tests/fixtures/native-subr-c-names.el', 'tests/fixtures/native-subr-c-names.expected'], changes"
assert s.count(a)==1;s=s.replace(a,"assert changes == ['src/lisp/primitives/print.rs', 'src/lisp/primitives/print/output.rs'], changes")
s=s.replace('recovered-2026-10-06/native-subr-objects/emaxx/target/vm-dispatch-validation','recovered-2026-10-06/native-subr-names/emaxx/target/vm-dispatch-validation')
ast.parse(s);(p/'run-source308-validation.py').open('x').write(s)
s=(p/'replay-native-subr307.py').read_text().replace('Source307 carries', 'Source308 additionally preserves the configured C-char sign conversion for function printer streams, keeping those callback arguments separate from valid encoded Lisp text. Source307 remains a4-pass/1-failure draft. This carries')
ast.parse(s);(p/'replay-native-subr308.py').open('x').write(s)
record=dict(status='unvalidated callback-only successor of failed307',candidate=str(c),base='2b561470516c519f2198d2551c7b85b474defcfc',changed_from307=['src/lisp/primitives/print.rs','src/lisp/primitives/print/output.rs'],authority='GNU print.c:strout promotes signed C char to int; printchar unsigned ch reaches the Lisp callback as4294967246/4294967227 for UTF-8 bytesCE/BB on this target. Actual GNU307 fixture and failed307 Rust output retain exactly this difference. No result normalization or expectation change.',rust_constraint='The existing transient printer uses valid internal character bytes and cannot encode those out-of-character-range C callback integers. Sparse offset/argument entries preserve actual callback values through composed output; ordinary printing adds no heap allocation for the empty vector, but its larger temporary struct and append/decode checks still need measurement. This is not a Lisp-object mirror or persistent registry.',goal_complete=False)
(p/'source308-working-init.json').open('x').write(json.dumps(record,indent=2));print(c)
