from pathlib import Path
import ast,difflib,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve();out=p.parents[2]/'docs/handover/2026-09-30-shared-reader-draft';sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda n:json.loads((p/n).read_text());c=p.parent/'recovered-2026-10-06/native-subr-callbacks/emaxx';m=read('source308-manifest.json');assert len(m)==541 and all(sha((c/n).read_bytes())==h for n,h in m.items())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package');exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
previous=p.parent/'recovered-2026-10-06/native-subr-names/emaxx';base=read('source307-manifest.json');snapshots={}
for number in [1,2]:
 manifest=read(f'source308-development{number}-manifest.json')
 with tarfile.open(p/f'source308-development{number}-source.tar.gz','r:gz') as t:
  data={n:t.extractfile(n).read() for n in manifest};assert all(sha(data[n])==h for n,h in manifest.items())
 old={n:(previous/n).read_bytes() for n in base} if number==1 else snapshots[number-1]
 assert set(old)==set(data);patch='';changed=[]
 for n in sorted(data):
  if data[n]!=old[n]:
   changed.append(n);patch+='diff --git a/'+n+' b/'+n+'\n';patch+=''.join(difflib.unified_diff(old[n].decode().splitlines(keepends=True),data[n].decode().splitlines(keepends=True),fromfile='a/'+n,tofile='b/'+n))
 (p/f'source308-development{number}-incremental.patch').open('x').write(patch);snapshots[number]=data
 print('Development',number,'delta:',changed)
state=read('source308-development3-result.json');assert all(r['exit_code']==0 and r['source_unchanged'] for r in state['results']);assert read('source308-development3-manifest.json')==m
assert 'test result: ok. 7 passed; 0 failed; 0 ignored;' in (p/'source308-development3-focused-and-dabbrev.log').read_text()
allowed={'.json','.log','.txt','.py','.patch','.stdout','.stderr','.el','.expected'}
# Only closed evidence. Ongoing formal validation and its state/log files are
# deliberately absent; its eventual results require a separate closed audit.
prefixes=('source308-development','source308-portable','source308-preparation','source308-consumers','source308-gnu-consumers','native-subr-dabbrev-gnu-trace.')
files={f.name:f for f in p.iterdir() if f.is_file() and f.suffix in allowed and f.name.startswith(prefixes)}
for n in ['source308-manifest.json','source308-draft.patch','source308-working-init.json','source307-manifest.json','source307-portable-complete.patch','source307-portable-incremental.patch','source307-portable-draft-audit.json','native-subr-dabbrev-trace.el','native-subr-dabbrev-real-location-comparison.json','source304-dabbrev-native-object-real-location.log','source306-dabbrev-native-object-real-location.log','prepare-native-subr-callbacks308.py','prepare-native-subr-callbacks308-fixed.py','run-native-subr-development308.py','run-native-subr-development2.py','run-native-subr-development3.py','prepare-native-subr-development2.py','prepare-native-subr-development3.py','repair-native-subr-consumers308.py','probe-native-subr-consumers308.py','probe-native-subr-consumers308-reviewed.py','replay-native-subr308.py','native_fixed_validation_support.py','package-source196-failure-and197-results.py',Path(__file__).name]:files[n]=p/n
package('source308-native-object-draft',files,dict(status='portable unapplied native-object draft; formal validation in progress',source_inputs=541,development_tests=dict(passed=7,failed=0,ignored=0),portable=read('source308-portable-draft-audit.json'),goal_complete=False,qualification='The development control closes the unchanged dabbrev regression and passes6 focused storage/GC/ABI/actual-GNU controls. Its failed predecessors remain preserved. Source308 fixes command recognition and native function identity in text properties and reader substitution, and C-name byte callbacks. No original frozen fixture, expected outcome or audit deviation changed. The temporary diagnostic test was removed. This archive certifies portable code and the closed development run only, not the ongoing gate/release selection, ordinary comparisons, platform validation or performance. Development1 reconstructs by applying its delta after the complete307 patch; development2 adds the trace-test delta. Their complete manifests identify every input.'))
