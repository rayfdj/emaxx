from pathlib import Path
import json,hashlib,shutil,subprocess
p=Path(__file__).parent;c=p.parent/'recovered-2026-10-06/native-subr-callbacks/emaxx';m=json.loads((p/'source308-development1-manifest.json').read_text());sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
assert all(sha(c/n)==h for n,h in m.items())
s=json.loads((p/'source308-development1-result.json').read_text());b=Path(s['binary']);assert sha(b)==s['binary_sha256']
r=p/'source308-development1-retained';r.mkdir();shutil.copy2(b,r/b.name)
for n in ['src/lisp/primitives/print.rs','src/lisp/primitives/print/output.rs']:shutil.copy2(c/n,r/Path(n).name)
f=c/'src/lisp/eval/tests/eval_05.rs';f.write_text(f.read_text()+'''
// Temporary diagnostic only; removed before the validated candidate is frozen.
#[test]
fn native_subr_dabbrev_diagnostic_trace() {
    run_with_large_stack(|| {
        let mut interp = upstream_lisp_test_interpreter("dabbrev-tests.el");
        let file = std::env::var("EMAXX_DIAGNOSTIC_FORMS").expect("diagnostic forms file");
        let forms = std::fs::read_to_string(file).expect("diagnostic forms");
        eprintln!("DIAGNOSTIC {:?}", eval_str_with(&mut interp, &forms));
    });
}
''')
print('Temporary diagnostic test added; all original controls unchanged')
