from pathlib import Path
import hashlib, json, re, subprocess, sys
from native_fixed_validation_support import audit_selected

p = Path(__file__).parent.resolve()
root = p.parents[2]
tag, directory = sys.argv[1:]
c = Path(directory)
assert tag == 'source303'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read(tag + '-manifest.json')
prior_manifest = read('source302-manifest.json')
assert len(manifest) == 534 and all(sha(c / name) == digest for name, digest in manifest.items())
assert all(manifest[name] == digest for name, digest in prior_manifest.items() if name.startswith('tests/'))
assert [n for n,h in manifest.items() if prior_manifest.get(n)!=h] == ['src/lisp/primitives/buffers.rs', 'src/lisp/primitives/tests.rs']
prior_tests = (p.parent / 'recovered-2026-10-05/native-binary-arithmetic/emaxx/src/lisp/primitives/tests.rs').read_bytes()
current_tests = (c / 'src/lisp/primitives/tests.rs').read_bytes()
assert current_tests.startswith(prior_tests) and current_tests[len(prior_tests):].count(b'#[test]') == 1
new_column_test = 'lisp::primitives::tests::buffer_display_columns_match_gnu_original_line_motion_probe'
state = read(tag + '-validation-result.json')
assert len(state['results']) == 16
assert all(row['exit_code'] == 0 and not row['timed_out'] and row['source_unchanged'] for row in state['results'])
if tag == 'source303':
    for build_profile in ('gate', 'release', 'ordinary'):
        records = [json.loads(line) for line in (p / (tag+'-'+build_profile+'-build.log')).read_text().splitlines() if line.startswith('{')]
        artifact = [a for a in records if a.get('reason') == 'compiler-artifact' and a['target']['name'] == 'emaxx']
        assert artifact and all(a['fresh'] is False for a in artifact)
    for build_profile in ('gate', 'release'):
        assert sha(p / (tag+'-'+build_profile+'-libtest')) != sha(p / ('source302-'+build_profile+'-libtest'))
profiles = {}
new_test = 'lisp::native_comp::runtime::tests::native_many_empty_and_negative_list_counts_accept_null_storage'
selector = r'byte_?code|threads_retain_lexical_caller_roots|native_comp::runtime::|native.*(?:arity|calling|unwind|handler|argument)|numeric|arithmetic|remainder|modulo|bignum|float|integer|fixnum|lisp::types::|lisp::alloc::|buffer_line_indexes_preserve_gnu_lf_motion_narrowing_and_edits|^buffer::|column|indent|line|narrow|invisib|buffer.*(?:edit|multibyte)'
for profile in ('gate', 'release'):
    record = state['profiles'][profile]
    assert record['passed'] == 482 and record['passed'] + record['ignored'] == len(record['selectors']) and record['failed'] == record['ignored'] == 0
    inventory = [line[:-6] for line in (p / (tag + '-' + profile + '-inventory.log')).read_text().splitlines() if line.endswith(': test')]
    prior = [line[:-6] for line in (p / ('source302-' + profile + '-inventory.log')).read_text().splitlines() if line.endswith(': test')]
    assert len(inventory) == len(set(inventory)) and set(inventory) == set(prior) | {new_column_test}
    names = [name for name in inventory if re.search(selector, name)]
    assert names == record['selectors'] and new_column_test in names
    raw = (p / (tag + '-' + profile + '-selected.log')).read_text()
    counts = audit_selected(raw, names)
    assert all(record[k] == v for k,v in counts.items())
    assert sha(Path(record['binary'])) == sha(Path(record['retained_binary'])) == record['binary_sha256']
    for item in record['retained_inputs']:
        assert sha(Path(item['original'])) == sha(Path(item['retained'])) == item['sha256']
    profiles[profile] = record

ordinary = {}
names = list(read('source302-selected-audit.json')['ordinary_results']) + ['buffer-lf-line-index']
assert len(names) == 48
for name in names:
    comparison = read(tag + '-ordinary-' + name + '-comparison.json')
    assert comparison['passed'] and comparison['exact_match']
    outputs, programs = [], []
    for editor in ('gnu', 'emaxx'):
        stem = tag + '-ordinary-' + name + '-' + editor
        command, result = read(stem + '.command.json'), read(stem + '.result.json')
        assert all(sha(Path(path)) == digest for path, digest in command['inputs'].items())
        assert result == comparison['outcomes'][editor]
        assert result['exit_code'] == 0 and not result['timed_out'] and result['source_unchanged'] and result['inputs_unchanged']
        out, err = (p / (stem + '.stdout')).read_bytes(), (p / (stem + '.stderr')).read_bytes()
        assert out and not err and hashlib.sha256(out).hexdigest() == result['stdout_sha256'] and err.hex() == result['stderr_hex']
        assert result['expected_output'] is not False
        if name not in ('bytecode-integer-boundaries', 'buffer-lf-line-motion', 'native-binary-arithmetic', 'buffer-lf-line-index'):
            assert out == (p / ('source302-ordinary-' + name + '-' + editor + '.stdout')).read_bytes()
        else:
            assert out == (c / ('tests/fixtures/' + name + '.expected')).read_bytes().rstrip(b'\n')
        outputs.append(out)
        programs.append(command['command'][-1])
    assert outputs[0] == outputs[1] and programs[0] == programs[1]
    ordinary[name] = dict(passed=True, stdout_sha256=hashlib.sha256(outputs[0]).hexdigest(), stdout_bytes=len(outputs[0]))
assert read(tag + '-generated-loaded-comparison.json')['passed']
for editor in ('gnu', 'emaxx'):
    stem = tag + '-generated-loaded-' + editor
    command, result = read(stem + '-command.json'), read(stem + '-result.json')
    assert all(sha(Path(path)) == digest for path, digest in command['inputs'].items())
    assert result['exit_code'] == 0 and not result['timed_out'] and result['source_unchanged'] and result['inputs_unchanged']
    assert command['command'][-2:] == ['-l', str(p / 'printer-varied-v3-293638f0.el')]
    out = (p / (stem + '.stdout')).read_bytes()
    assert len(out) == 4088269 and len(out.splitlines()) == 198
    assert out == (p / 'printer-varied-v3-gnu.stdout').read_bytes() and not (p / (stem + '.stderr')).read_bytes()
artifacts = read(tag + '-ordinary-artifacts.json')
assert all(sha(Path(path)) == sha(Path(row['immutable_copy'])) == row['sha256'] for path, row in artifacts.items())
for stage in ('fmt', 'check', 'clippy', 'diff', 'ordinary-build', 'gate-build', 'release-build'):
    raw = (p / (tag + '-' + stage + '.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
    for line in raw.splitlines():
        if line.startswith('{'):
            assert json.loads(line).get('message', {}).get('level') not in ('warning', 'error')
portable = read(tag + '-portable-draft-audit.json')
assert len(portable['patches']) == 2
for row in portable['patches']:
    assert row['inputs'] == 534 and row['bytes_and_modes'] == 'exact' and sha(p / row['patch']) == row['sha256']
evidence = {str(path): sha(path) for path in p.glob(tag + '-*') if path.is_file() and path.suffix in ('.json', '.log', '.stdout', '.stderr', '.patch')}
record = dict(status='passed', source_inputs_verified=534, profiles=profiles,
              ordinary_comparisons=49, ordinary_results=ordinary,
              generated_rows=198, generated_bytes=4088269,
              ordinary_artifacts=artifacts, portable_replays=portable['patches'], evidence_files=evidence,
              qualification='Source303 repairs ordinary buffer character widths using GNU rules and the live width table.534 exact input bytes/modes, fresh builds, zero-warning strict checks,482 selected passes/profile and49 actual GNU comparisons verify. All original tests/fixtures remain. The original338-row probe now matches actual GNU, closing its60 prior column failures without changing any expected byte. Broader display semantics, counters, ownership and final architecture/performance remain open.', goal_complete=False)
baseline_broad = read('source302-line-broad-diagnosis.json')
assert baseline_broad['exact_match'] is False and baseline_broad['rows'] == 338 and baseline_broad['different_rows'] == 60
baseline_gnu = p / 'source302-line-broad-gnu.stdout'
baseline_emaxx = p / 'source302-line-broad-emaxx.stdout'
assert sha(baseline_gnu) == baseline_broad['outcomes']['gnu']['stdout_sha256']
assert sha(baseline_emaxx) == baseline_broad['outcomes']['emaxx']['stdout_sha256']
repaired_output = (p / (tag + '-ordinary-buffer-lf-line-index-emaxx.stdout')).read_bytes()
assert repaired_output == baseline_gnu.read_bytes() and repaired_output != baseline_emaxx.read_bytes()
import ast
parser = next(n for n in ast.parse((p / 'compare-buffer-line-broad-probe.py').read_text()).body
              if isinstance(n, ast.FunctionDef) and n.name == 'parse')
exec(compile(ast.Module(body=[parser], type_ignores=[]), '<existing-full-probe-parser>', 'exec'))
parsed = parse(repaired_output.decode())
assert parsed[0] == len(parsed[1]) == 338 and all(len(row) == 13 for row in parsed[1])
record['closed_broad_probe_failure'] = dict(status='all338 original rows now match GNU', rows=338,
    different_rows=0, original_failing_rows=60,
    baseline_diagnosis_sha256=sha(p / 'source302-line-broad-diagnosis.json'),
    baseline_gnu_sha256=sha(baseline_gnu), baseline_emaxx_sha256=sha(baseline_emaxx),
    repaired_output_sha256=hashlib.sha256(repaired_output).hexdigest(),
    qualification='Original fixture and expected bytes unchanged. Actual ordinary GNU and candidate outputs are identical. The preserved302 negative retains its60 original column mismatches; no broader display correctness claim.')

with (p / (tag + '-selected-audit.json')).open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps(dict(status='passed', source=tag, profiles={k: r['passed'] for k, r in profiles.items()}, ordinary_comparisons=49, source_inputs=534)))
