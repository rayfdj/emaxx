from pathlib import Path
import ast, re

p = Path(__file__).parent.resolve()
pending = {}

def write(name, source):
    ast.parse(source)
    assert name not in pending and not (p / name).exists()
    pending[name] = source

def translate(source):
    tags = {'source297': 'source302', 'source302': 'source303'}
    return re.sub(r'source(?:297|302)', lambda m: tags[m[0]], source)

source = translate((p / 'measure-native-arithmetic.py').read_text())
paths = {'native-funcall-dispatch/emaxx': 'native-binary-arithmetic/emaxx',
         'native-binary-arithmetic/emaxx': 'buffer-display-columns/emaxx'}
source = re.sub('|'.join(re.escape(n) for n in paths), lambda m: paths[m[0]], source)
source = source.replace('native-arithmetic', 'buffer-columns')
old = next(n.value for n in ast.walk(ast.parse(source)) if isinstance(n, ast.Constant)
           and isinstance(n.value, str) and n.value.startswith('Three alternating repetitions'))
source = source.replace(repr(old), repr('Three alternating unchanged full16 pilots,192 ordinary processes, original302 and corrected303. The original60 column failures remain with302;303 must pass the unchanged338-row GNU probe before measuring the cost of restoring character widths. Every sample and unfavorable case remains. No build/test/profile work overlaps timing. This is not final calibrated nine-round/every-case3% acceptance.'))
write('measure-buffer-columns.py', source)
source = translate((p / 'audit-native-arithmetic-performance.py').read_text()).replace('native-arithmetic', 'buffer-columns')
old = next(n.value for n in ast.walk(ast.parse(source)) if isinstance(n, ast.Constant)
           and isinstance(n.value, str) and n.value.startswith('Three alternating unchanged'))
source = source.replace(repr(old), repr('Three alternating unchanged full16 pilots verify all192 actual results/modes for original302 and width-corrected303. Preserve original60 column failures and all timing samples, including the cost of correctness. Builds/tests/profiles are separate. Real counters, full architecture/ownership, calibrated nine-round/every-case3% performance and final validation/audit remain required.'))
write('audit-buffer-columns-performance.py', source)
source = (p / 'finish-native-arithmetic-performance-closed.py').read_text().replace('native-arithmetic', 'buffer-columns').replace('source302 selected audit', 'source303 selected audit')
old = "assert selected['status']=='buffer-columns selected audit closed; 60 original display-column failures retained separately; performance pending',selected['status']"
new = "assert selected['status']=='buffer-columns selected audit closed; all338 original rows match GNU; performance pending',selected['status']"
assert source.count(old) == 1
source = source.replace(old, new).replace("len(selected['steps'])==5", "len(selected['steps'])==4")
anchor = " for name in ['measure-buffer-columns.py','audit-buffer-columns-performance.py']:"
assert source.count(anchor) == 1
source = source.replace(anchor, ''' state['status']='waiting for complete302 macOS processes to exit before timing';save()
 while not (p/'source302-full-queue-result.json').exists():
  print(state['status'],flush=True);time.sleep(30)
 platform=json.loads((p/'source302-full-queue-result.json').read_text())
 assert platform['status']=='complete macOS processes finished; raw evidence requires audit',platform['status']
 state['prior_platform_results']=[{k:r[k] for k in ['stage','exit_code','timed_out']} for r in platform['results']];save()
''' + anchor)
write('finish-buffer-columns-performance-closed.py', source)
for name, source in pending.items():
    with (p / name).open('x') as f:
        f.write(source)
print('Prepared303 timing queue: selected comparison and all302 local platform work must finish first')
