from pathlib import Path
import hashlib, json, subprocess, sys, time
p = Path(__file__).parent.resolve()
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p/n).read_text())
helpers = {n:sha(p/n) for n in ['native_fixed_validation_support.py', 'run-source303-validation.py', 'verify-existing-portable-arithmetic-draft.py', 'compare-vm-dispatch-fixtures.py', 'compare-source302-generated-loaded.py', 'compare-source303-generated-loaded.py', 'compare-buffer-line-broad-probe.py', 'audit-buffer-columns-selected.py', Path(__file__).name]}
state = dict(status='waiting for source303 fresh validation', steps=[], helpers=helpers, goal_complete=False)
def save(): (p/'buffer-columns-selection-closed-state.json').write_text(json.dumps(state,indent=2)+'\n')
def run(stage, command):
    assert all(sha(p/n)==h for n,h in helpers.items())
    state['status']='running '+stage;save();start=time.monotonic()
    with (p/('buffer-columns-selection-closed-'+stage+'-command.json')).open('x') as f: json.dump(dict(command=command, cwd=str(p), helpers=helpers),f,indent=2)
    with (p/('buffer-columns-selection-closed-'+stage+'.log')).open('xb') as log:
        r=subprocess.run(command,cwd=p,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
    item=dict(stage=stage,exit_code=r.returncode,elapsed_seconds=time.monotonic()-start,helpers_unchanged=all(sha(p/n)==h for n,h in helpers.items()))
    state['steps'].append(item);save();print(json.dumps(item),flush=True)
    assert r.returncode==0 and item['helpers_unchanged']
save();success=False
try:
    while not (p/'source303-validation-result.json').exists():
        print(state['status'],flush=True);time.sleep(20)
    assert read('source302-selected-audit.json')['status']=='passed'
    assert read('source303-validation-result.json')['status']=='strict, selected and ordinary build passed; raw audit and ordinary comparisons required'
    names=list(read('source302-selected-audit.json')['ordinary_results'])+['buffer-lf-line-index']
    assert len(names)==48
    for tag,folder in [('source303','buffer-display-columns')]:
        c=p.parent/'recovered-2026-10-05'/folder/'emaxx'
        if tag=='source303': run(tag+'-portable',[sys.executable,'-B',str(p/'verify-existing-portable-arithmetic-draft.py'),tag,str(c)])
        run(tag+'-ordinary',[sys.executable,'-B',str(p/'compare-vm-dispatch-fixtures.py'),tag,str(c),*names])
        run(tag+'-generated',[sys.executable,'-B',str(p/('compare-'+tag+'-generated-loaded.py'))])
        run(tag+'-audit',[sys.executable,'-B',str(p/'audit-buffer-columns-selected.py'),tag,str(c)])
    state['status']='buffer-columns selected audit closed; all338 original rows match GNU; performance pending';success=True
except Exception as error:
    state.update(status='selection stopped',error=repr(error))
finally:
    save()
    with (p/'buffer-columns-selection-closed-result.json').open('x') as f:json.dump(state,f,indent=2)
print(json.dumps(dict(status=state['status'],error=state.get('error'))),flush=True)
sys.exit(0 if success else 1)
