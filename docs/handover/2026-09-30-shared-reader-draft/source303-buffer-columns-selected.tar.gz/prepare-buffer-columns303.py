from pathlib import Path
import ast, hashlib, json, subprocess

p = Path(__file__).parent.resolve()
root = p.parents[2]
c = p.parent / 'recovered-2026-10-05/buffer-display-columns/emaxx'
g = p.parent / 'rebuilt-2026-10-01/emacs'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p / n).read_text())
base = read('source302-applied-commit.json')['commit']
manifest = read('source302-manifest.json')
assert all(sha(root / n) == h for n,h in manifest.items())
assert read('source302-selected-audit.json')['retained_broad_probe_failure']['different_rows'] == 60
assert not c.exists()
c.parent.mkdir()
(c.parent / 'emacs').symlink_to(g, target_is_directory=True)
for command in [
    ['git', 'clone', '--shared', '--quiet', '--no-checkout', str(root), str(c)],
    ['git', '-C', str(c), 'sparse-checkout', 'init', '--no-cone'],
    ['git', '-C', str(c), 'sparse-checkout', 'set', '--no-cone', *sorted({'/' + n for n in manifest} | {'/tools/', '/compat/'})],
    ['git', '-C', str(c), 'checkout', '--detach', base],
]:
    subprocess.run(command, check=True)
assert all(sha(c / n) == h for n,h in manifest.items())
path = c / 'src/lisp/primitives/buffers.rs'
before = path.read_text()
start = before.index('pub(crate) fn column_after(')
end = before.index('\npub(crate) fn char_is_invisible(', start)
part = before[start:end]
old = '''    } else {
        current_col + 1
    }
}
'''
new = '''    } else if (' '..='~').contains(&ch) {
        current_col + 1
    } else if ch == '\\n' {
        current_col
    } else {
        // indent.c:scan_for_column and buffer.h:CHARACTER_WIDTH use
        // ctl-arrow for ASCII controls, four columns for unibyte high
        // bytes, and the live char-width-table for multibyte characters.
        let width = if ch <= '\\u{7f}' {
            if interp
                .lookup_var("ctl-arrow", env)
                .is_some_and(|value| value.is_truthy())
            {
                2
            } else {
                4
            }
        } else if !interp.buffer.borrow().is_multibyte() {
            4
        } else {
            let width = interp
                .lookup_var("char-width-table", env)
                .and_then(|value| match value.kind() {
                    Kind::CharTable(table) => interp.char_table_get(table, ch as u32),
                    _ => None,
                })
                .and_then(|value| value.as_integer().ok())
                .unwrap_or(0);
            // buffer.h:sanitize_char_width caps invalid numeric widths.
            if (0..=1000).contains(&width) {
                width as usize
            } else {
                1000
            }
        };
        current_col + width
    }
}
'''
assert part.count(old) == 1
path.write_text(before[:start] + part.replace(old, new) + before[end:])
test_path = c / 'src/lisp/primitives/tests.rs'
old_tests = test_path.read_text()
test = '''
#[test]
fn buffer_display_columns_match_gnu_original_line_motion_probe() {
    assert_oracle_contract_matches_interpreter(
        include_str!("../../../tests/fixtures/buffer-lf-line-index.el"),
        include_str!("../../../tests/fixtures/buffer-lf-line-index.expected").trim_end(),
        "original 338-row line/column probe across controls, multibyte text, narrowing and edits",
    );
}
'''
test_path.write_text(old_tests + test)
subprocess.run(['cargo', 'fmt', '--all'], cwd=c, check=True)
assert test_path.read_text() == old_tests + test
assert [n for n,h in manifest.items() if sha(c / n) != h] == ['src/lisp/primitives/buffers.rs', 'src/lisp/primitives/tests.rs']
assert all(sha(c / n) == h for n,h in manifest.items() if n.startswith('tests/'))
with (p / 'source303-static-review.json').open('x') as f:
    json.dump(dict(status='unvalidated repair of already recorded display-column failures', candidate=str(c), base_commit=base,
        inputs={str(f): sha(f) for f in [path, test_path, g / 'src/indent.c', g / 'src/buffer.h']},
        mechanism='column_after retains invisibility and tab handling, uses ctl-arrow for ASCII controls, width4 for high bytes in unibyte buffers, and the actual live char-width-table with GNU sanitize_char_width bounds for non-ASCII multibyte characters. Printable ASCII remains width1. No host Unicode width substitute, cache, alternate representation or unsafe access.',
        failure='Source302 still differs from actual GNU in60 of338 original buffer-lf-line-index rows, solely column field10. This change targets that existing negative. The original fixture and expected bytes are unchanged; one regression test now invokes that entire existing probe.',
        preserved='Every original test/assertion/fixture remains. No line lookup, source292 LF configuration, native arithmetic, GC threshold or measurement criterion change. The unchanged source302 remains the baseline and its complete platform runs are independent.',
        limits='This repair does not claim complete display/overlay/composition semantics, GNU parity, real counters or final architecture/ownership completion. Full timing must wait for independent302 platform jobs and all303 validation to exit.', goal_complete=False), f, indent=2)

runner = (p / 'run-source302-validation.py').read_text().replace('source302', 'source303').replace('source297', 'source302')
runner = runner.replace('native-binary-arithmetic/emaxx', 'buffer-display-columns/emaxx').replace('native-funcall-dispatch/emaxx', 'native-binary-arithmetic/emaxx')
old = "assert changes == ['src/lisp/native_comp/runtime.rs', 'src/lisp/primitives/tests.rs', 'tests/fixtures/native-binary-arithmetic.el', 'tests/fixtures/native-binary-arithmetic.expected']"
new = "assert changes == ['src/lisp/primitives/buffers.rs', 'src/lisp/primitives/tests.rs']"
assert runner.count(old) == 1
runner = runner.replace(old, new).replace('native_binary_arithmetic_preserves_gnu_boundaries_types_and_errors', 'buffer_display_columns_match_gnu_original_line_motion_probe')
old = r'byte_?code|threads_retain_lexical_caller_roots|native_comp::runtime::|native.*(?:arity|calling|unwind|handler|argument)|numeric|arithmetic|remainder|modulo|bignum|float|integer|fixnum|lisp::types::|lisp::alloc::|buffer_line_indexes_preserve_gnu_lf_motion_narrowing_and_edits'
assert runner.count(old) == 1
runner = runner.replace(old, old + r'|^buffer::|column|indent|line|narrow|invisib|buffer.*(?:edit|multibyte)')
ast.parse(runner)
with (p / 'run-source303-validation.py').open('x') as f:
    f.write(runner)
generated = (p / 'compare-source302-generated-loaded.py').read_text().replace('source302', 'source303').replace('native-binary-arithmetic/emaxx', 'buffer-display-columns/emaxx')
ast.parse(generated)
with (p / 'compare-source303-generated-loaded.py').open('x') as f:
    f.write(generated)
print('Prepared source303: original width failures, unchanged broad fixture, GNU character-width rules')
