from pathlib import Path
import hashlib,json,sys
p=Path(__file__).parent.resolve();tag,directory=sys.argv[1:];c=Path(directory)
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
m=json.loads((p/(tag+'-manifest.json')).read_text());r=json.loads((p/(tag+'-portable-draft-audit.json')).read_text())
assert len(m)==534 and all(sha(c/n)==h for n,h in m.items())
assert len(r['patches'])==2
for kind,row in zip(('incremental','complete'),r['patches']):
    assert row['inputs']==len(m) and row['bytes_and_modes']=='exact'
    assert sha(p/row['patch'])==row['sha256']
    replay=p/(tag+'-replay-'+kind)
    assert all(sha(replay/n)==h and (replay/n).stat().st_mode & 0o777 == (c/n).stat().st_mode & 0o777 for n,h in m.items())
print(json.dumps(dict(status='existing portable byte/mode replays reverified',source=tag,inputs=len(m),patches=r['patches'])))
