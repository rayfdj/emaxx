from pathlib import Path
import ast

p = Path(__file__).parent.resolve()
pending = {}

def write(name, source):
    ast.parse(source)
    assert name not in pending and not (p / name).exists()
    pending[name] = source

def replace(source, old, new):
    assert source.count(old) == 1, (old, source.count(old))
    return source.replace(old, new)

source = (p / 'replay-native-arithmetic302.py').read_text()
old = next(n.value for n in ast.walk(ast.parse(source)) if isinstance(n, ast.Constant)
           and isinstance(n.value, str) and n.value.startswith('Source302 adds'))
source = replace(source, repr(old), repr('Source303 repairs the already recorded column-width mismatch using GNU control-character rules and the live width table. All534 input bytes/modes reconstruct from applied2680b957 and main. Every original test/fixture remains; a new test invokes the unchanged original338-row probe. No workload, timeout, expectation or criterion changes.'))
write('replay-buffer-columns303.py', source)

source = (p / 'audit-native-arithmetic-selected.py').read_text().replace('source302', 'source303').replace('source297', 'source302')
source = source.replace('native-funcall-dispatch/emaxx', 'native-binary-arithmetic/emaxx')
source = source.replace('new_arithmetic_test', 'new_column_test').replace('native_binary_arithmetic_preserves_gnu_boundaries_types_and_errors', 'buffer_display_columns_match_gnu_original_line_motion_probe')
source = replace(source, "assert [n for n,h in manifest.items() if prior_manifest.get(n)!=h] == ['src/lisp/native_comp/runtime.rs', 'src/lisp/primitives/tests.rs', 'tests/fixtures/native-binary-arithmetic.el', 'tests/fixtures/native-binary-arithmetic.expected']", "assert [n for n,h in manifest.items() if prior_manifest.get(n)!=h] == ['src/lisp/primitives/buffers.rs', 'src/lisp/primitives/tests.rs']")
selector = r'byte_?code|threads_retain_lexical_caller_roots|native_comp::runtime::|native.*(?:arity|calling|unwind|handler|argument)|numeric|arithmetic|remainder|modulo|bignum|float|integer|fixnum|lisp::types::|lisp::alloc::|buffer_line_indexes_preserve_gnu_lf_motion_narrowing_and_edits'
source = replace(source, selector, selector + r'|^buffer::|column|indent|line|narrow|invisib|buffer.*(?:edit|multibyte)')
source = replace(source, "names = list(read('source302-selected-audit.json')['ordinary_results']) + ['native-binary-arithmetic']\nassert len(names) == 47", "names = list(read('source302-selected-audit.json')['ordinary_results']) + ['buffer-lf-line-index']\nassert len(names) == 48")
source = replace(source, "('bytecode-integer-boundaries', 'buffer-lf-line-motion', 'native-binary-arithmetic')", "('bytecode-integer-boundaries', 'buffer-lf-line-motion', 'native-binary-arithmetic', 'buffer-lf-line-index')")
source = source.replace('ordinary_comparisons=48', 'ordinary_comparisons=49')
source = replace(source, "assert record['passed'] + record['ignored'] == len(record['selectors']) and record['failed'] == 0 and record['ignored'] == 0", "assert record['passed'] == 482 and record['passed'] + record['ignored'] == len(record['selectors']) and record['failed'] == record['ignored'] == 0")
old = next(n.value for n in ast.walk(ast.parse(source)) if isinstance(n, ast.Constant)
           and isinstance(n.value, str) and n.value.startswith('Source302 extends'))
source = replace(source, repr(old), repr('Source303 repairs ordinary buffer character widths using GNU rules and the live width table.534 exact input bytes/modes, fresh builds, zero-warning strict checks,482 selected passes/profile and49 actual GNU comparisons verify. All original tests/fixtures remain. The original338-row probe now matches actual GNU, closing its60 prior column failures without changing any expected byte. Broader display semantics, counters, ownership and final architecture/performance remain open.'))
start = source.index("broad = read(tag + '-line-broad-diagnosis.json')")
end = source.index("\nwith (p / (tag + '-selected-audit.json'))", start)
source = source[:start] + '''baseline_broad = read('source302-line-broad-diagnosis.json')
assert baseline_broad['exact_match'] is False and baseline_broad['rows'] == 338 and baseline_broad['different_rows'] == 60
baseline_gnu = p / 'source302-line-broad-gnu.stdout'
baseline_emaxx = p / 'source302-line-broad-emaxx.stdout'
assert sha(baseline_gnu) == baseline_broad['outcomes']['gnu']['stdout_sha256']
assert sha(baseline_emaxx) == baseline_broad['outcomes']['emaxx']['stdout_sha256']
repaired_output = (p / (tag + '-ordinary-buffer-lf-line-index-emaxx.stdout')).read_bytes()
assert repaired_output == baseline_gnu.read_bytes() and repaired_output != baseline_emaxx.read_bytes()
import ast
parser = next(n for n in ast.parse((p / 'compare-buffer-line-broad-probe.py').read_text()).body
              if isinstance(n, ast.FunctionDef) and n.name == 'parse')
exec(compile(ast.Module(body=[parser], type_ignores=[]), '<existing-full-probe-parser>', 'exec'))
parsed = parse(repaired_output.decode())
assert parsed[0] == len(parsed[1]) == 338 and all(len(row) == 13 for row in parsed[1])
record['closed_broad_probe_failure'] = dict(status='all338 original rows now match GNU', rows=338,
    different_rows=0, original_failing_rows=60,
    baseline_diagnosis_sha256=sha(p / 'source302-line-broad-diagnosis.json'),
    baseline_gnu_sha256=sha(baseline_gnu), baseline_emaxx_sha256=sha(baseline_emaxx),
    repaired_output_sha256=hashlib.sha256(repaired_output).hexdigest(),
    qualification='Original fixture and expected bytes unchanged. Actual ordinary GNU and candidate outputs are identical. The preserved302 negative retains its60 original column mismatches; no broader display correctness claim.')
''' + source[end:]
write('audit-buffer-columns-selected.py', source)

source = (p / 'finish-native-arithmetic-selected-closed.py').read_text().replace('source302', 'source303').replace('source297', 'source302')
source = source.replace('native-binary-arithmetic', 'buffer-display-columns')
source = source.replace('native-arithmetic-selection', 'buffer-columns-selection').replace('audit-native-arithmetic-selected.py', 'audit-buffer-columns-selected.py')
source = replace(source, "names=list(read('source302-selected-audit.json')['ordinary_results'])+['buffer-display-columns']\n    assert len(names)==47", "names=list(read('source302-selected-audit.json')['ordinary_results'])+['buffer-lf-line-index']\n    assert len(names)==48")
line = "        run(tag+'-broad-diagnosis',[sys.executable,'-B',str(p/'compare-buffer-line-broad-probe.py'),tag,str(c)])\n"
source = replace(source, line, '')
source = source.replace('native-arithmetic selected audit closed; 60 original display-column failures retained separately; performance pending', 'buffer-columns selected audit closed; all338 original rows match GNU; performance pending')
write('finish-buffer-columns-selected-closed.py', source)

for name, source in pending.items():
    with (p / name).open('x') as f:
        f.write(source)
print('Prepared source303 portable and selected-evidence helpers; no timing overlaps302 full validation')
