from pathlib import Path
import hashlib
import json
import shutil
import subprocess

p = Path(__file__).parent.resolve()
root = p.parents[2]
recovered = p.parent / 'recovered-2026-09-30'
isolated = recovered / 'macro-reader/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
old = json.loads((p / 'source196-fresh-manifest.json').read_text())
current = json.loads((p / 'source198-manifest.json').read_text())
assert all(sha(isolated / name) == digest for name, digest in old.items())
assert all(sha(root / name) == digest for name, digest in current.items())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == '7e45db47438a39e97658bddaceba903e0e41c186'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=isolated, text=True).strip() == '21d20f0eec08f3c013d5d3eb3bd6e9cfc16b3199'
assert (p / 'source196-fresh-full-local-supervisor-result.json').is_file()
for pid in [8612, 8613, 8614, 12611, 12612]:
    result = subprocess.run(['ps', '-p', str(pid), '-o', 'pid=,command='], capture_output=True, text=True)
    assert result.returncode == 1 and not result.stdout and not result.stderr

# Retain the ordinary executable and image at their original relative depth,
# so the image's relative native-library paths still resolve correctly.
retained = recovered / 'macro-reader196-retained/emaxx/target/frame-validation/release'
retained.mkdir(parents=True, exist_ok=False)
artifacts = {}
for suffix in ['', '.pdmp']:
    source = isolated / ('target/frame-validation/release/emaxx' + suffix)
    immutable = p / ('source196-fresh-ordinary-emaxx' + suffix)
    assert sha(source) == sha(immutable)
    destination = retained / ('emaxx' + suffix)
    shutil.copy2(source, destination)
    assert sha(destination) == sha(immutable)
    artifacts[str(destination)] = sha(destination)

changed = []
for name, digest in current.items():
    target = isolated / name
    if not target.exists() or sha(target) != digest:
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy(root / name, target)  # Fresh mtime is required by Cargo.
        changed.append(name)
    assert sha(target) == digest
assert (isolated.parent / 'emacs/src/alloc.c').is_file()
record = {'previous_source': 'source196-fresh', 'starting_source': 'source198',
          'isolated_checkout': str(isolated), 'previous_supervisors_exited': True,
          'preserved_artifacts': artifacts, 'source198_inputs': len(current),
          'changed_inputs': changed,
          'qualification': 'Preparation only. No source199 implementation or validation is claimed.'}
with (p / 'source199-preparation.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record, indent=2))
