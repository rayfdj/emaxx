from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import time

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/macro-reader/emaxx'
tag = 'source199-baseline'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
manifest = json.loads((p / (tag + '-manifest.json')).read_text())
unchanged = lambda: all(sha(root / name) == digest for name, digest in manifest.items())
env = {'CARGO_TARGET_DIR': str(root / 'target/frame-validation'), 'CARGO_BUILD_JOBS': '1',
       'RUST_MIN_STACK': '134217728', 'RUST_TEST_THREADS': '1', 'EMAXX_GC_VERIFY': '1'}

def save(suffix, record):
    with (p / (tag + '-' + suffix + '.json')).open('x') as stream:
        json.dump(record, stream, indent=2)
        stream.write('\n')

def run(stage, command, extra=None):
    assert unchanged()
    save(stage + '-command', {'command': command, 'working_directory': str(root),
                            'environment_override': env, **(extra or {})})
    start = time.monotonic()
    with (p / (tag + '-' + stage + '.log')).open('x') as log:
        result = subprocess.run(command, cwd=root, env={**os.environ, **env},
                                stdout=log, stderr=subprocess.STDOUT, timeout=3600)
    record = {'exit_code': result.returncode, 'elapsed_seconds': time.monotonic() - start,
              'source_unchanged': unchanged()}
    save(stage + '-result', record)
    print(stage, json.dumps(record), flush=True)
    return result.returncode

code = run('gate-build', ['cargo', 'test', '--locked', '--all-features', '--profile', 'gate',
                         '--lib', '--no-run', '--message-format=json-render-diagnostics'])
if code == 0:
    artifacts = []
    for line in (p / (tag + '-gate-build.log')).read_text().splitlines():
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        if item.get('reason') == 'compiler-artifact' and item.get('profile', {}).get('test') and item.get('executable'):
            artifacts.append(item['executable'])
    assert len(artifacts) == 1
    binary = p / (tag + '-gate-libtest')
    assert not binary.exists()
    shutil.copy2(artifacts[0], binary)
    names = ['lisp::alloc::vectors::tests::vector_allocations_have_word_sized_footprints',
             'lisp::native_comp::runtime::tests::interpreted_closure_allocation_charges_its_gnu_lisp_words']
    listed = subprocess.check_output([str(binary), '--list', '--format', 'terse'], cwd=root, text=True)
    with (p / (tag + '-inventory.txt')).open('x') as stream:
        stream.write(listed)
    assert all(name + ': test' in listed.splitlines() for name in names)
    code = run('focused', [str(binary), *names, '--exact', '--nocapture', '--test-threads=1'],
               {'selected_inventory': names, 'binary_sha256': sha(binary)})
save('result', {'exit_code': code, 'source_unchanged': unchanged(),
                'qualification': 'Original source198 runtime with new architectural controls. A failing footprint or charge assertion is retained as baseline evidence; it is not a passing runtime validation.'})
raise SystemExit(code)
