from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
out = p.parents[2] / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected', '.h'}
selected = read('source296-selected-audit.json')
performance = read('native-fixed-performance-audit.json')
assert selected['status'] == 'passed' and selected['source_inputs_verified'] == 532
assert selected['ordinary_comparisons'] == 47
assert all(r['passed'] == 326 and r['failed'] == 0 and r['ignored'] == 0
           for r in selected['profiles'].values())
assert selected['retained_broad_probe_failure']['exact_match'] is False
assert performance['status'] == 'all 192 processes and actual results/modes verified'
assert read('native-fixed-performance-sequence-closed-result.json')['status'] == 'timing audited; source decision pending'
for audit in (selected, performance):
    assert all(sha(Path(name).read_bytes()) == digest for name, digest in audit['evidence_files'].items())
helpers = [
    'run-source296-validation.py', 'audit-native-fixed-selected.py',
    'compare-source296-generated-loaded.py', 'compare-source292-generated-loaded.py',
    'compare-vm-dispatch-fixtures.py', 'compare-buffer-line-broad-probe.py',
    'native_fixed_validation_support.py', 'verify-existing-portable-draft.py',
    'replay-native-fixed296.py', 'finish-native-fixed-selected-closed.py',
    'source292-gate-inventory.log', 'source292-release-inventory.log',
    'prepare-native-fixed296.py', 'source292-full-validation-launch.json',
    'source292-manifest.json', 'source292-selected-audit.json',
    'printer-varied-v3-293638f0.el', 'printer-varied-v3-gnu.stdout',
    'package-source196-failure-and197-results.py', Path(__file__).name,
]
files = {f.name: f for f in p.iterdir() if f.is_file() and f.suffix in allowed
         and f.name.startswith(('source296-', 'native-fixed-selection-', 'native-fixed-coordinator-'))}
files.update({name: p / name for name in helpers})
package('source296-native-fixed-selected', files, dict(
    status='closed fresh selected validation for source296', audit=selected,
    qualification='All 532 source inputs and modes replay exactly. Fresh gate/release/ordinary compilation is verified. Each selected profile has 326 passes and no failures or ignores; 47 actual ordinary GNU comparisons pass. The entire broad probe retains 60 original display-column failures. No fixture, assertion, selector, timeout or comparison rule is weakened. Full-platform, accounting, ownership and final performance acceptance remain open.',
    goal_complete=False))
files = {}
for tag in ('source292', 'source296'):
    for directory in sorted(p.glob(tag + '-native-fixed-pilot-*')) + [p / (tag + '-core-native')]:
        for f in directory.rglob('*'):
            if f.is_file() and f.suffix in allowed:
                files[str(f.relative_to(p))] = f
for f in p.iterdir():
    if f.is_file() and f.suffix in allowed and f.name.startswith('native-fixed-performance-'):
        files[f.name] = f
for name in ['measure-native-fixed.py', 'audit-native-fixed-performance.py',
             'finish-native-fixed-performance-closed.py', 'source296-application-decision.json',
             'package-source196-failure-and197-results.py', Path(__file__).name]:
    files[name] = p / name
package('source296-native-fixed-performance', files, dict(
    status='all 192 actual diagnostic results and modes verified', audit=performance,
    application_decision=read('source296-application-decision.json'),
    qualification='Three alternating repetitions of every unchanged 16-workload pilot for applied LF-correct baseline292 and native fixed-copy candidate296. Every sample, unfavorable case and startup/total/RSS/GC report remains. Builds, tests and profiles were separate from timing. Allocation counters remain unavailable. This diagnostic does not certify calibrated nine-round acceptance or the unchanged upper 95% ratio of at most 1.03 for every case.',
    goal_complete=False))
