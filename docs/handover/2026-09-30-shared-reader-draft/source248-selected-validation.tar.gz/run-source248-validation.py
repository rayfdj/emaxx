from pathlib import Path
import json, subprocess, sys, time
p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/coding-property-order/emaxx'
stages = [
    ['check-source248.py', '248'], ['static-source248.py', '248'],
    ['test-source248-controls.py', '248', 'gate'], ['build-source248.py', '248'],
    ['compare-source230-fixtures.py', 'source248', str(root),
     'overriding-property-identity', 'coding-candidate-symbol-properties', 'coding-candidate-translation', 'coding-candidate-character-identities', 'coding-candidate-inventory', 'file-write-coding-selection', 'new-file-coding-lifecycle', 'file-write-order',
     'canonical-coding-character-storage', 'canonical-coding-identity-storage',
     'canonical-coding-conversion-storage', 'copied-canonical-string-storage', 'coding-error-object-storage'],
    ['probe-source248-compiler-load.py'],
    ['test-source248-broad.py', '248', 'gate'],
]
results = []
for name, *args in stages:
    command = [sys.executable, str(p / name), *args]
    start = time.monotonic()
    result = subprocess.run(command, stdin=subprocess.DEVNULL)
    results.append(dict(command=command, exit_code=result.returncode, elapsed_seconds=time.monotonic()-start))
    if result.returncode:
        break
with (p / 'source248-validation-result.json').open('x') as f:
    json.dump(results, f, indent=2)
raise SystemExit(results[-1]['exit_code'])
