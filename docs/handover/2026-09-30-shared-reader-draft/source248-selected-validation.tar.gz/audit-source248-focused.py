from pathlib import Path
import ast, hashlib, json, re, shutil, sys

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/coding-property-order/emaxx'
profile = sys.argv[1] if len(sys.argv) > 1 else 'gate'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'audit-source238-release.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'audit_log')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<raw-verdict-auditor>', 'exec'))
manifest = read('source248-manifest.json')
assert len(manifest) == 472 and all(sha(root / name) == digest for name, digest in manifest.items())
command = read('source248-' + profile + '-controls-command.json')
result = read('source248-' + profile + '-controls-result.json')
assert result['exit_code'] == 0 and result['source_unchanged']
names = command['selected_inventory']
previous = read('source247-' + profile + '-controls-command.json')['selected_inventory']
assert len(names) == len(set(names)) == 172
assert set(previous) <= set(names)
assert set(names) - set(previous) == {'lisp::primitives::tests::symbol_properties_preserve_override_order_and_identity'}
ignored = ['tty::tty_differential_end_to_end', 'tty::tty_smoke_end_to_end']
audit_log(names, (p / ('source248-' + profile + '-controls.log')).read_text(), ignored)
for stage in ['check', 'fmt', 'clippy', 'diff', profile + '-build']:
    stage_result = read('source248-' + stage + '-result.json')
    assert stage_result['exit_code'] == 0 and stage_result['source_unchanged']
    raw = (p / ('source248-' + stage + '.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
    for line in raw.splitlines():
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        assert row.get('message', {}).get('level') not in ['warning', 'error']
binary = p / ('source248-' + profile + '-libtest')
assert sha(binary) == command['binary_sha256']
images = sorted((p / 'fixture-images-source248').glob('loadup-' + sha(binary)[:8] + '-*.pdmp'))
assert len(images) == 1
retained = p / ('source248-' + profile + '-focused-retained-inputs')
retained.mkdir()
files = []
for source in [binary, *images]:
    destination = retained / source.name
    digest = sha(source)
    shutil.copy2(source, destination)
    assert sha(source) == sha(destination) == digest
    files.append(dict(original=str(source), retained=str(destination), sha256=digest, bytes=destination.stat().st_size))
record = dict(status='passed', profile=profile, passed=170, failed=0, ignored=ignored,
              names=names, inputs_verified=472, retained_files=files, strict_checks='zero-warning pass',
              qualification='Every preceding selected control remains present and passes; the additional unchanged GNU-backed fixture passes. It adds the first-nil duplicate property rule, with unchanged GNU-derived outputs; same-name uninterned symbol/key identity and atom-entry controls are preserved. The source247 nil/t translation and property-override controls remain. Complete upstream/compiler, frozen, terminal, Linux and performance evidence remains separate.')
with (p / ('source248-' + profile + '-focused-audit.json')).open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps({key: record[key] for key in ['status', 'profile', 'passed', 'ignored', 'strict_checks']}, indent=2))
