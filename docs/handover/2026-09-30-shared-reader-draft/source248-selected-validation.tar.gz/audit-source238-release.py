from pathlib import Path
import hashlib, json, re, shutil

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/rx-repair/emaxx'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read('source238-manifest.json')
assert len(manifest) == 446
assert all(sha(root / name) == digest for name, digest in manifest.items())

def audit_log(names, raw, ignored):
    assert re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', raw, re.M) == [
        ('ok', str(len(names) - len(ignored)), '0', str(len(ignored)))]
    starts = list(re.finditer(r'^test (\S+) \.\.\. ', raw, re.M))
    assert [m[1] for m in starts] == names
    for index, match in enumerate(starts):
        end = starts[index + 1].start() if index + 1 < len(starts) else raw.rindex('test result:')
        verdict = raw[match.end():end].strip()
        if match[1] in ignored:
            assert verdict.startswith('ignored,'), match[1]
        else:
            assert re.search(r'(?:^|\s)ok$', verdict), match[1]

inventories = {}
for profile, count in [('gate', 2988), ('release', 2987)]:
    names = [line[:-6] for line in (p / ('source238-' + profile + '-inventory.txt')).read_text().splitlines()
             if line.endswith(': test')]
    assert len(names) == len(set(names)) == count
    inventories[profile] = names
assert set(inventories['gate']) - set(inventories['release']) == {
    'file_system::posix::tests::posix_file_drop_rejects_an_externally_closed_descriptor'}
assert not set(inventories['release']) - set(inventories['gate'])
prefixes = ('lisp::bytecode::', 'lisp::native_comp::runtime::', 'lisp::primitives::pdumper::',
            'lisp::primitives::tests::', 'lisp::reader::', 'lisp::types::')
groups = []
for group, count in [('controls', 103), ('broad', 940)]:
    stem = 'source238-release-' + group
    command, result = read(stem + '-command.json'), read(stem + '-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
    assert sha(p / 'source238-release-libtest') == command['binary_sha256']
    assert command['environment_override']['LANG'] == command['environment_override']['LC_ALL'] == 'C'
    names = command['selected_inventory']
    assert len(names) == len(set(names)) == count
    if group == 'broad':
        assert names == [name for name in inventories['release'] if name.startswith(prefixes)]
        assert names == sorted(read('source234-release-broad-command.json')['selected_inventory'] + [
            'lisp::primitives::tests::mapconcat_preserves_canonical_bytes_and_character_sequences',
            'lisp::primitives::tests::reader_hex_escapes_preserve_the_raw_byte_boundary_and_digit_count'])
        ignored = []
    else:
        assert names == read('source238-gate-controls-command.json')['selected_inventory']
        ignored = ['tty::tty_differential_end_to_end', 'tty::tty_smoke_end_to_end']
    assert command['command'][1:] == names + ['--exact', '--nocapture', '--test-threads=1']
    audit_log(names, (p / (stem + '.log')).read_text(), ignored)
    groups.append(dict(profile='release', stage=group, passed=count-len(ignored), failed=0, ignored=ignored))
for stage in ['check', 'fmt', 'clippy', 'diff', 'gate-build', 'release-build']:
    result = read('source238-' + stage + '-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
    raw = (p / ('source238-' + stage + '.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
    for line in raw.splitlines():
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        assert item.get('message', {}).get('level') not in ['error', 'warning']
assert all(stage['exit_code'] == 0 for stage in read('source238-release-and-ordinary-result.json'))
names = read('source238-release-controls-command.json')['selected_inventory']
raw = (p / 'source238-release-controls.log').read_text()
first = 'test ' + names[0] + ' ... ok'
assert first in raw
ignored = ['tty::tty_differential_end_to_end', 'tty::tty_smoke_end_to_end']
mutants = {
    'missing-verdict': raw.replace(first, '', 1),
    'duplicate-verdict': raw.replace(first, first + '\n' + first, 1),
    'failed-verdict-under-green-summary': raw.replace(first, first.replace(' ... ok', ' ... FAILED'), 1),
    'missing-summary': raw[:raw.rindex('test result:')],
    'false-summary-total': raw.replace('101 passed; 0 failed;', '100 passed; 0 failed;', 1),
    'new-ignore-under-green-summary': raw.replace(first, first.replace(' ... ok', ' ... ignored, new exclusion'), 1),
}
for label, invalid in mutants.items():
    try:
        audit_log(names, invalid, ignored)
    except (AssertionError, ValueError):
        pass
    else:
        raise AssertionError('Auditor accepted corrupt evidence: ' + label)
retained = p / 'source238-release-retained-inputs'
retained.mkdir()
images = sorted((p / 'fixture-images-source238').glob('loadup-' + sha(p / 'source238-release-libtest')[:8] + '-*.pdmp'))
assert len(images) == 1
files = []
for source in [p / 'source238-release-libtest', *images]:
    target = retained / source.name
    digest = sha(source)
    shutil.copy2(source, target)
    assert sha(source) == sha(target) == digest
    files.append(dict(original=str(source), retained=str(target), sha256=digest, bytes=target.stat().st_size))
record = dict(status='source238 selected release validation passes', inputs_verified=len(manifest),
              strict_checks='passed with zero warnings', groups=groups, retained_files=files,
              inventory_counts={profile: len(names) for profile, names in inventories.items()},
              existing_profile_difference='One unchanged cfg(debug_assertions) POSIX file-drop control is gate-only.',
              corrupt_logs_rejected=list(mutants), goal_complete=False,
              qualification='All 101 focused release tests pass with two pre-existing TTY end-to-end ignores; all 940 affected-module release tests pass without ignores. Every raw name and verdict, artifact identity and corruption rejection is verified. Complete macOS, Linux and terminal validation remain separate. The ordinary encoding diagnostic exposes additional failures not covered by these passing controls. No pinned Darwin, physical accounting or performance certification.')
with (p / 'source238-release-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps(dict(status=record['status'], groups=groups, retained_files=files), indent=2))
