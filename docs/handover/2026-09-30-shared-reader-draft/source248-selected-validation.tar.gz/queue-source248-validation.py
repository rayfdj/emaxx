from pathlib import Path
import hashlib, json, os, subprocess, sys, time

p = Path(__file__).parent.resolve()
candidate = p.parent / 'recovered-2026-09-30/coding-property-order/emaxx'
prior = p.parent / 'recovered-2026-09-30/coding-properties/emaxx'
manifest = json.loads((p / 'source248-manifest.json').read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert len(manifest) == 472 and all(sha(candidate / n) == h for n, h in manifest.items())
state = dict(status='waiting for existing source247 validation supervisor', prior_pid=90626,
             source_manifest='source248-manifest.json', goal_complete=False)
def save():
    (p / 'source248-validation-queue-state.json').write_text(json.dumps(state, indent=2) + '\n')
save()
try:
    while True:
        process = subprocess.run(['ps', '-p', '90626', '-o', 'command='], capture_output=True, text=True)
        if process.returncode == 1 and not process.stdout.strip():
            break
        if process.returncode or 'run-source247-validation.py' not in process.stdout:
            raise RuntimeError('prior supervisor state is ambiguous: ' + process.stdout + process.stderr)
        time.sleep(5)
    stages = json.loads((p / 'source247-validation-result.json').read_text())
    if len(stages) != 7 or any(stage['exit_code'] != 0 for stage in stages):
        raise RuntimeError('source247 did not complete its original selected pipeline successfully')
    state['status'] = 'auditing completed source247 before cache reuse'
    save()
    subprocess.run([sys.executable, str(p / 'audit-source247-selected.py')], check=True)
    assert json.loads((p / 'source247-gate-focused-audit.json').read_text())['passed'] == 169
    state['status'] = 'cloning completed source247 cache'
    save()
    (candidate / 'target').mkdir(exist_ok=True)
    assert not (candidate / 'target/frame-validation').exists()
    subprocess.run(['cp', '-cR', str(prior / 'target/frame-validation'),
                    str(candidate / 'target/frame-validation')], check=True)
    assert all(sha(candidate / n) == h for n, h in manifest.items())
    helper = p / 'run-source248-validation.py'
    command = [sys.executable, '-B', str(helper)]
    state.update(status='running source248 selected validation', command=command,
                 helper_sha256=sha(helper), cache_source=str(prior / 'target/frame-validation'))
    save()
    with (p / 'source248-validation-driver.log').open('x') as log:
        result = subprocess.run(command, cwd=candidate, stdin=subprocess.DEVNULL,
            stdout=log, stderr=subprocess.STDOUT,
            env={**os.environ, 'PYTHONUNBUFFERED': '1', 'PYTHONDONTWRITEBYTECODE': '1'})
    state.update(status='source248 selected validation finished', exit_code=result.returncode)
    save()
    raise SystemExit(result.returncode)
except Exception as error:
    state.update(status='queue failed', error=repr(error))
    save()
    raise
