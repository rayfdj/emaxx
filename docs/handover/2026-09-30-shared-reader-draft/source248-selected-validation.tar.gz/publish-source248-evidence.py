from pathlib import Path
import hashlib, json, subprocess, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
sha = lambda data: hashlib.sha256(data).hexdigest()

def output(command):
    return subprocess.check_output(command, cwd=root, text=True).strip()

def save(name, record):
    with (p / name).open('x') as stream:
        json.dump(record, stream, indent=2)

prior = 'de944b6a19257a50f9d873fa9b43b43fd28b0d7b'
runtime = 'aaf31ce70abc920f9fc3395c01db7ffc57328f81'
assert output(['git', 'branch', '--show-current']) == 'runtime-char-tables'
assert output(['git', 'rev-parse', 'HEAD']) == prior
assert not output(['git', 'diff', '--cached', '--name-only'])
manifest = json.loads((p / 'source246-manifest.json').read_text())
assert len(manifest) == 468
assert all(sha((root / name).read_bytes()) == digest for name, digest in manifest.items())
paths = ['HANDOVER.md', 'docs/runtime-representation-progress.md',
         'docs/runtime-representation-correctness-recovery-draft.md']
stems = ['source246-release-and-linux-rust-failure', 'source248-property-drafts',
         'source247-selected-and246-gnu-diagnosis']
archives = []
for stem in stems:
    base = 'docs/handover/2026-09-30-shared-reader-draft/' + stem
    record = json.loads((root / (base + '-manifest.json')).read_text())
    archive = root / (base + '.tar.gz')
    assert record['goal_complete'] is False
    assert sha(archive.read_bytes()) == record['archive']['sha256']
    assert archive.stat().st_size == record['archive']['bytes']
    with tarfile.open(archive) as contents:
        assert contents.getnames() == [item['path'] for item in record['files']]
        for item in record['files']:
            data = contents.extractfile(item['path']).read()
            assert len(data) == item['bytes'] and sha(data) == item['sha256']
    archives.append(record['archive'])
    paths.extend([base + '-manifest.json', base + '.tar.gz'])
subprocess.run(['git', 'diff', '--check'], cwd=root, check=True)
subprocess.run(['git', 'add', '--', *paths], cwd=root, check=True)
assert set(output(['git', 'diff', '--cached', '--name-only']).splitlines()) == set(paths)
subprocess.run(['git', 'diff', '--cached', '--check'], cwd=root, check=True)
subprocess.run(['git', '-c', 'user.name=Ray', '-c', 'user.email=26018378+rayfdj@users.noreply.github.com',
                'commit', '-m', 'Preserve correctness diagnosis and isolated property repairs'], cwd=root, check=True)
head = output(['git', 'rev-parse', 'HEAD'])
assert not output(['git', 'status', '--porcelain'])
save('source248-evidence-commit.json', dict(commit=head, runtime_commit=runtime,
     root_inputs=468, paths=paths, archives=archives, goal_complete=False))
command = ['git', 'push', 'origin', 'HEAD:refs/heads/runtime-char-tables']
result = subprocess.run(command, cwd=root, stdin=subprocess.DEVNULL, capture_output=True, text=True)
save('source248-evidence-push.json', dict(command=command, exit_code=result.returncode,
     stdout=result.stdout, stderr=result.stderr))
result.check_returncode()
assert output(['git', 'ls-remote', '--heads', 'origin', 'refs/heads/runtime-char-tables']).split()[0] == head
body = (p / 'source248-evidence-pr-body.md').read_text()
payload = p / 'source248-evidence-pr-payload.json'
with payload.open('x') as stream:
    json.dump(dict(title='Share Lisp object fields and execute bytecode from live strings', body=body), stream)
updated = json.loads(output(['gh', 'api', 'repos/rayfdj/emaxx/pulls/79', '--method', 'PATCH', '--input', str(payload)]))
save('source248-evidence-pr-update.json', updated)
verified = json.loads(output(['gh', 'api', 'repos/rayfdj/emaxx/pulls/79']))
assert verified['head']['sha'] == head and verified['draft'] and verified['body'] == body
assert verified['base']['sha'] == '21d20f0eec08f3c013d5d3eb3bd6e9cfc16b3199'
save('source248-evidence-pr-verified.json', verified)
print(json.dumps(dict(status='evidence pushed and draft PR verified', head=head, runtime_commit=runtime,
     pull_request=verified['html_url'], main_unchanged=True, goal_complete=False)))
