from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected', '.h'}

def collect(patterns, directories):
    files = {str(f.relative_to(p)): f for pattern in patterns for f in p.glob(pattern)
             if f.is_file() and f.suffix in allowed}
    for directory in directories:
        files.update({str(f.relative_to(p)): f for f in (p / directory).rglob('*')
                      if f.is_file() and (f.suffix in allowed or f.name == 'Makefile')})
    files[Path(__file__).name] = Path(__file__)
    return files

mac = read('source246-macos-rust-complete-audit.json')
tty = read('source246-complete-terminal-audit.json')
frozen = read('source246-linux-frozen-complete-audit.json')
raw = read('source246-linux-frozen-raw-integrity-audit.json')
assert mac['total_passed'] == 3096 and mac['library_ignored'] == 2
assert tty['scenarios'] == 226 and tty['verified_checkpoints'] == 686
assert frozen['verified_files'] == 519 and frozen['verified_outcomes'] == 7928
smoke = read('source246-gnu-trace-macos-smoke/summary.json')
assert smoke['status'] == 'ordinary smoke completed' and smoke['inputs_unchanged']
assert len(smoke['runs']) == 20
for row in smoke['runs']:
    assert row['exit_code'] == 0 and not row['timed_out'] and row['expected_output']
    for suffix in ['stdout', 'stderr']:
        data = (p / 'source246-gnu-trace-macos-smoke' / row[suffix + '_file']).read_bytes()
        assert sha(data) == row[suffix + '_sha256']
        if suffix == 'stderr':
            assert data == b''
files = collect(['source246-full-gate*', 'source246-macos-*', 'source246-manifest.json',
    'source246-full-ttydiff*', 'source246-complete-terminal-audit.json', 'source246-linux-frozen-*',
    'audit-source246-macos-names.py', 'verify-source246-macos-rust.py',
    'verify-complete-reader-terminal-receipts.py', 'verify-complete-frozen-receipts.py',
    'audit-source246-frozen.py', 'download-source246-linux-frozen.py',
    'run-source246-full-gate.py', 'run-source246-full-tty.py', 'gnu-census-trace-static-audit.json',
    'validate-gnu-census-trace.py'],
    ['full-gate-source246', 'source246-linux-frozen-artifacts', 'source246-gnu-trace-macos-smoke'])
for name in ['tools/diagnose_gnu_census_trace.py', 'tools/diagnostics/gnu-census-snapshot.py',
             '.github/workflows/frozen-run.yml']:
    files[name] = root / name
package('source246-complete-frozen-macos-terminal', files, dict(macos=mac, terminal=tty,
    frozen=frozen, raw_integrity=raw, gnu_trace_smoke_processes=20,
    trace_static=read('gnu-census-trace-static-audit.json'),
    qualification='Exact source246 closes complete macOS (3096 passes/two existing ignores), terminal (226 scenarios/686 comparisons), and pinned Linux frozen (519 files/7928 outcomes/1038 successful processes). Every raw inventory/verdict and retained input hash is checked. Linux Rust remains failed on two GNU reference assertions; no cause is established. The new read-only GNU GC observer has 15 synthetic decoder checks and eight parsed shell blocks; its ordinary-only macOS smoke passes 20 processes. GDB has not run yet. Darwin pin, remaining coding/architecture/accounting/ownership work, final audit and performance remain open.'))

selected = read('source248-selected-audit.json')
focused = read('source248-gate-focused-audit.json')
assert selected['affected_passes'] == 953 and selected['ordinary_comparisons'] == 13
assert focused['passed'] == 170 and focused['inputs_verified'] == 472
files = collect(['source248-*', '*source248*.py', 'compare-source230-fixtures.py',
                 'audit-source238-release.py'], ['source248-gate-focused-retained-inputs'])
# The original compiler-file comparison is still executing. Keep only its
# immutable launch receipt/helper; do not package partial outputs.
for name in list(files):
    if name.startswith('source248-upstream-compiler') and name != 'source248-upstream-compiler-launch.json':
        del files[name]
package('source248-selected-validation', files, dict(focused=focused,
    affected_passes=953, ordinary_matches=13, compiler_load='both editors succeed',
    source_manifest='source248-manifest.json', inputs=472,
    qualification='Strict zero-warning checks, 170 focused passes/two existing ignores, all 953 affected controls and thirteen ordinary comparisons pass. Both original source246 negative property fixtures now match GNU without changed outputs. Original compiler-file load passes; complete 177-test comparison is launched, not certified. Queue94807 has exited. Root remains source246, and no source248 complete platform/release/frozen or performance result is claimed.'))
