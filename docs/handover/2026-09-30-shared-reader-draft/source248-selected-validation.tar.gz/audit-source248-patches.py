from pathlib import Path
import hashlib, io, json, os, subprocess, tarfile, tempfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
candidate = p.parent / 'recovered-2026-09-30/coding-property-order/emaxx'
sha = lambda data: hashlib.sha256(data).hexdigest()
records = []
for tag in ['source248']:
    manifest = json.loads((p / (tag + '-manifest.json')).read_text())
    frozen = json.loads((p / (tag + '-freeze.json')).read_text())
    assert len(manifest) == 472
    for label, info in frozen['patches'].items():
        patch = p / (tag + '-' + label + '.patch')
        assert sha(patch.read_bytes()) == info['sha256']
        tracked = set(subprocess.check_output(
            ['git', 'ls-tree', '-r', '--name-only', info['base']], cwd=root, text=True).splitlines())
        names = sorted(tracked & manifest.keys())
        archive = subprocess.check_output(['git', 'archive', info['base'], '--', *names], cwd=root)
        with tempfile.TemporaryDirectory(prefix='emaxx-file-coding-patch-', dir='/private/tmp') as temp:
            temp = Path(temp)
            with tarfile.open(fileobj=io.BytesIO(archive)) as source:
                for member in source:
                    assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
                    path = temp / member.name
                    if member.isdir():
                        path.mkdir(parents=True, exist_ok=True)
                    else:
                        assert member.isfile()
                        path.parent.mkdir(parents=True, exist_ok=True)
                        path.write_bytes(source.extractfile(member).read())
                        os.chmod(path, 0o755 if member.mode & 0o111 else 0o644)
            subprocess.run(['git', 'apply', '--check', str(patch)], cwd=temp, check=True)
            subprocess.run(['git', 'apply', str(patch)], cwd=temp, check=True)
            for name, digest in manifest.items():
                assert sha((temp / name).read_bytes()) == digest, (tag, label, name)
                assert (temp / name).stat().st_mode & 0o777 == (candidate / name).stat().st_mode & 0o777, name
        records.append(dict(source=tag, patch=label, inputs=len(manifest), base=info['base'],
                            patch_sha256=info['sha256'], bytes_and_git_checkout_modes='exact'))
current = json.loads((p / 'source248-manifest.json').read_text())
assert all(sha((candidate / name).read_bytes()) == digest for name, digest in current.items())
with (p / 'source248-patch-replay-audit.json').open('x') as out:
    json.dump(dict(status='exact', replays=records,
                   qualification='Both incremental and complete patches reproduce all 472 inputs and Git checkout modes. Separate source248 property-resolution repair; runtime validation is separate. Published source246 and its active full runs remain unchanged.'), out, indent=2)
print(json.dumps(records, indent=2))
