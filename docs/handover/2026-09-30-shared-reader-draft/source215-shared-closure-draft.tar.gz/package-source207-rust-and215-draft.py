from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve();root=p.parents[2]
out=root/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest()
tree=ast.parse((p/'package-source196-failure-and197-results.py').read_text())
node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
allowed={'.json','.log','.txt','.py','.patch','.stdout','.stderr','.el','.expected'}
def add(files,names):
    files.update({name:p/name for name in names})

files={str(f.relative_to(p)):f for f in (p/'full-gate-source207').rglob('*') if f.is_file() and f.suffix in allowed}
add(files,['source207-full-gate-command.json','source207-full-gate-result.json','source207-full-gate.log','run-source207-full-gate.py',
           'verify-source207-macos-rust.py','audit-source207-macos-names.py','source207-macos-rust-complete-audit.json','source207-macos-rust-name-audit.json',
           'source207-manifest.json','source207-base.json','source207-complete.patch','source207-census-repair-audit.json','audit-source207-census-repair.py',Path(__file__).name])
files['tools/retain_rust_gate_artifacts.py']=root/'tools/retain_rust_gate_artifacts.py'
package('source207-macos-complete-rust',files,json.loads((p/'source207-macos-rust-complete-audit.json').read_text()))

base=p/'linux-source207-rust-artifacts'
files={str(f.relative_to(p)):f for f in base.rglob('*') if f.is_file() and f.suffix in allowed}
add(files,['source207-linux-rust-final-state.json','source207-linux-rust-ci.log','source207-linux-rust-download.json','source207-linux-rust-complete-audit.json',
           'source207-linux-rust-name-audit.json','audit-source207-linux-names.py','verify-complete-rust-receipts.py','source207-census-repair-audit.json',
           'audit-source207-census-repair.py',Path(__file__).name])
package('source207-linux-complete-rust',files,json.loads((p/'source207-linux-rust-complete-audit.json').read_text()))

prefixes=tuple('source'+str(number)+'-' for number in range(209,215))
files={f.name:f for f in p.iterdir() if f.is_file() and f.suffix in allowed and f.name.startswith(prefixes)}
files.update({f.name:f for f in p.glob('implement-source209-*.py')})
add(files,['implement-source210-bytecode-fixes.py','audit-source209-through214-patches.py','audit-source214-controls.py',
           'check-bytecode208.py','static-bytecode208.py','test-bytecode-controls-next.py','freeze-bytecode-candidate.py',
           'run-source213-controls.py','run-source214-controls.py',Path(__file__).name])
package('source214-shared-closure-draft-and-controls',files,json.loads((p/'source214-controls-audit.json').read_text()))

# Include only closed strict results and immutable launch/source receipts.
# Live gate/broad logs are deliberately not packaged as completed evidence.
names=['source215-base.json','source215-manifest.json','source215-complete.patch','source215-patch-replay-and-modes-audit.json','audit-source215-patch.py',
       'source215-validation-launch.json','run-source215-validation.py','test-bytecode-controls215.py','test-bytecode-broad215.py',
       'check-bytecode208.py','static-bytecode208.py','freeze-bytecode-candidate.py',Path(__file__).name]
for label in ['check','fmt','clippy','diff']:
    result=json.loads((p/('source215-'+label+'-result.json')).read_text())
    assert result['exit_code']==0 and result['source_unchanged']
    names += ['source215-'+label+suffix for suffix in ['-command.json','-result.json','.log']]
package('source215-shared-closure-draft',{name:p/name for name in names},dict(
    status='isolated shared-closure draft; runtime validation running',inputs=418,strict_checks='passed',
    supervisor=json.loads((p/'source215-validation-launch.json').read_text())['pid'],
    qualification='Source214 passes five original controls and still fails active-call code mutation. Source215 repairs a subsequently identified missing live-vector census increment in direct constant-vector copying, and adds a 20-case census/identity control. This archive contains no source215 runtime verdict. No implementation from this separate draft is applied to the task branch. Full shared-string/VM architecture, broad validation and performance criteria remain open.'))
