from pathlib import Path
import hashlib
import json
import subprocess
import sys

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/bytecode-closure/emaxx'
tag, description = sys.argv[1:]
base = '21d20f0eec08f3c013d5d3eb3bd6e9cfc16b3199'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
files = [*root.joinpath('src').rglob('*.rs'), *root.joinpath('tests').rglob('*'),
         *root.joinpath('.cargo').glob('*')]
files += [root / name for name in [
    'Cargo.toml', 'Cargo.lock', 'build.rs', 'tools/ttydiff.py',
    'tools/fixtures/fieldnotes.org', 'tools/fixtures/fake_lsp_server.py',
    'compat/emacs_compat_runner.el', 'src/lisp/bytecode/fixture-oracle-30.2.elc',
    'src/lisp/bytecode/fixture-oracle2-30.2.elc', 'src/lisp/bytecode/fixture-oracle3-30.2.elc']]
manifest = {str(f.relative_to(root)): sha(f) for f in sorted(set(files)) if f.is_file()}
paths = ['src', 'tests', 'Cargo.toml', 'Cargo.lock', 'build.rs', '.cargo',
         'compat/emacs_compat_runner.el', 'tools/ttydiff.py',
         'tools/fixtures/fieldnotes.org', 'tools/fixtures/fake_lsp_server.py']
patch = subprocess.check_output(['git', 'diff', '--binary', base, '--', *paths], cwd=root)
untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '--', *paths], cwd=root, text=True).splitlines()
for name in untracked:
    result = subprocess.run(['git', 'diff', '--no-index', '--binary', '--', '/dev/null', name], cwd=root, capture_output=True)
    assert result.returncode == 1 and not result.stderr
    patch += result.stdout
with (p / (tag + '-complete.patch')).open('xb') as stream:
    stream.write(patch)
for suffix, record in [('-manifest.json', manifest), ('-base.json', {
        'commit': base, 'worktree': str(root), 'inputs': len(manifest),
        'changes': description, 'complete_patch_includes_untracked': untracked})]:
    with (p / (tag + suffix)).open('x') as stream:
        json.dump(record, stream, indent=2)
        stream.write('\n')
print(tag, len(manifest), sha(p / (tag + '-complete.patch')))
