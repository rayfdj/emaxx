from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve();root=p.parents[2]
out=root/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest()
tree=ast.parse((p/'package-source196-failure-and197-results.py').read_text())
node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
names=['source220-controls-audit.json','audit-source220-controls.py','source220-gate-inventory.txt',
       'source220-gate-controls-command.json','source220-gate-controls-result.json','source220-gate-controls.log',
       'source220-gate-build-command.json','source220-gate-build-result.json','source220-gate-build.log',
       'source220-validation-result.json','source220-validation-driver.log','run-source220-validation.py',
       'source220-broad-launch.json','run-source220-broad.py','source220-gate-broad-command.json',
       'test-string-broad219.py','test-string-controls219.py',Path(__file__).name]
scope=json.loads((p/'source220-controls-audit.json').read_text())
scope['broader_stage']={'supervisor':json.loads((p/'source220-broad-launch.json').read_text())['pid'],
                       'inventory':len(json.loads((p/'source220-gate-broad-command.json').read_text())['selected_inventory']),
                       'outcome':'running; no runtime verdict in this archive'}
package('source220-string-controls-and-broad-launch',{name:p/name for name in names},scope)
