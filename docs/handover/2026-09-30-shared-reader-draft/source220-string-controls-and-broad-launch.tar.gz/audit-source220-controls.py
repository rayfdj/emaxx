from pathlib import Path
import ast,hashlib,json,re
p=Path(__file__).parent.resolve();root=p.parent/'recovered-2026-09-30/string-bytes/emaxx'
sha=lambda file:hashlib.sha256(file.read_bytes()).hexdigest()
read=lambda name:json.loads((p/name).read_text())
manifest=read('source220-manifest.json');assert len(manifest)==421
assert all(sha(root/name)==digest for name,digest in manifest.items())
tree=ast.parse((p/'audit-shared-reader196-fresh-selected.py').read_text())
node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='audit_log')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<raw-auditor>','exec'))
command=read('source220-gate-controls-command.json');result=read('source220-gate-controls-result.json')
assert result['exit_code']==101 and result['source_unchanged']
assert sha(p/'source220-gate-libtest')==command['binary_sha256']
names=command['selected_inventory']
assert len(names)==12 and set(read('source216-gate-controls-command.json')['selected_inventory'])<=set(names)
failed=audit_log(names,(p/'source220-gate-controls.log').read_text(),10,2)
assert failed==['lisp::primitives::tests::bytecode_code_mutation_during_active_call_matches_gnu',
               'lisp::primitives::tests::canonical_string_bytes_preserve_gnu_characters_mutation_and_clear']
assert 'Signal("Invalid character: 55296")' in (p/'source220-gate-controls.log').read_text()
old_driver=read('source220-validation-result.json')
assert [item['stage'] for item in old_driver]==['check','strict','gate-controls']
record=dict(status='failed focused runtime controls',passed=10,failed=2,ignored=0,
            inputs_verified=421,binary_sha256=command['binary_sha256'],failing_names=failed,
            direct_byte_payload_control='passed: original storage bytes, sizes and in-place stores at 1/17/257/4097 bytes',
            original_supervisor='67724 exited after focused controls; stale source219 receipt check prevented the planned broad stage',
            qualification='The ordinary GNU fixture passes, but Emaxx evaluation rejects character 55296 (a surrogate) through the remaining character-to-Rust-char producer. Later expressions in that failed test are not passing coverage. Active-call code mutation remains (41 194), expected (67 194). The separately launched broader stage retains every affected-module name. No complete string/bytecode architecture or performance claim.',
            raw_hashes={name:sha(p/name) for name in ['source220-gate-controls-command.json','source220-gate-controls-result.json','source220-gate-controls.log','source220-validation-result.json','run-source220-validation.py']})
with (p/'source220-controls-audit.json').open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps(record,indent=2))
