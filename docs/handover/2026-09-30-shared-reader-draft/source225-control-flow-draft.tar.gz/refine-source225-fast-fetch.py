from pathlib import Path

p = Path(__file__).parent.resolve()
file = p / 'source225-proposed/src/lisp/bytecode/vm.rs'
s = file.read_text()
s = s.replace('enum FastExit {\n    Slow,', 'enum FastExit {\n    Slow(super::Instr),\n    Error(super::ByteCodeError),', 1)
s = s.replace('    let mut instruction_start;', '    let mut instruction: super::Instr;', 1)
s = s.replace('''            *pc = instruction_start;
            return FastExit::Slow;''', '''            *pc = instruction.offset;
            return FastExit::Slow(instruction);''', 1)
s = s.replace('''        instruction_start = at;
        let Ok(instr) = super::fetch_instruction(code, at, object.constants.len()) else {
            *pc = at;
            return FastExit::Slow;
        };
        let op = instr.op;
        at += instr.len;''', '''        instruction = match super::fetch_instruction(code, at, object.constants.len()) {
            Ok(instr) => instr,
            Err(error) => {
                *pc = at;
                return FastExit::Error(error);
            }
        };
        let op = instruction.op;
        at += instruction.len;''', 1)
start = s.index('            match exit {', s.index("let result = 'run: loop"))
end = s.index('            last_instruction = Some(instr);', start)
s = s[:start] + '''            last_instruction = None;
            // Carry the already fetched instruction into the slow dispatch.
            // No callback runs between these loops, so fetching it again
            // would add work without observing another Lisp mutation.
            let instr = match exit {
                FastExit::Return(value) => breturn!(value),
                FastExit::QuitCheck => {
                    crate::lisp::native_comp::maybe_gc(interp, env);
                    interp.maybe_quit(env)?;
                    continue;
                }
                FastExit::Slow(instr) => instr,
                FastExit::Error(error) => return Err(LispError::Signal(error.to_string())),
            };
''' + s[end:]
assert 'return FastExit::Slow;' not in s
assert 'instruction_start' not in s
file.write_text(s)
print('Prepared one fetch per instruction across the fast/slow dispatch boundary')
