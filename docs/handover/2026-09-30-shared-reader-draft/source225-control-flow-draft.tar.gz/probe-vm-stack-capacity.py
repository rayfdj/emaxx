from pathlib import Path
import hashlib, json, os, subprocess

p = Path(__file__).parent.resolve()
recovered = p.parent / 'recovered-2026-09-30'
fixture = p / 'vm-stack-capacity.el'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
editors = {
    'gnu': (recovered / 'emacs/src/emacs', recovered / 'emacs/src/emacs.pdmp', recovered / 'emacs/src/bytecode.c'),
    'emaxx207': (recovered / 'eval-frames/emaxx/target/frame-validation/release/emaxx',
                 recovered / 'eval-frames/emaxx/target/frame-validation/release/emaxx.pdmp',
                 recovered / 'eval-frames/emaxx/src/lisp/bytecode/vm.rs'),
}
prior = json.loads((p / 'source207-ordinary-runtime-cons-mutation-emaxx.command.json').read_text())
for f in editors['emaxx207'][:2]:
    assert sha(f) == prior['inputs'][str(f)]
records = []
for name, inputs in editors.items():
    command = [str(inputs[0]), '-Q', '--batch', '-l', str(fixture)]
    identities = {str(f): sha(f) for f in [fixture, *inputs]}
    env = {'LANG': 'C', 'LC_ALL': 'C', 'EMAXX_GC_VERIFY': '1'}
    with (p / ('vm-stack-capacity-' + name + '-command.json')).open('x') as stream:
        json.dump(dict(command=command, working_directory=str(p), environment_override=env, inputs=identities), stream, indent=2)
    result = subprocess.run(command, cwd=p, env={**os.environ, **env}, capture_output=True, timeout=120)
    for suffix, data in [('stdout', result.stdout), ('stderr', result.stderr)]:
        with (p / ('vm-stack-capacity-' + name + '.' + suffix)).open('xb') as stream:
            stream.write(data)
    record = dict(editor=name, exit_code=result.returncode, inputs_unchanged=all(sha(Path(f)) == digest for f, digest in identities.items()),
                  stdout_sha256=hashlib.sha256(result.stdout).hexdigest(), stderr_sha256=hashlib.sha256(result.stderr).hexdigest())
    with (p / ('vm-stack-capacity-' + name + '-result.json')).open('x') as stream:
        json.dump(record, stream, indent=2)
    assert result.returncode == 0 and not result.stderr and record['inputs_unchanged']
    records.append(record)
    print(name, result.stdout.decode(), flush=True)
record = dict(results=records, qualification='Ordinary same-input capacity diagnostic on validated source207, not a timing or source223 result. GNU source/native ABI matches but is not the frozen Darwin executable. No source changes. GNU allocates 512K Lisp words including frame headers; current Rust reserves 256K words and separate host frame storage. Full stack layout/capacity/accounting remains open.')
with (p / 'vm-stack-capacity-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
