from pathlib import Path
import hashlib, json

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/string-bytes/emaxx'
manifest = json.loads((p / 'source224-manifest.json').read_text())
assert all(hashlib.sha256((root / name).read_bytes()).hexdigest() == digest for name, digest in manifest.items())
draft = p / 'source225-proposed'
draft.mkdir()

def save(name, data):
    target = draft / name
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('x') as stream:
        stream.write(data)

name = 'src/lisp/bytecode.rs'
s = (root / name).read_text()
s = s.replace('    /// A jump destination lies outside the code string.\n    JumpOutOfRange',
              '    /// A diagnostic jump destination lies outside the code string.\n    #[cfg(test)]\n    JumpOutOfRange', 1)
s = s.replace('            ByteCodeError::JumpOutOfRange {', '            #[cfg(test)]\n            ByteCodeError::JumpOutOfRange {', 1)
start = s.index('    match instr.op {', s.index('fn fetch_instruction('))
end = s.index('    Ok(instr)', start)
s = s[:start] + '''    if let Op::VarRef(index)
        | Op::VarSet(index)
        | Op::VarBind(index)
        | Op::Constant(index)
        | Op::Constant2(index) = instr.op
        && usize::from(index) >= constants_len
    {
        return Err(ByteCodeError::ConstantOutOfRange {
            offset,
            index: usize::from(index),
            constants_len,
        });
    }
    // bytecode.c only uses a branch or handler destination when control
    // transfers there. An untaken branch must not inspect it. The next
    // decode bounds-checks the actual PC before reading any bytes, so even
    // an invalid taken branch cannot perform an out-of-bounds Rust access.
''' + s[end:]
save(name, s)

name = 'src/lisp/primitives/tests.rs'
s = (root / name).read_text() + '''

#[test]
fn unused_bytecode_destinations_follow_actual_control_flow() {
    let fixture = include_str!("../../../tests/fixtures/bytecode-unused-destinations.el");
    let program = fixture.trim().strip_prefix("(prin1")
        .expect("ordinary fixture starts with prin1")
        .strip_suffix(')').expect("ordinary fixture closes prin1");
    let expected = include_str!("../../../tests/fixtures/bytecode-unused-destinations.expected").trim_end();
    assert_oracle_contract_matches_interpreter(program, expected, "unused bytecode destinations");
}
'''
save(name, s)

name = 'src/lisp/bytecode/vm.rs'
s = (root / name).read_text() + '''

#[cfg(test)]
#[test]
fn taken_bytecode_branch_outside_storage_errors_without_leaking_a_frame() {
    let mut interp = Interpreter::new();
    let mut env = Env::new();
    let code = primitives::bytes_to_shared_unibyte_value(&[130, 255, 255]);
    let function = Value::allocated_closure(&[
        Value::Integer(0), code, Value::vector([]), Value::Integer(0),
    ]);
    let Kind::Closure(closure) = function.kind() else {
        panic!("actual closure");
    };
    let stack_before = interp.bc_stack.len();
    let roots_before = interp.bc_functions.len();
    let error = execute_closure(&mut interp, closure, &[], &mut env)
        .expect_err("the actual next fetch must check the string boundary");
    assert!(matches!(error.kind(), LispErrorKind::Signal(message)
        if message == "byte code ran off the end of its program"));
    assert_eq!(interp.bc_stack.len(), stack_before);
    assert_eq!(interp.bc_functions.len(), roots_before);
}
'''
save(name, s)
save('tests/fixtures/bytecode-unused-destinations.el', (p / 'bytecode-unused-destinations.el').read_text())
save('tests/fixtures/bytecode-unused-destinations.expected', (p / 'bytecode-unused-destinations-gnu.stdout').read_text() + '\n')
print('Prepared the actual-control-flow repair and GNU/Rust-boundary controls without editing source224')
