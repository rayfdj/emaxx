from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
tree = ast.parse((p / 'package-source196-failure-and197-results.py').read_text())
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected'}
for stem, folder, audit, extra in [
    ('source204-linux-frozen', 'linux-source204-frozen-artifacts', 'source204-linux-frozen-complete-audit.json',
     ['source204-linux-frozen-final-state.json', 'source204-linux-frozen-ci.log', 'source204-linux-frozen-download.json', 'verify-complete-frozen-receipts.py']),
    ('source204-exact-census-incomplete', 'linux-source204-census-artifacts', 'source204-exact-census-v1-audit.json',
     ['source204-census-diagnosis-final-state.json', 'source204-census-diagnosis-ci.log', 'source204-census-diagnosis-download.json', 'audit-source204-exact-census-v1.py', 'source204-census-inspected-abi-v3.txt', 'source204-census-diagnosis-local-checks-v3.json']),
]:
    directory = p / folder
    files = {folder + '/' + str(f.relative_to(directory)): f for f in directory.rglob('*') if f.is_file() and f.suffix in allowed}
    for name in [audit, *extra, Path(__file__).name]:
        files[name] = p / name
    package(stem, files, json.loads((p / audit).read_text()))
