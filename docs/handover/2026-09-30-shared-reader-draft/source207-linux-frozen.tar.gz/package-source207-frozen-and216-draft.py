from pathlib import Path
import ast, gzip, hashlib, io, json, re, tarfile

p=Path(__file__).parent.resolve()
root=p.parents[2]
out=root/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda name:json.loads((p/name).read_text())
tree=ast.parse((p/'package-source196-failure-and197-results.py').read_text())
node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
allowed={'.json','.log','.txt','.py','.patch','.stdout','.stderr','.el','.expected'}

base=p/'linux-source207-frozen-artifacts'
files={str(f.relative_to(p)):f for f in base.rglob('*') if f.is_file() and f.suffix in allowed}
for name in ['source207-linux-frozen-final-state.json','source207-linux-frozen-ci.log','source207-linux-frozen-download.json','source207-linux-frozen-complete-audit.json','collect-source207-frozen.py','verify-complete-frozen-receipts.py',Path(__file__).name]:
    files[name]=p/name
package('source207-linux-frozen',files,read('source207-linux-frozen-complete-audit.json'))

names=['source215-gate-broad-command.json','source215-gate-broad-result.json','source215-gate-broad.log',
       'source215-validation-result.json','source215-validation-driver.log','source215-broad-failure-audit.json',
       'audit-source215-broad.py','source215-gate-inventory.txt','test-bytecode-broad215.py',
       'source215-locale-replay-command.json','source215-locale-replay-result.json','source215-locale-replay.log',
       'source215-constructor-fixtures.el','source215-constructor-fixtures-command.json','source215-constructor-fixtures-result.json',
       'source215-constructor-fixtures.stdout','source215-constructor-fixtures.stderr',
       'diagnose-source215-broad.py','audit-source215-diagnosis.py','source215-broad-diagnosis-audit.json',
       'source215-manifest.json','source215-base.json','source215-complete.patch',Path(__file__).name]
package('source215-broad-failure-and-diagnosis',{name:p/name for name in names},dict(
    original_broad=read('source215-broad-failure-audit.json'),diagnosis=read('source215-broad-diagnosis-audit.json')))

names=['source216-base.json','source216-manifest.json','source216-complete.patch','source216-patch-replay-and-modes-audit.json',
       'audit-source216-patch.py','source216-validation-launch.json','run-source216-validation.py',
       'test-bytecode-controls216.py','test-bytecode-broad216.py','check-bytecode208.py','static-bytecode208.py',
       'freeze-bytecode-candidate.py',Path(__file__).name]
for stage in ['check','fmt','clippy','diff']:
    result=read('source216-'+stage+'-result.json')
    assert result['exit_code']==0 and result['source_unchanged']
    raw=(p/('source216-'+stage+'.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:',raw,re.M)
    if stage in ['fmt','diff']:assert not raw
    names+=['source216-'+stage+suffix for suffix in ['-command.json','-result.json','.log']]
package('source216-bytecode-fixture-repair-draft',{name:p/name for name in names},dict(
    status='strict checks pass; selected and broader runtime validation launched',inputs=418,
    supervisor=read('source216-validation-launch.json')['pid'],
    qualification='Source215 runtime unchanged; three GNU-invalid unit-test constructors now use genuine unibyte code strings and ordinary vectors. Every original behavior assertion is preserved. Validation helpers restore the existing grouped gate C locale. Ten focused controls and all 848 broader module tests include the unresolved active-call mutation failure. This archive assigns no source216 runtime verdict. Separate draft only; no bytecode implementation applied to the task branch.'))
