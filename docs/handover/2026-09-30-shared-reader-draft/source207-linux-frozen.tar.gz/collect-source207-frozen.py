from pathlib import Path
import json, subprocess, time

p = Path(__file__).parent.resolve()
repo = 'rayfdj/emaxx'
run = '36775569711'
head = '092fef676e7667332349b12fd9b63539dd39072b'

def save(name, data):
    with (p / name).open('x') as stream:
        json.dump(data, stream, indent=2)
        stream.write('\n')

state = json.loads(subprocess.check_output(
    ['gh', 'run', 'view', run, '--repo', repo, '--json',
     'databaseId,headSha,status,conclusion,url,jobs'], text=True))
assert state['status'] == 'completed' and state['conclusion'] == 'success'
assert state['headSha'] == head
save('source207-linux-frozen-final-state.json', state)
with (p / 'source207-linux-frozen-ci.log').open('x') as stream:
    subprocess.run(['gh', 'run', 'view', run, '--repo', repo, '--log'],
                   stdout=stream, stderr=subprocess.STDOUT, check=True)
destination = p / 'linux-source207-frozen-artifacts'
assert not destination.exists()
command = ['gh', 'run', 'download', run, '--repo', repo, '--dir', str(destination)]
start = time.monotonic()
result = subprocess.run(command, text=True, capture_output=True)
save('source207-linux-frozen-download.json', dict(command=command,
     exit_code=result.returncode, elapsed_seconds=time.monotonic()-start,
     stdout=result.stdout, stderr=result.stderr))
result.check_returncode()
summaries = list(destination.rglob('summary.json'))
assert len(summaries) == 1, summaries
subprocess.run(['python3', str(p / 'verify-complete-frozen-receipts.py'),
                str(summaries[0].parent), head, run,
                str(p / 'source207-linux-frozen-complete-audit.json')], check=True)
