from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
out = p.parents[2] / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
c = p.parent / 'recovered-2026-10-05/native-bytecode-inline/emaxx'
manifest = read('source301-manifest.json')
assert len(manifest) == 532 and all(sha((c / n).read_bytes()) == h for n, h in manifest.items())
portable = read('source301-portable-draft-audit.json')
assert all(r['inputs'] == 532 and r['bytes_and_modes'] == 'exact' and sha((p / r['patch']).read_bytes()) == r['sha256'] for r in portable['patches'])
snapshots = p / 'source301-launch-snapshot'
snapshots.mkdir()
files = {}
for name in ['source301-validation-state.json', 'native-bytecode-inlining-selection-closed-state.json',
             'native-bytecode-inlining-performance-sequence-closed-state.json']:
    target = snapshots / name
    with target.open('xb') as f:
        f.write((p / name).read_bytes())
    files[str(target.relative_to(p))] = target
helpers = ['prepare-native-bytecode301.py', 'prepare-native-bytecode-evidence301.py',
           'run-source301-validation.py', 'replay-native-bytecode301.py',
           'audit-native-bytecode-inline-selected.py', 'compare-source301-generated-loaded.py',
           'compare-source300-generated-loaded.py', 'compare-source292-generated-loaded.py',
           'compare-vm-dispatch-fixtures.py', 'compare-buffer-line-broad-probe.py',
           'native_fixed_validation_support.py', 'verify-existing-portable-draft.py',
           'finish-native-bytecode-inlining-selected-closed.py', 'measure-native-bytecode-inlining.py',
           'audit-native-bytecode-inlining-performance.py', 'finish-native-bytecode-inlining-performance-closed.py',
           'source301-manifest.json', 'source301-static-review.json', 'source301-portable-draft-audit.json',
           'source301-portable-incremental.patch', 'source301-portable-complete.patch',
           'source300-application-decision.json', 'source300-native-helper-symbol.json',
           'source300-manifest.json', 'source300-selected-audit.json',
           'source300-gate-inventory.log', 'source300-release-inventory.log',
           'source297-full-validation-launch.json', 'package-source196-failure-and197-results.py', Path(__file__).name]
for name in helpers:
    files[name] = p / name
for stage in ['cache-clone', 'fresh-crate', 'fresh-gate-crate', 'fresh-release-crate', 'fmt', 'check', 'clippy', 'diff']:
    for suffix in ['-command.json', '-result.json', '.log']:
        f = p / ('source301-' + stage + suffix)
        assert f.exists()
        files[f.name] = f
package('source301-native-bytecode-inline-draft', files, dict(
    status='portable unapplied inline-only source301 draft; full validation/timing pending',
    portable=portable, source_inputs_verified=532,
    qualification='All source bytes/modes replay. Strict source301 checks have zero warnings. Immutable launch snapshots do not imply selected/comparison/performance completion; inspect the live/final coordinator receipts when resuming. Source300 remains held after the original192-process diagnostic with two native-transition regressions. Applied runtime remains source297. The queued three-way comparison retains original297, default300 and inline301, all16 workloads and every unfavorable result. No full-goal completion claim.',
    goal_complete=False))
