from pathlib import Path
import hashlib,json,os,subprocess,time
project=Path('/Users/nbmhqa186/projects/emaxx');p=project/'target/runtime-goal/resume-2026-09-28';r=p.parent/'recovered-2026-09-30';root=r/'display-tables/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
for fixture in ['reader-hex-byte-boundary']:
 source=project/('tests/fixtures/'+fixture+'.el');form='(prin1 '+source.read_text()+')'
 for editor,binary in [('gnu',r/'emacs/src/emacs'),('emaxx',root/'target/frame-validation/release/emaxx')]:
  stem='source234-negative-v2-'+fixture+'-'+editor;command=[str(binary),'-Q','--batch','--eval',form]
  inputs={str(f):sha(f) for f in [binary,binary.with_suffix('.pdmp'),source]}
  with (p/(stem+'-command.json')).open('x') as f:json.dump({'command':command,'inputs':inputs,'environment_override':{'LANG':'C','LC_ALL':'C'}},f,indent=2)
  start=time.monotonic()
  with (p/(stem+'.stdout')).open('xb') as out,(p/(stem+'.stderr')).open('xb') as err:
   result=subprocess.run(command,cwd=root,env={**os.environ,'LANG':'C','LC_ALL':'C'},stdin=subprocess.DEVNULL,stdout=out,stderr=err,timeout=600)
  record={'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,'inputs_unchanged':all(sha(Path(name))==digest for name,digest in inputs.items())}
  with (p/(stem+'-result.json')).open('x') as f:json.dump(record,f,indent=2)
  print(stem,record,flush=True)
