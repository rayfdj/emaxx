from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve();out=p.parents[2]/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest()
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
allowed={'.json','.log','.txt','.py','.patch','.stdout','.stderr','.el','.expected','.md'}
def selected(patterns):
 return {str(f.relative_to(p)):f for pattern in patterns for f in p.glob(pattern) if f.is_file() and f.suffix in allowed}
def add_tree(files,directory):
 files.update({str(f.relative_to(p)):f for f in (p/directory).rglob('*') if f.is_file() and f.suffix in allowed})
read=lambda f:json.loads((p/f).read_text())
files=selected(['source234-release-*','source234-ordinary-*','source234-full-gate*','source234-macos-rust-*','source234-linux-rust-*','source234-manifest.json','source232-full-gate-fresh*','source232-macos-rust-*','audit-source234-*.py','verify-source234-*.py','audit-source232-macos-names.py','verify-source232-macos-rust.py','run-source234-*.py','run-source232-full-gate-fresh.py','build-source234.py','test-source234-broad.py','compare-source230-fixtures.py','source234-linux-launches.json','source234-linux-*-dispatch.json','source234-linux-*-initial-state.json','source234-*-result.json','source234-local-commit.json','source234-remote-head.json','source234-pr-body.md','launch-source234-linux.py',Path(__file__).name])
for directory in ['full-gate-source234','source234-linux-rust-artifacts','full-gate-source232-fresh']:add_tree(files,directory)
package('source234-complete-rust-and-selected',files,{'macos':read('source234-macos-rust-complete-audit.json'),'linux':read('source234-linux-rust-complete-audit.json'),'release':read('source234-release-audit.json'),'ordinary':read('source234-ordinary-audit.json'),'source232_prior_repair':read('source232-macos-rust-complete-audit.json'),'qualification':'Full source234 Rust passes on macOS and Linux; frozen comparison separately fails at rx. Main remains source174; no final goal or performance completion.'})
files=selected(['source234-linux-frozen-*','source234-rx-*','source234-negative-*','diagnose-source234-*.py','audit-source234-linux-frozen-failure.py','source234-manifest.json',Path(__file__).name]);add_tree(files,'source234-linux-frozen-artifacts')
package('source234-linux-rx-failure',files,read('source234-linux-frozen-failure-audit.json'))
files=selected(['source235-*','source236-*','source237-*','check-source235.py','static-source235.py','build-source235.py','run-source235-*.py','run-source236-*.py','run-source237-*.py','test-source236-tty.py','audit-source237-*.py','source238-manifest.json','source238-*.patch','source238-validation-launch.json','run-source238-validation.py','check-source238.py','static-source238.py','build-source238.py','test-source238-controls.py','validate-source238-rx.py',Path(__file__).name])
for stage in ['check','fmt','clippy','diff']:
 r=read('source238-'+stage+'-result.json');assert r['exit_code']==0 and r['source_unchanged']
 for suffix in ['-command.json','-result.json','.log']:
  name='source238-'+stage+suffix;files[name]=p/name
package('source237-display-validation-and238-rx-draft',files,{'display_units':read('source237-tty-unit-audit.json'),'display_terminal':read('source237-selected-terminal-audit.json'),'source238':'Separate 446-input combined candidate contains the source237 renderer and reader/mapconcat repairs. Only strict checks are complete; 103 selected gate controls, ordinary build and upstream rx tests are active. No source238 runtime repair claim.','earlier_failures':'Source235 has five compile errors. Source236 corrects API usage but fails three unwrap Clippy lints. Source237 replaces those with explained expects and passes strict/unit/selected terminal validation. The first TTY audit used a zero-ignore auditor and rejected existing ignores; an attempted helper launch before its file existed ran no tests. All retained; no weakening of assertions.','remaining_display_review':'Full 226-scenario terminal inventory and further display-table edge cases remain required: newline translation, generated stretch spaces/alignment, special extra-slot glyphs, control glyphs, non-Unicode glyph output and face precedence with no-font fallback are not fully differentially certified.','goal_complete':False})
