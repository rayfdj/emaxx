from pathlib import Path
import hashlib, json, os, subprocess, time

p = Path(__file__).parent.resolve()
repository = p.parents[2]
gnu = p.parent / 'recovered-2026-09-30/emacs/src/emacs'
fixture = repository / 'tests/fixtures/vector-closure-rounded-census.el'
expected_file = fixture.with_suffix('.expected')
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
inputs = {str(path): sha(path) for path in [gnu, gnu.with_suffix('.pdmp'), fixture, expected_file, Path(__file__)]}
command = [str(gnu), '--batch', '-Q', '--eval', '(prin1 ' + fixture.read_text() + ')']
control = 'lisp::primitives::tests::native_vector_and_closure_census_matches_gnu_word_layout'
variants = {
    'full': {'VALIDATION': 'rust', 'VALIDATION_RUST_FILTER': ''},
    'single': {'VALIDATION': 'rust-replay', 'VALIDATION_RUST_FILTER': control},
    'group': {'VALIDATION': 'rust-replay', 'VALIDATION_RUST_FILTER': 'lisp::primitives::tests::'},
}
records = []
for repetition in range(3):
    order = ['full', 'single', 'group'] if repetition % 2 == 0 else ['group', 'single', 'full']
    for variant in order:
        stem = 'source243-gnu-census-env-macos-' + str(repetition + 1) + '-' + variant
        overrides = {'LANG': 'C', 'LC_ALL': 'C', **variants[variant]}
        start = time.monotonic()
        result = subprocess.run(command, cwd=repository, env={**os.environ, **overrides},
                                stdin=subprocess.DEVNULL, capture_output=True, timeout=120)
        for suffix, raw in [('stdout', result.stdout), ('stderr', result.stderr)]:
            with (p / (stem + '.' + suffix)).open('xb') as out:
                out.write(raw)
        row = dict(repetition=repetition + 1, variant=variant, command=command,
                   environment_overrides=overrides, exit_code=result.returncode,
                   elapsed_seconds=time.monotonic() - start,
                   stdout_file=stem + '.stdout', stderr_file=stem + '.stderr',
                   stdout_sha256=hashlib.sha256(result.stdout).hexdigest(),
                   stderr_sha256=hashlib.sha256(result.stderr).hexdigest(),
                   expected_output=result.stdout == expected_file.read_bytes().rstrip(b'\n'),
                   inputs_unchanged=all(sha(Path(name)) == digest for name, digest in inputs.items()))
        records.append(row)
        print(repetition + 1, variant, result.returncode, result.stdout.decode(errors='replace'), flush=True)
assert all(row['exit_code'] == 0 and row['inputs_unchanged'] for row in records)
record = dict(status='diagnostic completed', inputs=inputs, runs=records,
              qualification='GNU-only macOS probe of the two recorded CI dispatch variables that differed between the previous Linux full/group failures and single-test pass. The original Lisp program, expected output and normal --batch -Q entry point are unchanged. All other environment is inherited and HOME is unchanged. This does not reproduce the Linux executable, complete CI environment, preceding Rust tests or their filesystem effects, and cannot clear the Linux failure. No timing or performance claim.')
with (p / 'source243-gnu-census-env-macos-result.json').open('x') as out:
    json.dump(record, out, indent=2)
