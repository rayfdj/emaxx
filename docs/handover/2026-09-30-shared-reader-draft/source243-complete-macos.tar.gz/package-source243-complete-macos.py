from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
read = lambda name: json.loads((p / name).read_text())
audit = read('source243-macos-rust-complete-audit.json')
names = read('source243-macos-rust-name-audit.json')
assert audit['status'] == names['status'] == 'passed'
assert audit['total_passed'] == 3093 and audit['library_ignored'] == 2
assert names['raw_names_verified'] == 2996 and audit['retained_files_verified'] == 4
assert sha((p / 'full-gate-source243/summary.json').read_bytes()) == audit['summary_sha256']
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr'}
patterns = ['source243-full-gate*', 'source243-macos-*', 'source243-manifest.json',
            'source243-*.patch', 'source243-gate-inventory.txt',
            'audit-source243-macos-names.py', 'verify-source243-macos-rust.py',
            'run-source243-full-gate.py', 'launch-source243-complete.py',
            'source243-gnu-census-env-macos*', 'diagnose-source243-gnu-census-env-macos.py',
            Path(__file__).name]
files = {str(file.relative_to(p)): file for pattern in patterns for file in p.glob(pattern)
         if file.is_file() and file.suffix in allowed}
for directory in ['full-gate-source243', 'source243-gnu-census-helper-macos']:
    files.update({str(file.relative_to(p)): file for file in (p / directory).rglob('*')
                  if file.is_file() and file.suffix in allowed})
smoke = read('source243-gnu-census-helper-macos/summary.json')
assert smoke['status'] == 'diagnostic completed' and smoke['failed_processes'] == 0
assert smoke['scope'] == 'GNU-only probes' and len(smoke['gnu_runs']) == 9 and not smoke['rust_runs']
assert smoke['inputs_unchanged'] and smoke['compiled_inputs_unchanged']
for item in smoke['gnu_runs']:
    assert item['passed'] and item['exit_code'] == 0 and not item['timed_out']
    for stream in ['stdout', 'stderr']:
        file = p / 'source243-gnu-census-helper-macos' / item[stream + '_file']
        assert sha(file.read_bytes()) == item[stream + '_sha256']
helper = root / 'tools/diagnose_gnu_census.py'
assert sha(helper.read_bytes()) == smoke['inputs'][str(helper)]
files['tools/diagnose_gnu_census.py'] = helper
files['workflow/frozen-run.yml'] = root / '.github/workflows/frozen-run.yml'
package('source243-complete-macos', files,
        dict(macos=audit, raw_names=names,
             gnu_helper_smoke={'runs': 9, 'failed': 0, 'rust_branch_executed': False},
             qualification='Source243 complete macOS Rust validation closes supervisor55867: 3,093 passes, two existing ignores, native identity, all 2,996 raw library names/verdicts and four retained input hashes verified. The frozen dirty checkout matches all 462 published runtime inputs at 8d4fcd39. Nine preceding GNU-only workflow-environment probes and the new helper\'s nine GNU-only smoke probes match on macOS; they do not resolve the Linux GNU census failure. The helper\'s Rust orchestration has not run yet. Complete terminal and exact-source Linux results remain pending. Main is unchanged and the full goal is incomplete.'))
