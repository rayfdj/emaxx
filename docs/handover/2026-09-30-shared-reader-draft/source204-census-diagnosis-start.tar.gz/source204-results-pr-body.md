Command input was decoded and copied independently by frame, menu, minibuffer and keyboard-macro loops. Share the incremental reader, preserve live keymap changes, and read the authoritative macro array and index. Replace macro saved-state host storage and global root registration with GNU's two conses and scoped roots.

Vector allocation rounded eight-byte-aligned objects to 16 bytes. Use Lisp-word alignment while preserving the existing 40-byte mark bitmap, and correct the resulting GNU pseudovector census differences. Ordinary two-slot vectors occupy 24 rather than 32 bytes. The free-list head table grows by 1,008 bytes; this remains part of the cost.

The original Linux suspended-bytecode failure was traced with its retained executable and image to a partially written cons-field selector on the stack. It falsely retained an unrelated cons. Represent retained fields by their actual one-word addresses, read cons payloads directly, and accept only GNU's valid conservative cons offsets. New baseline controls fail before the repair; both original survival/reclamation assertions remain unchanged.

Validation of the current source204 repair:

- Formatting, compiler, Clippy and diff checks pass with zero warnings. All 410 source inputs match the tested checkout.
- 596 gate and 596 release tests pass, including seven focused controls per profile.
- 39 exact ordinary GNU/Emaxx batch comparisons and one same-input terminal GC fixture pass. The original invalid-mode batch attempt remains failed: both editors matched but ran no interactive callbacks. Its unchanged fixture and original expectations pass in real terminal commands.
- Complete macOS Rust passes 3,059 tests, with two existing ignores and native artifact identity. All 2,962 library test names/verdicts and 410 input hashes are audited.
- Complete Linux Rust fails two census assertions after 2,232 passes: the first delta in each is 47 slots below expected. Both original reclamation assertions pass; four later groups and both Cargo stages did not run. The failed executable/image and raw logs are retained. [Exact-artifact diagnosis](https://github.com/rayfdj/emaxx/actions/runs/36770142335) is running.
- Complete terminal and Linux frozen comparisons are still running on unchanged runtime source204.

The preceding source201 passes complete macOS/Linux Rust gates (3,056/3,068 tests, two existing ignores each), all 226 terminal scenarios/686 comparisons, and the Linux frozen inventory (519 files/7,928 matching outcomes/1,038 successful processes). These remain source201 evidence, not full certification of source204. All earlier failed runs, diagnostics, raw evidence and limitations are preserved in the handover archives.

Keep this PR in draft while the Linux census failures are diagnosed and complete candidate validation remains unfinished. Main remains the source174 checkpoint. Symbol/object authority, physical allocation and GC accounting, final adversarial review, pinned Darwin evidence and the locked GNU performance criterion remain open. Static code and footprint reductions do not establish timing or performance parity. See HANDOVER.md and docs/runtime-representation-cons-roots-draft.md for reproduction and evidence.

A separately packaged bytecode draft preserves two architectural failures (88-byte detached record/slot storage versus GNU's 40-byte closure) and ordinary code-string mutation differences, including mutation during an active call. No bytecode repair is applied here. All seven allocation counters and memory-use-counts also remain unimplemented; those negative baselines are linked from HANDOVER.md.
