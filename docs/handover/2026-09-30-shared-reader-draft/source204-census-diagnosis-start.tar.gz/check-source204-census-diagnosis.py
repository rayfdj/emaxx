from pathlib import Path
import ast, hashlib, json, os, shutil, subprocess, sys, tempfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
sys.path.insert(0, str(root / 'tools'))
import diagnose_exact_census as driver

artifact = p / 'linux-source204-rust-artifacts/ordinary-linux-d186d40bf014ca53d0a2652b4e2f2d921c5cb009/rust'
driver.read_retained(artifact)
for name in ['tools/diagnose_exact_census.py', 'tools/diagnostics/exact-census-watch.py']:
    ast.parse((root / name).read_text())
rejected = []
for label in ['wrong_revision', 'wrong_summary_hash', 'wrong_binary_hash', 'traversal', 'duplicate_artifact', 'missing_inventory']:
    with tempfile.TemporaryDirectory(prefix='census-input-check-') as temporary:
        tmp = Path(temporary)
        for relative in ['summary.json', 'inventory.txt', 'retained-inputs/manifest.json']:
            target = tmp / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(artifact / relative, target)
        for source in (artifact / 'retained-inputs').rglob('*'):
            if source.is_file() and source.name != 'manifest.json':
                target = tmp / 'retained-inputs' / source.relative_to(artifact / 'retained-inputs')
                target.parent.mkdir(parents=True, exist_ok=True)
                os.link(source, target)
        manifest_file = tmp / 'retained-inputs/manifest.json'
        manifest = json.loads(manifest_file.read_text())
        if label == 'wrong_revision':
            summary = json.loads((tmp / 'summary.json').read_text())
            summary['git']['head'] = '0' * 40
            (tmp / 'summary.json').write_text(json.dumps(summary))
            manifest['gate_summary_sha256'] = driver.sha(tmp / 'summary.json')
        elif label == 'wrong_summary_hash':
            manifest['gate_summary_sha256'] = '0' * 64
        elif label == 'wrong_binary_hash':
            manifest['files'][0]['sha256'] = '0' * 64
        elif label == 'traversal':
            manifest['files'][0]['artifact'] = '../libtest'
        elif label == 'duplicate_artifact':
            manifest['files'].append(manifest['files'][0])
        elif label == 'missing_inventory':
            text = (tmp / 'inventory.txt').read_text()
            (tmp / 'inventory.txt').write_text(text.replace(driver.TESTS[0] + ': test\n', ''))
        manifest_file.write_text(json.dumps(manifest))
        try:
            driver.read_retained(tmp)
        except ValueError:
            rejected.append(label)
        else:
            raise AssertionError('accepted corrupt retained inputs: ' + label)

binary = artifact / 'retained-inputs/libtest'
commands = [['/usr/bin/nm', str(binary)]]
for start, stop in [('0xe71350', '0xe71450'), ('0xfcc9e0', '0xfcca60'), ('0xa56450', '0xa564a0'),
                    ('0xa576c0', '0xa57710'), ('0x10a37e0', '0x10a3830'), ('0xe21e70', '0xe21ec0'), ('0xe22020', '0xe22070')]:
    commands.append(['/usr/bin/objdump', '-d', '--start-address=' + start, '--stop-address=' + stop, str(binary)])
with (p / 'source204-census-inspected-abi.txt').open('x') as stream:
    for command in commands:
        stream.write(json.dumps(command) + '\n')
        stream.write(subprocess.check_output(command, text=True))
record = dict(status='passed local input checks; Linux replay not yet run', rejected=rejected,
              binary_sha256=driver.sha(binary),
              helpers={name: driver.sha(root / name) for name in ['tools/diagnose_exact_census.py', 'tools/diagnostics/exact-census-watch.py']},
              abi_evidence_sha256=driver.sha(p / 'source204-census-inspected-abi.txt'),
              qualification='Original artifacts accepted, six malformed-input variants rejected. Syntax checked; GDB observer awaits execution against its inspected Linux binary.')
with (p / 'source204-census-diagnosis-local-checks.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record, indent=2))
