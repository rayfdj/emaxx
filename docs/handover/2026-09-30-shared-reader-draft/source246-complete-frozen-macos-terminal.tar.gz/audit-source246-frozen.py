from pathlib import Path
import hashlib, json, subprocess, sys

p = Path(__file__).parent.resolve()
root = p.parents[2]
artifact = p / 'source246-linux-frozen-artifacts'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda path: json.loads(path.read_text())
download = read(p / 'source246-linux-frozen-download.json')
assert download['run_id'] == 36840217747
assert sha(p / 'source246-linux-frozen-artifact.zip') == download['archive_sha256']
assert len(download['files']) == 5204
assert all(sha(artifact / path) == digest for path, digest in download['files'].items())
summaries = list(artifact.rglob('summary.json'))
assert len(summaries) == 1
frozen = summaries[0].parent
head = 'aaf31ce70abc920f9fc3395c01db7ffc57328f81'
subprocess.run([sys.executable, str(p / 'verify-complete-frozen-receipts.py'), str(frozen),
                head, '36840217747', str(p / 'source246-linux-frozen-complete-audit.json')],
               cwd=root, check=True)
summary = read(summaries[0])
for file in summary['files']:
    directory = (frozen / file).with_suffix('.compat')
    execution = read(directory / 'execution.json')
    assert execution['contract_sha256'] == sha(frozen / 'contract.json')
    assert all(sha(directory / name) == digest for name, digest in execution['sha256'].items())
    pair = [read(directory / (runner + '.json')) for runner in ['oracle', 'emaxx']]
    assert {row['name']: (row['status'], row['expected']) for row in pair[0]['results']} == {
        row['name']: (row['status'], row['expected']) for row in pair[1]['results']}
capture = read(artifact / 'oracle-inputs/manifest.json')
verified = read(artifact / 'oracle-inputs/verification.json')
assert capture['status'] == 'captured' and verified['status'] == 'unchanged'
assert verified['capture_manifest_sha256'] == sha(artifact / 'oracle-inputs/manifest.json')
assert verified['files_verified'] == len(capture['files']) == 4
assert not capture['source_tracked_changes']
assert capture['source_commit'] == summary['provenance']['oracle_repo_commit']
for item in capture['files']:
    file = artifact / 'oracle-inputs' / item['artifact']
    assert file.stat().st_size == item['bytes'] and sha(file) == item['sha256']
assert capture['files'][0]['sha256'] == summary['provenance']['oracle_sha256']
record = dict(status='all raw execution hashes, paired outcomes and actual GNU inputs verified',
              files=519, outcomes=7928, successful_processes=1038, archive_members=5204,
              contract_sha256=sha(frozen / 'contract.json'), archive_sha256=download['archive_sha256'],
              oracle_capture=capture, oracle_after_verification=verified, goal_complete=False,
              qualification='Supplements the complete frozen inventory/process audit with every paired name/status/expectation and execution hash. The actual GNU executable/dump/configuration/Makefile were retained before the run and verified unchanged afterward. GNU and Emaxx each report 7670 passes, 47 expected failures and 211 skips. All 177 original compiler tests pass. The historical source244 GNU Eglot timeout remains failed evidence; this pass does not explain it. Full Linux Rust, pinned Darwin and performance remain unresolved.')
with (p / 'source246-linux-frozen-raw-integrity-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps({k: record[k] for k in ['status', 'files', 'outcomes', 'successful_processes']}))
