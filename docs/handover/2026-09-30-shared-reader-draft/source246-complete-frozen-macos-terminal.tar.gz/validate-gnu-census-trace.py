from pathlib import Path
import ast, hashlib, json, struct, subprocess

p = Path(__file__).parent.resolve()
root = p.parents[2]
observer = root / 'tools/diagnostics/gnu-census-snapshot.py'
driver = root / 'tools/diagnose_gnu_census_trace.py'
workflow = root / '.github/workflows/frozen-run.yml'
for path in [observer, driver]:
    ast.parse(path.read_text(), filename=str(path))
tree = ast.parse(observer.read_text())
namespace = dict(struct=struct, types={0: 'PVEC_NORMAL_VECTOR', 1: 'PVEC_FREE',
                                     12: 'PVEC_BOOL_VECTOR', 14: 'PVEC_HASH_TABLE'})
nodes = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in ['describe', 'heap']]
exec(compile(ast.Module(body=nodes, type_ignores=[]), '<GNU-heap-observer>', 'exec'), namespace)
describe = namespace['describe']
mark, pseudo = 1 << 63, 1 << 62
checked = []
for slots in [0, 1, 8, 511, 4094]:
    data = struct.pack('<QQ', slots | mark, 123)
    row = describe(4096, data)
    assert row['bytes'] == 8 * (slots + 1) and row['marked'] and row['kind_number'] == 0
    checked.append('normal-' + str(slots))
for bits, size in [(0, 16), (1, 24), (64, 24), (65, 32), (32768, 4112)]:
    row = describe(4096, struct.pack('<Qq', pseudo | (12 << 24), bits))
    assert row['bytes'] == size and not row['marked'] and row['kind_number'] == 12
    checked.append('bool-' + str(bits))
row = describe(4096, struct.pack('<QQ', mark | pseudo | (14 << 24) | (2 << 12) | 6, 0))
assert row['bytes'] == 72 and row['kind'] == 'PVEC_HASH_TABLE'
checked.append('nine-word-pseudovector')
try:
    describe(4096, struct.pack('<Qq', pseudo | (12 << 24), -1))
except ValueError:
    checked.append('reject-negative-bool-size')
else:
    raise AssertionError('negative bool size accepted')
block = bytearray(4096)
struct.pack_into('<Q', block, 0, mark | 8)
struct.pack_into('<Qq', block, 72, mark | pseudo | (12 << 24), 65)
remaining = 4088 - 104
struct.pack_into('<Q', block, 104, pseudo | (1 << 24) | ((remaining // 8 - 1) << 12))
large = bytearray(8 + 512 * 8)
struct.pack_into('<Q', large, 8, mark | 511)
blobs = {4096: block, 16384: large}

def memory(address, count):
    for base, data in blobs.items():
        if base <= address and address + count <= base + len(data):
            return bytes(data[address - base:address - base + count])
    raise ValueError('invalid synthetic read')

namespace.update(memory=memory, integer=lambda expr: {'vector_blocks': 4096, 'large_vectors': 16384}[expr])
records = namespace['heap']()
assert set(records) == {4096, 4168, 16392}
assert sum(row['bytes'] // 8 for row in records.values()) == 525
checked.append('complete-mixed-small-large-free-inventory')
struct.pack_into('<Q', block, 4088, 4096)
try:
    namespace['heap']()
except ValueError as error:
    assert 'chain' in str(error)
    checked.append('reject-cyclic-block-chain')
else:
    raise AssertionError('cycle accepted')
struct.pack_into('<Q', block, 4088, 0)
struct.pack_into('<Q', block, 0, mark | 4096)
try:
    namespace['heap']()
except ValueError as error:
    assert 'crosses' in str(error)
    checked.append('reject-cross-block-vector')
else:
    raise AssertionError('cross-block vector accepted')

parsed = json.loads(subprocess.check_output(['ruby', '-ryaml', '-rjson', '-e',
    'puts JSON.generate(YAML.load_file(ARGV[0]))', str(workflow)], text=True))
steps = parsed['jobs']['linux']['steps']
shells = 0
for index, step in enumerate(steps):
    if 'run' not in step:
        continue
    subprocess.run(['bash', '-n'], input=step['run'], text=True, check=True, capture_output=True)
    shells += 1
invocation = next(step for step in steps if step.get('name') == 'Execute the requested validation or diagnosis')['run']
assert 'gnu-census-trace)' in invocation
assert 'python3 tools/diagnose_gnu_census_trace.py --output target/frozen-ci/gnu-census-trace' in invocation
subprocess.run(['git', 'diff', '--check'], cwd=root, check=True)
record = dict(status='static and synthetic decoder checks pass', decoder_checks=checked,
              shell_blocks_checked=shells, files={str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
                                                for path in [observer, driver, workflow]},
              qualification='Python ASTs, complete workflow YAML, every shell block and vector-header/block traversal checks pass. Actual GDB ABI/symbol access has not run on Linux. Ordinary macOS smoke is separate and cannot certify the observer or explain the GNU census failure.')
with (p / 'gnu-census-trace-static-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps(record, indent=2))
