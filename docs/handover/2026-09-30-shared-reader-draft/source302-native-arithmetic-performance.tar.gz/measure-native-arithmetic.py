from pathlib import Path
import hashlib, json, os, subprocess, sys, time
p = Path(__file__).parent.resolve()
g = p.parent / 'rebuilt-2026-10-01/emacs'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p/n).read_text())
variants = {
 'source297':(p.parent/'recovered-2026-10-05/native-funcall-dispatch/emaxx','vm-dispatch-validation'),
 'source302':(p.parent/'recovered-2026-10-05/native-binary-arithmetic/emaxx','vm-dispatch-validation'),
}
inputs = {}
for tag, (directory,target) in variants.items():
    c = directory
    assert read(tag+'-selected-audit.json')['status'] == 'passed'
    manifest = read(tag+'-manifest.json')
    assert all(sha(c/n) == h for n,h in manifest.items())
    binary = c/'target'/target/'release/emaxx'
    for path,r in read(tag+'-ordinary-artifacts.json').items():
        assert sha(Path(path)) == sha(Path(r['immutable_copy'])) == r['sha256']
    for n in ('tools/core_runtime_perf.py','compat/core_runtime_perf.json','compat/core_runtime_perf.el'):
        assert sha(c/n) == read('source284-performance-result.json')['measurement_inputs'][str(p.parents[2]/n)]
    inputs[tag] = dict(root=c,binary=binary,native=p/(tag+'-core-native'),manifest=manifest)
state = dict(status='starting native preparation', rounds=3,
             schedule=[['source297','source302'],['source302','source297'],['source297','source302']],
             qualification='Three alternating repetitions of unchanged full16 pilot,192 normal editor processes. Applied297 is baseline;302 avoids redundant argument staging and primitive numeric conversion for native two-fixnum +/− after existing handler synchronization. All unfavorable samples and original width failures remain. No build/test/profile work overlaps timing. This diagnostic does not certify calibrated nine-round every-case3% acceptance.', results=[], goal_complete=False)
def save():
    (p/'native-arithmetic-performance-state.json').write_text(json.dumps(state,indent=2)+'\n')
def run(stage, tag, args):
    item = inputs[tag]
    command = [sys.executable,'-B','tools/core_runtime_perf.py',*args,'--source',str(g),'--oracle',str(g/'src/emacs'),'--emaxx',str(item['binary']),'--diagnostic']
    with (p/('native-arithmetic-performance-'+stage+'-command.json')).open('x') as f:
        json.dump(dict(command=command,working_directory=str(item['root']),source_manifest=tag+'-manifest.json',environment_overrides=dict(LANG='C',LC_ALL='C')),f,indent=2)
    state['status'] = 'running '+stage; save(); start=time.monotonic()
    with (p/('native-arithmetic-performance-'+stage+'.log')).open('xb') as log:
        r = subprocess.run(command,cwd=item['root'],env=dict(os.environ,LANG='C',LC_ALL='C'),stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
    result = dict(stage=stage,source=tag,exit_code=r.returncode,elapsed_seconds=time.monotonic()-start,
                  source_unchanged=all(sha(item['root']/n)==h for n,h in item['manifest'].items()))
    with (p/('native-arithmetic-performance-'+stage+'-result.json')).open('x') as f:json.dump(result,f,indent=2)
    state['results'].append(result);save();print(json.dumps(result),flush=True)
    assert result['exit_code']==0 and result['source_unchanged']
try:
    for tag in ('source302',):
        run(tag+'-prepare',tag,['prepare','--output',str(inputs[tag]['native'])])
    for item in inputs.values():
        for editor in ('oracle','emaxx'):
            artifact=json.loads((item['native']/editor/'artifact.json').read_text())
            assert artifact['completed'] and sha(item['native']/editor/'comp-test-funcs.eln')==artifact['sha256']
    process_list = subprocess.check_output(['/bin/ps','-axo','pid,ppid,command'],text=True)
    competing = [line for line in process_list.splitlines() if any(token in line for token in (
        'cargo build ', 'cargo test ', '/rustc ', 'tools/ttydiff.py', 'tools/serial_grouped_gate.py', '/usr/bin/sample '))]
    with (p/'native-arithmetic-performance-process-audit.json').open('x') as f:json.dump(dict(process_listing_sha256=hashlib.sha256(process_list.encode()).hexdigest(), competing_task_processes=competing, qualification='Unrelated host process details are not retained. No local build/test/profile competitor at timing entry.'),f,indent=2)
    assert not competing, competing
    for round_number,order in enumerate(state['schedule']):
        for tag in order:
            output=p/(tag+'-native-arithmetic-pilot-'+str(round_number))
            run(tag+'-pilot-'+str(round_number),tag,['pilot','--pilot-runner','both','--native-dir',str(inputs[tag]['native']),'--output',str(output)])
    state['status']='all diagnostic comparisons finished; raw audit required'
except Exception as error:
    state.update(status='diagnostic comparison stopped',error=repr(error))
finally:
    save()
    with (p/'native-arithmetic-performance-result.json').open('x') as f:json.dump(state,f,indent=2)
sys.exit(0 if state['status'].startswith('all diagnostic') else 1)
