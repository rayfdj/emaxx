from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
out = p.parents[2] / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected', '.h'}
selected = read('source302-selected-audit.json')
performance = read('native-arithmetic-performance-audit.json')
decision = read('source302-application-decision.json')
assert selected['status'] == 'passed' and selected['source_inputs_verified'] == 534
assert selected['ordinary_comparisons'] == 48
assert all(x['passed'] == 328 and x['failed'] == x['ignored'] == 0 for x in selected['profiles'].values())
assert performance['status'] == 'all 192 processes and actual results/modes verified'
assert read('native-arithmetic-performance-sequence-closed-result.json')['status'] == 'timing audited; source decision pending'
for audit in [selected, performance]:
    assert all(sha(Path(n).read_bytes()) == h for n, h in audit['evidence_files'].items())
baseline = read('source297-arithmetic-baseline-ordinary-native-binary-arithmetic-comparison.json')
assert baseline['passed'] and baseline['exact_match']
for editor in ('gnu', 'emaxx'):
    stem = 'source297-arithmetic-baseline-ordinary-native-binary-arithmetic-' + editor
    command, result = read(stem + '.command.json'), read(stem + '.result.json')
    assert all(sha(Path(n).read_bytes()) == h for n,h in command['inputs'].items())
    assert result == baseline['outcomes'][editor]
    assert result['exit_code'] == 0 and not result['timed_out'] and result['source_unchanged'] and result['inputs_unchanged']
    assert sha((p / (stem + '.stdout')).read_bytes()) == result['stdout_sha256']
    assert (p / (stem + '.stdout')).read_bytes() == (p / 'native-binary-arithmetic.expected').read_bytes().rstrip(b'\n')
    assert not (p / (stem + '.stderr')).read_bytes()
helpers = ['prepare-native-arithmetic302.py', 'prepare-native-arithmetic-evidence302.py',
           'run-source302-validation.py', 'replay-native-arithmetic302.py',
           'apply-native-arithmetic302.py', 'setup-source302-full-macos.py',
           'queue-source302-full-macos.py', 'audit-source302-selected-for-full.py',
           'audit-native-arithmetic-selected.py', 'compare-source302-generated-loaded.py',
           'compare-source300-generated-loaded.py', 'compare-source297-generated-loaded.py', 'compare-source292-generated-loaded.py',
           'compare-vm-dispatch-fixtures.py', 'compare-buffer-line-broad-probe.py',
           'native_fixed_validation_support.py', 'verify-existing-portable-arithmetic-draft.py',
           'finish-native-arithmetic-selected-closed.py',
           'source297-manifest.json', 'source297-selected-audit.json',
           'source297-gate-inventory.log', 'source297-release-inventory.log',
           'printer-varied-v3-293638f0.el', 'printer-varied-v3-gnu.stdout',
           'native-binary-arithmetic.el', 'native-binary-arithmetic.expected',
           'package-source196-failure-and197-results.py', Path(__file__).name]
files = {f.name: f for f in p.iterdir() if f.is_file() and f.suffix in allowed
         and f.name.startswith(('source302-', 'native-arithmetic-selection-', 'source297-arithmetic-baseline-'))}
files.update({name: p / name for name in helpers})
package('source302-native-arithmetic-selected', files, dict(
    status='closed fresh source302 selected validation',
    audit=dict(path='source302-selected-audit.json', sha256=sha((p / 'source302-selected-audit.json').read_bytes())),
    profiles={k: {f: v[f] for f in ['passed', 'failed', 'ignored']} for k, v in selected['profiles'].items()},
    source_inputs_verified=534, ordinary_comparisons=48,
    qualification='Source302 adds immediate two-fixnum native +/− after existing handler synchronization, retaining overflow and other-type fallbacks. Every original test/fixture remains.534 byte/mode replays, fresh builds, warning-free strict checks,328 selected passes/profile and48 actual GNU comparisons verify. New forced-native boundaries already match actual GNU on applied297. The full broad probe retains60 original width failures. Full-goal requirements remain open.', goal_complete=False))
files = {}
for tag in ['source297', 'source302']:
    for directory in sorted(p.glob(tag + '-native-arithmetic-pilot-*')) + [p / (tag + '-core-native')]:
        for f in directory.rglob('*'):
            if f.is_file() and f.suffix in allowed:
                files[str(f.relative_to(p))] = f
for f in p.iterdir():
    if f.is_file() and f.suffix in allowed and f.name.startswith('native-arithmetic-performance-'):
        files[f.name] = f
for name in ['measure-native-arithmetic.py', 'audit-native-arithmetic-performance.py',
             'finish-native-arithmetic-performance-closed.py', 'source302-application-decision.json',
             'package-source196-failure-and197-results.py', Path(__file__).name]:
    files[name] = p / name
package('source302-native-arithmetic-performance', files, dict(
    status='all192 actual process answers and execution modes verified',
    audit=dict(path='native-arithmetic-performance-audit.json', sha256=sha((p / 'native-arithmetic-performance-audit.json').read_bytes())),
    application_decision=decision,
    qualification='Applied297 and arithmetic302 run three alternating unchanged full16 pilots. All samples/startup/total/RSS/GC and unavailable-counter errors remain. Builds/tests/profiles are separate. This diagnostic does not certify calibrated nine-round/every-case3% acceptance or full-goal completion.', goal_complete=False))
