"""Check rejected weak-key name reads without calling an inferior process."""
from pathlib import Path
import ast
import contextlib
import hashlib
import io
import json
import struct
import sys
import types

root = Path(__file__).resolve().parents[3]
file = root / 'tools/diagnostics/exact-weak-root-watch.py'

class UnmappedMemory(Exception):
    pass

class Breakpoint:
    def __init__(self, *args, **kwargs):
        pass

class Inferior:
    def __init__(self):
        self.memory = {}

    def read_memory(self, address, length):
        if address >= 1 << 64:
            raise OverflowError('int too big to convert')
        if address not in self.memory:
            raise UnmappedMemory('unmapped control address')
        return self.memory[address][:length]

inferior = Inferior()
registers = {'$rdx': 0x1003, '$rdi': 0x3000}
fake = types.SimpleNamespace(
    Breakpoint=Breakpoint, MemoryError=UnmappedMemory, BP_WATCHPOINT=1, WP_WRITE=1,
    selected_inferior=lambda: inferior, parse_and_eval=lambda expr: registers[expr],
    execute=lambda *args, **kwargs: '',
)
nodes = [node for node in ast.parse(file.read_text()).body
         if isinstance(node, (ast.FunctionDef, ast.ClassDef, ast.Assign))]
namespace = {'gdb': fake, 'json': json, 'struct': struct,
             'os': types.SimpleNamespace(environ={'EMAXX_WATCH_KEY_HEAD': 'runtime-key'})}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(file), 'exec'), namespace)

def word(address, value):
    inferior.memory[address] = struct.pack('<Q', value)

word(0x3000, 0x4000)
word(0x1000, 0x2000)
word(0x2000, 0xfffffffffffffff8)
stream = io.StringIO()
with contextlib.redirect_stdout(stream):
    insertion = namespace['WeakInsertion']()
    assert insertion.stop() is False and insertion.stop() is False
    word(0x2000, 0x5000)
    word(0x5018, len(b'runtime-key'))
    word(0x5010, 0x6000)
    inferior.memory[0x6000] = b'runtime-key'
    assert insertion.stop() is False
    registers['$rdx'] = 0x1013
    word(0x1010, 0x2000)
    assert insertion.stop() is False
assert namespace['unreadable_weak_key_names'] == {'OverflowError': 2}
assert namespace['watched_keys'] == [0x1003, 0x1013] and insertion.enabled is False
records = [json.loads(line[11:]) for line in stream.getvalue().splitlines()
           if line.startswith('EXACT_ROOT ')]
assert len([r for r in records if r['event'] == 'unreadable weak-key name']) == 1
assert len([r for r in records if r['event'] == 'watch installed']) == 2
result = {'status': 'passed', 'overflow_candidates_recorded': 2,
          'valid_named_keys_watched': 2, 'events': records,
          'helper_sha256': hashlib.sha256(file.read_bytes()).hexdigest(),
          'qualification': 'Simulated inferior memory validates callback handling only; actual GDB and runtime results remain separate.'}
with Path(sys.argv[1]).open('x') as output:
    json.dump(result, output, indent=2)
print(json.dumps(result, indent=2))
