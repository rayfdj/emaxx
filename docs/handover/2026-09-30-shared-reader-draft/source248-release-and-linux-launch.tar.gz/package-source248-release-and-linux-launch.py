from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
ordinary = read('source248-ordinary-audit.json')
selected = read('source248-selected-audit.json')
assert not set(ordinary['fixtures']) & set(selected['fixtures'])
assert len(ordinary['fixtures']) + len(selected['fixtures']) == 70
release = read('source248-release-audit.json')
assert [group['passed'] for group in release['groups']] == [170, 953]
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected'}
patterns = ['source248-release-*', 'source248-ordinary-*', 'source248-gate-*-command.json',
            'source248-gate-inventory.txt', 'source248-selected-audit.json', 'source248-manifest.json',
            'source248-linux-*', 'source248-applied-*', 'audit-source248-release.py',
            'audit-source248-ordinary.py', 'publish-source248-applied.py', 'dispatch-source248-linux.py',
            'gnu-census-trace-argv*', Path(__file__).name]
files = {str(path.relative_to(p)): path for pattern in patterns for path in p.glob(pattern)
         if path.is_file() and path.suffix in allowed}
for path in (p / 'gnu-census-trace-argv-draft').rglob('*'):
    if path.is_file():
        files[str(path.relative_to(p))] = path
package('source248-release-and-linux-launch', files,
        dict(release=release, ordinary=ordinary, ordinary_total=70,
             linux_rust=read('source248-linux-rust-launch.json'),
             linux_frozen=read('source248-linux-frozen-launch.json'),
             observer_repair=read('gnu-census-trace-argv-static-audit.json'),
             qualification='Source248 release matches gate: 170 focused passes/two existing ignores and 953 affected passes. All 57 preceding ordinary controls pass in addition to thirteen selected fixtures, 70 distinct matches. Exact source/runtime artifact and raw result hashes are verified. Full Linux Rust36849791338 and frozen36849797068 launch on fa7578ac; full macOS/terminal remain active. The GNU diagnostic argument repair is only statically checked and still needs Linux execution. Complete correctness and the full goal remain open.'))
