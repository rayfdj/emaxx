from pathlib import Path
import hashlib, json, subprocess, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
sha = lambda data: hashlib.sha256(data).hexdigest()

def output(command):
    return subprocess.check_output(command, cwd=root, text=True).strip()

def save(name, record):
    with (p / name).open('x') as stream:
        json.dump(record, stream, indent=2)

prior = '2dd1dea85d6fbd9ed3017346d4d17348bdbbd329'
assert output(['git', 'branch', '--show-current']) == 'runtime-char-tables'
assert output(['git', 'rev-parse', 'HEAD']) == prior
assert not output(['git', 'diff', '--cached', '--name-only'])
manifest = json.loads((p / 'source248-manifest.json').read_text())
assert len(manifest) == 472
assert all(sha((root / name).read_bytes()) == digest for name, digest in manifest.items())
assert json.loads((p / 'source248-upstream-compiler-raw-audit.json').read_text())['outcomes_per_editor'] == 177
assert json.loads((p / 'source248-selected-audit.json').read_text())['affected_passes'] == 953
assert json.loads((p / 'source248-c-reference-review.json').read_text())['root_inputs'] == 472
paths = ['HANDOVER.md', 'docs/runtime-representation-progress.md',
         'docs/runtime-representation-correctness-recovery-draft.md',
         'src/lisp/primitives/coding.rs', 'src/lisp/primitives/dispatch/misc.rs',
         'src/lisp/primitives/tests.rs', 'tests/fixtures/coding-candidate-symbol-properties.el',
         'tests/fixtures/coding-candidate-symbol-properties.expected',
         'tests/fixtures/overriding-property-identity.el',
         'tests/fixtures/overriding-property-identity.expected']
stems = ['source248-compiler-and-complete-launch', 'source248-c-reference-and246-trace-failure']
archives = []
for stem in stems:
    base = 'docs/handover/2026-09-30-shared-reader-draft/' + stem
    record = json.loads((root / (base + '-manifest.json')).read_text())
    archive = root / (base + '.tar.gz')
    assert record['goal_complete'] is False
    assert sha(archive.read_bytes()) == record['archive']['sha256']
    assert archive.stat().st_size == record['archive']['bytes']
    with tarfile.open(archive) as contents:
        assert contents.getnames() == [item['path'] for item in record['files']]
        for item in record['files']:
            data = contents.extractfile(item['path']).read()
            assert len(data) == item['bytes'] and sha(data) == item['sha256']
    archives.append(record['archive'])
    paths.extend([base + '-manifest.json', base + '.tar.gz'])
subprocess.run(['git', 'diff', '--check'], cwd=root, check=True)
subprocess.run(['git', 'add', '--', *paths], cwd=root, check=True)
assert set(output(['git', 'diff', '--cached', '--name-only']).splitlines()) == set(paths)
subprocess.run(['git', 'diff', '--cached', '--check'], cwd=root, check=True)
subprocess.run(['git', '-c', 'user.name=Ray', '-c', 'user.email=26018378+rayfdj@users.noreply.github.com',
                'commit', '-m', 'Match GNU property lookup for coding translation symbols'], cwd=root, check=True)
head = output(['git', 'rev-parse', 'HEAD'])
assert not output(['git', 'status', '--porcelain'])
save('source248-applied-commit.json', dict(commit=head, runtime_source='source248',
     root_inputs=472, paths=paths, archives=archives, goal_complete=False))
command = ['git', 'push', 'origin', 'HEAD:refs/heads/runtime-char-tables']
result = subprocess.run(command, cwd=root, stdin=subprocess.DEVNULL, capture_output=True, text=True)
save('source248-applied-push.json', dict(command=command, exit_code=result.returncode,
     stdout=result.stdout, stderr=result.stderr))
result.check_returncode()
assert output(['git', 'ls-remote', '--heads', 'origin', 'refs/heads/runtime-char-tables']).split()[0] == head
body = (p / 'source248-applied-pr-body.md').read_text()
payload = p / 'source248-applied-pr-payload.json'
with payload.open('x') as stream:
    json.dump(dict(title='Share Lisp object fields and execute bytecode from live strings', body=body), stream)
updated = json.loads(output(['gh', 'api', 'repos/rayfdj/emaxx/pulls/79', '--method', 'PATCH', '--input', str(payload)]))
save('source248-applied-pr-update.json', updated)
verified = json.loads(output(['gh', 'api', 'repos/rayfdj/emaxx/pulls/79']))
assert verified['head']['sha'] == head and verified['draft'] and verified['body'] == body
assert verified['base']['sha'] == '21d20f0eec08f3c013d5d3eb3bd6e9cfc16b3199'
save('source248-applied-pr-verified.json', verified)
print(json.dumps(dict(status='evidence pushed and draft PR verified', head=head, runtime_source='source248',
     pull_request=verified['html_url'], main_unchanged=True, goal_complete=False)))
