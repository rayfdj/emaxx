from pathlib import Path
import json, re, subprocess

p = Path(__file__).parent.resolve()
root = p.parents[2]
head = 'fa7578ac04a697d45acb59bb296a8365541b29c9'

def save(name, value):
    with (p / name).open('x') as stream:
        json.dump(value, stream, indent=2)

assert subprocess.check_output(['git', 'ls-remote', '--heads', 'origin',
    'refs/heads/runtime-char-tables'], cwd=root, text=True).split()[0] == head
launches = []
for validation in ['rust', 'frozen']:
    command = ['gh', 'workflow', 'run', 'frozen-run.yml', '--repo', 'rayfdj/emaxx',
               '--ref', 'runtime-char-tables', '-f', 'validation=' + validation]
    result = subprocess.run(command, cwd=root, stdin=subprocess.DEVNULL,
                            capture_output=True, text=True)
    prefix = 'source248-linux-' + validation
    save(prefix + '-dispatch.json', dict(command=command, commit=head,
        exit_code=result.returncode, stdout=result.stdout, stderr=result.stderr))
    result.check_returncode()
    match = re.fullmatch(r'https://github.com/rayfdj/emaxx/actions/runs/(\d+)\s*', result.stdout)
    assert match, result.stdout
    run_id = int(match[1])
    state = json.loads(subprocess.check_output(['gh', 'run', 'view', str(run_id),
        '--repo', 'rayfdj/emaxx', '--json', 'status,conclusion,headSha,url'], cwd=root, text=True))
    assert state['headSha'] == head
    launch = dict(run_id=run_id, state=state, source_commit=head, runtime_source='source248',
        qualification='Full existing Linux validation of the exact pushed 472-input source248 checkpoint. Strict, selected, thirteen ordinary comparisons and all 177 original compiler tests pass locally. Complete source246 passes are historical; source246 Linux Rust and GNU GC diagnostic remain failed. No passing verdict is inferred from dispatch.')
    save(prefix + '-launch.json', launch)
    launches.append(launch)
print(json.dumps(launches))
