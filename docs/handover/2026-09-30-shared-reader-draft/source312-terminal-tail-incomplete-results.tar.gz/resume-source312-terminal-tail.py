from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).parent.resolve();read=lambda n:json.loads((p/n).read_text());sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
previous=read('source312-terminal-retry-command.json');audit=read('source312-macos-terminal-audit.json');root=Path(previous['working_directory']);manifest=read(previous['source_manifest'])
assert audit['status']=='failed' and audit['fully_matching_scenarios']==173 and audit['matching_comparisons']==374 and audit['unexecuted_comparisons']==312 and not audit['divergent_labels']
selection=previous['inventory'][173:];assert len(selection)==53 and selection[0]=='dired-batch-overwrite-decline';assert selection==[x['scenario'] for x in audit['partial_scenarios']]+audit['unstarted_scenarios']
inputs=dict(previous['inputs']);inputs[str(Path(__file__))]=sha(Path(__file__));assert all(sha(Path(n))==h for n,h in inputs.items())
command=previous['command']+selection
record=dict(command=command,working_directory=str(root),environment_override=previous['environment_override'],inputs=inputs,source_manifest=previous['source_manifest'],candidate_commit=previous['candidate_commit'],inventory=selection,preceding_successful_scenarios=173,expected_comparisons=312,qualification='Runs every remaining original scenario, beginning with the GNU readiness failure. Same executables/images/harness/actions and120-second startup deadline. Original complete attempt stays failed; this tail alone is not one complete226-scenario pass.')
(p/'source312-terminal-tail-command.json').open('x').write(json.dumps(record,indent=2));start=time.monotonic()
with (p/'source312-terminal-tail.log').open('xb') as log:r=subprocess.run(command,cwd=root,env=dict(os.environ,**previous['environment_override']),stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
result=dict(exit_code=r.returncode,elapsed_seconds=time.monotonic()-start,source_unchanged=all(sha(root/n)==h for n,h in manifest.items()),inputs_unchanged=all(sha(Path(n))==h for n,h in inputs.items()),goal_complete=False,raw_audit='required')
(p/'source312-terminal-tail-result.json').open('x').write(json.dumps(result,indent=2));print(result,flush=True)
