from pathlib import Path
import ast, hashlib, json, subprocess

p = Path(__file__).parent.resolve()
root = p.parents[2]
c = p.parent / 'recovered-2026-10-05/native-fixed-funcall/emaxx'
g = p.parent / 'rebuilt-2026-10-01/emacs'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p / n).read_text())
base = read('source292-applied-commit.json')['commit']
manifest = read('source292-manifest.json')
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == base
assert all(sha(root / n) == h for n, h in manifest.items())
assert read('single-line-performance-sequence-closed-result.json')['status'] == 'timing audited; source decision pending'
assert not c.exists()
c.parent.mkdir()
(c.parent / 'emacs').symlink_to(g, target_is_directory=True)
commands = [
    ['git', 'clone', '--shared', '--quiet', '--no-checkout', str(root), str(c)],
    ['git', '-C', str(c), 'sparse-checkout', 'init', '--no-cone'],
    ['git', '-C', str(c), 'sparse-checkout', 'set', '--no-cone',
     *sorted({'/' + n for n in manifest} | {'/tools/', '/compat/'})],
    ['git', '-C', str(c), 'checkout', '--detach', base],
]
for command in commands:
    subprocess.run(command, check=True)
assert all(sha(c / n) == h for n, h in manifest.items())
path = c / 'src/lisp/native_comp/runtime.rs'
before = path.read_text()
old = '''        if matches!(convention, NativeCallingConvention::Fixed) {
            let maximum = maximum.expect("a fixed subr has a finite maximum arity");
            let mut padded = smallvec::SmallVec::<[NativeWord; 8]>::new();
            padded.extend_from_slice(arguments);
            padded.resize(maximum, 0);
            Ok(unsafe { call_word_target(target, convention, &padded) })
        } else {
            Ok(unsafe { call_word_target(target, convention, arguments) })
        }
'''
new = '''        if matches!(convention, NativeCallingConvention::Fixed) {
            let maximum = maximum.expect("a fixed subr has a finite maximum arity");
            // eval.c:funcall_subr copies only to supply omitted optional
            // arguments. Fully supplied fixed calls use the original words.
            if arguments.len() < maximum {
                let mut padded = smallvec::SmallVec::<[NativeWord; 8]>::new();
                padded.extend_from_slice(arguments);
                padded.resize(maximum, 0);
                return Ok(unsafe { call_word_target(target, convention, &padded) });
            }
        }
        Ok(unsafe { call_word_target(target, convention, arguments) })
'''
assert before.count(old) == 1
path.write_text(before.replace(old, new))
assert [n for n, h in manifest.items() if sha(c / n) != h] == ['src/lisp/native_comp/runtime.rs']
review = dict(
    status='unvalidated native fixed-argument copy removal', candidate=str(c), base_commit=base,
    inputs={str(path): sha(path), str(g / 'src/eval.c'): sha(g / 'src/eval.c')},
    mechanism='GNU eval.c:funcall_subr copies and nil-pads only when numargs is less than the finite maximum. After the unchanged arity check, fixed calls at the maximum can pass the same original words directly to call_word_target.',
    removed_work='SmallVec initialization, argument copy, resize and drop on fully supplied fixed native funcall calls. These arguments fit inline; no claim of removing a heap allocation.',
    preserved='All argument words, maximum/minimum checks and function identity construction, optional padding, MANY convention, target resolution, native backtrace, collection entry, handlers, return and unwind paths are unchanged. Fixed ABI reads words into value parameters; no shared slice is exposed as writable. No new unsafe block, cache, lookup, name/size special case, collection or test/fixture change.',
    scope='Existing full native/VM/numeric/allocator selection and required suspended-root contracts, plus the applied LF control; all ordinary GNU comparisons and the failed broader column probe. No correctness exploration is added.',
    limits='This bounded removal does not resolve general runtime aliasing/ownership, counters, remaining architecture, final-platform validation or GNU parity.',
    goal_complete=False)
with (p / 'source296-static-review.json').open('x') as f:
    json.dump(review, f, indent=2)

# Reuse the fresh-build runner with an unchanged source inventory and the
# existing native/VM selection. Every replacement is checked before writing.
runner = (p / 'run-source295-validation.py').read_text()
runner = runner.replace('source295', 'source296').replace('buffer-single-line/emaxx', 'native-fixed-funcall/emaxx')
runner = runner.replace('from buffer_line_validation_support import audit_selected',
                        'from native_fixed_validation_support import audit_selected')
runner = runner.replace("assert changes == ['src/buffer.rs']", "assert changes == ['src/lisp/native_comp/runtime.rs']")
old_selector = r'^buffer::|^tty::|line|column|undo|window|narrow|invisib|buffer.*(?:edit|multibyte)|threads_retain_lexical_caller_roots|suspended_bytecode_retains_operand_and_unwind_roots'
selector = r'byte_?code|threads_retain_lexical_caller_roots|native_comp::runtime::|native.*(?:arity|calling|unwind|handler|argument)|numeric|arithmetic|remainder|modulo|bignum|float|integer|fixnum|lisp::types::|lisp::alloc::|buffer_line_indexes_preserve_gnu_lf_motion_narrowing_and_edits'
assert runner.count(old_selector) == 1
runner = runner.replace(old_selector, selector)
ast.parse(runner)
with (p / 'run-source296-validation.py').open('x') as f:
    f.write(runner)
support = (p / 'buffer_line_validation_support.py').read_text()
assert support.count('assert set(ignored) == EXISTING_IGNORES') == 1
support = support.replace('assert set(ignored) == EXISTING_IGNORES',
                          'assert set(ignored) == EXISTING_IGNORES.intersection(selectors)')
with (p / 'native_fixed_validation_support.py').open('x') as f:
    f.write(support)
generated = (p / 'compare-source295-generated-loaded.py').read_text().replace('source295', 'source296').replace('buffer-single-line/emaxx', 'native-fixed-funcall/emaxx')
ast.parse(generated)
with (p / 'compare-source296-generated-loaded.py').open('x') as f:
    f.write(generated)
print('Prepared source296 from applied source292; only optional argument staging condition changes')
