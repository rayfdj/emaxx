from pathlib import Path
import hashlib,json,subprocess
p=Path(__file__).parent.resolve();repository=p.parents[2]
head='092fef676e7667332349b12fd9b63539dd39072b'
baseline='d186d40bf014ca53d0a2652b4e2f2d921c5cb009'
changed=subprocess.check_output(['git','diff','--name-only',baseline,head,'--','src','tests','Cargo.toml','Cargo.lock','build.rs','.cargo'],cwd=repository,text=True).splitlines()
assert changed==['src/lisp/eval/core.rs'],changed
linux=p/('linux-source207-rust-artifacts/ordinary-linux-'+head+'/rust')
names=['native_pseudovector_census_matches_gnu_word_layout','native_vector_and_closure_census_matches_gnu_word_layout','suspended_bytecode_retains_operand_and_unwind_roots','threads_retain_lexical_caller_roots_across_separate_callee_environments']
results={}
for platform,root in [('macos',p/'full-gate-source207'),('linux',linux)]:
    raw=(root/'repeat-01-primitives.log').read_text()
    lines=['test lisp::primitives::tests::'+name+' ... ok' for name in names]
    assert all(raw.splitlines().count(line)==1 for line in lines)
    results[platform]={'raw_lines':lines,'raw_sha256':hashlib.sha256((root/'repeat-01-primitives.log').read_bytes()).hexdigest()}
    assert json.loads((p/('source207-'+platform+'-rust-complete-audit.json')).read_text())['status']=='passed'
record={'status':'passed on complete macOS and Linux Rust runs','source_commit':head,'baseline_failure_commit':baseline,'changed_compiled_or_test_inputs':changed,'original_assertions_unchanged':True,'regression_results':results,'qualification':'Confirms both original Linux census failures and both original suspended-root survival/reclamation controls on source207. Does not certify later bytecode drafts or establish performance parity.'}
with (p/'source207-census-repair-audit.json').open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps(record,indent=2))
