from pathlib import Path
from collections import Counter
import hashlib,json,re,zipfile
p=Path(__file__).parent.resolve();project=p.parents[2]
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();read=lambda f:json.loads(f.read_text())
head='8d4fcd39fafcac4d7f69987714164129a769e094'
state=read(p/'source243-linux-frozen-final-state.json');assert state['status']=='completed' and state['conclusion']=='failure' and state['headSha']==head
item=read(p/'source243-linux-frozen-artifacts.json')['artifacts'][0]
archive=p/'source243-linux-frozen-artifact.zip';assert 'sha256:'+sha(archive)==item['digest']
dest=p/'source243-linux-frozen-artifacts'
with zipfile.ZipFile(archive) as z:
 for member in z.infolist():
  if not member.is_dir():assert sha(dest/member.filename)==hashlib.sha256(z.read(member)).hexdigest()
frozen=next((dest/'compat').glob('frozen-*'));contract=read(frozen/'contract.json')
assert read(frozen/'head.json')['commit']==head==contract['provenance']['subject_git_head']
assert not contract['provenance']['subject_git_dirty']
manifest=project/'compat/oracle_tests_all_linux.txt';assert sha(manifest)==contract['manifest_sha256']
expected={};current=None
for line in manifest.read_text().splitlines():
 m=re.fullmatch(r'([^ ].*): discovered=(\d+) selected=(\d+)',line)
 if m:current=m[1];expected[current]=[]
 elif line.startswith('  '):expected[current].append(line[2:])
 elif ': load-error ' in line:current=None
 else:assert not line.strip(),line
failed='test/src/comp-tests.el';index=contract['files'].index(failed)
assert len(contract['files'])==519
assert len(list(frozen.rglob('comparison.json')))==index
outcomes=Counter();edebug=None
for file in contract['files'][:index+1]:
 directory=frozen/Path(file).with_suffix('.compat');execution=read(directory/'execution.json')
 assert execution['contract_sha256']==sha(frozen/'contract.json')
 assert all(sha(directory/name)==digest for name,digest in execution['sha256'].items())
 reports={editor:read(directory/(editor+'.json')) for editor in ['oracle','emaxx']}
 for editor in reports:
  report=reports[editor];process=read(directory/(editor+'.execution.json'))['process']
  assert not process['timed_out']
  if file==failed and editor=='emaxx':
   assert process['exit_code']==255 and not process['test_started']
   assert 'Error reading from stdin' in process['stderr'] and 'Select coding system (default utf-8):' in process['stdout']
   assert 'comp--native-compile' in process['stdout'] and 'comp-test-funcs.el' in process['stderr']
   assert report['results']==[]
  else:
   assert process['exit_code']==0 and report['file_status']=='loaded'
   assert sorted(report['selected_tests'])==sorted(expected[file])
   assert sorted(row['name'] for row in report['results'])==sorted(expected[file])
 if file==failed:continue
 comparison=read(directory/'comparison.json');assert comparison['matches'] and not comparison['issues'] and not comparison['execution_issues']
 left={row['name']:(row['status'],row['expected']) for row in reports['oracle']['results']}
 right={row['name']:(row['status'],row['expected']) for row in reports['emaxx']['results']}
 assert left==right and comparison['matching_outcomes']==len(expected[file]) and comparison['mismatching_outcomes']==0
 for status,expected_result in left.values():
  assert expected_result or status=='skipped'
  outcomes['expected_failure' if status=='failed' else status]+=1
 if file.endswith('/edebug-tests.el'):edebug=len(left)
assert edebug==46 and not (frozen/'summary.json').exists()
record={'status':'frozen comparison fails loading compiler tests at an unexpected coding-system prompt','source_commit':head,'completed_matching_files':index,'matching_outcomes':sum(outcomes.values()),'outcomes_per_editor':dict(outcomes),'edebug_matching_outcomes':edebug,'failed_file':failed,'missing_emaxx_outcomes':len(expected[failed]),'unstarted_files':519-index-1,'qualification':'Emaxx exits 255 while native-compiling comp-test-funcs.el during comp-tests.el loading, before any selected test starts. Its stdout requests a coding system and batch stdin is exhausted. GNU loads the original file and all 177 selected outcomes pass. Every completed pair and raw execution hash is verified; later files are unstarted. Expected failures and skips remain distinct from passes. No complete frozen pass.'}
with (p/'source243-linux-frozen-failure-audit.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(record,indent=2))
