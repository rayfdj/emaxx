from pathlib import Path
import hashlib, io, json, re, subprocess, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
d = p / 'source243-linux-gnu-census-artifacts/gnu-census'
sha = lambda data: hashlib.sha256(data).hexdigest()
s = json.loads((d / 'summary.json').read_text())
assert s['status'] == 'diagnostic completed' and s['failed_processes'] == 0
assert s['inputs_unchanged'] and s['compiled_inputs_unchanged']
assert s['source_after'] == s['git'] == dict(head='3a35ad00ed62c3a1b1f717f347f0f67bd8817890', dirty=False)
manifest = json.loads((p / 'source243-manifest.json').read_text())
compiled = json.loads((d / 'source-before.json').read_text())
assert len(manifest) == 462 and len(compiled) == 455
assert all(manifest[name] == digest for name, digest in compiled.items())
for commit in [s['git']['head'], '8d4fcd39fafcac4d7f69987714164129a769e094']:
    blob = subprocess.check_output(['git', 'archive', commit, '--', *sorted(manifest)], cwd=root)
    with tarfile.open(fileobj=io.BytesIO(blob)) as archive:
        assert all(sha(archive.extractfile(name).read()) == digest for name, digest in manifest.items())
fixture = root / 'tests/fixtures/vector-closure-rounded-census.el'
expected = (root / 'tests/fixtures/vector-closure-rounded-census.expected').read_bytes().rstrip(b'\n')
assert len(s['gnu_runs']) == 18
matrix = set()
for run in s['gnu_runs']:
    matrix.add((run['stage'], run['repetition'], run['variant']))
    assert run['exit_code'] == 0 and not run['timed_out'] and run['passed'] and run['expected_output']
    assert run['command'][-1] == '(prin1 ' + fixture.read_text() + ')'
    for output in ['stdout', 'stderr']:
        data = (d / run[output + '_file']).read_bytes()
        assert sha(data) == run[output + '_sha256']
        assert data == (expected if output == 'stdout' else b'')
assert matrix == {(stage, repetition, variant) for stage in ['before', 'after']
                  for repetition in [1, 2, 3] for variant in ['full', 'single', 'group']}
def listed(name):
    return [line[:-6] for line in (d / name).read_text().splitlines() if line.endswith(': test')]
all_names, single, group = (listed(name + '-inventory.log') for name in ['full', 'single', 'group'])
assert len(all_names) == len(set(all_names)) == 3004
assert len(single) == 1 and len(group) == 651
assert group == [name for name in all_names if name.startswith('lisp::primitives::tests::')]
assert single == [name for name in group if name.endswith('::native_vector_and_closure_census_matches_gnu_word_layout')]
assert not listed('single-ignored.log') and not listed('group-ignored.log')
assert len(s['rust_runs']) == 3
for run, names in zip(s['rust_runs'], [single, group, single], strict=True):
    raw = (d / run['log_file']).read_bytes()
    assert sha(raw) == run['log_sha256']
    verdicts = re.findall(r'^test (\S+) \.\.\. (ok|FAILED|ignored)\s*$', raw.decode(), re.M)
    assert verdicts == [(name, 'ok') for name in names]
    assert run['executed_tests'] == names
    result = run['result']
    assert result['status'] == 'ok' and result['passed'] == len(names)
    assert result['failed'] == result['ignored'] == result['measured'] == 0
    assert result['filtered_out'] == 3004 - len(names)
    assert run['passed'] and run['exit_code'] == 0 and not run['timed_out']
assert len(s['retained_files']) == 8
for item in s['retained_files']:
    data = (d / item['artifact']).read_bytes()
    assert len(data) == item['bytes'] and sha(data) == item['sha256']
assert sha((d / 'libtest').read_bytes()) == s['test_binary']['sha256'] == '41a6c39df19583ef828b35fdb1219bf84c960e484cb14536502ca527605dd0d0'
assert s['oracle_source_commit'] == '636f166cfc86aa90d63f592fd99f3fdd9ef95ebd'
record = dict(status='passed', gnu_probes=18, rust_passes=[1, 651, 1], full_inventory=3004,
              retained_files_verified=8, compiled_inputs_verified=455, source_inputs_verified=462,
              gnu_executable_sha256=sha((d / 'gnu-inputs/emacs').read_bytes()),
              gnu_image_sha256=sha((d / 'gnu-inputs/emacs.pdmp').read_bytes()),
              qualification='Bounded unchanged GNU census diagnostic passes every raw process and inventory check on source243-equivalent runtime. The exact Rust executable also matches the complete Linux Rust gate. GNU executable/image identities are retained for this diagnosis, but were not retained in the older source238 failures; their cause remains unresolved. This is not complete-gate or performance evidence.')
with (p / 'source243-linux-gnu-census-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps(record, indent=2))
