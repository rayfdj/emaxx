from pathlib import Path
import hashlib, json, os, subprocess, time
p = Path(__file__).parent.resolve()
root = p.parents[2]
recovered = p.parent / 'recovered-2026-09-30'
checkout = recovered / 'file-coding/emaxx'
fixture = p / 'coding-candidate-inventory.el'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
manifest = json.loads((p / 'source243-manifest.json').read_text())
unchanged = lambda: all(sha(checkout / name) == digest for name, digest in manifest.items())
assert len(manifest) == 462 and unchanged()
records, outputs = {}, {}
for editor, binary in [('gnu', recovered / 'emacs/src/emacs'), ('emaxx', checkout / 'target/frame-validation/release/emaxx')]:
    command = [str(binary), '-Q', '--batch', '--eval', '(prin1 ' + fixture.read_text() + ')']
    inputs = {str(f): sha(f) for f in [fixture, Path(__file__), binary, binary.with_suffix('.pdmp')]}
    stem = p / ('source243-coding-inventory-' + editor)
    with Path(str(stem) + '-command.json').open('x') as f:
        json.dump(dict(command=command, working_directory=str(root), environment_overrides={'LANG':'C','LC_ALL':'C'}, inputs=inputs, timeout_seconds=120), f, indent=2)
    start = time.monotonic()
    result = subprocess.run(command, cwd=root, env={**os.environ, 'LANG':'C', 'LC_ALL':'C'},
                            stdin=subprocess.DEVNULL, capture_output=True, timeout=120)
    for suffix, data in [('stdout', result.stdout), ('stderr', result.stderr)]:
        with Path(str(stem) + '.' + suffix).open('xb') as f:f.write(data)
    record = dict(exit_code=result.returncode, elapsed_seconds=time.monotonic()-start,
                  stdout_sha256=hashlib.sha256(result.stdout).hexdigest(), stderr_sha256=hashlib.sha256(result.stderr).hexdigest(),
                  source_unchanged=unchanged(), inputs_unchanged=all(sha(Path(name)) == digest for name,digest in inputs.items()))
    with Path(str(stem) + '-result.json').open('x') as f:json.dump(record, f, indent=2)
    records[editor], outputs[editor] = record, result.stdout
    print(editor, json.dumps(record), result.stdout.decode(errors='replace'), result.stderr.decode(errors='replace'), flush=True)
    assert result.returncode == 0 and not result.stderr and record['source_unchanged'] and record['inputs_unchanged']
with (p / 'source243-coding-inventory-negative-audit.json').open('x') as f:
    json.dump(dict(matches=outputs['gnu']==outputs['emaxx'], records=records, fixture_sha256=sha(fixture),
                   qualification='Same-input ordinary coding-candidate inventory, custom definitions, exclusions, priority change, narrowed marker range and real coding-cookie selection. Unchanged frozen source243; no performance or complete-coding claim.'), f, indent=2)
