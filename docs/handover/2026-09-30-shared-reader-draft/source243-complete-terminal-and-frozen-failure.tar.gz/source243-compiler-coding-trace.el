(defun source243-coding-trace-log (tag values)
  (let ((print-length 20) (print-level 5) (print-escape-newlines t))
    (princ "\nCODING-TRACE ")
    (prin1 (cons tag values))
    (terpri)))

(advice-add
 'write-region :before
 (lambda (&rest arguments)
   (source243-coding-trace-log
    'write
    (list (if (stringp (car arguments))
              (list 'string (length (car arguments))
                    (multibyte-string-p (car arguments)))
            (car arguments))
          (cdr arguments) (buffer-name) coding-system-for-write
          buffer-file-coding-system coding-system-require-warning
          enable-multibyte-characters))))

(advice-add
 'select-safe-coding-system :before
 (lambda (&rest arguments)
   (source243-coding-trace-log
    'select
    (list arguments (buffer-name) coding-system-for-write
          buffer-file-coding-system enable-multibyte-characters
          (buffer-substring-no-properties
           (point-min) (min (point-max) (+ (point-min) 80))))))))

(advice-add
 'select-safe-coding-system-interactively :before
 (lambda (&rest arguments)
   (source243-coding-trace-log 'interactive arguments)
   (backtrace)))
