from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
read = lambda name: json.loads((p / name).read_text())
terminal = read('source243-complete-terminal-audit.json')
frozen = read('source243-linux-frozen-failure-audit.json')
diagnosis = read('source243-linux-gnu-census-audit.json')
negative = read('source243-coding-inventory2-negative-audit.json')
assert terminal['status'] == 'passed' and terminal['verified_checkpoints'] == 686
assert frozen['completed_matching_files'] == 482 and frozen['missing_emaxx_outcomes'] == 177
assert diagnosis['status'] == 'passed' and diagnosis['gnu_probes'] == 18
assert not negative['matches']
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected'}
patterns = [
    'source243-full-ttydiff-*', 'source243-full-ttydiff.log', 'source243-complete-terminal-audit.json',
    'source243-linux-frozen-*', 'source243-linux-gnu-census-*', 'source243-gnu-diagnosis-*',
    'source243-compiler-*', 'source243-coding-inventory*', 'coding-candidate-inventory*.el',
    'coding-candidate-inventory*-syntax.json', 'source243-manifest.json', 'source243-complete.patch',
    'run-source243-full-tty.py', 'verify-complete-reader-terminal-receipts.py',
    'download-source243-linux-frozen-failure.py', 'audit-source243-linux-frozen-failure.py',
    'download-source243-linux-gnu-census.py', 'audit-source243-gnu-diagnosis*.py',
    'probe-source243-compiler-*.py', 'probe-source243-coding-*.py', Path(__file__).name,
]
files = {str(file.relative_to(p)): file for pattern in patterns for file in p.glob(pattern)
         if file.is_file() and file.suffix in allowed}
for directory in ['source243-linux-frozen-artifacts', 'source243-linux-gnu-census-artifacts',
                  'source243-compiler-load', 'source243-compiler-coding-trace', 'source243-compiler-coding-trace2']:
    files.update({str(file.relative_to(p)): file for file in (p / directory).rglob('*')
                  if file.is_file() and file.suffix in allowed})
package('source243-closed-correctness', files,
        dict(terminal=terminal, frozen_failure=frozen, gnu_diagnosis=diagnosis, negative_fixture=negative,
             qualification='Complete source243 terminal validation passes all 226 unchanged scenarios and 686 comparisons. Linux frozen36822376061 remains failed after 482 matching files and 6,911 outcomes: Emaxx cannot load comp-tests.el because safe coding candidates omit utf-8-emacs, while GNU runs all 177 selected tests. The unchanged ordinary compiler load reproduces the failure. GNU-only census diagnosis36825694384 passes 18 probes and unchanged Rust single/group/single controls; it does not explain historical source238 GNU variation. Failed initial probe syntax and audit setup attempts remain preserved. No full frozen, pinned Darwin or performance pass is claimed.'))
