from pathlib import Path
import ast, hashlib, json, subprocess

p = Path(__file__).parent.resolve()
root = p.parents[2]
c = p.parent / 'recovered-2026-10-05/native-bytecode-entry/emaxx'
g = p.parent / 'rebuilt-2026-10-01/emacs'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p / n).read_text())
base = read('source297-applied-commit.json')['commit']
manifest = read('source297-manifest.json')
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == base
assert all(sha(root / n) == h for n, h in manifest.items())
assert all(r['validation'] == 'completed' for r in read('source297-mixed-profile-result.json')['results'])
assert not c.exists()
c.parent.mkdir()
(c.parent / 'emacs').symlink_to(g, target_is_directory=True)
for command in [
    ['git', 'clone', '--shared', '--quiet', '--no-checkout', str(root), str(c)],
    ['git', '-C', str(c), 'sparse-checkout', 'init', '--no-cone'],
    ['git', '-C', str(c), 'sparse-checkout', 'set', '--no-cone', *sorted({'/' + n for n in manifest} | {'/tools/', '/compat/'})],
    ['git', '-C', str(c), 'checkout', '--detach', base],
]:
    subprocess.run(command, check=True)
assert all(sha(c / n) == h for n, h in manifest.items())
path = c / 'src/lisp/eval/core.rs'
before = path.read_text()
old = '''                let backtrace_function = original_name
                    .map(CallName::original_symbol_value)
                    .unwrap_or(Value::Record(id));
                self.with_backtrace_frame(backtrace_function, args, |interp| {
                    interp.capture_current_backtrace_context(
                        original_name.map(CallName::as_str),
                        env,
                        None,
                    );
                    crate::lisp::native_comp::maybe_gc(interp, env);
                    let result = crate::lisp::native_comp::call_function(interp, env, id.id, args);
                    interp.settle_frame_result(result, env)
                })
'''
assert before.count(old) == 1
after = before.replace(old, '                self.funcall_native_subr(id, original_name, args, env)\n')
helper = '''    /// bytecode.c:Bcall dispatches a resolved native subr without resolving
    /// the original symbol again. Share the ordinary native call body so
    /// its backtrace, GC, debugger and nonlocal-exit lifecycle stays identical.
    #[inline]
    fn funcall_native_subr(
        &mut self,
        id: RecordRef,
        original_name: Option<CallName<'_>>,
        args: &[Value],
        env: &mut Env,
    ) -> Result<Value, LispError> {
        let backtrace_function = original_name
            .map(CallName::original_symbol_value)
            .unwrap_or(Value::Record(id));
        self.with_backtrace_frame(backtrace_function, args, |interp| {
            interp.capture_current_backtrace_context(
                original_name.map(CallName::as_str),
                env,
                None,
            );
            crate::lisp::native_comp::maybe_gc(interp, env);
            let result = crate::lisp::native_comp::call_function(interp, env, id.id, args);
            interp.settle_frame_result(result, env)
        })
    }

'''
anchor = '    /// Execute one GNU byte-code closure with the activation-frame contract\n'
assert after.count(anchor) == 1
after = after.replace(anchor, helper + anchor)
anchor = '''                        // A lambda, an autoload, a local function binding or
                        // a void function: the general path, which resolves
                        // again from the cache.
'''
branch = '''                        Ok(FunctionResolution::Resolved(value))
                            if matches!(value.kind(), Kind::Record(id) if self
                                .find_record(id)
                                .is_some_and(|record| record.kind == RecordKind::NativeCompiledFunction)) =>
                        {
                            let Kind::Record(id) = value.kind() else {
                                unreachable!("matched above")
                            };
                            self.funcall_native_subr(
                                id,
                                Some(CallName::Symbol(&name)),
                                args,
                                env,
                            )
                        }
'''
assert after.count(anchor) == 1
after = after.replace(anchor, branch + anchor)
path.write_text(after)
assert [n for n, h in manifest.items() if sha(c / n) != h] == ['src/lisp/eval/core.rs']
review = dict(
    status='unvalidated shared native call entry from Bcall', candidate=str(c), base_commit=base,
    inputs={str(f): sha(f) for f in [path, g / 'src/bytecode.c', g / 'src/eval.c', root / 'src/lisp/eval/bindings.rs']},
    mechanism='After existing resolve_symbol_call yields a native function, Bcall uses the same extracted native call body as call_function_value_inner. This removes a second unchanged symbol/alias resolution and general function-kind dispatch. The extracted body is identical. begin/end_funcall, pending termination, profiler fallback, named backtrace, debugger context, maybe_gc, native registry/arity/calling convention, result settlement and errors remain. No target cache or new representation is introduced.',
    gnu_reference='bytecode.c:Bcall takes a resolved non-dynamic SUBRP directly through funcall_subr; other kinds use funcall_general. The Rust helper retains the existing native loader for both fixed and dynamic functions, including dynamic lambda binding. Existing lookup_function_symbol only reads the live cells; no callbacks or collections occur between the removed duplicate resolutions.',
    limits='This does not repair pre-existing call resolution versus collecting-finalizer ordering, native record/registry architecture, Rust aliasing/ownership, unavailable counters or the final performance gap. These requirements remain open. All tests and fixtures are unchanged; no new unrelated correctness investigation.',
    goal_complete=False)
with (p / 'source299-static-review.json').open('x') as f:
    json.dump(review, f, indent=2)
runner = (p / 'run-source297-validation.py').read_text()
runner = runner.replace('source297', 'source299').replace('source296', 'source297')
runner = runner.replace('native-funcall-dispatch/emaxx', 'native-bytecode-entry/emaxx').replace('native-fixed-funcall/emaxx', 'native-funcall-dispatch/emaxx')
runner = runner.replace("changes == ['src/lisp/native_comp/runtime.rs']", "changes == ['src/lisp/eval/core.rs']")
runner = runner.replace('new_test', 'required_boundary_test').replace('set(prior) | {required_boundary_test}', 'set(prior)')
ast.parse(runner)
with (p / 'run-source299-validation.py').open('x') as f:
    f.write(runner)
generated = (p / 'compare-source297-generated-loaded.py').read_text().replace('source297', 'source299').replace('native-funcall-dispatch/emaxx', 'native-bytecode-entry/emaxx')
ast.parse(generated)
with (p / 'compare-source299-generated-loaded.py').open('x') as f:
    f.write(generated)
print('Prepared source299: shared native Bcall entry, all tests/fixtures unchanged')
