from pathlib import Path
import ast, hashlib, json, subprocess

p = Path(__file__).parent.resolve()
root = p.parents[2]
c = p.parent / 'recovered-2026-10-05/native-bytecode-entry-formatted/emaxx'
g = p.parent / 'rebuilt-2026-10-01/emacs'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p / n).read_text())
base = read('source297-applied-commit.json')['commit']
manifest = read('source297-manifest.json')
path = c / 'src/lisp/eval/core.rs'
original = p.parent / 'recovered-2026-10-05/native-bytecode-entry/emaxx/src/lisp/eval/core.rs'
before = original.read_text()
old = '''                            self.funcall_native_subr(
                                id,
                                Some(CallName::Symbol(&name)),
                                args,
                                env,
                            )'''
new = '                            self.funcall_native_subr(id, Some(CallName::Symbol(&name)), args, env)'
assert before.count(old) == 1 and path.read_text() == before.replace(old, new)
assert [n for n, h in manifest.items() if sha(c / n) != h] == ['src/lisp/eval/core.rs']
assert not (p / 'source300-manifest.json').exists()
with (p / 'source300-preparation-retry.json').open('x') as f:
    json.dump(dict(status='formatting equivalence assertion corrected before validation',
                   original_helper_sha256=sha(p / 'prepare-native-bytecode300.py'),
                   error='The preparer incorrectly expected rustfmt to change only whitespace. Rustfmt also removes the optional trailing comma when collapsing this call. The original source299 formatting failure and original preparer are retained.',
                   verification='Exact source comparison permits only that one rustfmt call collapse. No semantic tokens except its optional trailing comma differ; all other532 inputs remain identical.',
                   validated=False, goal_complete=False), f, indent=2)
tree = ast.parse((p / 'prepare-native-bytecode300.py').read_text())
start = next(i for i, n in enumerate(tree.body) if isinstance(n, ast.Assign)
             and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'review')
exec(compile(ast.Module(body=tree.body[start:], type_ignores=[]), '<finish-source300-preparation>', 'exec'))
