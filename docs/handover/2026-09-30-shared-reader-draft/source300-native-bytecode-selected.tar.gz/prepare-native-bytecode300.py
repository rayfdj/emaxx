from pathlib import Path
import ast, hashlib, json, subprocess

p = Path(__file__).parent.resolve()
root = p.parents[2]
c = p.parent / 'recovered-2026-10-05/native-bytecode-entry-formatted/emaxx'
g = p.parent / 'rebuilt-2026-10-01/emacs'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p / n).read_text())
base = read('source297-applied-commit.json')['commit']
manifest = read('source297-manifest.json')
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == base
assert all(sha(root / n) == h for n, h in manifest.items())
assert all(r['validation'] == 'completed' for r in read('source297-mixed-profile-result.json')['results'])
assert not c.exists()
c.parent.mkdir()
(c.parent / 'emacs').symlink_to(g, target_is_directory=True)
for command in [
    ['git', 'clone', '--shared', '--quiet', '--no-checkout', str(root), str(c)],
    ['git', '-C', str(c), 'sparse-checkout', 'init', '--no-cone'],
    ['git', '-C', str(c), 'sparse-checkout', 'set', '--no-cone', *sorted({'/' + n for n in manifest} | {'/tools/', '/compat/'})],
    ['git', '-C', str(c), 'checkout', '--detach', base],
]:
    subprocess.run(command, check=True)
assert all(sha(c / n) == h for n, h in manifest.items())
path = c / 'src/lisp/eval/core.rs'
original = p.parent / 'recovered-2026-10-05/native-bytecode-entry/emaxx/src/lisp/eval/core.rs'
failed = read('source299-validation-result.json')
assert failed['status'] == 'validation stopped' and failed['results'][-1]['stage'] == 'fmt'
assert failed['results'][-1]['exit_code'] == 1 and not failed['profiles']
path.write_bytes(original.read_bytes())
subprocess.run(['cargo', 'fmt', '--all'], cwd=c, check=True)
assert [n for n, h in manifest.items() if sha(c / n) != h] == ['src/lisp/eval/core.rs']
assert ''.join(path.read_text().split()) == ''.join(original.read_text().split())
review = dict(
    status='unvalidated formatting-only successor to source299; shared native call entry from Bcall', candidate=str(c), base_commit=base,
    inputs={str(f): sha(f) for f in [path, g / 'src/bytecode.c', g / 'src/eval.c', root / 'src/lisp/eval/bindings.rs']},
    mechanism='After existing resolve_symbol_call yields a native function, Bcall uses the same extracted native call body as call_function_value_inner. This removes a second unchanged symbol/alias resolution and general function-kind dispatch. The extracted body is identical. begin/end_funcall, pending termination, profiler fallback, named backtrace, debugger context, maybe_gc, native registry/arity/calling convention, result settlement and errors remain. No target cache or new representation is introduced.',
    gnu_reference='bytecode.c:Bcall takes a resolved non-dynamic SUBRP directly through funcall_subr; other kinds use funcall_general. The Rust helper retains the existing native loader for both fixed and dynamic functions, including dynamic lambda binding. Existing lookup_function_symbol only reads the live cells; no callbacks or collections occur between the removed duplicate resolutions.',
    limits='This does not repair pre-existing call resolution versus collecting-finalizer ordering, native record/registry architecture, Rust aliasing/ownership, unavailable counters or the final performance gap. These requirements remain open. All tests and fixtures are unchanged; no new unrelated correctness investigation.',
    goal_complete=False)
with (p / 'source300-static-review.json').open('x') as f:
    json.dump(review, f, indent=2)
runner = (p / 'run-source297-validation.py').read_text()
runner = runner.replace('source297', 'source300').replace('source296', 'source297')
runner = runner.replace('native-funcall-dispatch/emaxx', 'native-bytecode-entry-formatted/emaxx').replace('native-fixed-funcall/emaxx', 'native-funcall-dispatch/emaxx')
runner = runner.replace("changes == ['src/lisp/native_comp/runtime.rs']", "changes == ['src/lisp/eval/core.rs']")
runner = runner.replace('new_test', 'required_boundary_test').replace('set(prior) | {required_boundary_test}', 'set(prior)')
ast.parse(runner)
with (p / 'run-source300-validation.py').open('x') as f:
    f.write(runner)
generated = (p / 'compare-source297-generated-loaded.py').read_text().replace('source297', 'source300').replace('native-funcall-dispatch/emaxx', 'native-bytecode-entry-formatted/emaxx')
ast.parse(generated)
with (p / 'compare-source300-generated-loaded.py').open('x') as f:
    f.write(generated)
print('Prepared source300: shared native Bcall entry, all tests/fixtures unchanged')
