from pathlib import Path
import ast

p = Path(__file__).parent.resolve()

def write(name, source):
    ast.parse(source)
    with (p / name).open('x') as f:
        f.write(source)

source = (p / 'replay-native-dispatch297.py').read_text()
tree = ast.parse(source)
old = next(n.value for n in ast.walk(tree) if isinstance(n, ast.Constant)
           and isinstance(n.value, str) and n.value.startswith('Source297 reorders'))
source = source.replace(repr(old), repr('Source300 shares the ordinary native call body with the already-resolved Bcall path. Source299 failed formatting before compilation; source300 changes only that formatting. All532 bytes/modes reconstruct from4af440a9 and main. All assertions, fixtures, selectors, timeouts and performance requirements remain. Selected validation and timing are separate.'))
write('replay-native-bytecode300.py', source)

source = (p / 'audit-native-dispatch-selected.py').read_text()
source = source.replace("assert tag in ('source297', 'source298')", "assert tag == 'source300'")
source = source.replace('source296', 'source297').replace('native-fixed-funcall/emaxx', 'native-funcall-dispatch/emaxx')
source = source.replace("== ['src/lisp/native_comp/runtime.rs']", "== ['src/lisp/eval/core.rs']")
a = source.index('old_runtime=')
b = source.index("state = read(tag + '-validation-result.json')", a)
source = source[:a] + source[b:]
source = source.replace("if tag in ('source297', 'source298'):", "if tag == 'source300':")
source = source.replace('set(prior) | {new_test}', 'set(prior)')
old = next(n.value for n in ast.walk(ast.parse(source)) if isinstance(n, ast.Constant)
           and isinstance(n.value, str) and n.value.startswith('Bounded selected native/VM/'))
source = source.replace(repr(old), repr('Source300 reuses the identical ordinary native call body after Bcall resolves a native function. All532 inputs/modes, fresh builds, unchanged inventories and original assertions/fixtures verify.327 selected passes per profile and47 actual GNU comparisons. The broad probe retains60 original width failures. Source299 formatting failure and the300 preparer assertion correction remain preserved. Complete platform/ownership/accounting, final audit and performance acceptance remain open.'))
write('audit-native-bytecode-selected.py', source)

source = (p / 'finish-native-dispatch-selected-closed.py').read_text()
source = source.replace('source297', 'source300').replace('source296', 'source297')
source = source.replace('native-funcall-dispatch', 'native-bytecode-entry-formatted')
source = source.replace('native-dispatch', 'native-bytecode')
write('finish-native-bytecode-selected-closed.py', source)

source = (p / 'measure-native-fixed.py').read_text()
source = source.replace('source296', 'source300').replace('source292', 'source297')
source = source.replace('native-fixed-funcall/emaxx', 'native-bytecode-entry-formatted/emaxx').replace('buffer-line-index/emaxx', 'native-funcall-dispatch/emaxx')
source = source.replace('native-fixed', 'native-bytecode')
source = source.replace('Applied LF-correct source297 is the baseline; source300 removes redundant fixed native argument copying only.', 'Applied source297 is the baseline; source300 avoids duplicate symbol resolution/general dispatch before the unchanged native call body.')
write('measure-native-bytecode.py', source)

source = (p / 'audit-native-fixed-performance.py').read_text()
source = source.replace('source296', 'source300').replace('source292', 'source297').replace('native-fixed', 'native-bytecode')
source = source.replace('baseline292 and native fixed-copy candidate296', 'baseline297 and shared native Bcall candidate300')
write('audit-native-bytecode-performance.py', source)

source = (p / 'finish-native-fixed-performance-closed.py').read_text().replace('native-fixed', 'native-bytecode')
source = source.replace('waiting for both line selected audits', 'waiting for source300 selected audit')
write('finish-native-bytecode-performance-closed.py', source)
print('Prepared source300 selected/replay/measurement/audit helpers; no original helper changed')
