from pathlib import Path
import hashlib, json, re, subprocess, sys
from native_fixed_validation_support import audit_selected

p = Path(__file__).parent.resolve()
root = p.parents[2]
tag, directory = sys.argv[1:]
c = Path(directory)
assert tag == 'source300'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read(tag + '-manifest.json')
prior_manifest = read('source297-manifest.json')
assert len(manifest) == 532 and all(sha(c / name) == digest for name, digest in manifest.items())
assert all(manifest[name] == digest for name, digest in prior_manifest.items() if name.startswith('tests/'))
assert [n for n,h in manifest.items() if prior_manifest.get(n)!=h] == ['src/lisp/eval/core.rs']
assert (c / 'src/lisp/primitives/tests.rs').read_bytes() == (p.parent / 'recovered-2026-10-05/native-funcall-dispatch/emaxx/src/lisp/primitives/tests.rs').read_bytes()
state = read(tag + '-validation-result.json')
assert len(state['results']) == 16
assert all(row['exit_code'] == 0 and not row['timed_out'] and row['source_unchanged'] for row in state['results'])
if tag == 'source300':
    for build_profile in ('gate', 'release', 'ordinary'):
        records = [json.loads(line) for line in (p / (tag+'-'+build_profile+'-build.log')).read_text().splitlines() if line.startswith('{')]
        artifact = [a for a in records if a.get('reason') == 'compiler-artifact' and a['target']['name'] == 'emaxx']
        assert artifact and all(a['fresh'] is False for a in artifact)
    for build_profile in ('gate', 'release'):
        assert sha(p / (tag+'-'+build_profile+'-libtest')) != sha(p / ('source297-'+build_profile+'-libtest'))
profiles = {}
new_test = 'lisp::native_comp::runtime::tests::native_many_empty_and_negative_list_counts_accept_null_storage'
selector = r'byte_?code|threads_retain_lexical_caller_roots|native_comp::runtime::|native.*(?:arity|calling|unwind|handler|argument)|numeric|arithmetic|remainder|modulo|bignum|float|integer|fixnum|lisp::types::|lisp::alloc::|buffer_line_indexes_preserve_gnu_lf_motion_narrowing_and_edits'
for profile in ('gate', 'release'):
    record = state['profiles'][profile]
    assert record['passed'] + record['ignored'] == len(record['selectors']) and record['failed'] == 0 and record['ignored'] == 0
    inventory = [line[:-6] for line in (p / (tag + '-' + profile + '-inventory.log')).read_text().splitlines() if line.endswith(': test')]
    prior = [line[:-6] for line in (p / ('source297-' + profile + '-inventory.log')).read_text().splitlines() if line.endswith(': test')]
    assert len(inventory) == len(set(inventory)) and set(inventory) == set(prior)
    names = [name for name in inventory if re.search(selector, name)]
    assert names == record['selectors']
    raw = (p / (tag + '-' + profile + '-selected.log')).read_text()
    counts = audit_selected(raw, names)
    assert all(record[k] == v for k,v in counts.items())
    assert sha(Path(record['binary'])) == sha(Path(record['retained_binary'])) == record['binary_sha256']
    for item in record['retained_inputs']:
        assert sha(Path(item['original'])) == sha(Path(item['retained'])) == item['sha256']
    profiles[profile] = record

ordinary = {}
names = list(read('source297-selected-audit.json')['ordinary_results'])
assert len(names) == 46
for name in names:
    comparison = read(tag + '-ordinary-' + name + '-comparison.json')
    assert comparison['passed'] and comparison['exact_match']
    outputs, programs = [], []
    for editor in ('gnu', 'emaxx'):
        stem = tag + '-ordinary-' + name + '-' + editor
        command, result = read(stem + '.command.json'), read(stem + '.result.json')
        assert all(sha(Path(path)) == digest for path, digest in command['inputs'].items())
        assert result == comparison['outcomes'][editor]
        assert result['exit_code'] == 0 and not result['timed_out'] and result['source_unchanged'] and result['inputs_unchanged']
        out, err = (p / (stem + '.stdout')).read_bytes(), (p / (stem + '.stderr')).read_bytes()
        assert out and not err and hashlib.sha256(out).hexdigest() == result['stdout_sha256'] and err.hex() == result['stderr_hex']
        assert result['expected_output'] is not False
        if name not in ('bytecode-integer-boundaries', 'buffer-lf-line-motion'):
            assert out == (p / ('source297-ordinary-' + name + '-' + editor + '.stdout')).read_bytes()
        else:
            assert out == (c / ('tests/fixtures/' + name + '.expected')).read_bytes().rstrip(b'\n')
        outputs.append(out)
        programs.append(command['command'][-1])
    assert outputs[0] == outputs[1] and programs[0] == programs[1]
    ordinary[name] = dict(passed=True, stdout_sha256=hashlib.sha256(outputs[0]).hexdigest(), stdout_bytes=len(outputs[0]))
assert read(tag + '-generated-loaded-comparison.json')['passed']
for editor in ('gnu', 'emaxx'):
    stem = tag + '-generated-loaded-' + editor
    command, result = read(stem + '-command.json'), read(stem + '-result.json')
    assert all(sha(Path(path)) == digest for path, digest in command['inputs'].items())
    assert result['exit_code'] == 0 and not result['timed_out'] and result['source_unchanged'] and result['inputs_unchanged']
    assert command['command'][-2:] == ['-l', str(p / 'printer-varied-v3-293638f0.el')]
    out = (p / (stem + '.stdout')).read_bytes()
    assert len(out) == 4088269 and len(out.splitlines()) == 198
    assert out == (p / 'printer-varied-v3-gnu.stdout').read_bytes() and not (p / (stem + '.stderr')).read_bytes()
artifacts = read(tag + '-ordinary-artifacts.json')
assert all(sha(Path(path)) == sha(Path(row['immutable_copy'])) == row['sha256'] for path, row in artifacts.items())
for stage in ('fmt', 'check', 'clippy', 'diff', 'ordinary-build', 'gate-build', 'release-build'):
    raw = (p / (tag + '-' + stage + '.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
    for line in raw.splitlines():
        if line.startswith('{'):
            assert json.loads(line).get('message', {}).get('level') not in ('warning', 'error')
portable = read(tag + '-portable-draft-audit.json')
assert len(portable['patches']) == 2
for row in portable['patches']:
    assert row['inputs'] == 532 and row['bytes_and_modes'] == 'exact' and sha(p / row['patch']) == row['sha256']
evidence = {str(path): sha(path) for path in p.glob(tag + '-*') if path.is_file() and path.suffix in ('.json', '.log', '.stdout', '.stderr', '.patch')}
record = dict(status='passed', source_inputs_verified=532, profiles=profiles,
              ordinary_comparisons=47, ordinary_results=ordinary,
              generated_rows=198, generated_bytes=4088269,
              ordinary_artifacts=artifacts, portable_replays=portable['patches'], evidence_files=evidence,
              qualification='Source300 reuses the identical ordinary native call body after Bcall resolves a native function. All532 inputs/modes, fresh builds, unchanged inventories and original assertions/fixtures verify.327 selected passes per profile and47 actual GNU comparisons. The broad probe retains60 original width failures. Source299 formatting failure and the300 preparer assertion correction remain preserved. Complete platform/ownership/accounting, final audit and performance acceptance remain open.', goal_complete=False)
broad = read(tag + '-line-broad-diagnosis.json')
assert broad['exact_match'] is False and broad['rows'] == 338 and broad['different_rows'] == 60
for editor in ('gnu', 'emaxx'):
    stem = tag + '-line-broad-' + editor
    command = read(stem + '.command.json'); outcome = read(stem + '.result.json')
    assert all(sha(Path(n)) == h for n,h in command['inputs'].items())
    assert outcome == broad['outcomes'][editor]
    assert outcome['exit_code'] == 0 and outcome['source_unchanged'] and outcome['inputs_unchanged']
    assert sha(p / (stem + '.stdout')) == outcome['stdout_sha256']
    assert sha(p / (stem + '.stderr')) == outcome['stderr_sha256']
    assert not (p / (stem + '.stderr')).read_bytes()
assert all(row['fields'] == [10] for row in broad['differences'])
record['retained_broad_probe_failure'] = broad

with (p / (tag + '-selected-audit.json')).open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps(dict(status='passed', source=tag, profiles={k: r['passed'] for k, r in profiles.items()}, ordinary_comparisons=47, source_inputs=532)))
