from pathlib import Path
import hashlib, json, os, subprocess, sys, time

p = Path(__file__).parent.resolve()
label, binary_path = sys.argv[1:]
binary = Path(binary_path)
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
outdir = p / ('source309-active-lifecycle-' + label)
outdir.mkdir()
worker = p / 'native-unit309-active-worker.el'
caller = p / 'native-unit309-active-caller.el'
driver = p / 'native-unit309-active-driver.el'
results = {}
for stage, source in [('compile-caller', caller), ('compile-worker', worker), ('execute', None)]:
    env = dict(EMAXX_GC_VERIFY='1', LANG='C', LC_ALL='C',
               RUNTIME_UNIT_ACTIVE_WORKER=str(outdir / 'worker.eln'),
               RUNTIME_UNIT_ACTIVE_CALLER=str(outdir / 'caller.eln'))
    if source:
        env.update(RUNTIME_UNIT_ACTIVE_SOURCE=str(source),
                   RUNTIME_UNIT_ACTIVE_OUTPUT=str(outdir / ('caller.eln' if stage == 'compile-caller' else 'worker.eln')))
        args = ['--eval', '(progn (require (quote comp)) (native-compile (getenv "RUNTIME_UNIT_ACTIVE_SOURCE") (getenv "RUNTIME_UNIT_ACTIVE_OUTPUT")))']
    else:
        args = ['-l', str(driver)]
    command = [str(binary), '-Q', '--batch', *args]
    files = [binary, binary.with_suffix('.pdmp'), worker, caller, driver, Path(__file__)]
    if not source:
        files += [outdir / 'caller.eln', outdir / 'worker.eln']
    inputs = {str(f): sha(f) for f in files}
    (outdir / (stage + '-command.json')).open('x').write(json.dumps(dict(
        command=command, cwd=str(p), inputs=inputs, timeout_seconds=180,
        environment_overrides=env, qualification='Each editor compiles its own caller and worker in separate producer processes. A fresh consumer uses the same program through interpreted, bytecode and native calls. The worker unbinds itself and collects before returning real unit constants. No persistent function or unit handle is retained by the driver.'), indent=2))
    start = time.monotonic()
    try:
        run = subprocess.run(command, cwd=p, env=dict(os.environ, **env),
                             stdin=subprocess.DEVNULL, capture_output=True, timeout=180)
        code, stdout, stderr, timeout = run.returncode, run.stdout, run.stderr, False
    except subprocess.TimeoutExpired as error:
        code, stdout, stderr, timeout = None, error.stdout or b'', error.stderr or b'', True
    (outdir / (stage + '.stdout')).open('xb').write(stdout)
    (outdir / (stage + '.stderr')).open('xb').write(stderr)
    result = dict(exit_code=code, timed_out=timeout, elapsed_seconds=time.monotonic()-start,
                  stdout_sha256=hashlib.sha256(stdout).hexdigest(), stderr_sha256=hashlib.sha256(stderr).hexdigest(),
                  inputs_unchanged=all(sha(Path(f)) == h for f, h in inputs.items()))
    (outdir / (stage + '-result.json')).open('x').write(json.dumps(result, indent=2))
    results[stage] = result
    print(label, stage, result, stdout.decode(errors='backslashreplace'), stderr.decode(errors='backslashreplace'), flush=True)
    if code != 0 or timeout or not result['inputs_unchanged']:
        break
(outdir / 'result.json').open('x').write(json.dumps(results, indent=2))
