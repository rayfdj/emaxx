from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).parent.resolve();source=p/'native-unit309-file-worker.el';driver=p/'native-unit309-file-driver.el';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();results={}
for label,binary in [('gnu',p.parent/'rebuilt-2026-10-01/emacs/src/emacs'),('source308',p.parent/'recovered-2026-10-06/native-subr-callbacks/emaxx/target/vm-dispatch-validation/release/emaxx')]:
 outdir=p/('source309-file-lifecycle-'+label);outdir.mkdir();eln=outdir/'unit-worker.eln'
 for stage in ['compile','execute']:
  env=dict(EMAXX_GC_VERIFY='1',LANG='C',LC_ALL='C',RUNTIME_UNIT309_SOURCE=str(source),RUNTIME_UNIT309_ELN=str(eln))
  cmd=[str(binary),'-Q','--batch']+(['--eval','(progn (require (quote comp)) (native-compile (getenv "RUNTIME_UNIT309_SOURCE") (getenv "RUNTIME_UNIT309_ELN")))'] if stage=='compile' else ['-l',str(driver)])
  inputs={str(f):sha(f) for f in [binary,binary.with_suffix('.pdmp'),source,driver,Path(__file__),*([eln] if stage=='execute' else [])]}
  rec=dict(command=cmd,cwd=str(p),inputs=inputs,timeout_seconds=180,environment_overrides=env,goal_complete=False);(outdir/(stage+'-command.json')).open('x').write(json.dumps(rec,indent=2));start=time.monotonic()
  try:r=subprocess.run(cmd,cwd=p,env=dict(os.environ,**env),stdin=subprocess.DEVNULL,capture_output=True,timeout=180);code,out,err,timed=r.returncode,r.stdout,r.stderr,False
  except subprocess.TimeoutExpired as e:code,out,err,timed=None,e.stdout or b'',e.stderr or b'',True
  (outdir/(stage+'.stdout')).open('xb').write(out);(outdir/(stage+'.stderr')).open('xb').write(err);result=dict(exit_code=code,timed_out=timed,elapsed_seconds=time.monotonic()-start,stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),inputs_unchanged=all(sha(Path(f))==h for f,h in inputs.items()));(outdir/(stage+'-result.json')).open('x').write(json.dumps(result,indent=2));results[label+'-'+stage]=result;print(label,stage,result,out.decode(errors='backslashreplace'),err.decode(errors='backslashreplace'),flush=True)
  assert code==0 and not timed and result['inputs_unchanged']
(p/'source309-file-lifecycle-baseline-comparison.json').open('x').write(json.dumps(dict(outcomes=results,exact_match=all(results['gnu-execute'][k]==results['source308-execute'][k] for k in ('exit_code','stdout_sha256','stderr_sha256')),goal_complete=False),indent=2))
