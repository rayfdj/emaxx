from pathlib import Path
p=Path(__file__).parent.resolve();c=p.parent/'recovered-2026-10-06/native-unit-objects/emaxx'
f=c/'src/lisp/native_comp/loader.rs';s=f.read_text().replace('with_lisp_stack_roots(&owners,','with_lisp_stack_roots(&owners.as_slice(),');f.write_text(s)
f=c/'src/lisp/alloc/vectors/native_units.rs';s=f.read_text();a=s.index('impl Drop for NativeUnitState');s=s[:a]+'''impl NativeUnitState {
    fn unload(&self) {
        let handle = self.handle.replace(std::ptr::null_mut());
        if handle.is_null() {
            return;
        }
        // comp.c:unload_comp_unit. The GC calls this after tracing proves
        // no live function, loader frame or Lisp root reaches the unit.
        // Host-runtime teardown also calls it before dropping relocation
        // cells, just as the previous owning Library's destructor did.
        unsafe {
            let library = libloading::os::unix::Library::from_raw(handle);
            if let Ok(saved) = library.get::<*mut usize>(b"comp_unit\\0") {
                let header = (std::ptr::from_ref(self) as *const u8)
                    .sub(size_of::<VectorHeader>()).cast_mut().cast::<VectorHeader>();
                let word = Value::NativeCompUnit(NativeUnitRef::from_raw(header)).word();
                if !saved.is_null() && std::ptr::read(*saved) == word {
                    std::ptr::write(*saved, Value::Nil.word());
                }
            }
            drop(library);
        }
    }

    /// Emaxx can tear down an editor without ending its host process. Close
    /// the units whose actual ELN relocation points into that editor's native
    /// runtime before its stable thread cell is freed. No ownership id or
    /// weak handle registry is needed, and ordinary calls pay no lookup.
    pub(crate) fn close_for_runtime(&self, thread_cell: *mut c_void) {
        let Some(library) = self.library() else { return; };
        // SAFETY: this is the exact pointer field installed by comp.c's
        // first-load path. Inspection does not run Lisp or collect.
        let owned = unsafe {
            library.get::<*mut *mut c_void>(b"current_thread_reloc\\0")
                .is_ok_and(|reloc| !reloc.is_null() && std::ptr::read(*reloc) == thread_cell)
        };
        if owned {
            self.unload();
        }
    }
}

impl Drop for NativeUnitState {
    fn drop(&mut self) {
        self.unload();
    }
}
''';f.write_text(s)
f=c/'src/lisp/alloc/vectors.rs';s=f.read_text();a=s.index('/// alloc.c\'s `sweep_vectors\'.');s=s[:a]+'''/// Close native libraries owned by a host editor that is ending. The
/// allocator already owns the complete object inventory; walking it here
/// avoids permanent roots or a duplicate unit registry on ordinary paths.
pub(crate) fn close_native_units_for_runtime(thread_cell: *mut std::ffi::c_void) {
    for kind in [BlockKind::VectorBlock, BlockKind::LargeVector] {
        for block in blocks_of(kind) {
            let mut header = block as *mut VectorHeader;
            loop {
                // SAFETY: registered blocks are tiled by initialized headers.
                // Closing an ELN changes no Lisp allocation and runs no Lisp.
                unsafe {
                    if (*header).tag() == VectorTag::NativeCompUnit {
                        NativeUnitRef::from_raw(header).close_for_runtime(thread_cell);
                    }
                    if matches!(kind, BlockKind::LargeVector) {
                        break;
                    }
                    header = advance(header, (*header).nbytes());
                    if !vector_in_block(header, block) {
                        break;
                    }
                }
            }
        }
    }
}

'''+s[a:];f.write_text(s)
f=c/'src/lisp/native_comp/runtime.rs';s=f.read_text();a=s.index('impl std::ops::Deref for NativeRuntime');s=s[:a]+'''impl Drop for NativeSharedState {
    fn drop(&mut self) {
        if self.linked_code {
            // Only the final shared owner runs this, after native frames have
            // ended. Empty parked/default shells have no attached code.
            crate::lisp::alloc::vectors::close_native_units_for_runtime(
                std::ptr::from_mut(&mut *self.thread_pointer).cast(),
            );
        }
    }
}

'''+s[a:];f.write_text(s)
print('preserved editor teardown without a unit registry')
