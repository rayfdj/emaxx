from pathlib import Path
p=Path(__file__).parent.resolve();c=p.parent/'recovered-2026-10-06/native-unit-objects/emaxx'
def edit(name,old,new,count=1):
 f=c/name;s=f.read_text();assert s.count(old)==count,(name,old[:100],s.count(old));f.write_text(s.replace(old,new))
edit('src/lisp/primitives/values.rs','        Kind::NativeFunction(function) => {\n            hash_mix(state, 53);','        Kind::NativeCompUnit(unit) => {\n            hash_mix(state, 54);\n            hash_mix(state, unit.identity() as u64);\n        }\n        Kind::NativeFunction(function) => {\n            hash_mix(state, 53);',2)
f=c/'src/lisp/native_comp/loader.rs';s=f.read_text()
s=s.replace('use crate::lisp::eval::{Interpreter, RecordKind};','use crate::lisp::eval::Interpreter;').replace('LispError, NativeFunctionRef, Value','LispError, NativeFunctionRef, NativeUnitRef, Value')
a=s.index('struct LoadedUnit {');b=s.index('struct EphemeralRelocations',a);s=s[:a]+s[b:]
a=s.index('/// A loader execution shell.');b=s.index("pub(super) struct LoaderState",a);s=s[:a]+s[b:]
s=s.replace("    registry: &'a mut NativeRegistry,\n",'').replace("        registry: &'a mut NativeRegistry,\n",'').replace('            registry,\n','')
s=s.replace('    static ACTIVE_REGISTRY: Cell<*mut NativeRegistry> = const { Cell::new(std::ptr::null_mut()) };\n','').replace('    previous_registry: *mut NativeRegistry,\n','').replace('        ACTIVE_REGISTRY.set(self.previous_registry);\n','')
s=s.replace('    registry: &mut NativeRegistry,\n','').replace('    let previous_registry = ACTIVE_REGISTRY.replace(registry);\n','').replace('        previous_registry,\n','')
s=s.replace('    let registry = ACTIVE_REGISTRY.replace(std::ptr::null_mut());\n','').replace('        previous_registry: registry,\n','')
a=s.index('    // SAFETY: this private scope is entered');b=s.index('    let placeholder_compiler',a);s=s[:a]+s[b:]
a=s.index('    if let Some(placeholder) = placeholder_registry');b=s.index('    if let Some(placeholder) = placeholder_compiler',a);s=s[:a]+s[b:]
a=s.index('fn with_active_registry');b=s.index('pub(super) fn with_active_registered_runtime',a);s=s[:a]+s[b:]
# Debug consistency checks now read GNU's actual unit fields, not a host mirror.
s=s.replace('    unit: &LoadedUnit,','    unit: NativeUnitRef,').replace('vector_values(&unit._data)','vector_values(&unit.field(5))').replace('vector_values(&unit._impure_data)','vector_values(&unit.field(6))')
s=s.replace('''    if data_values.len() != unit.data_relocation_count {
        return false;
    }
''','''    let Some(library) = unit.library() else { return false; };
    let Ok(data_relocations) = (unsafe { data_symbol::<NativeWord>(&library, DATA_RELOC_SYM) }) else { return false; };
''').replace('unit.data_relocations.add(index)','data_relocations.add(index)')
s=s.replace('''    if impure_values.len() != unit.impure_relocation_count {
        return false;
    }
    let Some(guard) = interpreter
        .find_record(unit.record_id)
        .and_then(|record| record.slots.get(2))
    else {
        return false;
    };''','    let guard = unit.field(2);')
s=s.replace('unit.impure_relocations.add(', 'unit.impure_relocations().add(').replace('unit.impure_relocation_count', 'unit.impure_relocation_count()')
# Normal load: stable GC unit replaces Rc<LoadedUnit> and record-id lookup.
s=s.replace('''        registry,
''','')
s=s.replace('    let (record_id, unit, top_level) = if saved_word != 0 {','    let (unit, top_level) = if saved_word != 0 {')
s=s.replace('''        let unit = runtime.decode_relocation(saved_word)?;
        let Kind::Record(record_id) = unit.kind() else {
            return Err(inconsistent(filename));
        };
        let loaded = registry
            .unit(record_id.id)
            .ok_or_else(|| inconsistent(filename))?;
        loaded.loaded_once.set(true);
        let unit_file = interpreter
            .find_record(record_id)
            .and_then(|record| record.slots.first())
            .cloned()
            .unwrap_or(*filename);''','''        let Kind::NativeCompUnit(unit) = runtime.decode_relocation(saved_word)?.kind() else {
            return Err(inconsistent(filename));
        };
        if !unit.is_loaded() { return Err(inconsistent(filename)); }
        unit.loaded_once.set(true);
        let unit_file = unit.field(0);''')
s=s.replace('        (record_id.id, unit, top_level)','        (unit, top_level)')
s=s.replace('''    let loaded = registry
        .unit(record_id)
        .expect("unit registered before its top-level code runs");
    let recursive_load = loaded.load_ongoing.replace(true);
    let unit_file = interpreter
        .find_record(record_id)
        .and_then(|record| record.slots.first())
        .cloned()
        .unwrap_or(*filename);''','''    let unit_value = Value::NativeCompUnit(unit);
    interpreter.with_lisp_stack_roots(&unit_value, |interpreter| {
    let recursive_load = unit.load_ongoing.replace(true);
    let unit_file = unit.field(0);
    let library = unit.library().expect("unit owns its handle before top-level code");''')
s=s.replace('            &loaded.library,','            &library,').replace('with_native_state(compiler, registry, runtime,','with_native_state(compiler, runtime,').replace('std::slice::from_ref(&unit),','std::slice::from_ref(&unit_value),')
s=s.replace('            &loaded,','            unit,').replace('        loaded.load_ongoing.set(false);','        unit.load_ongoing.set(false);').replace('&[unit_file, unit, loaded_units]','&[unit_file, unit_value, loaded_units]')
a=s.index('    Ok(result)\n}',s.index('pub(super) fn load('));s=s[:a]+s[a:].replace('    Ok(result)\n}','    Ok(result)\n    })\n}',1)
s=s.replace(') -> Result<(u64, Value, *const c_void), LispError> {',') -> Result<(NativeUnitRef, *const c_void), LispError> {')
a=s.index('    let Kind::Record(record_id) = candidate_unit.kind()');b=s.index('    unsafe { std::ptr::write(saved_unit, unit_word) };',a)
s=s[:a]+'''    let Kind::NativeCompUnit(unit) = candidate_unit.kind() else {
        unreachable!("native load candidate is a native compilation unit")
    };
    let file = unit.field(0);
    let unit_word = candidate_unit.word();
'''+s[b:]
a=s.index('    {\n        let record = interpreter',s.index('fn first_load'));b=s.index('    let data_relocations =',a)
s=s[:a]+'''    unit.set_field(1, optimization_qualities);
    unit.set_field(5, data);
    unit.set_field(6, impure_data);
'''+s[b:]
a=s.index('    let data_relocations =',s.index('fn first_load'));b=s.index('    saved_unit_rollback.disarm();',a)
s=s[:a]+'''    unsafe { fill_relocations(&library, DATA_RELOC_SYM, runtime, &data_values)? };
    let impure_relocations =
        unsafe { fill_relocations(&library, DATA_RELOC_IMPURE_SYM, runtime, &impure_values)? };
    unit.install_library(library, impure_relocations);
'''+s[b:]
s=s.replace('    Ok((record_id.id, unit, top_level))','    Ok((unit, top_level))')
a=s.index('    if ACTIVE_REGISTRY.with(Cell::get).is_null()',s.index('pub(crate) fn load_active'));b=s.index('\n}\n',a)
s=s[:a]+'''    if ACTIVE_COMPILER.with(Cell::get).is_null() {
        return Err(library);
    }
    Ok(with_active_compiler(|compiler| {
        super::runtime::with_current_runtime(|runtime| {
            load(LoaderState::new(compiler, runtime), interpreter, environment,
                 filename, library, candidate_unit, late)
        }).unwrap_or_else(|| Err(super::lisp::native_ice("active loader has no active runtime")))
    }).expect("active compiler checked above"))'''+s[b:]
s=s.replace('let Kind::Record(unit_record_id) = arguments[6].kind()', 'let Kind::NativeCompUnit(unit) = arguments[6].kind()')
s=s.replace('''        let unit = registry.unit(unit_record_id.id).ok_or_else(|| {
            LispError::SignalValue(Value::list([Value::symbol("wrong-register-subr-call")]))
        })?;''','''        let library = unit.library().ok_or_else(|| {
            LispError::SignalValue(Value::list([Value::symbol("wrong-register-subr-call")]))
        })?;''').replace('function_symbol(&unit.library,','function_symbol(&library,')
a=s.index('            let (lambda_guard, lambda_name_index) = {',s.index('pub(super) fn register_with_state'));b=s.index('            super::lisp::call_c_primitive(',a)
s=s[:a]+'''            let lambda_guard = unit.field(2);
            let lambda_name_index = unit.field(3);
'''+s[b:]
s=s.replace('''            let unit = registry
                .unit(unit_record_id.id)
                .expect("unit checked before registration");
''','')
a=s.index('    if ACTIVE_REGISTRY.with(Cell::get).is_null()',s.index('pub(crate) fn register_active'));b=s.index('\n}\n',a)
s=s[:a]+'''    if ACTIVE_COMPILER.with(Cell::get).is_null() {
        return None;
    }
    Some(super::runtime::with_current_runtime(|runtime| {
        register_with_state(runtime, interpreter, environment, arguments, kind)
    }).unwrap_or_else(|| Err(super::lisp::native_ice("active loader has no active runtime"))))'''+s[b:]
# Image-load paths use the same unit handle and seven fields.
a=s.index('    record_id: u64,',s.index('pub(super) fn load_dumped_unit'));s=s[:a]+s[a:].replace('    record_id: u64,','    unit: NativeUnitRef,',1)
a=s.index('    let unit = interpreter.record_value(record_id);',s.index('pub(super) fn load_dumped_unit'));b=s.index('    if let Some(text) =',a)
s=s[:a]+'''    let unit_value = Value::NativeCompUnit(unit);
    let file = unit.field(0);
    let lambda_guard = crate::lisp::json::make_hash_table(interpreter, "eq", Vec::new());
    unit.set_field(2, lambda_guard);
'''+s[b:]
s=s.replace('''    if let Some(record) = interpreter.find_record_mut(record_id)
        && let Some(slot) = record.slots.first_mut()
    {
        *slot = eln_file;
    }''','    unit.set_field(0, eln_file);')
s=s.replace('runtime.encode_relocations(std::slice::from_ref(&unit))?[0]', 'unit_value.word()')
a=s.index('    let (optimization_qualities, data, impure_data) = {');b=s.index('    saved_unit_rollback.disarm();',a)
s=s[:a]+'''    let data_values = vector_values(&unit.field(5))?;
    let impure_values = vector_values(&unit.field(6))?;
    unsafe { fill_relocations(&library, DATA_RELOC_SYM, runtime, &data_values)? };
    let impure_relocations =
        unsafe { fill_relocations(&library, DATA_RELOC_IMPURE_SYM, runtime, &impure_values)? };
    unit.install_library(library, impure_relocations);
'''+s[b:]
s=s.replace('&[eln_file, unit, loaded_units]', '&[eln_file, unit_value, loaded_units]')
s=s.replace('let Kind::Record(unit_record_id) = function.unit().kind()', 'let Kind::NativeCompUnit(unit) = function.unit().kind()')
a=s.index('    let unit_file = interpreter',s.index('pub(super) fn resolve_dumped_function'));b=s.index('    let c_name =',a)
s=s[:a]+'''    let unit_file = string_like(&unit.field(0)).map(|string| string.text).unwrap_or_default();
    let library = unit.library()
        .ok_or_else(|| dump_load_error(format!("NULL handle in compilation unit {unit_file}")))?;
'''+s[b:]
a=s.index('    let (lambda_guard, lambda_name_index) = {',s.index('pub(super) fn resolve_dumped_function'));b=s.index('    let lambda_data_index =',a)
s=s[:a]+'''    let lambda_guard = unit.field(2);
    let lambda_name_index = unit.field(3);
'''+s[b:]
a=s.index('pub(crate) fn unit_documentation(');b=s.index('pub(crate) fn direct_function',a)
s=s[:a]+'''pub(crate) fn unit_documentation(
    interpreter: &mut Interpreter,
    environment: &mut Env,
    unit: NativeUnitRef,
) -> Result<Value, LispError> {
    interpreter.with_lisp_stack_roots(&Value::NativeCompUnit(unit), |interpreter| {
        let library = unit.library()
            .ok_or_else(|| super::lisp::native_ice("native compilation unit is not loaded"))?;
        let file = unit.field(0);
        let docs = unsafe {
            read_static_object(&library, &file, TEXT_FDOC_SYM, interpreter, environment)?
        };
        if !is_vector_value(&docs) {
            return Err(LispError::SignalValue(Value::list([
                Value::symbol("native-lisp-file-inconsistent"), file,
                Value::string("missing documentation vector"),
            ])));
        }
        unit.set_field(4, docs);
        Ok(docs)
    })
}

'''+s[b:]
f.write_text(s)
# Remove the loader registry from its owning/suspended execution state.
f=c/'src/lisp/native_comp/state.rs';s=f.read_text().replace('loader::{self, NativeRegistry},','loader,').replace('    pub(super) registry: Box<NativeRegistry>,\n','').replace(' && self.registry.is_empty()','')
a=s.index('    /// The counter as the image load begins.');b=s.index('    pub(crate) fn garbage_collection_note_image_load_start',a);s=s[:a]+s[b:]
s=s.replace('loader::LoaderState::new(&self.compiler, &mut self.registry, &mut self.runtime)','loader::LoaderState::new(&self.compiler, &mut self.runtime)').replace('            &mut self.registry,\n','').replace('                &mut self.registry,\n','')
s=s.replace('units: &[u64]', 'units: &[crate::lisp::types::NativeUnitRef]').replace('for &record_id in units','for &unit in units').replace('                record_id,','                unit,')
a=s.index('    pub(crate) fn unit_documentation');b=s.index('    pub(crate) fn install_trampoline',a);s=s[:a]+s[b:]
s=s.replace('''        let Self {
            runtime, registry, ..
        } = self;''','        let runtime = &mut self.runtime;').replace('with_native_state(&self.compiler, registry, runtime,', 'with_native_state(&self.compiler, runtime,')
f.write_text(s)
f=c/'src/lisp/native_comp/runtime/suspension.rs';s=f.read_text().replace('        &mut state.registry,\n','');f.write_text(s)
f=c/'src/lisp/eval.rs';s=f.read_text().replace('''        for id in self.native_compiler.held_record_ids() {
            hold(id);
        }
''','').replace('''    /// native compilation units and subrs the loader holds (comp.c's
    /// loaded-units table and the subrs' unit slots).
''','''    /// windows. Native units are reached through actual Lisp roots, as the
    /// loaded-units table has weak values in GNU.
''');f.write_text(s)
f=c/'src/lisp/native_comp/mod.rs';s=f.read_text();a=s.index('    let Kind::Record(unit_id) = function.unit().kind()');b=s.index('    let docs = crate::lisp::primitives::vector_items(&docs)',a)
s=s[:a]+'''    let Kind::NativeCompUnit(unit) = function.unit().kind() else {
        return Err(lisp::native_ice("native function has no compilation unit"));
    };
    let docs = unit.field(4);
    let docs = if docs.is_nil() {
        loader::unit_documentation(interpreter, environment, unit)?
    } else { docs };
'''+s[b:];s=s.replace('units: &[u64]', 'units: &[crate::lisp::types::NativeUnitRef]');f.write_text(s)
print('migrated native loader and removed persistent unit registry')
