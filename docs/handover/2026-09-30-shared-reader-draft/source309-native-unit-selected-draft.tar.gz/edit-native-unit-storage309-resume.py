from pathlib import Path
p=Path(__file__).parent.resolve();c=p.parent/'recovered-2026-10-06/native-unit-objects/emaxx'
def edit(name,old,new,count=1):
 f=c/name;s=f.read_text();assert s.count(old)==count,(name,old[:100],s.count(old));f.write_text(s.replace(old,new))
edit('src/lisp/alloc/vectors.rs','            | VectorTag::Subr => {','            | VectorTag::Subr\n            | VectorTag::NativeCompUnit => {',2)
edit('src/lisp/alloc/vectors.rs','            VectorTag::Free => {}','            VectorTag::NativeCompUnit => {\n                std::ptr::drop_in_place(body.cast::<native_units::NativeUnitState>())\n            }\n            VectorTag::Free => {}')
edit('src/lisp/alloc/vectors.rs','            VectorTag::Subr => Value::NativeFunction(NativeFunctionRef::from_raw(header)),','            VectorTag::Subr => Value::NativeFunction(NativeFunctionRef::from_raw(header)),\n            VectorTag::NativeCompUnit => Value::NativeCompUnit(NativeUnitRef::from_raw(header)),')
edit('src/lisp/types.rs','pub use crate::lisp::alloc::vectors::NativeFunctionRef;','pub use crate::lisp::alloc::vectors::{NativeFunctionRef, NativeUnitRef};')
edit('src/lisp/types.rs','    NativeFunction(NativeFunctionRef),','    NativeFunction(NativeFunctionRef),\n    /// The authoritative GNU native compilation unit and owned library handle.\n    NativeCompUnit(NativeUnitRef),')
edit('src/lisp/types.rs','    pub fn NativeFunction(function: NativeFunctionRef) -> Value {','    pub fn NativeCompUnit(unit: NativeUnitRef) -> Value {\n        Value::from_bits(unit.identity() | TAG_VECTORLIKE)\n    }\n    #[inline]\n    pub fn NativeFunction(function: NativeFunctionRef) -> Value {')
edit('src/lisp/types.rs','                        crate::lisp::alloc::VectorTag::Subr => {','                        crate::lisp::alloc::VectorTag::NativeCompUnit => {\n                            Kind::NativeCompUnit(NativeUnitRef::from_raw(header))\n                        }\n                        crate::lisp::alloc::VectorTag::Subr => {')
edit('src/lisp/types.rs','            Kind::NativeFunction(v) => Value::NativeFunction(v),','            Kind::NativeFunction(v) => Value::NativeFunction(v),\n            Kind::NativeCompUnit(v) => Value::NativeCompUnit(v),')
edit('src/lisp/types.rs','            Kind::NativeFunction(function) => format!("native-function<{}>", function.name()),','            Kind::NativeFunction(function) => format!("native-function<{}>", function.name()),\n            Kind::NativeCompUnit(_) => "native-comp-unit".into(),')
edit('src/lisp/types.rs','        (Kind::NativeFunction(a), Kind::NativeFunction(b)) => a.ptr_eq(&b),','        (Kind::NativeFunction(a), Kind::NativeFunction(b)) => a.ptr_eq(&b),\n        (Kind::NativeCompUnit(a), Kind::NativeCompUnit(b)) => a.ptr_eq(&b),')
edit('src/lisp/types.rs','        Kind::NativeFunction(function) => write!(f, "#<subr {}>", function.name()),','        Kind::NativeFunction(function) => write!(f, "#<subr {}>", function.name()),\n        Kind::NativeCompUnit(unit) => write!(f, "#<native-comp-unit {}>", unit.field(0)),')
edit('src/lisp/eval.rs','    NativeCompUnit,\n','')
edit('src/lisp/eval.rs','            Self::NativeCompUnit => 11,\n','')
edit('src/lisp/eval.rs','            Kind::NativeFunction(value) => value.mark_bit().is_marked(self.epoch),','            Kind::NativeFunction(value) => value.mark_bit().is_marked(self.epoch),\n            Kind::NativeCompUnit(value) => value.mark_bit().is_marked(self.epoch),')
edit('src/lisp/eval.rs','            Kind::NativeFunction(value) => value.mark_bit().mark(self.epoch),','            Kind::NativeFunction(value) => value.mark_bit().mark(self.epoch),\n            Kind::NativeCompUnit(value) => value.mark_bit().mark(self.epoch),')
edit('src/lisp/eval.rs','            Kind::NativeFunction(function) => {\n                for field in function.fields() {','            Kind::NativeCompUnit(unit) => {\n                for field in unit.fields() {\n                    self.enqueue(&field);\n                }\n            }\n            Kind::NativeFunction(function) => {\n                for field in function.fields() {')
edit('src/lisp/eval.rs','            Kind::NativeFunction(function) => {\n                let key = function.identity();','''            Kind::NativeCompUnit(unit) => {
                assert!(!unit.is_loaded(), "cannot clone live native relocation pointers");
                let key = unit.identity();
                if let Some(copied) = self.vectors.get(&key) {
                    return *copied;
                }
                let copy = crate::lisp::types::NativeUnitRef::new();
                let copied = Value::NativeCompUnit(copy);
                self.vectors.insert(key, copied);
                copy.set_fields(unit.fields().map(|field| self.copy(&field)));
                copied
            }
            Kind::NativeFunction(function) => {
                let key = function.identity();''')
edit('src/lisp/alloc.rs','        Kind::NativeFunction(function) => Some(function.mark_bit().is_marked(epoch)),','        Kind::NativeFunction(function) => Some(function.mark_bit().is_marked(epoch)),\n        Kind::NativeCompUnit(unit) => Some(unit.mark_bit().is_marked(epoch)),')
edit('src/lisp/native_comp/runtime.rs','                        | crate::lisp::alloc::VectorTag::Subr','                        | crate::lisp::alloc::VectorTag::Subr\n                        | crate::lisp::alloc::VectorTag::NativeCompUnit')
for name in ['src/lisp/primitives/values.rs','src/lisp/primitives/buffers.rs']:
 f=c/name;s=f.read_text();s='\n'.join(line for line in s.split('\n') if 'RecordKind::NativeCompUnit' not in line);f.write_text(s)
edit('src/lisp/primitives/values.rs','        (Kind::NativeFunction(a), Kind::NativeFunction(b)) => a.ptr_eq(&b),','        (Kind::NativeFunction(a), Kind::NativeFunction(b)) => a.ptr_eq(&b),\n        (Kind::NativeCompUnit(a), Kind::NativeCompUnit(b)) => a.ptr_eq(&b),',3)
# Identity-only native units have no structural equality or hash recursion.
edit('src/lisp/primitives/values.rs','        Kind::NativeFunction(function) => {\n            hash_mix(state, 53);','        Kind::NativeCompUnit(unit) => {\n            hash_mix(state, 54);\n            hash_mix(state, unit.identity() as u64);\n        }\n        Kind::NativeFunction(function) => {\n            hash_mix(state, 53);')
print('installed actual native-unit storage and core tags')
