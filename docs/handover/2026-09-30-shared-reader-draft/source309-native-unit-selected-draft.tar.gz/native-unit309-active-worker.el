;; -*- coding: utf-8; lexical-binding: t; -*-
(defvar runtime-unit-active-weak)
(defun runtime-unit-active-worker (input)
  "Unbind this function while its machine frame still needs the unit."
  (fmakunbound 'runtime-unit-active-worker)
  (garbage-collect)
  (list (+ input 29) '(live (7 . 19) [37 61])
        (hash-table-count runtime-unit-active-weak)))
