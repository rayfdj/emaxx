from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
out = p.parents[2] / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda n: json.loads((p / n).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
audit = read('source309-selected-audit.json')
assert audit['status'] == 'passed' and audit['source_inputs_verified'] == 546
assert all(r['passed'] == 1035 for r in audit['profiles'].values())
assert audit['ordinary_comparisons'] == 56
assert read('source309-native-ownership-review.json')['runtime_owner_review']['status'] == 'successor required'
for n, h in audit['evidence_files'].items():
    assert sha(Path(n).read_bytes()) == h
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected'}
files, excluded = {}, []
for f in p.iterdir():
    if f.is_file() and f.suffix in allowed and f.name.startswith(('source309-', 'native-unit309-')):
        files[f.name] = f
    elif f.is_dir() and f.name.startswith('source309-') and any(w in f.name for w in ['file-lifecycle', 'active-lifecycle', 'retained-inputs']):
        for item in f.rglob('*'):
            if not item.is_file():
                continue
            if item.suffix in allowed:
                files[str(item.relative_to(p))] = item
            else:
                excluded.append(dict(path=str(item.relative_to(p)), bytes=item.stat().st_size, sha256=sha(item.read_bytes())))
for f in p.glob('*.py'):
    if '309' in f.name and any(w in f.name for w in ['native-unit', 'native-unit-', 'source309']):
        files[f.name] = f
for n in [
    'source308-manifest.json', 'source308-selected-audit.json', 'source308-validation-result.json',
    'source308-gate-inventory.log', 'source308-release-inventory.log',
    'source304-selected-audit.json', 'native_fixed_validation_support.py',
    'printer-varied-v3-293638f0.el', 'printer-varied-v3-gnu.stdout',
    'source302-line-broad-gnu.stdout', 'package-source196-failure-and197-results.py',
    Path(__file__).name,
]:
    files[n] = p / n
assert all(f.is_file() for f in files.values())
package('source309-native-unit-selected-draft', files, dict(
    status='portable selected draft; not applied because repeated-load ownership review requires a successor',
    source_inputs=546, passes_per_profile=1035, new_focused_per_profile=4, ordinary_comparisons=56,
    generated_rows=198, owner_review=read('source309-native-ownership-review.json'),
    excluded_binaries=excluded, goal_complete=False,
    qualification='Actual88-byte native units own their seven Lisp fields, flags, impure relocation pointer and dlopen handle. Host records, strong registry and permanent relocation roots are removed. Every predecessor fixture and selected name remains, including24 audit controls. GNU-confirmed printing/errors and anonymous/file/active-call lifetime comparisons match every output byte. In the fresh-process file and active-call controls, the prior308 retains a unit after each call while GNU and309 reclaim it; all real function answers remain identical. Development compile and Clippy failures remain preserved. The generator set-union typo was caught before launch; its fixed generator and unchanged launched runner are both retained. The review identifies a missing repeated-load owner check between two Rust editor instances; this prevents applying309 despite its selected passes. Complete platform validation, internal soundness, physical accounting and performance remain separate requirements.'))
