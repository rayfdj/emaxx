from pathlib import Path
import hashlib, json, re
from native_fixed_validation_support import audit_selected

p = Path(__file__).parent.resolve()
c = p.parent / 'recovered-2026-10-06/native-unit-objects/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p / n).read_text())
manifest = read('source309-manifest.json')
modes = read('source309-modes.json')
assert len(manifest) == len(modes) == 546
assert all(sha(c / n) == h and (c / n).stat().st_mode & 0o777 == modes[n] for n, h in manifest.items())
prior = read('source308-manifest.json')
assert all(manifest[n] == h for n, h in prior.items() if n.startswith(('tests/', 'tools/', 'compat/')))
assert manifest['src/anti_cheat.rs'] == prior['src/anti_cheat.rs']
for n in manifest:
    if n.endswith('.rs'):
        raw = (c / n).read_text()
        assert all(old not in raw for old in ['RecordKind::NativeCompUnit', 'NativeRegistry', 'struct LoadedUnit'])
state = read('source309-validation-result.json')
assert state['status'] == 'strict, selected and ordinary build passed; raw audit and ordinary comparisons required'
assert all(r['exit_code'] == 0 and not r['timed_out'] and r['source_unchanged'] for r in state['results'])
assert sha(p / state['runner']) == state['runner_sha256']
new = {
    'lisp::alloc::vectors::tests::native_unit_allocation_has_actual_gnu_fields_and_direct_tagged_identity',
    'lisp::alloc::vectors::tests::native_unit_traces_seven_fields_from_a_subr_and_collects_the_unreachable_cycle',
    'lisp::native_comp::loader::tests::native_unit_relocations_decode_the_actual_allocation_without_a_registry',
    'lisp::primitives::tests::native_unit_fields_preserve_gnu_printing_identity_properties_and_errors',
}
profiles = {}
for profile, required in [('gate', 3052), ('release', 3051)]:
    inventory = lambda tag: [line[:-6] for line in (p / f'{tag}-{profile}-inventory.log').read_text().splitlines() if line.endswith(': test')]
    names = inventory('source309')
    assert len(names) == len(set(names)) == required
    assert set(names) == set(inventory('source308')) | new
    baseline = set(read('source308-validation-result.json')['profiles'][profile]['selectors'])
    selected = [n for n in names if n in baseline or re.search(r'native|pdump|dump_|image|module|weak|thread|suspended|purecopy|hash|value_|print|command|completion|substitut|propert', n)]
    assert len(baseline) == 1031 and len(selected) == 1035 and baseline | new <= set(selected)
    assert len([n for n in selected if n.startswith('anti_cheat::')]) == 24
    record = state['profiles'][profile]
    assert record['selectors'] == selected
    focused = audit_selected((p / f'source309-{profile}-focused.log').read_text(), sorted(new))
    counts = audit_selected((p / f'source309-{profile}-selected.log').read_text(), selected)
    assert focused['passed'] == 4 and counts['passed'] == record['passed'] == 1035
    assert sha(Path(record['binary'])) == sha(Path(record['retained_binary'])) == record['binary_sha256']
    for item in record['retained_inputs']:
        assert sha(Path(item['original'])) == sha(Path(item['retained'])) == item['sha256']
    messages = [json.loads(line) for line in (p / f'source309-{profile}-build.log').read_text().splitlines() if line.startswith('{')]
    artifacts = [a for a in messages if a.get('reason') == 'compiler-artifact' and a['target']['name'] == 'emaxx' and a.get('profile', {}).get('test') and a.get('executable')]
    assert len(artifacts) == 1 and artifacts[0]['fresh'] is False and artifacts[0]['executable'] == record['binary']
    profiles[profile] = dict(**counts, focused=focused, selectors=selected, binary_sha256=record['binary_sha256'])
for stage in ['fmt', 'check', 'clippy', 'diff', 'gate-build', 'release-build', 'ordinary-build']:
    raw = (p / f'source309-{stage}.log').read_text()
    assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
    for line in raw.splitlines():
        if line.startswith('{'):
            assert json.loads(line).get('message', {}).get('level') not in ['warning', 'error']
artifacts = read('source309-ordinary-artifacts.json')
assert all(sha(Path(f)) == sha(Path(v['immutable_copy'])) == v['sha256'] for f, v in artifacts.items())
portable = read('source309-portable-draft-audit.json')
assert len(portable['patches']) == 2
for record in portable['patches']:
    assert record['inputs'] == 546 and record['bytes_and_modes'] == 'exact' and sha(p / record['patch']) == record['sha256']
ordinary = {}
names = list(read('source304-selected-audit.json')['ordinary_results']) + ['native-subr-authority', 'native-subr-c-names', 'native-subr-consumers', 'native-unit-authority']
assert len(names) == len(set(names)) == 52
for name in names:
    prefix = 'source309-ordinary-' + name
    comparison = read(prefix + '-comparison.json')
    assert comparison['passed'] and comparison['exact_match'], name
    outputs = []
    for editor in ['gnu', 'emaxx']:
        stem = prefix + '-' + editor
        result = read(stem + '.result.json')
        command = read(stem + '.command.json')
        assert all(sha(Path(f)) == h for f, h in command['inputs'].items())
        assert result['exit_code'] == 0 and not result['timed_out'] and result['inputs_unchanged'] and result['source_unchanged'] and result['expected_output'] is not False
        stdout, stderr = (p / (stem + '.stdout')).read_bytes(), (p / (stem + '.stderr')).read_bytes()
        assert stdout and not stderr and hashlib.sha256(stdout).hexdigest() == result['stdout_sha256']
        outputs.append(stdout)
    assert outputs[0] == outputs[1]
    ordinary[name] = comparison
driver = p / 'source309-native-c-names-loaded-driver.el'
assert driver.read_text() == ';; -*- coding: utf-8; lexical-binding: nil; -*-\n(prin1 ' + (c / 'tests/fixtures/native-subr-c-names.el').read_text() + ')\n'
for editor in ['gnu', 'emaxx']:
    command = read('source309-ordinary-native-subr-c-names-' + editor + '.command.json')
    assert command['command'][-2:] == ['-l', str(driver)]
assert read('source309-generated-loaded-comparison.json')['passed']
for editor in ['gnu', 'emaxx']:
    stem = 'source309-generated-loaded-' + editor
    result = read(stem + '-result.json')
    command = read(stem + '-command.json')
    assert all(sha(Path(f)) == h for f, h in command['inputs'].items())
    stdout = (p / (stem + '.stdout')).read_bytes()
    assert result['exit_code'] == 0 and not result['timed_out'] and result['inputs_unchanged'] and result['source_unchanged']
    assert len(stdout) == 4088269 and len(stdout.splitlines()) == 198 and stdout == (p / 'printer-varied-v3-gnu.stdout').read_bytes()
    assert not (p / (stem + '.stderr')).read_bytes()
queue = read('source309-ordinary-queue-result.json')
assert queue['status'] == 'ordinary comparisons passed; independent raw audit required'
assert all(sha(p / n) == h for n, h in queue['helpers'].items())
lifecycles = {}
for name, stems, dotted in [
    ('file-lifecycle', ['source309-file-lifecycle-gnu/execute', 'source309-file-lifecycle-source309/execute'], False),
    ('active-lifecycle', ['source309-active-lifecycle-gnu/execute', 'source309-active-lifecycle-source309/execute'], False),
    ('anonymous-lifecycle', ['source309-lifecycle-baseline-gnu', 'source309-lifecycle-candidate-source309'], True),
]:
    outputs = []
    for stem in stems:
        command = read(stem + ('.command.json' if dotted else '-command.json'))
        result = read(stem + ('.result.json' if dotted else '-result.json'))
        assert all(sha(Path(f)) == h for f, h in command['inputs'].items())
        assert result['exit_code'] == 0 and not result['timed_out'] and result['inputs_unchanged']
        stdout, stderr = (p / (stem + '.stdout')).read_bytes(), (p / (stem + '.stderr')).read_bytes()
        assert stdout and not stderr and sha(p / (stem + '.stdout')) == result['stdout_sha256']
        outputs.append(stdout)
    assert outputs[0] == outputs[1], name
    comparison = read('source309-ordinary-' + name + '-comparison.json')
    assert comparison['passed'] and comparison['exact_match'] and comparison['source_unchanged']
    lifecycles[name] = comparison
assert (p / 'source309-file-lifecycle-source309/execute.stdout').read_bytes() == (c / 'tests/fixtures/native-unit-lifecycle.expected').read_bytes().rstrip(b'\n')
assert (p / 'source309-ordinary-buffer-lf-line-index-emaxx.stdout').read_bytes() == (p / 'source302-line-broad-gnu.stdout').read_bytes()
evidence = {str(f): sha(f) for f in p.glob('source309-*') if f.is_file() and f.suffix in ['.json', '.log', '.stdout', '.stderr', '.patch', '.el', '.expected']}
result = dict(status='passed', source_inputs_verified=546, profiles=profiles, ordinary_comparisons=56,
              ordinary_results=ordinary, lifecycle_results=lifecycles, generated_rows=198,
              ordinary_artifacts=artifacts, portable_replays=portable['patches'], evidence_files=evidence, goal_complete=False,
              qualification='The actual88-byte native unit replaces its host record, strong native registry and permanent relocation roots. All1031 predecessor selected controls remain plusfour new controls. Both profiles and every ordinary comparison are independently audited. Metadata follows actual GNU, and native code survives active collection and becomes reclaimable after calls. Obsolete representation assertions are explicitly migrated, including removal of the deleted registry-is-empty assertion; semantic assertions and original fixture bytes remain. This is selected correctness evidence only; no complete platform, whole-runtime soundness, physical accounting or performance acceptance claim.')
(p / 'source309-selected-audit.json').open('x').write(json.dumps(result, indent=2))
print(json.dumps(dict(status='passed', source_inputs=546, passes_per_profile=1035, ordinary_comparisons=56)))
