from pathlib import Path
p=Path(__file__).parent.resolve();c=p.parent/'recovered-2026-10-06/native-unit-objects/emaxx'
def edit(name,old,new,count=1):
 f=c/name;s=f.read_text();assert s.count(old)==count,(name,old[:100],s.count(old));f.write_text(s.replace(old,new))
f=c/'src/lisp/alloc/vectors/native_units.rs'
f.open('x').write('''//! comp.h:Lisp_Native_Comp_Unit: seven traced Lisp words and the actual
//! relocation pointer, load flags and dynamic-library handle.

use super::{VectorHeader, VectorTag, Vectorlike, VectorlikeRef};
use crate::lisp::types::Value;
use libloading::Library;
use std::cell::Cell;
use std::ffi::c_void;
use std::mem::ManuallyDrop;

#[repr(C)]
#[derive(Debug)]
pub struct NativeUnitState {
    fields: [Cell<Value>; 7],
    impure_relocations: Cell<*mut usize>,
    pub(crate) loaded_once: Cell<bool>,
    pub(crate) load_ongoing: Cell<bool>,
    handle: Cell<*mut c_void>,
}

pub type NativeUnitRef = VectorlikeRef<NativeUnitState>;

const _: () = {
    assert!(size_of::<NativeUnitState>() == 80);
    assert!(std::mem::offset_of!(NativeUnitState, fields) == 0);
    assert!(std::mem::offset_of!(NativeUnitState, impure_relocations) == 56);
    assert!(std::mem::offset_of!(NativeUnitState, loaded_once) == 64);
    assert!(std::mem::offset_of!(NativeUnitState, load_ongoing) == 65);
    assert!(std::mem::offset_of!(NativeUnitState, handle) == 72);
};

impl Vectorlike for NativeUnitState {
    const TAG: VectorTag = VectorTag::NativeCompUnit;
    const LISP_SLOTS: usize = 7;
}

impl NativeUnitRef {
    pub(crate) fn new() -> Self {
        crate::lisp::native_comp::note_lisp_allocation(88);
        Self::allocate(NativeUnitState {
            fields: [const { Cell::new(Value::Nil) }; 7],
            impure_relocations: Cell::new(std::ptr::null_mut()),
            loaded_once: Cell::new(false),
            load_ongoing: Cell::new(false),
            handle: Cell::new(std::ptr::null_mut()),
        })
    }
}

impl NativeUnitState {
    pub(crate) fn field(&self, index: usize) -> Value {
        self.fields[index].get()
    }
    pub(crate) fn set_field(&self, index: usize, value: Value) {
        self.fields[index].set(value);
    }
    pub(crate) fn fields(&self) -> [Value; 7] {
        std::array::from_fn(|index| self.field(index))
    }
    pub(crate) fn set_fields(&self, fields: [Value; 7]) {
        for (slot, value) in self.fields.iter().zip(fields) {
            slot.set(value);
        }
    }
    pub(crate) fn is_loaded(&self) -> bool {
        !self.handle.get().is_null()
    }
    pub(crate) fn install_library(&self, library: Library, impure_relocations: *mut usize) {
        assert!(!self.is_loaded(), "one owned dlopen handle per native unit");
        self.impure_relocations.set(impure_relocations);
        self.handle.set(libloading::os::unix::Library::from(library).into_raw());
    }
    /// A non-owning libloading view. The rooted unit, not this temporary
    /// wrapper, owns the dlopen reference. No callback can change its handle.
    pub(crate) fn library(&self) -> Option<ManuallyDrop<Library>> {
        let handle = self.handle.get();
        if handle.is_null() {
            None
        } else {
            // SAFETY: install_library consumed a live dlopen reference; the
            // collector closes it only after this unit is unreachable. The
            // ManuallyDrop view must never close the unit's reference.
            Some(ManuallyDrop::new(unsafe {
                libloading::os::unix::Library::from_raw(handle).into()
            }))
        }
    }
    pub(crate) fn impure_relocations(&self) -> *mut usize {
        self.impure_relocations.get()
    }
    pub(crate) fn impure_relocation_count(&self) -> usize {
        match self.field(6).kind() {
            crate::lisp::types::Kind::Vector(vector) => vector.len(),
            _ => 0,
        }
    }
}

impl Drop for NativeUnitState {
    fn drop(&mut self) {
        let handle = self.handle.replace(std::ptr::null_mut());
        if handle.is_null() {
            return;
        }
        // comp.c:unload_comp_unit. Drop receives exclusive access only after
        // tracing proves no live function, loader frame or Lisp root owns it.
        // A failed load may never have exported comp_unit; skip that lookup.
        unsafe {
            let library = libloading::os::unix::Library::from_raw(handle);
            if let Ok(saved) = library.get::<*mut usize>(b"comp_unit\\0") {
                let header = (std::ptr::from_mut(self) as *mut u8)
                    .sub(size_of::<VectorHeader>()).cast::<VectorHeader>();
                let word = Value::NativeCompUnit(NativeUnitRef::from_raw(header)).word();
                if !saved.is_null() && std::ptr::read(*saved) == word {
                    std::ptr::write(*saved, Value::Nil.word());
                }
            }
            drop(library);
        }
    }
}
''')
edit('src/lisp/alloc/vectors.rs','pub use native_functions::NativeFunctionRef;','pub use native_functions::NativeFunctionRef;\npub(crate) mod native_units;\npub use native_units::NativeUnitRef;')
edit('src/lisp/alloc/vectors.rs','    Subr = 18,','    Subr = 18,\n    NativeCompUnit = 26,')
edit('src/lisp/alloc/vectors.rs','            18 => Self::Subr,','            18 => Self::Subr,\n            26 => Self::NativeCompUnit,')
edit('src/lisp/alloc/vectors.rs','            | VectorTag::Subr => {','            | VectorTag::Subr\n            | VectorTag::NativeCompUnit => {')
edit('src/lisp/alloc/vectors.rs','            VectorTag::Free => {}','            VectorTag::NativeCompUnit => {\n                std::ptr::drop_in_place(body.cast::<native_units::NativeUnitState>())\n            }\n            VectorTag::Free => {}')
edit('src/lisp/alloc/vectors.rs','            VectorTag::Subr => Value::NativeFunction(NativeFunctionRef::from_raw(header)),','            VectorTag::Subr => Value::NativeFunction(NativeFunctionRef::from_raw(header)),\n            VectorTag::NativeCompUnit => Value::NativeCompUnit(NativeUnitRef::from_raw(header)),')
edit('src/lisp/types.rs','pub use crate::lisp::alloc::vectors::NativeFunctionRef;','pub use crate::lisp::alloc::vectors::{NativeFunctionRef, NativeUnitRef};')
edit('src/lisp/types.rs','    NativeFunction(NativeFunctionRef),','    NativeFunction(NativeFunctionRef),\n    /// The authoritative GNU native compilation unit and owned library handle.\n    NativeCompUnit(NativeUnitRef),')
edit('src/lisp/types.rs','    pub fn NativeFunction(function: NativeFunctionRef) -> Value {','    pub fn NativeCompUnit(unit: NativeUnitRef) -> Value {\n        Value::from_bits(unit.identity() | TAG_VECTORLIKE)\n    }\n    #[inline]\n    pub fn NativeFunction(function: NativeFunctionRef) -> Value {')
edit('src/lisp/types.rs','                        crate::lisp::alloc::VectorTag::Subr => {','                        crate::lisp::alloc::VectorTag::NativeCompUnit => {\n                            Kind::NativeCompUnit(NativeUnitRef::from_raw(header))\n                        }\n                        crate::lisp::alloc::VectorTag::Subr => {')
edit('src/lisp/types.rs','            Kind::NativeFunction(v) => Value::NativeFunction(v),','            Kind::NativeFunction(v) => Value::NativeFunction(v),\n            Kind::NativeCompUnit(v) => Value::NativeCompUnit(v),')
edit('src/lisp/types.rs','            Kind::NativeFunction(function) => format!("native-function<{}>", function.name()),','            Kind::NativeFunction(function) => format!("native-function<{}>", function.name()),\n            Kind::NativeCompUnit(_) => "native-comp-unit".into(),')
edit('src/lisp/types.rs','        (Kind::NativeFunction(a), Kind::NativeFunction(b)) => a.ptr_eq(&b),','        (Kind::NativeFunction(a), Kind::NativeFunction(b)) => a.ptr_eq(&b),\n        (Kind::NativeCompUnit(a), Kind::NativeCompUnit(b)) => a.ptr_eq(&b),')
edit('src/lisp/types.rs','        Kind::NativeFunction(function) => write!(f, "#<subr {}>", function.name()),','        Kind::NativeFunction(function) => write!(f, "#<subr {}>", function.name()),\n        Kind::NativeCompUnit(unit) => write!(f, "#<native-comp-unit {}>", unit.field(0)),')
edit('src/lisp/eval.rs','    NativeCompUnit,\n','')
edit('src/lisp/eval.rs','            Self::NativeCompUnit => 11,\n','')
edit('src/lisp/eval.rs','            Kind::NativeFunction(value) => value.mark_bit().is_marked(self.epoch),','            Kind::NativeFunction(value) => value.mark_bit().is_marked(self.epoch),\n            Kind::NativeCompUnit(value) => value.mark_bit().is_marked(self.epoch),')
edit('src/lisp/eval.rs','            Kind::NativeFunction(value) => value.mark_bit().mark(self.epoch),','            Kind::NativeFunction(value) => value.mark_bit().mark(self.epoch),\n            Kind::NativeCompUnit(value) => value.mark_bit().mark(self.epoch),')
edit('src/lisp/eval.rs','            Kind::NativeFunction(function) => {\n                for field in function.fields() {','            Kind::NativeCompUnit(unit) => {\n                for field in unit.fields() {\n                    self.enqueue(&field);\n                }\n            }\n            Kind::NativeFunction(function) => {\n                for field in function.fields() {')
edit('src/lisp/eval.rs','            Kind::NativeFunction(function) => {\n                let key = function.identity();','''            Kind::NativeCompUnit(unit) => {
                assert!(!unit.is_loaded(), "cannot clone live native relocation pointers");
                let key = unit.identity();
                if let Some(copied) = self.vectors.get(&key) {
                    return *copied;
                }
                let copy = crate::lisp::types::NativeUnitRef::new();
                let copied = Value::NativeCompUnit(copy);
                self.vectors.insert(key, copied);
                copy.set_fields(unit.fields().map(|field| self.copy(&field)));
                copied
            }
            Kind::NativeFunction(function) => {
                let key = function.identity();''')
edit('src/lisp/alloc.rs','        Kind::NativeFunction(function) => Some(function.mark_bit().is_marked(epoch)),','        Kind::NativeFunction(function) => Some(function.mark_bit().is_marked(epoch)),\n        Kind::NativeCompUnit(unit) => Some(unit.mark_bit().is_marked(epoch)),')
edit('src/lisp/native_comp/runtime.rs','                        | crate::lisp::alloc::VectorTag::Subr','                        | crate::lisp::alloc::VectorTag::Subr\n                        | crate::lisp::alloc::VectorTag::NativeCompUnit')
for name in ['src/lisp/primitives/values.rs','src/lisp/primitives/buffers.rs']:
 f=c/name;s=f.read_text();s='\n'.join(line for line in s.split('\n') if 'RecordKind::NativeCompUnit' not in line);f.write_text(s)
edit('src/lisp/primitives/values.rs','        (Kind::NativeFunction(a), Kind::NativeFunction(b)) => a.ptr_eq(&b),','        (Kind::NativeFunction(a), Kind::NativeFunction(b)) => a.ptr_eq(&b),\n        (Kind::NativeCompUnit(a), Kind::NativeCompUnit(b)) => a.ptr_eq(&b),',3)
# Identity-only native units have no structural equality or hash recursion.
edit('src/lisp/primitives/values.rs','        Kind::NativeFunction(function) => {\n            hash_mix(state, 53);','        Kind::NativeCompUnit(unit) => {\n            hash_mix(state, 54);\n            hash_mix(state, unit.identity() as u64);\n        }\n        Kind::NativeFunction(function) => {\n            hash_mix(state, 53);')
print('installed actual native-unit storage and core tags')
