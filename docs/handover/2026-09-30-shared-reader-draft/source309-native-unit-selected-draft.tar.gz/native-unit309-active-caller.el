;; -*- coding: utf-8; lexical-binding: t; -*-
(defun runtime-unit-active-caller (input)
  "Call a function from another compilation unit by its current binding."
  (funcall (intern (concat "runtime-unit-active-" "worker")) input))
