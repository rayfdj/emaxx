;; -*- coding: utf-8; lexical-binding: t; -*-
(require 'bytecomp)
(defvar runtime-unit-active-weak (make-hash-table :test 'eq :weakness 'key))
(defvar runtime-unit-active-results nil)
(defun runtime-unit-active-load ()
  (load (getenv "RUNTIME_UNIT_ACTIVE_WORKER") nil t)
  (unless (native-comp-function-p
           (symbol-function 'runtime-unit-active-worker))
    (error "Native worker required"))
  (puthash (subr-native-comp-unit
            (symbol-function 'runtime-unit-active-worker))
           t runtime-unit-active-weak))
(defalias 'runtime-unit-active-bytecode
  (byte-compile
   '(lambda (input)
      (funcall (intern (concat "runtime-unit-active-" "worker")) input))))
(load (getenv "RUNTIME_UNIT_ACTIVE_CALLER") nil t)
(unless (and (native-comp-function-p
              (symbol-function 'runtime-unit-active-caller))
             (byte-code-function-p
              (symbol-function 'runtime-unit-active-bytecode)))
  (error "Native and bytecode callers required"))
(dolist (mode '(interpreted bytecode native))
  (dolist (input '(31 79 113))
    (runtime-unit-active-load)
    (let ((answer
           (cond
            ((eq mode 'interpreted) (runtime-unit-active-worker input))
            ((eq mode 'bytecode) (runtime-unit-active-bytecode input))
            (t (runtime-unit-active-caller input)))))
      (push (list mode input answer
                  (fboundp 'runtime-unit-active-worker))
            runtime-unit-active-results))
    (dotimes (_ 6) (garbage-collect))
    (push (hash-table-count runtime-unit-active-weak)
          runtime-unit-active-results)))
(prin1 (nreverse runtime-unit-active-results))
