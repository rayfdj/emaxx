from pathlib import Path
p=Path(__file__).parent.resolve();c=p.parent/'recovered-2026-10-06/native-unit-objects/emaxx'
def edit(name,old,new,count=1):
 f=c/name;s=f.read_text();assert s.count(old)==count,(name,old[:100],s.count(old));f.write_text(s.replace(old,new))
f=c/'src/lisp/primitives/dispatch/comp.rs';s=f.read_text();a=s.index('    let candidate_unit = interp.create_pseudovector(');b=s.index('    let loaded_units =',a)
s=s[:a]+'''    let candidate = crate::lisp::types::NativeUnitRef::new();
    let candidate_unit = Value::NativeCompUnit(candidate);
    interp.with_lisp_stack_roots(&candidate_unit, |interp| {
'''+s[b:]
a=s.index('    let Kind::Record(candidate_id) = candidate_unit.kind()');b=s.index('\n}\n\ndefine_dispatch!',a)
s=s[:a]+'''    candidate.set_field(0, *filename);
    let lambda_guard = crate::lisp::json::make_hash_table(interp, "eq", Vec::new());
    candidate.set_field(2, lambda_guard);
    let lambda_name_index = crate::lisp::json::make_hash_table(interp, "equal", Vec::new());
    candidate.set_field(3, lambda_name_index);
    crate::lisp::native_comp::load(interp, env, filename, library, &candidate_unit, late)
    })'''+s[b:]
f.write_text(s)
f=c/'src/lisp/primitives/dispatch/buffer_meta.rs';s=f.read_text();a=s.index('                let Kind::Record(id)',s.index('            "native-comp-unit-file"'));b=s.index('            "decode-char"',a)
s=s[:a]+'''                let Kind::NativeCompUnit(unit) = args[0].kind() else {
                    return Err(LispError::TypeError("native-comp-unit".into(), args[0].type_name()));
                };
                Ok(unit.field(0))
            }
            "native-comp-unit-set-file" => {
                need_args(name, args, 2)?;
                let Kind::NativeCompUnit(unit) = args[0].kind() else {
                    return Err(LispError::TypeError("native-comp-unit".into(), args[0].type_name()));
                };
                unit.set_field(0, args[1]);
                Ok(args[0])
            }
'''+s[b:];f.write_text(s)
edit('src/lisp/primitives/buffers.rs','        Kind::NativeFunction(_) => "native-comp-function",','        Kind::NativeFunction(_) => "native-comp-function",\n        Kind::NativeCompUnit(_) => "native-comp-unit",')
edit('src/lisp/primitives/print.rs','        Kind::HashTable(_) => render_hash_table_prin1(interp, value, env, context, depth),','''        Kind::NativeCompUnit(unit) => {
            let fields = [
                render_prin1_with_context(interp, &unit.field(0), env, context, depth + 1)?,
                render_prin1_with_context(interp, &unit.field(1), env, context, depth + 1)?,
            ];
            Ok(PrintOutput::join(&fields, " ").enclosed("#<native compilation unit: ", ">"))
        }
        Kind::HashTable(_) => render_hash_table_prin1(interp, value, env, context, depth),''')
f=c/'src/lisp/primitives/pdumper/context.rs';s=f.read_text().replace('    NativeFunction(usize),','    NativeFunction(usize),\n    NativeCompUnit(usize),').replace('pub(crate) const NATIVE_SUBR_CODE: u32 = 15;','pub(crate) const NATIVE_SUBR_CODE: u32 = 15;\npub(crate) const NATIVE_UNIT_CODE: u32 = 14;').replace('        RecordKind::NativeCompUnit => 14,\n','').replace('        14 => RecordKind::NativeCompUnit,\n','')
s=s.replace('        Kind::NativeFunction(function) => ObjectKey::NativeFunction(function.identity()),','        Kind::NativeFunction(function) => ObjectKey::NativeFunction(function.identity()),\n        Kind::NativeCompUnit(unit) => ObjectKey::NativeCompUnit(unit.identity()),')
s=s.replace('            Kind::NativeFunction(_) => DumpType::Record,','            Kind::NativeFunction(_) | Kind::NativeCompUnit(_) => DumpType::Record,')
s=s.replace('            Kind::NativeFunction(function) => {','''            Kind::NativeCompUnit(unit) => {
                let offset = self.dump_native_comp_unit(unit)?;
                (offset, DumpType::Record)
            }
            Kind::NativeFunction(function) => {''')
s=s.replace('''            RecordKind::NativeCompUnit => {
                let offset = self.dump_native_comp_unit(id, &type_tag, &slots)?;
                Ok((offset, DumpType::Record))
            }
''','')
a=s.index('    fn dump_native_comp_unit(');b=s.index('    /// dump_subr for a native function',a)
s=s[:a]+'''    fn dump_native_comp_unit(
        &mut self,
        unit: crate::lisp::types::NativeUnitRef,
    ) -> Result<u32, DumpError> {
        if !matches!(unit.field(0).kind(), Kind::Cons(_)) {
            return Err(DumpError::Lisp(LispError::Signal(
                "trying to dump non fixed-up eln file".into(),
            )));
        }
        let mut slots = unit.fields();
        slots[4] = Value::Nil;
        // Legacy codec 14 carries seven Lisp fields. No runtime record/id
        // is reconstructed; object offsets retain sharing and cycles.
        let start = self.object_start()?;
        let mut words = vec![0, u64::from(NATIVE_UNIT_CODE), 0, slots.len() as u64];
        words.resize(slots.len() + 4, WORD_NIL);
        self.field_lv(start, &mut words, 2, &Value::symbol("native-comp-unit"), WEIGHT_STRONG);
        for (index, field) in slots.iter().enumerate() {
            self.field_lv(start, &mut words, index + 4, field, WEIGHT_STRONG);
        }
        let offset = self.object_finish(&words)?;
        if self.flags.dump_object_contents {
            self.dump_relocs[LATE_RELOCS].push((offset, DumpRelocKind::NativeCompUnit));
        }
        Ok(offset)
    }

'''+s[b:];f.write_text(s)
f=c/'src/lisp/primitives/pdumper/load.rs';s=f.read_text().replace('pub(crate) native_units: Vec<u64>,','pub(crate) native_units: Vec<crate::lisp::types::NativeUnitRef>,')
a=s.index('                    let record_kind = record_kind_from_code(kind_code)');s=s[:a]+'''                    if kind_code == super::context::NATIVE_UNIT_CODE {
                        if nslots != 7 || self.relocs.get(&offset) != Some(&DumpRelocKind::NativeCompUnit) {
                            return Err(LoadError::Error("invalid native compilation unit image record".into()));
                        }
                        let unit = crate::lisp::types::NativeUnitRef::new();
                        self.objects.insert(offset, Value::NativeCompUnit(unit));
                        native_units.push(unit);
                        continue;
                    }
'''+s[a:]
a=s.index('                    // The native kinds carry their late relocations;');b=s.index('\n                }\n                DumpType::CharTable',a);s=s[:a]+s[b:]
s=s.replace('''                        function.set_fields([slots[6], slots[7], slots[8], slots[9], slots[4]]);
                    } else {''','''                        function.set_fields([slots[6], slots[7], slots[8], slots[9], slots[4]]);
                    } else if let Kind::NativeCompUnit(unit) = self.objects[&offset].kind() {
                        unit.set_fields(slots.try_into().map_err(|_| LoadError::Error("invalid unit field count".into()))?);
                    } else {''')
f.write_text(s)
# Native relocation arrays are owned/reached through the actual unit, never
# permanent roots. Existing loader-root tests use the scoped range API.
f=c/'src/lisp/native_comp/runtime.rs';s=f.read_text().replace('    permanent_root_ranges: Vec<NativeRootRange>,','    linked_code: bool,').replace('                permanent_root_ranges: Vec::new(),','                linked_code: false,').replace('            && self.permanent_root_ranges.is_empty()','            && !self.linked_code')
s=s.replace('''        for range in self
            .permanent_root_ranges
            .iter()
            .chain(&self.ephemeral_root_ranges)
        {''','        for range in &self.ephemeral_root_ranges {')
a=s.index('    pub(crate) fn register_permanent_root_range');b=s.index('    pub(crate) fn push_ephemeral_root_range',a);s=s[:a]+s[b:]
s=s.replace('register_permanent_root_range(', 'push_ephemeral_root_range(')
s=s.replace('''    pub(crate) fn current_thread_relocation(&mut self) -> *mut c_void {
        (&mut *self.thread_pointer''','''    pub(crate) fn current_thread_relocation(&mut self) -> *mut c_void {
        // Rust image templates cannot duplicate live machine-code pointers
        // into this stable runtime cell. This is a host clone constraint,
        // not an object registry or a GC root.
        self.linked_code = true;
        (&mut *self.thread_pointer''')
s=s.replace('''        // comp.c keeps loaded units' relocation objects alive between
        // generated calls too. Use the same mark/sweep path in both states:
        // the absence of a native stack removes only that stack's roots,
        // not relocation roots or the bridge edges needed to reach them.''','''        // Persistent native data is reached through each live unit's seven
        // Lisp fields, as in comp.c. Only active ephemeral load ranges and
        // active/suspended execution stacks are additional native roots.''')
f.write_text(s)
f=c/'src/lisp/native_comp/loader.rs';s=f.read_text().replace('register_permanent_root_range(', 'push_ephemeral_root_range(').replace('        let mut registry = NativeRegistry::default();\n','').replace('with_native_state(&compiler, &mut registry, &mut runtime,', 'with_native_state(&compiler, &mut runtime,').replace('                    &mut registry,\n','').replace('                &mut registry,\n','')
s=s.replace('''            assert!(
                registry.is_empty(),
                "calls must not reconstruct a function registry"
            );
''','')
a=s.index('        // The function-name maps have gone.');b=s.index('\n    }\n}\n\nfn inconsistent',a)
s=s[:a]+'''        let before = NativeUnitRef::new();
        before.set_field(0, Value::string("before-suspension"));
        before.install_library(libloading::os::unix::Library::this().into(), std::ptr::null_mut());
        let suspended = NativeUnitRef::new();
        suspended.set_field(0, Value::string("during-suspension"));
        suspended.install_library(libloading::os::unix::Library::this().into(), std::ptr::null_mut());
        let owners = [Value::NativeCompUnit(before), Value::NativeCompUnit(suspended)];
        interpreter.with_lisp_stack_roots(&owners, |interpreter| {
            with_native_state(&compiler, &mut runtime, |_runtime| {
                let runtime_pointer = ACTIVE_REGISTERED_RUNTIME.get();
                let compiler_pointer = ACTIVE_COMPILER.get();
                let panic = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                    super::super::runtime::with_thread_suspended(interpreter, |interpreter| {
                        assert!(ACTIVE_REGISTERED_RUNTIME.get().is_null());
                        assert!(ACTIVE_COMPILER.get().is_null());
                        assert!(Rc::ptr_eq(&interpreter.native_compiler.compiler, &compiler));
                        super::super::begin_garbage_collection(interpreter, &Env::new());
                        assert!(before.is_loaded());
                        assert!(suspended.is_loaded());
                        suspended.set_field(1, Value::Integer(29));
                        panic!("loader-suspension-test");
                    })
                })).expect_err("the Rust panic must propagate after owner restoration");
                assert_eq!(panic.downcast_ref::<&str>(), Some(&"loader-suspension-test"));
                assert_eq!(ACTIVE_REGISTERED_RUNTIME.get(), runtime_pointer);
                assert_eq!(ACTIVE_COMPILER.get(), compiler_pointer);
            });
            assert_eq!(before.field(0).as_string().expect("unit file"), "before-suspension");
            assert_eq!(suspended.field(0).as_string().expect("unit file"), "during-suspension");
            assert_eq!(suspended.field(1), Value::Integer(29));
            assert!(before.is_loaded() && suspended.is_loaded());
        });
        assert!(runtime.is_pristine());
        assert!(ACTIVE_REGISTERED_RUNTIME.get().is_null());
        assert!(ACTIVE_COMPILER.get().is_null());'''+s[b:]
s=s.replace('''    let mut data = unsafe {''','''    unit.set_field(1, optimization_qualities);
    let mut data = unsafe {''',1).replace('''    let impure_data = unsafe {''','''    unit.set_field(5, data);
    let impure_data = unsafe {''',1)
s=s.replace('''    if interpreter
        .lookup_var("purify-flag", environment)''','''    unit.set_field(6, impure_data);
    if interpreter
        .lookup_var("purify-flag", environment)''',1)
f.write_text(s)
print('migrated unit consumers, dump codec and GC ownership')
