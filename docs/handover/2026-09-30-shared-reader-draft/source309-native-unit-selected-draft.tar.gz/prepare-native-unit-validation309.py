from pathlib import Path
import ast,hashlib,json
p=Path(__file__).parent.resolve();c=p.parent/'recovered-2026-10-06/native-unit-objects/emaxx';base=json.loads((p/'source308-manifest.json').read_text());sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
new={'src/lisp/alloc/vectors/native_units.rs','tests/fixtures/native-unit-authority.el','tests/fixtures/native-unit-lifecycle-worker.el','tests/fixtures/native-unit-lifecycle-driver.el','tests/fixtures/native-unit-lifecycle.expected'}
names=sorted(set(base)|new);m={n:sha(c/n) for n in names};assert len(m)==546
changes=[n for n,h in m.items() if base.get(n)!=h]
assert not any('RecordKind::NativeCompUnit' in (c/n).read_text() or 'struct NativeRegistry' in (c/n).read_text() or 'struct LoadedUnit' in (c/n).read_text() for n in m if n.endswith('.rs'))
assert all(m[n]==h for n,h in base.items() if n.startswith('tests/'))
assert json.loads((p/'source309-development5-clippy-result.json').read_text())['exit_code']==0
s=(p/'run-source308-validation.py').read_text().replace('source308','source309').replace('native-subr-callbacks/emaxx','native-unit-objects/emaxx')
a=s.index("base = read(p / ");b=s.index("with (p / 'source309-manifest.json')",a)
s=s[:a]+f'''base = read(p / 'source308-manifest.json')
names = sorted(set(base) | {sorted(new)!r})
manifest = {{n: sha(c / n) for n in names}}
assert len(manifest) == 546 and (c.parent / 'emacs').resolve() == g.resolve()
assert all(manifest[n] == h for n, h in base.items() if n.startswith('tests/'))
changes = [n for n, h in manifest.items() if base.get(n) != h]
assert changes == {changes!r}, changes
assert (c / 'src/anti_cheat.rs').read_bytes() == (p.parents[2] / 'src/anti_cheat.rs').read_bytes()
assert not any('RecordKind::NativeCompUnit' in (c / n).read_text() for n in names if n.endswith('.rs'))
with (p / 'source309-modes.json').open('x') as stream:
    json.dump({{n: (c / n).stat().st_mode & 0o777 for n in names}}, stream, indent=2)
''' +s[b:]
s=s.replace('recovered-2026-10-06/native-subr-names/emaxx/target/vm-dispatch-validation','recovered-2026-10-06/native-unit-objects/emaxx/target/unit-development')
s=s.replace("sha(p / ('source304-' + profile + '-libtest'))", "sha(p / ('source308-' + profile + '-libtest'))")
s=s.replace("('source304-' + profile + '-inventory.log')", "('source308-' + profile + '-inventory.log')")
a=s.index('        new_tests = {');b=s.index('        assert set(inventory)',a)
s=s[:a]+'''        new_tests = {
            'lisp::alloc::vectors::tests::native_unit_allocation_has_actual_gnu_fields_and_direct_tagged_identity',
            'lisp::alloc::vectors::tests::native_unit_traces_seven_fields_from_a_subr_and_collects_the_unreachable_cycle',
            'lisp::native_comp::loader::tests::native_unit_relocations_decode_the_actual_allocation_without_a_registry',
            'lisp::primitives::tests::native_unit_fields_preserve_gnu_printing_identity_properties_and_errors',
        }
'''+s[b:]
s=s.replace("read(p / 'source304-validation-result.json')", "read(p / 'source308-validation-result.json')")
# All predecessor controls plus the new unit controls, no selector removed.
ast.parse(s);(p/'run-source309-validation.py').open('x').write(s)
record=dict(status='ready for frozen formal native-unit validation',candidate=str(c),source_inputs=len(m),changes=changes,development_controls=dict(passed=13,failed=0,ignored=0),latest_development_clippy='passed; initial new-test unwrap lint remains recorded',root_commit='6ad703c4ae85b4c3d0be6351a2df9f3bd47489ef',goal_complete=False,qualification='The13-pass development4 fixture precedes the final new invalid-argument cases, their exact GNU error-data repair, test expect lint repair and removal of redundant field stores. Formal fresh validation is required on the final inputs. All previous external fixtures and test names remain. Registry-specific test setup now exercises real GC unit ownership across suspension; the removed registry.is_empty assertion names a deleted type and has no runtime representation left to inspect. Existing semantic assertions remain. The failed compiler/lint attempts and both observed baseline retention/printing differences are retained.')
(p/'source309-formal-validation-preflight.json').open('x').write(json.dumps(record,indent=2))
print(json.dumps(dict(source_inputs=len(m),changed=len(changes),candidate=str(c))))
