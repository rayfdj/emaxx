from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).parent.resolve();root=p.parents[2]
base='0c58c4d43bd52f1ac455abd2a8e845c8523dda6c'
selected=p.parent/'recovered-2026-09-30/string-storage/emaxx'
candidate=p.parent/'recovered-2026-09-30/string-borrow-roots/emaxx'
gnu=p.parent/'rebuilt-2026-10-01/emacs'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
read=lambda n:json.loads((p/n).read_text())
manifest=read('source270-manifest.json')
assert len(manifest)==510 and all(sha(root/n)==sha(selected/n)==h for n,h in manifest.items())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==base
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
state=read('source270-validation-result.json');assert len(state['results'])==8 and all(r['exit_code']==0 for r in state['results'])
assert not candidate.exists()
candidate.parent.mkdir(parents=True,exist_ok=True)
result=subprocess.run(['git','worktree','add','--detach',str(candidate),base],cwd=root,capture_output=True,text=True)
with (p/'string-borrow-probe-checkout-command.json').open('x') as f:json.dump(dict(exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr),f,indent=2)
result.check_returncode()
(candidate.parent/'emacs').symlink_to(gnu,target_is_directory=True)
assert all(sha(candidate/n)==h for n,h in manifest.items())
record=dict(candidate=str(candidate),base_commit=base,source_inputs_verified=510,qualification='Separate ownership/rooting investigation. No source270 selected/full input or helper is edited. Production source is initially byte-identical to validated source270; the next step adds a diagnostic regression control.')
with (p/'string-borrow-probe-checkout.json').open('x') as f:json.dump(record,f,indent=2)
target=candidate/'target/string-borrow-validation';target.parent.mkdir()
command=['/bin/cp','-cR',str(selected/'target/string-storage-validation'),str(target)]
started=time.monotonic()
with (p/'string-borrow-probe-cache-clone.log').open('xb') as log:
    result=subprocess.run(command,cwd=root,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
with (p/'string-borrow-probe-cache-clone.json').open('x') as f:json.dump(dict(command=command,exit_code=result.returncode,elapsed_seconds=time.monotonic()-started,qualification='Copies only the completed selected270 cache into a new APFS clone. Full270 has its own target and remains running.'),f,indent=2)
result.check_returncode();print(json.dumps(record,indent=2))
