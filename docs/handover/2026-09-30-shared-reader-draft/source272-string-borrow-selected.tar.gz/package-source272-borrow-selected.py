from pathlib import Path
import ast,gzip,hashlib,io,json,subprocess,tarfile
p=Path(__file__).parent.resolve();root=p.parents[2]
out=root/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda n:json.loads((p/n).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
audit=read('source272-borrow-selected-audit.json')
assert audit['status']=='passed' and audit['source_inputs_verified']==510
assert all(row['focused_passes']==206 and row['affected_passes']==1062 for row in audit['profiles'].values())
pid=str(read('source272-selected-launch.json')['pid'])
process=subprocess.run(['ps','-p',pid,'-o','command='],capture_output=True,text=True)
assert process.returncode==1 and not process.stdout.strip(), 'Do not package mutable running logs'
helpers={
    'prepare-string-borrow-probe.py','string-borrow-probe-checkout-command.json','string-borrow-probe-checkout.json',
    'string-borrow-probe-cache-clone.json','string-borrow-probe-cache-clone.log',
    'run-source271-borrow-probe.py','audit-source271-borrow-negative.py','prepare-source272-borrow-validation.py',
    'run-source272-borrow-repair.py','prepare-string-borrow-selected.py','string-borrow-selected-preparation.json',
    'run-string-borrow-focused.py','audit-string-borrow-focused.py','run-string-borrow-release.py','audit-string-borrow-release.py',
    'test-string-borrow-broad.py','queue-source272-borrow-selected.py','audit-source272-borrow-selected.py',
    'freeze-source272-borrow-patches.py','prepare-source272-full-validation.py','audit-source272-selected-for-full.py',
    'queue-source272-full-macos.py','setup-source272-full-macos.py','dispatch-source272-linux.py',
    'apply-source272-selected.py','commit-source272-selected.py',
    'source270-manifest.json','source270-gate-inventory.log','source270-release-inventory.log',
    'source270-gate-controls-command.json','source270-release-controls-command.json',
    'source270-gate-broad-command.json','source270-release-broad-command.json','source270-selected-audit.json',
    'audit-source270-selected.py','source270-string-borrow-review.json','source270-raw-report-adversarial-audit.json',
    'source249-gate-controls-command.json','source249-gate-broad-command.json','source249-release-broad-command.json',
    'source255-gate-controls-command.json','source255-gate-inventory.log',
    'source261-gate-broad-command.json','source261-release-broad-command.json','source263-gate-broad-command.json',
    'package-source196-failure-and197-results.py',Path(__file__).name,
}
allowed={'.json','.log','.txt','.py','.patch','.stdout','.stderr'}
files={}
for file in p.iterdir():
    if file.is_file() and file.suffix in allowed and (file.name.startswith(('source271-','source272-')) or file.name in helpers):
        files[file.name]=file
assert helpers<=files.keys(),sorted(helpers-files.keys())
package('source272-string-borrow-selected',files,dict(
    negative=read('source271-borrow-negative-audit.json'),selected=audit,reference=read('source272-c-and-ownership-review.json'),
    full_preparation=read('source272-full-validation-preparation.json'),
    qualification='Preserves the unmodified source271 test-only failure, raw logs/commands, all510 input manifests and exact incremental/complete replay patches. Source272 closes that property-root negative and adds weak-key retention/reclamation plus pre-mark exclusive-borrow rejection, with zero-warning strict checks and206 focused/1062 affected passes in each profile; two existing ignores remain. Every original selector, test and GNU fixture byte remains. Full source272 validation is prepared but has not launched. Source270 complete Rust results are separate. Sblocks, real intervals, symbol authority, physical accounting, broader public ownership, VM/profile work and the locked16-workload3% criterion remain incomplete.'))
