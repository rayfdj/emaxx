from pathlib import Path
import hashlib,json
p=Path(__file__).parent.resolve()
assert json.loads((p/'source271-borrow-negative-audit.json').read_text())['status']=='confirmed negative'
source=(p/'run-source271-borrow-probe.py').read_text()
source=source.replace('source271','source272')
source=source.replace("changed_file = 'src/lisp/native_comp/runtime.rs'", "changed_files = {'src/lisp/alloc.rs', 'src/lisp/alloc/strings.rs', 'src/lisp/eval.rs', 'src/lisp/native_comp/runtime.rs'}")
source=source.replace('n != changed_file','n not in changed_files')
source=source.replace("subprocess.check_output(['git', 'diff', '--name-only'], cwd=candidate, text=True).splitlines() == [changed_file]", "set(subprocess.check_output(['git', 'diff', '--name-only'], cwd=candidate, text=True).splitlines()) == changed_files")
source=source.replace('source272-test-only.patch','source272-repair.patch')
source=source.replace('== 3022','== 3024')
source=source.replace("        'borrowed_string_properties_survive_off_stack_guards_and_are_reclaimed_after_release',", "        'borrowed_string_properties_survive_off_stack_guards_and_are_reclaimed_after_release',\n        'off_stack_string_borrows_enter_the_weak_table_fixed_point',\n        'exclusive_string_borrows_reject_gc_before_marking_or_sweeping',")
source=source.replace("try:\n    build =", """try:
    for stage, command in [
        ('fmt', ['cargo', 'fmt', '--all', '--check']),
        ('check', ['cargo', 'check', '--locked', '--all-targets', '--all-features']),
        ('clippy', ['cargo', 'clippy', '--locked', '--all-targets', '--all-features', '--', '-D', 'warnings']),
        ('diff', ['git', 'diff', '--check']),
    ]:
        assert run(stage, command) == 0
        assert not any(line.startswith('warning:') for line in (p / ('source272-' + stage + '.log')).read_text().splitlines())
    build =""")
source=source.replace("len(state['results']) == 3", "len(state['results']) == 7")
assert 'changed_file)' not in source and '== 3022' not in source
helper=p/'run-source272-borrow-repair.py'
compile(source,str(helper),'exec')
with helper.open('x') as f:f.write(source)
with (p/'source272-validation-preparation.json').open('x') as f:
    json.dump(dict(helper=str(helper),helper_sha256=hashlib.sha256(helper.read_bytes()).hexdigest(),qualification='Successor to the preserved test-only source271 failure. Formats/freezes four changed sources, checks all targets/features with warnings denied, builds a 3024-name gate inventory and runs the unchanged negative plus weak-table, exclusive-borrow, cycle and pure controls. No result is yet claimed.'),f,indent=2)
print(helper)
