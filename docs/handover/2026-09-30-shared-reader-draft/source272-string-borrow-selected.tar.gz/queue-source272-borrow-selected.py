from pathlib import Path
import hashlib,json,os,subprocess,sys,time
p=Path(__file__).parent.resolve();root=p.parents[2]
candidate=p.parent/'recovered-2026-09-30/string-borrow-roots/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
read=lambda n:json.loads((p/n).read_text())
manifest=read('source272-manifest.json');baseline=read('source270-manifest.json')
unchanged=lambda:len(manifest)==510 and all(sha(candidate/n)==h for n,h in manifest.items())
baseline_unchanged=lambda:all(sha(root/n)==h for n,h in baseline.items())
stages=[
    ['run-string-borrow-focused.py','272'],
    ['audit-string-borrow-focused.py','272'],
    ['test-string-borrow-broad.py','272','gate'],
    ['run-string-borrow-release.py','272'],
    ['audit-string-borrow-release.py','272'],
    ['test-string-borrow-broad.py','272','release'],
]
helpers={str(p/s[0]):sha(p/s[0]) for s in stages}
state=dict(status='waiting for source272 diagnostic validation',source_manifest='source272-manifest.json',helpers=helpers,stages=stages,results=[],goal_complete=False)
def save_state():
    (p/'source272-selected-state.json').write_text(json.dumps(state,indent=2)+'\n')
try:
    save_state()
    while not (p/'source272-probe-result.json').exists():
        assert unchanged() and baseline_unchanged()
        time.sleep(10)
    probe=read('source272-probe-result.json')
    assert len(probe['results'])==7 and all(row['exit_code']==0 and row['source_unchanged'] for row in probe['results']), 'Diagnostic failed; selected validation is not launched'
    for name,*arguments in stages:
        assert unchanged() and baseline_unchanged()
        assert all(sha(Path(helper))==h for helper,h in helpers.items())
        command=[sys.executable,'-B',str(p/name),*arguments]
        state.update(status='running '+name,current_command=command);save_state()
        started=time.monotonic()
        result=subprocess.run(command,cwd=candidate,stdin=subprocess.DEVNULL,env=dict(os.environ,PYTHONUNBUFFERED='1',PYTHONDONTWRITEBYTECODE='1'))
        row=dict(command=command,exit_code=result.returncode,elapsed_seconds=time.monotonic()-started,source_unchanged=unchanged(),published_source_unchanged=baseline_unchanged())
        state['results'].append(row)
        if result.returncode or not row['source_unchanged'] or not row['published_source_unchanged']:break
    state['status']='selected processes finished; final raw audit required'
except Exception as error:
    state.update(status='failed',error=repr(error))
finally:
    save_state()
    with (p/'source272-selected-result.json').open('x') as f:json.dump(state,f,indent=2)
print(json.dumps(state),flush=True)
sys.exit(0 if len(state['results'])==len(stages) and all(row['exit_code']==0 for row in state['results']) else 1)
