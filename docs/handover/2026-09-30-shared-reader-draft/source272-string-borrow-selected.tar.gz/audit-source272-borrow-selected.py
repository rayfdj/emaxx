from pathlib import Path
import ast,hashlib,json,re
p=Path(__file__).parent.resolve();root=p.parents[2]
candidate=p.parent/'recovered-2026-09-30/string-borrow-roots/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
read=lambda n:json.loads((p/n).read_text())
state=read('source272-selected-result.json')
assert len(state['stages'])==len(state['results'])==6
assert all(row['exit_code']==0 and row['source_unchanged'] and row['published_source_unchanged'] for row in state['results'])
assert all(sha(Path(n))==h for n,h in state['helpers'].items())
manifest=read('source272-manifest.json');baseline=read('source270-manifest.json')
assert len(manifest)==510 and all(sha(candidate/n)==h for n,h in manifest.items())
assert all(sha(root/n)==h for n,h in baseline.items())
assert read('source271-borrow-negative-audit.json')['counts']==dict(passed=2,failed=1,ignored=0)
replay=read('source272-borrow-patch-replay-audit.json')
assert replay['status']=='exact' and len(replay['replays'])==3
assert all(sha(p/row['patch'])==row['sha256'] for row in replay['replays'])
node=next(n for n in ast.parse((p/'audit-source270-selected.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='audit_log')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<preserved-exact-raw-verdict-parser>','exec'))
added={'lisp::native_comp::runtime::tests::'+name for name in [
    'borrowed_string_properties_survive_off_stack_guards_and_are_reclaimed_after_release',
    'off_stack_string_borrows_enter_the_weak_table_fixed_point',
    'exclusive_string_borrows_reject_gc_before_marking_or_sweeping',
]}
ignored=['tty::tty_differential_end_to_end','tty::tty_smoke_end_to_end']
profiles={};inventories={}
for profile,count in [('gate',3024),('release',3023)]:
    inventory=lambda source:[line[:-6] for line in (p/(source+'-'+profile+'-inventory.log')).read_text().splitlines() if line.endswith(': test')]
    names=inventory('source272');prior_names=inventory('source270')
    assert len(names)==len(set(names))==count
    assert set(names)==set(prior_names)|added
    inventories[profile]=set(names)
    focused=read('source272-'+profile+'-controls-command.json')
    prior=read('source270-'+profile+'-controls-command.json')
    assert len(focused['selectors'])==208 and set(focused['selectors'])==set(prior['selectors'])|added
    assert focused['command'][1:]==focused['selectors']+['--exact','--test-threads=1','--nocapture']
    audit=read('source272-focused-audit.json' if profile=='gate' else 'source272-release-focused-audit.json')
    assert audit['status']=='passed' and audit['counts']==dict(ok=206,FAILED=0,ignored=2)
    for item in audit['retained_inputs']:
        assert sha(Path(item['original']))==sha(Path(item['artifact']))==item['sha256']
    command=read('source272-'+profile+'-broad-command.json')
    names_broad=command['selected_inventory']
    assert len(names_broad)==len(set(names_broad))==1062
    assert set(names_broad)==set(read('source270-'+profile+'-broad-command.json')['selected_inventory'])|added
    assert command['command'][1:]==names_broad+['--exact','--nocapture','--test-threads=1']
    assert sha(p/('source272-'+profile+'-libtest'))==command['binary_sha256']==focused['binary_sha256']
    for stage,selectors,ignores in [('controls',focused['selectors'],ignored),('broad',names_broad,[])]:
        result=read('source272-'+profile+'-'+stage+'-result.json')
        assert result['exit_code']==0 and result['source_unchanged']
        raw=(p/('source272-'+profile+'-'+stage+'.log')).read_text()
        audit_log(selectors,raw,ignores)
        summaries=re.findall(r'^test result: ok\. (\d+) passed; 0 failed; (\d+) ignored; 0 measured; (\d+) filtered out;',raw,re.M)
        assert len(summaries)==1 and tuple(map(int,summaries[0]))==(len(selectors)-len(ignores),len(ignores),count-len(selectors))
    profiles[profile]=dict(focused_passes=206,existing_ignores=ignored,affected_passes=1062,complete_inventory=count,binary_sha256=command['binary_sha256'])
assert inventories['gate']-inventories['release']=={'file_system::posix::tests::posix_file_drop_rejects_an_externally_closed_descriptor'}
assert not inventories['release']-inventories['gate']
probe=read('source272-probe-result.json')
assert len(probe['results'])==7 and all(r['exit_code']==0 and r['source_unchanged'] for r in probe['results'])
selectors=[n for n in read('source272-gate-probe-command.json')['command'][1:] if n.startswith('lisp::')]
assert len(selectors)==5
audit_log(selectors,(p/'source272-gate-probe.log').read_text(),[])
for stage in ['fmt','check','clippy','diff','gate-build','release-build']:
    row=read('source272-'+stage+'-result.json');assert row['exit_code']==0 and row['source_unchanged']
    raw=(p/('source272-'+stage+'.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:',raw,re.M)
    for line in raw.splitlines():
        if line.startswith('{'):assert json.loads(line).get('message',{}).get('level') not in ['error','warning']
record=dict(status='passed',source_inputs_verified=510,profiles=profiles,diagnostic_controls=5,
            added_tests=sorted(added),original_negative_preserved=True,original_tests_and_fixtures_preserved=True,
            patch_replay=replay,strict_checks='zero-warning pass',goal_complete=False,
            qualification='The unchanged source271 negative now passes: off-stack shared string guards retain the header and property graph; weak-key values survive only while borrowed and are reclaimed afterward. Exclusive guards reject collection before advancing its mark epoch or sweeping, including both empty singletons. Existing 205 focused selectors,1059 affected selectors and all fixture bytes are preserved in each profile. The three expected panic messages are caught contract checks, with final successful verdicts. Source270 full-platform results remain separate; no source272 full-platform, standalone GNU, timing, memory or complete public-ownership claim follows.')
with (p/'source272-borrow-selected-audit.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps({k:record[k] for k in ['status','source_inputs_verified','profiles','diagnostic_controls']},indent=2))
