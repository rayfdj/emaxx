from pathlib import Path
import hashlib,io,json,os,subprocess,tarfile,tempfile
p=Path(__file__).parent.resolve();root=p.parents[2]
candidate=p.parent/'recovered-2026-09-30/string-borrow-roots/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
read=lambda n:json.loads((p/n).read_text())
base='0c58c4d43bd52f1ac455abd2a8e845c8523dda6c'
main='21d20f0eec08f3c013d5d3eb3bd6e9cfc16b3199'
before=read('source270-manifest.json');manifest=read('source272-manifest.json')
assert len(manifest)==510 and all(sha(candidate/n)==h for n,h in manifest.items())
assert all(sha(root/n)==h for n,h in before.items())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=candidate,text=True).strip()==base
changed=[n for n in manifest if before[n]!=manifest[n]]
assert set(changed)=={'src/lisp/alloc.rs','src/lisp/alloc/strings.rs','src/lisp/eval.rs','src/lisp/native_comp/runtime.rs'}
runtime='src/lisp/native_comp/runtime.rs'
text=(candidate/runtime).read_text()
start=text.index('    #[test]\n    fn borrowed_string_properties_survive_off_stack_guards_and_are_reclaimed_after_release()')
end=text.index('    #[test]\n    fn pure_string_headers_survive_unrooted_gc_outside_the_ordinary_census()',start)
assert text[:start]+text[end:]==(root/runtime).read_text(), 'Every original runtime line and test remains unchanged'
patches={}
for label,commit in [('portable-incremental',base),('portable-complete',main)]:
    data=subprocess.check_output(['git','diff','--binary',commit,'--',*sorted(manifest)],cwd=candidate)
    file=p/('source272-'+label+'.patch')
    with file.open('xb') as f:f.write(data)
    patches[label]=dict(base=commit,sha256=sha(file),bytes=len(data))
assert (p/'source272-portable-incremental.patch').read_bytes()==(p/'source272-repair.patch').read_bytes()
records=[]
replays=[('source271-test-only.patch',base,read('source271-manifest.json'))]
replays += [('source272-'+label+'.patch',row['base'],manifest) for label,row in patches.items()]
for patch,commit,inputs in replays:
    tracked=set(subprocess.check_output(['git','ls-tree','-r','--name-only',commit],cwd=root,text=True).splitlines())
    archive=subprocess.check_output(['git','archive',commit,'--',*sorted(tracked & inputs.keys())],cwd=root)
    with tempfile.TemporaryDirectory(prefix='emaxx-borrow-replay-',dir='/private/tmp') as temporary:
        directory=Path(temporary)
        with tarfile.open(fileobj=io.BytesIO(archive)) as source:
            for member in source:
                assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
                destination=directory/member.name
                if member.isdir():destination.mkdir(parents=True,exist_ok=True)
                else:
                    assert member.isfile()
                    destination.parent.mkdir(parents=True,exist_ok=True)
                    destination.write_bytes(source.extractfile(member).read())
                    os.chmod(destination,0o755 if member.mode & 0o111 else 0o644)
        subprocess.run(['git','apply','--check',str(p/patch)],cwd=directory,check=True)
        subprocess.run(['git','apply',str(p/patch)],cwd=directory,check=True)
        assert all(sha(directory/n)==h for n,h in inputs.items())
        assert all((directory/n).stat().st_mode & 0o777==(candidate/n).stat().st_mode & 0o777 for n in inputs)
    records.append(dict(patch=patch,base=commit,inputs=len(inputs),sha256=sha(p/patch),bytes_and_modes='exact'))
with (p/'source272-freeze.json').open('x') as f:json.dump(dict(source='source272',inputs=510,changed_files=changed,patches=patches),f,indent=2)
with (p/'source272-borrow-patch-replay-audit.json').open('x') as f:
    json.dump(dict(status='exact',replays=records,original_runtime_tests='byte-identical',
                   qualification='The test-only failing source271 and both source272 repair patches reproduce all510 inputs and modes. All original tests/fixtures/expected outputs remain unchanged. Selected runtime validation is separate; public ownership, sblocks/intervals, accounting, VM and performance requirements remain open.'),f,indent=2)
print(json.dumps(records,indent=2))
