from pathlib import Path
import hashlib,json
p=Path(__file__).parent.resolve()
extra="""    'borrowed_string_properties_survive_off_stack_guards_and_are_reclaimed_after_release',
    'off_stack_string_borrows_enter_the_weak_table_fixed_point',
    'exclusive_string_borrows_reject_gc_before_marking_or_sweeping',
"""
rows=[]
for old,new in [
    ('run-string-storage-focused.py','run-string-borrow-focused.py'),
    ('run-string-storage-release.py','run-string-borrow-release.py'),
    ('audit-string-storage-focused.py','audit-string-borrow-focused.py'),
    ('audit-string-storage-release.py','audit-string-borrow-release.py'),
    ('test-string-storage-broad.py','test-string-borrow-broad.py'),
]:
    text=(p/old).read_text().replace('string-storage/emaxx','string-borrow-roots/emaxx').replace('target/string-storage-validation','target/string-borrow-validation')
    if old.startswith('run-'):
        text=text.replace('extra_names = {\n','extra_names = {\n'+extra).replace('== 205','== 208')
        text=text.replace('== 3021','== 3024').replace('== 3020','== 3023')
        if old=='run-string-storage-focused.py':
            start=text.index("command = ['cargo', 'test'")
            end=text.index('inventory = [line',start)
            text=text[:start]+"""binary = p / (prefix + '-gate-libtest')
receipt = json.loads((p / (prefix + '-binary.json')).read_text())
assert sha(binary) == receipt['sha256']
probe = json.loads((p / (prefix + '-probe-result.json')).read_text())
assert len(probe['results']) == 7 and all(row['exit_code'] == 0 and row['source_unchanged'] for row in probe['results'])
"""+text[end:]
    if old.startswith('audit-'):
        text=text.replace('205','208')
    if old=='test-string-storage-broad.py':
        text=text.replace('len(names)==1059','len(names)==1062')
        text=text.replace("print('Selected broad existing modules:'", """storage=json.loads((p/('source270-'+profile+'-broad-command.json')).read_text())['selected_inventory']
assert len(storage)==1059 and set(storage)<=set(names)
print('Selected broad existing modules:'""")
        old_qualification='All preceding 962 source261 affected controls, six unchanged GNU comparison/casing fixtures, all86 compatibility-runtime controls, all1054 source263 controls, and five new string-storage/GC/dump controls. The original Unicode comparison retains its GNU assertions with proper Lisp initialization and adds bare/empty-table coverage; no selector, expectation or timeout is dropped.'
        text=text.replace(old_qualification,'All 1059 source270 affected-module controls remain, plus three new borrow/property/weak-root/exclusive-borrow controls. Original selectors, fixtures, expected bytes and timeout are unchanged. This selected suite is separate from full-platform validation.')
    compile(text,new,'exec')
    with (p/new).open('x') as f:f.write(text)
    rows.append(dict(original=old,helper=new,sha256=hashlib.sha256(text.encode()).hexdigest()))
with (p/'string-borrow-selected-preparation.json').open('x') as f:json.dump(dict(status='prepared, not executed',helpers=rows),f,indent=2)
print(json.dumps(rows,indent=2))
