from pathlib import Path
import hashlib,json,re
p=Path(__file__).parent.resolve();root=p.parents[2]
candidate=p.parent/'recovered-2026-09-30/string-borrow-roots/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
read=lambda n:json.loads((p/n).read_text())
before=read('source270-manifest.json');after=read('source271-manifest.json')
assert len(before)==len(after)==510 and before.keys()==after.keys()
assert all(sha(candidate/n)==h for n,h in after.items())
assert all(sha(root/n)==h for n,h in before.items())
changed=[n for n in before if before[n]!=after[n]]
assert changed==['src/lisp/native_comp/runtime.rs']
runtime=(candidate/changed[0]).read_text()
start=runtime.index('    #[test]\n    fn borrowed_string_properties_survive_off_stack_guards_and_are_reclaimed_after_release()')
end=runtime.index('    #[test]\n    fn pure_string_headers_survive_unrooted_gc_outside_the_ordinary_census()',start)
assert runtime[:start]+runtime[end:]==(root/changed[0]).read_text(), 'Production runtime and every original test must remain byte-identical'
result=read('source271-probe-result.json')
assert [r['exit_code'] for r in result['results']]==[0,0,101]
assert all(r['source_unchanged'] and r['published_source_unchanged'] for r in result['results'])
binary=read('source271-binary.json');assert sha(Path(binary['path']))==binary['sha256']
inventory=lambda n:[line[:-6] for line in (p/n).read_text().splitlines() if line.endswith(': test')]
prior=inventory('source270-gate-inventory.log');current=inventory('source271-gate-inventory.log')
test='lisp::native_comp::runtime::tests::borrowed_string_properties_survive_off_stack_guards_and_are_reclaimed_after_release'
assert len(current)==len(set(current))==3022 and sorted(set(current)-set(prior))==[test] and set(prior)<=set(current)
log=(p/'source271-gate-probe.log').read_text()
assert 'test result: FAILED. 2 passed; 1 failed; 0 ignored; 0 measured; 3019 filtered out;' in log
assert re.search(r'a string borrow also retains its property values: "unknown native cons word 0x[0-9a-f]+"',log)
assert log.count('\nFAILED\n')==1
for name in ['native_gc_traces_string_properties_and_reclaims_string_cycles','pure_string_headers_survive_unrooted_gc_outside_the_ordinary_census']:
    assert 'test lisp::native_comp::runtime::tests::'+name+' ... ok\n' in log
out=dict(status='confirmed negative',source_inputs_verified=510,test_only=True,production_source='source270',
         counts=dict(passed=2,failed=1,ignored=0),failing_test=test,binary=binary,
         log_sha256=sha(p/'source271-gate-probe.log'),patch_sha256=sha(p/'source271-test-only.patch'),
         c_reference='alloc.c:mark_objects marks a reached string and its interval tree before weak-table processing and sweeping (rebuilt GNU revision636f166c, alloc.c7255ff).',
         diagnosis='sweep_strings retains borrowed headers, but no mark-phase root traces an off-stack Rust borrow. The checked native decoder rejects its freed cons property value; no freed child is dereferenced by this diagnostic.',
         qualification='This confirms one Rust ownership defect outside the frozen Lisp fixtures. Published source270 and both full-validation checkouts remain unchanged. Existing test names, expectations and failure evidence are preserved; no GNU/performance parity or complete ownership claim follows.')
with (p/'source271-borrow-negative-audit.json').open('x') as f:json.dump(out,f,indent=2)
print(json.dumps(out,indent=2))
