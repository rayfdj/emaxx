from pathlib import Path
import hashlib,json,os,subprocess,sys,time
p=Path(__file__).parent.resolve();c=p.parent/'recovered-2026-10-06/native-unit-owners/emaxx';g=p.parent/'rebuilt-2026-10-01/emacs';target=c/'target/unit-development'
label=sys.argv[1];command=sys.argv[2:];assert label and command
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
base=json.loads((p/'source309-manifest.json').read_text());names=sorted(set(base)|{str(f.relative_to(c)) for f in (c/'src').rglob('*.rs')}|{str(f.relative_to(c)) for f in (c/'tests/fixtures').glob('native-unit-*')})
m={n:sha(c/n) for n in names}
manifest=p/('source310-'+label+'-manifest.json');manifest.open('x').write(json.dumps(m,indent=2))
patch=subprocess.check_output(['git','diff','--binary','--',*names],cwd=c)
tracked=set(subprocess.check_output(['git','ls-files'],cwd=c,text=True).splitlines())
for n in sorted(set(m)-tracked):
 r=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',n],cwd=c,capture_output=True);assert r.returncode==1;patch+=r.stdout
(p/('source310-'+label+'.patch')).open('xb').write(patch)
env=dict(os.environ,CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='1',RUST_MIN_STACK='134217728',RUST_TEST_THREADS='1',EMAXX_GC_VERIFY='1',EMAXX_GNU_SOURCE_DIRECTORY=str(g),EMAXX_DUMP_SOURCE_DIRECTORY=str(g),EMACS_TEST_DIRECTORY=str(g/'test'),EMAXX_IMAGE_TEMPLATE='1',EMAXX_FIXTURE_IMAGE_DIR=str(p/'fixture-images-source310-development'),LANG='C',LC_ALL='C')
rec=dict(command=command,candidate=str(c),source_manifest=manifest.name,environment_overrides={k:v for k,v in env.items() if k.startswith(('CARGO_','RUST_','EMAXX_','EMACS_TEST')) or k in ('LANG','LC_ALL')},goal_complete=False)
(p/('source310-'+label+'-command.json')).open('x').write(json.dumps(rec,indent=2));start=time.monotonic()
with (p/('source310-'+label+'.log')).open('xb') as log:
 try:r=subprocess.run(command,cwd=c,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,timeout=1800);code=r.returncode;timeout=False
 except subprocess.TimeoutExpired:code=None;timeout=True
rec.update(exit_code=code,timed_out=timeout,elapsed_seconds=time.monotonic()-start,source_unchanged=all(sha(c/n)==h for n,h in m.items()))
(p/('source310-'+label+'-result.json')).open('x').write(json.dumps(rec,indent=2));print(json.dumps(rec),flush=True)
sys.exit(0 if code==0 and not timeout and rec['source_unchanged'] else 1)
