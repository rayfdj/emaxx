from pathlib import Path
import hashlib, json, os, re, subprocess

p = Path(__file__).parent.resolve()
root = p.parents[2]
c = p.parent / 'recovered-2026-10-06/native-unit-owners/emaxx'
commit = '6ad703c4ae85b4c3d0be6351a2df9f3bd47489ef'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p / n).read_text())
manifest, modes = read('source310-manifest.json'), read('source310-modes.json')
unchanged = lambda: all(sha(c / n) == h and (c / n).stat().st_mode & 0o777 == modes[n] for n, h in manifest.items())
assert unchanged()
old = read('source310-validation-result.json')
assert old['status'] == 'validation stopped' and old['results'][-1]['stage'] == 'gate-selected'
assert old['results'][-1]['exit_code'] == 101 and old['results'][-1]['source_unchanged']
raw = (p / 'source310-gate-selected.log').read_text()
body = raw.split('\nfailures:\n', 1)[0]
matches = list(re.finditer(r'^test (\S+) \.\.\. ', body, re.M))
selectors = read('source310-gate-selected-command.json')['command'][3:]
assert [m[1] for m in matches] == selectors and len(selectors) == len(set(selectors)) == 1036
failed = []
for i, m in enumerate(matches):
    end = matches[i + 1].start() if i + 1 < len(matches) else len(body)
    verdict = body[m.end():end].strip()
    assert re.search(r'(?:^|\s)(ok|FAILED)$', verdict), (m[1], verdict)
    if verdict.endswith('FAILED'):
        failed.append(m[1])
expected = ['builtin_arities_match_fresh_regeneration', 'gnu_c_defsym_manifest_matches_fresh_regeneration',
            'gnu_c_manifest_matches_fresh_regeneration', 'native_comp_fast_paths_are_audited_against_gnu_c']
assert failed == ['anti_cheat::gate_tests::' + n for n in expected]
assert 'test result: FAILED. 1032 passed; 4 failed; 0 ignored;' in raw
missing = ['compat/generate_builtin_arities.el', 'compat/generate_gnu_c_defsym_manifest.el',
           'compat/generate_gnu_c_primitive_manifest.el', 'tools/generate_native_subrs.rs']
assert all(not (c / n).exists() for n in missing)
preserved = {n: sha(p / n) for n in ['run-source310-validation.py', 'source310-validation-result.json',
    'source310-gate-selected-command.json', 'source310-gate-selected.log', 'source310-gate-selected-result.json',
    'source310-gate-libtest', 'source310-ordinary-queue-result.json']}
entries = subprocess.check_output(['git', 'ls-tree', '-rz', commit, '--', 'tools', 'compat'], cwd=root).split(b'\0')
aux, restored, existing = {}, [], []
for entry in filter(None, entries):
    header, name = entry.split(b'\t', 1)
    mode, kind, oid = header.decode().split()
    assert kind == 'blob' and mode in ['100644', '100755']
    name = name.decode()
    data = subprocess.check_output(['git', 'show', commit + ':' + name], cwd=root)
    file = c / name
    permissions = int(mode[-3:], 8)
    if file.exists():
        assert file.read_bytes() == data and file.stat().st_mode & 0o777 == permissions, name
        existing.append(name)
    else:
        file.parent.mkdir(parents=True, exist_ok=True)
        with file.open('xb') as out:
            out.write(data)
        os.chmod(file, permissions)
        restored.append(name)
    aux[name] = dict(sha256=sha(file), mode=permissions, git_blob=oid, bytes=len(data))
assert unchanged() and all(sha(p / n) == h for n, h in preserved.items())
record = dict(status='auxiliary validation inputs restored; rerun required', commit=commit,
    candidate=str(c), runtime_manifest='source310-manifest.json', runtime_input_count=546,
    runtime_inputs_unchanged=True, original_failed_selection=dict(passed=1032, failed=4, ignored=0,
    failed_names=failed, selected_names=selectors), original_missing_generators=missing,
    preserved_failed_attempt=preserved, auxiliary_inputs=aux, restored=restored, already_present=existing,
    helper=Path(__file__).name, helper_sha256=sha(Path(__file__)), goal_complete=False,
    qualification='The 546-input manifest covers runtime/build/fixture inputs, not every audit dependency. '
    'The sparse checkout omitted unchanged generators. Restore the complete tools and compat trees from the '
    'published source308 commit; bind their bytes and modes into resumed validation. No runtime, assertion, '
    'selector, fixture, expected output or original failure was changed. Passing reruns remain required.')
with (p / 'source310-validation-input-recovery.json').open('x') as f:
    json.dump(record, f, indent=2)
print(json.dumps(dict(restored=len(restored), auxiliary_inputs=len(aux), original_passed=1032, original_failed=4)))
