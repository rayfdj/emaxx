from pathlib import Path
import hashlib, json, subprocess, time

p = Path(__file__).parent.resolve()
root = p.parents[2]
read = lambda n: json.loads((p / n).read_text())
commit = read('source310-applied-commit.json')['commit']
repo, branch = 'rayfdj/emaxx', 'runtime-char-tables'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == commit
assert read('source310-selected-audit.json')['status'] == 'passed'
assert read('source310-application-decision.json')['status'].startswith('apply source310')
remote = subprocess.check_output(['git', 'ls-remote', 'origin', 'refs/heads/' + branch], cwd=root, text=True)
assert remote.split()[0] == commit
assert not (p / 'source310-full-validation-launch.json').exists()
state = dict(commit=commit, branch=branch, repository=repo, runs={}, commands=[], goal_complete=False,
             helper=Path(__file__).name, helper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             qualification='Explicit standing user approval covers later validated task updates on this branch and Linux CI. '
             'Existing Rust and frozen workflows are dispatched once and their exact head verified. Launch is not a validation result.')
def listing():
    cmd = ['gh', 'run', 'list', '--repo', repo, '--workflow', 'frozen-run.yml', '--branch', branch,
           '--event', 'workflow_dispatch', '--limit', '20', '--json',
           'databaseId,headSha,headBranch,status,conclusion,url,createdAt,workflowName']
    return json.loads(subprocess.check_output(cmd, cwd=root, text=True))
try:
    for kind in ['rust', 'frozen']:
        before = {r['databaseId'] for r in listing()}
        cmd = ['gh', 'workflow', 'run', 'frozen-run.yml', '--repo', repo, '--ref', branch, '--field', 'validation=' + kind]
        result = subprocess.run(cmd, cwd=root, text=True, capture_output=True)
        state['commands'].append(dict(validation=kind, command=cmd, exit_code=result.returncode,
                                      stdout=result.stdout, stderr=result.stderr, dispatched_at=time.time()))
        assert result.returncode == 0, state['commands'][-1]
        found = []
        for _ in range(12):
            found = [r for r in listing() if r['databaseId'] not in before and r['headSha'] == commit]
            if found:
                break
            time.sleep(5)
        assert len(found) == 1, found
        assert found[0]['headBranch'] == branch
        state['runs'][kind] = found[0]
        print(json.dumps(dict(validation=kind, run=found[0])), flush=True)
    state['status'] = 'both exact-source Linux workflows launched'
except Exception as error:
    state.update(status='launch incomplete; inspect commands and existing runs before retry', error=repr(error))
finally:
    (p / 'source310-full-validation-launch.json').open('x').write(json.dumps(state, indent=2))
assert len(state['runs']) == 2, state
