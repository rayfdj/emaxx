from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
out = p.parents[2] / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda n: json.loads((p / n).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
audit = read('source310-selected-audit.json')
assert audit['status'] == 'passed' and audit['source_inputs_verified'] == 546
assert audit['auxiliary_inputs_verified'] == 94
assert all(r['passed'] == 1036 and r['failed'] == r['ignored'] == 0 for r in audit['profiles'].values())
assert audit['ordinary_comparisons'] == 56
for n, h in audit['evidence_files'].items():
    assert sha(Path(n).read_bytes()) == h
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected'}
files, excluded = {}, []
for f in p.iterdir():
    if f.is_file() and f.suffix in allowed and f.name.startswith('source310-'):
        files[f.name] = f
    elif f.is_dir() and f.name.startswith('source310-') and any(w in f.name for w in ['file-lifecycle', 'active-lifecycle', 'retained-inputs']):
        for item in f.rglob('*'):
            if not item.is_file():
                continue
            if item.suffix in allowed:
                files[str(item.relative_to(p))] = item
            else:
                excluded.append(dict(path=str(item.relative_to(p)), bytes=item.stat().st_size, sha256=sha(item.read_bytes())))
for f in p.glob('*.py'):
    if '310' in f.name and 'sequence' not in f.name and any(w in f.name for w in ['native-unit', 'source310']):
        files[f.name] = f
for pattern in ['native-unit309-*.el', 'source309-lifecycle-baseline-*', 'source309-file-lifecycle-baseline-comparison.json', 'source309-metadata-*.stdout']:
    for f in p.glob(pattern):
        if f.is_file() and f.suffix in allowed:
            files[f.name] = f
for n in [
    'source309-manifest.json', 'source309-modes.json', 'source309-selected-audit.json', 'source309-validation-result.json',
    'source309-gate-inventory.log', 'source309-release-inventory.log', 'source309-native-ownership-review.json',
    'source308-manifest.json', 'source308-selected-audit.json', 'source308-validation-result.json',
    'source304-selected-audit.json', 'native_fixed_validation_support.py',
    'printer-varied-v3-293638f0.el', 'printer-varied-v3-gnu.stdout',
    'source302-line-broad-gnu.stdout', 'package-source196-failure-and197-results.py', Path(__file__).name,
]:
    files[n] = p / n
assert all(f.is_file() for f in files.values())
package('source310-native-unit-selected', files, dict(
    status='selected native-unit correctness validated; full-platform and performance requirements separate',
    source_inputs=546, auxiliary_inputs=94, passes_per_profile=1036, new_focused_per_profile=5,
    ordinary_comparisons=56, generated_rows=198, excluded_binaries=excluded, goal_complete=False,
    original_failed_attempt=audit['recovery']['original_failed_selection'],
    qualification='Actual88-byte GNU-layout native units replace the host record, strong library registry and permanent relocation roots. '
    'The seven actual Lisp fields own their graph; the unreachable unit closes its library. Repeat loads compare the actual DSO thread '
    'relocation with the owning editor, rejecting foreign live runtimes without adding a registry or ordinary-call lookup. The meaningful '
    'two-editor negative control failed before repair and passes after; its earlier bare-editor setup failure is separately retained. '
    'Every1035 predecessor selected name remains, including24 audit controls. Both profiles pass1036 controls and all56 ordinary GNU '
    'comparisons match, including native metadata, self-unbinding calls through three execution modes and eventual reclamation. '
    'The initial formal selection remains failed with1032 passes/four omitted-generator errors; all94 auxiliary tools/compat inputs '
    'were restored exactly from6ad703c4 without changing any of the546 runtime/build/fixture inputs or gate binary. The four controls '
    'and complete selection subsequently pass. All failures, commands, raw verdicts and portable patches remain. Whole-runtime soundness, '
    'physical accounting, final platform validation and final calibrated performance acceptance are not established by this bundle.'))
