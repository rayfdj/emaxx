from pathlib import Path
import json, subprocess

p = Path(__file__).parent.resolve()
c = p.parent / 'recovered-2026-10-06/native-unit-owners/emaxx'
negative = json.loads((p / 'source310-owner-negative2-result.json').read_text())
assert negative['exit_code'] == 101 and not negative['timed_out'] and negative['source_unchanged']
assert "a live unit cannot adopt the second editor's runtime" in (p / 'source310-owner-negative2.log').read_text()

def replace(name, old, new):
    file = c / name
    text = file.read_text()
    assert text.count(old) == 1, name
    file.write_text(text.replace(old, new))

replace('src/lisp/alloc/vectors/native_units.rs',
'''    pub(crate) fn close_for_runtime(&self, thread_cell: *mut c_void) {
        let Some(library) = self.library() else {
            return;
        };
        // SAFETY: this is the exact pointer field installed by comp.c's
        // first-load path. Inspection does not run Lisp or collect.
        let owned = unsafe {
            library
                .get::<*mut *mut c_void>(b"current_thread_reloc\\0")
                .is_ok_and(|reloc| !reloc.is_null() && std::ptr::read(*reloc) == thread_cell)
        };
        if owned {
            self.unload();
        }
    }''',
'''    pub(crate) fn belongs_to_runtime(&self, thread_cell: *const c_void) -> bool {
        let Some(library) = self.library() else {
            return false;
        };
        // SAFETY: this is the exact pointer field installed by comp.c's
        // first-load path. Inspection does not run Lisp or collect.
        unsafe {
            library
                .get::<*mut *mut c_void>(b"current_thread_reloc\\0")
                .is_ok_and(|reloc| {
                    !reloc.is_null()
                        && std::ptr::eq(std::ptr::read(*reloc).cast_const(), thread_cell)
                })
        }
    }

    pub(crate) fn close_for_runtime(&self, thread_cell: *mut c_void) {
        if self.belongs_to_runtime(thread_cell) {
            self.unload();
        }
    }''')
replace('src/lisp/native_comp/runtime.rs',
'''    pub(crate) fn current_thread_relocation(&mut self) -> *mut c_void {''',
'''    pub(crate) fn current_thread_relocation_address(&self) -> *const c_void {
        std::ptr::from_ref(&*self.thread_pointer).cast()
    }

    pub(crate) fn current_thread_relocation(&mut self) -> *mut c_void {''')
replace('src/lisp/native_comp/loader.rs',
'''        if !unit.is_loaded() {
            return Err(inconsistent(filename));
        }
        unit.loaded_once.set(true);''',
'''        // Unlike GNU's one editor per process, two Rust editors may be
        // alive in this host. Their dlopen image still has only one runtime
        // relocation. Preserve the former registry's owner check using that
        // actual field before running code or changing any unit state.
        if !unit.belongs_to_runtime(runtime.current_thread_relocation_address()) {
            return Err(inconsistent(filename));
        }
        unit.loaded_once.set(true);''')
subprocess.run(['cargo', 'fmt', '--all'], cwd=c, check=True)
print('Restored repeated-load ownership using the actual DSO runtime relocation; ordinary function calls unchanged')
