from pathlib import Path
import ast, hashlib, json
p = Path(__file__).parent.resolve()
text = (p / 'audit-native-unit310-selected.py').read_text()
def replace(old, new, count=1):
    global text
    assert text.count(old) == count, (old, text.count(old))
    text = text.replace(old, new)
replace("state = read('source310-validation-result.json')", '''original = read('source310-validation-result.json')
assert original['status'] == 'validation stopped'
assert all(r['exit_code'] == 0 and not r['timed_out'] and r['source_unchanged'] for r in original['results'][:-1])
assert original['results'][-1]['stage'] == 'gate-selected' and original['results'][-1]['exit_code'] == 101
assert sha(p / original['runner']) == original['runner_sha256']
recovery = read('source310-validation-input-recovery.json')
assert all(sha(p / n) == h for n, h in recovery['preserved_failed_attempt'].items())
assert recovery['original_failed_selection']['passed'] == 1032 and recovery['original_failed_selection']['failed'] == 4
assert len(recovery['auxiliary_inputs']) == 94
assert all(sha(c / n) == item['sha256'] and (c / n).stat().st_mode & 0o777 == item['mode']
           for n, item in recovery['auxiliary_inputs'].items())
restored = audit_selected((p / 'source310-resumed-restored-audit-controls.log').read_text(),
                          recovery['original_failed_selection']['failed_names'])
assert restored['passed'] == 4
state = read('source310-resumed-validation-result.json')
assert state['validation_input_recovery_sha256'] == sha(p / 'source310-validation-input-recovery.json')
''')
replace("names = inventory('source310')", "names = inventory('source310-resumed')")
for suffix in ['focused.log', 'selected.log']:
    replace("f'source310-{profile}-" + suffix + "'", "f'source310-resumed-{profile}-" + suffix + "'")
replace("f'source310-{profile}-build.log'", "(('source310-' if profile == 'gate' else 'source310-resumed-') + profile + '-build.log')")
replace("    raw = (p / f'source310-{stage}.log').read_text()", "    prefix = 'source310-' if stage in ['fmt', 'check', 'clippy', 'diff', 'gate-build'] else 'source310-resumed-'\n    raw = (p / (prefix + stage + '.log')).read_text()")
replace("queue = read('source310-ordinary-queue-result.json')", "queue = read('source310-resumed-ordinary-queue-result.json')")
replace("assert all(sha(p / n) == h for n, h in queue['helpers'].items())", '''assert all(sha(p / n) == h for n, h in queue['helpers'].items())
assert len(queue['steps']) == 8
assert all(r['exit_code'] == 0 and not r['timed_out'] and r['inputs_unchanged'] for r in queue['steps'])
for kind, stages in [('file', ['compile', 'execute']), ('active', ['compile-caller', 'compile-worker', 'execute'])]:
    for editor in ['gnu', 'source310']:
        directory = p / ('source310-' + kind + '-lifecycle-' + editor)
        for stage in stages:
            command = json.loads((directory / (stage + '-command.json')).read_text())
            result = json.loads((directory / (stage + '-result.json')).read_text())
            assert result['exit_code'] == 0 and not result['timed_out'] and result['inputs_unchanged']
            assert all(sha(Path(n)) == h for n, h in command['inputs'].items())
            assert sha(directory / (stage + '.stdout')) == result['stdout_sha256']
            assert sha(directory / (stage + '.stderr')) == result['stderr_sha256']
''')
replace("source_inputs_verified=546, profiles=profiles", "source_inputs_verified=546, auxiliary_inputs_verified=94, recovery=recovery, original_attempt_status='failed', profiles=profiles")
replace("Both profiles and every ordinary comparison are independently audited.", "Both profiles and every ordinary comparison are independently audited. The initial selected attempt remains failed (1032 passes/four missing-generator failures); exact published auxiliary inputs were restored without changing the runtime, test binary, assertions or selectors. All four generator controls and the complete selection passed afterward; all94 auxiliary input bytes/modes are bound to the resumed runs.")
ast.parse(text)
file = p / 'audit-native-unit310-selected-resumed.py'
with file.open('x') as f:
    f.write(text)
print(json.dumps(dict(helper=file.name, sha256=hashlib.sha256(file.read_bytes()).hexdigest())))
