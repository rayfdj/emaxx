from pathlib import Path
import ast, hashlib, json

p = Path(__file__).parent.resolve()
original = (p / 'run-source310-validation.py').read_text()
prefix = original[:original.index("base = read(p / 'source309-manifest.json')")]
prefix += '''manifest = read(p / 'source310-manifest.json')
modes = read(p / 'source310-modes.json')
recovery = read(p / 'source310-validation-input-recovery.json')
assert len(manifest) == 546
assert (c.parent / 'emacs').resolve() == g.resolve()
changes = read(p / 'source310-validation-result.json')['changes']
assert read(p / 'source310-validation-result.json')['status'] == 'validation stopped'
assert read(p / 'source310-ordinary-queue-result.json')['steps'] == []
'''
text = prefix + original[original.index('env = dict'):]
def replace(old, new, count=1):
    global text
    assert text.count(old) == count, (old, text.count(old), count)
    text = text.replace(old, new)

replace("unchanged = lambda: all(sha(c / n) == h for n, h in manifest.items())", '''unchanged = lambda: (
    all(sha(c / n) == h and (c / n).stat().st_mode & 0o777 == modes[n] for n, h in manifest.items())
    and all(sha(c / n) == item['sha256'] and (c / n).stat().st_mode & 0o777 == item['mode']
            for n, item in recovery['auxiliary_inputs'].items())
    and all(sha(p / n) == h for n, h in recovery['preserved_failed_attempt'].items()))
state['validation_input_recovery'] = 'source310-validation-input-recovery.json'
state['validation_input_recovery_sha256'] = sha(p / state['validation_input_recovery'])
state['original_attempt'] = 'source310-validation-result.json'
state['original_attempt_status'] = 'failed; 1032 passed and four omitted-generator audit failures'
''')
replace("'source310-validation-state.json'", "'source310-resumed-validation-state.json'")
replace("'source310-validation-result.json').open('x')", "'source310-resumed-validation-result.json').open('x')")
replace("('source310-' + stage", "('source310-resumed-' + stage", 3)
start = text.index('    assert not target.exists()')
end = text.index("    for profile in ('gate', 'release'):", start)
text = text[:start] + '''    assert target.is_dir() and unchanged()
    gate_binary = read(p / 'source310-gate-selected-command.json')['command'][0]
    assert sha(Path(gate_binary)) == sha(p / 'source310-gate-libtest')
    run('restored-audit-controls', [gate_binary, '--exact', '--test-threads=1',
        *recovery['original_failed_selection']['failed_names']])
    state['restored_audit_controls'] = audit_selected(
        (p / 'source310-resumed-restored-audit-controls.log').read_text(),
        recovery['original_failed_selection']['failed_names'])
''' + text[end:]
replace("        run(profile + '-build', ['cargo', 'test', '--locked', '--profile', profile, '--all-features', '--lib', '--no-run', '--message-format=json'])", "        if profile == 'release':\n            run(profile + '-build', ['cargo', 'test', '--locked', '--profile', profile, '--all-features', '--lib', '--no-run', '--message-format=json'])")
replace("(p / ('source310-' + profile + '-build.log'))", "(p / (('source310-' if profile == 'gate' else 'source310-resumed-') + profile + '-build.log'))")
replace("        assert not retained.exists()\n        shutil.copy2(binary, retained)", "        if profile == 'release':\n            assert not retained.exists()\n            shutil.copy2(binary, retained)\n        else:\n            assert retained.exists()")
for suffix in ['inventory.log', 'focused.log', 'selected.log']:
    replace("('source310-' + profile + '-" + suffix + "')", "('source310-resumed-' + profile + '-" + suffix + "')")
replace("'source310-ordinary-build.log'", "'source310-resumed-ordinary-build.log'")
ast.parse(text)
runner = p / 'run-source310-validation-resumed.py'
with runner.open('x') as f:
    f.write(text)

queue = (p / 'finish-native-unit310-ordinary.py').read_text()
assert queue.count('source310-validation-result.json') == 2
queue = queue.replace('source310-validation-result.json', 'source310-resumed-validation-result.json')
queue = queue.replace("'run-source310-validation.py'", "'run-source310-validation-resumed.py', 'source310-validation-input-recovery.json'")
queue = queue.replace('source310-ordinary-queue-', 'source310-resumed-ordinary-queue-')
old = "manifest = read('source310-manifest.json')"
assert queue.count(old) == 1
queue = queue.replace(old, old + "\nrecovery = read('source310-validation-input-recovery.json')")
old = "and all(sha(p / n) == h for n, h in helpers.items()))"
assert queue.count(old) == 1
queue = queue.replace(old, "and all(sha(p / n) == h for n, h in helpers.items())\n            and all(sha(c / n) == item['sha256'] and (c / n).stat().st_mode & 0o777 == item['mode']\n                    for n, item in recovery['auxiliary_inputs'].items()))")
ast.parse(queue)
with (p / 'finish-native-unit310-ordinary-resumed.py').open('x') as f:
    f.write(queue)
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
print(json.dumps({n: sha(p / n) for n in [runner.name, 'finish-native-unit310-ordinary-resumed.py']}))
