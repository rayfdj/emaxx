from pathlib import Path
import ast, hashlib, json

p = Path(__file__).parent.resolve()
outputs = {}
for name in ['setup-source308-full-macos.py', 'queue-source308-full-macos.py', 'audit-source308-selected-for-full.py']:
    text = (p / name).read_text()
    text = text.replace('source308', 'source310').replace('native-subr-callbacks/emaxx', 'native-unit-owners/emaxx')
    text = text.replace('native-subr-full/emaxx', 'native-unit-full/emaxx')
    text = text.replace('541', '546').replace('1031', '1036')
    text = text.replace("ordinary_comparisons']==52", "ordinary_comparisons']==56")
    text = text.replace("ordinary_comparisons'] == 52", "ordinary_comparisons'] == 56")
    text = text.replace('ordinary_comparisons=52', 'ordinary_comparisons=56')
    if name.startswith('setup-'):
        old = "assert read('native-subr308-combined-performance-audit.json')['status']=='all 384 processes and actual results/modes verified'\nassert read('native-subr308-performance-sequence-final-result.json')['status']=='timing audited; native-object source decision pending'"
        assert old in text
        text = text.replace(old, "assert read('native-unit310-performance-audit.json')['status']=='all 192 processes and actual results/modes verified'\nassert read('native-unit310-sequence-result.json')['status']=='selected correctness and diagnostic timing audited; application decision required'")
    if name.startswith('queue-'):
        needle = "assert len(manifest) == 546 and unchanged(root) and unchanged(selected_root)"
        assert needle in text
        text = text.replace(needle, needle + "\n    auxiliary = json.loads((p / 'source310-validation-input-recovery.json').read_text())['auxiliary_inputs']\n    assert len(auxiliary) == 94\n    for directory in [root, selected_root]:\n        assert all(sha(directory / n) == item['sha256'] and (directory / n).stat().st_mode & 0o777 == item['mode'] for n, item in auxiliary.items())")
        text = text.replace("p / 'source310-manifest.json', p / 'source310-full-checkout.json',", "p / 'source310-manifest.json', p / 'source310-full-checkout.json', p / 'source310-validation-input-recovery.json',")
    if name.startswith('audit-'):
        needle = "assert all(sha(Path(n))==h for n,h in audit['evidence_files'].items())"
        assert needle in text
        text = text.replace(needle, "assert audit['auxiliary_inputs_verified'] == 94\n" + needle)
    ast.parse(text)
    new = p / name.replace('source308', 'source310')
    with new.open('x') as f:
        f.write(text)
    outputs[new.name] = hashlib.sha256(new.read_bytes()).hexdigest()
print(json.dumps(outputs, indent=2))
