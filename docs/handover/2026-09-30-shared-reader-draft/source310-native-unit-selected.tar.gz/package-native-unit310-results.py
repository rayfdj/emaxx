from pathlib import Path
import ast, gzip, hashlib, io, json, sys, tarfile

p = Path(__file__).parent.resolve()
out = p.parents[2] / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda n: json.loads((p / n).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected', '.h'}
phase = sys.argv[1]
assert phase in ['performance', 'terminal308']
files = {}
if phase == 'performance':
    audit = read('native-unit310-performance-audit.json')
    decision = read('source310-application-decision.json')
    assert audit['status'] == 'all 192 processes and actual results/modes verified'
    assert read('native-unit310-sequence-result.json')['status'] == 'selected correctness and diagnostic timing audited; application decision required'
    assert all(sha(Path(n).read_bytes()) == h for n, h in audit['evidence_files'].items())
    for tag in ['source308', 'source310']:
        for directory in sorted(p.glob(tag + '-native-unit310-pilot-*')) + [p / (tag + '-core-native')]:
            files.update({str(f.relative_to(p)): f for f in directory.rglob('*') if f.is_file() and f.suffix in allowed})
    for f in p.iterdir():
        if f.is_file() and f.suffix in allowed and f.name.startswith(('native-unit310-performance-', 'native-unit310-sequence-')):
            files[f.name] = f
    for n in ['measure-native-unit310.py', 'audit-native-unit310-performance.py', 'finish-native-unit310-sequence.py',
              'source310-application-decision.json', 'source310-manifest.json', 'source310-modes.json',
              'source310-selected-audit.json', 'source310-validation-input-recovery.json', 'source310-ordinary-artifacts.json',
              'source308-manifest.json', 'source308-selected-audit.json', 'source308-ordinary-artifacts.json',
              'audit-native-unit310-selected-resumed.py', 'source308-macos-terminal-audit.json',
              'package-source196-failure-and197-results.py', Path(__file__).name]:
        files[n] = p / n
    assert all(f.is_file() for f in files.values())
    package('source310-native-unit-performance', files, dict(status=audit['status'], application_decision=decision,
        audit=dict(path='native-unit310-performance-audit.json', sha256=sha((p / 'native-unit310-performance-audit.json').read_bytes())),
        qualification=audit['qualification'], goal_complete=False))
else:
    audit = read('source308-macos-terminal-audit.json')
    queue = read('source308-full-queue-result.json')
    assert audit['status'] == 'passed' and audit['fully_matching_scenarios'] == 226 and audit['matching_comparisons'] == 686
    assert queue['status'] == 'complete macOS processes finished; raw evidence requires audit'
    assert sha((p / 'source308-full-tty.log').read_bytes()) == audit['log_sha256']
    assert read('source308-full-oracle-verify-result.json')['exit_code'] == 0
    verification = read('source308-full-retained-gnu/verification.json')
    assert verification['status'] == 'unchanged' and verification['files_verified'] == 4
    oracle = read('source308-full-retained-gnu/manifest.json')
    assert verification['capture_manifest_sha256'] == sha((p / 'source308-full-retained-gnu/manifest.json').read_bytes())
    for item in oracle['files']:
        assert sha(Path(item['original']).read_bytes()) == sha((p / 'source308-full-retained-gnu' / item['artifact']).read_bytes()) == item['sha256']
    for f in p.iterdir():
        if f.is_file() and f.suffix in allowed and f.name.startswith(('source308-full-tty', 'source308-full-oracle-verify', 'source308-full-queue')):
            files[f.name] = f
    for n in ['audit-source308-macos-terminal.py', 'source308-macos-terminal-audit.json', 'source308-macos-frozen-audit.json',
              'source308-manifest.json', 'source308-full-launch.json', 'source308-full-checkout.json', 'queue-source308-full-macos.py',
              'source248-full-ttydiff-retry-command.json', 'source248-manifest.json',
              'package-source196-failure-and197-results.py', Path(__file__).name]:
        files[n] = p / n
    for f in (p / 'source308-full-retained-gnu').glob('*.json'):
        files[str(f.relative_to(p))] = f
    assert all(f.is_file() for f in files.values())
    package('source308-macos-terminal-results', files, dict(status=audit['status'], terminal=audit,
        final_oracle_verification=verification, qualification=audit['qualification'], goal_complete=False))
