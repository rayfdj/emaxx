from pathlib import Path
import ast
import gzip
import hashlib
import io
import json
import re
import sys
import tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
for script, function in [('audit-shared-reader196-fresh-selected.py', 'audit_log'),
                         ('package-source196-failure-and197-results.py', 'package')]:
    node = next(node for node in ast.parse((p / script).read_text()).body
                if isinstance(node, ast.FunctionDef) and node.name == function)
    exec(compile(ast.Module(body=[node], type_ignores=[]), script, 'exec'))
sys.path.insert(0, str(root / 'tools'))
import grouped_gate

artifact = p / 'linux-source196-rust-artifacts'
run = artifact / 'rust'
summary = json.loads((run / 'summary.json').read_text())
state = read('source196-linux-rust-final-state.json')
assert state['status'] == 'completed' and state['conclusion'] == 'failure'
assert summary['git'] == {'head': state['headSha'], 'dirty': False}
assert state['headSha'] == 'ece02f9522d4e0d6d7a6a0cf6648dd109885780b'
assert summary['status'] == 'failed' and summary['cargo_stages'] == []
retained = json.loads((run / 'retained-inputs/manifest.json').read_text())
assert sha((run / 'summary.json').read_bytes()) == retained['gate_summary_sha256']
for item in retained['files']:
    data = (run / 'retained-inputs' / item['artifact']).read_bytes()
    assert len(data) == item['bytes'] and sha(data) == item['sha256']
assert sha((run / 'retained-inputs/libtest').read_bytes()) == summary['test_binary']['sha256']
inventory = grouped_gate.parse_inventory((run / 'inventory.txt').read_text())
assert sha(('\n'.join(inventory) + '\n').encode()) == summary['inventory']['sha256']
groups, _ = grouped_gate.classify_inventory(inventory, 'full')
observed = []
for group in ['eval_01', 'eval_02', 'eval_03', 'eval_04', 'eval_05', 'primitives']:
    failed = int(group == 'primitives')
    passed = len(groups[group]) - failed
    log = (run / ('repeat-01-' + group + '.log')).read_text()
    failures = audit_log(groups[group], log, passed, failed)
    if failed:
        assert failures == ['lisp::primitives::tests::native_keyboard_input_family_matches_gnu_kboard_contracts']
        assert 'No unread-command-events available for interactive input' in log
    observed.append({'group': group, 'passed': passed, 'failed': failed, 'failures': failures})
assert sum(item['passed'] for item in observed) == 2229
remaining = ['compat_runtime', 'tty', 'batch', 'lightweight']
assert all(not (run / ('repeat-01-' + group + '.log')).exists() for group in remaining)
audit = {'status': 'failed', 'head': state['headSha'], 'groups': observed,
         'raw_passed': 2229, 'raw_failed': 1, 'retained_artifact_hashes_verified': True,
         'unexecuted': remaining + ['binary Cargo stage', 'integration Cargo stage'],
         'qualification': 'Same unchanged keyboard-input fixture failure as macOS. No full-source pass. Linux frozen comparison is a separate still-running run.'}
with (p / 'source196-linux-rust-failure-audit.json').open('x') as stream:
    json.dump(audit, stream, indent=2)
files = {str(f.relative_to(p)): f for f in artifact.rglob('*') if f.is_file() and f.suffix in {'.json', '.log', '.txt', '.apparmor'}}
for name in ['source196-linux-rust-final-state.json', 'source196-linux-rust-download.json',
             'source196-linux-rust-failure-audit.json', 'source196-linux-rust.log', Path(__file__).name]:
    files[name] = p / name
package('source196-linux-rust-failure', files, audit)

for stage in ['check', 'fmt', 'clippy', 'diff', 'gate-build', 'gate-focused']:
    result = read('source198-' + stage + '-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
command = read('source198-gate-focused-command.json')
assert sha(Path(command['command'][0]).read_bytes()) == command['binary_sha256']
assert audit_log(command['selected_inventory'], (p / 'source198-gate-focused.log').read_text(), 3, 0) == []
assert all(sha((Path(command['working_directory']) / name).read_bytes()) == digest
           for name, digest in read('source198-manifest.json').items())
files = {Path(__file__).name: Path(__file__)}
for stage in ['check', 'fmt', 'clippy', 'diff', 'gate-build', 'gate-focused']:
    for suffix in ['-command.json', '-result.json', '.log']:
        name = 'source198-' + stage + suffix
        files[name] = p / name
package('source198-focused', files, {'strict_checks': 'passed', 'focused_gate': 3,
        'qualification': 'The original ten keyboard-input assertions, live binding control and macro reclamation control pass. Broader gate/release, ordinary and complete validation remain unclaimed. Runtime source is unchanged from source197; no performance claim.'})
