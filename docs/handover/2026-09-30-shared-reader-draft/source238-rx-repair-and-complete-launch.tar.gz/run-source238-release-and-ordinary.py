from pathlib import Path
import json,subprocess,sys,time
p=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28')
assert all(stage['exit_code']==0 for stage in json.loads((p/'source238-validation-result.json').read_text()))
results=[]
for name,args in [('run-source238-ordinary.py',[]),('test-source238-controls.py',['238','release']),('test-source238-broad.py',['238','release'])]:
 command=[sys.executable,str(p/name),*args];start=time.monotonic();result=subprocess.run(command,stdin=subprocess.DEVNULL)
 results.append({'command':command,'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start})
 if result.returncode:break
with (p/'source238-release-and-ordinary-result.json').open('x') as f:json.dump(results,f,indent=2)
raise SystemExit(results[-1]['exit_code'])
