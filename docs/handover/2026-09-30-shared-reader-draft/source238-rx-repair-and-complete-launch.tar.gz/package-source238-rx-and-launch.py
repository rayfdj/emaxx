from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve();out=p.parents[2]/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest()
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
audit=json.loads((p/'source238-rx-audit.json').read_text());assert audit['processes']==4
names=['source238-rx-audit.json','audit-source238-rx.py','source238-validation-result.json','source238-validation.log','validate-source238-rx.py','source238-ordinary-artifacts.json','source238-local-commit.json','source238-push-result.json','source238-remote-head.json','commit-source238-checkpoint.py','source238-linux-launches.json','launch-source238-linux.py','source238-full-gate-launch.json','run-source238-full-gate.py','source238-full-tty-launch.json','run-source238-full-tty.py','source238-full-ttydiff-command.json','source238-release-and-ordinary-launch.json','run-source238-release-and-ordinary.py','run-source238-ordinary.py','test-source238-broad.py','source238-pr-body.md',Path(__file__).name]
for stage in ['ordinary-build','ordinary-image']:
 for suffix in ['-command.json','-result.json','.log']:names.append('source238-'+stage+suffix)
files={name:p/name for name in names}
for pattern in ['source238-rx-*','source238-linux-*-dispatch.json','source238-linux-*-initial-state.json']:
 files.update({f.name:f for f in p.glob(pattern) if f.is_file()})
package('source238-rx-repair-and-complete-launch',files,{'rx_audit':audit,'publication':json.loads((p/'source238-remote-head.json').read_text()),'linux':json.loads((p/'source238-linux-launches.json').read_text()),'qualification':'Local unchanged upstream rx reproduction now passes all 36 tests through both runners in each editor. Exact source238 runtime a7e12de8 is pushed. Full macOS supervisor30236, full terminal31378, release/ordinary31379 and both fresh Linux runs are active. Launches are not completed passes. Arbitrary failure-report encoding, complete display-table review, pinned Darwin and performance remain open.'})
