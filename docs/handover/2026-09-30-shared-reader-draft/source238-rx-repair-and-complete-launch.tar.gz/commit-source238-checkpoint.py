from pathlib import Path
import hashlib,io,json,subprocess,tarfile
p=Path(__file__).parent.resolve();root=p.parents[2]
sha=lambda data:hashlib.sha256(data).hexdigest()
run=lambda args:subprocess.check_output(args,cwd=root,text=True).strip()
assert run(['git','branch','--show-current'])=='runtime-char-tables'
assert run(['git','rev-parse','HEAD'])=='df42fda2a31144ecb25cd5102385a8a3660c173a'
assert not run(['git','diff','--cached','--name-only'])
audit=json.loads((p/'source238-focused-audit.json').read_text());assert audit['passed']==101 and len(audit['ignored'])==2
manifest=json.loads((p/'source238-manifest.json').read_text());assert len(manifest)==446
assert all(sha((root/name).read_bytes())==digest for name,digest in manifest.items())
docs=['HANDOVER.md','docs/runtime-representation-progress.md','docs/runtime-representation-correctness-recovery-draft.md']
stems=['source234-complete-rust-and-selected','source234-linux-rx-failure','source237-display-validation-and238-rx-draft','source238-focused-validation']
archive_paths=[]
for stem in stems:
 prefix='docs/handover/2026-09-30-shared-reader-draft/'+stem
 archive_paths += [prefix+'-manifest.json',prefix+'.tar.gz']
 record=json.loads((root/(prefix+'-manifest.json')).read_text());a=root/(prefix+'.tar.gz')
 assert sha(a.read_bytes())==record['archive']['sha256']
 with tarfile.open(a) as t:
  assert t.getnames()==[f['path'] for f in record['files']]
  for f in record['files']:assert sha(t.extractfile(f['path']).read())==f['sha256']
subprocess.run(['git','diff','--check'],cwd=root,check=True)
subprocess.run(['git','add','--',*sorted(manifest),*docs,*archive_paths],cwd=root,check=True)
subprocess.run(['git','diff','--cached','--check'],cwd=root,check=True)
tree=run(['git','write-tree'])
contents=subprocess.check_output(['git','archive',tree,'--',*sorted(manifest)],cwd=root)
with tarfile.open(fileobj=io.BytesIO(contents)) as archive:
 for name,digest in manifest.items():assert sha(archive.extractfile(name).read())==digest,name
changed=run(['git','diff','--cached','--name-only']).splitlines()
assert all(name in manifest or name in docs or name in archive_paths for name in changed)
subprocess.run(['git','-c','user.name=Ray','-c','user.email=26018378+rayfdj@users.noreply.github.com','commit','-m','Honor display tables and preserve characters in reader and mapconcat'],cwd=root,check=True)
head=run(['git','rev-parse','HEAD']);assert run(['git','rev-parse','HEAD^{tree}'])==tree
assert not run(['git','status','--porcelain'])
record=dict(commit=head,tree=tree,branch='runtime-char-tables',source='source238',source_inputs=446,changed_paths=changed,goal_complete=False,validation='Strict zero-warning checks and 101 focused gate passes with two existing ignores on all 446 exact inputs. Source237 component matches all 11 selected terminal scenarios and 39 comparisons, clearing all seven original divergences. Source234 complete macOS/Linux Rust pass with 3079/3091 tests; frozen fails later at rx despite repairing Edebug. New reader/mapconcat fixes have GNU-backed focused controls; ordinary upstream rx, complete macOS, full terminal and Linux validation remain required. Main and the full goal remain unchanged; no performance parity claimed.')
with (p/'source238-local-commit.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(dict(commit=head,source_inputs=446,changed_paths=len(changed),status='committed locally; not yet pushed'),indent=2))
