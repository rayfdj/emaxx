from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).parent.resolve(); root=p.parent/'recovered-2026-09-30/rx-repair/emaxx';gnu=p.parent/'recovered-2026-09-30/emacs'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
artifacts=json.loads((p/'source238-ordinary-artifacts.json').read_text())
assert all(sha(Path(name))==entry['sha256'] for name,entry in artifacts.items())
outcomes=[]
selector="(not (or (tag :expensive-test) (tag :unstable)))"
fixture=gnu/'test/lisp/emacs-lisp/rx-tests.el';runner=root/'compat/emacs_compat_runner.el'
for mode in ['ordinary-ert','compat']:
 for editor,binary in [('gnu',gnu/'src/emacs'),('emaxx',root/'target/frame-validation/release/emaxx')]:
  stem='source238-rx-'+mode+'-'+editor
  env={'LANG':'C','LC_ALL':'C','EMACS_TEST_DIRECTORY':str(gnu/'test')}
  command=[str(binary),'-Q','--batch','-L',str(gnu/'test'),'-l','ert']
  if mode=='compat':
   env.update(EMAXX_BATCH_RESULT_FILE=str(p/(stem+'-report.json')),EMAXX_COMPAT_RELATIVE_FILE='test/lisp/emacs-lisp/rx-tests.el',EMAXX_COMPAT_RUNNER=editor,EMAXX_COMPAT_SELECTOR=selector)
   command+=['-l',str(runner)]
  command+=['-l',str(fixture),'--eval',('emaxx-compat-run' if mode=='compat' else 'ert-run-tests-batch-and-exit')]
  command[-1]='('+command[-1]+" '"+selector+')'
  inputs={str(f):sha(f) for f in [binary,binary.with_suffix('.pdmp'),fixture,runner]}
  with (p/(stem+'-command.json')).open('x') as f:json.dump({'command':command,'environment_override':env,'inputs':inputs,'qualification':'Diagnostic ordinary source238 macOS run of unchanged rx inventory; GNU source/ABI matches but is not pinned Darwin.'},f,indent=2)
  start=time.monotonic()
  with (p/(stem+'.stdout')).open('xb') as out,(p/(stem+'.stderr')).open('xb') as err:
   result=subprocess.run(command,cwd=root,env={**os.environ,**env},stdin=subprocess.DEVNULL,stdout=out,stderr=err,timeout=600)
  record={'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,'inputs_unchanged':all(sha(Path(name))==digest for name,digest in inputs.items())}
  with (p/(stem+'-result.json')).open('x') as f:json.dump(record,f,indent=2)
  outcomes.append(record)
  print(stem,record,flush=True)

assert len(outcomes)==4 and all(row['exit_code']==0 and row['inputs_unchanged'] for row in outcomes),outcomes
