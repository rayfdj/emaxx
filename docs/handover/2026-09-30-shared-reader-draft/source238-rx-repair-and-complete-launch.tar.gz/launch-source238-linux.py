from pathlib import Path
from datetime import datetime, timezone
import json
import subprocess
import time

p = Path(__file__).parent.resolve()
head = json.loads((p / 'source238-remote-head.json').read_text())['commit']
repo = 'rayfdj/emaxx'

def runs():
    command = ['gh', 'run', 'list', '--repo', repo, '--workflow', 'frozen-run.yml',
               '--branch', 'runtime-char-tables', '--limit', '15',
               '--json', 'databaseId,headSha,status,conclusion,url,createdAt']
    return [row for row in json.loads(subprocess.check_output(command)) if row['headSha'] == head]

launched = []
for validation in ['rust', 'frozen']:
    before = {row['databaseId'] for row in runs()}
    command = ['gh', 'workflow', 'run', 'frozen-run.yml', '--repo', repo,
               '--ref', 'runtime-char-tables', '-f', 'validation=' + validation]
    result = subprocess.run(command, capture_output=True, text=True)
    with (p / ('source238-linux-' + validation + '-dispatch.json')).open('x') as stream:
        json.dump(dict(command=command, commit=head, exit_code=result.returncode,
                       stdout=result.stdout, stderr=result.stderr), stream, indent=2)
    assert result.returncode == 0, result.stderr
    for attempt in range(15):
        fresh = [row for row in runs() if row['databaseId'] not in before]
        if fresh:
            break
        time.sleep(2)
    assert len(fresh) == 1, fresh
    row = fresh[0]
    state = json.loads(subprocess.check_output([
        'gh', 'run', 'view', str(row['databaseId']), '--repo', repo,
        '--json', 'status,conclusion,headSha,url,jobs']))
    assert state['headSha'] == head
    with (p / ('source238-linux-' + validation + '-initial-state.json')).open('x') as stream:
        json.dump(state, stream, indent=2)
    launched.append(dict(validation=validation, id=row['databaseId'], status=state['status'],
                         headSha=head, url=state['url'], command=command))
    print(validation, row['databaseId'], state['status'], state['url'], flush=True)
with (p / 'source238-linux-launches.json').open('x') as stream:
    json.dump(dict(observed_at=datetime.now(timezone.utc).isoformat(), commit=head,
                   branch='runtime-char-tables', goal_complete=False, runs=launched,
                   qualification='Both run heads verified against the independently verified pushed commit. Launches do not establish passing results.'), stream, indent=2)
