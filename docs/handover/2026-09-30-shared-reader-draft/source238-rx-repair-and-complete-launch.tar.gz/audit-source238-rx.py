from pathlib import Path
import hashlib,json,re
p=Path(__file__).parent.resolve();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();read=lambda f:json.loads((p/f).read_text())
reports={editor:read('source238-rx-compat-'+editor+'-report.json') for editor in ['gnu','emaxx']}
expected=sorted(reports['gnu']['selected_tests']);assert len(expected)==len(set(expected))==36
for editor,report in reports.items():
 assert report['file_status']=='loaded' and sorted(report['selected_tests'])==expected
 assert sorted(row['name'] for row in report['results'])==expected
 assert all(row['status']=='passed' and row['expected'] for row in report['results'])
 for mode in ['ordinary-ert','compat']:
  stem='source238-rx-'+mode+'-'+editor
  command=read(stem+'-command.json');result=read(stem+'-result.json')
  assert result['exit_code']==0 and result['inputs_unchanged']
  assert all(sha(Path(f))==digest for f,digest in command['inputs'].items())
  if mode=='ordinary-ert':
   raw=(p/(stem+'.stderr')).read_text()
   names=re.findall(r'^\s*passed\s+\d+/36\s+(\S+)',raw,re.M)
   assert sorted(names)==expected
   assert '36 results as expected, 0 unexpected' in raw
  else:assert (p/(stem+'.stderr')).read_bytes()==b''
old=(p/'source234-rx-ordinary-ert-emaxx.stderr').read_text()
assert re.findall(r'^\s*FAILED\s+\d+/36\s+(\S+)',old,re.M)==['rx-char-any-raw-byte','rx-charset-or']
record={'status':'all 36 upstream rx tests pass in both ordinary ERT and structured runners','source':'source238','original_repaired_tests':['rx-char-any-raw-byte','rx-charset-or'],'test_names':expected,'processes':4,'qualification':'Each editor executes the unchanged upstream rx file and selector through normal -Q batch entry points and its own valid executable/image. All 36 raw ordinary ERT verdicts and all 36 structured outcomes pass for each editor. This closes the local reproduction of the source234 Linux failure; the fresh Linux frozen run remains required. Successful rx reporting does not establish that arbitrary failure reports containing unsupported characters work. GNU is source/native-ABI matched, not pinned Darwin. No timing claim.'}
with (p/'source238-rx-audit.json').open('x') as f:json.dump(record,f,indent=2)
print(record['status'])
