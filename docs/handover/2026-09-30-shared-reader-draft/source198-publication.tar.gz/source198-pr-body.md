Command input previously used separate decoding paths in frames, menus, minibuffers and keyboard macros. Those paths could repeat collecting keymap filters, keep copied macro events after Lisp replaced or stopped execution, and lose wrapped events or modifier bits.

Use one incremental reader with live keymaps and rooted event values. Keyboard macros read the actual Lisp array and public index. Nested state uses GNU's two ordinary conses and a borrowed root scope, removing the per-execution host vector and global root-registry registration. Coordinate lookup shares display-motion traversal, and unchanged GNU Lisp owns mouse-link translation.

The existing keyboard-input fixture now loads the actual batch Lisp owners, as its GNU oracle does. All ten original assertions remain. New controls verify live bound/unbound mouse events and macro survival through collecting callbacks, followed by reclamation after completion or errors.

Validated on all 405 recorded runtime/test/build inputs:

- Formatting, compiler, Clippy `-D warnings` and diff checks pass.
- All 542 selected gate tests and 542 release tests pass, including the original GC survival/reclamation contracts.
- All 28 ordinary same-input GNU comparisons pass, with raw outputs, inventories and artifact identities audited.

Complete validation is running on `7e45db47438a39e97658bddaceba903e0e41c186`: [Linux Rust](https://github.com/rayfdj/emaxx/actions/runs/36748039991), [Linux frozen comparison](https://github.com/rayfdj/emaxx/actions/runs/36748047488), and local full macOS Rust. Terminal validation runs after the preceding candidate's PTY run. This PR remains in draft until complete results are audited.

The portable handover preserves both preceding full Rust failures, the exact-binary replay, the missing sibling-path failures, and the earlier stale-build failure. The preceding reader candidate's complete Linux frozen comparison matches 519 files and 7,928 outcomes; that result does not certify this newer macro-state change. GNU on macOS matches source/native ABI but is not the frozen Darwin executable.

This checkpoint does not complete the full runtime goal. Symbol authority, physical allocation accounting, broader reader contracts, the final audit and locked performance parity remain open.
