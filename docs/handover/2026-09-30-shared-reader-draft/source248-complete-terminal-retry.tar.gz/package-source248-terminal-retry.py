from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
audit = read('source248-terminal-retry-audit.json')
assert audit['status']=='passed' and audit['fully_matching_scenarios']==226
assert audit['matching_comparisons']==686 and audit['unexecuted_comparisons']==0
names = [
    'source248-manifest.json', 'source248-ordinary-artifacts.json',
    'source248-full-ttydiff-retry-launch.json', 'source248-full-ttydiff-retry-command.json',
    'source248-full-ttydiff-retry-result.json', 'source248-full-ttydiff-retry.log',
    'source248-full-ttydiff-retry-driver.log', 'source248-terminal-retry-audit.json',
    'run-source248-full-tty-retry.py', 'audit-source248-terminal-retry.py',
    'source248-full-ttydiff-command.json', 'source248-full-ttydiff-result.json',
    'source248-full-ttydiff.log', 'source248-terminal-failure-audit.json',
    'source248-recursive-minibuffer-replay-command.json',
    'source248-recursive-minibuffer-replay-result.json',
    'source248-recursive-minibuffer-replay.log', 'run-source248-recursive-minibuffer-replay.py',
    'source248-current-requirement-review.json',
    'package-source196-failure-and197-results.py', Path(__file__).name,
]
files={name:p/name for name in names}
assert all(path.is_file() for path in files.values())
package('source248-complete-terminal-retry',files,
        dict(terminal=audit,requirement_review=read('source248-current-requirement-review.json'),
             qualification='The unchanged second full source248 terminal run passes all 226 scenarios and 686 comparisons (658 screen, 28 filesystem). Supervisor14540 has exited. All raw verdicts, 472 source inputs and eight execution inputs are checked; original selectors, actions, timeouts and comparison strictness remain. The first GNU startup failure and unchanged selected replay remain distinct preserved results, without a claimed cause. This closes this checkpoint terminal gate, not pinned Darwin or the full architectural/performance objective. Source249 remains isolated and is validating under supervisor15814.'))
