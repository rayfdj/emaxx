from pathlib import Path
import hashlib, json, re, runpy

p = Path(__file__).parent.resolve()
read = lambda name: json.loads((p / name).read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
command = read('source248-full-ttydiff-retry-command.json')
result = read('source248-full-ttydiff-retry-result.json')
original = read('source248-full-ttydiff-command.json')
root = Path(command['working_directory'])
manifest = read(command['source_manifest'])
assert len(manifest) == 472 and all(sha(root / name) == digest for name, digest in manifest.items())
assert len(command['inputs']) == 8
assert all(sha(Path(name)) == digest for name, digest in command['inputs'].items())
for field in ['command', 'working_directory', 'environment_overrides', 'source_manifest', 'inventory']:
    assert command[field] == original[field], field
shared = set(command['inputs']) & set(original['inputs'])
assert len(shared) == 7
assert all(command['inputs'][name] == original['inputs'][name] for name in shared)
assert set(command['inputs']) - shared == {str(p / 'run-source248-full-tty-retry.py')}
assert set(original['inputs']) - shared == {str(p / 'run-source248-full-tty.py')}
assert result['source_unchanged'] and result['inputs_unchanged']
raw = (p / 'source248-full-ttydiff-retry.log').read_text()
module = runpy.run_path(str(root / 'tools/ttydiff.py'), run_name='inventory_only')
scenarios = module['select_scenarios']([])
assert [s[0] for s in scenarios] == command['inventory']
assert len(scenarios) == result['expected_scenarios'] == 226
expected = {}
for scenario in scenarios:
    name, keys = scenario[0], scenario[2]
    labels = []
    final_label, final_filesystem = name, False
    for index, item in enumerate(keys):
        action = module['normalize_action'](item, index)
        if not action.checkpoint:
            continue
        label = f'{name}::{index + 1}:{action.name}'
        if index + 1 == len(keys):
            final_label, final_filesystem = label, action.filesystem
        else:
            labels.append(label)
            if action.filesystem:
                labels.append(label + ' filesystem')
    labels.append(final_label)
    if final_filesystem:
        labels.append(final_label + ' filesystem')
    expected[name] = labels
assert sum(map(len, expected.values())) == 686
starts = list(re.finditer(r'^RUN \[(\d+)/(\d+)\] (.+)$', raw, re.M))
assert len(starts) == result['started_scenarios']
assert [(m[1], m[2], m[3]) for m in starts] == [
    (str(i + 1), '226', s[0]) for i, s in enumerate(scenarios[:len(starts)])]
matches, divergent, partial, successful = [], [], [], []
for index, match in enumerate(starts):
    name = match[3]
    stop = starts[index + 1].start() if index + 1 < len(starts) else len(raw)
    segment = raw[match.end():stop]
    verdicts = re.findall(r'^(MATCH|DIVERGE) \[(.+)\]: (.+)$', segment, re.M)
    labels = [v[1] for v in verdicts]
    assert labels == expected[name][:len(labels)], name
    for kind, label, detail in verdicts:
        if kind == 'MATCH':
            assert re.fullmatch(r'text area identical \(\d+ rows\)|isolated fixture trees identical', detail)
            matches.append(label)
        else:
            assert re.fullmatch(r'\d+ terminal difference\(s\)', detail)
            divergent.append(label)
    if labels == expected[name] and all(v[0] == 'MATCH' for v in verdicts):
        successful.append(name)
    else:
        partial.append(dict(scenario=name, missing=expected[name][len(labels):],
                            raw_tail=segment[-4000:]))
unstarted = [s[0] for s in scenarios[len(starts):]]
unexecuted = sum(len(row['missing']) for row in partial) + sum(len(expected[name]) for name in unstarted)
assert len(matches) + len(divergent) + unexecuted == 686
passed = len(successful) == 226 and len(matches) == 686 and not divergent and not partial and not unstarted
assert (result['exit_code'] == 0) == passed
assert ('PASS: all scenarios match' in raw) == passed
record = dict(status='passed' if passed else 'failed', goal_complete=False,
              inputs_verified=472, execution_inputs_verified=8,
              fully_matching_scenarios=len(successful), matching_comparisons=len(matches),
              matching_screen_comparisons=sum(not label.endswith(' filesystem') for label in matches),
              matching_filesystem_comparisons=sum(label.endswith(' filesystem') for label in matches),
              divergent_labels=divergent, partial_scenarios=partial, unstarted_scenarios=unstarted,
              unexecuted_comparisons=unexecuted, log_sha256=sha(p / 'source248-full-ttydiff-retry.log'),
              ordinary_artifacts=read('source248-ordinary-artifacts.json'),
              qualification='Second complete unchanged source248 terminal run, after the local Rust gate exited. Original commands, seven execution inputs, selectors, actions, timeouts and comparisons are byte-identical; the wrapper is separately hashed. Every observed comparison is checked against the original full inventory. The first GNU startup failure and selected replay remain separate results; this run cannot establish their cause. GNU is source/native-ABI matched, not pinned Darwin. No performance or full-goal completion claim.')
with (p / 'source248-terminal-retry-audit.json').open('x') as f:
    json.dump(record, f, indent=2)
print(json.dumps({key: record[key] for key in ['status', 'fully_matching_scenarios', 'matching_comparisons', 'unexecuted_comparisons', 'divergent_labels']}, indent=2))
