from pathlib import Path
import hashlib,json,subprocess
p=Path(__file__).parent.resolve();repo=p.parents[2]
source=p.parent/'recovered-2026-09-30/bytecode-closure/emaxx'
target=p.parent/'recovered-2026-09-30/string-bytes/emaxx'
base='7903975d26f9ef4ce50d951ae8be655e7024596a'
runtime='092fef676e7667332349b12fd9b63539dd39072b'
paths=['src','tests','Cargo.toml','Cargo.lock','build.rs','.cargo','compat/emacs_compat_runner.el','tools/ttydiff.py','tools/fixtures/fieldnotes.org','tools/fixtures/fake_lsp_server.py']
manifest=json.loads((p/'source216-manifest.json').read_text())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
assert all(sha(source/name)==digest for name,digest in manifest.items())
patch=subprocess.check_output(['git','diff','--binary',runtime,'--',*paths],cwd=source)
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard','--',*paths],cwd=source,text=True).splitlines()
for name in untracked:
    result=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',name],cwd=source,capture_output=True)
    assert result.returncode==1 and not result.stderr
    patch+=result.stdout
patch_path=p/'source216-from-source207.patch'
with patch_path.open('xb') as stream:stream.write(patch)
assert not target.exists()
target.parent.mkdir(parents=True)
subprocess.run(['git','worktree','add','--detach',str(target),base],cwd=repo,check=True)
subprocess.run(['git','apply','--check',str(patch_path)],cwd=target,check=True)
subprocess.run(['git','apply',str(patch_path)],cwd=target,check=True)
(target.parent/'emacs').symlink_to(p.parent/'recovered-2026-09-30/emacs',target_is_directory=True)
assert all(sha(target/name)==digest for name,digest in manifest.items())
assert all(sha(source/name)==digest for name,digest in manifest.items())
record=dict(base_commit=base,runtime_base=runtime,source216_inputs_verified=len(manifest),
            target=str(target),patch_sha256=sha(patch_path),
            qualification='Separate checkout for canonical string-byte work. The running source216 checkout and its helpers remain untouched; this does not certify a new implementation.')
with (p/'string-bytes-checkout-created.json').open('x') as stream:
    json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps(record,indent=2))
