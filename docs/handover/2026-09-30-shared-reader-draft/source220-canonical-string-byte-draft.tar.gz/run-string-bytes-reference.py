from pathlib import Path
import hashlib,json,os,subprocess
p=Path(__file__).parent.resolve();gnu=p.parent/'recovered-2026-09-30/emacs'
sha=lambda file:hashlib.sha256(file.read_bytes()).hexdigest()
fixture=p/'canonical-string-bytes.el'
files=[fixture,gnu/'src/emacs',*sorted((gnu/'src').glob('emacs*.pdmp')),*[gnu/'src'/name for name in ['lisp.h','character.h','alloc.c','data.c','fns.c','bytecode.c']]]
identities={str(file):sha(file) for file in files}
command=[str(gnu/'src/emacs'),'-Q','--batch','-l',str(fixture)]
record=dict(command=command,environment_override={'LANG':'C','LC_ALL':'C'},inputs=identities,
            qualification='Ordinary GNU reference for shared unibyte stores, internal encoding boundaries, error order/data identity and clear-string byte counts/properties. Source/native ABI matched Darwin oracle; not the pinned executable. No Emaxx result is assigned.')
with (p/'canonical-string-bytes-gnu-command.json').open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
result=subprocess.run(command,env={**os.environ,'LANG':'C','LC_ALL':'C'},capture_output=True,timeout=60)
for suffix,data in [('stdout',result.stdout),('stderr',result.stderr)]:
    with (p/('canonical-string-bytes-gnu.'+suffix)).open('xb') as stream:stream.write(data)
record=dict(exit_code=result.returncode,inputs_unchanged=all(sha(Path(file))==digest for file,digest in identities.items()),
            stdout_sha256=hashlib.sha256(result.stdout).hexdigest(),stderr_sha256=hashlib.sha256(result.stderr).hexdigest())
with (p/'canonical-string-bytes-gnu-result.json').open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps(record,indent=2));print(result.stdout.decode());print(result.stderr.decode())
assert result.returncode==0 and not result.stderr and record['inputs_unchanged']
