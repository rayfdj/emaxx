from pathlib import Path
import re
root=Path(__file__).parent.parent/'recovered-2026-09-30/string-bytes/emaxx'

def edit(name,old,new,count=1):
    path=root/name;text=path.read_text()
    assert text.count(old)==count,(name,old,text.count(old),count)
    path.write_text(text.replace(old,new))

edit('src/lisp/reader.rs','''SharedStringState {
                            text: s,
                            props: Vec::new(),
                            multibyte: has_explicit_multibyte || has_invalid_unicode,
                            extended_chars,
                        }''','''SharedStringState::new(
                            s, Vec::new(), has_explicit_multibyte || has_invalid_unicode,
                            extended_chars,
                        )''')
edit('src/lisp/reader.rs','''SharedStringState {
                text,
                props,
                multibyte,
                extended_chars,
            }''','''SharedStringState::new(text, props, multibyte, extended_chars)''')
edit('src/lisp/primitives/strings.rs','''SharedStringState {
        text,
        props: shared_string_props(&props),
        multibyte,
        extended_chars,
    }''','''SharedStringState::new(text, shared_string_props(&props), multibyte, extended_chars)''')
edit('src/lisp/primitives/strings.rs','''SharedStringState {
            text,
            props: shared_string_props(&[]),
            multibyte,
            extended_chars,
        }''','''SharedStringState::new(text, Vec::new(), multibyte, extended_chars)''')
edit('src/lisp/eval.rs','''                let mut inner = state.borrow().clone();
                let copied = crate::lisp::types::string_object_value(
                    crate::lisp::types::SharedStringState {
                        text: std::mem::take(&mut inner.text),
                        props: Vec::new(),
                        multibyte: inner.multibyte,
                        extended_chars: std::mem::take(&mut inner.extended_chars),
                    },
                );''','''                let copied = crate::lisp::types::string_object_value(
                    state.borrow().clone_without_properties(),
                );''')

# These fields belong to SharedStringState, not the transient StringLike view.
for path in (root/'src').rglob('*.rs'):
    if path.name=='string_data.rs':continue
    text=path.read_text();old=text
    text=text.replace('state.borrow().text.clone()', 'state.borrow().text()')
    text=text.replace('state.text.clone()', 'state.text()')
    text=text.replace('state.as_ref().borrow().text', 'state.as_ref().borrow().text()')
    text=text.replace('std::cell::RefCell::borrow(object.as_ref()).text', 'std::cell::RefCell::borrow(object.as_ref()).text()')
    text=text.replace('std::cell::RefCell::borrow(&state).text.clone()', 'std::cell::RefCell::borrow(&state).text()')
    text=text.replace('string.borrow().text.to_string()', 'string.borrow().text()')
    text=text.replace('*text == string.borrow().text', '*text == string.borrow().text()')
    text=text.replace('state.borrow().text.chars()', 'state.borrow().text().chars()')
    text=text.replace('state.borrow().text.as_bytes()', 'state.borrow().text().as_bytes()')
    text=text.replace('state.borrow().text.is_empty()', 'state.borrow().text().is_empty()')
    text=text.replace('state.borrow().text,', 'state.borrow().text(),')
    text=text.replace('state.text,', 'state.text(),')
    text=text.replace('state.extended_chars.clone()', 'state.text_parts().1')
    text=text.replace('state.borrow().multibyte', 'state.borrow().is_multibyte()')
    text=re.sub(r'state\.multibyte\b(?!\s*=)', 'state.is_multibyte()',text)
    if text!=old:path.write_text(text)

edit('src/lisp/types.rs','a.text == b.text && a.extended_chars == b.extended_chars','a.text_parts() == b.text_parts()')
edit('src/lisp/types.rs','b.extended_chars.is_empty() && a.as_str() == b.text','{ let (text, extended) = b.text_parts(); extended.is_empty() && a.as_str() == text }')
edit('src/lisp/types.rs','a.extended_chars.is_empty() && a.text == b.as_str()','{ let (text, extended) = a.text_parts(); extended.is_empty() && text == b.as_str() }')
edit('src/lisp/alloc/vectors/char_tables.rs','string.borrow().text.as_bytes().first()', 'string.borrow().bytes().first()')
edit('src/lisp/primitives/loading.rs','&state.borrow().text,', '&state.borrow().text(),')
edit('src/lisp/primitives/dispatch/strings.rs','result.push_str(&state.text);','result.push_str(&state.text());')

for file in ['src/lisp/primitives/strings.rs','src/lisp/primitives/dispatch/collections.rs','src/lisp/primitives/dispatch/display.rs']:
    path=root/file;text=path.read_text();text=text.replace('state.text.chars().count()', 'state.len()');path.write_text(text)
edit('src/lisp/primitives/values.rs','state.borrow().text().chars().count() as i64','state.borrow().len() as i64')
edit('src/lisp/primitives/dispatch/collections.rs','state.text = std::iter::repeat_n(fill_char, len).collect();','let multibyte = state.is_multibyte();\n                        state.replace_text(std::iter::repeat_n(fill_char, len).collect(), multibyte, Vec::new());')
edit('src/lisp/primitives/dispatch/collections.rs','''                        let len = state.text.len();
                        state.text = "\\0".repeat(len);
                        state.props.clear();
                        state.multibyte = false;''','''                        state.clear();''')
edit('src/lisp/primitives/dispatch/gnutls.rs','''        state.text = "\\0".repeat(state.text.len());
        state.props.clear();
        state.multibyte = false;''','''        state.clear();''')
