from pathlib import Path
root=Path(__file__).parent.parent/'recovered-2026-09-30/string-bytes/emaxx'
def edit(name,old,new,count=1):
    path=root/name;text=path.read_text();assert text.count(old)==count,(name,old,text.count(old));path.write_text(text.replace(old,new))
edit('src/lisp/primitives/dispatch/strings.rs','result.push_str(&state.text);','result.push_str(&state.text());')
for file in ['src/lisp/primitives/strings.rs','src/lisp/primitives/dispatch/collections.rs','src/lisp/primitives/dispatch/display.rs']:
    path=root/file;text=path.read_text();text=text.replace('state.text.chars().count()', 'state.len()');path.write_text(text)
edit('src/lisp/primitives/values.rs','state.borrow().text().chars().count() as i64','state.borrow().len() as i64')
edit('src/lisp/primitives/dispatch/collections.rs','state.text = std::iter::repeat_n(fill_char, len).collect();','let multibyte = state.is_multibyte();\n                        state.replace_text(std::iter::repeat_n(fill_char, len).collect(), multibyte, Vec::new());')
edit('src/lisp/primitives/dispatch/collections.rs','''                        let len = state.text.len();
                        state.text = "\\0".repeat(len);
                        state.props.clear();
                        state.multibyte = false;''','''                        state.clear();''')
edit('src/lisp/primitives/dispatch/gnutls.rs','''        state.text = "\\0".repeat(state.text.len());
        state.props.clear();
        state.multibyte = false;''','''        state.clear();''')
edit('src/lisp/primitives/strings.rs','''            let state = state.borrow();
            Some(StringLike {
                text: state.text(),''','''            let state = state.borrow();
            let (text, extended_chars) = state.text_parts();
            Some(StringLike {
                text,''')
edit('src/lisp/primitives/strings.rs','extended_chars: state.text_parts().1,','extended_chars,')
edit('src/lisp/primitives/strings.rs','''        Kind::StringObject(state) => {
            let state = state.borrow();
            code_in(&state.text(), state.is_multibyte(), &state.extended_chars, index)
        }''','''        Kind::StringObject(state) => state.borrow().character_at(index),''')
edit('src/lisp/primitives/strings.rs','''                Some(f(&state.text(), &state.extended_chars, Some(state.is_multibyte())))''','''                let (text, extended) = state.text_parts();
                Some(f(&text, &extended, Some(state.is_multibyte())))''')

path=root/'src/lisp/primitives/strings.rs';text=path.read_text()
start=text.index('    let code = new_value.as_integer()?;',text.index('pub(crate) fn aset_string_value('))
end=text.index('    let mut string = string_like(target)',start)
text=text[:start]+'''    if let Kind::StringObject(state) = target.kind() {
        let mut state = state.borrow_mut();
        // data.c:Faset checks the existing character index before NEWELT.
        if index >= state.len() {
            drop(state);
            return Err(args_out_of_range_for_aset(target, index));
        }
        let Kind::Integer(code) = new_value.kind() else {
            return Err(LispError::WrongTypeArgument("characterp".into(), *new_value));
        };
        if !(0..=0x3f_ffff).contains(&code) {
            return Err(LispError::WrongTypeArgument("characterp".into(), *new_value));
        }
        if !state.store_character(index, code as u32) {
            drop(state);
            return Err(LispError::SignalValue(Value::list([
                Value::symbol("args-out-of-range"), *target, *new_value,
            ])));
        }
        return Ok(*target);
    }
    let code = new_value.as_integer()?;
'''+text[end:]
old='''    if let Kind::StringObject(state) = target.kind() {
        let mut state = state.borrow_mut();
        state.text = string.text;
        state.props = shared_string_props(&string.props);
        state.multibyte = string.multibyte;
        return Ok(*target);
    }
'''
assert text.count(old)==1;text=text.replace(old,'');path.write_text(text)
