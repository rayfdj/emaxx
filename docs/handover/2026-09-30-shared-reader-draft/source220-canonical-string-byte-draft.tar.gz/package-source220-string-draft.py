from pathlib import Path
import ast,gzip,hashlib,io,json,re,tarfile
p=Path(__file__).parent.resolve();root=p.parents[2]
out=root/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda name:json.loads((p/name).read_text())
tree=ast.parse((p/'package-source196-failure-and197-results.py').read_text())
node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
candidate=p.parent/'recovered-2026-09-30/string-bytes/emaxx'
manifest=read('source220-manifest.json')
assert len(manifest)==421 and all(sha((candidate/name).read_bytes())==digest for name,digest in manifest.items())
assert read('source217-check-result.json')['exit_code']==101
assert read('source218-check-result.json')['exit_code']==0
assert read('source219-clippy-result.json')['exit_code']==101
assert not (p/'source219-gate-controls-result.json').exists()
for stage in ['check','fmt','clippy','diff']:
    result=read('source220-'+stage+'-result.json')
    assert result['exit_code']==0 and result['source_unchanged']
    raw=(p/('source220-'+stage+'.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:',raw,re.M)
    if stage in ['fmt','diff']:assert not raw
assert read('canonical-string-bytes-gnu-result.json')['exit_code']==0
assert read('canonical-string-bytes-gnu-result.json')['inputs_unchanged']
assert not (p/'canonical-string-bytes-gnu.stderr').read_bytes()
assert (candidate/'tests/fixtures/canonical-string-bytes.el').read_bytes()==(p/'canonical-string-bytes.el').read_bytes()
assert (candidate/'tests/fixtures/canonical-string-bytes.expected').read_bytes()==(p/'canonical-string-bytes-gnu.stdout').read_bytes()+b'\n'
allowed={'.json','.log','.txt','.py','.patch','.stdout','.stderr','.el','.expected'}
files={f.name:f for f in p.iterdir() if f.is_file() and f.suffix in allowed and f.name.startswith(('source217-','source218-','source219-','canonical-string-bytes-'))}
names=['source220-base.json','source220-manifest.json','source220-complete.patch','source220-validation-launch.json',
       'run-source220-validation.py','run-source219-validation.py','source216-from-source207.patch','create-string-bytes-checkout.py',
       'string-bytes-checkout-created.json','implement-source217-string-consumers.py','implement-source217-string-consumers-rest.py',
       'audit-source217-through220-patches.py','freeze-string-candidate.py','check-string217.py','static-string217.py',
       'test-string-controls219.py','test-string-broad219.py','canonical-string-bytes.el','run-string-bytes-reference.py',Path(__file__).name]
for stage in ['check','fmt','clippy','diff']:
    names+=['source220-'+stage+suffix for suffix in ['-command.json','-result.json','.log']]
files.update({name:p/name for name in names})
package('source220-canonical-string-byte-draft',files,dict(status='isolated canonical-byte draft; runtime validation running',
    source_inputs=421,strict_checks='passed with zero warnings',supervisor=read('source220-validation-launch.json')['pid'],
    qualification='Actual GNU-encoded shared-string payload replaces retained Rust text and extended-character side storage. Direct reads/stores/conversion/image bytes are implemented, with ordinary GNU reference and two new controls. Source217 has twelve compiler errors; source218 compiles; source219 compiles but fails three strict test unwrap lints and runs no runtime tests; source220 corrects those diagnostics. This archive contains no source220 runtime verdict. Direct VM dispatch, immutable/plain string migration, compact header/native layout, physical accounting and complete correctness/performance remain open. No draft runtime is applied to the task branch.'))
