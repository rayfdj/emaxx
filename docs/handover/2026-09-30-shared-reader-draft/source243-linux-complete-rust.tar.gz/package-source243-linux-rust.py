from pathlib import Path
import ast, gzip, hashlib, io, json, re, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
read = lambda name: json.loads((p / name).read_text())
audit = read('source243-linux-rust-complete-audit.json')
names = read('source243-linux-rust-name-audit.json')
assert audit['status'] == names['status'] == 'passed'
assert audit['total_passed'] == 3105 and audit['library_ignored'] == 2
assert names['raw_names_verified'] == 3004 and audit['retained_files_verified'] == 4
state = read('source243-linux-rust-final-state.json')
assert state['status'] == 'completed' and state['conclusion'] == 'success'
step = [line for line in (p / 'source243-linux-rust-ci.log').read_text().splitlines()
        if '\tBuild current runner and check Rust formatting and lint\t' in line]
assert len(step) == 12 and not any(re.search(r'\bwarning(?:\[|:)', line) for line in step)
launch = read('source243-linux-gnu-census-launch.json')
assert launch['run_id'] == 36825694384 and launch['source_commit'] == '3a35ad00ed62c3a1b1f717f347f0f67bd8817890'
allowed = {'.json', '.log', '.txt', '.py', '.patch'}
patterns = ['source243-linux-rust-*', 'source243-linux-gnu-census-*',
            'source243-census-original-pass-audit.json', 'source243-manifest.json',
            'source243-complete.patch', 'source243-macos-continuation-*',
            'audit-source243-linux-rust-names.py', 'verify-source243-linux-rust.py',
            'download-source243-linux-rust.py', 'launch-source243-gnu-census-linux.py',
            'commit-source243-macos-continuation.py', Path(__file__).name]
files = {str(file.relative_to(p)): file for pattern in patterns for file in p.glob(pattern)
         if file.is_file() and file.suffix in allowed}
files.update({str(file.relative_to(p)): file for file in (p / 'source243-linux-rust-artifacts').rglob('*')
              if file.is_file() and file.suffix in allowed})
package('source243-linux-complete-rust', files,
        dict(linux=audit, raw_names=names, diagnosis_launch=launch,
             qualification='Run36822371375 closes the complete source243 Linux Rust gate on exact 8d4fcd39: 3,105 passes, two existing ignores, native artifact identity and all 3,004 raw library names/verdicts verified. Four executable/image copies are locally retained and hashed. CI formatting and strict Clippy/build complete without compiler warnings. The original census control and both original suspended/thread-root contracts pass; fixture, expectation and oracle/helper bodies are unchanged from failed source238. This current-source pass does not identify the earlier GNU census variation\'s cause. Bounded diagnosis36825694384 is dispatched on 3a35ad00 with the same 462 runtime inputs; no diagnostic verdict is inferred. GNU executable/image identity was not retained in the complete Rust job; the diagnosis explicitly retains it. Complete frozen and terminal results, final pinned Darwin, performance and full-goal requirements remain open.'))
