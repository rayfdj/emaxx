from pathlib import Path
import hashlib, io, json, subprocess, tarfile
p = Path(__file__).parent.resolve()
root = p.parents[2]
sha = lambda data: hashlib.sha256(data).hexdigest()
def output(args):
    return subprocess.check_output(args, cwd=root, text=True).strip()
def save(name, data):
    with (p / name).open('x') as f:
        json.dump(data, f, indent=2)
assert output(['git', 'branch', '--show-current']) == 'runtime-char-tables'
assert output(['git', 'rev-parse', 'HEAD']) == '04a7ce6d035ddccf22b4d2ce991db57c637ec647'
assert not output(['git', 'diff', '--cached', '--name-only'])
manifest = json.loads((p / 'source243-manifest.json').read_text())
assert len(manifest) == 462 and all(sha((root / name).read_bytes()) == digest for name, digest in manifest.items())
paths = ['HANDOVER.md', 'docs/runtime-representation-progress.md', 'docs/runtime-representation-correctness-recovery-draft.md', 'tools/diagnose_gnu_census.py', '.github/workflows/frozen-run.yml']
stems = ['source243-complete-macos']
for stem in stems:
    prefix = 'docs/handover/2026-09-30-shared-reader-draft/' + stem
    paths += [prefix + '-manifest.json', prefix + '.tar.gz']
    record = json.loads((root / (prefix + '-manifest.json')).read_text())
    archive = root / (prefix + '.tar.gz')
    assert sha(archive.read_bytes()) == record['archive']['sha256']
    with tarfile.open(archive) as t:
        assert t.getnames() == [entry['path'] for entry in record['files']]
        for entry in record['files']:
            data = t.extractfile(entry['path']).read()
            assert sha(data) == entry['sha256'] and len(data) == entry['bytes']
subprocess.run(['git', 'diff', '--check'], cwd=root, check=True)
subprocess.run(['git', 'add', '--', *paths], cwd=root, check=True)
assert set(output(['git', 'diff', '--cached', '--name-only']).splitlines()) == set(paths)
subprocess.run(['git', 'diff', '--cached', '--check'], cwd=root, check=True)
tree = output(['git', 'write-tree'])
data = subprocess.check_output(['git', 'archive', tree, '--', *sorted(manifest)], cwd=root)
with tarfile.open(fileobj=io.BytesIO(data)) as t:
    assert all(sha(t.extractfile(name).read()) == digest for name, digest in manifest.items())
subprocess.run(['git', '-c', 'user.name=Ray', '-c', 'user.email=26018378+rayfdj@users.noreply.github.com',
                'commit', '-m', 'Add GNU census diagnosis and record complete macOS validation'], cwd=root, check=True)
head = output(['git', 'rev-parse', 'HEAD'])
assert output(['git', 'rev-parse', 'HEAD^{tree}']) == tree
assert not output(['git', 'status', '--porcelain'])
save('source243-macos-continuation-commit.json', dict(commit=head, runtime='8d4fcd39fafcac4d7f69987714164129a769e094',
     unchanged_runtime_inputs=462, paths=paths, macos_passed=3093, existing_ignores=2, gnu_only_helper_smoke_passed=9, goal_complete=False))
command = ['git', 'push', 'origin', 'HEAD:refs/heads/runtime-char-tables']
result = subprocess.run(command, cwd=root, stdin=subprocess.DEVNULL, capture_output=True, text=True)
save('source243-macos-continuation-push.json', dict(command=command, exit_code=result.returncode, stdout=result.stdout, stderr=result.stderr))
result.check_returncode()
remote = output(['git', 'ls-remote', '--heads', 'origin', 'refs/heads/runtime-char-tables'])
assert remote.split()[0] == head
save('source243-macos-continuation-remote.json', dict(commit=head, raw=remote))
print(json.dumps(dict(commit=head, status='source243 complete macOS evidence and bounded GNU census diagnostic pushed; task runtime remains source243; main unchanged')))
