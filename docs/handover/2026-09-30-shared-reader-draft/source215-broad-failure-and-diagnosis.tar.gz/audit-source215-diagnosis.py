from pathlib import Path
import ast, hashlib, json, re

p = Path(__file__).parent.resolve()
root = p.parent/'recovered-2026-09-30/bytecode-closure/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda name: json.loads((p/name).read_text())
tree = ast.parse((p/'audit-shared-reader196-fresh-selected.py').read_text())
node = next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='audit_log')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<raw-auditor>','exec'))
command = read('source215-locale-replay-command.json')
result = read('source215-locale-replay-result.json')
assert result['exit_code']==0 and result['source_unchanged'] and result['inputs_unchanged']
assert command['environment_override']['LANG']==command['environment_override']['LC_ALL']=='C'
assert not audit_log(command['selected_inventory'],(p/'source215-locale-replay.log').read_text(),5,0)
fixture = read('source215-constructor-fixtures-result.json')
assert fixture['exit_code']==0 and fixture['empty_stderr'] and fixture['source_unchanged'] and fixture['inputs_unchanged']
assert not fixture['expected_output']
expected = b'((t t nil nil) ((error "Invalid byte-code object") (error "Invalid byte-code object") (error "Invalid byte-code object") (error "Invalid byte-code object")) 42 (t t) (#("Original" 0 1 (field shared)) shared))'
assert (p/'source215-constructor-fixtures.stdout').read_bytes()==expected
assert all(sha(Path(f))==digest for f,digest in read('source215-constructor-fixtures-command.json')['inputs'].items())
manifest=read('source215-manifest.json')
assert all(sha(root/name)==digest for name,digest in manifest.items())
record=dict(locale_replay='five passed, unchanged source and assertions',
            invalid_constructor_cases=4,valid_original_contracts='increment, repeated identity, shared text/property mutation',
            original_wrapper='failed: expected string print omitted its newly installed text property; raw GNU output and failed expectation preserved',
            verified_actual_output=expected.decode(),inputs_verified=418,
            qualification='Separate controlled replay establishes the helper locale omission. GNU rejects all three legacy unit-test constructor inputs and the unibyte/list-vector variant; proper unibyte strings and ordinary vectors preserve the original call/identity/mutation contracts. No runtime constructor relaxation is justified. Active-call mutation remains failed; no complete validation or performance claim.')
with (p/'source215-broad-diagnosis-audit.json').open('x') as stream:
    json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps(record,indent=2))
