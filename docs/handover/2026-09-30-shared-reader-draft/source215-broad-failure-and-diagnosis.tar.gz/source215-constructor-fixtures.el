(let* ((increment-code (string #x89 #x54 #x87))
       (return-code (string #x87))
       (increment-bytes (unibyte-string #x89 #x54 #x87))
       (return-bytes (unibyte-string #x87))
       (invalid
        (mapcar
         (lambda (fields)
           (condition-case err (apply #'make-byte-code fields)
             (error err)))
         (list (list 257 increment-code '(vector-literal) 3)
               (list 257 return-code [] 1)
               (list 257 return-code '(vector-literal) 1)
               (list 257 return-bytes '(vector-literal) 1))))
       (increment (make-byte-code 257 increment-bytes [] 3))
       (identity (make-byte-code 257 return-bytes [] 1))
       (argument (copy-sequence "original")))
  (prin1
   (list (list (multibyte-string-p increment-code)
               (multibyte-string-p return-code)
               (multibyte-string-p increment-bytes)
               (multibyte-string-p return-bytes))
         invalid
         (funcall increment 41)
         (list (eq (funcall identity argument) argument)
               (eq (funcall identity argument) argument))
         (progn
           (put-text-property 0 1 'field 'shared (funcall identity argument))
           (aset (funcall identity argument) 0 ?O)
           (list argument (get-text-property 0 'field argument))))))
