from pathlib import Path
import ast, hashlib, json, re, shutil

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/bytecode-closure/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read('source215-manifest.json')
assert len(manifest) == 418 and all(sha(root/name) == digest for name,digest in manifest.items())
tree = ast.parse((p/'audit-shared-reader196-fresh-selected.py').read_text())
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'audit_log')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<raw-auditor>', 'exec'))
command = read('source215-gate-broad-command.json')
result = read('source215-gate-broad-result.json')
assert result['exit_code'] == 101 and result['source_unchanged']
binary = p/'source215-gate-libtest'
assert sha(binary) == command['binary_sha256']
inventory = [line[:-6] for line in (p/'source215-gate-inventory.txt').read_text().splitlines() if line.endswith(': test')]
expected = [name for name in inventory if name.startswith(('lisp::bytecode::','lisp::native_comp::runtime::','lisp::primitives::pdumper::','lisp::primitives::tests::'))]
assert len(expected) == 848 and command['selected_inventory'] == expected
failed = audit_log(expected, (p/'source215-gate-broad.log').read_text(), 839, 9)
retained = p/'source215-broad-retained-inputs'
retained.mkdir()
files = []
for source in [binary, *sorted((p/'fixture-images-source215').glob('*.pdmp'))]:
    digest = sha(source)
    target = retained/source.name
    shutil.copy2(source,target)
    assert sha(target) == sha(source) == digest
    files.append(dict(original=str(source), retained=str(target), sha256=digest, bytes=target.stat().st_size))
record = dict(status='failed', passed=839, failed=9, ignored=0, inputs_verified=418,
              failing_names=failed, inventory_verified=848, retained_files=files,
              raw_hashes={name:sha(p/name) for name in ['source215-gate-broad.log','source215-gate-broad-command.json','source215-gate-broad-result.json','source215-validation-result.json']},
              qualification='Original broader draft run, with all raw names/verdicts checked. Five failures occur at the GNU expected-output check before testing Emaxx; the helper omitted the ordinary grouped gate LANG=C/LC_ALL=C settings, requiring a separate controlled replay. Three bytecode unit fixtures supply multibyte code strings and two also supply obsolete list-form vector literals; validity must be checked against GNU before repair. The active-call code mutation failure remains a runtime defect. Retained image is a post-run file, not a per-test use transcript. No complete validation or performance claim.')
with (p/'source215-broad-failure-audit.json').open('x') as stream:
    json.dump(record,stream,indent=2); stream.write('\n')
print(json.dumps(record,indent=2))
