from pathlib import Path
import ast, hashlib, json, os, re, subprocess, time

p = Path(__file__).parent.resolve()
root = p.parent/'recovered-2026-09-30/bytecode-closure/emaxx'
gnu = p.parent/'recovered-2026-09-30/emacs'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda name: json.loads((p/name).read_text())
manifest = read('source215-manifest.json')
def unchanged():
    return all(sha(root/name) == digest for name,digest in manifest.items())
def save(name,data):
    with (p/name).open('x') as stream:
        json.dump(data,stream,indent=2); stream.write('\n')

prior = read('source215-gate-broad-command.json')
binary = p/'source215-gate-libtest'
assert sha(binary) == prior['binary_sha256'] and unchanged()
env = {**prior['environment_override'], 'LANG':'C', 'LC_ALL':'C'}
failures = read('source215-broad-failure-audit.json')['failing_names']
names = [name for name in failures if name.rsplit('::',1)[1] in [
    'char_charset_family_follows_charset_c',
    'char_charset_restriction_narrows_to_charset_list_or_coding_system',
    'commandp_follows_fcommandp_order_and_property_error',
    'defvaralias_follows_eval_c',
    'quoting_style_reaches_message_error_text_and_display_table']]
assert len(names) == 5
inputs = [binary, gnu/'src/emacs', *sorted((gnu/'src').glob('emacs-*.pdmp'))]
identities = {str(f):sha(f) for f in inputs}
command = [str(binary),*names,'--exact','--nocapture','--test-threads=1']
save('source215-locale-replay-command.json',dict(command=command,working_directory=str(root),
     environment_override=env,selected_inventory=names,inputs=identities,
     qualification='Separate controlled replay using the unchanged ordinary grouped gate locale. The original nine-failure run remains failed. No source or expected-output change.'))
start = time.monotonic()
with (p/'source215-locale-replay.log').open('x') as stream:
    completed = subprocess.run(command,cwd=root,env={**os.environ,**env},stdout=stream,stderr=subprocess.STDOUT,timeout=600)
result = dict(exit_code=completed.returncode,elapsed_seconds=time.monotonic()-start,
              source_unchanged=unchanged(),inputs_unchanged=all(sha(Path(f))==digest for f,digest in identities.items()))
save('source215-locale-replay-result.json',result)
print('locale replay',result,flush=True)

fixture = p/'source215-constructor-fixtures.el'
command = [str(gnu/'src/emacs'),'-Q','--batch','-l',str(fixture)]
save('source215-constructor-fixtures-command.json',dict(command=command,working_directory=str(root),
     environment_override={'LANG':'C','LC_ALL':'C'},inputs={**identities,str(fixture):sha(fixture)}))
result = subprocess.run(command,cwd=root,env={**os.environ,'LANG':'C','LC_ALL':'C'},capture_output=True,timeout=60)
for suffix,data in [('stdout',result.stdout),('stderr',result.stderr)]:
    with (p/('source215-constructor-fixtures.'+suffix)).open('xb') as stream:stream.write(data)
expected = b'((t t nil nil) ((error "Invalid byte-code object") (error "Invalid byte-code object") (error "Invalid byte-code object") (error "Invalid byte-code object")) 42 (t t) ("Original" shared))'
record = dict(exit_code=result.returncode,expected_output=result.stdout==expected,empty_stderr=not result.stderr,
              source_unchanged=unchanged(),inputs_unchanged=all(sha(Path(f))==digest for f,digest in identities.items()),
              stdout_sha256=hashlib.sha256(result.stdout).hexdigest(),stderr_sha256=hashlib.sha256(result.stderr).hexdigest(),expected=expected.decode())
save('source215-constructor-fixtures-result.json',record)
print('GNU fixtures',record,flush=True)
assert result.returncode == 0 and record['expected_output'] and record['empty_stderr'] and record['source_unchanged'] and record['inputs_unchanged']
tree = ast.parse((p/'audit-shared-reader196-fresh-selected.py').read_text())
node = next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='audit_log')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<raw-auditor>','exec'))
assert completed.returncode == 0
assert not audit_log(names,(p/'source215-locale-replay.log').read_text(),5,0)
save('source215-broad-diagnosis-audit.json',dict(locale_replay='five passed, unchanged source and assertions',
     invalid_constructor_cases=4,valid_original_contracts='increment, repeated identity, shared text/property mutation',
     source_unchanged=unchanged(),qualification='The old failed broad run is preserved. These controls establish the helper locale omission and invalid legacy constructor fixtures. They do not repair active-call mutation or certify broader draft correctness.'))
