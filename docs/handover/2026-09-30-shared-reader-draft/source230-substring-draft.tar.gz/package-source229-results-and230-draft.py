from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve();root=p.parents[2];out=root/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest();read=lambda name:json.loads((p/name).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
selected=read('source229-results-audit.json');ordinary=read('source229-ordinary-audit.json');failure=read('source229-full-rust-failure-audit.json');substring=read('source229-substring-baseline-audit.json')
assert [(g['passed'],g['failed']) for g in selected['groups']]==[(26,0),(934,0),(26,0),(934,0)]
assert len(ordinary['fixtures'])==50 and failure['passed']==680 and failure['failed']==1
allowed={'.json','.log','.txt','.py','.patch','.stdout','.stderr','.el','.expected','.dat'}
files={f.name:f for f in p.iterdir() if f.is_file() and f.suffix in allowed and f.name.startswith('source229-') and not f.name.startswith(('source229-full-tty','source229-quote-state'))}
full=p/'full-gate-source229'
files.update({str(f.relative_to(p)):f for f in full.rglob('*') if f.is_file() and f.suffix in allowed})
names=['source229-full-tty-launch.json','source229-full-ttydiff-command.json','audit-source229-results.py','audit-source229-ordinary.py','audit-source229-full-rust-failure.py','audit-source229-patches.py','audit-shared-reader196-fresh-selected.py','run-string-validation229.py','test-string-controls229.py','test-string-broad219.py','check-string217.py','static-string217.py','run-source229-release.py','run-source229-build-and-ordinary.py','build-string225.py','run-source229-ordinary.py','compare-source229-fixtures.py','run-source229-full-gate.py','run-source229-full-tty.py','source207-ordinary-comparisons-command.json','substring-character-storage.el','substring-argument-validation.el','substring-reversed-bounds.el','quoted-bytecode-reader-closure.el',Path(__file__).name]
files.update({name:p/name for name in names})
package('source229-selected-and-rust-failure',files,dict(selected=selected,ordinary=ordinary,complete_rust_failure=failure,substring_negative_baseline=substring,
    qualification='All selected and ordinary checkpoint results pass, while the complete Rust run remains failed and three additional ordinary substring controls retain mismatches including a host abort. The unchanged quoted-bytecode form matches GNU fields and execution; the failing Rust assertion requires removed host-record storage. Complete terminal comparison is still active and has a help-text screen divergence; its active log/results are not packaged. No new runtime is published and no source229 Linux, pinned Darwin or performance claim is made.'))
manifest=read('source230-manifest.json');candidate=p.parent/'recovered-2026-09-30/string-ops/emaxx'
assert len(manifest)==440 and all(sha((candidate/name).read_bytes())==digest for name,digest in manifest.items())
names=['source230-base.json','source230-manifest.json','source230-complete.patch','source230-launch.json','source230-patch-replay-and-modes-audit.json','string-ops-checkout-created.json','freeze-string-ops-candidate.py','audit-source230-patches.py','check-string230.py','static-string230.py','test-string-controls230.py','test-string-broad230.py','run-string-validation230.py',Path(__file__).name]
for stage in ['check','fmt','clippy','diff']:
    result=read('source230-'+stage+'-result.json');assert result['exit_code']==0 and result['source_unchanged']
    names+=['source230-'+stage+suffix for suffix in ['-command.json','-result.json','.log']]
package('source230-substring-draft',{name:p/name for name in names},dict(status='strict checks pass; focused and affected-module gate validation running',source_inputs=440,supervisor=read('source230-launch.json')['pid'],
    qualification='Separate worktree copies canonical substring bytes and vector fields, validates both GNU index types before joint range checks, shares the canonical substring path with completion, and updates the old quoted-bytecode internal-record assertion with actual closure fields/execution confirmed by ordinary GNU. The three unchanged failing substring fixtures become permanent controls. No runtime, release, full-platform or performance pass is assigned. Source229 remains frozen for its complete terminal run.'))
