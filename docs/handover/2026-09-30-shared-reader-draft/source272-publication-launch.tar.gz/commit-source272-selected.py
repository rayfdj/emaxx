from pathlib import Path
import hashlib,json,subprocess
p=Path(__file__).parent.resolve();root=p.parents[2]
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
read=lambda n:json.loads((p/n).read_text())
manifest=read('source272-manifest.json')
assert all(sha(root/n)==h for n,h in manifest.items())
assert read('source272-borrow-selected-audit.json')['status']=='passed'
review=read('source272-applied-review.json')
assert review['status']=='validated source272 applied; ready for commit'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='0c58c4d43bd52f1ac455abd2a8e845c8523dda6c'
assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()=='runtime-char-tables'
files=review['runtime_files']+review['documentation_files']+review['archives']
assert len(files)==len(set(files))==13
assert subprocess.check_output(['git','diff','--binary'],cwd=root)==(p/'source272-applied-review.patch').read_bytes()
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root,text=True).strip()
subprocess.run(['git','add','--',*files],cwd=root,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root,text=True).splitlines())==set(files)
subprocess.run(['git','diff','--cached','--check'],cwd=root,check=True)
command=['git','-c','user.name=Ray','-c','user.email=26018378+rayfdj@users.noreply.github.com','commit','-m','Trace string borrow roots before garbage collection']
result=subprocess.run(command,cwd=root,stdin=subprocess.DEVNULL,capture_output=True,text=True)
with (p/'source272-commit-command.json').open('x') as f:
    json.dump(dict(command=command,exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr,helper_sha256=sha(Path(__file__))),f,indent=2)
result.check_returncode()
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
assert all(sha(root/n)==h for n,h in manifest.items())
with (p/'source272-applied-commit.json').open('x') as f:
    json.dump(dict(commit=commit,branch='runtime-char-tables',source_inputs_verified=510,files=files,goal_complete=False),f,indent=2)
command=['git','push','origin','HEAD:refs/heads/runtime-char-tables']
result=subprocess.run(command,cwd=root,stdin=subprocess.DEVNULL,capture_output=True,text=True)
with (p/'source272-applied-push.json').open('x') as f:
    json.dump(dict(commit=commit,command=command,exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr),f,indent=2)
result.check_returncode()
remote=subprocess.check_output(['git','ls-remote','--heads','origin','refs/heads/runtime-char-tables'],cwd=root,text=True).split()[0]
assert remote==commit
with (p/'source272-published-head.json').open('x') as f:
    json.dump(dict(commit=commit,remote_branch_head=remote,goal_complete=False,qualification='Validated source272 and preserved negative/selected/full-Rust evidence are published to the authorized task branch. Main is unchanged; source272 full validation remains separate.'),f,indent=2)
print(json.dumps(dict(commit=commit,remote_branch_head=remote),indent=2))
