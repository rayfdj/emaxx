from pathlib import Path
import ast,gzip,hashlib,io,json,subprocess,tarfile,time
p=Path(__file__).parent.resolve();root=p.parents[2]
out=root/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda n:json.loads((p/n).read_text())
commit=read('source272-applied-commit.json')['commit']
assert commit=='eb286e230b414fc753b37b4008566950b98fc867'
manifest=read('source272-manifest.json')
assert all(sha((root/n).read_bytes())==h for n,h in manifest.items())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==commit
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
assert read('source272-applied-push.json')['exit_code']==0
macos=read('source272-full-launch.json');state=read('source272-full-queue-state.json')
assert macos['validation_commit']==state['candidate_commit']==commit
assert state['status']=='waiting for the existing source270 full macOS supervisor' and 'error' not in state
processes=subprocess.check_output(['ps','-p',str(macos['pid'])+','+str(state['preceding_full_pid']),'-o','pid,etime,command'],text=True)
assert 'queue-source272-full-macos.py' in processes and 'queue-source270-full-macos.py' in processes
with (p/'source272-full-queue-at-publication.json').open('x') as f:json.dump(dict(snapshot=state,processes=processes),f,indent=2)
launches={mode:read('source272-linux-'+mode+'-launch.json') for mode in ['rust','frozen']}
ci={}
for mode,launch in launches.items():
    current=json.loads(subprocess.check_output(['gh','run','view',str(launch['run_id']),'--repo','rayfdj/emaxx','--json','status,conclusion,headSha,url']))
    assert current['headSha']==launch['source_commit']==commit
    ci[mode]=current
with (p/'source272-ci-at-publication.json').open('x') as f:json.dump(ci,f,indent=2)
pr=json.loads(subprocess.check_output(['gh','pr','view','79','--repo','rayfdj/emaxx','--json','isDraft,baseRefName,headRefName,url']))
assert pr['isDraft'] and pr['baseRefName']=='main' and pr['headRefName']=='runtime-char-tables'

node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
names=[
    'source272-applied-review.json','source272-applied-review.patch','source272-commit-command.json',
    'source272-applied-commit.json','source272-applied-push.json','source272-published-head.json',
    'source272-full-checkout-command.json','source272-full-checkout.json','source272-full-launch.json',
    'source272-full-queue-at-publication.json','source272-ci-at-publication.json','source272-full-validation-preparation.json',
    'source272-linux-rust-dispatch.json','source272-linux-rust-launch.json','source272-linux-frozen-dispatch.json','source272-linux-frozen-launch.json',
    'source272-manifest.json','source272-borrow-selected-audit.json',
    'apply-source272-selected.py','commit-source272-selected.py','prepare-source272-full-validation.py',
    'audit-source272-selected-for-full.py','setup-source272-full-macos.py','queue-source272-full-macos.py',
    'dispatch-source272-linux.py','package-source196-failure-and197-results.py',Path(__file__).name,
]
package('source272-publication-launch',{n:p/n for n in names},dict(
    runtime_commit=commit,macos_launch=macos,macos_state=state['status'],linux=ci,
    qualification='Validated source272 was committed and pushed with its unchanged negative and complete selected evidence. Full Linux Rust/frozen runs target exact eb286e23. macOS supervisor27731 has a clean exact-commit checkout and waits for the existing source270 full supervisor3079; it has not started full test stages. These launch records infer no outcome. Main and every unfinished goal requirement remain unchanged.'))

handover=root/'HANDOVER.md';text=handover.read_text()
text=text.replace('The task runtime is **source272**, with **510 verified inputs**.', 'The task runtime is **source272**, pushed as **`eb286e23`**, with **510 verified inputs**.',1)
text=text.replace('the preceding test-only negative replay all 510 bytes/modes exactly.', 'the preceding test-only negative replay all 510 inputs and file modes exactly.',1)
old='''Full source272 validation is prepared but not yet launched at this checkpoint:
`setup-source272-full-macos.py` requires the published commit and waits for the
existing source270 full supervisor before starting complete Rust, frozen and
terminal stages; `dispatch-source272-linux.py` uses the existing Rust/frozen CI.'''
new='''The [full-validation launch receipts](docs/handover/2026-09-30-shared-reader-draft/source272-publication-launch-manifest.json)
record macOS supervisor **27731** in the clean exact-commit checkout
`target/runtime-goal/recovered-2026-09-30/string-borrow-full/emaxx`, waiting for
source270 supervisor **3079** to finish before full Rust, frozen and terminal
validation. Linux [Rust36937044662](https://github.com/rayfdj/emaxx/actions/runs/36937044662)
and [frozen36937049816](https://github.com/rayfdj/emaxx/actions/runs/36937049816)
are dispatched on exact `eb286e23`. Read `source272-full-*` and the exact CI runs
for live state; keep both source272 checkouts unchanged.'''
assert text.count(old)==1;handover.write_text(text.replace(old,new))
progress=root/'docs/runtime-representation-progress.md';text=progress.read_text()
text=text.replace('The current runtime is **source272**, with 510 verified inputs and','The current runtime is **source272** (`eb286e23`), with 510 verified inputs and',1)
old='Full source272 validation is prepared, not yet launched at this checkpoint.'
new='''The [full-validation launches](handover/2026-09-30-shared-reader-draft/source272-publication-launch-manifest.json)
target exact `eb286e23`: macOS supervisor27731 waits for the existing source270
full run; Linux Rust36937044662/frozen36937049816 are dispatched. No full
source272 outcome is inferred. Read HANDOVER.md and the retained live receipts.'''
assert text.count(old)==1;progress.write_text(text.replace(old,new))
recovery=root/'docs/runtime-representation-correctness-recovery-draft.md';text=recovery.read_text()
old='Full source272 validation is prepared but not launched at this checkpoint.'
new='''The [source272 full-validation launches](handover/2026-09-30-shared-reader-draft/source272-publication-launch-manifest.json)
target pushed `eb286e23`: Linux Rust/frozen are dispatched and macOS is queued
behind the existing source270 full run. Launch does not establish a result.'''
assert text.count(old)==1;recovery.write_text(text.replace(old,new))
subprocess.run(['git','diff','--check'],cwd=root,check=True)
files=['HANDOVER.md','docs/runtime-representation-progress.md','docs/runtime-representation-correctness-recovery-draft.md',
       'docs/handover/2026-09-30-shared-reader-draft/source272-publication-launch.tar.gz',
       'docs/handover/2026-09-30-shared-reader-draft/source272-publication-launch-manifest.json']
subprocess.run(['git','add','--',*files],cwd=root,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root,text=True).splitlines())==set(files)
command=['git','-c','user.name=Ray','-c','user.email=26018378+rayfdj@users.noreply.github.com','commit','-m','Record string borrow repair publication and full validation']
result=subprocess.run(command,cwd=root,capture_output=True,text=True)
with (p/'source272-publication-docs-commit-command.json').open('x') as f:json.dump(dict(command=command,exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr),f,indent=2)
result.check_returncode()
docs_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
command=['git','push','origin','HEAD:refs/heads/runtime-char-tables']
result=subprocess.run(command,cwd=root,capture_output=True,text=True)
with (p/'source272-publication-docs-push.json').open('x') as f:json.dump(dict(command=command,commit=docs_commit,exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr),f,indent=2)
result.check_returncode()

body=f'''This draft removes duplicate Lisp payloads and lossy string conversions across the interpreter, bytecode VM and native execution. The applied runtime is source272 (`{commit}`, 510 verified inputs). Strings share canonical GNU bytes and allocation, identity, mutation and comparison behavior in the recorded cases. A live Rust string borrow now retains its property graph through collection; previously an off-stack guard kept the header but lost a cons property. The original failing diagnostic remains archived and passes unchanged after the repair.

Lisp values remain one word, cons payloads two words, and bytecode executes from its live code string. Strings use a direct 32-byte header plus 16 bytes of borrow/allocator metadata, dedicated cells and packed property spans. Normal empty forms are canonical; pure copies preserve GNU identity/write protection and dump restoration behavior. Ordering, version comparison, range validation and casing follow GNU C and live tables. The separate plain-string arena, binding/callback copies and VM text adapter are removed. Collection traces shared Rust guards before weak-table processing and rejects exclusive guards before starting an epoch or sweeping. The extra GC scan and temporary vectors have not been timed.

Audited source272 validation:

- Formatting, all-target/all-feature checking, strict Clippy and diff checks pass with zero warnings.
- Both profiles pass 206 focused controls with the two existing ignores, and all 1,062 affected controls. Every original test, selector and GNU fixture/expected byte remains. Complete inventories and retained executable/image identities are verified.
- New controls verify property survival, weak-key retention, reclamation after release and exclusive-borrow rejection, including both empty roots. The unchanged source271 negative and both repair patches reproduce all 510 inputs and modes.

Full source272 validation targets exact `eb286e23`: [Linux Rust36937044662]({ci['rust']['url']}) and [Linux frozen36937049816]({ci['frozen']['url']}) are dispatched. A clean macOS checkout is queued behind the preceding full run, then executes complete Rust, frozen and terminal validation. No source272 full result is inferred from launch.

The preceding source270 has audited full Rust results: 3,118 macOS / 3,130 Linux passes, two existing ignores each, all raw names, native artifact identity and retained inputs. Its 33 standalone GNU comparisons match unchanged output, including all 12,600 prefix rows and the recorded ordering/range/casing/empty/pure negatives. Those cases overlap and are not summed. Source270 frozen/terminal runs are separate. Earlier source261 results retain Linux frozen 519 files/7,928 matches, macOS frozen 7,915 matches/six strict build-feature skip-diagnostic differences, and terminal 226 scenarios/686 matches. Historical results do not certify later source; capability reports and comparison rules remain unchanged.

GNU was rebuilt from pristine `636f166c` using the recorded Apple-libxml2 recipe. Darwin explicitly adopts executable `29cfb20d…`; the old pin and every failed draft/probe remain archived. Regenerated native/C manifests and fresh canonical discovery match the recorded contract. Actual executable, dump, configuration and Makefile are retained.

The full goal remains incomplete: data sblocks and real intervals, symbol authority and remaining host-text consumers, physical accounting and real counters, broader public ownership/serialization, VM stack/profiling, final-source validation/adversarial review, and all sixteen locked workloads with the unchanged 3% ceiling. No current memory saving, speedup or GNU performance parity is claimed. Main remains `21d20f0e`; this PR stays draft. [HANDOVER.md](https://github.com/rayfdj/emaxx/blob/runtime-char-tables/HANDOVER.md) links the complete requirements, closed evidence and continuation.
'''
bodyfile=p/'pr79-body-source272.txt'
with bodyfile.open('x') as f:f.write(body)
command=['gh','pr','edit','79','--repo','rayfdj/emaxx','--title','Share compact Lisp storage across execution modes','--body-file',str(bodyfile)]
result=subprocess.run(command,cwd=root,capture_output=True,text=True)
with (p/'source272-pr-update.json').open('x') as f:json.dump(dict(command=command,exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr,body_sha256=sha(bodyfile.read_bytes())),f,indent=2)
result.check_returncode()
for attempt in range(10):
    pr=json.loads(subprocess.check_output(['gh','pr','view','79','--repo','rayfdj/emaxx','--json','headRefOid,isDraft,baseRefName,headRefName,url,title,body']))
    if pr['headRefOid']==docs_commit:break
    time.sleep(2)
assert pr['headRefOid']==docs_commit and pr['isDraft'] and pr['baseRefName']=='main' and pr['headRefName']=='runtime-char-tables'
assert pr['body'].strip()==body.strip()
refs=dict(line.split()[::-1] for line in subprocess.check_output(['git','ls-remote','--heads','origin','refs/heads/main','refs/heads/runtime-char-tables'],cwd=root,text=True).splitlines())
assert refs['refs/heads/main']=='21d20f0eec08f3c013d5d3eb3bd6e9cfc16b3199' and refs['refs/heads/runtime-char-tables']==docs_commit
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
assert all(sha((root/n).read_bytes())==h for n,h in manifest.items())
record=dict(runtime_commit=commit,documentation_commit=docs_commit,remote_refs=refs,pr=pr,macos_launch=macos,linux=ci,source_inputs_verified=510,goal_complete=False)
with (p/'source272-publication.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps({k:record[k] for k in ['runtime_commit','documentation_commit','remote_refs','source_inputs_verified']},indent=2))
