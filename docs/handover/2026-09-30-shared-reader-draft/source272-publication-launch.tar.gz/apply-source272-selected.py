from pathlib import Path
import hashlib,json,subprocess
p=Path(__file__).parent.resolve();root=p.parents[2]
candidate=p.parent/'recovered-2026-09-30/string-borrow-roots/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
read=lambda n:json.loads((p/n).read_text())
before=read('source270-manifest.json');after=read('source272-manifest.json')
assert read('source272-borrow-selected-audit.json')['status']=='passed'
assert read('source272-borrow-patch-replay-audit.json')['status']=='exact'
assert all(sha(root/n)==h for n,h in before.items()) and all(sha(candidate/n)==h for n,h in after.items())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='0c58c4d43bd52f1ac455abd2a8e845c8523dda6c'
assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()=='runtime-char-tables'
assert not subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).strip()
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root,text=True).strip()
archive_dir='docs/handover/2026-09-30-shared-reader-draft/'
archives=[archive_dir+stem+suffix for stem in ['source270-complete-rust-platforms','source272-string-borrow-selected'] for suffix in ['.tar.gz','-manifest.json']]
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines()
assert set(untracked)==set(archives),untracked
for stem in ['source270-complete-rust-platforms','source272-string-borrow-selected']:
    receipt=json.loads((root/(archive_dir+stem+'-manifest.json')).read_text())
    file=root/archive_dir/receipt['archive']['path']
    assert sha(file)==receipt['archive']['sha256'] and file.stat().st_size==receipt['archive']['bytes']
patch=p/'source272-portable-incremental.patch'
assert sha(patch)==read('source272-freeze.json')['patches']['portable-incremental']['sha256']
subprocess.run(['git','apply','--check',str(patch)],cwd=root,check=True)
subprocess.run(['git','apply',str(patch)],cwd=root,check=True)
assert all(sha(root/n)==h for n,h in after.items())

handover=root/'HANDOVER.md'
text=handover.read_text()
needle='## Current correctness recovery\n\nThe task runtime is **source270**, pushed as **`0ecf6e11`**, with **510 verified\ninputs**.'
assert text.count(needle)==1
prefix='''## Current correctness recovery

The task runtime is **source272**, with **510 verified inputs**. Its
[closed borrow-root repair evidence](docs/handover/2026-09-30-shared-reader-draft/source272-string-borrow-selected-manifest.json)
verifies zero-warning strict checks, **206 focused passes / two existing ignores**
and **1,062 affected passes in each profile**. Every original selector, test,
GNU fixture and expected byte is preserved. Both portable repair patches and
the preceding test-only negative replay all 510 bytes/modes exactly.

Source271 exposed a Rust ownership defect outside the frozen Lisp fixtures:
an off-stack shared string guard kept its header alive while its cons property
was reclaimed. Its original **two passes / one failure** remains preserved.
Source272 scans the existing borrow metadata before marking, traces shared
guards through the ordinary property graph and weak-table fixed point, and
rejects an exclusive guard before advancing the epoch or sweeping anything.
Controls verify survival, weak-key retention, reclamation after release and
exclusive-borrow rejection, including both permanent empty roots. No per-access
lookup or retained registry is added. The extra GC scan and temporary vectors
have not been timed; broader public ownership/serialization remains open.

The selected checkout `target/runtime-goal/recovered-2026-09-30/string-borrow-roots/emaxx`
is frozen. Receipts/helpers are under `target/runtime-goal/resume-2026-09-28`.
Full source272 validation is prepared but not yet launched at this checkpoint:
`setup-source272-full-macos.py` requires the published commit and waits for the
existing source270 full supervisor before starting complete Rust, frozen and
terminal stages; `dispatch-source272-linux.py` uses the existing Rust/frozen CI.
No full source272 result, standalone GNU comparison or performance claim follows
from these selected checks. Main remains `21d20f0e`, PR79 remains draft, and the
full architectural/performance goal is active and incomplete.

## Preceding storage checkpoint: source270

The preceding storage runtime **source270** was pushed as **`0ecf6e11`**, with
**510 verified inputs**.'''
text=text.replace(needle,prefix)
old='''Full macOS supervisor **3079** runs in the clean exact-commit checkout
`target/runtime-goal/recovered-2026-09-30/string-storage-full/emaxx`. It has completed
selected re-audit, idle-cache cloning and GNU artifact capture, and now runs the
full Rust gate before frozen and terminal validation. Linux
[Rust 36930970705](https://github.com/rayfdj/emaxx/actions/runs/36930970705) and
[frozen36930977055](https://github.com/rayfdj/emaxx/actions/runs/36930977055) are dispatched
on exact `0ecf6e11`. Read `source270-full-*` and the exact Linux runs for live state.
Keep both source270 checkouts unchanged. No full-run result, memory saving, speedup
or GNU performance parity is inferred. Main remains `21d20f0e`; PR79 stays draft.'''
new='''The [complete Rust audits on both platforms](docs/handover/2026-09-30-shared-reader-draft/source270-complete-rust-platforms-manifest.json)
verify **3,118 macOS / 3,130 Linux passes**, with **two existing ignores each**,
all 3,021/3,029 library names, native artifact identity and retained Rust/GNU inputs.
Linux [Rust36930970705](https://github.com/rayfdj/emaxx/actions/runs/36930970705)
is complete on exact `0ecf6e11`. Full macOS supervisor **3079** continues frozen
then terminal validation in the clean checkout
`target/runtime-goal/recovered-2026-09-30/string-storage-full/emaxx`; Linux
[frozen36930977055](https://github.com/rayfdj/emaxx/actions/runs/36930977055) remains
separate. Read `source270-full-*` and the exact run for live state. Keep both
source270 checkouts unchanged. Rust passes do not close the separately exposed
borrow-root defect or certify source272, frozen/terminal, memory or performance.'''
assert text.count(old)==1
handover.write_text(text.replace(old,new))

progress=root/'docs/runtime-representation-progress.md'
text=progress.read_text()
heading='# Current goal status — 2 October 2026\n\n'
assert text.startswith(heading)
text=text.replace('The task runtime is **source270**, pushed as **`0ecf6e11`**, with **510 verified inputs**.', 'The preceding storage runtime **source270** was pushed as **`0ecf6e11`**, with **510 verified inputs**.',1)
text=text.replace('Full results are pending.', 'Its complete Rust results are now closed: **3,118 macOS / 3,130 Linux passes**,\nwith two existing ignores each; frozen/terminal outcomes remain separate.',1)
addition='''The current runtime is **source272**, with 510 verified inputs and
[closed borrow-root repair evidence](handover/2026-09-30-shared-reader-draft/source272-string-borrow-selected-manifest.json):
zero-warning strict checks, **206 focused passes / two existing ignores** and
**1,062 affected passes in each profile**, retaining all original tests/fixtures.
An unchanged source271 diagnostic first showed a live off-stack Rust string
guard losing its property child. Source272 roots shared guards before the
weak-table fixed point and rejects exclusive guards before any mark/sweep work.
Survival and reclamation controls pass; the original negative is retained.
The GC scan's cost remains unmeasured, and broader public ownership is unfinished.
Full source272 validation is prepared, not yet launched at this checkpoint.

The [closed source270 full Rust audits](handover/2026-09-30-shared-reader-draft/source270-complete-rust-platforms-manifest.json)
verify 3,118 macOS / 3,130 Linux passes, two existing ignores each, all raw library
names and retained inputs. Frozen/terminal are separate. Main remains 21d20f0e,
PR79 is draft, and the full goal—including sblocks, actual intervals, symbol
authority, physical accounting, VM profiling and the locked 16-workload 3% ceiling—
remains active. [HANDOVER.md](../HANDOVER.md) contains the current continuation.

## Historical storage checkpoint: source270

'''
progress.write_text(heading+addition+text[len(heading):])

common=root/'docs/runtime-representation-common-strings-draft.md'
text=common.read_text()
old='''The full goal is active and incomplete. The task runtime is now source261, pushed
as `eddfe782`, with 488 inputs and [closed selected validation](handover/2026-09-30-shared-reader-draft/source261-common-string-selected-manifest.json).
The earlier separately packaged drafts and failures remain historical evidence.'''
new='''The full goal is active and incomplete. The current task runtime is source272,
with 510 inputs and [closed borrow-root repair validation](handover/2026-09-30-shared-reader-draft/source272-string-borrow-selected-manifest.json).
It retains source270's direct string header/storage fixes and repairs off-stack
Rust borrow tracing; broader ownership, sblocks and actual intervals remain open.
The source256/source261 development record below preserves its original failures
and bounded results. Use HANDOVER.md for current execution/publication state.'''
assert text.count(old)==1;common.write_text(text.replace(old,new))

recovery=root/'docs/runtime-representation-correctness-recovery-draft.md'
text=recovery.read_text();needle='## Verified recovery\n'
assert text.count(needle)==1
addition='''## Current checkpoint: source272

The [borrow-root repair](handover/2026-09-30-shared-reader-draft/source272-string-borrow-selected-manifest.json)
passes 206 focused controls and 1,062 affected controls in each profile, retaining
two existing ignores and every original test/fixture. The preserved source271
negative shows an off-stack Rust string guard retaining its header but losing a
cons property. The repair traces that root before weak tables/sweeping and rejects
exclusive guards before starting an epoch. New controls verify survival and
reclamation. This host-ownership case was outside the earlier frozen fixtures;
passing those fixtures did not establish it. Broader public ownership remains open.

The preceding source270 [complete Rust audits](handover/2026-09-30-shared-reader-draft/source270-complete-rust-platforms-manifest.json)
close 3,118 macOS / 3,130 Linux passes with two existing ignores each, all raw names,
native identity and retained inputs. Its frozen/terminal runs remain separate.
Full source272 validation is prepared but not launched at this checkpoint.
Read [HANDOVER.md](../HANDOVER.md) for live continuation state. All historical
failures below remain failures; no performance parity or final completion is claimed.

'''
recovery.write_text(text.replace(needle,addition+needle))

shared=root/'docs/runtime-representation-shared-reader-draft.md'
text=shared.read_text();heading='# Shared command reader draft — 30 September 2026\n\n'
assert text.startswith(heading)
shared.write_text(heading+'This is the historical reader/allocator development record. Read\n[HANDOVER.md](../HANDOVER.md) and the [requirement map](runtime-representation-progress.md)\nfor the current source272 runtime and validation state. Earlier running/pending\nlabels below describe their original checkpoints, not the current task branch.\n\n'+text[len(heading):])

subprocess.run(['git','diff','--check'],cwd=root,check=True)
changed=[n for n in after if after[n]!=before[n]]
docs=['HANDOVER.md','docs/runtime-representation-progress.md','docs/runtime-representation-common-strings-draft.md','docs/runtime-representation-correctness-recovery-draft.md','docs/runtime-representation-shared-reader-draft.md']
assert set(subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines())==set(changed+docs)
with (p/'source272-applied-review.patch').open('xb') as f:f.write(subprocess.check_output(['git','diff','--binary'],cwd=root))
record=dict(status='validated source272 applied; ready for commit',runtime_files=changed,documentation_files=docs,archives=archives,source_inputs_verified=510,goal_complete=False)
with (p/'source272-applied-review.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(record,indent=2))
