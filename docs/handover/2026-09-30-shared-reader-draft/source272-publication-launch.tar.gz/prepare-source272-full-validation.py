from pathlib import Path
import ast,hashlib,json
p=Path(__file__).parent.resolve()
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()

auditor=(p/'audit-source272-borrow-selected.py').read_text()
auditor=auditor.replace("assert all(sha(root/n)==h for n,h in baseline.items())", "full_root=Path(read('source272-full-checkout.json')['candidate'])\nassert all(sha(full_root/n)==h for n,h in manifest.items())")
auditor=auditor.replace("(p/'source272-borrow-selected-audit.json').open('x')", "(p/'source272-full-selected-audit.json').open('x')")
with (p/'audit-source272-selected-for-full.py').open('x') as f:f.write(auditor)

queue=(p/'queue-source270-full-macos.py').read_text().replace('source270','source272')
queue=queue.replace('string-storage/emaxx','string-borrow-roots/emaxx').replace('target/string-storage-validation','target/string-borrow-validation')
queue=queue.replace('source272-validation-launch.json','source272-selected-launch.json').replace('queue-string-storage270-validation.py','queue-source272-borrow-selected.py')
queue=queue.replace('source272-validation-result.json','source272-selected-result.json')
queue=queue.replace("prior['status'] == 'selected processes finished; raw evidence requires audit'", "prior['status'] == 'selected processes finished; final raw audit required'")
queue=queue.replace("len(prior['stages']) == 8", "len(prior['stages']) == 6")
queue=queue.replace(" and row['prior_source_unchanged']",'').replace(" and row['helper_unchanged']",'')
queue=queue.replace('source272-selected-audit.json','source272-full-selected-audit.json')
queue=queue.replace("selected['status'] == 'passed' and selected['ordinary_comparisons'] == 33", "selected['status'] == 'passed' and selected['diagnostic_controls'] == 5")
queue=queue.replace("row['focused_passes'] == 203 and row['affected_passes'] == 1059", "row['focused_passes'] == 206 and row['affected_passes'] == 1062")
needle="    assert run('selected-audit'"
at=queue.index(needle)
queue=queue[:at]+"""    preceding = json.loads((p / 'source270-full-launch.json').read_text())
    preceding_pid = str(preceding['pid'])
    state.update(status='waiting for the existing source270 full macOS supervisor', preceding_full_pid=int(preceding_pid))
    save_state()
    while True:
        process = subprocess.run(['ps', '-p', preceding_pid, '-o', 'command='], capture_output=True, text=True)
        if process.returncode == 1 and not process.stdout.strip():
            break
        assert process.returncode == 0 and 'queue-source270-full-macos.py' in process.stdout
        verify_inputs()
        time.sleep(5)
    assert (p / 'source270-full-queue-result.json').is_file(), 'Preceding outcomes must be retained, including any failure'
"""+queue[at:]
with (p/'queue-source272-full-macos.py').open('x') as f:f.write(queue)

setup=(p/'setup-source270-full-macos.py').read_text().replace('source270','source272').replace('string-storage-full/emaxx','string-borrow-full/emaxx')
setup=setup.replace('source272-selected-audit.json','source272-borrow-selected-audit.json')
with (p/'setup-source272-full-macos.py').open('x') as f:f.write(setup)

dispatch=(p/'dispatch-source270-linux.py').read_text().replace('source270','source272')
start=dispatch.index("                qualification='")
end=dispatch.index("')\n    save",start)
dispatch=dispatch[:start]+"                qualification='Exact pushed source272 string-borrow root repair:510 inputs, zero-warning strict checks,206 focused passes/two existing ignores and1062 affected passes in each profile. The original off-stack property-root failure is preserved and now passes alongside weak-table/reclamation/exclusive-borrow controls. Source270 complete Rust results are separate:macOS3118/Linux3130 passes with two existing ignores. Source270 frozen/terminal runs remain separate; no full source272 result or performance/ownership completion is inferred from dispatch."+dispatch[end:]
with (p/'dispatch-source272-linux.py').open('x') as f:f.write(dispatch)
helpers=['audit-source272-selected-for-full.py','queue-source272-full-macos.py','setup-source272-full-macos.py','dispatch-source272-linux.py']
for name in helpers:ast.parse((p/name).read_text())
with (p/'source272-full-validation-preparation.json').open('x') as f:
    json.dump(dict(status='prepared, not launched',helpers={n:sha(p/n) for n in helpers},goal_complete=False,
                   qualification='Requires successful closed source272 selected results and validated publication. Full macOS uses a clean exact-commit checkout, re-verifies all source/selected inputs and waits for existing source270 full validation to exit before cloning the idle selected272 cache. Complete Rust,519 frozen files,226 terminal scenarios and final GNU verification are unchanged. Linux uses the existing exact-commit Rust/frozen workflow. No source272 full run has yet started.'),f,indent=2)
print('Prepared full source272 validation; not launched.')
