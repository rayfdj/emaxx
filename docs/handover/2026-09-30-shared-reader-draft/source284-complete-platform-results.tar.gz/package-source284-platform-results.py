from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile
p=Path(__file__).parent.resolve();out=p/'source286-publication-stage'
sha=lambda data:hashlib.sha256(data).hexdigest()
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
previous=json.loads((out/'source284-closed-platform-validation-manifest.json').read_text())
frozen=Path(json.loads((p/'source284-macos-frozen-audit.json').read_text())['raw_root'])
files={};excluded=[]
for item in previous['files']:
    name=item['path']
    if name.startswith('macos-frozen/tools/'):
        excluded.append(item);continue
    original=frozen/name.removeprefix('macos-frozen/') if name.startswith('macos-frozen/') else p/name
    assert sha(original.read_bytes())==item['sha256']
    files[name]=original
assert excluded and all(Path(r['path']).name in ('cargo','rustc','rustdoc','rust-analyzer') for r in excluded)
files[Path(__file__).name]=Path(__file__)
scope=dict(previous['scope'],packaging_correction=dict(previous_local_archive=previous['archive'],excluded_host_tools=excluded,
           reason='The first local package included unchanged host tool executables despite its binary-exclusion label. It remains locally retained but is not published. This successor retains their exact identities and all raw comparison evidence, excluding those executables. No test evidence or verdict changed.'))
package('source284-complete-platform-results',files,scope)
