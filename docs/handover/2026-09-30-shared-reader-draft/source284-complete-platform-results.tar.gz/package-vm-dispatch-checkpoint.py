from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile
p=Path(__file__).parent.resolve(); root=p.parents[2]
out=p/'source286-publication-stage';out.mkdir(exist_ok=True)
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda n:json.loads((p/n).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
allowed={'.json','.log','.txt','.py','.patch','.stdout','.stderr','.el','.expected','.h'}
assert read('source286-selected-audit.json')['status']=='passed'
assert read('source287-selected-audit.json')['status']=='passed'
assert read('source286-applied-push.json')['exit_code']==0
assert read('vm-dispatch-performance-audit.json')['status']=='all 288 processes and actual results/modes verified'
files={}
for f in p.iterdir():
    if not f.is_file() or f.suffix not in allowed:continue
    if f.name.startswith(('source285-','source286-','source287-')) and not any(s in f.name for s in ('-full-','-linux-','-call-profile')):
        files[f.name]=f
    if f.suffix=='.py' and any(s in f.name for s in ('source285','source286','source287','vm-dispatch')):
        files[f.name]=f
for name in ('package-source196-failure-and197-results.py','printer-varied-v3-293638f0.el','printer-varied-v3-gnu.stdout','vm-dispatch-audit-helper-correction.json'):
    files[name]=p/name
scope=dict(status='selected VM checkpoint applied and pushed',selected=read('source286-selected-audit.json'),
           corrected_baseline=read('source287-selected-audit.json'),applied=read('source286-applied-commit.json'),
           qualification='522 inputs and modes replay from source284 and main.118 selected controls in each profile and43 ordinary GNU comparisons pass. No prior test/fixture removed. Original malformed vector fixture, baseline remainder mismatch, strict Clippy failure, EOF audit pattern error and baseline image helper/environment failures remain. Source287 corrects only remainder operands; source286 additionally removes repeated hot-op decoding. Full final-source validation and goal acceptance remain open.',goal_complete=False)
package('source286-vm-dispatch-selected',files,scope)
files={}
for tag in ('source284','source287','source286'):
    for directory in sorted(p.glob(tag+'-vm-comparison-pilot-*')):
        for f in directory.rglob('*'):
            if f.is_file():files[str(f.relative_to(p))]=f
    directory=p/(tag+'-core-native')
    for f in directory.rglob('*'):
        if f.is_file() and f.suffix in allowed:files[str(f.relative_to(p))]=f
for f in (p/'source286-call-profiles').rglob('*'):
    if f.is_file() and f.suffix in allowed:files[str(f.relative_to(p))]=f
for f in p.iterdir():
    if f.is_file() and f.suffix in allowed and (f.name.startswith('vm-dispatch-performance-') or f.name in ('measure-vm-dispatch-pilots.py','measure-vm-dispatch-pilots-v2.py','audit-vm-dispatch-performance.py','profile-source286-calls.py','source286-call-profile-result.json',Path(__file__).name)):
        files[f.name]=f
package('source286-vm-dispatch-performance',files,dict(status='all288 pilot processes and results/modes verified; diagnostic',audit=read('vm-dispatch-performance-audit.json'),profiles=read('source286-call-profile-result.json'),
        qualification='Three rotated repetitions of unchanged16-case pilot across original284, corrected287 and optimized286. Retains every favorable and unfavorable sample. The original benchmark preflight KeyError ran no process; its corrected helper uses the original separate measurement-input manifest. No runtime, workload, timeout, expected answer or tolerance changed to fit timings. Real allocation counters and calibrated nine-round performance criterion remain unsatisfied. Profiles are separate from timing.',goal_complete=False))
files={}
for f in p.iterdir():
    if f.is_file() and f.suffix in allowed and (f.name.startswith(('source284-full-','source284-macos-','source284-linux-frozen-','source284-org-fold-')) or f.name in ('audit-source284-linux-frozen.py','audit-source284-macos-frozen.py','audit-source284-macos-terminal.py','audit-source284-macos-rust-names.py','verify-source284-macos-rust.py','retry-source284-org-fold-bounded.py','verify-complete-frozen-receipts279.py','source284-manifest.json',Path(__file__).name)):
        files[f.name]=f
for directory in (p/'full-gate-source284',p/'source284-full-retained-gnu',p/'source284-linux-frozen-artifacts'):
    for f in directory.rglob('*'):
        if f.is_file() and (f.suffix in allowed or f.name=='Makefile'):files[str(f.relative_to(p))]=f
frozen=Path(read('source284-macos-frozen-audit.json')['raw_root'])
for f in frozen.rglob('*'):
    if f.is_file():files['macos-frozen/'+str(f.relative_to(frozen))]=f
retry=read('source284-org-fold-bounded-result.json')
assert retry['exit_code']==0 and not retry['timed_out'] and retry['inputs_unchanged']
log=(p/'source284-org-fold-bounded.log').read_text()
assert 'MATCH [org-fold]: text area identical' in log and 'PASS: all scenarios match' in log and 'DIVERGE' not in log
package('source284-closed-platform-validation',files,dict(status='closed predecessor evidence with explicit failures',
        macos_rust=read('source284-macos-rust-verification.json'),macos_frozen=read('source284-macos-frozen-audit.json'),
        macos_terminal=read('source284-macos-terminal-audit.json'),gnu_terminal_retry=retry,
        linux_frozen=read('source284-linux-frozen-raw-integrity-audit.json'),
        qualification='Source284:3130 macOS Rust passes/two existing ignores, all7928 Linux frozen outcomes match, macOS7915 matches/six existing strict diagnostic differences. Original terminal run has8 matching scenarios/comparisons and678 unexecuted comparisons after GNU org-fold startup failure. Separate unchanged org-fold retry gets the actual equal screen under180-second readiness/300-second overall bounds, without replacing the failed full run. Linux Rust2284 passes/one GNU reference census failure is preserved in its earlier separate archive. These results do not certify source286.',goal_complete=False))
