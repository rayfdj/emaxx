from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys,time
p=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28')
root=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/macro-saved-state/emaxx')
tag='source'+sys.argv[1]
profile=sys.argv[2]
manifest=json.loads((p/(tag+'-manifest.json')).read_text())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def unchanged():return all(sha(root/name)==value for name,value in manifest.items())
def save(suffix,data):
    with (p/(tag+'-'+suffix+'.json')).open('x') as stream:json.dump(data,stream,indent=2);stream.write('\n')
env={'CARGO_TARGET_DIR':'/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/macro-saved-state/emaxx/target/frame-validation','CARGO_BUILD_JOBS':'1',
     'RUST_MIN_STACK':'134217728','RUST_TEST_THREADS':'1','EMAXX_GC_VERIFY':'1','EMAXX_IMAGE_TEMPLATE':'1',
     'EMAXX_FIXTURE_IMAGE_DIR':str(p/('fixture-images-'+tag)),
     'EMAXX_GNU_SOURCE_DIRECTORY':'/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/emacs',
     'EMAXX_DUMP_SOURCE_DIRECTORY':'/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/emacs',
     'EMACS_TEST_DIRECTORY':'/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/emacs/test'}
def run(stage,command,extra=None):
    assert unchanged()
    save(stage+'-command',{'command':command,'working_directory':str(root),'environment_override':env,**(extra or {})})
    start=time.monotonic()
    with (p/(tag+'-'+stage+'.log')).open('x') as log:
        result=subprocess.run(command,cwd=root,env={**os.environ,**env},stdout=log,stderr=subprocess.STDOUT,timeout=3600)
    record={'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,'source_unchanged':unchanged()}
    save(stage+'-result',record)
    print(stage,json.dumps(record),flush=True)
    return result.returncode or (0 if record['source_unchanged'] else 2)
code=run(profile+'-build',['cargo','test','--locked','--all-features','--profile',profile,'--lib','--no-run','--message-format=json-render-diagnostics'])
if code:sys.exit(code)
artifacts=[]
for line in (p/(tag+'-'+profile+'-build.log')).read_text().splitlines():
    try:item=json.loads(line)
    except json.JSONDecodeError:continue
    if item.get('reason')=='compiler-artifact' and item.get('profile',{}).get('test') and item.get('executable'):artifacts.append(item['executable'])
assert len(artifacts)==1
binary=p/(tag+'-'+profile+'-libtest');assert not binary.exists();shutil.copy2(artifacts[0],binary)
listed=subprocess.run([str(binary),'--list','--format','terse'],cwd=root,env={**os.environ,**env},capture_output=True,text=True,check=True)
(p/(tag+'-'+profile+'-inventory.txt')).write_text(listed.stdout)
inventory=[line[:-6] for line in listed.stdout.splitlines() if line.endswith(': test')]
filters=['kbd_macro', 'keyboard_macro', 'tty::tests::', 'minibuffer', 'input_decode', 'read_key', 'read_char', 'read_event', 'key_binding', 'keymap', 'arity', 'argument', 'backtrace', 'callee', 'call_function', 'source_call', 'autoload', 'special_form', 'eval_list', 'lexical', 'circular', 'dotted', 'thread', 'suspended_bytecode', 'native_unwind', 'lisp::runtime::', 'unwind_protect', 'function_cells', 'compute_motion', 'vertical_motion', 'posn', 'window', 'pdumper', 'keyboard_input', 'lisp::eval::roots::']
selected=[name for name in inventory if any(part in name for part in filters)]
assert selected and len(selected)==len(set(selected))
for required in ['threads_retain_lexical_caller_roots_across_separate_callee_environments','suspended_bytecode_retains_operand_and_unwind_roots']:
    assert any(name.endswith('::'+required) for name in selected)
focus_names=['lisp::primitives::tests::native_keyboard_input_family_matches_gnu_kboard_contracts', 'lisp::primitives::tests::input_decode_down_events_follow_live_bindings_without_bootstrap_fallbacks', 'lisp::primitives::tests::input_decode_macro_roots_survive_callbacks_then_release_completed_arrays']
assert all(name in selected for name in focus_names)
code=run(profile+'-focused',[str(binary),*focus_names,'--exact','--nocapture','--test-threads=1'],{'binary_sha256':sha(binary),'selected_inventory':focus_names})
if code:sys.exit(code)
code=run(profile+'-selected',[str(binary),*filters,'--nocapture','--test-threads=1'],{'binary_sha256':sha(binary),'selected_inventory':selected})
text=(p/(tag+'-'+profile+'-selected.log')).read_text()
match=re.search(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
if not code:
    assert match and match[1]=='ok' and int(match[2])==len(selected) and int(match[3])==int(match[4])==0
save(profile+'-selected-inventory-check',{'expected':len(selected),'summary':match.group(0) if match else None,'binary_unchanged':sha(binary),'process_exit_code':code})
print(text[-5000:],flush=True)
sys.exit(code)
