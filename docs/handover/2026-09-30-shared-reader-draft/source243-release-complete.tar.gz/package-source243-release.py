from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
out = p.parents[2] / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
read = lambda name: json.loads((p / name).read_text())
audit = read('source243-release-audit.json')
assert [row['passed'] for row in audit['groups']] == [165, 948]
assert all(stage['exit_code'] == 0 for stage in read('source243-release-and-ordinary-result.json'))
allowed = {'.json', '.log', '.txt', '.py'}
patterns = ['source243-release-*', 'source243-manifest.json', 'source243-gate-inventory.txt',
            'source243-gate-controls-command.json', 'source243-gate-broad-command.json',
            'audit-source243-release.py', 'audit-source238-release.py',
            'test-source243-controls.py', 'test-source243-broad.py',
            'run-source243-release-and-ordinary.py', 'source243-ordinary-audit.json',
            'source243-new-ordinary-audit.json', 'audit-source243-macos-names.py',
            'verify-source243-macos-rust.py', Path(__file__).name]
files = {str(file.relative_to(p)): file for pattern in patterns for file in p.glob(pattern)
         if file.is_file() and file.suffix in allowed}
package('source243-release-complete', files,
        dict(release=audit,
             qualification='Release supervisor55868 has exited. Source243 passes the same 165 focused controls with two existing ignores and all 948 affected controls in both profiles. Exact release executable/image copies and hashes are retained locally; every raw name and verdict is checked. All 65 ordinary comparisons are separately audited. Complete macOS55867, full terminal55869 and exact-commit Linux jobs remain active. Prepared complete-Mac auditors are included but have not executed. Main and all remaining full-goal requirements are unchanged.'))
