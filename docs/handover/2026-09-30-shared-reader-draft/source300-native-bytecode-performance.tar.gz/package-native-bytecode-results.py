from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
out = p.parents[2] / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected', '.h'}
selected = read('source300-selected-audit.json')
performance = read('native-bytecode-performance-audit.json')
decision = read('source300-application-decision.json')
assert selected['status'] == 'passed' and selected['source_inputs_verified'] == 532
assert selected['ordinary_comparisons'] == 47
assert all(x['passed'] == 327 and x['failed'] == x['ignored'] == 0 for x in selected['profiles'].values())
assert performance['status'] == 'all 192 processes and actual results/modes verified'
assert read('native-bytecode-performance-sequence-closed-result.json')['status'] == 'timing audited; source decision pending'
for audit in [selected, performance]:
    assert all(sha(Path(n).read_bytes()) == h for n, h in audit['evidence_files'].items())
helpers = [
    'prepare-native-bytecode299.py', 'prepare-native-bytecode300.py', 'finish-prepare-native-bytecode300.py',
    'prepare-native-bytecode-evidence300.py', 'run-source299-validation.py', 'run-source300-validation.py',
    'audit-native-bytecode-selected.py', 'compare-source300-generated-loaded.py',
    'compare-source297-generated-loaded.py', 'compare-source292-generated-loaded.py',
    'compare-vm-dispatch-fixtures.py', 'compare-buffer-line-broad-probe.py',
    'native_fixed_validation_support.py', 'verify-existing-portable-draft.py',
    'replay-native-bytecode300.py', 'finish-native-bytecode-selected-closed.py',
    'source297-gate-inventory.log', 'source297-release-inventory.log', 'source297-manifest.json',
    'source297-selected-audit.json', 'source297-full-validation-launch.json',
    'printer-varied-v3-293638f0.el', 'printer-varied-v3-gnu.stdout',
    'package-source196-failure-and197-results.py', Path(__file__).name,
]
files = {f.name: f for f in p.iterdir() if f.is_file() and f.suffix in allowed
         and f.name.startswith(('source299-', 'source300-', 'native-bytecode-selection-'))}
files.update({name: p / name for name in helpers})
package('source300-native-bytecode-selected', files, dict(
    status='closed fresh selected validation for source300',
    audit=dict(path='source300-selected-audit.json', sha256=sha((p / 'source300-selected-audit.json').read_bytes())),
    profiles={k: {f: v[f] for f in ['passed', 'failed', 'ignored']} for k, v in selected['profiles'].items()},
    source_inputs_verified=532, ordinary_comparisons=47,
    qualification='All532 input bytes/modes replay exactly. Fresh gate/release/ordinary builds and327 selected passes per profile verify. All original tests/assertions/fixtures/selectors are unchanged.47 actual GNU comparisons pass; the entire broad probe retains60 original column-width failures. Original299 formatting failure and300 preparer assertion correction remain. Full platform/ownership/accounting/final acceptance remain open. Full audits, commands and raw results are inside the archive.',
    goal_complete=False))
files = {}
for tag in ['source297', 'source300']:
    for directory in sorted(p.glob(tag + '-native-bytecode-pilot-*')) + [p / (tag + '-core-native')]:
        for f in directory.rglob('*'):
            if f.is_file() and f.suffix in allowed:
                files[str(f.relative_to(p))] = f
for f in p.iterdir():
    if f.is_file() and f.suffix in allowed and f.name.startswith('native-bytecode-performance-'):
        files[f.name] = f
for name in ['measure-native-bytecode.py', 'audit-native-bytecode-performance.py',
             'finish-native-bytecode-performance-closed.py', 'source300-application-decision.json',
             'package-source196-failure-and197-results.py', Path(__file__).name]:
    files[name] = p / name
package('source300-native-bytecode-performance', files, dict(
    status='all192 actual process answers and modes verified',
    audit=dict(path='native-bytecode-performance-audit.json', sha256=sha((p / 'native-bytecode-performance-audit.json').read_bytes())),
    application_decision=decision,
    qualification='All samples/startup/total/RSS/GC reports and unavailable-allocation errors remain. Applied297 and candidate300 run three alternating unchanged full16 pilots each, separately from builds/tests/profiles. Small diagnostic, no statistical acceptance. Real counters, calibration and nine-round every-case upper95% GNU ratio at most1.03 remain required. Full audits and raw results are inside the archive.',
    goal_complete=False))
