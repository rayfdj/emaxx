from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
out = p.parents[2] / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
read = lambda name: json.loads((p / name).read_text())
ordinary = read('source246-ordinary-audit.json')
new = read('source246-selected-audit.json')
assert len(ordinary['fixtures']) == 57 and len(new['fixtures']) == 11
assert len(set(ordinary['fixtures'] + new['fixtures'])) == 68
commit = read('source246-checkpoint-commit.json')['commit']
linux = {label: read('source246-linux-' + label + '-launch.json') for label in ['rust', 'frozen']}
assert all(row['source_commit'] == row['state']['headSha'] == commit for row in linux.values())
allowed = {'.json', '.log', '.txt', '.py', '.stdout', '.stderr'}
patterns = ['source246-ordinary-*', 'source246-selected-audit.json', 'source246-manifest.json',
            'source246-checkpoint-*', 'source246-linux-*', 'launch-source246-linux.py',
            'commit-source246-checkpoint.py', 'run-source246-release-and-ordinary.py',
            'audit-source246-ordinary.py', 'audit-source246-selected.py',
            'compare-source230-fixtures.py', Path(__file__).name]
files = {str(file.relative_to(p)): file for pattern in patterns for file in p.glob(pattern)
         if file.is_file() and file.suffix in allowed}
files['source246-linux-launch-label-correction.json'] = p / 'source246-linux-launch-label-correction.json'
package('source246-linux-launch-and-ordinary', files,
        dict(source_commit=commit, preceding_ordinary=ordinary, new_ordinary=new,
             total_distinct_ordinary_comparisons=68, linux_launches=linux,
             qualification='Exact pushed source246 runtime checkpoint. All 57 preceding ordinary comparisons and eleven new comparisons pass; 68 distinct same-input comparisons in total. Linux Rust and full frozen jobs are dispatched on this commit, with no completion inferred. Complete local macOS/release/terminal validation remains active and its active logs are excluded. Earlier failed sources and the unresolved GNU census diagnosis remain preserved; main and the full goal are unchanged.'))
