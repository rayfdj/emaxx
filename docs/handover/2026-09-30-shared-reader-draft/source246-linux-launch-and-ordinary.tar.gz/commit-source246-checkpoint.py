from pathlib import Path
import hashlib, io, json, subprocess, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
sha = lambda data: hashlib.sha256(data).hexdigest()
def output(command):
    return subprocess.check_output(command, cwd=root, text=True).strip()
def save(name, record):
    with (p / name).open('x') as stream:json.dump(record, stream, indent=2)
prior = '0f5e6ff8e6d7662d2eb648ee9f872ad4a96ef489'
assert output(['git', 'branch', '--show-current']) == 'runtime-char-tables'
assert output(['git', 'rev-parse', 'HEAD']) == prior
assert output(['git', 'ls-remote', '--heads', 'origin', 'refs/heads/runtime-char-tables']).split()[0] == prior
assert not output(['git', 'diff', '--cached', '--name-only'])
manifest = json.loads((p / 'source246-manifest.json').read_text())
assert len(manifest) == 468 and all(sha((root / name).read_bytes()) == digest for name, digest in manifest.items())
assert json.loads((p / 'source246-selected-audit.json').read_text())['status'] == 'passed'
assert json.loads((p / 'source246-upstream-compiler-raw-audit.json').read_text())['status'] == 'passed'
paths = ['HANDOVER.md', 'docs/runtime-representation-progress.md', 'docs/runtime-representation-correctness-recovery-draft.md',
         '.github/workflows/frozen-run.yml', 'tools/retain_oracle_artifacts.py',
         'src/lisp/primitives/coding.rs', 'src/lisp/primitives/dispatch/buffer_meta.rs', 'src/lisp/primitives/tests.rs',
         'tests/fixtures/coding-candidate-translation.el', 'tests/fixtures/coding-candidate-translation.expected',
         'tests/fixtures/coding-candidate-character-identities.el', 'tests/fixtures/coding-candidate-character-identities.expected']
retention = json.loads((p / 'oracle-retention-validation-audit.json').read_text())
assert retention['status'] == 'passed'
assert sha((root / 'tools/retain_oracle_artifacts.py').read_bytes()) == retention['tool_sha256']
assert sha((root / '.github/workflows/frozen-run.yml').read_bytes()) == retention['workflow_sha256']
for stem in ['source244-closed-validation', 'source246-coding-translation-selected']:
    prefix = 'docs/handover/2026-09-30-shared-reader-draft/' + stem
    paths += [prefix + '-manifest.json', prefix + '.tar.gz']
    record = json.loads((root / (prefix + '-manifest.json')).read_text())
    archive = root / (prefix + '.tar.gz')
    assert sha(archive.read_bytes()) == record['archive']['sha256']
    with tarfile.open(archive) as contents:
        assert contents.getnames() == [entry['path'] for entry in record['files']]
        for entry in record['files']:
            data = contents.extractfile(entry['path']).read()
            assert sha(data) == entry['sha256'] and len(data) == entry['bytes']
subprocess.run(['git', 'diff', '--check'], cwd=root, check=True)
subprocess.run(['git', 'add', '--', *paths], cwd=root, check=True)
assert set(output(['git', 'diff', '--cached', '--name-only']).splitlines()) == set(paths)
subprocess.run(['git', 'diff', '--cached', '--check'], cwd=root, check=True)
tree = output(['git', 'write-tree'])
data = subprocess.check_output(['git', 'archive', tree, '--', *sorted(manifest)], cwd=root)
with tarfile.open(fileobj=io.BytesIO(data)) as contents:
    assert all(sha(contents.extractfile(name).read()) == digest for name, digest in manifest.items())
subprocess.run(['git', '-c', 'user.name=Ray', '-c', 'user.email=26018378+rayfdj@users.noreply.github.com',
                'commit', '-m', 'Honor live coding translations and preserve private-use characters'], cwd=root, check=True)
head = output(['git', 'rev-parse', 'HEAD'])
assert output(['git', 'rev-parse', 'HEAD^{tree}']) == tree
assert not output(['git', 'status', '--porcelain'])
save('source246-checkpoint-commit.json', dict(commit=head, source='source246', inputs=468, paths=paths,
     focused_passed=168, existing_ignores=2, affected_passed=951, ordinary_comparisons=11,
     upstream_compiler_passes_per_editor=177, goal_complete=False))
command = ['git', 'push', 'origin', 'HEAD:refs/heads/runtime-char-tables']
result = subprocess.run(command, cwd=root, stdin=subprocess.DEVNULL, capture_output=True, text=True)
save('source246-checkpoint-push.json', dict(command=command, exit_code=result.returncode, stdout=result.stdout, stderr=result.stderr))
result.check_returncode()
remote = output(['git', 'ls-remote', '--heads', 'origin', 'refs/heads/runtime-char-tables'])
assert remote.split()[0] == head
save('source246-checkpoint-remote.json', dict(commit=head, raw=remote))
print(json.dumps(dict(commit=head, status='source246 repair pushed; full platform validation pending; main unchanged')))
