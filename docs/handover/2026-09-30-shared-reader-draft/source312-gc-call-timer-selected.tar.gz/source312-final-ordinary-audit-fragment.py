ordinary = {}
names = list(read('source304-selected-audit.json')['ordinary_results']) + ['native-subr-authority', 'native-subr-c-names', 'native-subr-consumers', 'native-unit-authority', 'bytecode-stack-layout', 'vm-stack-capacity', 'call-after-gc-redefinition', 'timer-snapshot-gc']
assert len(names) == len(set(names)) == 56
for name in names:
    prefix = 'source312-final-ordinary-' + name
    comparison = read(prefix + '-comparison.json')
    assert comparison['passed'] and comparison['exact_match'], name
    outputs = []
    for editor in ['gnu', 'emaxx']:
        stem = prefix + '-' + editor
        result = read(stem + '.result.json')
        command = read(stem + '.command.json')
        assert all(sha(Path(f)) == h for f, h in command['inputs'].items())
        assert result['exit_code'] == 0 and not result['timed_out'] and result['inputs_unchanged'] and result['source_unchanged'] and result['expected_output'] is not False
        stdout, stderr = (p / (stem + '.stdout')).read_bytes(), (p / (stem + '.stderr')).read_bytes()
        assert stdout and not stderr and hashlib.sha256(stdout).hexdigest() == result['stdout_sha256']
        outputs.append(stdout)
    assert outputs[0] == outputs[1]
    ordinary[name] = comparison
driver = p / 'source312-final-native-c-names-loaded-driver.el'
assert driver.read_text() == ';; -*- coding: utf-8; lexical-binding: nil; -*-\n(prin1 ' + (c / 'tests/fixtures/native-subr-c-names.el').read_text() + ')\n'
for editor in ['gnu', 'emaxx']:
    command = read('source312-final-ordinary-native-subr-c-names-' + editor + '.command.json')
    assert command['command'][-2:] == ['-l', str(driver)]
assert read('source312-final-generated-loaded-comparison.json')['passed']
for editor in ['gnu', 'emaxx']:
    stem = 'source312-final-generated-loaded-' + editor
    result = read(stem + '-result.json')
    command = read(stem + '-command.json')
    assert all(sha(Path(f)) == h for f, h in command['inputs'].items())
    stdout = (p / (stem + '.stdout')).read_bytes()
    assert result['exit_code'] == 0 and not result['timed_out'] and result['inputs_unchanged'] and result['source_unchanged']
    assert len(stdout) == 4088269 and len(stdout.splitlines()) == 198 and stdout == (p / 'printer-varied-v3-gnu.stdout').read_bytes()
    assert not (p / (stem + '.stderr')).read_bytes()
queue = read('source312-final-ordinary-queue-result.json')
assert queue['status'] == 'ordinary comparisons passed; independent raw audit required'
assert all(sha(p / n) == h for n, h in queue['helpers'].items())
assert len(queue['steps']) == 8
assert all(r['exit_code'] == 0 and not r['timed_out'] and r['inputs_unchanged'] for r in queue['steps'])
for kind, stages in [('file', ['compile', 'execute']), ('active', ['compile-caller', 'compile-worker', 'execute'])]:
    for editor in ['gnu', 'source312-final']:
        directory = p / ('source312-final-' + kind + '-lifecycle-' + editor)
        for stage in stages:
            command = json.loads((directory / (stage + '-command.json')).read_text())
            result = json.loads((directory / (stage + '-result.json')).read_text())
            assert result['exit_code'] == 0 and not result['timed_out'] and result['inputs_unchanged']
            assert all(sha(Path(n)) == h for n, h in command['inputs'].items())
            assert sha(directory / (stage + '.stdout')) == result['stdout_sha256']
            assert sha(directory / (stage + '.stderr')) == result['stderr_sha256']

lifecycles = {}
for name, stems, dotted in [
    ('file-lifecycle', ['source312-final-file-lifecycle-gnu/execute', 'source312-final-file-lifecycle-source312-final/execute'], False),
    ('active-lifecycle', ['source312-final-active-lifecycle-gnu/execute', 'source312-final-active-lifecycle-source312-final/execute'], False),
    ('anonymous-lifecycle', ['source312-final-lifecycle-candidate-gnu', 'source312-final-lifecycle-candidate-source312-final'], True),
]:
    outputs = []
    for stem in stems:
        command = read(stem + ('.command.json' if dotted else '-command.json'))
        result = read(stem + ('.result.json' if dotted else '-result.json'))
        assert all(sha(Path(f)) == h for f, h in command['inputs'].items())
        assert result['exit_code'] == 0 and not result['timed_out'] and result['inputs_unchanged']
        stdout, stderr = (p / (stem + '.stdout')).read_bytes(), (p / (stem + '.stderr')).read_bytes()
        assert stdout and not stderr and sha(p / (stem + '.stdout')) == result['stdout_sha256']
        outputs.append(stdout)
    assert outputs[0] == outputs[1], name
    comparison = read('source312-final-ordinary-' + name + '-comparison.json')
    assert comparison['passed'] and comparison['exact_match'] and comparison['source_unchanged']
    lifecycles[name] = comparison
assert (p / 'source312-final-file-lifecycle-source312-final/execute.stdout').read_bytes() == (c / 'tests/fixtures/native-unit-lifecycle.expected').read_bytes().rstrip(b'\n')
assert (p / 'source312-final-ordinary-buffer-lf-line-index-emaxx.stdout').read_bytes() == (p / 'source302-line-broad-gnu.stdout').read_bytes()
