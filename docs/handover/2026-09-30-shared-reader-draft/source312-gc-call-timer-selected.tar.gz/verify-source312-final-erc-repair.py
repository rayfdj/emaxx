from pathlib import Path
import os,json,subprocess,time,hashlib,signal
p=Path(__file__).parent.resolve();old=json.loads((p/'source310-erc-pristine-diagnostic/0/command.json').read_text());root=p/'source312-final-erc-repair';root.mkdir();c=p.parent/'recovered-2026-10-06/bytecode-gc/emaxx';g=p.parent/'rebuilt-2026-10-01/emacs';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();rows=[]
for round_ in range(3):
 for label,exe in [('old',Path(old['command'][0])),('new',c/'target/gc-development/release/emaxx'),('gnu',g/'src/emacs')]:
  d=root/str(round_)/label;d.mkdir(parents=True);cmd=[s.replace(str(p/'source310-erc-pristine-diagnostic/0'),str(d)) for s in old['command']];cmd[0]=str(exe);env=dict(os.environ)
  for k in list(env):
   if k.startswith('EMAXX_') or k in ['EMACSDATA','EMACSDOC','EMACSLOADPATH','EMACSNATIVELOADPATH','EMACSPATH','GREP_OPTIONS','LC_ALL','LC_CTYPE','XDG_CONFIG_HOME']:del env[k]
  overrides={k:v.replace(str(p/'source310-erc-pristine-diagnostic/0'),str(d)) for k,v in old['environment_overrides'].items()};overrides['ERC_DIAGNOSTIC_PADDING']='a'*(128*round_)
  if label=='gnu':overrides['EMAXX_COMPAT_RUNNER']='oracle'
  env.update(overrides);(d/'command.json').write_text(json.dumps(dict(command=cmd,cwd=old['cwd'],environment_overrides=overrides,binary_sha256=sha(exe),image_sha256=sha(exe.with_suffix('.pdmp')),qualification='Same unchanged ERC test and pristine checkout; normal entry without tracing library; padding varied identically for all revisions'),indent=2));start=time.monotonic()
  with (d/'stdout').open('wb') as out,(d/'stderr').open('wb') as err:
   try:r=subprocess.run(cmd,cwd=old['cwd'],env=env,stdout=out,stderr=err,timeout=120);code,timed=r.returncode,False
   except subprocess.TimeoutExpired:code,timed=None,True
  result=dict(label=label,round=round_,exit_code=code,signal=signal.Signals(-code).name if code is not None and code<0 else None,timed_out=timed,elapsed_seconds=time.monotonic()-start)
  report=d/'emaxx.json'
  if report.exists():result['ert_summary']=json.loads(report.read_text()).get('summary')
  (d/'result.json').write_text(json.dumps(result,indent=2));rows.append(result);print(result,flush=True)
(p/'source312-final-erc-repair-result.json').open('x').write(json.dumps(rows,indent=2))
