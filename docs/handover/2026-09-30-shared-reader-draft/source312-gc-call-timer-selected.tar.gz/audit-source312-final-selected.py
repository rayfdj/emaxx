from pathlib import Path
import hashlib, json, re, subprocess
from native_fixed_validation_support import audit_selected

p = Path(__file__).parent.resolve()
c = p.parent / 'recovered-2026-10-06/bytecode-gc/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p / n).read_text())
manifest, modes = read('source312-final-manifest.json'), read('source312-final-modes.json')
assert len(manifest) == len(modes) == 552
assert all(sha(c / n) == h and (c / n).stat().st_mode & 0o777 == modes[n] for n, h in manifest.items())
prior = read('source311-manifest.json')
assert all(manifest[n] == h for n, h in prior.items() if n.startswith(('tests/', 'tools/', 'compat/')))
assert manifest['src/anti_cheat.rs'] == prior['src/anti_cheat.rs']
auxiliary = read('source310-validation-input-recovery.json')['auxiliary_inputs']
assert len(auxiliary) == 94
assert all(sha(c / n) == item['sha256'] and (c / n).stat().st_mode & 0o777 == item['mode'] for n, item in auxiliary.items())

# Development5 changes only a test's setup from development4. Retain all
# original strings and every original assertion; prove production is identical.
previous = read('source312-timer-development4-manifest.json')
changed = [n for n in manifest if manifest[n] != previous[n]]
assert changed == ['src/lisp/native_comp/runtime.rs']
old_tree = p.parent / 'source312-portable-replay/emaxx'
old = (old_tree / changed[0]).read_text()
new = (c / changed[0]).read_text()
start = new.index('            // alloc.c:compact_small_strings need not move')
end = new.index('            for index in 0..768 {', start)
assert new[:start] + new[end:] == old and sha(old_tree / changed[0]) == previous[changed[0]]

new_tests = {
    'lisp::native_comp::runtime::tests::native_automatic_gc_runs_statistics_and_hooks_under_gnu_inhibition',
    'lisp::primitives::tests::bytecode_calls_observe_gc_hook_redefinition_and_gnu_collection_completion',
    'lisp::primitives::tests::timer_snapshot_survives_canceling_and_collecting_later_entries',
}
profiles = {}
for profile, prefix, required, helper in [
    ('gate', 'source312-timer-development5', 3058, 'run-source312-timer-development5.py'),
    ('release', 'source312-release2', 3057, 'run-source312-release2.py'),
]:
    state = read(prefix + '-result.json')
    assert 'passed' in state['status'] and 'stopped' not in state['status']
    assert sha(p / helper) == state['helper_sha256']
    assert all(r['exit_code'] == 0 and not r['timed_out'] and r['source_unchanged'] for r in state['results'])
    inventory = [s[:-6] for s in (p / (prefix + '-inventory.log')).read_text().splitlines() if s.endswith(': test')]
    previous_names = [s[:-6] for s in (p / ('source311-' + profile + '-inventory.log')).read_text().splitlines() if s.endswith(': test')]
    assert len(inventory) == len(set(inventory)) == required
    assert set(inventory) == set(previous_names) | new_tests
    selected = read(prefix + '-selected-command.json')['command'][3:]
    baseline = read('source311-' + profile + '-selected-command.json')['command'][3:]
    assert len(selected) == 1068 and set(selected) == set(baseline) | new_tests
    assert len([n for n in selected if n.startswith('anti_cheat::')]) == 24
    focused_names = read(prefix + '-focused-command.json')['command'][3:]
    assert len(focused_names) == 8 and new_tests <= set(focused_names)
    assert 'lisp::native_comp::runtime::tests::string_sblocks_compact_unborrowed_data_and_hold_borrowed_blocks' in focused_names
    focused = audit_selected((p / (prefix + '-focused.log')).read_text(), focused_names)
    counts = audit_selected((p / (prefix + '-selected.log')).read_text(), selected)
    assert focused['passed'] == 8 and counts['passed'] == 1068
    assert sha(Path(state['binary'])) == sha(Path(state['retained_binary'])) == state['binary_sha256']
    messages = [json.loads(line) for line in (p / (prefix + '-build.log')).read_text().splitlines() if line.startswith('{')]
    artifacts = [a for a in messages if a.get('reason') == 'compiler-artifact' and a['target']['name'] == 'emaxx' and a.get('profile', {}).get('test') and a.get('executable')]
    assert len(artifacts) == 1 and not artifacts[0]['fresh'] and artifacts[0]['executable'] == state['binary']
    for stage in ['fmt', 'check', 'clippy', 'build', 'ordinary-build']:
        log = p / (prefix + '-' + stage + '.log')
        if not log.exists():
            assert profile == 'release' and stage in ['fmt', 'check', 'clippy']
            continue
        raw = log.read_text()
        assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
        for line in raw.splitlines():
            if line.startswith('{'):
                assert json.loads(line).get('message', {}).get('level') not in ['warning', 'error']
    profiles[profile] = dict(**counts, focused=focused, binary_sha256=state['binary_sha256'])

diff = subprocess.run(['git', 'diff', '--check'], cwd=c, capture_output=True)
assert diff.returncode == 0 and not diff.stdout and not diff.stderr
artifacts = read('source312-final-ordinary-artifacts.json')
assert all(sha(Path(f)) == sha(Path(v['immutable_copy'])) == v['sha256'] for f, v in artifacts.items())
portable = read('source312-final-portable-audit.json')
assert portable['source_inputs'] == 552
assert portable['incremental_patch_sha256'] == sha(p / 'source312-timer-development5.patch')
assert portable['complete_patch_sha256'] == sha(p / 'source312-final-portable-complete.patch')
for tree in ['source312-final-portable-replay/emaxx', 'source312-final-portable-main-replay']:
    replay = p.parent / tree
    assert all(sha(replay / n) == h and (replay / n).stat().st_mode & 0o777 == modes[n] for n, h in manifest.items())

# Same independent raw-byte, process, fixture and lifecycle checks used for311,
# extended with both new ordinary fixtures. No earlier successful output stands
# in for a process from this exact candidate.
exec(compile((p / 'source312-final-ordinary-audit-fragment.py').read_text(),
             'source312-final-ordinary-audit-fragment.py', 'exec'))

extra = read('source312-final-extra-result.json')
assert extra['status'] == 'extra ordinary probes finished; raw comparison audit required'
assert all(sha(p / n) == h for n, h in extra['helpers'].items())
assert all(r['exit_code'] == 0 and r['inputs_unchanged'] for r in extra['steps'])
call_results = read('source312-final-call-ordinary-results.json')
assert len(call_results) == 6
for i in range(0, 6, 2):
    outputs = []
    for row in call_results[i:i + 2]:
        stem = p / ('source312-final-call-ordinary-' + Path(row['fixture']).stem + '-' + row['label'])
        command = json.loads(stem.with_suffix('.command.json').read_text())
        binary = Path(command['command'][0])
        assert sha(binary) == command['binary_sha256']
        assert sha(binary.with_suffix('.pdmp')) == command['image_sha256']
        assert sha(Path(row['fixture'])) == command['fixture_sha256']
        assert row['exit_code'] == 0 and not row['timed_out']
        assert sha(stem.with_suffix('.stdout')) == row['stdout_sha256']
        assert sha(stem.with_suffix('.stderr')) == row['stderr_sha256']
        out, err = stem.with_suffix('.stdout').read_bytes(), stem.with_suffix('.stderr').read_bytes()
        assert out and not err
        outputs.append(out)
    assert outputs[0] == outputs[1]
    if i:
        assert outputs[0] == (c / 'tests/fixtures/call-after-gc-redefinition.expected').read_bytes().rstrip(b'\n')

erc = read('source312-final-erc-repair-result.json')
assert len(erc) == 9
for index in range(3):
    reports = []
    for label in ['new', 'gnu']:
        directory = p / 'source312-final-erc-repair' / str(index) / label
        command = json.loads((directory / 'command.json').read_text())
        result = json.loads((directory / 'result.json').read_text())
        binary = Path(command['command'][0])
        assert sha(binary) == command['binary_sha256'] and sha(binary.with_suffix('.pdmp')) == command['image_sha256']
        assert result['exit_code'] == 0 and not result['timed_out']
        report = json.loads((directory / 'emaxx.json').read_text())
        assert report['file_status'] == 'loaded' and report['file_error'] is None
        assert report['selected_tests'] == ['erc-scenarios-misc-commands--AMSG-GMSG-AME-GME']
        assert report['summary'] == dict(total=1, passed=1, failed=0, skipped=0, unexpected=0)
        assert len(report['results']) == 1 and report['results'][0]['status'] == 'passed'
        reports.append({k: report[k] for k in ['file', 'selector', 'file_status', 'file_error', 'discovered_tests', 'selected_tests', 'summary']})
    assert reports[0] == reports[1]

evidence = {str(f): sha(f) for f in p.glob('source312-*') if f.is_file()
            and f.suffix in ['.json', '.log', '.stdout', '.stderr', '.patch', '.el', '.expected']}
result = dict(status='passed', source_inputs_verified=552, auxiliary_inputs_verified=94,
              profiles=profiles, ordinary_comparisons=60, ordinary_results=ordinary,
              lifecycle_results=lifecycles, generated_rows=198, extra_call_pairs=3,
              upstream_erc_repetitions=3, ordinary_artifacts=artifacts,
              portable_replays=portable, evidence_files=evidence, goal_complete=False,
              qualification='Selected correctness only. Both profiles retain all1065 predecessor selectors and24 audit controls; three controls and two ordinary fixtures are added. All original fixtures/expected bytes and compaction assertions remain. The compaction setup now guarantees a retired data entry; development4 production bytes are unchanged. Native automatic GC completes finalizers/hooks/stats, all call paths resolve after their entry GC, and timer snapshots retain live objects across callbacks. Earlier runtime negatives, setup failures, failed selections, and source310 frozen crash remain recorded. Full exact-source platform validation, internal native borrow/ownership audit, physical accounting and counters, remaining architecture, adversarial review and calibrated performance acceptance remain open.')
(p / 'source312-final-selected-audit.json').open('x').write(json.dumps(result, indent=2))
print(json.dumps(dict(status='passed', source_inputs=552, passes_per_profile=1068,
                      ordinary_comparisons=60, extra_call_pairs=3, upstream_erc_repetitions=3)))
