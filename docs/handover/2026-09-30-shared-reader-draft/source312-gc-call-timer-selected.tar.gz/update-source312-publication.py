from pathlib import Path
import json

p = Path(__file__).parent.resolve()
root = p.parents[2]
audit = json.loads((p / 'source312-final-selected-audit.json').read_text())
assert audit['status'] == 'passed' and audit['ordinary_comparisons'] == 60
text = """## GC completion, call order and timer lifetime — 7 October 2026

**Source312 is applied; the full goal remains incomplete.** Native automatic GC
now runs finalizers, updates collection statistics and runs the inhibited
post-GC hook through the same completion path as ordinary collection
(GNU alloc.c:garbage_collect, lines 6698–6731). Interpreter, bytecode and native
funcall entries root their unresolved function/arguments, collect, then resolve
the current function cell (eval.c:Ffuncall, bytecode.c:Bcall). This also
removes duplicate dispatch-specific call frames. A callback can replace a
bytecode function with an interpreted function, primitive, alias or void cell;
the actual next call now agrees with GNU.

The source310 macOS ERC crash was a timer snapshot retaining unrooted Lisp
words across callbacks. A callback could cancel later timers and collect their
vectors; the later snapshot access read freed memory. The snapshot now uses
the existing RootedVec, retaining remaining entries until iteration consumes
them, corresponding to GNU's reachable copied timer lists in
keyboard.c:timer_check. The original crash, its layout dependence, instrumented
diagnosis and subsequent ordinary reproductions remain preserved.

The [selected evidence](PREFIXsource312-gc-call-timer-selected-manifest.json)
verifies **552 runtime inputs and modes**, **94 auxiliary inputs**, warning-free
strict checks, **1,068 passes and eight focused passes per profile**, and
**60 ordinary GNU comparisons**, including 198 generated rows. Three additional
call probes match actual GNU output, including native compilation, and the
unchanged upstream ERC case passes in GNU and312 across three environment
layouts. Both portable replays reproduce every runtime byte and mode.
All 1,065 predecessor selectors, 24 audit controls and original fixture/expected
bytes remain. The compaction test now guarantees an actual retired data entry
before the borrowed string; every original string and assertion remains.
The old setup incorrectly required movement even when data could already be at
its destination, which GNU's compact_small_strings does not require.
Both earlier broad failures and the smaller unchanged passing replay remain.

This is a [correctness publication](PREFIXsource312-application-decision.json)
with [exact applied-source verification](PREFIXsource312-applied-source-verification.json).
Full exact-source Linux/macOS validation and312 timing remain separate;
inspect the saved launch/queue receipts before starting another run.

Predecessor311's [Linux Rust run](PREFIXsource311-linux-rust-results-manifest.json)
passes **3,164 tests with two existing ignores**. Its
[full Linux frozen run](PREFIXsource311-linux-frozen-results-manifest.json)
matches **519 files / 7,928 outcomes / 1,038 successful processes**:
each editor reports 7,670 passes, 47 expected failures and 211 skips.
Its [paired full16 diagnostic](PREFIXsource311-linux-stack-performance-results-manifest.json)
verifies all 192 actual answers/modes. The raw body geometric ratio311/310
is **1.006777**; paired GNU aggregates are 2.903372× and 2.841965× respectively.
These were measured before the native GC completion repair: reported GC counts
and elapsed GC time omitted native automatic collections. Keep the timings and
regressions visible, but do not call them equivalent-work performance acceptance.

Source310's [macOS frozen run](PREFIXsource310-macos-frozen-abort-manifest.json)
remains failed: 182 complete comparisons / 2,951 matching outcomes, followed by
the ERC crash; 336 files never started. Its
[terminal raw audit](PREFIXsource310-macos-terminal-qualified-results-manifest.json)
finds 226 scenarios / 686 matching comparisons, but a diagnostic rebuild changed
the executable during the run, so unchanged-artifact acceptance is unestablished.
The [original frozen executable/image](PREFIXsource310-original-frozen-retention-verified.json)
are retained separately from the later crashing replay binary. The new full
validation checkout is isolated and its terminal stage uses retained copies.

Main remains 21d20f0e, PR79 remains draft. Allocated-symbol authority, real
intervals and unified pure storage, remaining adapters, physical accounting and
allocation counters, internal native borrow/ownership review, final adversarial
review, complete final-source validation and the unchanged calibrated nine-round
every-workload performance criterion remain open. No GNU performance parity or
full-goal completion is claimed. Earlier sections preserve historical states.

"""
for name, prefix in [
    ('HANDOVER.md', 'docs/handover/2026-09-30-shared-reader-draft/'),
    ('docs/runtime-representation-progress.md', 'handover/2026-09-30-shared-reader-draft/'),
    ('docs/runtime-representation-bytecode-draft.md', 'handover/2026-09-30-shared-reader-draft/'),
]:
    f = root / name
    old = f.read_text()
    heading = text.splitlines()[0]
    assert heading not in old
    offset = old.index('## Applied bytecode stack — 6 October 2026')
    new = old[:offset] + text.replace('PREFIX', prefix) + old[offset:]
    if name.endswith('progress.md'):
        new = new.replace('# Current goal status — 5 October 2026', '# Current goal status — 7 October 2026', 1)
    f.write_text(new)
print('Updated current continuation; preserved historical failures and full-goal requirements.')
