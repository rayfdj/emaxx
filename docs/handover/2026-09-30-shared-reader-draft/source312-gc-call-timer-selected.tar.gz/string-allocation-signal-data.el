(let ((payload (list 'error (propertize "allocation-probe-47" 'probe-tag 83)))
      (memory-full nil))
  (let ((memory-signal-data payload))
    (list
     (mapcar
      (lambda (character)
        (condition-case condition
            (progn (make-string (ash 1 58) character) 'unexpected-success)
          (error (list (eq condition payload)
                       (eq (cdr condition) (cdr payload))
                       condition memory-full))))
      '(97 128 2097152))
     (mapcar
      (lambda (character)
        (condition-case condition
            (progn (make-string most-positive-fixnum character) 'unexpected-success)
          (error condition)))
      '(128 2097152))
     (make-string 3 97))))
