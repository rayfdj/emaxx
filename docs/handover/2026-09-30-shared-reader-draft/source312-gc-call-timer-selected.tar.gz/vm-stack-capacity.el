(prin1
 (mapcar
  (lambda (depth)
    (condition-case err
        (funcall (make-byte-code 0 (unibyte-string 192 135) [capacity-ok] depth))
      (error (list (car err) (cadr err)))))
  '(1 131072 262144 393216)))
