from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
out = p.parents[2] / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda n: json.loads((p / n).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
audit = read('source312-final-selected-audit.json')
assert audit['status'] == 'passed' and audit['ordinary_comparisons'] == 60
assert all(r['passed'] == 1068 and r['failed'] == r['ignored'] == 0 for r in audit['profiles'].values())
assert all(sha(Path(n).read_bytes()) == h for n, h in audit['evidence_files'].items())
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected', '.c'}
files, excluded = {}, []
for f in p.iterdir():
    if f.is_file() and f.suffix in allowed and (f.name.startswith('source312-') or '312' in f.name and f.suffix == '.py'):
        files[f.name] = f
    elif f.is_dir() and f.name.startswith('source312-') and any(w in f.name for w in ['lifecycle', 'erc-repair']):
        for item in f.rglob('*'):
            if not item.is_file():
                continue
            if item.suffix in allowed or item.name in ['stdout', 'stderr']:
                files[str(item.relative_to(p))] = item
            else:
                excluded.append(dict(path=str(item.relative_to(p)), bytes=item.stat().st_size, sha256=sha(item.read_bytes())))
for pattern in ['bytecode-post-gc-*.el', 'native-unit309-*.el', 'source310-erc-symbolication.json',
                'source310-original-frozen-retention-verified.json', 'source310-full-frozen-subject-inputs.json']:
    for f in p.glob(pattern):
        if f.is_file():
            files[f.name] = f
for n in [
    'source311-manifest.json', 'source311-modes.json', 'source311-selected-audit.json',
    'source311-gate-inventory.log', 'source311-release-inventory.log',
    'source311-gate-selected-command.json', 'source311-release-selected-command.json',
    'source310-validation-input-recovery.json', 'source304-selected-audit.json',
    'native_fixed_validation_support.py', 'printer-varied-v3-293638f0.el',
    'printer-varied-v3-gnu.stdout', 'source302-line-broad-gnu.stdout',
    'package-source196-failure-and197-results.py', Path(__file__).name,
]:
    files[n] = p / n
# Ordinary fixture commands are an explicit dependency inventory, including
# unchanged historical .el programs outside the checkout.
for f in p.glob('source312-final-ordinary-*.command.json'):
    for name in json.loads(f.read_text())['inputs']:
        item = Path(name)
        if item.parent == p and item.suffix in ['.el', '.expected', '.py']:
            files[item.name] = item
assert all(f.is_file() for f in files.values())
package('source312-gc-call-timer-selected', files, dict(
    status='selected GC completion, call-order and timer-root correctness validated',
    source_inputs=552, auxiliary_inputs=94, passes_per_profile=1068, focused_per_profile=8,
    ordinary_comparisons=60, generated_rows=198, extra_call_pairs=3, upstream_erc_repetitions=3,
    excluded_binaries=excluded, goal_complete=False, qualification=audit['qualification']))
