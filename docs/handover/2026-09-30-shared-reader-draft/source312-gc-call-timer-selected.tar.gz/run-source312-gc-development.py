from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys,time
from native_fixed_validation_support import audit_selected
p=Path(__file__).parent.resolve();c=p.parent/'recovered-2026-10-06/bytecode-gc/emaxx';g=p.parent/'rebuilt-2026-10-01/emacs'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();prefix='source312-gc-development'
base=json.loads((p/'source311-manifest.json').read_text());names=sorted(base)
manifest={n:sha(c/n) for n in names};(p/(prefix+'-manifest.json')).open('x').write(json.dumps(manifest,indent=2))
patch=subprocess.check_output(['git','diff','--binary'],cwd=c)
for n in sorted(set(names)-set(base)):
 r=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',n],cwd=c,capture_output=True);assert r.returncode==1 and not r.stderr;patch+=r.stdout
(p/(prefix+'.patch')).open('xb').write(patch)
extra=json.loads((p/'source310-validation-input-recovery.json').read_text())['auxiliary_inputs'];assert all(sha(c/n)==v['sha256'] for n,v in extra.items())
target=c/'target/gc-development';overrides=dict(CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='1',LANG='C',LC_ALL='C',RUST_MIN_STACK='134217728',RUST_TEST_THREADS='1',EMAXX_GC_VERIFY='1',EMAXX_GNU_SOURCE_DIRECTORY=str(g),EMAXX_DUMP_SOURCE_DIRECTORY=str(g),EMACS_TEST_DIRECTORY=str(g/'test'),EMAXX_IMAGE_TEMPLATE='1',EMAXX_FIXTURE_IMAGE_DIR=str(p/'fixture-images-source312-development'))
env=dict(os.environ,**overrides)
state=dict(status='starting development validation',candidate=str(c),manifest=prefix+'-manifest.json',source_inputs=len(manifest),base_commit='447c84c13017f47878855273a2a0609f9f9edeb1',results=[],goal_complete=False,helper_sha256=sha(Path(__file__)))
unchanged=lambda:all(sha(c/n)==h for n,h in manifest.items()) and all(sha(c/n)==v['sha256'] for n,v in extra.items())
def save(): (p/(prefix+'-state.json')).write_text(json.dumps(state,indent=2))
def run(stage,command,timeout=1800):
 assert unchanged();save();stem=prefix+'-'+stage
 (p/(stem+'-command.json')).open('x').write(json.dumps(dict(command=command,cwd=str(c),environment_overrides=overrides,timeout_seconds=timeout),indent=2))
 state['status']='running '+stage;save();start=time.monotonic()
 with (p/(stem+'.log')).open('xb') as log:
  try:r=subprocess.run(command,cwd=c,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,timeout=timeout);code,timed_out=r.returncode,False
  except subprocess.TimeoutExpired:code,timed_out=None,True
 result=dict(stage=stage,exit_code=code,timed_out=timed_out,elapsed_seconds=time.monotonic()-start,source_unchanged=unchanged());state['results'].append(result)
 (p/(stem+'-result.json')).open('x').write(json.dumps(result,indent=2));save();print(json.dumps(result),flush=True)
 assert code==0 and not timed_out and result['source_unchanged'],result
try:
 assert target.exists()
 for stage,cmd in [('fresh-crate',['cargo','clean','--package','emaxx']),('fresh-gate',['cargo','clean','--package','emaxx','--profile','gate']),('fmt',['cargo','fmt','--all','--','--check']),('check',['cargo','check','--locked','--all-targets','--all-features']),('clippy',['cargo','clippy','--locked','--all-targets','--all-features','--','-D','warnings']),('build',['cargo','test','--locked','--profile','gate','--all-features','--lib','--no-run','--message-format=json'])]:run(stage,cmd)
 messages=[json.loads(x) for x in (p/(prefix+'-build.log')).read_text().splitlines() if x.startswith('{')]
 artifacts=[x for x in messages if x.get('reason')=='compiler-artifact' and x['target']['name']=='emaxx' and x.get('profile',{}).get('test') and x.get('executable')]
 assert len(artifacts)==1 and not artifacts[0]['fresh'];binary=Path(artifacts[0]['executable']);retained=p/(prefix+'-libtest');shutil.copy2(binary,retained);assert sha(binary)==sha(retained)
 state.update(binary=str(binary),binary_sha256=sha(binary),retained_binary=str(retained));save()
 run('inventory',[str(binary),'--list'])
 inventory=[x[:-6] for x in (p/(prefix+'-inventory.log')).read_text().splitlines() if x.endswith(': test')]
 prior=[x[:-6] for x in (p/'source311-gate-inventory.log').read_text().splitlines() if x.endswith(': test')]
 new={'lisp::native_comp::runtime::tests::native_automatic_gc_runs_statistics_and_hooks_under_gnu_inhibition'}
 assert set(inventory)==set(prior)|new and len(inventory)==len(set(inventory))
 focused=sorted(new|{'lisp::native_comp::runtime::tests::eval_sub_runs_maybe_gc_before_form_dispatch','lisp::native_comp::runtime::tests::garbage_collect_maybe_matches_gnu_factor_boundary','lisp::native_comp::runtime::tests::native_gc_matches_gnu_threshold_boundary_and_half_live_adjustment','lisp::native_comp::runtime::tests::native_gc_matches_gnu_percentage_type_and_saturation_rules'})
 run('focused',[str(binary),'--exact','--test-threads=1',*focused]);state['focused']=audit_selected((p/(prefix+'-focused.log')).read_text(),focused);save()
 run('ordinary-build',['cargo','build','--locked','--profile','gate','--all-features','--bin','emaxx','--bin','make-fingerprint','--message-format=json'])
 env['EMAXX_IMAGE_FORCE']='1'
 run('ordinary-image',['sh','tools/build-image.sh',str(target/'gate/emaxx')])
 del env['EMAXX_IMAGE_FORCE']
 state['status']='development GC-tail strict/focused and ordinary build passed; call-order repair and broader validation pending'
except Exception as error:state.update(status='development validation stopped',error=repr(error))
finally:
 save();(p/(prefix+'-result.json')).open('x').write(json.dumps(state,indent=2))
print(json.dumps(dict(status=state['status'],error=state.get('error'))),flush=True)
