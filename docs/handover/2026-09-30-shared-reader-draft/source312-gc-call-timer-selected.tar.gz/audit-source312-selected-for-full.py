from pathlib import Path
import hashlib,json
p=Path(__file__).parent.resolve()
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
read=lambda n:json.loads((p/n).read_text())
audit=read('source312-final-selected-audit.json');m=read('source312-final-manifest.json')
assert audit['status']=='passed' and audit['ordinary_comparisons']==60
assert all(r['passed']==1068 and r['failed']==r['ignored']==0 for r in audit['profiles'].values())
assert len(m)==552
for root in [Path(read('source312-full-checkout.json')['candidate']),p.parent/'recovered-2026-10-06/bytecode-gc/emaxx']:
    assert all(sha(root/n)==h for n,h in m.items())
assert audit['auxiliary_inputs_verified'] == 94
assert all(sha(Path(n))==h for n,h in audit['evidence_files'].items())
assert all(sha(Path(n))==sha(Path(r['immutable_copy']))==r['sha256'] for n,r in audit['ordinary_artifacts'].items())
portable = audit['portable_replays']
assert sha(p/'source312-timer-development5.patch') == portable['incremental_patch_sha256']
assert sha(p/'source312-final-portable-complete.patch') == portable['complete_patch_sha256']
with (p/'source312-full-selected-audit.json').open('x') as f:json.dump(audit,f,indent=2)
print(json.dumps(dict(status='passed',verified_inputs=552,profiles={n:r['passed'] for n,r in audit['profiles'].items()},ordinary_comparisons=60)))
