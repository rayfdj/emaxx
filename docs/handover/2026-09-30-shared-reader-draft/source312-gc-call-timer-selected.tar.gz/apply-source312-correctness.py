from pathlib import Path
import hashlib, json, subprocess

p = Path(__file__).parent.resolve()
root = p.parents[2]
c = p.parent / 'recovered-2026-10-06/bytecode-gc/emaxx'
d = root / 'docs/handover/2026-09-30-shared-reader-draft'
read = lambda n: json.loads((p / n).read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert head == '447c84c13017f47878855273a2a0609f9f9edeb1'
audit = read('source312-final-selected-audit.json')
assert audit['status'] == 'passed' and audit['ordinary_comparisons'] == 60
assert all(r['passed'] == 1068 and r['failed'] == r['ignored'] == 0 for r in audit['profiles'].values())
assert all(sha(Path(n)) == h for n, h in audit['evidence_files'].items())
manifest, modes = read('source312-final-manifest.json'), read('source312-final-modes.json')
assert all(sha(c / n) == h and (c / n).stat().st_mode & 0o777 == modes[n] for n, h in manifest.items())
assert all(sha(root / n) == h for n, h in read('source311-manifest.json').items())
auxiliary = read('source310-validation-input-recovery.json')['auxiliary_inputs']
assert all(sha(root / n) == v['sha256'] and (root / n).stat().st_mode & 0o777 == v['mode'] for n, v in auxiliary.items())
patch = p / 'source312-timer-development5.patch'
assert sha(patch) == read('source312-final-portable-audit.json')['incremental_patch_sha256']
decision = dict(
    status='apply source312 selected correctness repair; full goal remains open',
    base_commit=head, selected_audit_sha256=sha(p / 'source312-final-selected-audit.json'),
    rationale='Repair native automatic GC completion, function-cell resolution after GC, and a reproduced upstream timer use-after-free. Preserve every predecessor selector, all fixture expectations, all compaction assertions and failed development results.',
    gnu_reference=dict(source='636f166cfc86aa90d63f592fd99f3fdd9ef95ebd',
                       mechanisms=['alloc.c:garbage_collect', 'eval.c:Ffuncall', 'bytecode.c:Bcall',
                                   'keyboard.c:timer_check', 'alloc.c:compact_small_strings']),
    performance='Not yet measured for312; previous paired311/310 raw timings and GC-accounting limitations are retained. No speedup or GNU-parity claim.',
    remaining=['complete exact-source platform validation', 'allocated symbol authority', 'real intervals and unified pure storage',
               'remaining adapters', 'physical allocation accounting and public counters', 'internal native ownership/borrow audit',
               'final adversarial review', 'calibrated locked16 nine-round every-case GNU performance criterion'],
    goal_complete=False)
(p / 'source312-application-decision.json').open('x').write(json.dumps(decision, indent=2))
steps = []
for command in [['git', 'apply', '--check', str(patch)], ['git', 'apply', str(patch)], ['git', 'diff', '--check']]:
    result = subprocess.run(command, cwd=root, capture_output=True, text=True)
    steps.append(dict(command=command, exit_code=result.returncode, stdout=result.stdout, stderr=result.stderr))
    assert result.returncode == 0, steps[-1]
assert all(sha(root / n) == h and (root / n).stat().st_mode & 0o777 == modes[n] for n, h in manifest.items())
record = dict(status='source312 applied; all552 runtime inputs and94 auxiliary inputs match selected validation',
              pre_apply_head=head, patch_sha256=sha(patch), source_manifest_sha256=sha(p / 'source312-final-manifest.json'),
              steps=steps, goal_complete=False,
              qualification='Selected correctness publication only. Full exact-source Linux/macOS and performance remain separate.')
(p / 'source312-applied-source-verification.json').open('x').write(json.dumps(record, indent=2))
for name in ['source312-application-decision.json', 'source312-applied-source-verification.json']:
    (d / name).open('xb').write((p / name).read_bytes())
print(record['status'])
