(let ((length (ash 1 58)))
  (list
   (mapcar (lambda (character)
             (condition-case condition
                 (progn (make-string length character) 'unexpected-success)
               (error condition)))
           '(97 128 2097152))
   (condition-case condition
       (progn (make-string most-positive-fixnum 2097152) 'unexpected-success)
     (error condition))
   (make-string 3 97)))
