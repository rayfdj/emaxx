from pathlib import Path
import hashlib, json, subprocess, sys, time

p = Path(__file__).parent.resolve()
c = p.parent / 'recovered-2026-10-06/bytecode-gc/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p / n).read_text())
manifest = read('source312-final-manifest.json')
helpers = {n: sha(p / n) for n in [Path(__file__).name,
    'run-source312-final-ordinary-call-probes.py', 'verify-source312-final-erc-repair.py']}
state = dict(status='waiting for release validation', helpers=helpers, steps=[], goal_complete=False)
def unchanged():
    return all(sha(c / n) == h for n, h in manifest.items()) and all(sha(p / n) == h for n, h in helpers.items())
def save():
    (p / 'source312-final-extra-state.json').write_text(json.dumps(state, indent=2))
try:
    save()
    while not (p / 'source312-release2-result.json').exists():
        assert unchanged()
        time.sleep(5)
    assert read('source312-release2-result.json')['status'].startswith('release focused and 1068 selected controls and ordinary build passed')
    for stage, helper in [('calls', 'run-source312-final-ordinary-call-probes.py'),
                          ('erc', 'verify-source312-final-erc-repair.py')]:
        assert unchanged()
        state['status'] = 'running ' + stage
        save()
        cmd = [sys.executable, '-B', str(p / helper)]
        (p / ('source312-final-extra-' + stage + '-command.json')).open('x').write(json.dumps(dict(command=cmd, cwd=str(p), timeout_seconds=1800, helpers=helpers), indent=2))
        started = time.monotonic()
        with (p / ('source312-final-extra-' + stage + '.log')).open('xb') as log:
            r = subprocess.run(cmd, cwd=p, stdout=log, stderr=subprocess.STDOUT, timeout=1800)
        row = dict(stage=stage, exit_code=r.returncode, elapsed_seconds=time.monotonic()-started, inputs_unchanged=unchanged())
        state['steps'].append(row)
        save()
        assert r.returncode == 0 and row['inputs_unchanged']
    state['status'] = 'extra ordinary probes finished; raw comparison audit required'
except Exception as error:
    state.update(status='extra ordinary probes stopped', error=repr(error))
finally:
    save()
    (p / 'source312-final-extra-result.json').open('x').write(json.dumps(state, indent=2))
print(state['status'], state.get('error'), flush=True)
