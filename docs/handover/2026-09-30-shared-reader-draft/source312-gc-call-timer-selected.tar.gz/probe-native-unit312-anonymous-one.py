from pathlib import Path
import hashlib,json,os,subprocess,time,sys
p=Path(__file__).parent.resolve();probe=p/'native-unit309-lifecycle-probe.el';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();results={}
label,binary_arg=sys.argv[1:];binary=Path(binary_arg)
for label,binary in [(label,binary)]:
 stem=p/('source312-lifecycle-candidate-'+label);cmd=[str(binary),'-Q','--batch','-l',str(probe)];inputs={str(f):sha(f) for f in [binary,binary.with_suffix('.pdmp'),probe,Path(__file__)]}
 rec=dict(command=cmd,cwd=str(p),inputs=inputs,timeout_seconds=180,environment_overrides=dict(EMAXX_GC_VERIFY='1',LANG='C',LC_ALL='C'),goal_complete=False);stem.with_suffix('.command.json').open('x').write(json.dumps(rec,indent=2));start=time.monotonic()
 try:r=subprocess.run(cmd,cwd=p,env=dict(os.environ,**rec['environment_overrides']),stdin=subprocess.DEVNULL,capture_output=True,timeout=180);code,out,err,timed=r.returncode,r.stdout,r.stderr,False
 except subprocess.TimeoutExpired as e:code,out,err,timed=None,e.stdout or b'',e.stderr or b'',True
 stem.with_suffix('.stdout').open('xb').write(out);stem.with_suffix('.stderr').open('xb').write(err);result=dict(exit_code=code,timed_out=timed,elapsed_seconds=time.monotonic()-start,stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),inputs_unchanged=all(sha(Path(f))==h for f,h in inputs.items()));stem.with_suffix('.result.json').open('x').write(json.dumps(result,indent=2));results[label]=result;print(label,result,out.decode(errors='backslashreplace'),err.decode(errors='backslashreplace'),flush=True)
