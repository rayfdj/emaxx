from pathlib import Path
import json,os,subprocess,time,hashlib
p=Path(__file__).parent.resolve();g=p.parent/'rebuilt-2026-10-01/emacs';c=p.parent/'recovered-2026-10-06/bytecode-gc/emaxx';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
base=(c/'tests/fixtures/call-after-gc-redefinition.el').read_text();native=base.replace("(require 'bytecomp)","(require 'comp)").replace('(let ((caller (byte-compile','(let ((caller (native-compile').replace('(byte-code-function-p caller)','(native-comp-function-p caller)');assert native!=base
(p/'source312-final-native-call-redefinition.el').open('x').write(native)
results=[]
for fixture in [p/'bytecode-post-gc-resolution-tuned.el',c/'tests/fixtures/call-after-gc-redefinition.el',p/'source312-final-native-call-redefinition.el']:
 outputs={}
 for label,exe in [('gnu',g/'src/emacs'),('source312-final',c/'target/gc-development/release/emaxx')]:
  stem=p/('source312-final-call-ordinary-'+fixture.stem+'-'+label);cache=p/('source312-final-call-ordinary-cache-'+label);cache.mkdir(exist_ok=True)
  cmd=[str(exe),'-Q','--batch','--eval','(startup-redirect-eln-cache '+json.dumps(str(cache))+')','--eval','(prin1 '+fixture.read_text()+')']
  overrides=dict(LANG='C',LC_ALL='C',EMACS_TEST_DIRECTORY=str(g/'test'),EMAXX_GNU_SOURCE_DIRECTORY=str(g),EMAXX_DUMP_SOURCE_DIRECTORY=str(g))
  stem.with_suffix('.command.json').open('x').write(json.dumps(dict(command=cmd,cwd=str(c),environment_overrides=overrides,fixture_sha256=sha(fixture),binary_sha256=sha(exe),image_sha256=sha(exe.with_suffix('.pdmp')),timeout_seconds=240),indent=2));start=time.monotonic()
  with stem.with_suffix('.stdout').open('xb') as out,stem.with_suffix('.stderr').open('xb') as err:
   try:r=subprocess.run(cmd,cwd=c,env=dict(os.environ,**overrides),stdout=out,stderr=err,timeout=240);code,timed=r.returncode,False
   except subprocess.TimeoutExpired:code,timed=None,True
  result=dict(label=label,fixture=str(fixture),exit_code=code,timed_out=timed,elapsed_seconds=time.monotonic()-start,stdout_sha256=sha(stem.with_suffix('.stdout')),stderr_sha256=sha(stem.with_suffix('.stderr')));stem.with_suffix('.result.json').open('x').write(json.dumps(result,indent=2));results.append(result);outputs[label]=stem.with_suffix('.stdout').read_bytes();print(fixture.name,label,code,outputs[label].decode()[:1500],flush=True)
 comparison=dict(fixture=str(fixture),outputs_identical=outputs['gnu']==outputs['source312-final'],processes_successful=all(x['exit_code']==0 and not x['timed_out'] for x in results[-2:]));(p/('source312-final-call-ordinary-'+fixture.stem+'-comparison.json')).open('x').write(json.dumps(comparison,indent=2));print(comparison,flush=True)
(p/'source312-final-call-ordinary-results.json').open('x').write(json.dumps(results,indent=2))
