from pathlib import Path
import subprocess,json,hashlib,io,tarfile
p=Path(__file__).parent.resolve();root=p.parents[2];c=p.parent/'recovered-2026-10-06/bytecode-gc/emaxx';work=p.parent/'source312-final-portable-replay/emaxx';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();read=lambda f:json.loads(f.read_text());manifest=read(p/'source312-timer-development5-manifest.json');assert len(manifest)==552 and all(sha(c/n)==h for n,h in manifest.items());assert not work.exists();work.parent.mkdir(parents=True)
log=(p/'source312-final-portable-replay.log').open('xb')
def run(cmd,cwd=None):
 print(cmd,flush=True);subprocess.run(cmd,cwd=cwd,stdout=log,stderr=subprocess.STDOUT,check=True)
run(['git','clone','--shared','--no-checkout',str(root),str(work)])
run(['git','sparse-checkout','set','.cargo','src','tests','tools','compat'],work)
run(['git','checkout','--detach','447c84c13017f47878855273a2a0609f9f9edeb1'],work)
patch=p/'source312-timer-development5.patch';run(['git','apply','--check',str(patch)],work);run(['git','apply',str(patch)],work)
modes={n:(c/n).stat().st_mode & 0o777 for n in manifest};assert all(sha(work/n)==h and (work/n).stat().st_mode & 0o777==modes[n] for n,h in manifest.items());(p/'source312-final-modes.json').open('x').write(json.dumps(modes,indent=2))
run(['git','add','--',*sorted(manifest)],work)
complete=subprocess.check_output(['git','diff','--cached','--binary','21d20f0eec08f3c013d5d3eb3bd6e9cfc16b3199','--',*sorted(manifest)],cwd=work);(p/'source312-final-portable-complete.patch').open('xb').write(complete)
# Reconstruct main in a separate filesystem tree and apply the full patch there.
base=p.parent/'source312-final-portable-main-replay';base.mkdir();run(['git','init','-q',str(base)])
tracked=set(subprocess.check_output(['git','ls-tree','-r','--name-only','21d20f0eec08f3c013d5d3eb3bd6e9cfc16b3199'],cwd=root,text=True).splitlines());names=sorted(set(manifest)&tracked);data=subprocess.check_output(['git','-c','tar.umask=0022','archive','21d20f0eec08f3c013d5d3eb3bd6e9cfc16b3199','--',*names],cwd=root)
with tarfile.open(fileobj=io.BytesIO(data)) as archive:
 for member in archive.getmembers():assert not member.name.startswith('/') and '..' not in Path(member.name).parts
 archive.extractall(base)
run(['git','apply','--check',str(p/'source312-final-portable-complete.patch')],base);run(['git','apply',str(p/'source312-final-portable-complete.patch')],base)
assert all(sha(base/n)==h and (base/n).stat().st_mode & 0o777==modes[n] for n,h in manifest.items());assert all(sha(c/n)==h for n,h in manifest.items())
receipt=dict(status='both portable runtime replays match every byte and mode',source_inputs=552,base_commit='447c84c13017f47878855273a2a0609f9f9edeb1',main_commit='21d20f0eec08f3c013d5d3eb3bd6e9cfc16b3199',incremental_patch_sha256=sha(patch),complete_patch_sha256=sha(p/'source312-final-portable-complete.patch'),manifest_sha256=sha(p/'source312-timer-development5-manifest.json'),mode_manifest_sha256=sha(p/'source312-final-modes.json'),goal_complete=False,qualification='Reproduction of the isolated draft only; gate/release and application reviews remain separate.')
(p/'source312-final-portable-audit.json').open('x').write(json.dumps(receipt,indent=2));log.close();print(receipt)
