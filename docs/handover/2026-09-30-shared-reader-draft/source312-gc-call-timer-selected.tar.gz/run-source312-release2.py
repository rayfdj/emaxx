from pathlib import Path
import hashlib,json,os,subprocess,time,shutil,sys
from native_fixed_validation_support import audit_selected
p=Path(__file__).parent.resolve();c=p.parent/'recovered-2026-10-06/bytecode-gc/emaxx';g=p.parent/'rebuilt-2026-10-01/emacs';prefix='source312-release2';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();read=lambda f:json.loads(f.read_text());manifest=read(p/'source312-timer-development5-manifest.json');assert len(manifest)==552
extra=read(p/'source310-validation-input-recovery.json')['auxiliary_inputs'];target=c/'target/gc-development';overrides=dict(CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='2',LANG='C',LC_ALL='C',RUST_MIN_STACK='134217728',RUST_TEST_THREADS='1',EMAXX_GC_VERIFY='1',EMAXX_GNU_SOURCE_DIRECTORY=str(g),EMAXX_DUMP_SOURCE_DIRECTORY=str(g),EMACS_TEST_DIRECTORY=str(g/'test'),EMAXX_IMAGE_TEMPLATE='1',EMAXX_FIXTURE_IMAGE_DIR=str(p/'fixture-images-source312-release2'));env=dict(os.environ,**overrides)
unchanged=lambda:all(sha(c/n)==h for n,h in manifest.items()) and all(sha(c/n)==v['sha256'] for n,v in extra.items());state=dict(status='waiting for gate ordinary build',source_manifest='source312-timer-development5-manifest.json',candidate=str(c),results=[],goal_complete=False,helper_sha256=sha(Path(__file__)))
def save():(p/(prefix+'-state.json')).write_text(json.dumps(state,indent=2))
def run(stage,cmd,timeout=3600):
 assert unchanged();stem=prefix+'-'+stage;(p/(stem+'-command.json')).open('x').write(json.dumps(dict(command=cmd,cwd=str(c),environment_overrides=overrides,timeout_seconds=timeout),indent=2));state['status']='running '+stage;save();start=time.monotonic()
 with (p/(stem+'.log')).open('xb') as log:
  try:r=subprocess.run(cmd,cwd=c,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout);code,timed=r.returncode,False
  except subprocess.TimeoutExpired:code,timed=None,True
 result=dict(stage=stage,exit_code=code,timed_out=timed,elapsed_seconds=time.monotonic()-start,source_unchanged=unchanged());state['results'].append(result);(p/(stem+'-result.json')).open('x').write(json.dumps(result,indent=2));save();print(result,flush=True);assert code==0 and not timed and result['source_unchanged'],result
try:
 save()
 while not (p/'source312-timer-development5-ordinary-image-result.json').exists():
  assert unchanged();end=p/'source312-timer-development5-result.json';assert not end.exists(),read(end) if end.exists() else None;time.sleep(5)
 assert read(p/'source312-timer-development5-ordinary-image-result.json')['exit_code']==0
 run('build',['cargo','test','--locked','--release','--all-features','--lib','--no-run','--message-format=json'])
 messages=[json.loads(x) for x in (p/(prefix+'-build.log')).read_text().splitlines() if x.startswith('{')];artifacts=[x for x in messages if x.get('reason')=='compiler-artifact' and x['target']['name']=='emaxx' and x.get('profile',{}).get('test') and x.get('executable')];assert len(artifacts)==1 and not artifacts[0]['fresh'];binary=Path(artifacts[0]['executable']);retained=p/(prefix+'-libtest');shutil.copy2(binary,retained);assert sha(binary)==sha(retained);state.update(binary=str(binary),binary_sha256=sha(binary),retained_binary=str(retained));save()
 run('inventory',[str(binary),'--list']);inventory={x[:-6] for x in (p/(prefix+'-inventory.log')).read_text().splitlines() if x.endswith(': test')};prior={x[:-6] for x in (p/'source311-release-inventory.log').read_text().splitlines() if x.endswith(': test')};new={'lisp::native_comp::runtime::tests::native_automatic_gc_runs_statistics_and_hooks_under_gnu_inhibition','lisp::primitives::tests::bytecode_calls_observe_gc_hook_redefinition_and_gnu_collection_completion','lisp::primitives::tests::timer_snapshot_survives_canceling_and_collecting_later_entries'};assert inventory==prior|new and len(inventory)==3057
 focused=read(p/'source312-timer-development5-focused-command.json')['command'][3:];run('focused',[str(binary),'--exact','--test-threads=1',*focused]);state['focused']=audit_selected((p/(prefix+'-focused.log')).read_text(),focused);save()
 selected=sorted(set(read(p/'source311-release-selected-command.json')['command'][3:])|new);assert len(selected)==1068 and set(selected)<=inventory
 run('selected',[str(binary),'--exact','--test-threads=1',*selected]);state['selected']=audit_selected((p/(prefix+'-selected.log')).read_text(),selected);save()
 run('ordinary-build',['cargo','build','--locked','--release','--all-features','--bin','emaxx','--bin','make-fingerprint','--bin','compat-harness','--message-format=json'])
 env['EMAXX_IMAGE_FORCE']='1';run('ordinary-image',['sh','tools/build-image.sh',str(target/'release/emaxx')]);del env['EMAXX_IMAGE_FORCE'];state['ordinary_artifacts']={}
 for original in [target/'release/emaxx',target/'release/emaxx.pdmp']:
  copy=p/('source312-ordinary-'+original.name);shutil.copy2(original,copy);assert sha(copy)==sha(original);state['ordinary_artifacts'][str(original)]=dict(sha256=sha(original),immutable_copy=str(copy),bytes=copy.stat().st_size)
 state['status']='release focused and 1068 selected controls and ordinary build passed; differential and application audits pending'
except Exception as error:state.update(status='release validation stopped',error=repr(error))
finally:save();(p/(prefix+'-result.json')).open('x').write(json.dumps(state,indent=2));print(state['status'],state.get('error'),flush=True)
