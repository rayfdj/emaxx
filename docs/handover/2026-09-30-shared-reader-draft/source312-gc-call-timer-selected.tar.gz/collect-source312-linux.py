from pathlib import Path
import hashlib,json,subprocess,time
p=Path(__file__).parent.resolve();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
launch=json.loads((p/'source312-full-validation-launch.json').read_text());head=launch['commit'];assert head==json.loads((p/'source312-applied-commit.json').read_text())['commit']
pending={r['mode']:r['run']['databaseId'] for r in launch['runs']};assert len(pending)==3
state=dict(status='waiting for exact-source workflows',commit=head,pending=pending.copy(),finished={},helper_sha256=sha(Path(__file__)),launch_sha256=sha(p/'source312-full-validation-launch.json'),goal_complete=False)
def save(): (p/'source312-linux-collection-state.json').write_text(json.dumps(state,indent=2))
save()
try:
 while pending:
  for mode,run_id in list(pending.items()):
   cmd=['gh','run','view',str(run_id),'--repo','rayfdj/emaxx','--json','status,conclusion,headSha,jobs,createdAt,updatedAt,url']
   r=subprocess.run(cmd,capture_output=True,text=True,timeout=60)
   if r.returncode:
    state.setdefault('poll_errors',[]).append(dict(run_id=run_id,time=time.time(),exit_code=r.returncode,stderr=r.stderr));save();continue
   data=json.loads(r.stdout);assert data['headSha']==head
   state.setdefault('current',{})[mode]={k:data[k] for k in ['status','conclusion','url']};save()
   if data['status']!='completed':continue
   (p/f'source312-linux-{mode}-terminal.json').open('x').write(json.dumps(data,indent=2))
   destination=p/f'source312-linux-{mode}-artifacts';assert not destination.exists()
   cmd=['gh','run','download',str(run_id),'--repo','rayfdj/emaxx','--dir',str(destination)];start=time.monotonic()
   state['status']='downloading '+mode;save()
   r=subprocess.run(cmd,capture_output=True,text=True,timeout=900)
   (p/f'source312-linux-{mode}-download.log').open('x').write(r.stdout+r.stderr)
   receipt=dict(command=cmd,run_id=run_id,exit_code=r.returncode,elapsed_seconds=time.monotonic()-start)
   (p/f'source312-linux-{mode}-download.json').open('x').write(json.dumps(receipt,indent=2));assert r.returncode==0,receipt
   state['finished'][mode]=dict(run_id=run_id,conclusion=data['conclusion'],artifact_directory=str(destination),raw_audit='pending')
   pending.pop(mode);state['pending']=pending.copy();state['status']='waiting for remaining workflows' if pending else 'all raw artifacts downloaded; independent audits required';save()
  if pending:time.sleep(45)
except Exception as error:state.update(status='collection stopped',error=repr(error))
finally:
 state['helper_unchanged']=sha(Path(__file__))==state['helper_sha256'];save();(p/'source312-linux-collection-result.json').open('x').write(json.dumps(state,indent=2))
print(json.dumps(state),flush=True)
