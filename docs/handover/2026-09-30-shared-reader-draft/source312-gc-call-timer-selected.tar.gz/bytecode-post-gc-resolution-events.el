;; Ordinary diagnostic for bytecode.c:Bcall resolving the function after maybe_gc.
(progn
  (require 'bytecomp)
  (defvar stack-call-ready nil)
  (defvar stack-call-hook-ran nil)
  (defvar stack-call-events nil)
  (defvar stack-call-replacement nil)
  (defalias 'stack-call-target (byte-compile '(lambda (value) (list 'old (length value)))))
  (setq stack-call-replacement (byte-compile '(lambda (value) (list 'new (length value)))))
  (let ((caller (byte-compile '(lambda ()
                                (let ((argument (make-vector 100000 nil)))
                                  (setq stack-call-ready t)
                                  (stack-call-target argument))))))
    (garbage-collect)
    (let ((gc-cons-threshold 10000)
          (gc-cons-percentage 0)
          (post-gc-hook
           (list (lambda ()
                   (push (list stack-call-ready gcs-done) stack-call-events)
                   (when stack-call-ready
                     (setq stack-call-hook-ran t)
                     (fset 'stack-call-target stack-call-replacement))))))
      (garbage-collect)
      (let ((answer (funcall caller)))
        (list answer stack-call-hook-ran stack-call-ready stack-call-events gcs-done
              (byte-code-function-p caller)
              (byte-code-function-p (symbol-function 'stack-call-target)))))))
