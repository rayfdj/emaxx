from pathlib import Path
import hashlib, json, subprocess, sys, time, os

p = Path(__file__).parent.resolve()
c = p.parent / 'recovered-2026-10-06/bytecode-gc/emaxx'
binary = c / 'target/gc-development/release/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p / n).read_text())
manifest = read('source312-final-manifest.json')
g = p.parent / 'rebuilt-2026-10-01/emacs'
os.environ.update(EMACS_TEST_DIRECTORY=str(g / 'test'), EMAXX_GNU_SOURCE_DIRECTORY=str(g), EMAXX_DUMP_SOURCE_DIRECTORY=str(g))
recovery = read('source310-validation-input-recovery.json')
helpers = {n: sha(p / n) for n in [
    Path(__file__).name, 'run-source312-release2.py', 'source310-validation-input-recovery.json',
    'compare-native-unit312-final-fixtures.py', 'compare-source312-final-generated-loaded.py',
    'probe-native-unit312-final-file-one.py', 'probe-native-unit312-final-active.py',
    'probe-native-unit312-final-anonymous-one.py']}
state = dict(status='waiting for strict, selected and ordinary build', steps=[],
             helpers=helpers, goal_complete=False)

def unchanged():
    return (all(sha(c / n) == h for n, h in manifest.items())
            and all(sha(p / n) == h for n, h in helpers.items())
            and all(sha(c / n) == item['sha256'] and (c / n).stat().st_mode & 0o777 == item['mode']
                    for n, item in recovery['auxiliary_inputs'].items()))

def save():
    (p / 'source312-final-ordinary-queue-state.json').write_text(json.dumps(state, indent=2))

def run(stage, command):
    assert unchanged()
    state['status'] = 'running ' + stage
    save()
    record = dict(command=command, working_directory=str(p), timeout_seconds=1800,
                  helpers=helpers, source_manifest='source312-final-manifest.json')
    (p / ('source312-final-ordinary-queue-' + stage + '-command.json')).open('x').write(json.dumps(record, indent=2))
    start = time.monotonic()
    with (p / ('source312-final-ordinary-queue-' + stage + '.log')).open('xb') as log:
        try:
            result = subprocess.run(command, cwd=p, stdin=subprocess.DEVNULL,
                                    stdout=log, stderr=subprocess.STDOUT, timeout=1800)
            code, timeout = result.returncode, False
        except subprocess.TimeoutExpired:
            code, timeout = None, True
    state['steps'].append(dict(stage=stage, exit_code=code, timed_out=timeout,
                              elapsed_seconds=time.monotonic()-start, inputs_unchanged=unchanged()))
    save()

def compare_pair(name, gnu_stem, candidate_stem, dotted=False):
    suffix = '.result.json' if dotted else '-result.json'
    stems = [p / gnu_stem, p / candidate_stem]
    results = [json.loads(Path(str(stem) + suffix).read_text()) for stem in stems]
    stdout = [Path(str(stem) + '.stdout').read_bytes() for stem in stems]
    stderr = [Path(str(stem) + '.stderr').read_bytes() for stem in stems]
    commands = [json.loads(Path(str(stem) + ('.command.json' if dotted else '-command.json')).read_text()) for stem in stems]
    valid = all(r['exit_code'] == 0 and not r['timed_out'] and r['inputs_unchanged'] for r in results)
    valid = valid and all(all(sha(Path(f)) == h for f, h in command['inputs'].items()) for command in commands)
    valid = valid and all(hashlib.sha256(out).hexdigest() == r['stdout_sha256'] and hashlib.sha256(err).hexdigest() == r['stderr_sha256'] for out, err, r in zip(stdout, stderr, results))
    exact = stdout[0] == stdout[1] and stderr[0] == stderr[1]
    record = dict(passed=valid and exact and bool(stdout[0]) and not stderr[0],
                  exact_match=exact, outcomes=results, source_unchanged=unchanged(), goal_complete=False)
    (p / ('source312-final-ordinary-' + name + '-comparison.json')).open('x').write(json.dumps(record, indent=2))
    return record['passed']

save()
try:
    while not (p / 'source312-release2-result.json').exists():
        time.sleep(20)
    released = read('source312-release2-result.json')
    assert released['status'].startswith('release focused and 1068 selected controls and ordinary build passed')
    assert read('source312-final-portable-audit.json')['source_inputs'] == 552
    (p / 'source312-final-ordinary-artifacts.json').open('x').write(json.dumps(released['ordinary_artifacts'], indent=2))
    names = list(read('source304-selected-audit.json')['ordinary_results']) + [
        'native-subr-authority', 'native-subr-c-names', 'native-subr-consumers', 'native-unit-authority', 'bytecode-stack-layout', 'vm-stack-capacity', 'call-after-gc-redefinition', 'timer-snapshot-gc']
    assert len(names) == len(set(names)) == 56
    run('fixtures', [sys.executable, '-B', str(p / 'compare-native-unit312-final-fixtures.py'), 'source312-final', str(c), *names])
    run('generated', [sys.executable, '-B', str(p / 'compare-source312-final-generated-loaded.py')])
    gnu = p.parent / 'rebuilt-2026-10-01/emacs/src/emacs'
    run('file-lifecycle-gnu', [sys.executable, '-B', str(p / 'probe-native-unit312-final-file-one.py'), 'gnu', str(gnu)])
    run('active-lifecycle-gnu', [sys.executable, '-B', str(p / 'probe-native-unit312-final-active.py'), 'gnu', str(gnu)])
    run('anonymous-lifecycle-gnu', [sys.executable, '-B', str(p / 'probe-native-unit312-final-anonymous-one.py'), 'gnu', str(gnu)])
    run('file-lifecycle', [sys.executable, '-B', str(p / 'probe-native-unit312-final-file-one.py'), 'source312-final', str(binary)])
    run('active-lifecycle', [sys.executable, '-B', str(p / 'probe-native-unit312-final-active.py'), 'source312-final', str(binary)])
    run('anonymous-lifecycle', [sys.executable, '-B', str(p / 'probe-native-unit312-final-anonymous-one.py'), 'source312-final', str(binary)])
    pairs = {
        'file-lifecycle': compare_pair('file-lifecycle', 'source312-final-file-lifecycle-gnu/execute', 'source312-final-file-lifecycle-source312-final/execute'),
        'active-lifecycle': compare_pair('active-lifecycle', 'source312-final-active-lifecycle-gnu/execute', 'source312-final-active-lifecycle-source312-final/execute'),
        'anonymous-lifecycle': compare_pair('anonymous-lifecycle', 'source312-final-lifecycle-candidate-gnu', 'source312-final-lifecycle-candidate-source312-final', dotted=True),
    }
    state['lifecycle_results'] = pairs
    passed = (all(r['exit_code'] == 0 and not r['timed_out'] and r['inputs_unchanged'] for r in state['steps'])
              and all(read('source312-final-ordinary-' + n + '-comparison.json')['passed'] for n in names)
              and read('source312-final-generated-loaded-comparison.json')['passed'] and all(pairs.values()))
    state.update(status='ordinary comparisons passed; independent raw audit required' if passed else 'ordinary comparisons failed',
                 fixture_comparisons=len(names), generated_comparisons=1, lifecycle_comparisons=3)
except Exception as error:
    state.update(status='ordinary comparison queue stopped', error=repr(error))
finally:
    save()
    (p / 'source312-final-ordinary-queue-result.json').open('x').write(json.dumps(state, indent=2))
print(json.dumps(state), flush=True)
