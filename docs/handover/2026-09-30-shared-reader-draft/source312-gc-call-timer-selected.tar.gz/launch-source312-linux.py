from pathlib import Path
import subprocess,json,time,sys
p=Path(__file__).parent.resolve();head=json.loads((p/'source312-applied-commit.json').read_text())['commit']
assert subprocess.check_output(['git','ls-remote','origin','refs/heads/runtime-char-tables'],text=True).split()[0]==head
state=dict(commit=head,repo='rayfdj/emaxx',branch='runtime-char-tables',status='launching',runs=[],goal_complete=False)
query=['gh','run','list','--repo','rayfdj/emaxx','--workflow','frozen-run.yml','--branch','runtime-char-tables','--event','workflow_dispatch','--limit','35','--json','databaseId,headSha,status,conclusion,createdAt,url']
read=lambda:json.loads(subprocess.check_output(query,text=True))
for mode in ['core-runtime-pair','rust','frozen']:
 before={r['databaseId'] for r in read()}
 command=['gh','workflow','run','frozen-run.yml','--repo','rayfdj/emaxx','--ref','runtime-char-tables','-f','validation='+mode]
 if mode=='core-runtime-pair':command+=['-f','baseline_revision=447c84c13017f47878855273a2a0609f9f9edeb1']
 r=subprocess.run(command,text=True,capture_output=True);assert r.returncode==0,(r.stdout,r.stderr)
 for attempt in range(30):
  after=[row for row in read() if row['databaseId'] not in before and row['headSha']==head]
  if len(after)==1:break
  assert len(after)<=1,after
  time.sleep(2)
 else:raise AssertionError('new exact-head workflow not found: '+mode)
 row=dict(mode=mode,command=command,run=after[0]);state['runs'].append(row)
 (p/'source312-linux-launch-state.json').write_text(json.dumps(state,indent=2));print(json.dumps(row),flush=True)
state['status']='three exact-source Linux workflows launched'
(p/'source312-full-validation-launch.json').open('x').write(json.dumps(state,indent=2))
print(state['status'])
