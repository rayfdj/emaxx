from pathlib import Path
import ast,gzip,hashlib,io,json,re,tarfile
p=Path(__file__).parent.resolve();root=p.parents[2]
candidate=p.parent/'recovered-2026-09-30/string-storage/emaxx'
out=root/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda n:json.loads((p/n).read_text())
old,new=read('source269-manifest.json'),read('source270-manifest.json')
assert len(old)==len(new)==510 and old.keys()==new.keys()
assert all(sha((candidate/n).read_bytes())==h for n,h in new.items())
changed=[n for n in new if old[n]!=new[n]]
assert changed==['src/lisp/primitives/coding.rs','src/lisp/primitives/tests.rs']
for stage in ['check','fmt','clippy','diff']:
    result=read('source270-'+stage+'-result.json')
    assert result['exit_code']==0 and result['source_unchanged']
    assert not re.search(r'^warning(?:\[.*\])?:',(p/('source270-'+stage+'.log')).read_text(),re.M)
assert read('source269-focused-audit.json')['counts']==dict(ok=201,FAILED=2,ignored=2)
assert read('source269-storage-failure-audit.json')['pure_storage_matches']==94
assert read('source270-storage-patch-replay-audit.json')['status']=='exact'
for item in read('source269-focused-retained-inputs.json')['files']:
    assert sha(Path(item['original']).read_bytes())==sha(Path(item['artifact']).read_bytes())==item['sha256']
published=read('source261-manifest.json')
assert len(published)==488 and all(sha((root/n).read_bytes())==h for n,h in published.items())
launch=read('source270-validation-launch.json')
assert sha((p/'queue-string-storage270-validation.py').read_bytes())==launch['helper_sha256']
preparation=dict(source_inputs_verified=510,changed_from269=changed,change='copy-sequence always uses ordinary constructors, including empty pure/restored strings; remove unreachable host-text copy path; drop fixture-owned interpreters before the separate initialized-image assertion',gnu_fixture_bytes_unchanged=True,strict_checks='zero-warning pass',patches='both exact',published_source261_unchanged=True,prior_failed_counts=dict(ok=201,FAILED=2,ignored=2),launch=launch,qualification='Preparation only. Source269 remains failed. Both failures are diagnosed from raw verdicts and actual GNU C; runtime source261 is unchanged. No source270 runtime pass inferred.')
with (p/'source270-storage-preparation-audit.json').open('x') as f:json.dump(preparation,f,indent=2)
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
files={}
for path in p.iterdir():
    n=path.name
    if not path.is_file():continue
    failed=n.startswith('source269-') and any(n.startswith('source269-'+s) for s in ['gate-','focused-','storage-failure','validation-']) and path.suffix in ['.json','.log']
    prepared=n.startswith('source270-') and any(n.startswith('source270-'+s) for s in ['format','manifest','freeze','unformatted','incremental','portable','check','fmt','clippy','diff','storage','validation-launch']) and path.suffix in ['.json','.log','.patch']
    if failed or prepared:files[n]=path
for n in ['source269-manifest.json','source269-storage-patch-replay-audit.json','audit-source269-storage-failure.py','audit-source270-storage-patches.py','audit-source270-selected.py','launch-source270-validation.py','queue-string-storage270-validation.py','check-string-storage-callers.py','freeze-string-storage-callers.py','run-string-storage-focused.py','audit-string-storage-focused.py','run-string-storage-release.py','audit-string-storage-release.py','test-string-storage-broad.py','build-string-storage-ordinary.py','compare-string-storage-fixtures.py','audit-source261-compare-strings.py','package-source196-failure-and197-results.py',Path(__file__).name]:
    assert (p/n).is_file(),n
    files[n]=p/n
package('source270-string-storage-empty-copy',files,dict(preparation=preparation,failed_source269=read('source269-focused-audit.json'),diagnosis=read('source269-storage-failure-audit.json'),qualification='Closed failed source269 focused result plus portable strict-checked source270 continuation. Source269 is201pass/twofail/twoexistingignores; no broad,release,ordinary stage ran. Source270 preserves all GNU expected bytes and fixes actual empty-copy allocation plus test-owned image lifetimes;205focused selectors,1059affected tests/profile and33ordinary fixtures run under98240. Only immutable strict/launch evidence is packaged for270. Root261 unchanged. Full architecture,platform correctness and locked performance requirements remain open.'))
