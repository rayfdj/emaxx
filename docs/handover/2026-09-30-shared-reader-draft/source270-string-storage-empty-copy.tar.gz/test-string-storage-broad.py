from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys,time
p=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28')
root=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/string-storage/emaxx')
tag='source'+sys.argv[1]
profile=sys.argv[2]
manifest=json.loads((p/(tag+'-manifest.json')).read_text())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def unchanged():return all(sha(root/name)==value for name,value in manifest.items())
def save(suffix,data):
    with (p/(tag+'-'+suffix+'.json')).open('x') as stream:json.dump(data,stream,indent=2);stream.write('\n')
env={'CARGO_TARGET_DIR':'/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/string-storage/emaxx/target/string-storage-validation','CARGO_BUILD_JOBS':'1',
     'LANG':'C','LC_ALL':'C','RUST_MIN_STACK':'134217728','RUST_TEST_THREADS':'1','EMAXX_GC_VERIFY':'1','EMAXX_IMAGE_TEMPLATE':'1',
     'EMAXX_FIXTURE_IMAGE_DIR':str(p/('fixture-images-'+tag)),
     'EMAXX_GNU_SOURCE_DIRECTORY':'/Users/nbmhqa186/projects/emaxx/target/runtime-goal/rebuilt-2026-10-01/emacs',
     'EMAXX_DUMP_SOURCE_DIRECTORY':'/Users/nbmhqa186/projects/emaxx/target/runtime-goal/rebuilt-2026-10-01/emacs',
     'EMACS_TEST_DIRECTORY':'/Users/nbmhqa186/projects/emaxx/target/runtime-goal/rebuilt-2026-10-01/emacs/test'}
def run(stage,command,extra=None):
    assert unchanged()
    save(stage+'-command',{'command':command,'working_directory':str(root),'environment_override':env,**(extra or {})})
    start=time.monotonic()
    with (p/(tag+'-'+stage+'.log')).open('x') as log:
        result=subprocess.run(command,cwd=root,env={**os.environ,**env},stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,timeout=3600)
    record={'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,'source_unchanged':unchanged()}
    save(stage+'-result',record)
    print(stage,json.dumps(record),flush=True)
    return result.returncode or (0 if record['source_unchanged'] else 2)
binary=p/(tag+'-'+profile+'-libtest')
command=json.loads((p/(tag+'-'+profile+'-controls-command.json')).read_text())
assert sha(binary)==command['binary_sha256']
inventory=[line[:-6] for line in (p/(tag+'-'+profile+'-inventory.log')).read_text().splitlines() if line.endswith(': test')]
names=[name for name in inventory if name.startswith(('lisp::bytecode::','lisp::native_comp::runtime::','lisp::primitives::pdumper::','lisp::primitives::tests::','lisp::reader::','lisp::types::','lisp::primitives::compat_runtime_tests::'))]
assert len(names)==1059 and len(names)==len(set(names))
common_inventory=[line[:-6] for line in (p/'source255-gate-inventory.log').read_text().splitlines() if line.endswith(': test')]
common_names=[name for name in common_inventory if name.startswith(('lisp::bytecode::','lisp::native_comp::runtime::','lisp::primitives::pdumper::','lisp::primitives::tests::','lisp::reader::','lisp::types::'))]
assert len(common_names)==957 and set(common_names)<=set(names)
prior=json.loads((p/('source249-'+profile+'-broad-command.json')).read_text())['selected_inventory']
assert set(prior)<=set(names) and len(prior)==955
preceding=json.loads((p/('source261-'+profile+'-broad-command.json')).read_text())['selected_inventory']
assert len(preceding)==962 and set(preceding)<=set(names)
ranges=json.loads((p/'source263-gate-broad-command.json').read_text())['selected_inventory']
assert len(ranges)==1054 and set(ranges)<=set(names)
print('Selected broad existing modules:',len(names),'tests',flush=True)
code=run(profile+'-broad',[str(binary),*names,'--exact','--nocapture','--test-threads=1'],{'binary_sha256':sha(binary),'selected_inventory':names,'qualification':'All preceding 962 source261 affected controls, six unchanged GNU comparison/casing fixtures, all86 compatibility-runtime controls, all1054 source263 controls, and five new string-storage/GC/dump controls. The original Unicode comparison retains its GNU assertions with proper Lisp initialization and adds bare/empty-table coverage; no selector, expectation or timeout is dropped.'})
print((p/(tag+'-'+profile+'-broad.log')).read_text()[-1500:],flush=True)
sys.exit(code)
