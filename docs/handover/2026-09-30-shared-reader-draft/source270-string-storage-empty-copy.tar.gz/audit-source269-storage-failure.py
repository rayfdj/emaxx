from pathlib import Path
import ast,hashlib,json,re
p=Path(__file__).parent.resolve();candidate=p.parent/'recovered-2026-09-30/string-storage/emaxx';gnu=p.parent/'rebuilt-2026-10-01/emacs'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
read=lambda n:json.loads((p/n).read_text())
manifest=read('source269-manifest.json')
assert len(manifest)==510 and all(sha(candidate/n)==h for n,h in manifest.items())
audit=read('source269-focused-audit.json')
assert audit['counts']==dict(ok=201,FAILED=2,ignored=2)
node=next(n for n in ast.parse((p/'audit-source261-compare-strings.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='parse')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<retained-lossless-lisp-parser>','exec'))
raw=(p/'source269-gate-controls.log').read_text()
def block(name):
    m=re.search(r'^test lisp::primitives::tests::'+name+r' \.\.\. ',raw,re.M)
    assert m
    stop=raw.find('\ntest ',m.end())
    assert stop>=0
    return raw[m.end():stop]
pure=block('pure_strings_preserve_gnu_identity_write_protection_and_error_order')
assert 'src/lisp/primitives/tests.rs:13404:' in pure
left,right=[ast.literal_eval(re.search(r'^\s*'+side+r': (".*")$',pure,re.M)[1]) for side in ['left','right']]
expected=p/'source261-probe-string-pure-storage-values-gnu.stdout'
assert right.encode()==expected.read_bytes()
a,b=parse(left),parse(right)
assert len(a)==len(b)==96
wrong=[dict(key=x[:3],actual=x[3:],gnu=y[3:]) for x,y in zip(a,b) if x!=y]
assert [row['key'] for row in wrong]==[['0','t','7'],['1','t','7']]
case=block('subr_frontier_compare_strings_uses_gnu_simple_upcase_canonicalization')
assert 'src/test_support.rs:387:' in case and 'is already loaded in this process' in case
assert 'cl-preloaded-6e6a1f4e-b7e4c17d.eln' in case
sequence_source=(gnu/'src/fns.c').read_text()
assert 'Lisp_Object val = STRING_MULTIBYTE (arg)' in sequence_source and 'make_uninit_multibyte_string (chars, bytes)' in sequence_source
assert 'if (!length)\n    return empty_unibyte_string;' in (gnu/'src/alloc.c').read_text()
assert 'if (!nbytes)\n    return empty_multibyte_string;' in (gnu/'src/alloc.c').read_text()
record=dict(status='failed',counts=audit['counts'],source_inputs_verified=510,raw_log_sha256=sha(p/'source269-gate-controls.log'),pure_storage_rows=96,pure_storage_matches=94,pure_storage_differences=wrong,gnu_expected_sha256=sha(expected),pure_storage_cause='shared_string_copy returned every zero-length object unchanged, retaining PURE_P. GNU Fcopy_sequence always uses ordinary constructors, yielding the corresponding normal empty singleton.',case_fixture_cause='The test retained its first initialized interpreter while the common assertion helper loaded a second image. The loader rejected a still-loaded native compilation unit before the added live-table assertion. Original dumped and bare assertions preceding the helper passed.',gnu_sources={n:sha(gnu/n) for n in ['src/fns.c','src/alloc.c','src/casetab.c','lisp/loadup.el','lisp/international/characters.el']},unexecuted=['affected gate','release','ordinary comparisons'],qualification='Selected focused evidence only. Source269 remains failed and unapplied; raw outputs and expected GNU bytes remain unchanged. Correct the actual empty-copy allocation path and release test-owned interpreters before the independent initialized fixture. Public runtime ownership remains an open full-goal requirement.')
with (p/'source269-storage-failure-audit.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps({k:record[k] for k in ['status','counts','pure_storage_rows','pure_storage_matches','pure_storage_cause','case_fixture_cause']},indent=2))
