from pathlib import Path
import hashlib, json, subprocess, sys
p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/string-storage/emaxx'
tag = 'source' + sys.argv[1]
assert sys.argv[1].isdecimal()
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
files = [*root.joinpath('src').rglob('*.rs'), *root.joinpath('tests').rglob('*')]
files += [root / name for name in ['Cargo.toml', 'Cargo.lock', 'build.rs', 'tools/ttydiff.py', 'tools/fixtures/fieldnotes.org', 'tools/fixtures/fake_lsp_server.py']]
files += list(root.joinpath('.cargo').glob('*'))
files += [root / name for name in ['compat/emacs_compat_runner.el', 'src/lisp/bytecode/fixture-oracle-30.2.elc', 'src/lisp/bytecode/fixture-oracle2-30.2.elc', 'src/lisp/bytecode/fixture-oracle3-30.2.elc']]
manifest = {str(file.relative_to(root)): sha(file) for file in sorted(set(files)) if file.is_file()}
assert len(manifest) == 510
assert json.loads((p / (tag + '-manifest.json')).read_text()) == manifest
untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=root, text=True).splitlines()
extra = b''
for name in sorted(set(untracked) & set(manifest)):
    result = subprocess.run(['git', 'diff', '--no-index', '--binary', '--', '/dev/null', name], cwd=root, capture_output=True)
    assert result.returncode == 1 and not result.stderr
    extra += result.stdout
patches = {}
for label, base in [('portable-incremental', 'e6120bcee99206d0b0c2f29d3429280bd7ad7024'),
                    ('portable-complete', '21d20f0eec08f3c013d5d3eb3bd6e9cfc16b3199')]:
    patch = subprocess.check_output(['git', 'diff', '--binary', base, '--', *sorted(manifest)], cwd=root) + extra
    target = p / (tag + '-' + label + '.patch')
    with target.open('xb') as f:
        f.write(patch)
    patches[label] = dict(base=base, sha256=sha(target), bytes=len(patch))
record = dict(inputs=510, patches=patches, candidate=str(root), goal_complete=False,
              qualification='Isolated compact-header and pure-string repair atop frozen source263. Direct32-byte header plus16-byte checked-borrow/allocator metadata; canonical empty forms; distinct permanent pure allocations, write protection, no-op handling and dump identity. Ordinary data still separately boxed and property spans retained, with sblocks, real intervals, physical accounting and ownership unfinished. Five stale RefCell callers are converted after preserved source264 compiler failure. The original Unicode comparison keeps its dumped-GNU assertions in an initialized interpreter and adds bare/empty-live-table coverage, following casetab.c and the new ordinary oracle fixture. Runtime root source261 and failed source263 remain unchanged. Strict and runtime evidence are separate; preserve every failure and do not infer completion or performance.')
with (p / (tag + '-freeze.json')).open('x') as f:
    json.dump(record, f, indent=2)
print(json.dumps(record, indent=2))
