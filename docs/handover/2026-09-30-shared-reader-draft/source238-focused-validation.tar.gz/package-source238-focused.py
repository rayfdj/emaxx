from pathlib import Path
import ast,gzip,hashlib,io,json,shutil,tarfile
p=Path(__file__).parent.resolve();out=p.parents[2]/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest()
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
audit=json.loads((p/'source238-focused-audit.json').read_text());assert audit['passed']==101 and len(audit['ignored'])==2
retained=p/'source238-focused-retained-inputs';retained.mkdir()
binary=p/'source238-gate-libtest';digest=sha(binary.read_bytes());images=list((p/'fixture-images-source238').glob('loadup-'+digest[:8]+'-*.pdmp'));assert len(images)==1
files=[]
for source in [binary,*images]:
 target=retained/source.name;digest=sha(source.read_bytes());shutil.copy2(source,target)
 assert sha(source.read_bytes())==sha(target.read_bytes())==digest
 files.append({'original':str(source),'retained':str(target),'sha256':digest,'bytes':target.stat().st_size})
with (p/'source238-focused-retained-inputs.json').open('x') as f:json.dump({'files':files,'qualification':'Retained after focused gate; no per-test image-use transcript.'},f,indent=2)
names=['source238-focused-audit.json','audit-source238-focused.py','source238-focused-retained-inputs.json','source238-manifest.json','source238-complete.patch','source238-incremental.patch','source238-gate-inventory.txt','source238-validation-launch.json','source238-full-gate-launch.json','run-source238-validation.py','run-source238-full-gate.py','check-source238.py','static-source238.py','test-source238-controls.py','build-source238.py','validate-source238-rx.py',Path(__file__).name]
for stage in ['check','fmt','clippy','diff','gate-build','gate-controls']:
 for suffix in ['-command.json','-result.json','.log']:names.append('source238-'+stage+suffix)
package('source238-focused-validation', {name:p/name for name in names}, {'focused':audit,'retained_files':files,'qualification':'Combined 446-input correctness candidate passes strict checks and all 101 selected tests with two existing ignores. Full macOS supervisor30236 is active. Ordinary executable build and unchanged upstream rx comparisons remain pending in supervisor27314. No complete source238 platform, frozen, terminal, release or performance pass claimed.'})
