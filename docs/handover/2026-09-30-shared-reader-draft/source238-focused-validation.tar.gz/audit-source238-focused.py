from pathlib import Path
import hashlib,json,re
p=Path(__file__).parent.resolve();root=p.parent/'recovered-2026-09-30/rx-repair/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();read=lambda f:json.loads((p/f).read_text())
manifest=read('source238-manifest.json');assert all(sha(root/f)==h for f,h in manifest.items())
c=read('source238-gate-controls-command.json');r=read('source238-gate-controls-result.json');assert r['exit_code']==0 and r['source_unchanged']
names=c['selected_inventory'];assert len(names)==len(set(names))==103
assert sha(p/'source238-gate-libtest')==c['binary_sha256']
ignored=['tty::tty_differential_end_to_end','tty::tty_smoke_end_to_end']
raw=(p/'source238-gate-controls.log').read_text()
assert re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',raw,re.M)==[('ok','101','0','2')]
starts=list(re.finditer(r'^test (\S+) \.\.\. ',raw,re.M))
assert [m[1] for m in starts]==names
for index,m in enumerate(starts):
 end=starts[index+1].start() if index+1<len(starts) else raw.rindex('test result:')
 verdict=raw[m.end():end].strip()
 if m[1] in ignored:assert verdict.startswith('ignored,'),m[1]
 else:assert re.search(r'(?:^|\s)ok$',verdict),m[1]
for stage in ['check','fmt','clippy','diff','gate-build']:
 r=read('source238-'+stage+'-result.json');assert r['exit_code']==0 and r['source_unchanged']
 raw=(p/('source238-'+stage+'.log')).read_text();assert not re.search(r'^warning(?:\[.*\])?:',raw,re.M)
 for line in raw.splitlines():
  try:d=json.loads(line)
  except json.JSONDecodeError:continue
  assert d.get('message',{}).get('level') not in ['warning','error']
record={'status':'strict and combined focused gate pass','inputs':len(manifest),'passed':101,'ignored':ignored,'names':names,'gate_binary_sha256':c['binary_sha256'],'qualification':'All 37 source234 controls plus the complete original TTY inventory, four display-table controls and two new GNU reader/mapconcat fixtures pass: 101 passed, zero failed, two existing TTY end-to-end ignores. Every raw verdict and strict-check log is verified. Complete macOS/Linux, release, ordinary rx and terminal validation remain separate.'}
with (p/'source238-focused-audit.json').open('x') as f:json.dump(record,f,indent=2)
print(record['status'],record['passed'],len(ignored))
