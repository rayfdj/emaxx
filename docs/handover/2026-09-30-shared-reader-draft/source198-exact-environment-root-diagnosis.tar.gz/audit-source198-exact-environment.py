from pathlib import Path
import hashlib
import json
import re

p = Path(__file__).parent.resolve()
artifact = next((p / 'linux-source198-exact-environment-artifacts').rglob('rust-exact-roots/summary.json')).parent
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
s = json.loads((artifact / 'summary.json').read_text())
state = json.loads((p / 'source198-linux-exact-environment-final-state.json').read_text())
assert state['databaseId'] == 36758535929 and state['status'] == 'completed' and state['conclusion'] == 'failure'
assert state['headSha'] == 'bdc09fe48b3940c3e294e2865ff02ead94b394ba'
assert s['source_revision'] == '7e45db47438a39e97658bddaceba903e0e41c186'
assert s['artifact_run'] == '36748039991'
assert all(s[key] for key in ['source_matches_original', 'source_unchanged', 'binary_unchanged', 'images_unchanged_after_plain', 'images_unchanged_after_child_controls'])
inputs = json.loads((artifact / 'source-before.json').read_text())
manifest = json.loads((p / 'source198-manifest.json').read_text())
assert len(inputs) == 398 and all(manifest[name] == digest for name, digest in inputs.items())
original = next((artifact / 'original').rglob('rust/summary.json')).parent
retained = original / 'retained-inputs'
retention = json.loads((retained / 'manifest.json').read_text())
assert retention['gate_summary_sha256'] == sha(original / 'summary.json')
for entry in retention['files']:
    path = retained / entry['artifact']
    assert path.stat().st_size == entry['bytes'] and sha(path) == entry['sha256']
assert sha(retained / 'libtest') == s['binary_sha256'] == '89058fe557e1d3138199c8c6d905c9ca502b03af38b218a6485c723254d19a65'
assert list(s['restored_images'].values()) == ['93471768b88dff7b9d83ee62c4e57b31994f3195890e42d9ae2595b842e38754']

expected_name = 'lisp::primitives::tests::suspended_bytecode_retains_operand_and_unwind_roots'
failure = '  left: "((1 t 0) (1 t 1))"\n right: "((1 t 0) (1 t 0))"'
verdict = r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;'
controls = []
for key, filename, failed, summaries in [
        ('plain', 'plain.log', True, 2),
        ('plain_child', 'plain-child.log', True, 1),
        ('plain_child_with_observer_environment', 'plain-child-with-observer.log', False, 1)]:
    raw = (artifact / filename).read_text()
    result = s[key]
    assert result['exit_code'] == (101 if failed else 0) and not result['timed_out']
    rows = re.findall(verdict, raw)
    assert len(rows) == summaries
    assert all(row[:5] == (('FAILED', '0', '1', '0', '0') if failed else ('ok', '1', '0', '0', '0')) for row in rows)
    assert result['executed_tests'] == [expected_name] * summaries
    if failed:
        assert failure in raw
    controls.append({'log': filename, 'exit_code': result['exit_code'], 'sha256': sha(artifact / filename)})
assert s['plain_child']['command'] == s['plain_child_with_observer_environment']['command']

runs = []
assert len(s['debugger_runs']) == 5
for result in s['debugger_runs']:
    raw = (artifact / result['log']).read_text()
    assert result['exit_code'] == 101 and not result['timed_out'] and result['images_unchanged']
    assert result['executed_tests'] == [expected_name]
    assert not result['callback_errors'] and not re.search(r'^(?:Python Exception|Traceback \(most recent call last\):)', raw, re.M)
    assert re.findall(verdict, raw) == [('FAILED', '0', '1', '0', '0', '2961')]
    assert failure in raw
    events = [json.loads(line.removeprefix('EXACT_ROOT ')) for line in raw.splitlines() if line.startswith('EXACT_ROOT ')]
    assert events == json.loads((artifact / result['trace']).read_text()) and len(events) == result['trace_events'] == 22
    watches = [event['key'] for event in events if event['event'] == 'watch installed']
    assert len(watches) == 2 and watches == result['watched_keys']
    assert len([event for event in events if event['event'] == 'collection sources']) == 4
    marks = [event for event in events if event['event'] == 'mark bit changed' and event['marked'] and event['retaining_native_root']]
    assert len(marks) == 2 and [event['epoch'] for event in marks] == [4, 5]
    for event in marks:
        assert event['key'] == watches[1]
        root = event['retaining_native_root']
        base = int(root['root'], 16) & ~7
        assert root['payload_words'][1] == watches[1]
        assert len(root['source_matches']) == 1
        match = root['source_matches'][0]
        assert match['kind'] == 'native stack' and int(match['raw'], 16) == base + 1
        assert len(match['frames']) == 1 and match['frames'][0]['function'].endswith('::eval_call')
    last = marks[-1]['retaining_native_root']
    assert last['source_matches'][0]['frames'][0]['offset'] == 32
    runs.append({'log': result['log'], 'trace_sha256': sha(artifact / result['trace']),
                 'exit_code': result['exit_code'], 'watched_key': watches[1],
                 'retaining_root': last, 'callback_errors': 0})

record = {'status': 'audited failure and retaining root', 'ci_run': state['databaseId'],
          'source_inputs_verified': len(inputs), 'binary_sha256': s['binary_sha256'],
          'controls': controls, 'debugger_runs': runs,
          'disassembly_sha256': sha(p / 'source198-retained-eval-call-disassembly-v2.txt'),
          'diagnosis': 'With original artifacts, the direct child fails and adding only the observer variable makes it pass. All five debugger children with that variable removed reproduce the original failure. Each final collection marks the second key through a cons reached from exactly one native stack word: cons base + 1, in eval_call at stack offset 32. Retained-binary disassembly shows a one-byte ConsSlot field-selector store at offset 32. GNU live_cons_holding accepts offsets 0, 3 and 8; Emaxx currently strips tag bits before accepting arbitrary cons interiors.',
          'qualification': 'No runtime repair or final-source pass is established. The retained source198 failure remains failed. Observer-environment control establishes a process-layout sensitivity, not a timing or performance result.'}
with (p / 'source198-exact-environment-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: value for key, value in record.items() if key != 'debugger_runs'}, indent=2))
