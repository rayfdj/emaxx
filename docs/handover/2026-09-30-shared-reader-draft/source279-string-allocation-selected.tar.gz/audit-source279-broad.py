from pathlib import Path
import hashlib, json, re, sys

p = Path(__file__).parent.resolve()
c = p.parent / 'recovered-2026-09-30/string-allocation-recovery/emaxx'
profile = sys.argv[1]
assert profile in ['gate', 'release']
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p / n).read_text())
m = read('source279-manifest.json')
assert len(m) == 511 and all(sha(c / n) == h for n, h in m.items())
command = read('source279-' + profile + '-broad-command.json')
result = read('source279-' + profile + '-broad-result.json')
assert sha(Path(command['command'][0])) == command['binary_sha256']
names = command['selected_inventory']
assert len(names) == len(set(names)) == 1067
assert command['command'][1:] == names + ['--exact', '--nocapture', '--test-threads=1']
assert set(read('source276-gate-broad-command.json')['selected_inventory']) <= set(names)
log = (p / ('source279-' + profile + '-broad.log')).read_text()
starts = list(re.finditer(r'^test (\S+) \.\.\. ', log, re.M))
assert [match[1] for match in starts] == names
observed = {}
for i, match in enumerate(starts):
    if i + 1 < len(starts):
        end = starts[i + 1].start()
    else:
        end = log.find('\nfailures:', match.end())
        if end < 0:
            end = log.index('\ntest result:', match.end())
    body = log[match.end():end]
    status = re.findall(r'(?:^|\s)(ok|FAILED|ignored)(?:,[^\n]*)?\s*\Z', body)
    assert len(status) == 1, (match[1], body[-500:])
    observed[match[1]] = status[0]
counts = {status: list(observed.values()).count(status) for status in ['ok', 'FAILED', 'ignored']}
summary = re.search(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; 0 measured; (\d+) filtered out;', log, re.M)
assert summary and tuple(map(int, summary.group(2, 3, 4))) == tuple(counts.values())
assert counts['ignored'] == 0 and result['source_unchanged']
assert result['exit_code'] == (101 if counts['FAILED'] else 0)
record = dict(status='failed' if counts['FAILED'] else 'passed', profile=profile, source_inputs_verified=511, counts=counts, inventory_count=len(names), raw_verdicts=observed, binary_sha256=command['binary_sha256'], log_sha256=sha(p / ('source279-' + profile + '-broad.log')), qualification='All 1064 original source276 controls plus the three unchanged allocation-error controls execute. Every name, order, raw verdict and summary is checked. The original source276 broad Emaxx -130 result remains unresolved and is not superseded by a later pass. This does not certify full-platform or performance requirements.', goal_complete=False)
with (p / ('source279-' + profile + '-broad-audit.json')).open('x') as out:
    json.dump(record, out, indent=2)
print(json.dumps({key: record[key] for key in ['status', 'profile', 'counts', 'inventory_count']}))
