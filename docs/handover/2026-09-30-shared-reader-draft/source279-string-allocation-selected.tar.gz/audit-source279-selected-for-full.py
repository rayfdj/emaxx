from pathlib import Path
import hashlib, json, subprocess, sys

p = Path(__file__).parent.resolve()
root = p.parents[2]
c = p.parent / 'recovered-2026-09-30/string-allocation-recovery/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p / n).read_text())
m = read('source279-manifest.json')
baseline = read('source272-manifest.json')
assert len(m) == 511 and all(sha(c / n) == h for n, h in m.items())
full_root = Path(read('source279-full-checkout.json')['candidate'])
assert all(sha(full_root / n) == h for n, h in m.items())
state = read('source279-selected-result.json')
assert len(state['results']) == len(state['stages']) == 8
assert all(row['source_unchanged'] and row['published_source_unchanged'] for row in state['results'])
assert all(sha(Path(n)) == h for n, h in state['helpers'].items())
profiles = {}
for profile in ['gate', 'release']:
    if not (p / ('source279-' + profile + '-broad-audit.json')).exists():
        subprocess.run([sys.executable, '-B', str(p / 'audit-source279-broad.py'), profile], check=True)
    focused = read('source279-' + ('focused-audit.json' if profile == 'gate' else 'release-focused-audit.json'))
    broad = read('source279-' + profile + '-broad-audit.json')
    assert focused['counts']['ignored'] == 2 and broad['counts']['ignored'] == 0
    for item in focused['retained_inputs']:
        assert sha(Path(item['original'])) == sha(Path(item['artifact'])) == item['sha256']
    profiles[profile] = dict(focused=focused['counts'], affected=broad['counts'], focused_status=focused['status'], affected_status=broad['status'])
prior = read('source270-selected-audit.json')['ordinary_expected_sha256']
fixtures = list(prior) + ['string-allocation-limits', 'string-allocation-signal-data', 'vector-closure-rounded-census', 'vector-pseudovector-word-census']
assert len(fixtures) == 37
ordinary = {}
failures = []
for name in fixtures:
    comparison = read('source279-ordinary-' + name + '-comparison.json')
    outputs = []
    programs = []
    for editor in ['gnu', 'emaxx']:
        stem = 'source279-ordinary-' + name + '-' + editor
        command = read(stem + '.command.json')
        result = read(stem + '.result.json')
        assert result['inputs_unchanged'] and result['source_unchanged']
        assert all(sha(Path(n)) == h for n, h in command['inputs'].items())
        stdout = (p / (stem + '.stdout')).read_bytes()
        stderr = (p / (stem + '.stderr')).read_bytes()
        assert hashlib.sha256(stdout).hexdigest() == result['stdout_sha256']
        assert stderr.hex() == result['stderr_hex']
        assert comparison['outcomes'][editor] == result
        programs.append(command['command'][-1])
        outputs.append((result['exit_code'], result['timed_out'], stdout, stderr, result['expected_output']))
    assert programs[0] == programs[1]
    matched = outputs[0][:4] == outputs[1][:4]
    passed = matched and all(code == 0 and not timed and not err and expected is not False for code, timed, out, err, expected in outputs)
    assert comparison['exact_match'] == matched and comparison['passed'] == passed
    if not passed:
        failures.append(name)
    ordinary[name] = dict(passed=passed, stdout_sha256=hashlib.sha256(outputs[0][2]).hexdigest())
    if passed and name in prior:
        assert ordinary[name]['stdout_sha256'] == prior[name]
    if passed and name.startswith('string-allocation-'):
        assert outputs[0][2] == (p / (name + '-gnu.stdout')).read_bytes()
artifacts = read('source279-ordinary-artifacts.json')
assert len(artifacts) == 2
assert all(sha(Path(n)) == sha(Path(row['immutable_copy'])) == row['sha256'] for n, row in artifacts.items())
passed = all(row['exit_code'] == 0 for row in state['results']) and not failures
passed &= all(row['focused_status'] == row['affected_status'] == 'passed' for row in profiles.values())
record = dict(status='passed' if passed else 'failed', source_inputs_verified=511, profiles=profiles, ordinary_comparisons=len(fixtures), ordinary_results=ordinary, ordinary_failures=failures, ordinary_artifacts=artifacts, qualification='Complete selected checks on frozen source279. Every earlier selector, assertion, fixture, timeout and expected byte remains; all raw names/verdicts and actual ordinary outputs are checked. Source278 three-abort negative and original source276 broad Emaxx first-vector -130 failure remain preserved. A later pass does not identify the latter cause. Full Linux/macOS validation, general exhaustion, ownership/accounting/interval work and locked performance requirements remain incomplete.', goal_complete=False)
with (p / 'source279-full-selected-audit.json').open('x') as out:
    json.dump(record, out, indent=2)
print(json.dumps({key: record[key] for key in ['status', 'profiles', 'ordinary_comparisons', 'ordinary_failures']}, indent=2))
sys.exit(0 if passed else 1)
