from pathlib import Path
import json
import subprocess

p = Path(__file__).parent.resolve()
root = p.parents[2]
head = json.loads((p / 'source279-applied-commit.json').read_text())['commit']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == head
assert subprocess.check_output(['git', 'branch', '--show-current'], cwd=root, text=True).strip() == 'runtime-char-tables'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True).strip()
remote = subprocess.check_output(['git', 'remote', 'get-url', '--push', 'origin'], cwd=root, text=True).strip()
assert remote in ['git@github.com:rayfdj/emaxx.git', 'https://github.com/rayfdj/emaxx.git', 'https://github.com/rayfdj/emaxx']
command = ['git', 'push', 'origin', 'HEAD:refs/heads/runtime-char-tables']
result = subprocess.run(command, cwd=root, capture_output=True, text=True)
with (p / 'source279-applied-push.json').open('x') as stream:
    json.dump(dict(commit=head, command=command, remote=remote, exit_code=result.returncode,
                   stdout=result.stdout, stderr=result.stderr,
                   qualification='Existing user approval covers validated updates for this task and branch. Main is not changed; full validation and full goal remain open.'), stream, indent=2)
result.check_returncode()
print(result.stdout + result.stderr)
