from pathlib import Path
import ast, hashlib, json

p = Path(__file__).parent.resolve()
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
s = (p / 'audit-source279-selected.py').read_text()
before = 'assert all(sha(root / n) == h for n, h in baseline.items())'
assert s.count(before) == 1
s = s.replace(before, "full_root = Path(read('source279-full-checkout.json')['candidate'])\nassert all(sha(full_root / n) == h for n, h in m.items())")
s = s.replace("(p / 'source279-selected-audit.json').open('x')", "(p / 'source279-full-selected-audit.json').open('x')")
with (p / 'audit-source279-selected-for-full.py').open('x') as out:
    out.write(s)
s = (p / 'queue-source270-full-macos.py').read_text().replace('source270', 'source279')
s = s.replace('string-storage/emaxx', 'string-allocation-recovery/emaxx').replace('target/string-storage-validation', 'target/string-sblock-validation')
s = s.replace('source279-validation-launch.json', 'source279-selected-launch.json').replace('source279-validation-result.json', 'source279-selected-result.json')
s = s.replace('queue-string-storage270-validation.py', 'queue-source279-fallible-selected.py')
s = s.replace('selected processes finished; raw evidence requires audit', 'selected processes finished; raw audit required')
s = s.replace(' and row[\'prior_source_unchanged\']', '').replace(' and row[\'helper_unchanged\']', '')
s = s.replace('len(manifest) == 510', 'len(manifest) == 511')
s = s.replace('source279-selected-audit.json', 'source279-full-selected-audit.json')
s = s.replace("selected['ordinary_comparisons'] == 33", "selected['ordinary_comparisons'] == 37")
s = s.replace("row['focused_passes'] == 203 and row['affected_passes'] == 1059", "row['focused'] == {'ok': 211, 'FAILED': 0, 'ignored': 2} and row['affected'] == {'ok': 1067, 'FAILED': 0, 'ignored': 0}")
with (p / 'queue-source279-full-macos.py').open('x') as out:
    out.write(s)
s = (p / 'setup-source272-full-macos.py').read_text().replace('source272', 'source279').replace('string-borrow-full/emaxx', 'string-allocation-full/emaxx')
s = s.replace('source279-borrow-selected-audit.json', 'source279-selected-audit.json').replace('==510', '==511').replace('verified=510', 'verified=511')
with (p / 'setup-source279-full-macos.py').open('x') as out:
    out.write(s)
s = (p / 'dispatch-source272-linux.py').read_text().replace('source272', 'source279')
a = s.index("                qualification='")
b = s.index("')\n    save", a)
s = s[:a] + "                qualification='Exact pushed source279 pooled-string/error-recovery checkpoint. Requires audited511 inputs, zero-warning strict checks,211 focused passes/two existing ignores and1067 affected passes in both profiles, plus37 ordinary GNU comparisons. Preserves source278 three-abort negative and unexplained source276 broad Emaxx census failure. No full-platform, process-wide OOM, ownership/accounting or performance completion is inferred from dispatch." + s[b:]
with (p / 'dispatch-source279-linux.py').open('x') as out:
    out.write(s)
helpers = ['audit-source279-selected-for-full.py', 'queue-source279-full-macos.py', 'setup-source279-full-macos.py', 'dispatch-source279-linux.py']
for name in helpers:
    ast.parse((p / name).read_text())
with (p / 'source279-full-validation-preparation.json').open('x') as out:
    json.dump(dict(status='prepared, not launched', helpers={n: sha(p / n) for n in helpers}, qualification='These helpers require a complete passing selected audit and a separately verified applied/pushed runtime commit. Full macOS uses a clean exact-commit checkout and rechecks selected/source/GNU inputs, then full Rust,519 frozen files and226 terminal scenarios. Linux uses the existing exact-commit workflow. No source279 full run is launched by this preparation.', goal_complete=False), out, indent=2)
print('Prepared full source279 validation; not launched.')
