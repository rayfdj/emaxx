from pathlib import Path
import hashlib
import json
import subprocess

p = Path(__file__).parent.resolve()
root = p.parents[2]
candidate = p.parent / 'recovered-2026-09-30/string-allocation-recovery/emaxx'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read('source279-manifest.json')
prior = read('source272-manifest.json')
audit = read('source279-selected-audit.json')
assert len(manifest) == 511 and all(sha(candidate / name) == digest for name, digest in manifest.items())
assert len(prior) == 510 and all(sha(root / name) == digest for name, digest in prior.items())
assert audit['status'] == 'passed' and audit['ordinary_comparisons'] == 37
assert all(row['focused'] == {'ok': 211, 'FAILED': 0, 'ignored': 2}
           and row['affected'] == {'ok': 1067, 'FAILED': 0, 'ignored': 0}
           for row in audit['profiles'].values())
assert read('source279-varied-strings-v2-comparison.json')['status'] == 'passed'
assert subprocess.check_output(['git', 'branch', '--show-current'], cwd=root, text=True).strip() == 'runtime-char-tables'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True).strip()
assert not (p / 'source279-applied-commit.json').exists()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert head == 'de005690499d25246c26f76cbe3ab63434687c96'
patch = p / 'source279-portable-incremental.patch'
assert sha(patch) == read('source279-freeze-and-probe-audit.json')['patches'][patch.name]['sha256']
for index, command in enumerate([['git', 'apply', '--check', str(patch)],
                                  ['git', 'apply', str(patch)], ['git', 'diff', '--check']]):
    result = subprocess.run(command, cwd=root, capture_output=True, text=True)
    with (p / ('source279-apply-stage-' + str(index) + '.json')).open('x') as stream:
        json.dump(dict(command=command, exit_code=result.returncode, stdout=result.stdout, stderr=result.stderr), stream, indent=2)
    result.check_returncode()
assert all(sha(root / name) == digest for name, digest in manifest.items())
assert all((root / name).stat().st_mode & 0o777 == (candidate / name).stat().st_mode & 0o777 for name in manifest)
subprocess.run(['git', 'add', '--', *sorted(manifest)], cwd=root, check=True)
expected = {name for name, digest in manifest.items() if prior.get(name) != digest}
assert len(expected) == 18
assert set(subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=root, text=True).splitlines()) == expected
command = ['git', '-c', 'user.name=Ray', '-c', 'user.email=26018378+rayfdj@users.noreply.github.com',
           'commit', '-m', 'Pool string data and preserve recoverable allocation errors']
result = subprocess.run(command, cwd=root, capture_output=True, text=True)
with (p / 'source279-apply-commit-command.json').open('x') as stream:
    json.dump(dict(command=command, exit_code=result.returncode, stdout=result.stdout, stderr=result.stderr), stream, indent=2)
result.check_returncode()
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True).strip()
assert all(sha(root / name) == digest for name, digest in manifest.items())
record = dict(commit=commit, parent=head, source_inputs=511, source_manifest='source279-manifest.json',
              candidate=str(candidate), selected_audit_sha256=sha(p / 'source279-selected-audit.json'),
              varied_probe_sha256=sha(p / 'source279-varied-strings-v2-comparison.json'), goal_complete=False,
              qualification='Exact selected-tested source279 checkpoint. Full platform checks, unexplained earlier census failure, process-wide exhaustion, remaining architecture and locked performance criteria are open. No existing assertions, fixtures, selectors or timeouts changed.')
with (p / 'source279-applied-commit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps(record, indent=2))
