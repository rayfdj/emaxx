from pathlib import Path
import ast
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(node for node in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(node, ast.FunctionDef) and node.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
frozen = read('source261-macos-frozen-audit.json')
assert frozen['verified_files'] == 519 and frozen['successful_processes'] == 1038
assert frozen['matching_outcomes'] == 7915 and frozen['mismatching_outcomes'] == 6
assert frozen['source_inputs_verified'] == 488
raw = Path(frozen['raw_root'])
files, links = {}, []
for path in raw.rglob('*'):
    if not path.is_file():
        continue
    name = str(path.relative_to(raw))
    if path.is_symlink():
        links.append(dict(path=name, target=str(path.readlink()), sha256=sha(path.read_bytes()), bytes=path.stat().st_size))
        continue
    files['source261-macos-frozen-raw/' + name] = path
with (p / 'source261-macos-frozen-tool-links.json').open('x') as stream:
    json.dump(dict(links=links, qualification='Existing harness tool links recorded by target/hash without copying system executables. All raw test reports and load markers are packaged.'), stream, indent=2)
names = [
    'source261-macos-frozen-audit.json', 'source261-macos-frozen-tool-links.json',
    'source261-manifest.json', 'source261-full-checkout.json', 'source261-full-launch.json',
    'source261-full-frozen-command.json', 'source261-full-frozen-result.json', 'source261-full-frozen.log',
    'source261-full-frozen-subject-inputs.json', 'source261-full-retained-gnu/manifest.json',
    'source261-full-retained-gnu/config.h', 'source261-full-retained-gnu/Makefile',
    'queue-source261-full-macos.py', 'audit-source261-macos-frozen.py', 'audit-source261-macos-terminal.py',
    'package-source196-failure-and197-results.py', Path(__file__).name,
]
for name in names:
    assert (p / name).is_file(), name
    files[name] = p / name
assert sum(name.endswith('.loaded') for name in files) == 1038
package('source261-complete-macos-frozen', files, dict(
    frozen=frozen,
    qualification='Complete source261 pinned macOS frozen comparison remains strictly failed:7915 matches/six build-feature skip-diagnostic differences, all519 files and1038 processes complete. Every raw hash/inventory/outcome/process and the actual GNU and Emaxx execution inputs are verified. Both editors report7623 passes/46 expected failures/252 skips; all177 original compiler tests pass. No feature string, selector, timeout or comparison rule is changed. Terminal validation remains separate; the current runtime and new ordinary negatives are not certified by historical passes.'))
baseline = read('source261-string-prefix-audit.json')
assert baseline['status'] == 'matched unchanged source261 baseline' and baseline['comparisons'] == 12600
state = read('source263-boundary-queue-state.json')
assert state['status'] == 'waiting for source263 selected validation'
with (p / 'source263-boundary-at-packaging.json').open('x') as stream:
    json.dump(state, stream, indent=2)
names = [
    'string-ordering-prefix-boundaries.el', 'string-ordering-prefix-boundaries.expected',
    'probe-source261-string-prefix.py', 'source261-string-prefix-probes.json', 'source261-string-prefix-audit.json',
    'source261-manifest.json', 'source261-ordinary-artifacts.json', 'source263-manifest.json',
    'source263-boundary-launch.json', 'source263-boundary-at-packaging.json',
    'queue-source263-boundary-control.py', 'audit-source263-selected.py',
    'compare-string-ranges-fixtures.py', 'audit-source261-compare-strings.py',
    'package-source196-failure-and197-results.py', Path(__file__).name,
]
for editor in ['gnu', 'source261']:
    for suffix in ['-command.json', '-result.json', '.stdout', '.stderr']:
        names.append('source261-probe-string-ordering-prefix-boundaries-' + editor + suffix)
files = {name: p / name for name in names}
assert all(path.is_file() for path in files.values())
package('source263-ordering-boundary-control', files, dict(
    baseline=baseline, launch=read('source263-boundary-launch.json'),
    qualification='All12600 GNU/source261 baseline comparisons match across14 word-boundary prefix lengths and30 actual character/storage cases. Supplementary queue87187 waits for successful selected source263 execution, then owns its complete selected audit and runs this exact ordinary control on its retained release executable/image. The source263 runtime/helper inputs and original28 ordinary fixtures remain unchanged. No source263 runtime or performance pass is claimed yet.'))
