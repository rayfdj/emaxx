from pathlib import Path
import ast
import hashlib
import json
import re
import shutil

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/string-ops/emaxx'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read('source231-manifest.json')
assert len(manifest) == 440
assert all(sha(root / name) == digest for name, digest in manifest.items())
node = next(n for n in ast.parse((p / 'audit-shared-reader196-fresh-selected.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'audit_log')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<raw-auditor>', 'exec'))
prefixes = ('lisp::bytecode::', 'lisp::native_comp::runtime::', 'lisp::primitives::pdumper::',
            'lisp::primitives::tests::', 'lisp::reader::', 'lisp::types::')
inventories = {}
for profile, count in [('gate', 2981), ('release', 2980)]:
    names = [line[:-6] for line in (p / ('source231-' + profile + '-inventory.txt')).read_text().splitlines()
             if line.endswith(': test')]
    assert len(names) == len(set(names)) == count
    inventories[profile] = names
assert set(inventories['gate']) - set(inventories['release']) == {
    'file_system::posix::tests::posix_file_drop_rejects_an_externally_closed_descriptor'}
assert not set(inventories['release']) - set(inventories['gate'])
groups = []
for group, count in [('controls', 31), ('broad', 937)]:
    stem = 'source231-release-' + group
    command, result = read(stem + '-command.json'), read(stem + '-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
    assert sha(p / 'source231-release-libtest') == command['binary_sha256']
    assert command['environment_override']['LANG'] == command['environment_override']['LC_ALL'] == 'C'
    names = command['selected_inventory']
    assert len(names) == len(set(names)) == count
    if group == 'broad':
        assert names == [name for name in inventories['release'] if name.startswith(prefixes)]
        assert names == read('source230-gate-broad-command.json')['selected_inventory']
    else:
        assert names == read('source231-gate-controls-command.json')['selected_inventory']
    assert command['command'][1:] == names + ['--exact', '--nocapture', '--test-threads=1']
    assert audit_log(names, (p / (stem + '.log')).read_text(), count, 0) == []
    groups.append(dict(profile='release', stage=group, passed=count, failed=0, ignored=0))
for stage in ['check', 'fmt', 'clippy', 'diff', 'gate-build', 'release-build']:
    result = read('source231-' + stage + '-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
    raw = (p / ('source231-' + stage + '.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
    for line in raw.splitlines():
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        assert item.get('message', {}).get('level') not in ['error', 'warning']
assert all(stage['exit_code'] == 0 for stage in read('source231-release-driver-result.json'))
names = read('source231-release-controls-command.json')['selected_inventory']
raw = (p / 'source231-release-controls.log').read_text()
first = 'test ' + names[0] + ' ... ok'
assert first in raw
mutants = {
    'missing-verdict': raw.replace(first, '', 1),
    'duplicate-verdict': raw.replace(first, first + '\n' + first, 1),
    'failed-verdict-under-green-summary': raw.replace(first, first.replace(' ... ok', ' ... FAILED'), 1),
    'missing-summary': raw[:raw.rindex('test result:')],
    'false-summary-total': raw.replace('31 passed; 0 failed;', '30 passed; 0 failed;', 1),
}
for label, invalid in mutants.items():
    try:
        audit_log(names, invalid, 31, 0)
    except (AssertionError, ValueError):
        pass
    else:
        raise AssertionError('Auditor accepted corrupt evidence: ' + label)
retained = p / 'source231-release-retained-inputs'
retained.mkdir()
images = sorted((p / 'fixture-images-source231').glob('loadup-' + sha(p / 'source231-release-libtest')[:8] + '-*.pdmp'))
assert len(images) == 1
files = []
for source in [p / 'source231-release-libtest', *images]:
    target = retained / source.name
    digest = sha(source)
    shutil.copy2(source, target)
    assert sha(source) == sha(target) == digest
    files.append(dict(original=str(source), retained=str(target), sha256=digest, bytes=target.stat().st_size))
record = dict(status='source231 selected release validation passes', inputs_verified=len(manifest),
              strict_checks='passed with zero warnings', groups=groups, retained_files=files,
              inventory_counts={profile: len(names) for profile, names in inventories.items()},
              existing_profile_difference='One unchanged cfg(debug_assertions) POSIX file-drop control is gate-only.',
              corrupt_logs_rejected=list(mutants), goal_complete=False,
              qualification='Fresh source231 release binary passes all 31 focused controls and all 937 affected-module tests with zero ignores. The same 31 focused gate controls passed separately. Production is unchanged from source230, whose affected-module gate passed; that historical result is not relabeled as a source231 gate run. Complete source231 macOS Rust is separately active. No full-platform, pinned compatibility, stack-capacity, physical-accounting or performance certification. Image is retained post-run, not a per-test image-use transcript.')
with (p / 'source231-release-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(dict(status=record['status'], inputs_verified=len(manifest), groups=groups, retained_files=files), indent=2))
