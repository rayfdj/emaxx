from pathlib import Path
import hashlib, json, os, subprocess, sys, time

p = Path(__file__).parent.resolve()
candidate = p.parent / 'recovered-2026-09-30/common-strings/emaxx'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
manifest = json.loads((p / 'source256-manifest.json').read_text())
unchanged = lambda: all(sha(candidate / name) == digest for name, digest in manifest.items())
fixtures = [
    'coding-post-read-character-count', 'coding-post-read-fast-path',
    'overriding-property-identity', 'coding-candidate-symbol-properties',
    'coding-candidate-translation', 'coding-candidate-character-identities',
    'coding-candidate-inventory', 'file-write-coding-selection',
    'new-file-coding-lifecycle', 'file-write-order',
    'canonical-coding-character-storage', 'canonical-coding-identity-storage',
    'canonical-coding-conversion-storage', 'copied-canonical-string-storage',
    'coding-error-object-storage', 'host-string-mutation', 'host-string-vector-mutation',
]
stages = [
    ['run-common-string-focused.py', '256'],
    ['audit-common-string-focused.py', '256'],
    ['test-common-string-broad.py', '256', 'gate'],
    ['run-common-string-release.py', '256'],
    ['audit-common-string-release.py', '256'],
    ['test-common-string-broad.py', '256', 'release'],
    ['build-common-string-ordinary.py', '256'],
    ['compare-common-string-fixtures.py', 'source256', str(candidate), *fixtures],
]
helpers = {str(p / stage[0]): sha(p / stage[0]) for stage in stages}
state = dict(status='waiting for complete source249 terminal supervisor to exit',
             prior_pid=12347, source_manifest='source256-manifest.json',
             helper_sha256=helpers, stages=stages, goal_complete=False)
results = []

def save_state():
    (p / 'source256-validation-queue-state.json').write_text(json.dumps(state, indent=2) + '\n')

save_state()
try:
    assert len(manifest) == 480 and unchanged()
    for stage in ['check', 'fmt', 'clippy', 'diff']:
        result = json.loads((p / ('source256-' + stage + '-result.json')).read_text())
        assert result['exit_code'] == 0 and result['source_unchanged']
    while True:
        process = subprocess.run(['ps', '-p', '12347', '-o', 'command='], capture_output=True, text=True)
        if process.returncode == 1 and not process.stdout.strip():
            break
        assert process.returncode == 0 and 'queue-source249-rebuilt-full-tty.py' in process.stdout, process.stdout + process.stderr
        time.sleep(5)
    prior = json.loads((p / 'source249-rebuilt-full-tty-result.json').read_text())
    assert prior['source_unchanged'] and prior['inputs_unchanged']
    state['prior_terminal_exit_code'] = prior['exit_code']
    # Draft validation is independent of the previous checkpoint verdict.
    # Preserve any prior failure and do not relabel it based on these tests.
    for name, *args in stages:
        helper = p / name
        assert unchanged() and sha(helper) == helpers[str(helper)]
        command = [sys.executable, '-B', str(helper), *args]
        state.update(status='running selected common-string validation', current_command=command)
        save_state()
        started = time.monotonic()
        result = subprocess.run(command, cwd=candidate, stdin=subprocess.DEVNULL,
                                env=dict(os.environ, PYTHONUNBUFFERED='1', PYTHONDONTWRITEBYTECODE='1'))
        results.append(dict(command=command, exit_code=result.returncode,
                            elapsed_seconds=time.monotonic() - started,
                            source_unchanged=unchanged(), helper_unchanged=sha(helper) == helpers[str(helper)]))
        if result.returncode or not results[-1]['source_unchanged'] or not results[-1]['helper_unchanged']:
            break
    state.update(status='selected validation finished; raw results require audit', results=results)
except Exception as error:
    state.update(status='queue or validation failed', error=repr(error), results=results)
finally:
    save_state()
    with (p / 'source256-validation-result.json').open('x') as out:
        json.dump(state, out, indent=2)
print(json.dumps(state), flush=True)
sys.exit(0 if len(results) == len(stages) and all(row['exit_code'] == 0 and row['source_unchanged'] and row['helper_unchanged'] for row in results) else 1)
