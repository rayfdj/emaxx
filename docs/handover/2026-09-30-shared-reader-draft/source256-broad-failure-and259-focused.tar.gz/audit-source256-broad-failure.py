from pathlib import Path
import hashlib, json, re

p = Path(__file__).parent.resolve()
candidate = p.parent / 'recovered-2026-09-30/common-strings/emaxx'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read('source256-manifest.json')
assert len(manifest) == 480 and all(sha(candidate / name) == digest for name, digest in manifest.items())
command = read('source256-gate-broad-command.json')
result = read('source256-gate-broad-result.json')
assert result['exit_code'] == 101 and result['source_unchanged']
names = command['selected_inventory']
assert len(names) == len(set(names)) == 957
assert command['command'][1:] == names + ['--exact', '--nocapture', '--test-threads=1']
prior = read('source249-gate-broad-command.json')['selected_inventory']
assert len(prior) == 955 and set(prior) <= set(names)
raw = (p / 'source256-gate-broad.log').read_text()
blocks = list(re.finditer(r'^test (\S+) \.\.\. ', raw, re.M))
observed = {}
for index, match in enumerate(blocks):
    stop = blocks[index + 1].start() if index + 1 < len(blocks) else raw.find('\nfailures:', match.end())
    assert stop >= match.end()
    verdicts = re.findall(r'^(ok|FAILED|ignored)(?:,.*)?$', raw[match.end():stop], re.M)
    assert len(verdicts) == 1 and match[1] not in observed
    observed[match[1]] = verdicts[0]
assert set(observed) == set(names)
counts = {key: list(observed.values()).count(key) for key in ['ok', 'FAILED', 'ignored']}
assert counts == {'ok': 956, 'FAILED': 1, 'ignored': 0}
failed = [name for name, verdict in observed.items() if verdict == 'FAILED']
assert failed == ['lisp::native_comp::runtime::tests::native_funcall_dispatches_bytecode_like_eval_c']
assert 'test result: FAILED. 956 passed; 1 failed; 0 ignored; 0 measured; 2048 filtered out;' in raw
assert 'byte-code string is not unibyte at char 0' in raw
retained = read('source256-focused-retained-inputs.json')['files']
assert len(retained) == 2 and retained[0]['sha256'] == command['binary_sha256']
for item in retained:
    assert sha(Path(item['artifact'])) == sha(Path(item['original'])) == item['sha256']
queue = read('source256-validation-result.json')
assert len(queue['results']) == 3
assert [row['exit_code'] for row in queue['results']] == [0, 0, 101]
assert all(row['source_unchanged'] and row['helper_unchanged'] for row in queue['results'])
gnu = read('source256-native-bytecode-constructor-gnu-result.json')
gnu_command = read('source256-native-bytecode-constructor-gnu-command.json')
assert gnu['exit_code'] == 0 and gnu['inputs_unchanged']
assert not (p / 'source256-native-bytecode-constructor-gnu.stderr').read_bytes()
assert all(sha(Path(name)) == digest for name, digest in gnu_command['inputs'].items())
assert sha(p / 'source256-native-bytecode-constructor-gnu.stdout') == gnu['stdout_sha256']
assert (p / 'source256-native-bytecode-constructor-gnu.stdout').read_text() == '((nil 3 3 (t t (137 84 135) 42)) (t 3 5 (error "Invalid byte-code object")))'
record = dict(
    status='failed', counts=counts, failed_tests=failed, raw_verdicts=observed,
    source_inputs_verified=480, prior_selectors_preserved=955, selected=957,
    retained_inputs=retained, unexecuted_stages=queue['stages'][3:],
    gnu_constructor=gnu, raw_log_sha256=sha(p / 'source256-gate-broad.log'),
    diagnosis='The Rust native-call test constructs intended opcode bytes 137/84/135 as Unicode U+0089/U+0054/U+0087. Canonical string construction correctly stores that as multibyte text (three characters/five bytes). Ordinary GNU make-byte-code accepts the three unibyte octets, retains their identity and funcall returns42; it rejects the Unicode form. The existing native dispatch/result/backtrace/depth assertions must be kept while correcting the fixture to explicit bytes.',
    qualification='Every broad raw name/verdict and retained executable/image verified. This full affected group remains failed; source256 release and ordinary stages did not run. No runtime repair or later source success is inferred.',
    goal_complete=False,
)
with (p / 'source256-broad-failure-audit.json').open('x') as f:
    json.dump(record, f, indent=2)
print(json.dumps({key: record[key] for key in ['status', 'counts', 'failed_tests', 'selected']}))
