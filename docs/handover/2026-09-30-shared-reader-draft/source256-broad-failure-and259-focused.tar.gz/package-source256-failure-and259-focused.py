from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
failed = read('source256-broad-failure-audit.json')
focused = read('source259-focused-audit.json')
assert failed['counts'] == {'ok': 956, 'FAILED': 1, 'ignored': 0}
assert focused['counts'] == {'ok': 188, 'FAILED': 0, 'ignored': 2}
for audit in [failed, focused]:
    for item in audit['retained_inputs']:
        assert sha(Path(item['artifact']).read_bytes()) == item['sha256']
helpers = {
    'source256-manifest.json', 'source259-manifest.json', 'source256-broad-failure-audit.json',
    'source256-focused-audit.json', 'source256-focused-retained-inputs.json',
    'source256-validation-result.json', 'source256-validation-queue-state.json', 'source256-validation-driver.log',
    'source259-focused-audit.json', 'source259-focused-inventory.json', 'source259-focused-retained-inputs.json',
    'source249-gate-broad-command.json', 'source249-gate-controls-command.json',
    'source255-gate-controls-command.json', 'source255-gate-inventory.log',
    'native-bytecode-unibyte-constructor.el', 'probe-native-bytecode-unibyte-constructor.py',
    'audit-source256-broad-failure.py', 'test-common-string-broad.py', 'queue-common-string256-validation.py',
    'run-string-comparison-hashes-focused.py', 'audit-string-comparison-hashes-focused.py',
    'source260-native-bytecode-fixture-prepared.patch', 'source260-native-bytecode-fixture-prepared.json',
    'package-source196-failure-and197-results.py', Path(__file__).name,
}
files = {}
for file in p.iterdir():
    if not file.is_file() or file.suffix not in {'.json', '.log', '.py', '.el', '.patch', '.stdout', '.stderr'}:
        continue
    name = file.name
    include = name in helpers or name.startswith(('source256-gate-broad', 'source256-native-bytecode-constructor-gnu'))
    for stage in ['gate-build', 'gate-inventory', 'gate-controls', 'check', 'fmt', 'clippy', 'diff']:
        include |= name.startswith('source259-' + stage + '-') or name == 'source259-' + stage + '.log'
    if include:
        files[name] = file
assert helpers <= files.keys()
package('source256-broad-failure-and259-focused', files, dict(
    source256_broad=failed, source259_focused=focused,
    qualification='Source256 broad gate remains failed: all 957 names verified, 956 pass and one native-call fixture uses invalid multibyte opcode storage. GNU accepts its unibyte form and rejects its original Unicode form. Release/ordinary stages did not run. The correction is prepared only; original native dispatch/result/backtrace/depth assertions remain in its patch. Separately, source259 passes all 190 focused selectors (188 passes/two existing ignores), including four unchanged GNU fixtures and the extended dump test. Its broader run is active and excluded here. No full runtime, performance or goal-completion claim.'))
