from pathlib import Path
import hashlib
import json

p = Path(__file__).parent.resolve()
capture = p / 'source261-full-retained-gnu'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
record = json.loads((capture / 'manifest.json').read_text())
assert record['status'] == 'captured' and len(record['files']) == 4
result = json.loads((p / 'source261-full-rust-result.json').read_text())
assert result['exit_code'] == 0 and result['fixed_inputs_unchanged'] and result['source_unchanged']
for item in record['files']:
    path = capture / item['artifact']
    assert path.stat().st_size == item['bytes'] and sha(path) == item['sha256']
    assert sha(Path(item['original'])) == item['sha256']
assert record['source_commit'] == '636f166cfc86aa90d63f592fd99f3fdd9ef95ebd'
assert record['source_tracked_changes'] == []
with (p / 'source261-macos-rust-oracle-audit.json').open('x') as stream:
    json.dump(dict(status='four GNU inputs unchanged after full Rust', source_commit=record['source_commit'],
                   files=record['files'], capture_manifest_sha256=sha(capture / 'manifest.json'),
                   qualification='Bounded post-Rust verification. The earlier inline audit stopped on KeyError(source), because each file uses the original field; it wrote no pass receipt and changed no input. This helper checks the documented original field. The active full supervisor retains its own final verification after frozen/terminal; no active receipt is overwritten.'), stream, indent=2)
print('Verified four GNU inputs after completed source261 Rust validation.')
