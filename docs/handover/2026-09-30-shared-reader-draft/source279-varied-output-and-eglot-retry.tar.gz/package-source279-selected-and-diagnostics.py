from pathlib import Path
import ast
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
c = p.parent / 'recovered-2026-09-30/string-allocation-recovery/emaxx'
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read('source279-manifest.json')
assert len(manifest) == 511 and all(sha((directory / name).read_bytes()) == digest for directory in [root, c] for name,digest in manifest.items())
selected = read('source279-selected-audit.json')
assert selected['status'] == 'passed' and selected['ordinary_comparisons'] == 37
assert all(row['focused'] == {'ok': 211, 'FAILED': 0, 'ignored': 2} and row['affected'] == {'ok': 1067, 'FAILED': 0, 'ignored': 0} for row in selected['profiles'].values())
assert read('source279-applied-push.json')['exit_code'] == 0
node = next(node for node in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(node, ast.FunctionDef) and node.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
allowed = {'.json', '.log', '.txt', '.py', '.el', '.expected', '.patch', '.stdout', '.stderr'}
files = {path.name: path for path in p.iterdir() if path.is_file() and path.suffix in allowed
         and path.name.startswith('source279-')
         and not path.name.startswith(('source279-full-', 'source279-varied-', 'source279-eglot-', 'source279-continuation-', 'source279-publication'))}
helpers = ['prepare-source279-selected.py', 'launch-source279-selected.py', 'queue-source279-fallible-selected.py',
           'run-fallible-strings-focused.py', 'audit-fallible-strings-focused.py', 'test-fallible-strings-broad.py',
           'run-fallible-strings-release.py', 'audit-fallible-strings-release.py', 'build-fallible-strings-ordinary.py',
           'compare-fallible-string-fixtures.py', 'audit-source279-broad.py', 'audit-source279-selected.py',
           'prepare-source279-full-validation.py', 'audit-source279-selected-for-full.py', 'queue-source279-full-macos.py',
           'setup-source279-full-macos.py', 'dispatch-source279-linux.py', 'apply-source279-selected.py',
           'apply-source279-bounded-checkpoint.py', 'push-source279-applied.py', 'package-source196-failure-and197-results.py', Path(__file__).name]
for name in helpers + ['source272-manifest.json', 'source270-selected-audit.json',
                      'source279-full-checkout.json', 'source279-full-checkout-command.json', 'source279-full-launch.json',
                      'source279-full-selected-audit.json', 'source279-full-selected-audit-command.json', 'source279-full-selected-audit-result.json',
                      'source279-full-cache-clone-command.json', 'source279-full-cache-clone-result.json',
                      'source279-full-fresh-gate-crate-command.json', 'source279-full-fresh-gate-crate-result.json',
                      'source279-full-oracle-capture-command.json', 'source279-full-oracle-capture-result.json']:
    assert (p / name).is_file(), name
    files[name] = p / name
for name in selected['ordinary_results']:
    fixture = next(path for path in [c / ('tests/fixtures/' + name + '.el'), p / (name + '.el')] if path.is_file())
    files['fixtures/' + fixture.name] = fixture
    if fixture.with_suffix('.expected').is_file(): files['fixtures/' + name + '.expected'] = fixture.with_suffix('.expected')
package('source279-string-allocation-selected', files,
        dict(selected=selected, applied=read('source279-applied-commit.json'),
             macos_launch=read('source279-full-launch.json'), linux_launches=[read('source279-linux-' + mode + '-launch.json') for mode in ['rust','frozen']],
             qualification='Closed selected gate/release and37 exact ordinary comparisons, not a full correctness certificate. Additional generated printing probe remains failed:53/198 rows differ, pre-existing on source270; raw diagnostic is in the separate source279-varied-output-and-eglot-retry archive. Earlier source276 census failure is unresolved. Full macOS/Linux validation has only launched; all architecture, ownership/accounting and performance requirements remain open.'))

diagnostics = {path.name: path for path in p.iterdir() if path.is_file() and path.suffix in allowed
               and path.name.startswith(('source279-varied-', 'source279-eglot-', 'source270-varied-strings-baseline'))}
for name in ['probe-source279-varied-strings.py', 'probe-source279-varied-strings-v2.py',
             'probe-source270-varied-string-baseline.py', 'retry-source279-eglot-bounded.py',
             'source279-manifest.json', 'source270-manifest.json', 'package-source196-failure-and197-results.py', Path(__file__).name]:
    diagnostics[name] = p / name
baseline = read('source270-varied-strings-baseline.result.json')
assert len(baseline['old_wrong_rows']) == 58 and len(baseline['latest_wrong_rows']) == 53
assert baseline['old_vs_latest_differing_rows'] == list(range(192,198))
retry = read('source279-eglot-bounded-comparison.json')
assert retry['status'] == 'passed' and retry['identical_final_buffer']
for editor in ['gnu','emaxx']:
    command = read('source279-eglot-bounded-' + editor + '-command.json')
    result = read('source279-eglot-bounded-' + editor + '-result.json')
    assert all(sha(Path(name).read_bytes()) == digest for name,digest in command['inputs'].items())
    assert result['inputs_unchanged'] and result['source_unchanged'] and result['exit_code'] == 0 and not result['timed_out']
    assert result['answer_sha256'] == sha((p / ('source279-eglot-bounded-' + editor + '-answer.txt')).read_bytes())
assert (p / 'source279-eglot-bounded-gnu-answer.txt').read_bytes() == (p / 'source279-eglot-bounded-emaxx-answer.txt').read_bytes()
package('source279-varied-output-and-eglot-retry', diagnostics,
        dict(generated_probe=read('source279-varied-strings-v2-comparison.json'), earlier_baseline=baseline, bounded_eglot=retry,
             qualification='Generated probe is FAILED, not rolled into selected pass counts. Preserve initial malformed-input failure and successor raw values including identical bytecompiler warnings. Source270 and279 have identical first192 mutation/copy rows;279 improves allocation conditions but53 output rows remain wrong. Separately, user-authorized macOS Eglot retry permits60s JSON-RPC/180s process waits for both editors, keeps original upstream test assertions, uses real Rust1.75 and captures identical final buffer bytes. This does not reclassify the original Linux timeout or establish a performance result or universal absence of cheating.'))
