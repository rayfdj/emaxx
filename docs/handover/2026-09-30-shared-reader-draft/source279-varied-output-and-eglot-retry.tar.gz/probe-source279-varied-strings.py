from pathlib import Path
import hashlib
import json
import os
import random
import subprocess
import time

p = Path(__file__).parent.resolve()
c = p.parent / 'recovered-2026-09-30/string-allocation-recovery/emaxx'
g = p.parent / 'rebuilt-2026-10-01/emacs'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
manifest = json.loads((p / 'source279-manifest.json').read_text())
assert all(sha(c / name) == digest for name, digest in manifest.items())
assert json.loads((p / 'source279-selected-audit.json').read_text())['status'] == 'passed'
rng = random.Random(20261002)
token = '%08x' % rng.getrandbits(32)
lengths = [0, 1, 7, 8, 15, 16, 31, 127, 255, 511, 1023, 1024, 1025, 2039, 4095, 8191, 8192, 8193]
characters = [0, 65, 127, 128, 255, 2047, 2048, 65535, 65536, 2097151, 2097152, 4194303]
cases = [(i, rng.choice(lengths), rng.choice(characters), rng.choice(characters), rng.getrandbits(24)) for i in range(96)]
rows = '\n'.join('(%s)' % ' '.join(map(str, row)) for row in cases)
form = ''';; -*- lexical-binding: t; -*-
(require 'bytecomp)
(let* ((print-length nil) (print-level nil) (print-circle t)
       (print-escape-nonascii t) (print-escape-multibyte t)
       (rr-TOKEN-worker
        (lambda (row)
          (let* ((number (nth 0 row)) (size (nth 1 row))
                 (character (nth 2 row)) (replacement (nth 3 row))
                 (salt (nth 4 row))
                 (value (make-string size character))
                 (alias value) (copy (copy-sequence value))
                 (position (if (> size 0) (% salt size) 0))
                 (mutation (condition-case problem
                               (aset value position replacement)
                             (error problem))))
            (when (> size 0)
              (put-text-property 0 (min size 3) 'rr-TOKEN-property
                                 (list number salt) value))
            (dotimes (index 9) (make-string (+ 113 index) character))
            (garbage-collect)
            (list row (eq value alias) (eq value copy)
                  mutation (length value) (string-bytes value)
                  (multibyte-string-p value) value copy
                  (concat value (string replacement 0 character))
                  (substring value 0 (min size 7))))))
       (compiled (byte-compile rr-TOKEN-worker))
       (cases '(ROWS)))
  (unless (byte-code-function-p compiled) (error "Bytecode mode not entered"))
  (dolist (mode (list (cons 'interpreted rr-TOKEN-worker) (cons 'bytecode compiled)))
    (dolist (row cases)
      (prin1 (list (car mode) (funcall (cdr mode) row)))
      (terpri)))
(let ((print-length nil) (print-level nil) (print-circle t))
  (dolist (character '(65 255 2048 65536 2097152 4194303))
    (let* ((payload (list 'error (propertize "varied-TOKEN-allocation"
                                            'rr-TOKEN-property (list character 751))))
           (memory-signal-data payload)
           (memory-full nil))
      (prin1
       (list 'allocation character
             (condition-case problem
                 (make-string (+ (ash 1 58) 751) character)
               (error (list (eq problem payload) (eq (cdr problem) (cdr payload))
                            problem memory-full)))
             (condition-case problem
                 (make-string most-positive-fixnum character)
               (error problem))
             (make-string 5 character)))
      (terpri))))
'''.replace('TOKEN', token).replace('ROWS', rows)
fixture = p / ('source279-varied-' + token + '.el')
with fixture.open('x') as stream:
    stream.write(form)
binaries = {'gnu': g / 'src/emacs', 'emaxx': c / 'target/string-sblock-validation/release/emaxx'}
outcomes = {}
raw = {}
for editor, binary in binaries.items():
    stem = p / ('source279-varied-strings-' + editor)
    inputs = {str(path): sha(path) for path in [binary, binary.with_suffix('.pdmp'), fixture, Path(__file__)]}
    command = [str(binary), '-Q', '--batch', '-l', str(fixture)]
    environment = dict(LANG='C', LC_ALL='C', EMAXX_GC_VERIFY='1')
    with stem.with_suffix('.command.json').open('x') as stream:
        json.dump(dict(command=command, working_directory=str(p), inputs=inputs,
                       environment_override=environment, timeout_seconds=120), stream, indent=2)
    start = time.monotonic()
    try:
        result = subprocess.run(command, cwd=p, env=dict(os.environ, **environment), stdin=subprocess.DEVNULL,
                                capture_output=True, timeout=120)
        code, stdout, stderr, timed_out = result.returncode, result.stdout, result.stderr, False
    except subprocess.TimeoutExpired as error:
        code, stdout, stderr, timed_out = None, error.stdout or b'', error.stderr or b'', True
    with stem.with_suffix('.stdout').open('xb') as stream:
        stream.write(stdout)
    with stem.with_suffix('.stderr').open('xb') as stream:
        stream.write(stderr)
    record = dict(exit_code=code, timed_out=timed_out, elapsed_seconds=time.monotonic() - start,
                  stdout_sha256=hashlib.sha256(stdout).hexdigest(), stderr_sha256=hashlib.sha256(stderr).hexdigest(),
                  stdout_bytes=len(stdout), output_rows=len(stdout.splitlines()),
                  inputs_unchanged=all(sha(Path(name)) == digest for name, digest in inputs.items()),
                  source_unchanged=all(sha(c / name) == digest for name, digest in manifest.items()))
    with stem.with_suffix('.result.json').open('x') as stream:
        json.dump(record, stream, indent=2)
    outcomes[editor] = record
    raw[editor] = code, timed_out, stdout, stderr
    print(editor, json.dumps(record), flush=True)
matching = raw['gnu'] == raw['emaxx']
passed = matching and all(row['exit_code'] == 0 and not row['timed_out']
                         and row['output_rows'] == 198 and row['inputs_unchanged'] and row['source_unchanged']
                         for row in outcomes.values()) and all(not value[3] for value in raw.values())
record = dict(status='passed' if passed else 'failed', exact_match=matching, outcomes=outcomes, seed=20261002,
              cases=cases, fixture=dict(path=str(fixture), sha256=sha(fixture)),
              coverage='96 varied size/content/mutation/property/alias/copy cases in each of interpreted and checked bytecode mode, with forced GC; six changed allocation condition payloads and bounds. Full printed contents and conditions are compared, not only success counts.',
              qualification='Additional bounded differential evidence on unchanged frozen source279, outside its original37 selected comparisons. No native-mode or timing claim; not a universal absence-of-cheating proof.', goal_complete=False)
with (p / 'source279-varied-strings-comparison.json').open('x') as stream:
    json.dump(record, stream, indent=2)
raise SystemExit(0 if passed else 1)
