from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

p = Path(__file__).parent.resolve()
c = p.parent / 'recovered-2026-09-30/string-storage/emaxx'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
manifest = json.loads((p / 'source270-manifest.json').read_text())
assert all(sha(c / name) == digest for name, digest in manifest.items())
binary = c / 'target/string-storage-validation/release/emaxx'
fixture = p / 'source279-varied-v2-293638f0.el'
inputs = {str(path): sha(path) for path in [binary, binary.with_suffix('.pdmp'), fixture, Path(__file__)]}
assert inputs[str(binary)] == '58bf546ac441f1b05ad1d2bc5ec0d020af00e603e3fd85de2acb3d73e66210c6'
command = [str(binary), '-Q', '--batch', '-l', str(fixture)]
environment = dict(LANG='C', LC_ALL='C', EMAXX_GC_VERIFY='1')
stem = p / 'source270-varied-strings-baseline'
with stem.with_suffix('.command.json').open('x') as stream:
    json.dump(dict(command=command, inputs=inputs, environment_override=environment,
                   working_directory=str(p), timeout_seconds=120), stream, indent=2)
start = time.monotonic()
try:
    result = subprocess.run(command, cwd=p, env=dict(os.environ, **environment), stdin=subprocess.DEVNULL,
                            capture_output=True, timeout=120)
    code, stdout, stderr, timed_out = result.returncode, result.stdout, result.stderr, False
except subprocess.TimeoutExpired as error:
    code, stdout, stderr, timed_out = None, error.stdout or b'', error.stderr or b'', True
for extension, data in [('stdout', stdout), ('stderr', stderr)]:
    with stem.with_suffix('.' + extension).open('xb') as stream: stream.write(data)
gnu = (p / 'source279-varied-strings-v2-gnu.stdout').read_bytes().splitlines()
latest = (p / 'source279-varied-strings-v2-emaxx.stdout').read_bytes().splitlines()
old = stdout.splitlines()
record = dict(exit_code=code, timed_out=timed_out, elapsed_seconds=time.monotonic()-start,
              source_unchanged=all(sha(c / name) == digest for name, digest in manifest.items()),
              inputs_unchanged=all(sha(Path(name)) == digest for name, digest in inputs.items()),
              stdout_sha256=hashlib.sha256(stdout).hexdigest(), stderr_sha256=hashlib.sha256(stderr).hexdigest(),
              output_rows=len(old), old_wrong_rows=[i for i,(a,b) in enumerate(zip(gnu,old)) if a!=b],
              latest_wrong_rows=[i for i,(a,b) in enumerate(zip(gnu,latest)) if a!=b],
              old_vs_latest_differing_rows=[i for i,(a,b) in enumerate(zip(old,latest)) if a!=b],
              qualification='Same frozen generated input on retained earlier source270 executable/image. Differences remain failures; this diagnostic brackets pre-existing printer defects separately from changed allocation error semantics.', goal_complete=False)
with stem.with_suffix('.result.json').open('x') as stream: json.dump(record,stream,indent=2)
print(json.dumps(record, indent=2))
assert code == 0 and not timed_out and len(old) == len(gnu) == len(latest) == 198
assert record['source_unchanged'] and record['inputs_unchanged']
