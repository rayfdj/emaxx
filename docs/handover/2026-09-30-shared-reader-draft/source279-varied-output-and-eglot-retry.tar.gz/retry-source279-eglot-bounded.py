from pathlib import Path
import hashlib
import json
import os
import subprocess
import tempfile
import time

p = Path(__file__).parent.resolve()
c = p.parent / 'recovered-2026-09-30/string-allocation-recovery/emaxx'
g = p.parent / 'rebuilt-2026-10-01/emacs'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
manifest = json.loads((p / 'source279-manifest.json').read_text())
assert all(sha(c / name) == digest for name, digest in manifest.items())
rust_analyzer = Path(subprocess.check_output(['rustup', 'which', '--toolchain', '1.75.0', 'rust-analyzer'], text=True).strip())
rust_bin = rust_analyzer.parent
tools = {name: rust_bin / name for name in ['rust-analyzer', 'cargo', 'rustc', 'rustdoc']}
versions = {name: subprocess.check_output([str(path), '--version'], text=True).strip() for name, path in tools.items()}
assert versions['rustc'].startswith('rustc 1.75.0 ')
assert (rust_bin.parent / 'lib/rustlib/src/rust/library').is_dir()
fixture = g / 'test/lisp/progmodes/eglot-tests.el'
assert sha(fixture) == '25341d9f7bd816a3d82c6cc119dd54d44d793d104cc40dd4cfa60885405eaf03'
helper = c / 'compat/emacs_compat_runner.el'
observe = p / 'source279-eglot-bounded-observation.el'
with observe.open('x') as stream:
    stream.write(''';; Diagnostic setting and passive result capture; original test is unchanged.
(setq jsonrpc-default-request-timeout 60)
(advice-add 'minibuffer-choose-completion :after
            (lambda (&rest _arguments)
              (let ((answer (buffer-string)))
                (with-temp-file (getenv "EMAXX_DIAGNOSTIC_ANSWER_FILE")
                  (insert answer)))))
''')
fixed = {str(path): sha(path) for path in [fixture, helper, observe, Path(__file__),
          g / 'src/config.h', g / 'src/Makefile', *tools.values()]}
for part in ['lib', 'libexec']:
    directory = rust_bin.parent / part
    if directory.exists():
        for path in directory.rglob('*'):
            if path.is_file(): fixed[str(path)] = sha(path)
records = {}
answers = {}
for editor, binary in [('gnu', g / 'src/emacs'), ('emaxx', c / 'target/string-sblock-validation/release/emaxx')]:
    prefix = 'source279-eglot-bounded-' + editor
    report = p / (prefix + '-ert.json')
    answer = p / (prefix + '-answer.txt')
    assert not report.exists() and not answer.exists()
    temporary = Path(tempfile.mkdtemp(prefix='eglot-' + editor + '-', dir='/private/tmp'))
    native = temporary / 'eln-cache'
    native.mkdir()
    command = [str(binary), '--eval', '(startup-redirect-eln-cache ' + json.dumps(str(native)) + ')',
               '--no-init-file', '--no-site-file', '--no-site-lisp', '--batch']
    # Use the same unchanged GNU Lisp definitions with each editor's own valid image.
    for directory in [g / 'lisp', *sorted(path for path in (g / 'lisp').iterdir() if path.is_dir())]:
        command += ['-L', str(directory)]
    command += ['-L', str(g / 'test'), '-l', 'ert', '-l', str(helper), '-l', str(fixture), '-l', str(observe),
                '--eval', "(emaxx-compat-run 'eglot-test-rust-completion-exit-function)"]
    environment = dict(PATH=str(rust_bin) + os.pathsep + os.environ['PATH'], LANG='C', LC_ALL='C',
                       TMPDIR=str(temporary), TMP=str(temporary), TEMP=str(temporary),
                       EMACS_TEST_DIRECTORY=str(g / 'test'), EMAXX_GC_VERIFY='1',
                       EMAXX_COMPAT_RUNNER=editor, EMAXX_COMPAT_SELECTOR="'eglot-test-rust-completion-exit-function",
                       EMAXX_COMPAT_RELATIVE_FILE='test/lisp/progmodes/eglot-tests.el',
                       EMAXX_BATCH_RESULT_FILE=str(report), EMAXX_DIAGNOSTIC_ANSWER_FILE=str(answer))
    inputs = dict(fixed, **{str(path): sha(path) for path in [binary, binary.with_suffix('.pdmp')]})
    with (p / (prefix + '-command.json')).open('x') as stream:
        json.dump(dict(command=command, environment_override=environment, working_directory=str(g / 'test'),
                       inputs=inputs, timeout_seconds=180, jsonrpc_timeout_seconds=60,
                       prerequisite_versions=versions, platform='macOS arm64',
                       qualification='User-authorized bounded diagnostic retry. Both editors receive the same60-second JSON-RPC default, unchanged upstream assertions and passive completion-answer capture. Original Linux timeout remains preserved; this is a new local result, not a reclassification of that run.'), stream, indent=2)
    start = time.monotonic()
    try:
        result = subprocess.run(command, cwd=g / 'test', env=dict(os.environ, **environment),
                                stdin=subprocess.DEVNULL, capture_output=True, timeout=180)
        code, stdout, stderr, timed_out = result.returncode, result.stdout, result.stderr, False
    except subprocess.TimeoutExpired as error:
        code, stdout, stderr, timed_out = None, error.stdout or b'', error.stderr or b'', True
    for suffix, content in [('stdout', stdout), ('stderr', stderr)]:
        with (p / (prefix + '.' + suffix)).open('xb') as stream: stream.write(content)
    ert = json.loads(report.read_text()) if report.exists() else None
    if answer.exists(): answers[editor] = answer.read_bytes()
    record = dict(exit_code=code, timed_out=timed_out, elapsed_seconds=time.monotonic() - start,
                  stdout_sha256=hashlib.sha256(stdout).hexdigest(), stderr_sha256=hashlib.sha256(stderr).hexdigest(),
                  inputs_unchanged=all(sha(Path(name)) == digest for name, digest in inputs.items()),
                  source_unchanged=all(sha(c / name) == digest for name, digest in manifest.items()),
                  report_sha256=sha(report) if report.exists() else None,
                  answer_sha256=sha(answer) if answer.exists() else None,
                  ert_summary=ert.get('summary') if ert else None, ert_results=ert.get('results') if ert else None)
    with (p / (prefix + '-result.json')).open('x') as stream: json.dump(record, stream, indent=2)
    records[editor] = record
    print(editor, json.dumps(record), flush=True)
expected = b'fn test() -> i32 { let v: usize = 1; v.count_ones.1234567890;'
passed = set(answers) == {'gnu', 'emaxx'} and answers['gnu'] == answers['emaxx'] == expected
passed &= all(row['exit_code'] == 0 and not row['timed_out'] and row['inputs_unchanged'] and row['source_unchanged']
              and len(row['ert_results'] or []) == 1 and row['ert_results'][0]['status'] == 'passed'
              and row['ert_results'][0]['expected'] for row in records.values())
with (p / 'source279-eglot-bounded-comparison.json').open('x') as stream:
    json.dump(dict(status='passed' if passed else 'failed', records=records,
                   identical_final_buffer=passed, expected_answer=expected.decode(), platform='macOS arm64',
                   qualification='Bounded local diagnostic only, original upstream assertions and real Rust1.75 LSP. Original Linux timeout remains a timeout; full validation and performance remain open.', goal_complete=False), stream, indent=2)
raise SystemExit(0 if passed else 1)
