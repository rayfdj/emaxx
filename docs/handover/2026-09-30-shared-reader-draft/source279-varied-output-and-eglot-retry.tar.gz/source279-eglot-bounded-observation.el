;; Diagnostic setting and passive result capture; original test is unchanged.
(setq jsonrpc-default-request-timeout 60)
(advice-add 'minibuffer-choose-completion :after
            (lambda (&rest _arguments)
              (let ((answer (buffer-string)))
                (with-temp-file (getenv "EMAXX_DIAGNOSTIC_ANSWER_FILE")
                  (insert answer)))))
