from pathlib import Path
import ast
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).parent.resolve()
out = p / 'source284-publication-stage'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
audit = read('source284-linux-rust-failure-audit.json')
assert audit['status'] == 'failed' and audit['library_passed'] == 2284 and audit['library_failed'] == 1
base = p / 'source284-linux-rust-artifacts/ordinary-linux-9c5b535614c5237dbd8e2e47f1dbe258bf7316be'
files = {}
excluded = []
for name, digest in audit['downloaded_files'].items():
    f = base / name
    assert sha(f.read_bytes()) == digest
    if f.suffix in {'.json', '.log', '.txt', '.h', '.apparmor'} or f.name == 'Makefile':
        files['linux/' + name] = f
    else:
        excluded.append(dict(path=name, bytes=f.stat().st_size, sha256=digest))
for f in p.glob('source284-linux-rust-*'):
    if f.is_file():
        files[f.name] = f
for name in ['audit-source284-linux-rust-failure.py', 'package-source196-failure-and197-results.py',
             'source272-linux-rust-failure-audit.json', Path(__file__).name]:
    files[name] = p / name
scope = dict(status='failed full Linux Rust run', audit=audit, excluded_local_binaries=excluded,
             qualification='The unchanged GNU first empty-vector census assertion fails before Emaxx runs in that test. All2284 completed passes are audited by name;756 library names and both Cargo stages never run. The source272 identical GNU output is retained for comparison, not used to normalize the failure. All four new reader/printer controls pass. No final full-platform certification; physical accounting and all remaining goal requirements stay open.',
             goal_complete=False)
package('source284-complete-linux-rust-failure', files, scope)
