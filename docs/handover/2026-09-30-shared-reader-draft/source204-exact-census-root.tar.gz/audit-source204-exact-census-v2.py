from pathlib import Path
import ast
import hashlib
import io
import json
import re
import subprocess
import sys
import tarfile

p = Path(__file__).parent.resolve()
repository = p.parents[2]
root = next((p / 'linux-source204-census-v2-artifacts').rglob('rust-exact-census/summary.json')).parent
summary = json.loads((root / 'summary.json').read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
sys.path.insert(0, str(repository / 'tools'))
from diagnose_exact_census import read_retained, REVISION, BINARY_SHA, IMAGE_SHA, TESTS

original = next((root / 'original').rglob('rust/summary.json')).parent
read_retained(original)
assert summary['status'] == 'diagnosis recorded; original failures remain failures'
assert summary['source_revision'] == REVISION
assert summary['binary_sha256'] == BINARY_SHA and summary['image_sha256'] == IMAGE_SHA
sources = json.loads((root / 'source-before.json').read_text())
assert len(sources) == summary['source_inputs'] == 403
archive = subprocess.check_output(['git', 'archive', REVISION, '--', *sources], cwd=repository)
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
    assert all(hashlib.sha256(tar.extractfile(name).read()).hexdigest() == value for name, value in sources.items())
tree = ast.parse((p / 'audit-shared-reader196-fresh-selected.py').read_text())
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'audit_log')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<raw-auditor>', 'exec'))
for label in ['selected', 'debugger']:
    result = summary[label]
    assert result['exit_code'] == 101 and not result['timed_out'] and not result['callback_errors']
    assert all(result[n] for n in ['binary_unchanged', 'image_unchanged', 'source_unchanged', 'inventory_matches'])
    assert result['expected_names'] == TESTS
    assert audit_log(TESTS, (root / result['log']).read_text(), 0, 2) == TESTS
raw = (root / 'debugger.log').read_text()
events = [json.loads(row) for row in re.findall(r'CENSUS_TRACE (\{[^\n]*\})', raw)]
assert events == json.loads((root / 'trace-events.json').read_text())
assert len(events) == summary['trace_events'] == 133
observations = []
for name in TESTS:
    short = name.rsplit('::', 1)[1]
    selected = [e for e in events if e['test'] == short]
    for event in ['explicit collection', 'roots', 'host stack', 'swept vectors']:
        assert [e['collection'] for e in selected if e['event'] == event and e['collection'] <= 4] == [1, 2, 3, 4]
    sweeps = [e for e in selected if e['event'] == 'swept vectors']
    assert len(sweeps) == 4 and not sweeps[0]['cleanup_observed']
    assert all(e['cleanup_observed'] for e in sweeps[1:])
    assert not sweeps[2]['objects'] and not sweeps[3]['objects']
    vector, record = sweeps[1]['objects']
    assert (vector['tag'], vector['slots'], record['tag'], record['slots']) == (0, 41, 34, 6)
    assert int(record['payload'][2], 16) == len(record['record_fields']) == 4
    fields = [int(v, 16) for v in record['record_fields']]
    assert fields[0] == 2 and fields[1] & 7 == 4
    assert fields[2] == int(vector['header'], 16) + 5 and fields[3] == 26
    matches = []
    for e in selected:
        if e['collection'] not in [1, 2]:
            continue
        ranges = e.get('ranges', []) if e['event'] == 'roots' else [dict(kind='host conservative stack', start=e['start'], words=e['words'])] if e['event'] == 'host stack' else []
        for region in ranges:
            for obj in [vector, record]:
                header = int(obj['header'], 16)
                for index, word in enumerate(region['words']):
                    if header <= int(word, 16) < header + 8 * (obj['slots'] + 1):
                        address = int(region['start'], 16) + 8 * index
                        frame = max((f for f in e['frames'] if int(f['sp'], 16) <= address), key=lambda f: int(f['sp'], 16))
                        matches.append(dict(collection=e['collection'], kind=region['kind'], object=obj['header'], word=word, address=hex(address), frame=frame, offset=address-int(frame['sp'], 16)))
    assert len(matches) == 1
    match = matches[0]
    assert match['collection'] == 1 and match['kind'] == 'host conservative stack'
    assert match['object'] == record['header'] and int(match['word'], 16) == int(record['header'], 16) + 5
    assert match['frame']['function'] == '<emaxx::lisp::eval::Interpreter>::eval' and match['offset'] == 8
    observations.append(dict(test=name, second_sweep=sweeps[1]['objects'], retaining_word=match,
                             logical_vector_slots=42+5))
state = json.loads((p / 'source204-census-diagnosis-v2-final-state.json').read_text())
assert state['status'] == 'completed' and state['conclusion'] == 'failure'
assert state['headSha'] == '770d9cbd7be8e306926bea2e948d7d011dd62056'
disassembly = p / 'source204-census-eval-disassembly.txt'
assert '96cbc4:' in disassembly.read_text() and '0x96d170' in disassembly.read_text()
result = dict(status='both original failures reproduced with complete observer', run=36772475709,
              source_revision=REVISION, compiled_inputs_verified=403, binary_sha256=BINARY_SHA,
              image_sha256=IMAGE_SHA, selected=dict(passed=0, failed=2), debugger=dict(passed=0, failed=2),
              trace_events=133, observations=observations,
              raw_hashes={name: sha(root / name) for name in ['summary.json', 'selected.log', 'debugger.log', 'source-before.json', 'trace-events.json']},
              disassembly_sha256=sha(disassembly),
              qualification='Both first collections have one direct captured root of the later-reclaimed closure: the tagged object word at eval stack offset 8. Its actual constants slot names the 41-element vector, giving the reported 47-slot drop. Both second collections lack that root. The original binary disassembly assigns that unused stack area to error-string construction. This is root/layout evidence, not a passing repair, total physical byte accounting, or timing. Unrecorded inherited CI environment remains a replay limitation.')
with (p / 'source204-exact-census-v2-audit.json').open('x') as f:
    json.dump(result, f, indent=2)
    f.write('\n')
print(json.dumps({k: v for k, v in result.items() if k != 'observations'}, indent=2))
