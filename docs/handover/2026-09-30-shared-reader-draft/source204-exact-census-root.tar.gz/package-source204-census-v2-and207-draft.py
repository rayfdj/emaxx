from pathlib import Path
import ast
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
tree = ast.parse((p / 'package-source196-failure-and197-results.py').read_text())
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected'}
folder = 'linux-source204-census-v2-artifacts'
directory = p / folder
files = {folder + '/' + str(f.relative_to(directory)): f for f in directory.rglob('*') if f.is_file() and f.suffix in allowed}
for name in ['source204-exact-census-v2-audit.json', 'audit-source204-exact-census-v2.py',
             'source204-census-diagnosis-v2-final-state.json', 'source204-census-diagnosis-v2-ci.log',
             'source204-census-diagnosis-v2-download.json', 'source204-census-diagnosis-v2-dispatch.json',
             'source204-census-eval-disassembly.txt', 'source204-census-inspected-abi-v4.txt',
             'source204-census-diagnosis-local-checks-v4.json', Path(__file__).name]:
    files[name] = p / name
package('source204-exact-census-root', files, json.loads((p / 'source204-exact-census-v2-audit.json').read_text()))
names = ['source207-manifest.json', 'source207-base.json', 'source207-complete.patch',
         'source207-patch-replay-and-modes-audit.json', 'audit-source207-patch.py',
         'source207-selected-validation-launch.json', 'freeze-eval-candidate.py',
         'queue-eval207-validation.py', 'check-eval207.py', 'static-eval207.py',
         'test-eval207.py', 'build-eval207.py', Path(__file__).name]
package('source207-eval-frame-draft', {name: p / name for name in names},
        dict(status='isolated unvalidated runtime draft', inputs=410,
             supervisor=json.loads((p / 'source207-selected-validation-launch.json').read_text())['pid'],
             qualification='Exact complete source patch and executable-mode replay verified. No runtime result is included in this launch archive. The published task branch remains source204; source206 bytecode negative baseline stays separate. All original failed assertions and expected values are unchanged.'))
