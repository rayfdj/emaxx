from pathlib import Path
import hashlib, json, os, subprocess, time

p = Path(__file__).parent.resolve()
gnu = p.parent / 'rebuilt-2026-10-01/emacs'
fixture = p / 'bytecode-unibyte-constructor.el'
prefix = 'source255-bytecode-constructor-gnu'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
paths = [Path(__file__), fixture, *[gnu / 'src' / name for name in ['emacs', 'emacs.pdmp', 'config.h', 'Makefile', 'alloc.c', 'bytecode.c']]]
before = {str(path): sha(path) for path in paths}
command = [str(gnu / 'src/emacs'), '-Q', '--batch', '--eval', '(prin1 ' + fixture.read_text() + ')']
def save(suffix, data):
    with (p / (prefix + '-' + suffix + '.json')).open('x') as stream:
        json.dump(data, stream, indent=2)
save('command', dict(command=command, working_directory=str(p), environment_override=dict(LANG='C', LC_ALL='C'), inputs=before, timeout_seconds=120))
started = time.monotonic()
with (p / (prefix + '.stdout')).open('xb') as out, (p / (prefix + '.stderr')).open('xb') as err:
    result = subprocess.run(command, cwd=p, env=dict(os.environ, LANG='C', LC_ALL='C'), stdin=subprocess.DEVNULL, stdout=out, stderr=err, timeout=120)
after = {str(path): sha(path) for path in paths}
stdout = (p / (prefix + '.stdout')).read_bytes()
stderr = (p / (prefix + '.stderr')).read_bytes()
save('result', dict(exit_code=result.returncode, elapsed_seconds=time.monotonic() - started,
                    inputs_unchanged=before == after, stdout_sha256=sha(p / (prefix + '.stdout')),
                    stderr_sha256=sha(p / (prefix + '.stderr')), qualification='Ordinary rebuilt GNU reference. alloc.c:Fmake_byte_code requires an unibyte code string and retains that string. Distinct bytecode.c:Fbyte_code handles old multibyte byte-code primitive inputs. No runtime expectation, selector or timeout was changed.'))
assert result.returncode == 0 and not stderr and before == after
print(stdout.decode(), flush=True)
