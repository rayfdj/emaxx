from pathlib import Path
import shutil

ROOT = Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/common-strings/emaxx')
OUT = Path(__file__).parent

def edit(name, old, new):
    p = ROOT / name
    s = p.read_text()
    assert old in s, (name, old)
    p.write_text(s.replace(old, new))

edit('src/lisp/types.rs', '    borrow::Borrow,\n', '')
edit('src/lisp/types.rs', '    path::Path,\n', '')
edit('src/lisp/types.rs', 'impl Borrow<str> for SymbolName', 'impl std::borrow::Borrow<str> for SymbolName')
edit('src/lisp/alloc.rs', '{ConsCell, Kind, MarkBit, Value}', '{ConsCell, Kind, Value}')
edit('src/buffer.rs', '        (Kind::String(left), Kind::String(right)) => left.ptr_eq(&right),\n', '')
edit('src/lisp/native_comp/runtime.rs', '                    Some(crate::lisp::alloc::Found::String(cell)) => cell as usize == address,\n', '')
edit('src/lisp/primitives/processes.rs', '''        let owned;
        let entry = match item.as_string() {
            Ok(text) => text,
            Err(_) => {
                owned = string_text(&item)?;
                owned.as_str()
            }
        };''', '        let entry = item.as_string()?;')
edit('src/lisp/reader.rs', 'Kind::StringObject(state) => state.borrow().text().into(),', 'Kind::StringObject(state) => state.borrow().text(),')
edit('src/lisp/types.rs', '''    pub(crate) fn symbol_by_tag(self) -> Option<SymbolName> {
        if self.0 & TAG_MASK == TAG_SYMBOL && !matches!(self.0, 0 | 48 | 96) {
            // SAFETY: a symbol-tagged word names a symbol cell; symbol
            // cells are swept after the vectors and the conses.
            Some(SymbolName::from_ref(unsafe {
                crate::lisp::alloc::SymbolRef::from_raw(
                    self.0 as *mut crate::lisp::alloc::SymbolCell,
                )
            }))
        } else {
            None
        }
    }''', '''    pub(crate) fn symbol_name_by_tag(&self) -> Option<&str> {
        if self.0 & TAG_MASK == TAG_SYMBOL && !matches!(self.0, 0 | 48 | 96) {
            // SAFETY: a symbol-tagged word names a symbol cell; symbol
            // cells are swept after the vectors and the conses. Its host
            // key is immutable and the borrow cannot outlive this handle.
            let cell = unsafe { &*(self.0 as *const crate::lisp::alloc::SymbolCell) };
            Some(cell.internal.as_str())
        } else {
            None
        }
    }''')
edit('src/lisp/types.rs', '''            Kind::Symbol(_) => {
                // SAFETY: this Value names a symbol, whose host key is immutable.
                let cell = unsafe { &*(self.word() as *const crate::lisp::alloc::SymbolCell) };
                Ok(cell.internal.as_str())
            },''', '            Kind::Symbol(_) => Ok(self.symbol_name_by_tag().expect("symbol tag")),')
edit('src/lisp/eval.rs', '''pub(crate) fn symbol_type_name_by_tag(&self) -> Option<&'static str> {
        self.type_tag.symbol_by_tag().map(|symbol| symbol.as_str())''', '''pub(crate) fn symbol_type_name_by_tag(&self) -> Option<&str> {
        self.type_tag.symbol_name_by_tag()''')
edit('src/lisp/primitives/values.rs', 'Kind::Symbol(symbol) => Some(symbol.as_str()),', 'Kind::Symbol(_) => value.symbol_name_by_tag(),')
edit('src/lisp/eval/runtime.rs', '''        let name = match purpose.kind() {
            Kind::Nil => "nil",
            Kind::T => "t",
            Kind::Symbol(name) => name.as_str(),
            _ => return Err(LispError::WrongTypeArgument("symbolp".into(), purpose)),
        };''', '        let name = purpose.as_symbol()?;')
edit('src/lisp/bytecode/vm.rs', 'Kind::Symbol(name) => Some(name.as_str()),', 'Kind::Symbol(_) => func.as_symbol().ok(),')
edit('src/lisp/primitives/dispatch/display.rs', 'let Kind::Symbol(key) = pair[0].kind() else', 'let Ok(key) = pair[0].as_symbol() else')
edit('src/lisp/primitives/dispatch/display.rs', 'properties.insert(key.as_str(), &pair[1])', 'properties.insert(key, &pair[1])')
edit('src/lisp/primitives/dispatch/fonts.rs', '                        Some(add.as_str())', '                        Some(if add == "prepend" { "prepend" } else { "append" })')
edit('src/tty.rs', 'Kind::Symbol(name) => name.as_str(),', 'Kind::Symbol(_) => command.as_symbol().expect("symbol command"),')
edit('src/lisp/primitives/tests.rs', '''    text.to_string()
}

const SCROLL_CONTRACT_PROGRAM''', '''    text.borrow().text()
}

const SCROLL_CONTRACT_PROGRAM''')
edit('src/lisp/primitives/strings.rs', '''pub(crate) fn immutable_lisp_string_storage_byte_len(text: &str) -> usize {
    let multibyte = text
        .chars()
        .any(|ch| !is_raw_byte_regex_char(ch) && (ch as u32) > 0x7f);
    lisp_string_storage_byte_len(text, multibyte, &[])
}

''', '')
for stem in ['host-string-mutation', 'host-string-vector-mutation']:
    shutil.copyfile(OUT / (stem + '.el'), ROOT / 'tests/fixtures' / (stem + '.el'))
    shutil.copyfile(OUT / ('source249-' + stem + '-gnu.stdout'), ROOT / 'tests/fixtures' / (stem + '.expected'))
with (ROOT / 'src/lisp/primitives/tests.rs').open('a') as stream:
    stream.write('''

#[test]
fn host_created_strings_preserve_mutation_properties_and_fill_errors() {
    assert_oracle_contract_matches_interpreter(
        include_str!("../../../tests/fixtures/host-string-mutation.el"),
        include_str!("../../../tests/fixtures/host-string-mutation.expected").trim_end(),
        "host-created strings share canonical mutation and fill contracts",
    );
}

#[test]
fn vector_held_host_strings_preserve_binding_identity_and_mutation() {
    assert_oracle_contract_matches_interpreter(
        include_str!("../../../tests/fixtures/host-string-vector-mutation.el"),
        include_str!("../../../tests/fixtures/host-string-vector-mutation.expected").trim_end(),
        "vector-held host strings retain identity through binding, stores and GC",
    );
}
''')
print('Repaired canonical string borrows and added unchanged GNU fixtures')
