(mapcar
 (lambda (code)
   (list (multibyte-string-p code) (length code) (string-bytes code)
         (condition-case err
             (let ((function (make-byte-code 257 code [] 3)))
               (list (byte-code-function-p function)
                     (eq (aref function 1) code)
                     (append (aref function 1) nil)
                     (funcall function 42)))
           (error err))))
 (list (unibyte-string #x89 #x87) (string #x89 #x87)))
