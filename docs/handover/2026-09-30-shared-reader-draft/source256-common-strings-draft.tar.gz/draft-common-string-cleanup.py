from pathlib import Path
import re

ROOT = Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/common-strings/emaxx')
def edit(name, transform):
    p = ROOT / name
    old = p.read_text()
    new = transform(old)
    assert old != new, name
    p.write_text(new)

for name in ['src/lisp/eval/threads.rs', 'src/lisp/eval/bindings.rs', 'src/lisp/eval/variables.rs']:
    edit(name, lambda s: re.sub(r'^\s*let (value|parameters) = \1;\n', '\n', s, flags=re.M).replace('callback: callback,', 'callback,'))
edit('src/lisp/bytecode/vm.rs', lambda s: s.replace('code: object.code.clone(),', 'code: object.code,'))

def completion(s):
    a = s.index('pub(crate) fn ensure_completion_list_item_identity(')
    b = s.index('pub(crate) fn completion_list_candidates(', a)
    s = s[:a] + s[b:]
    return s.replace('ensure_completion_list_item_identity(&ConsSlot::car(&cons_cell))?', 'cons_cell.car.get()')
edit('src/lisp/primitives/completion.rs', completion)
edit('src/lisp/primitives.rs', lambda s:s.replace('    ConsSlot, EmacsTermination, Env,', '    EmacsTermination, Env,'))

def loader(s):
    a = s.index("        let name_text: std::borrow::Cow<'_, str> = match name.kind() {")
    b = s.index('        if interned == SYMBOL_UNINTERNED', a)
    s = s[:a] + '''        let name_text = name.as_string()
            .map_err(|_| LoadError::Error("symbol name is not a string".into()))?;
''' + s[b:]
    return s.replace('name_text.into_owned(),', 'name_text,')
edit('src/lisp/primitives/pdumper/load.rs', loader)

def purecopy(s):
    a = s.index('        Kind::StringObject(_) => {')
    b = s.index('        Kind::Vector(_) =>', a)
    return s[:a] + '''        Kind::StringObject(state) => {
            let copy = state.borrow().clone_without_properties();
            crate::lisp::types::string_object_value(copy)
        }
''' + s[b:]
edit('src/lisp/primitives/purecopy.rs', purecopy)

def dump(s):
    s = s.replace('StringObject(usize),', 'String(usize),').replace('ObjectKey::StringObject(', 'ObjectKey::String(')
    s = s.replace('Kind::StringObject(_) => DumpType::StringObject,', 'Kind::StringObject(_) => DumpType::String,')
    a = s.index('        let string = string_like(object).expect("a string");')
    b = s.index('        self.object_start()?;', a)
    s = s[:a] + '''        let Kind::StringObject(state) = object.kind() else {
            unreachable!("dumping a string")
        };
        let (size, size_byte, props) = {
            let string = state.borrow();
            let props = string.props.iter().map(|span| TextPropertySpan {
                start: span.start,
                end: span.end,
                props: span.props.clone(),
            }).collect::<Vec<_>>();
            (string.len() as u64,
             if string.is_multibyte() { string.storage_bytes() as u64 } else { u64::MAX },
             props)
        };
''' + s[b:]
    s = s.replace('let has_props = !string.props.is_empty();', 'let has_props = !props.is_empty();')
    s = s.replace('self.dump_text_properties(interp, &string.props)?', 'self.dump_text_properties(interp, &props)?')
    s = s.replace('        Ok((offset, kind))\n    }\n\n    /// The string', '        Ok((offset, DumpType::String))\n    }\n\n    /// The string')
    return s
edit('src/lisp/primitives/pdumper/context.rs', dump)

def comments(s):
    s = s.replace('''            // Evaluating a string literal yields a string object with its
            // own identity, so `eq' distinguishes evaluations of distinct
            // literals while `(memq (car l) l)' still finds the element the
            // evaluation put there (GNU strings are always heap objects).

''', '')
    return s
edit('src/lisp/eval/core.rs', comments)
edit('src/lisp/primitives/strings.rs', lambda s:s.replace('''/// The text of a string VALUE without copying it when the string is a
/// shared text (`Value::String'): what a primitive reads and never keeps.
/// A `StringObject' is copied out of its cell as `string_like' copies it.''', '''/// A transient Rust text view of canonical bytes. It is never retained as
/// mutable string state; consumers needing characters or bytes use the payload.'''))
print('Removed obsolete binding/completion operations and dump text conversions')
