from pathlib import Path
import re
ROOT=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/common-strings/emaxx')
def edit(name, transform):
 p=ROOT/name
 original=p.read_text()
 updated=transform(original)
 assert updated!=original, name
 p.write_text(updated)
def between(s,start,end,new):
 a=s.index(start); b=s.index(end,a)
 return s[:a]+new+s[b:]
def types(s):
 s=between(s,'/// One Lisp string:', '/// A symbol name shared', '''/// A handle to the single canonical Lisp string payload. Rust text is
/// converted only at construction; variable bindings copy this handle.
pub type SharedText = StringObjectRef;

impl SharedText {
    pub fn new(text: String) -> Self {
        // Host callers still use the existing raw-byte text convention.
        // This conversion happens once, before publishing the Lisp object.
        let multibyte = !text.is_ascii()
            && text.chars().any(|ch| {
                !crate::lisp::primitives::is_raw_byte_regex_char(ch) && u32::from(ch) > 127
            });
        let value = string_object_value(SharedStringState::new(
            text, Vec::new(), multibyte, Vec::new(),
        ));
        let Kind::StringObject(state) = value.kind() else {
            unreachable!("string constructor")
        };
        state
    }

    pub fn into_string(self) -> String {
        self.borrow().text()
    }
}

impl PartialEq for SharedText {
    fn eq(&self, other: &Self) -> bool {
        if self.ptr_eq(other) {
            return true;
        }
        let left = self.borrow();
        let right = other.borrow();
        left.len() == right.len() && left.bytes() == right.bytes()
    }
}

impl Eq for SharedText {}

impl std::hash::Hash for SharedText {
    fn hash<H: Hasher>(&self, state: &mut H) {
        let text = self.borrow();
        std::hash::Hash::hash(&text.len(), state);
        std::hash::Hash::hash(text.bytes(), state);
    }
}

impl From<String> for SharedText {
    fn from(text: String) -> Self { Self::new(text) }
}

impl From<&str> for SharedText {
    fn from(text: &str) -> Self { Self::new(text.to_owned()) }
}

impl From<&String> for SharedText {
    fn from(text: &String) -> Self { Self::from(text.as_str()) }
}

impl FromIterator<char> for SharedText {
    fn from_iter<T: IntoIterator<Item = char>>(iter: T) -> Self {
        String::from_iter(iter).into()
    }
}

impl<'a> FromIterator<&'a char> for SharedText {
    fn from_iter<T: IntoIterator<Item = &'a char>>(iter: T) -> Self {
        iter.into_iter().copied().collect::<String>().into()
    }
}

impl From<SharedText> for String {
    fn from(text: SharedText) -> Self { text.into_string() }
}

impl From<&SharedText> for String {
    fn from(text: &SharedText) -> Self { text.borrow().text() }
}

''')
 s=s.replace('SharedText::new_untracked(text)', 'text')
 s=between(s,'            let text = if private || lisp_name.is_some()', '            let id = symbol_id_for', '''            let lisp_name = lisp_name.unwrap_or_else(|| {
                Value::String(SharedText::from(if private {
                    visible_symbol_name(&text)
                } else {
                    text.as_str()
                }))
            });
''')
 s=s.replace('SharedText::new_untracked(make_uninterned_symbol_name(visible, id))','make_uninterned_symbol_name(visible, id)')
 s=s.replace('fn new_uninterned(lisp_name: Value, internal: SharedText)', 'fn new_uninterned(lisp_name: Value, internal: String)')
 s=s.replace("pub fn as_str(&self) -> &'static str {\n        self.0.internal.as_str()\n    }", "pub fn as_str(&self) -> &str {\n        self.0.internal.as_str()\n    }")
 s=between(s, '    /// The host-side key text (a string cell', '\n}\n', '')
 s=s.replace('                mark(&Value::String(*name.internal_text()));\n','')
 s=s.replace('self.0.internal.text()', '&self.0.internal')
 s=s.replace('        name.0.internal\n', '        name.as_str().into()\n')
 s=s.replace('    String(SharedText),\n', '')
 s=s.replace('Value::from_bits(text.identity_ptr() | TAG_STRING)', 'Value::StringObject(text)')
 s=between(s, '            TAG_STRING => {', '            TAG_FLOAT => {', '''            TAG_STRING => {
                // SAFETY: every string word names the canonical payload.
                Kind::StringObject(unsafe {
                    crate::lisp::alloc::VectorlikeRef::from_raw((word & !TAG_MASK) as *mut _)
                })
            }
''')
 s=s.replace('            Kind::String(v) => Value::String(v),\n', '')
 s=s.replace('name: impl Into<SharedText>', 'name: impl Into<String>')
 s=s.replace('pub fn as_string(&self) -> Result<&str, LispError>', 'pub fn as_string(&self) -> Result<String, LispError>')
 s=s.replace('Kind::String(s) => Ok(s.as_str()),', 'Kind::StringObject(s) => Ok(s.borrow().text()),')
 # The borrow is tied to Value rather than a temporary decoded handle.
 s=s.replace('Kind::Symbol(s) => Ok(s.as_str()),', '''Kind::Symbol(_) => {
                // SAFETY: this Value names a symbol, whose host key is immutable.
                let cell = unsafe { &*(self.word() as *const crate::lisp::alloc::SymbolCell) };
                Ok(cell.internal.as_str())
            },''')
 s=s.replace('count: crate::lisp::alloc::live_strings() + objects,', 'count: objects,')
 s=s.replace('bytes: crate::lisp::alloc::live_string_bytes() + bytes,', 'bytes,')
 s=s.replace('    // The texts and the string objects, both counted by the sweep and\n    // raised by allocation (gcstat\'s total_strings, total_string_bytes).', "    // One allocator census for every Lisp string.")
 s=s.replace('    note_string_allocation(bytes);\n    Value::StringObject', '''    if state.len() == 0 && !state.is_multibyte() {
        return Value::StringObject(crate::lisp::alloc::vectors::empty_unibyte_string());
    }
    note_string_allocation(bytes);
    Value::StringObject''')
 return s
edit('src/lisp/types.rs',types)
edit('src/lisp/alloc/symbols.rs',lambda s:s.replace('/// The host-side key text (the string cell the symbol keeps alive).\n    pub(crate) internal: super::TextRef,','/// Immutable host lookup key, owned and released with the symbol.\n    pub(crate) internal: String,'))
def alloc(s):
 s=between(s,"/// `STRING_BLOCK_SIZE':", "/// `SYMBOL_BLOCK_SIZE':",'')
 s=s.replace('const C_MALLOC_SIZE_NEAR_1024: usize = 1016;\n','')
 s=s.replace('        BlockKind::String => STRINGS_PER_BLOCK * STRING_CELL_SIZE,\n','')
 s=s.replace('    String,\n','').replace('    String(*mut StringCell),\n','')
 s=between(s,"/// alloc.c's `string_block'", 'thread_local! {', '')
 s=between(s,'        BlockKind::String => {','        BlockKind::Symbol => {','')
 s=s.replace('    if EMPTY_TEXT.get().is_some_and(|&empty| empty == address) {\n        return Some(Found::String(address as *mut StringCell));\n    }', '''    if let Some(string) = vectors::empty_string_at(address) {
        return Some(Found::Vectorlike(string));
    }''')
 s=between(s,'        BlockKind::String => {','        BlockKind::VectorBlock => {','')
 s=s.replace('        Found::String(cell) => Value::String(TextRef(unsafe { NonNull::new_unchecked(cell) })),\n','')
 return s
edit('src/lisp/alloc.rs',alloc)
def vectors(s):
 marker='        let nbytes = self.nbytes();\n'
 index=s.index(marker,s.index('    fn mark_bit(&self)'))
 s=s[:index]+'''        if empty_string_at(address).is_some() {
            // SAFETY: the permanent empty string owns its separate mark.
            return VectorMark(VectorMarkStorage::Separate(unsafe {
                &(*(address as *const EmptyString)).mark
            }));
        }
'''+s[index:]
 index=s.index("/// `Lisp_Object' for an ordinary vector:")
 s=s[:index]+'''/// alloc.c's empty_unibyte_string: one permanent empty canonical string.
/// It is outside the swept blocks and the allocated Lisp-string census.
#[repr(C)]
struct EmptyString {
    header: VectorHeader,
    state: RefCell<SharedStringState>,
    mark: MarkBit,
}

static EMPTY_STRING: std::sync::OnceLock<usize> = std::sync::OnceLock::new();

pub(super) fn empty_string_at(address: usize) -> Option<*mut VectorHeader> {
    EMPTY_STRING.get().filter(|&&empty| empty == address)
        .map(|&empty| empty as *mut VectorHeader)
}

pub(crate) fn empty_unibyte_string() -> VectorlikeRef<RefCell<SharedStringState>> {
    let address = *EMPTY_STRING.get_or_init(|| {
        Box::leak(Box::new(EmptyString {
            header: VectorHeader {
                size: VectorHeader::pseudovector_size_word(
                    VectorTag::StringObject,
                    HEADER_SIZE + std::mem::size_of::<RefCell<SharedStringState>>(),
                ),
            },
            state: RefCell::new(SharedStringState::from_unibyte(Vec::new())),
            mark: MarkBit::default(),
        })) as *mut EmptyString as usize
    });
    // SAFETY: the permanent allocation uses the same header/payload layout.
    unsafe { VectorlikeRef::from_raw(address as *mut VectorHeader) }
}

'''+s[index:]
 return s
edit('src/lisp/alloc/vectors.rs',vectors)
edit('src/lisp/native_comp/runtime.rs', lambda s:s.replace('        crate::lisp::alloc::sweep_strings(epoch);\n','').replace('''            Value::String(crate::lisp::alloc::allocate_string(
                "internal-name".into(),
                crate::lisp::alloc::UNTRACKED_TEXT,
            )),''','            Value::string("internal-name"),'))
edit('src/lisp/eval.rs',lambda s:s.replace('                symbol.internal_text().mark_bit().mark(self.epoch);\n',''))
# Eliminate binding and callback copies. Every stored Value is now authoritative.
for p in (ROOT/'src/lisp').rglob('*.rs'):
 s=p.read_text(); orig=s
 if p==ROOT/'src/lisp/eval/runtime.rs':
  s=between(s,'    pub(super) fn stored_value(', '    pub(crate) fn resolve_load_target(', '')
 s=s.replace('args.into_iter().map(Self::stored_value).collect()', 'args')
 s=s.replace('value.map(Self::stored_value)', 'value')
 while 'Self::stored_value(' in s:
  a=s.index('Self::stored_value('); b=a+len('Self::stored_value('); i=b; depth=1
  while depth:
   if s[i]=='(': depth+=1
   elif s[i]==')': depth-=1
   i+=1
  s=s[:a]+s[b:i-1]+s[i:]
 s=re.sub(r'^\s*let (value|parameters) = ;\n','\n',s,flags=re.M)
 s=s.replace('Kind::String(_) | Kind::StringObject(_)', 'Kind::StringObject(_)')
 s=s.replace('Kind::StringObject(_) | Kind::String(_)', 'Kind::StringObject(_)')
 if s!=orig:p.write_text(s)
def bytecode(s):
 s=s.replace('use std::rc::Rc;\n','')
 s=between(s,'/// The original code string.', '#[derive(Clone, Debug)]\npub struct ByteCodeObject', '''/// The original canonical code string, fetched directly at each instruction.
#[derive(Clone, Copy, Debug)]
pub struct CodeBytes {
    original: Value,
}

impl CodeBytes {
    fn new(original: Value) -> Result<Self, ByteCodeError> {
        let Kind::StringObject(state) = original.kind() else {
            return Err(ByteCodeError::MalformedObject("code slot is not a string".into()));
        };
        if state.borrow().is_multibyte() {
            return Err(ByteCodeError::NonUnibyteCode { char_index: 0 });
        }
        Ok(Self { original })
    }

    pub(crate) fn original(&self) -> Value { self.original }

    /// BODY must not invoke Lisp, collect, or mutate the code string.
    /// The borrow ends before callbacks and frame changes.
    #[inline]
    pub(crate) fn with_bytes<R>(&self, body: impl FnOnce(&[u8]) -> R) -> R {
        let Kind::StringObject(state) = self.original.kind() else {
            unreachable!("validated code string")
        };
        body(state.borrow().bytes())
    }
}

''')
 s=between(s,'fn unibyte_bytes(', '/// Whether record slots look', '')
 return s
edit('src/lisp/bytecode.rs',bytecode)
def load(s):
 s=s.replace('Kind, SharedText, SubCharTableRef','Kind, SubCharTableRef')
 s=s.replace('        kind: DumpType,\n    ) -> Result<(Value, Option<u32>), LoadError>', '        _kind: DumpType,\n    ) -> Result<(Value, Option<u32>), LoadError>')
 s=between(s,'        let value = match kind {\n            DumpType::String => {','        Ok((value, (intervals != 0).then_some(intervals)))', '''        let value = crate::lisp::types::string_object_value_with_storage_bytes(
            SharedStringState::from_storage(bytes.to_vec(), size, multibyte)
                .map_err(|error| LoadError::Error(error.to_string()))?,
            nbytes,
        );
''')
 return s
edit('src/lisp/primitives/pdumper/load.rs',load)
print('Applied initial common-string draft in isolated checkout only')
