from pathlib import Path
import re

ROOT = Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/common-strings/emaxx')

def between(s, start, end, new):
    a = s.index(start)
    b = s.index(end, a)
    return s[:a] + new + s[b:]

def remove_arm(s, marker):
    a = s.index(marker)
    a = s.rfind('\n', 0, a) + 1
    arrow = s.index('=>', a)
    i = arrow + 2
    depth = 0
    block = s[i:].lstrip().startswith('{')
    while i < len(s):
        if s.startswith('//', i):
            i = s.index('\n', i)
            continue
        if s[i] == '"':
            i += 1
            while s[i] != '"':
                i += 2 if s[i] == '\\' else 1
            i += 1
            continue
        if s[i] == "'":
            char = re.match(r"'(?:\\.|[^'\\])'", s[i:])
            if char:
                i += len(char[0])
                continue
        if s[i] in '({[':
            depth += 1
        elif s[i] in ')}]':
            depth -= 1
            if block and depth == 0:
                i += 1
                if s[i:i+1] == ',':
                    i += 1
                if s[i:i+1] == '\n':
                    i += 1
                return s[:a] + s[i:]
        elif s[i] == ',' and depth == 0:
            i += 1
            if s[i:i+1] == '\n':
                i += 1
            return s[:a] + s[i:]
        i += 1
    raise AssertionError(marker)

def edit(name, transform):
    p = ROOT / name
    old = p.read_text()
    new = transform(old)
    assert new != old, name
    p.write_text(new)

def remove(s, markers):
    for marker in markers:
        s = remove_arm(s, marker)
    return s

simple = {
    'src/lisp/primitives/print.rs': ['Kind::String(text) => Some(', 'Kind::String(text) if !context.options.escape', 'Kind::String(text) => Ok(render_prin1_string'],
    'src/lisp/primitives/interactive.rs': ['Kind::String(text) => text.as_bytes()', 'Kind::String(text) => text.chars().next()'],
    'src/lisp/reader.rs': ['Kind::String(text) => text,', 'Kind::String(text) => (text.to_string()'],
    'src/lisp/primitives/purecopy.rs': ['Kind::String(text) => Value::String'],
    'src/lisp/primitives/keys.rs': ['Kind::String(text) => Ok(text.to_string())', 'Kind::String(text) => {'],
    'src/lisp/mod.rs': ['types::Kind::String(text) =>'],
    'src/lisp/alloc/vectors/char_tables.rs': ['Kind::String(text) =>'],
    'src/lisp/eval/bindings.rs': ['Kind::String(path) =>', 'Kind::String(path) =>'],
    'src/lisp/primitives/dispatch/misc_keymaps.rs': ['Kind::String(_) =>'],
    'src/lisp/primitives/loading.rs': ['Kind::String(spec) =>'],
    'src/lisp/primitives/dispatch/display.rs': ['Kind::String(text) =>'],
}
for name, markers in simple.items():
    edit(name, lambda s, markers=markers: remove(s, markers))

def types(s):
    s = remove(s, [
        'Kind::String(_) => "string"',
        '(Kind::String(a), Kind::String(b)) =>',
        '(Kind::String(a), Kind::StringObject(b)) =>',
        '(Kind::StringObject(a), Kind::String(b)) =>',
        'Kind::String(s) => write!',
        'Kind::String(text) => write!(f, "{text:?}")',
        'Kind::String(text) => write!(f, "{text}")',
        'Kind::String(text) => {',
    ])
    s = s.replace('Kind::String(text) => text.as_str(),', 'Kind::StringObject(text) => text.borrow().text(),')
    s = s.replace('Kind::String(', 'Kind::StringObject(')
    return s
edit('src/lisp/types.rs', types)

def values(s):
    return remove(s, [
        '(Kind::String(a), Kind::String(b)) =>',
        '(Kind::String(a), Kind::StringObject(b)) =>',
        '(Kind::StringObject(a), Kind::String(b)) =>',
        '(Kind::String(left), Kind::String(right)) =>',
        '(Kind::String(left), Kind::String(right)) =>',
        '(Kind::String(_), Kind::StringObject(_)) |',
        'Kind::String(text) => Ok(text.as_str()',
        'Kind::String(text) => {',
        'Kind::String(text) => {',
        'Kind::String(text) => Some(text.to_string())',
    ])
edit('src/lisp/primitives/values.rs', values)

def eval_source(s):
    s = remove(s, ['Kind::String(value) => value.mark_bit()', 'Kind::String(value) => value.mark_bit()'])
    s = s.replace('            | Kind::String(_)\n', '')
    # Shared string undo entries are already kept opaque with all metadata.
    s = remove_arm(s, 'Some((Kind::String(text), Kind::Integer(pos))) =>')
    return s
edit('src/lisp/eval.rs', eval_source)

def core(s):
    s = remove_arm(s, 'Kind::String(_) => Ok(*expr)')
    return s
edit('src/lisp/eval/core.rs', core)

def completion(s):
    s = between(s, '        (Kind::String(_), Kind::String(_))', '        (Kind::Cons(left),', '')
    s = remove_arm(s, 'Kind::String(text) => {')
    return s
edit('src/lisp/primitives/completion.rs', completion)

def context(s):
    s = s.replace('    String(usize),\n', '')
    s = remove(s, ['Kind::String(text) => ObjectKey::String', 'Kind::String(_) => DumpType::String'])
    s = between(s, '        let kind = match object.kind() {', '        let size = ', '        let kind = DumpType::StringObject;\n')
    return s
edit('src/lisp/primitives/pdumper/context.rs', context)
edit('src/lisp/primitives/pdumper/load.rs', lambda s: remove_arm(s, 'Kind::String(text) => std::borrow::Cow::Borrowed'))

def concat(s):
    s = between(s, 'fn plain_multibyte(', 'fn visit_sequence(', '')
    return remove(s, [
        'Kind::String(text) if text.is_ascii() =>',
        'Kind::String(text) => {',
        'Kind::String(text) if !plain_multibyte',
        'Kind::String(text) if text.is_ascii() =>',
        'Kind::String(text) => {',
    ])
edit('src/lisp/types/string_data/concat.rs', concat)

def strings(s):
    s = remove(s, ['Kind::String(_) => {', 'Kind::String(text) => Some(std::borrow::Cow::Borrowed', 'Kind::String(text) => Some(StringLike {'])
    s = between(s, '    fn code_in(', '    match value.kind() {', '')
    s = remove_arm(s, 'Kind::String(text) => {')
    s = between(s, 'pub(crate) fn string_texts_equal_in_place(', 'pub(crate) fn string_text(', '''pub(crate) fn string_texts_equal_in_place(left: &Value, right: &Value) -> Option<bool> {
    let (Kind::StringObject(left), Kind::StringObject(right)) = (left.kind(), right.kind()) else {
        return None;
    };
    let left = left.borrow();
    let right = right.borrow();
    Some(left.len() == right.len() && left.bytes() == right.bytes())
}

''')
    s = remove_arm(s, 'Kind::String(text) => text')
    s = between(s, 'pub(crate) fn aset_string_value(', 'pub(crate) fn shared_string_props(', '''pub(crate) fn aset_string_value(
    target: &Value,
    index: usize,
    new_value: &Value,
) -> Result<Value, LispError> {
    let Kind::StringObject(state) = target.kind() else {
        return Err(LispError::WrongTypeArgument("stringp".into(), *target));
    };
    let mut state = state.borrow_mut();
    // data.c:Faset checks the existing index before NEWELT.
    if index >= state.len() {
        drop(state);
        return Err(args_out_of_range_for_aset(target, index));
    }
    let code = crate::lisp::types::string_data::character_code(*new_value)?;
    if !state.store_character(index, code) {
        drop(state);
        return Err(LispError::SignalValue(Value::list([
            Value::symbol("args-out-of-range"), *target, *new_value,
        ])));
    }
    Ok(*target)
}

''')
    s = between(s, '        // A plain interned string has no shared property state', '        return Err(LispError::WrongTypeArgument("stringp".into(), *value));', '')
    return s
edit('src/lisp/primitives/strings.rs', strings)

def collections(s):
    s = remove(s, ['Kind::String(text) => {', 'Kind::String(_) => Ok(Value::Nil)', 'Kind::String(text) => text.chars().count()'])
    start = s.index('            "fillarray" => {')
    a = s.index('                    Kind::StringObject(state) => {', start)
    b = s.index('                    value if is_bool_vector_value', a)
    s = s[:a] + '''                    Kind::StringObject(state) => {
                        state.borrow_mut().fill(args[1])?;
                        Ok(args[0])
                    }
''' + s[b:]
    return s
edit('src/lisp/primitives/dispatch/collections.rs', collections)

def state(s):
    a = s.index('    /// fns.c:Fclear_string')
    return s[:a] + '''    /// fns.c:Ffillarray validates ITEM even for an empty string. Unibyte
    /// strings store its low byte; multibyte fills cannot resize the payload.
    /// Existing intervals and aliases continue to name the same object.
    pub(crate) fn fill(&mut self, item: Value) -> Result<(), LispError> {
        let code = character_code(item)?;
        if self.characters == 0 {
            return Ok(());
        }
        let (encoded, width) = if self.multibyte {
            encode_character(code)?
        } else {
            ([code as u8, 0, 0, 0, 0], 1)
        };
        if self.characters.checked_mul(width) != Some(self.bytes.len()) {
            return Err(LispError::Signal("Attempt to change byte length of a string".into()));
        }
        if width == 1 {
            self.bytes.fill(encoded[0]);
        } else {
            for bytes in self.bytes.chunks_exact_mut(width) {
                bytes.copy_from_slice(&encoded[..width]);
            }
        }
        Ok(())
    }

''' + s[a:]
edit('src/lisp/types/string_data.rs', state)

def buffer_edit(s):
    s = s.replace('Kind::String(text) if text.chars().count() == 1 => text.chars().next(),', 'Kind::StringObject(text) if text.borrow().len() == 1 => text.borrow().text().chars().next(),')
    s = s.replace('                    if matches!(object.kind(), Kind::String(_)) {\n                        return Ok(Value::T);\n                    }\n', '')
    return s
edit('src/lisp/primitives/dispatch/buffer_edit.rs', buffer_edit)
edit('src/lisp/primitives/dispatch/display.rs', lambda s: s.replace('Kind::String(path) => Some(path.to_string()),', 'Kind::StringObject(path) => Some(path.borrow().text()),'))
edit('src/lisp/eval/ert.rs', lambda s: s.replace('Kind::String(value) => value.to_string(),', 'Kind::StringObject(value) => value.borrow().text(),').replace('Kind::String(pattern) => Regex::new(&pattern)', 'Kind::StringObject(pattern) => Regex::new(&pattern.borrow().text())'))
edit('src/lisp/alloc.rs', lambda s:s.replace('Kind::String(text) => format!(', 'Kind::StringObject(text) => format!(').replace('text.as_str().chars().take(24)', 'text.borrow().text().chars().take(24)'))
edit('src/lisp/primitives/keys.rs', lambda s:s.replace('Some(Kind::String(_))', 'Some(Kind::StringObject(_))'))
edit('src/lisp/primitives/print.rs', lambda s:s.replace('Some(file @ Kind::String(_))', 'Some(file @ Kind::StringObject(_))'))

# Retain the same equality/identity and dump-roundtrip assertions using the
# canonical kind; no assertion is deleted for an implementation-only variant.
edit('src/lisp/primitives/pdumper/tests.rs', lambda s:s.replace('(Kind::String(_), Kind::String(_)) | (Kind::StringObject(_), Kind::StringObject(_))', '(Kind::StringObject(_), Kind::StringObject(_))'))
edit('src/lisp/eval/tests/eval_02.rs', lambda s:s.replace('matches!(items[2].kind(), Kind::String(name) if !name.is_empty())\n            || ', ''))
edit('src/lisp/primitives/tests.rs', lambda s:s.replace('Kind::String(', 'Kind::StringObject(').replace('"Fpurecopy strips mutable string storage"', '"Fpurecopy retains canonical string storage"').replace('text.as_str().to_string()', 'text.borrow().text()'))
edit('src/tty.rs', lambda s:s.replace('value.as_string().map(str::to_string).ok()', 'value.as_string().ok()'))
print('Removed legacy string consumer branches in isolated draft')
