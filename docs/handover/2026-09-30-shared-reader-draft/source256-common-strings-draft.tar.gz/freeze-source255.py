from pathlib import Path
import hashlib, json, subprocess
p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/common-strings/emaxx'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
files = [*root.joinpath('src').rglob('*.rs'), *root.joinpath('tests').rglob('*')]
files += [root / name for name in ['Cargo.toml', 'Cargo.lock', 'build.rs', 'tools/ttydiff.py', 'tools/fixtures/fieldnotes.org', 'tools/fixtures/fake_lsp_server.py']]
files += list(root.joinpath('.cargo').glob('*'))
files += [root / name for name in ['compat/emacs_compat_runner.el', 'src/lisp/bytecode/fixture-oracle-30.2.elc', 'src/lisp/bytecode/fixture-oracle2-30.2.elc', 'src/lisp/bytecode/fixture-oracle3-30.2.elc']]
manifest = {str(file.relative_to(root)): sha(file) for file in sorted(set(files)) if file.is_file()}
assert len(manifest) == 480
assert json.loads((p / 'source255-manifest.json').read_text()) == manifest
untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=root, text=True).splitlines()
extra = b''
for name in sorted(set(untracked) & set(manifest)):
    result = subprocess.run(['git', 'diff', '--no-index', '--binary', '--', '/dev/null', name], cwd=root, capture_output=True)
    assert result.returncode == 1 and not result.stderr
    extra += result.stdout
patches = {}
for label, base in [('portable-incremental', 'b8e5ad209e7ab05693a39eae2dc3a90408ef6871'),
                    ('portable-complete', '21d20f0eec08f3c013d5d3eb3bd6e9cfc16b3199')]:
    patch = subprocess.check_output(['git', 'diff', '--binary', base, '--', *sorted(manifest)], cwd=root) + extra
    target = p / ('source255-' + label + '.patch')
    with target.open('xb') as f:
        f.write(patch)
    patches[label] = dict(base=base, sha256=sha(target), bytes=len(patch))
record = dict(inputs=480, patches=patches, candidate=str(root), goal_complete=False,
              qualification='Isolated common-string draft. One canonical payload replaces the plain StringCell arena, binding copies and VM text adapter. Host symbol keys are owned by symbol cells; Lisp names retain canonical identity. Dumping preserves actual string bytes and flags. GNU-backed fillarray rules preserve properties and reject byte resizing. Strict checks pass; selected runtime validation is pending. Earlier compiler and lint failures, both original ordinary negatives and exact GNU expected bytes remain retained. This is not applied to the task runtime or a completion/performance claim.')
with (p / 'source255-freeze.json').open('x') as f:
    json.dump(record, f, indent=2)
print(json.dumps(record, indent=2))
