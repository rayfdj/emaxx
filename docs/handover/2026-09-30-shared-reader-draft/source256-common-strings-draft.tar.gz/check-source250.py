import subprocess,os,json,time
from pathlib import Path
p=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28')
r=json.loads((p/"source250-check-command.json").read_text())
t=time.monotonic()
with (p/"source250-check.log").open("xb") as log:
 c=subprocess.run(r["command"],cwd=r["cwd"],env=dict(os.environ,**r["environment_override"]),stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
with (p/"source250-check-result.json").open("x") as f:json.dump({"exit_code":c.returncode,"elapsed_seconds":time.monotonic()-t},f,indent=2)
