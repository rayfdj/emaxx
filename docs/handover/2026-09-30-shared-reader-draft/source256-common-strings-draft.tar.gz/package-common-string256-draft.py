from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
frozen = read('source256-freeze.json')
replay = read('source256-patch-replay-audit.json')
failed = read('source255-focused-audit.json')
c_review = read('source256-c-reference-audit.json')
assert frozen['inputs'] == 480 and replay['status'] == 'exact'
assert failed['status'] == 'failed' and failed['counts'] == {'ok': 181, 'FAILED': 1, 'ignored': 2}
for stage in ['check', 'fmt', 'clippy', 'diff']:
    receipt = read('source256-' + stage + '-result.json')
    assert receipt['exit_code'] == 0 and receipt['source_unchanged']
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected'}
helpers = {
    'draft-common-string-core.py', 'draft-common-string-core-repaired.py',
    'draft-common-string-consumers.py', 'draft-common-string-borrows.py', 'draft-common-string-cleanup.py',
    'check-source250.py', 'check-common-string-draft.py', 'run-common-string-focused.py',
    'audit-common-string-focused.py', 'run-common-string-release.py', 'audit-common-string-release.py',
    'test-common-string-broad.py', 'build-common-string-ordinary.py', 'compare-common-string-fixtures.py',
    'queue-common-string256-validation.py', 'freeze-source255.py', 'freeze-source256.py',
    'audit-source255-patches.py', 'audit-source256-patches.py', 'audit-common-string-c-reference.py',
    'probe-host-string-mutation-source249.py', 'probe-host-string-vector-mutation-source249.py',
    'probe-bytecode-unibyte-constructor.py', 'host-string-mutation.el', 'host-string-vector-mutation.el',
    'bytecode-unibyte-constructor.el', 'common-strings-draft-checkout.json',
    'common-string-edit-helper-failure.json', 'common-string-cleanup-helper-failure.json',
    'package-source196-failure-and197-results.py', Path(__file__).name,
}
files = {}
for file in p.iterdir():
    if not file.is_file() or file.suffix not in allowed:
        continue
    name = file.name
    if name in helpers or name.startswith(('source249-host-string-', 'source250-', 'source251-', 'source252-', 'source253-', 'source254-', 'source255-')):
        files[name] = file
    elif name.startswith('source256-'):
        # Only completed strict checks, frozen patches and immutable launches
        # belong to this draft snapshot. Active logs and mutable states do not.
        if any(name.startswith('source256-' + stage + '-') or name == 'source256-' + stage + '.log'
               for stage in ['check', 'fmt', 'clippy', 'diff', 'format']):
            files[name] = file
        elif name in ['source256-manifest.json', 'source256-unformatted.patch', 'source256-incremental.patch',
                      'source256-freeze.json', 'source256-portable-incremental.patch', 'source256-portable-complete.patch',
                      'source256-patch-replay-audit.json', 'source256-c-reference-audit.json', 'source256-draft-history.json',
                      'source256-validation-launch.json', 'source256-validation-queue-launch.json',
                      'source256-validation-queue-state-snapshot-20261001T1606Z.json']:
            files[name] = file
assert helpers <= files.keys()
for stem in ['host-string-mutation', 'host-string-vector-mutation']:
    for suffix in ['.el', '.expected']:
        name = 'tests/fixtures/' + stem + suffix
        files['source256-fixtures/' + stem + suffix] = p.parent / 'recovered-2026-09-30/common-strings/emaxx' / name
package('source256-common-strings-draft', files, dict(
    current_source='source256', source_inputs=480, frozen=frozen, patch_replay=replay,
    strict_checks='zero-warning pass', original_source255_focused_failure=failed,
    c_reference=c_review, queue_launch=read('source256-validation-queue-launch.json'),
    qualification='Separately packaged unfinished common-string draft; task runtime remains source249. All negative fixture/GNU output bytes, intermediate check failures and the failed source255 runtime evidence are preserved. Source256 uses actual unibyte bytes in the demonstrably invalid local fixture and retains all original assertions plus a Unicode rejection control. Selected gate/release/broader/ordinary checks are queued after terminal12347. No complete runtime, performance, physical-layout or full-goal certificate.'))
