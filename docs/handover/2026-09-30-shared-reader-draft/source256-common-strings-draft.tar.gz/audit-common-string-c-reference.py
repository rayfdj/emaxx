from pathlib import Path
import hashlib, json, subprocess

p = Path(__file__).parent.resolve()
root = p.parents[2]
candidate = p.parent / 'recovered-2026-09-30/common-strings/emaxx'
gnu = p.parent / 'rebuilt-2026-10-01/emacs'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read('source256-manifest.json')
assert len(manifest) == 480 and all(sha(candidate / name) == digest for name, digest in manifest.items())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=gnu, text=True).strip() == '636f166cfc86aa90d63f592fd99f3fdd9ef95ebd'
assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=gnu, text=True)
references = {
    'src/lisp.h': ['struct Lisp_String', 'STRING_MULTIBYTE (Lisp_Object str)'],
    'src/alloc.c': ['init_strings (void)', 'make_string (const char *contents', 'make_unibyte_string (const char *contents', 'make_multibyte_string (const char *contents', 'DEFUN ("make-byte-code"'],
    'src/data.c': ['DEFUN ("symbol-name"', 'DEFUN ("aset"'],
    'src/fns.c': ['DEFUN ("fillarray"', 'DEFUN ("clear-string"'],
    'src/bytecode.c': ['DEFUN ("byte-code"'],
}
records = {}
for name, needles in references.items():
    text = (gnu / name).read_text()
    records[name] = dict(sha256=sha(gnu / name), anchors={needle: text[:text.index(needle)].count('\n') + 1 for needle in needles})
for stem in ['host-string-mutation', 'host-string-vector-mutation']:
    fixture = candidate / 'tests/fixtures' / (stem + '.el')
    expected = fixture.with_suffix('.expected')
    assert fixture.read_bytes() == (p / (stem + '.el')).read_bytes()
    assert expected.read_bytes().rstrip(b'\n') == (p / ('source249-' + stem + '-gnu.stdout')).read_bytes()
    original = read('source249-' + stem + '-comparison.json')
    assert original['inputs_unchanged'] and not original['same_stdout']
    assert all(result['exit_code'] == 0 for result in original['results'].values())
old = read('source255-manifest.json')
assert {name for name in manifest if manifest[name] != old[name]} == {'src/lisp/bytecode.rs'}
failed = read('source255-focused-audit.json')
assert failed['counts'] == {'ok': 181, 'FAILED': 1, 'ignored': 2}
constructor = read('source255-bytecode-constructor-gnu-result.json')
assert constructor['exit_code'] == 0 and constructor['inputs_unchanged']
assert (p / 'source255-bytecode-constructor-gnu.stdout').read_text() == '((nil 2 2 (t t (137 135) 42)) (t 2 4 (error "Invalid byte-code object")))'
all_rust = '\n'.join(path.read_text() for path in (candidate / 'src').rglob('*.rs'))
for removed in ['Kind::String(', 'struct StringCell', 'struct TextRef', 'fn stored_value(', 'new_untracked(', 'fn unibyte_bytes(']:
    assert removed not in all_rust, removed
runtime_facts = [
    'One StringObjectRef payload carries actual bytes, character count, multibyte flag and properties; SharedText is an alias, not another storage class.',
    'The old plain-string arena, GC tracing, sweep and census are removed. Binding/callback/completion conversion copies and the bytecode text adapter are removed.',
    'Ordinary string mutation uses the existing canonical payload. fillarray validates even empty strings, keeps properties, stores low bytes in unibyte strings and rejects a changed multibyte storage length, following fns.c.',
    'Dumping writes actual bytes/counts/flag and one string object key/type. Loading both previous wire types creates the same canonical payload.',
    'The supplied Lisp symbol-name object is retained. Immutable host lookup keys are owned by SymbolCell and dropped with it, instead of occupying a second GC string cell.',
    'The source255 bytecode fixture failure is preserved. Source256 constructs actual unibyte opcodes, retains every original assertion and adds rejection of the previous Unicode form, as confirmed by ordinary GNU make-byte-code.',
]
limitations = [
    'This is not GNU\'s 32-byte Lisp_String layout or sblock allocator: RefCell, Vec headers/capacities, property spans and vector allocation overhead remain. The existing GNU-formula allocation charge is not physical Rust accounting.',
    'Moving host symbol keys into SymbolCell grows that cell; it removes a separate key cell but establishes no net physical memory saving. Value/function/plist authority still lives in per-interpreter tables and symbol id/name registries.',
    'Host-text construction retains the old raw-byte/private-use convention. Many consumers still allocate transient decoded Rust text. Performance effects are unmeasured.',
    'The permanent empty unibyte string is canonical. The GNU empty multibyte singleton and general pure-string write protection remain unfinished.',
    'Public runtime ownership, collection while values/borrows remain externally accessible, true cumulative counters, physical accounting, VM stack layout, locked workloads and final adversarial audit are unfinished.',
    'Source256 strict checks pass; complete gate/release/ordinary validation is queued. Source255 focused failure is not a source256 passing result. No runtime draft is applied to the task branch.',
]
record = dict(source='source256', inputs=480, gnu_revision='636f166cfc86aa90d63f592fd99f3fdd9ef95ebd',
              gnu_references=records, implementation=runtime_facts, remaining=limitations,
              changed_since_source255=['src/lisp/bytecode.rs'], prior_failure=failed['counts'],
              goal_complete=False, qualification='Static mechanism review against the pristine configured GNU C source and unchanged ordinary negative fixtures. This is not a full correctness, layout, memory, performance or ownership certificate.')
with (p / 'source256-c-reference-audit.json').open('x') as out:
    json.dump(record, out, indent=2)
print('GNU C reference and unchanged negative fixtures verified; architecture and performance limitations recorded')
