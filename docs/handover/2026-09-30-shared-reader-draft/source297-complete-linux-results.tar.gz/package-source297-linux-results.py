from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
out = p.parents[2] / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda n: json.loads((p / n).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
rust = read('source297-linux-rust-audit.json')
names = read('source297-linux-rust-name-audit.json')
frozen = read('source297-linux-frozen-raw-integrity-audit.json')
assert rust['status'] == frozen['status'] == names['status'] == 'passed'
assert rust['total_passed'] == 3148 and rust['library_ignored'] == 2
assert names['raw_names_verified'] == 3047
assert frozen['files'] == 519 and frozen['outcomes'] == 7928
files = {}
excluded = []
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.h', '.apparmor', '.loaded'}
for kind in ['rust', 'frozen']:
    folder = p / ('source297-linux-' + kind + '-artifacts')
    download = read('source297-linux-' + kind + '-download-files.json')
    assert all(sha((folder / name).read_bytes()) == digest for name, digest in download['files'].items())
    for f in folder.rglob('*'):
        if not f.is_file():
            continue
        if f.suffix in allowed or f.name == 'Makefile':
            files[str(f.relative_to(p))] = f
        else:
            excluded.append(dict(path=str(f.relative_to(p)), bytes=f.stat().st_size, sha256=sha(f.read_bytes())))
for f in p.glob('source297-linux-*'):
    if f.is_file() and f.suffix in allowed:
        files[f.name] = f
for name in ['source297-full-validation-launch.json', 'source297-manifest.json',
             'source297-applied-commit.json', 'source297-applied-push.json',
             'source297-portable-complete.patch', 'audit-source297-linux-rust-names.py',
             'verify-source297-linux-rust.py', 'audit-source297-linux-frozen.py',
             'verify-complete-frozen-receipts279.py', 'package-source196-failure-and197-results.py',
             Path(__file__).name]:
    files[name] = p / name
package('source297-complete-linux-results', files, dict(
    status='closed source297 Linux Rust and frozen validation',
    rust=rust, names=names, oracle=read('source297-linux-rust-oracle-audit.json'),
    frozen=dict(status=frozen['status'], files=frozen['files'], outcomes=frozen['outcomes'],
                successful_processes=frozen['successful_processes'], run_id=frozen['run_id'],
                raw_integrity_audit_sha256=sha((p / 'source297-linux-frozen-raw-integrity-audit.json').read_bytes())),
    excluded_binaries=excluded,
    qualification='Exact published4af440a9 and532 source inputs verify. Every3047 library name/verdict,3148 Rust passes/two existing ignores, native artifact identity and retained artifacts verify. Frozen519 files/7928 equal outcomes/1038 successful processes and all177 compiler controls verify. Actual GNU executable/dump/configuration/Makefile hashes match the pins. Prior GNU census failures and the source276 Emaxx negative remain unresolved; this passing run does not erase them. These predecessor results do not certify source300/301, macOS, final ownership/counters or GNU parity.',
    goal_complete=False))
