from pathlib import Path
import hashlib
import json
import re

p = Path(__file__).parent.resolve()
root = p / "source297-linux-rust-artifacts/ordinary-linux-4af440a93be274739b3745d26e9026e12974b411/rust"
summary = json.loads((root / "summary.json").read_text())
inventory = [line[:-6] for line in (root / "inventory.txt").read_text().splitlines() if line.endswith(": test")]
assert summary["status"] == "passed" and len(inventory) == 3047
prior_root = p / "source296-linux-rust-artifacts/ordinary-linux-68ca5d8819ddae6f699ac7eeae694b1b19867261/rust"
prior_names = {line[:-6] for line in (prior_root / "inventory.txt").read_text().splitlines() if line.endswith(": test")}
assert set(inventory) == prior_names | {'lisp::native_comp::runtime::tests::native_many_empty_and_negative_list_counts_accept_null_storage'}
ignored = summary["inventory"]["ignored_tests"]
seen = []
for group in summary["runs"][0]["groups"]:
    log = (root / Path(group["log"]).name).read_text()
    starts = list(re.finditer(r"^test (\S+) \.\.\. ", log, re.M))
    assert len(starts) == group["expected_tests"], group["group"]
    for index, match in enumerate(starts):
        end = starts[index + 1].start() if index + 1 < len(starts) else log.rindex("test result:")
        captured = log[match.end():end].strip()
        if match[1] in ignored:
            assert captured.startswith("ignored"), match[1]
        else:
            assert re.search(r"(?:^|\s)ok$", captured), (match[1], captured)
        seen.append(match[1])
assert sorted(seen) == sorted(inventory) and len(seen) == len(set(seen))
with (p / "source297-linux-rust-name-audit.json").open("x") as stream:
    json.dump({"status": "passed", "raw_names_verified": len(seen),
               "inventory_sha256": hashlib.sha256((root / "inventory.txt").read_bytes()).hexdigest(),
               "qualification": "Every raw library test name and final libtest verdict matches the complete inventory, including the two existing ignores. Native test output before the final verdict is preserved. Complements the count, native identity and retained-artifact audit."}, stream, indent=2)
print("Verified", len(seen), "distinct raw test names and verdicts")
