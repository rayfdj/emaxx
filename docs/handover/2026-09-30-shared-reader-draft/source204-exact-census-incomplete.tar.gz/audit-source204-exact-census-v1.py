from pathlib import Path
import ast, hashlib, io, json, re, subprocess, tarfile

p = Path(__file__).parent.resolve()
repository = p.parents[2]
root = next((p / 'linux-source204-census-artifacts').rglob('rust-exact-census/summary.json')).parent
summary = json.loads((root / 'summary.json').read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
assert summary['status'] == 'diagnostic error'
assert summary['binary_sha256'] == '6ea03c1ac6c36eea7cdbdbd8a32369954b5a079b266d4950dd4e1a942aa663bc'
assert summary['image_sha256'] == '85ebb975393d794a1b8fdb1a27ba835161ab7b99484f4cae70c217298c52827e'
sources = json.loads((root / 'source-before.json').read_text())
assert len(sources) == summary['source_inputs'] == 403
archive = subprocess.check_output(['git', 'archive', summary['source_revision'], '--', *sources], cwd=repository)
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
    assert all(hashlib.sha256(tar.extractfile(name).read()).hexdigest() == value for name, value in sources.items())
tree = ast.parse((p / 'audit-shared-reader196-fresh-selected.py').read_text())
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'audit_log')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<raw-auditor>', 'exec'))
for label, passed in [('selected', 0), ('original-group', 624)]:
    result = summary[label]
    assert result['exit_code'] == 101 and not result['timed_out'] and not result['callback_errors']
    assert all(result[n] for n in ['binary_unchanged', 'image_unchanged', 'source_unchanged', 'inventory_matches'])
    failures = audit_log(result['expected_names'], (root / result['log']).read_text(), passed, 2)
    assert failures == summary['selected']['expected_names']
debugger = summary['debugger']
assert debugger['exit_code'] == 255 and not debugger['timed_out']
assert debugger['callback_errors'] == ['Traceback (most recent call last):'] and debugger['summaries'] == []
raw = (root / 'debugger.log').read_text()
assert 'ValueError: cleanup inventory exceeds bounded observer' in raw
events = [json.loads(row) for row in re.findall(r'CENSUS_TRACE (\{[^\n]*\})', raw)]
sweeps = [event for event in events if event['event'] == 'swept vectors']
assert [(event['test'], event['collection']) for event in sweeps] == [('native_pseudovector_census_matches_gnu_word_layout', n) for n in [1, 2, 3, 4]]
second = sweeps[1]['objects']
assert [(obj['tag'], obj['slots']) for obj in second] == [(0, 41), (34, 6)]
assert int(second[1]['payload'][2], 16) == 4
assert not sweeps[2]['objects'] and not sweeps[3]['objects']
record = dict(status='exact failures reproduced; debugger incomplete', source_revision=summary['source_revision'],
              source_inputs_verified=403, binary_sha256=summary['binary_sha256'], image_sha256=summary['image_sha256'],
              selected=dict(passed=0, failed=2), original_group=dict(passed=624, failed=2),
              debugger_exit_code=255, debugger_error='cleanup inventory exceeds bounded observer',
              first_control_second_sweep=second, second_control_first_sweep_incomplete=True,
              raw_log_hashes={name: sha(root / name) for name in ['selected.log', 'original-group.log', 'debugger.log']},
              qualification='The first control reclaimed a 41-element vector and a host record with four detached fields in its second explicit sweep; later two sweeps reclaimed no counted vectors. This is partial diagnostic evidence, not a completed debugger outcome or established retaining root. Native-heap roots were captured; the independent host conservative stack was not yet captured.')
with (p / 'source204-exact-census-v1-audit.json').open('x') as f:
    json.dump(record, f, indent=2)
    f.write('\n')
print(json.dumps({k: v for k, v in record.items() if k != 'first_control_second_sweep'}, indent=2))
