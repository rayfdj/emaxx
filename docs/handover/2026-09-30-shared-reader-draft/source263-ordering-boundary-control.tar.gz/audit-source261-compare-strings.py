from pathlib import Path
import hashlib
import json
import re

p = Path(__file__).parent.resolve()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())


def parse(text):
    tokens = iter(re.findall(r'"(?:\\.|[^"\\])*"|[()]|[^()\s]+', text))

    def one(token):
        if token != '(':
            assert token != ')'
            return token
        result = []
        for token in tokens:
            if token == ')':
                return result
            result.append(one(token))
        raise AssertionError('Unclosed list')

    result = one(next(tokens))
    assert next(tokens, None) is None
    return result


records = []
for fixture, count, width in [('compare-strings-ranges', 22, 2),
                               ('compare-strings-character-storage', 1024, 5),
                               ('compare-strings-live-case-table', 3, 7)]:
    outcomes, processes = {}, {}
    for editor in ['gnu', 'source261', 'source174']:
        stem = 'source261-probe-' + fixture + '-' + editor
        command, result = read(stem + '-command.json'), read(stem + '-result.json')
        assert not result['timed_out'] and result['source_unchanged'] and result['inputs_unchanged']
        assert all(sha(Path(name)) == digest for name, digest in command['inputs'].items())
        assert sha(p / (stem + '.stdout')) == result['stdout_sha256']
        assert sha(p / (stem + '.stderr')) == result['stderr_sha256']
        processes[editor] = result
        if fixture == 'compare-strings-character-storage' and editor == 'source174':
            assert result['exit_code'] == 255
            continue
        assert result['exit_code'] == 0 and not (p / (stem + '.stderr')).read_bytes()
        rows = parse((p / (stem + '.stdout')).read_text())
        assert len(rows) == count and all(len(row) == width for row in rows)
        key_width = 4 if width == 5 else 1
        outcomes[editor] = {tuple(row[:key_width]): row[key_width:] for row in rows}
        assert len(outcomes[editor]) == count
    gnu = outcomes['gnu']
    assert all(rows.keys() == gnu.keys() for rows in outcomes.values())
    if width == 5:
        labels = {key[2] for key in gnu}
        assert len(labels) == 16
        assert set(gnu) == {(buffer, ignore_case, left, right) for buffer in ['nil', 't']
                            for ignore_case in ['nil', 't'] for left in labels for right in labels}
    else:
        assert outcomes['source174'] == outcomes['source261']
    differences = [dict(key=list(key), gnu=value, source261=outcomes['source261'][key])
                   for key, value in gnu.items() if value != outcomes['source261'][key]]
    record = dict(fixture=fixture, fixture_sha256=sha(p / (fixture + '.el')),
                  compared_rows=count, differing_rows=len(differences),
                  differences=differences, processes=processes)
    if width == 7:
        assert all(value[0] == outcomes['source261'][key][0] for key, value in gnu.items())
        record['upcase_observations_match'] = True
        record['wrong_comparison_observations'] = sum(
            a != b for key, value in gnu.items() for a, b in zip(value[1:], outcomes['source261'][key][1:]))
    record['historical_limit'] = (
        'Main/source174 exited255 before producing the character matrix; its raw failure is preserved. No historical row attribution is inferred.'
        if width == 5 else 'Main/source174 output is byte-identical to source261 for this fixture; all observed differences here predate the current task branch.')
    records.append(record)
gnu = p.parent / 'rebuilt-2026-10-01/emacs'
references = {}
for file, anchors in {
    'src/fns.c': ['DEFUN ("compare-strings"', 'validate_subarray (Lisp_Object array'],
    'src/character.h': ['fetch_string_char_as_multibyte_advance (Lisp_Object string'],
    'src/casefiddle.c': ['case_character_impl (struct casing_str_buf', 'do_casify_natnum ('],
}.items():
    lines = (gnu / file).read_text().splitlines()
    references[file] = dict(sha256=sha(gnu / file), anchors={
        anchor: next(i + 1 for i, line in enumerate(lines) if anchor in line) for anchor in anchors})
record = dict(status='ordinary compare-strings negatives verified', fixtures=records,
              gnu_references=references, goal_complete=False,
              qualification='Eight ordinary processes complete with empty stderr; the ninth is a preserved main/source174 failure. Inputs, raw output hashes, exact range errors and all matrix keys are checked. Live upcase follows the changed case table while compare-strings does not. Existing frozen/selected inputs are unchanged; this audit does not validate a repair or establish general historical attribution.')
with (p / 'source261-compare-strings-negative-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps([dict(fixture=row['fixture'], rows=row['compared_rows'], differing_rows=row['differing_rows'],
                       wrong_comparison_observations=row.get('wrong_comparison_observations')) for row in records], indent=2))
