from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

p = Path(__file__).parent.resolve()
candidate = p.parent / 'recovered-2026-09-30/string-ranges/emaxx'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read('source263-manifest.json')
unchanged = lambda: len(manifest) == 500 and all(sha(candidate / name) == digest for name, digest in manifest.items())
prior_pid = read('source263-validation-launch.json')['pid']
assert prior_pid == 64601
fixed = {name: sha(p / name) for name in [
    Path(__file__).name, 'audit-source263-selected.py', 'compare-string-ranges-fixtures.py',
    'source263-manifest.json', 'string-ordering-prefix-boundaries.el',
    'string-ordering-prefix-boundaries.expected', 'source261-string-prefix-audit.json',
]}
state = dict(status='waiting for source263 selected validation', prior_pid=prior_pid,
             fixed_inputs=fixed, results=[], goal_complete=False)


def save_state():
    (p / 'source263-boundary-queue-state.json').write_text(json.dumps(state, indent=2) + '\n')


def verify():
    assert unchanged() and all(sha(p / name) == digest for name, digest in fixed.items())


def run(stage, command):
    verify()
    state.update(status='running ' + stage)
    save_state()
    with (p / ('source263-boundary-' + stage + '-command.json')).open('x') as stream:
        json.dump(dict(command=command, working_directory=str(candidate), fixed_inputs=fixed), stream, indent=2)
    started = time.monotonic()
    with (p / ('source263-boundary-' + stage + '.log')).open('xb') as log:
        process = subprocess.run(command, cwd=candidate, stdin=subprocess.DEVNULL,
                                 stdout=log, stderr=subprocess.STDOUT,
                                 env=dict(os.environ, PYTHONUNBUFFERED='1', PYTHONDONTWRITEBYTECODE='1'))
    row = dict(stage=stage, exit_code=process.returncode, elapsed_seconds=time.monotonic() - started,
               source_unchanged=unchanged(), fixed_inputs_unchanged=all(sha(p / name) == digest for name, digest in fixed.items()))
    with (p / ('source263-boundary-' + stage + '-result.json')).open('x') as stream:
        json.dump(row, stream, indent=2)
    state['results'].append(row)
    save_state()
    verify()
    return process.returncode


save_state()
try:
    verify()
    while True:
        process = subprocess.run(['ps', '-p', str(prior_pid), '-o', 'command='], capture_output=True, text=True)
        if process.returncode == 1 and not process.stdout.strip():
            break
        assert process.returncode == 0 and 'queue-string-ranges263-validation.py' in process.stdout
        time.sleep(5)
    prior = read('source263-validation-result.json')
    state['prior_result_sha256'] = sha(p / 'source263-validation-result.json')
    assert prior['status'] == 'selected validation finished; raw results require audit'
    assert len(prior['results']) == len(prior['stages']) == 8
    assert all(row['exit_code'] == 0 and row['source_unchanged'] and row['prior_source_unchanged']
               and row['helper_unchanged'] for row in prior['results']), 'Preceding selected validation did not pass'
    assert run('selected-audit', [sys.executable, '-B', str(p / 'audit-source263-selected.py')]) == 0
    assert run('ordinary', [sys.executable, '-B', str(p / 'compare-string-ranges-fixtures.py'),
               'source263', str(candidate), 'string-ordering-prefix-boundaries']) == 0
    baseline = read('source261-string-prefix-audit.json')
    expected = (p / 'string-ordering-prefix-boundaries.expected').read_bytes().rstrip(b'\n')
    assert hashlib.sha256(expected).hexdigest() == baseline['stdout_sha256']
    for editor in ['gnu', 'emaxx']:
        stem = 'source263-ordinary-string-ordering-prefix-boundaries-' + editor
        row, command = read(stem + '.result.json'), read(stem + '.command.json')
        assert row['exit_code'] == 0 and not row['timed_out'] and row['expected_output']
        assert row['source_unchanged'] and row['inputs_unchanged']
        assert all(sha(Path(name)) == digest for name, digest in command['inputs'].items())
        assert (p / (stem + '.stdout')).read_bytes() == expected and not (p / (stem + '.stderr')).read_bytes()
    with (p / 'source263-boundary-control-audit.json').open('x') as stream:
        json.dump(dict(status='matched', comparisons=12600, source_inputs_verified=500,
                       fixture_sha256=fixed['string-ordering-prefix-boundaries.el'],
                       expected_stdout_sha256=baseline['stdout_sha256'], goal_complete=False,
                       qualification='Additional unchanged same-input ordinary control after all selected source263 stages pass. All12600 full-range/prefix comparisons match the original GNU/source261 baseline byte for byte. This supplements the28 ordinary selected fixtures; no complete-platform or performance pass is inferred.'), stream, indent=2)
    state.update(status='selected audit and boundary comparison passed')
except Exception as error:
    state.update(status='stopped without passing boundary validation', error=repr(error))
finally:
    save_state()
    with (p / 'source263-boundary-queue-result.json').open('x') as stream:
        json.dump(state, stream, indent=2)
print(json.dumps(state), flush=True)
sys.exit(0 if state['status'] == 'selected audit and boundary comparison passed' else 1)
