from pathlib import Path
import ast
import hashlib
import json
import re

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/eval-frames/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read('source207-manifest.json')
assert len(manifest) == 410 and all(sha(root / name) == digest for name, digest in manifest.items())
tree = ast.parse((p / 'audit-shared-reader196-fresh-selected.py').read_text())
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'audit_log')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<raw-auditor>', 'exec'))
build = read('source207-selected-build-validation-result.json')
assert build['passed'] and build['all_completed'] and build['source_unchanged']
rust = []
for profile in ['gate', 'release']:
    for suffix, count in [('focused', 9), ('selected', 596)]:
        stem = 'source207-' + profile + '-' + suffix
        command, result = read(stem + '-command.json'), read(stem + '-result.json')
        assert result['exit_code'] == 0 and result['source_unchanged']
        assert len(command['selected_inventory']) == count
        assert not audit_log(command['selected_inventory'], (p / (stem + '.log')).read_text(), count, 0)
        assert sha(p / ('source207-' + profile + '-libtest')) == command['binary_sha256']
    rust.append(dict(profile=profile, passed=596, failed=0, ignored=0, focused_subset=9))
for label in ['check', 'fmt', 'clippy', 'diff', 'gate-build', 'release-build', 'ordinary-build', 'ordinary-image']:
    outcome = read('source207-' + label + '-result.json')
    assert outcome['exit_code'] == 0 and outcome['source_unchanged']
    raw = (p / ('source207-' + label + '.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
    for line in raw.splitlines():
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        assert item.get('message', {}).get('level') not in ['error', 'warning']
for name, entry in read('source207-ordinary-artifacts.json').items():
    assert sha(Path(name)) == entry['sha256'] == sha(Path(entry['immutable_copy']))
comparison_result = read('source207-ordinary-comparisons-result.json')
assert comparison_result['exit_code'] == 0 and comparison_result['fixtures'] == 40
fixtures = read('source207-ordinary-comparisons-command.json')['fixtures']
assert len(fixtures) == len(set(fixtures)) == 40
for fixture in fixtures:
    stem = 'source207-ordinary-' + fixture
    comparison = read(stem + '-comparison.json')
    assert comparison['passed'] and comparison['exact_match']
    outputs = []
    for editor in ['gnu', 'emaxx']:
        result = read(stem + '-' + editor + '.result.json')
        command = read(stem + '-' + editor + '.command.json')
        assert result == comparison['outcomes'][editor]
        assert result['exit_code'] == 0 and not result['timed_out']
        assert result['source_unchanged'] and result['inputs_unchanged']
        assert result['expected_output'] is not False
        stdout = p / (stem + '-' + editor + '.stdout')
        assert sha(stdout) == result['stdout_sha256']
        assert (p / (stem + '-' + editor + '.stderr')).read_bytes() == b''
        assert all(sha(Path(name)) == digest for name, digest in command['inputs'].items())
        outputs.append(stdout.read_bytes())
    assert outputs[0] == outputs[1]
record = dict(status='selected evidence verified', rust=rust, ordinary_fixtures=fixtures,
              strict_checks='zero compiler/Clippy warnings, zero fmt/diff differences',
              inputs_rehashed=410, ordinary_artifacts=read('source207-ordinary-artifacts.json'),
              qualification='Selected macOS evidence only, including nine focused controls per profile as a subset of each 596-test selection. Source204 also passed locally. Linux repair, complete candidate gates, pinned Darwin oracle identity and the full performance goal remain separate requirements.')
with (p / 'source207-selected-audit.json').open('x') as f:
    json.dump(record, f, indent=2)
    f.write('\n')
print(json.dumps({k: v for k, v in record.items() if k not in ['ordinary_fixtures', 'ordinary_artifacts']}, indent=2))
