(let ((original-words-called 0)
      (tails (list 19 11529215046068469760 3.25
                   (copy-sequence "original-words-text")
                   (make-symbol "original-words-uninterned")
                   (vector 8 9 10) (make-bool-vector 17 t)
                   (make-char-table 'original-words-table)
                   (make-hash-table :size 3) (make-marker)
                   (record 'original-words-record 7 11)
                   (symbol-function 'car))))
  (list
   (mapcar
    (lambda (tail)
      (condition-case error-data
          (eval (cons '(lambda (&rest values)
                         (setq original-words-called
                               (1+ original-words-called)))
                      tail))
        (error
         (garbage-collect)
         (list (car error-data) (cadr error-data)
               (eq (caddr error-data) tail) original-words-called))))
    tails)
   (mapcar
    (lambda (head)
      (condition-case error-data
          (eval (list head '(setq original-words-called
                                 (1+ original-words-called))))
        (error
         (garbage-collect)
         (list (car error-data) (eq (cadr error-data) head)
               original-words-called))))
    (list (vector 'original-head) 3.25 11529215046068469760
          (copy-sequence "original-head-text")))
   (let* ((shared (cons 'original-shared nil))
          (function '(lambda (value) (garbage-collect) value)))
     (setcdr shared shared)
     (unwind-protect
         (eq (eval (list function (list 'quote shared))) shared)
       (setcdr shared nil)))))
