from pathlib import Path
import ast,hashlib,io,json,os,re,subprocess,tarfile,tempfile
p=Path(__file__).parent.resolve();repository=p.parents[2];checkout=p.parent/'recovered-2026-09-30/bytecode-closure/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();read=lambda n:json.loads((p/n).read_text())
manifest=read('source205-manifest.json');assert len(manifest)==410
assert all(sha(checkout/n)==h for n,h in manifest.items())
previous=read('source204-manifest.json');changed=[n for n,h in manifest.items() if previous[n]!=h]
assert changed==['src/lisp/native_comp/runtime/record_layout_tests.rs']
assert read('source205-gate-build-result.json')['exit_code']==0
outcome=read('source205-gate-baseline-result.json');assert outcome['exit_code']==101 and outcome['source_unchanged']
command=read('source205-gate-baseline-command.json');names=command['selected_inventory'];assert len(names)==2
assert sha(p/'source205-gate-libtest')==command['binary_sha256']
inventory=[line[:-6] for line in (p/'source205-gate-inventory.txt').read_text().splitlines() if line.endswith(': test')]
assert all(name in inventory for name in names)
namespace={'re':re};tree=ast.parse((p/'audit-source204-selected.py').read_text());node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='audit_log')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<raw-auditor>','exec'),namespace)
raw=(p/'source205-gate-baseline.log').read_text();assert sorted(namespace['audit_log'](names,raw,0,2))==sorted(names)
assert 'left: 88\n right: 40' in raw and 'left: 34\n right: 31' in raw
base=read('source205-base.json')['commit'];paths=['src','tests','Cargo.toml','Cargo.lock','build.rs','.cargo','compat/emacs_compat_runner.el','tools/ttydiff.py','tools/fixtures/fieldnotes.org','tools/fixtures/fake_lsp_server.py']
archive=subprocess.check_output(['git','archive',base,*paths],cwd=repository)
with tempfile.TemporaryDirectory(prefix='source205-patch-',dir='/private/tmp') as td:
 temp=Path(td)
 with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
  for member in tar.getmembers():assert (temp/member.name).resolve().is_relative_to(temp)
  tar.extractall(temp)
 result=subprocess.run(['git','apply','--unsafe-paths','--directory='+str(temp),str(p/'source205-complete.patch')],cwd=repository,capture_output=True,text=True)
 assert result.returncode==0,result.stderr
 assert all(sha(temp/n)==h for n,h in manifest.items())
 tracked=subprocess.check_output(['git','ls-files','--stage','--',*manifest],cwd=checkout,text=True).splitlines()
 modes={line.split('\t',1)[1]:line.split()[0] for line in tracked}
 assert all(bool((temp/n).stat().st_mode&0o111)==(modes[n]=='100755') for n in manifest)
fixtures=[('source204-closure-baseline','closure-representation-transitions',False,255),('source204-closure-controls','bytecode-closure-shared-constants',True,0),('source204-code-mutation','bytecode-code-mutation-baseline',False,0),('source204-active-code-mutation','bytecode-code-active-mutation-baseline',False,0)]
observations=[]
for tag,fixture,passing,code in fixtures:
 comparison=read(tag+'-ordinary-'+fixture+'-comparison.json');assert comparison['passed'] is passing
 outputs={}
 for editor in ['gnu','emaxx']:
  stem=tag+'-ordinary-'+fixture+'-'+editor;out=read(stem+'.result.json');cmd=read(stem+'.command.json')
  assert out==comparison['outcomes'][editor] and out['exit_code']==code and not out['timed_out'] and out['source_unchanged'] and out['inputs_unchanged']
  stdout=(p/(stem+'.stdout')).read_bytes();stderr=(p/(stem+'.stderr')).read_bytes()
  assert hashlib.sha256(stdout).hexdigest()==out['stdout_sha256'] and stderr.hex()==out['stderr_hex']
  assert all(sha(Path(f))==h for f,h in cmd['inputs'].items())
  if code==0:assert stderr==b''
  outputs[editor]=stdout.decode(errors='replace')
 if fixture=='bytecode-code-mutation-baseline':assert outputs=={'gnu':'((before 41 t) (after 193 67))','emaxx':'((before 41 t) (after 193 41))'}
 if fixture=='bytecode-code-active-mutation-baseline':assert outputs=={'gnu':'(67 194)','emaxx':'(41 194)'}
 observations.append({'fixture':fixture,'matched':passing,'exit_code_per_editor':code,'outputs':outputs})
record={'status':'confirmed negative architectural and mutation baselines','source_manifest_sha256':sha(p/'source205-manifest.json'),'complete_patch_sha256':sha(p/'source205-complete.patch'),'input_count':410,'changed_from_published_runtime':changed,'patch_replay_and_modes_verified':True,'raw_passed':0,'raw_failed':2,'binary_sha256':command['binary_sha256'],'first_allocation_bytes':88,'gnu_header_and_slots_bytes':40,'header_tags':{'current':34,'gnu_closure':31},'ordinary':observations,'qualification':'Runtime source204 is unchanged. Only two tests were added in the isolated baseline. The invalid closure-aset probe stays failed; the valid constants/clone/GC/rejected-aset comparison passes. Code-string mutation differs both between calls and inside an active call. An entry-only cache refresh would not repair the latter. No layout or VM repair implemented.'}
with (p/'source205-baseline-audit.json').open('x') as f:json.dump(record,f,indent=2)
print('Verified source205 negative baseline, exact patch replay, valid closure contracts and both code-mutation failures.')
