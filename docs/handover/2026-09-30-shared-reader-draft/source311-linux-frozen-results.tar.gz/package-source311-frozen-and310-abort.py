from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve();out=p.parents[2]/'docs/handover/2026-09-30-shared-reader-draft';sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda n:json.loads((p/n).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package');exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
allowed={'.json','.log','.txt','.py','.patch','.stdout','.stderr','.el','.expected','.h','.loaded','.c'}
audit=read('source311-linux-frozen-complete-audit.json');raw=read('source311-linux-frozen-raw-integrity-audit.json');assert audit['status']=='matched' and raw['status']=='passed';files={}
for f in (p/'source311-linux-frozen-artifacts').rglob('*'):
 if f.is_file() and f.suffix in allowed:files[str(f.relative_to(p))]=f
for n in ['source311-linux-frozen-complete-audit.json','source311-linux-frozen-raw-integrity-audit.json','source311-linux-frozen-terminal.json','source311-linux-frozen-download.json','source311-linux-collection-result.json','source311-full-validation-launch.json','audit-source311-linux-frozen.py','verify-complete-frozen-receipts279.py','source311-manifest.json',Path(__file__).name,'package-source196-failure-and197-results.py']:files[n]=p/n
package('source311-linux-frozen-results',files,dict(status='complete source311 Linux frozen comparison matched',audit=audit,goal_complete=False,qualification='All 519 files, 7928 outcomes and 1038 processes verified. The 47 expected failures and 211 skips per editor are not passes. No macOS or source312 certification.'))
audit=read('source310-macos-frozen-abort-audit.json');base=Path(audit['raw_directory']);assert all(sha((base/n).read_bytes())==h for n,h in audit['raw_files'].items());files={};types={}
for runner in ['oracle','emaxx']:
 types[runner]={'passed':0,'expected_failure':0,'unexpected_failure':0,'skipped':0}
 for f in base.rglob(runner+'.json'):
  for row in json.loads(f.read_text())['results']:
   category=('expected_failure' if row['expected'] else 'unexpected_failure') if row['status']=='failed' else row['status'];types[runner][category]+=1
assert types['emaxx']['expected_failure']==types['oracle']['expected_failure']==17 and types['emaxx']['unexpected_failure']==types['oracle']['unexpected_failure']==0
for f in base.rglob('*'):
 if f.is_file() and f.suffix in allowed:files['frozen-abort/'+str(f.relative_to(base))]=f
for dirname in ['source310-erc-pristine-diagnostic','source310-erc-direct','source310-erc-direct-harness-env','source310-erc-lldb','source310-erc-signal-trace','erc-retained-revisions']:
 for f in (p/dirname).rglob('*'):
  if f.is_file() and (f.suffix in allowed or f.name in ['stdout','stderr']):files[str(f.relative_to(p))]=f
for n in ['source310-full-frozen-command.json','source310-full-frozen-result.json','source310-full-frozen.log','source310-manifest.json','source310-full-checkout.json','source310-macos-frozen-abort-audit.json','audit-source310-macos-frozen-abort.py','source310-erc-replay-command.json','source310-erc-replay-result.json','source310-erc-replay.log','source310-erc-symbolication.json','source310-erc-lldb-cleanup.json','reproduce-source310-erc-signal.py','trace-source310-erc-signal.py','trace-source310-erc-layouts.py','compare-erc-retained-revisions.py','erc-crash-trace.c',Path(__file__).name,'package-source196-failure-and197-results.py']:files[n]=p/n
trace=(p/'source310-erc-pristine-diagnostic/4/stderr').read_text();assert 'address=0xa5a5a5a5a5a5a5a0' in trace and 'run_due_timers' in trace
package('source310-macos-frozen-abort',files,dict(status=audit['status'],source_commit=audit['source_commit'],attempted_files=183,scheduled_files=519,completed_comparisons=182,matching_outcomes=2951,raw_outcome_counts=types,successful_processes=365,retained_inputs=audit['retained_inputs'],signal_reproductions=audit['direct_signal_reproductions'],goal_complete=False,diagnosis='Instrumented source310 reproduction faults on the freed-memory poison pattern while run_due_timers decodes a timer. Its copied Rust Vec is not a GC root; a callback can cancel and collect later entries. Source312 adds a rooted snapshot; repair validation is pending. LLDB launch timed out; its orphaned debugserver was terminated. Shim compilation initially needed sys/ucontext.h instead of the deprecated ucontext.h entry; the successful diagnostic is distinct from acceptance.',qualification='The full frozen run aborts at ERC after GNU passes and Emaxx terminates without a result. 336 files never start. Later changed-path runs passing do not erase the SIGSEGVs; this is not a complete six-diagnostic-only result. Original failed executable/image retained locally; their bytes are not in this portable log archive.'))
