from pathlib import Path
import ast,hashlib,json,re,shutil
p=Path(__file__).parent.resolve();root=p.parent/'recovered-2026-09-30/bytecode-closure/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
read=lambda name:json.loads((p/name).read_text())
manifest=read('source216-manifest.json');before=read('source215-manifest.json')
assert len(manifest)==418 and manifest.keys()==before.keys()
assert [name for name in manifest if manifest[name]!=before[name]]==['src/lisp/bytecode/vm.rs']
assert all(sha(root/name)==digest for name,digest in manifest.items())
tree=ast.parse((p/'audit-shared-reader196-fresh-selected.py').read_text())
node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='audit_log')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<raw-auditor>','exec'))
failure='lisp::primitives::tests::bytecode_code_mutation_during_active_call_matches_gnu'
binary=p/'source216-gate-libtest';groups=[]
for label,passed in [('controls',9),('broad',847)]:
    command=read('source216-gate-'+label+'-command.json');result=read('source216-gate-'+label+'-result.json')
    assert result['exit_code']==101 and result['source_unchanged']
    assert sha(binary)==command['binary_sha256']
    assert command['environment_override']['LANG']==command['environment_override']['LC_ALL']=='C'
    names=command['selected_inventory']
    if label=='broad':assert names==read('source215-gate-broad-command.json')['selected_inventory']
    else:
        assert set(names)==set(read('source215-gate-controls-command.json')['selected_inventory'])|{
            'lisp::bytecode::vm::native_surface_tests::'+name for name in [
                'make_byte_code_object_is_callable','byte_code_argument_prologue_preserves_string_identity',
                'byte_code_direct_string_arguments_are_mutable_lisp_objects']}
    assert audit_log(names,(p/('source216-gate-'+label+'.log')).read_text(),passed,1)==[failure]
    groups.append(dict(stage=label,passed=passed,failed=1,ignored=0,inventory_verified=len(names)))
for label in ['check','fmt','clippy','diff','gate-build']:
    result=read('source216-'+label+'-result.json');assert result['exit_code']==0 and result['source_unchanged']
    raw=(p/('source216-'+label+'.log')).read_text();assert not re.search(r'^warning(?:\[.*\])?:',raw,re.M)
    for line in raw.splitlines():
        try:item=json.loads(line)
        except json.JSONDecodeError:continue
        assert item.get('message',{}).get('level') not in ['error','warning']
    if label in ['fmt','diff']:assert not raw
retained=p/'source216-retained-inputs';retained.mkdir();files=[]
for source in [binary,*sorted((p/'fixture-images-source216').glob('*.pdmp'))]:
    target=retained/source.name;digest=sha(source);shutil.copy2(source,target)
    assert sha(source)==sha(target)==digest
    files.append(dict(original=str(source),retained=str(target),sha256=digest,bytes=target.stat().st_size))
record=dict(status='partial architecture draft; active-call mutation remains failed',inputs_verified=418,
            strict_checks='passed with zero warnings',groups=groups,failing_names=[failure],retained_files=files,
            qualification='All original broader names execute unchanged. Source216 differs from source215 only in three GNU-invalid constructor fixtures inside vm.rs tests; every behavior assertion remains. Both profiles here are gate only, not release or complete validation. Original source215 failures and helper diagnostic failure remain preserved. No runtime bytecode change is applied to the task branch; direct byte cursor, string/symbol authority, final checks and performance remain open.')
with (p/'source216-results-audit.json').open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps(record,indent=2))
