from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve();root=p.parents[2]
out=root/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest()
tree=ast.parse((p/'package-source196-failure-and197-results.py').read_text())
node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
names=['source216-results-audit.json','audit-source216-results.py','source216-gate-inventory.txt',
       'source216-validation-result.json','source216-validation-driver.log','run-source216-validation.py',
       'test-bytecode-controls216.py','test-bytecode-broad216.py','source215-gate-controls-command.json',
       'source215-gate-broad-command.json','source215-manifest.json','source216-manifest.json',Path(__file__).name]
for stage in ['check','fmt','clippy','diff','gate-build','gate-controls','gate-broad']:
    names+=['source216-'+stage+suffix for suffix in ['-command.json','-result.json','.log']]
package('source216-bytecode-results',{name:p/name for name in names},json.loads((p/'source216-results-audit.json').read_text()))
