from pathlib import Path
import json,subprocess,sys,time
p=Path(__file__).parent.resolve()
stages=[
 ('check',['python3',str(p/'check-bytecode208.py'),'216']),
 ('strict',['python3',str(p/'static-bytecode208.py'),'216']),
 ('gate-controls',['python3',str(p/'test-bytecode-controls216.py'),'216','gate']),
 ('gate-broad',['python3',str(p/'test-bytecode-broad216.py'),'216','gate']),
]
results=[]
for stage,command in stages:
    start=time.monotonic(); print('START',stage,flush=True)
    result=subprocess.run(command,cwd=p.parents[2])
    results.append({'stage':stage,'command':command,'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start})
    print('END',stage,results[-1],flush=True)
    if result.returncode:
        # Broaden after an executed libtest failure, preserving its verdict.
        # A build failure has no controls-result receipt and stops here.
        if stage!='gate-controls' or not (p/'source216-gate-controls-result.json').exists():break
with (p/'source216-validation-result.json').open('x') as stream:
    json.dump(results,stream,indent=2);stream.write('\n')
sys.exit(next((r['exit_code'] for r in results if r['exit_code']),0))
