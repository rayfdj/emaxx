from pathlib import Path
import ast,hashlib,json,re,subprocess,sys
p=Path(__file__).parent.resolve();head='6ad703c4ae85b4c3d0be6351a2df9f3bd47489ef';artifact=p/('source308-linux-rust-artifacts/ordinary-linux-'+head);root=artifact/'rust';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();read=lambda f:json.loads(f.read_text())
terminal=read(p/'source308-linux-rust-terminal.json');assert terminal['headSha']==head and terminal['status']=='completed' and terminal['conclusion']=='success'
files={str(f.relative_to(p/'source308-linux-rust-artifacts')):sha(f) for f in artifact.rglob('*') if f.is_file()}
(p/'source308-linux-rust-download-files.json').open('x').write(json.dumps(dict(files=files,run_id=37416429720,goal_complete=False),indent=2))
s=read(root/'summary.json');assert s['status']=='passed' and s['git']==dict(dirty=False,head=head)
inventory=[x[:-6] for x in (root/'inventory.txt').read_text().splitlines() if x.endswith(': test')]
prior=p/'source304-linux-rust-failure-artifacts/ordinary-linux-2b561470516c519f2198d2551c7b85b474defcfc/rust/inventory.txt'
old={x[:-6] for x in prior.read_text().splitlines() if x.endswith(': test')}
added={
'lisp::alloc::vectors::tests::native_subr_allocation_has_gnu_fields_and_direct_tagged_identity',
'lisp::alloc::vectors::tests::native_subr_marks_all_five_fields_and_releases_unreachable_cycles',
'lisp::native_comp::loader::tests::native_subr_calls_read_actual_target_and_arity_fields',
'lisp::primitives::tests::native_subr_authority_preserves_gnu_metadata_calls_and_identity',
'lisp::primitives::tests::native_subr_c_names_follow_gnu_nul_termination_without_changing_symbols',
'lisp::primitives::tests::native_subr_consumers_preserve_commands_completion_properties_and_substitution'}
assert len(inventory)==len(set(inventory))==3056 and set(inventory)==old|added
seen={}
for group in s['runs'][0]['groups']:
 raw=(root/Path(group['log']).name).read_text();starts=list(re.finditer(r'^test (\S+) \.\.\. ',raw,re.M));assert len(starts)==group['expected_tests']
 for i,m in enumerate(starts):
  end=starts[i+1].start() if i+1<len(starts) else raw.rindex('test result:');verdict=raw[m.end():end].strip();assert m[1] not in seen
  if m[1] in s['inventory']['ignored_tests']:assert verdict.startswith('ignored');seen[m[1]]='ignored'
  else:assert re.search(r'(?:^|\s)ok$',verdict),(m[1],verdict);seen[m[1]]='passed'
assert set(seen)==set(inventory)
(p/'source308-linux-rust-name-audit.json').open('x').write(json.dumps(dict(status='passed',raw_names_verified=len(seen),added_tests=sorted(added),raw_verdicts=seen,inventory_sha256=sha(root/'inventory.txt'),goal_complete=False),indent=2))
script=(p/'verify-source297-linux-rust.py').read_text().replace('source297','source308').replace('4af440a93be274739b3745d26e9026e12974b411',head).replace('recovered-2026-10-05/native-funcall-dispatch/emaxx','recovered-2026-10-06/native-subr-callbacks/emaxx').replace('len(inputs)==532','len(inputs)==541').replace('source308-linux-rust-completed.json','source308-linux-rust-terminal.json').replace("['raw_names_verified']==3047","['raw_names_verified']==3056")
ast.parse(script);helper=p/'verify-source308-linux-rust.py';helper.open('x').write(script)
subprocess.run([sys.executable,str(helper),str(root),head,str(p/'source308-linux-rust-audit.json')],check=True)
cap=artifact/'oracle-inputs';m=read(cap/'manifest.json');v=read(cap/'verification.json')
assert m['status']=='captured' and m['source_commit']=='636f166cfc86aa90d63f592fd99f3fdd9ef95ebd' and m['source_tracked_changes']==[]
assert v['status']=='unchanged' and v['files_verified']==4 and v['capture_manifest_sha256']==sha(cap/'manifest.json')
for item in m['files']:
 f=cap/item['artifact'];assert sha(f)==item['sha256'] and f.stat().st_size==item['bytes']
assert m['files'][0]['sha256']=='5e1721732427d69d8af63211f1e3833ec21e40f97f4b7f6cd4cb224b72cebfcf'
assert m['files'][1]['sha256']=='bf4974228f3b3ea4374cec75a38eeb2bd0e7dd944da5bec4e6ad0387092502ae'
(p/'source308-linux-rust-oracle-audit.json').open('x').write(json.dumps(dict(status='passed',capture=m,verification=v,goal_complete=False,qualification='The pinned Linux GNU inputs were retained before this run and verified unchanged after it. The full-source308 Rust pass, including its GNU census assertion, does not erase the prior GNU census failures or establish their cause.'),indent=2))
print('Complete Linux source308 raw names, counts, artifact identities and retained GNU inputs verified')
