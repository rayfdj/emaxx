from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
out = p.parents[2] / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
linux = read('source308-linux-rust-audit.json')
frozen = read('source308-linux-frozen-raw-integrity-audit.json')
mac = read('source308-macos-rust-audit.json')
assert linux['status'] == frozen['status'] == mac['status'] == 'passed'
assert linux['total_passed'] == 3157 and mac['total_passed'] == 3145
assert linux['library_ignored'] == mac['library_ignored'] == 2
assert frozen['files'] == 519 and frozen['outcomes'] == 7928
assert read('source308-linux-rust-oracle-audit.json')['status'] == 'passed'
assert read('source308-macos-rust-oracle-audit.json')['status'] == 'passed'
for n, h in read('source308-linux-rust-download-files.json')['files'].items():
    assert sha((p / 'source308-linux-rust-artifacts' / n).read_bytes()) == h
for n, h in frozen['raw_files'].items():
    assert sha((Path(frozen['raw_artifact_directory']) / n).read_bytes()) == h
files, excluded = {}, []
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.h', '.apparmor', '.loaded'}
for name in ['source308-linux-rust-artifacts', 'source308-linux-frozen-artifacts', 'full-gate-source308', 'source308-full-retained-gnu']:
    for f in (p / name).rglob('*'):
        if not f.is_file():
            continue
        if f.suffix in allowed or f.name == 'Makefile':
            files[str(f.relative_to(p))] = f
        else:
            excluded.append(dict(path=str(f.relative_to(p)), bytes=f.stat().st_size, sha256=sha(f.read_bytes())))
for f in p.iterdir():
    if f.is_file() and f.suffix in allowed and f.name.startswith(('source308-linux-', 'source308-macos-rust-')):
        files[f.name] = f
for name in [
    'source308-full-validation-launch.json', 'source308-full-launch.json', 'source308-full-checkout.json',
    'source308-full-rust-command.json', 'source308-full-rust-result.json', 'source308-full-rust-binary.json',
    'source308-full-rust-retention-result.json', 'source308-full-oracle-capture-command.json',
    'source308-full-oracle-capture-result.json', 'source308-full-oracle-capture.log',
    'source308-manifest.json', 'source308-applied-commit.json', 'source308-push-result.json',
    'source308-portable-complete.patch', 'audit-source308-linux-rust.py', 'verify-source308-linux-rust.py',
    'audit-source308-linux-frozen.py', 'verify-complete-frozen-receipts279.py',
    'audit-source308-macos-rust-names.py', 'verify-source308-macos-rust.py',
    'package-source196-failure-and197-results.py', Path(__file__).name,
]:
    files[name] = p / name
assert all(f.is_file() for f in files.values())
package('source308-platform-validation-progress', files, dict(
    status='closed full Linux Rust and frozen; closed full macOS Rust; macOS frozen and TTY remain separate',
    source_commit='6ad703c4ae85b4c3d0be6351a2df9f3bd47489ef', linux_rust=linux, macos_rust=mac,
    linux_frozen=dict(files=519, outcomes=7928, successful_processes=1038,
                      runner_summaries=read('source308-linux-frozen-complete-audit.json')['runner_summaries']),
    excluded_binaries=excluded, goal_complete=False,
    qualification='Every scheduled Rust library name and Cargo result is audited on both platforms; both native artifact identity controls pass. All519 frozen Linux files and7928 outcomes match actual pinned GNU, with7670 passes,47 expected failures and211 skips per editor. The earlier GNU census failures remain failed and their cause unresolved; this later pass does not erase them. macOS frozen and TTY are separate ongoing checks. This checkpoint does not certify the isolated309 native-unit draft, unfinished architecture/accounting/internal ownership, final adversarial review or the locked performance criterion.'))
