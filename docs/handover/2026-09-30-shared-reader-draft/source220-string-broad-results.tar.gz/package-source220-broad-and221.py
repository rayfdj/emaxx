from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
tree = ast.parse((p / 'package-source196-failure-and197-results.py').read_text())
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))

audit = read('source220-broad-audit.json')
assert (audit['passed'], audit['failed'], audit['ignored']) == (925, 2, 0)
names = ['source220-broad-audit.json', 'audit-source220-broad.py', 'source220-gate-broad-command.json',
         'source220-gate-broad-result.json', 'source220-gate-broad.log', 'source220-broad-driver-result.json',
         'source220-broad-launch.json', 'source220-broad-driver.log', 'run-source220-broad.py',
         'test-string-broad219.py', 'source220-manifest.json', Path(__file__).name]
package('source220-string-broad-results', {name: p / name for name in names}, audit)

audit = read('source221-results-audit.json')
assert audit['inputs_verified'] == 423
assert audit['groups'][1]['passed'] == 927 and audit['groups'][1]['failed'] == 1
assert read('source221-patch-replay-and-modes-audit.json')['results'][0]['passed']
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected'}
files = {f.name: f for f in p.iterdir() if f.is_file() and f.suffix in allowed
         and f.name.startswith(('source221-', 'canonical-string-constructors-'))}
names = ['canonical-string-constructors.el', 'run-string-constructors-reference.py', 'audit-source221-results.py',
         'audit-source221-patch.py', 'run-string-validation221.py', 'freeze-string-candidate.py',
         'check-string217.py', 'static-string217.py', 'test-string-controls221.py', 'test-string-broad219.py',
         Path(__file__).name]
files.update({name: p / name for name in names})
package('source221-string-constructor-repair', files, audit)
