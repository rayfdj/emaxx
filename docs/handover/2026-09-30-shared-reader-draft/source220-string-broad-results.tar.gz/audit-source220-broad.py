from pathlib import Path
import ast, hashlib, json, re, shutil

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/string-bytes/emaxx'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read('source220-manifest.json')
assert len(manifest) == 421
assert all(sha(root / name) == digest for name, digest in manifest.items())
tree = ast.parse((p / 'audit-shared-reader196-fresh-selected.py').read_text())
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'audit_log')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<raw-auditor>', 'exec'))
command = read('source220-gate-broad-command.json')
result = read('source220-gate-broad-result.json')
assert result['exit_code'] == 101 and result['source_unchanged']
assert read('source220-broad-driver-result.json')['exit_code'] == 101
assert command['environment_override']['LANG'] == command['environment_override']['LC_ALL'] == 'C'
binary = p / 'source220-gate-libtest'
assert sha(binary) == command['binary_sha256']
inventory = [line[:-6] for line in (p / 'source220-gate-inventory.txt').read_text().splitlines() if line.endswith(': test')]
names = [name for name in inventory if name.startswith(('lisp::bytecode::', 'lisp::native_comp::runtime::', 'lisp::primitives::pdumper::', 'lisp::primitives::tests::', 'lisp::reader::', 'lisp::types::'))]
assert len(names) == 927 and names == command['selected_inventory']
failed = audit_log(names, (p / 'source220-gate-broad.log').read_text(), 925, 2)
assert failed == read('source220-controls-audit.json')['failing_names']
retained = p / 'source220-retained-inputs'
retained.mkdir()
files = []
for source in [binary, *sorted((p / 'fixture-images-source220').glob('*.pdmp'))]:
    target = retained / source.name
    digest = sha(source)
    shutil.copy2(source, target)
    assert sha(source) == sha(target) == digest
    files.append(dict(original=str(source), retained=str(target), sha256=digest, bytes=target.stat().st_size))
record = dict(status='complete broader inventory with two retained failures', passed=925, failed=2, ignored=0,
              inputs_verified=len(manifest), inventory_verified=len(names), failing_names=failed, retained_files=files,
              qualification='Source220 gate only, not release or full validation. The original active-call mutation and surrogate-constructor assertions both fail unchanged. Supervisor 68772 has exited. No performance result.',
              raw_hashes={name: sha(p / name) for name in ['source220-gate-broad-command.json', 'source220-gate-broad-result.json', 'source220-gate-broad.log', 'source220-broad-driver-result.json']})
with (p / 'source220-broad-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record, indent=2))
