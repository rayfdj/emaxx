from pathlib import Path
import json,subprocess,sys,time
p=Path(__file__).parent.resolve()
command=['python3',str(p/'test-string-broad219.py'),'220','gate']
assert not (p/'source220-gate-broad-command.json').exists()
start=time.monotonic()
result=subprocess.run(command,cwd=p.parents[2])
record=dict(command=command,exit_code=result.returncode,elapsed_seconds=time.monotonic()-start,
            qualification='Runs the originally planned but unexecuted broader stage once. The first supervisor stopped after focused failure because its continuation check named source219 rather than source220. Original source/results/helpers remain unchanged.')
with (p/'source220-broad-driver-result.json').open('x') as stream:
    json.dump(record,stream,indent=2);stream.write('\n')
sys.exit(result.returncode)
