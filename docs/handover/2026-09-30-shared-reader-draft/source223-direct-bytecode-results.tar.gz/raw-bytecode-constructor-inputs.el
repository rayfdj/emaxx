(prin1
 (list
  (let ((code (string 192 193 92 135)))
    (list (multibyte-string-p code)
          (append (string-as-unibyte code) nil)))
  (byte-code (unibyte-string 192 193 92 135) [40 2] 4)
  (byte-code (string-to-multibyte (unibyte-string 192 193 92 135)) [40 2] 4)))
