from pathlib import Path
import ast, hashlib, json, re, shutil

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/string-bytes/emaxx'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read('source223-manifest.json')
assert len(manifest) == 425 and all(sha(root / name) == digest for name, digest in manifest.items())
node = next(n for n in ast.parse((p / 'audit-shared-reader196-fresh-selected.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'audit_log')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<raw-auditor>', 'exec'))
failure = 'lisp::bytecode::vm::native_surface_tests::byte_code_primitive_executes_program'
groups = []
for profile in ['gate', 'release']:
    for group, passed, failed in [('controls', 17, 0), ('broad', 929, 1)]:
        stem = 'source223-' + profile + '-' + group
        command, result = read(stem + '-command.json'), read(stem + '-result.json')
        assert result['exit_code'] == (101 if failed else 0) and result['source_unchanged']
        assert sha(p / ('source223-' + profile + '-libtest')) == command['binary_sha256']
        assert command['environment_override']['LANG'] == command['environment_override']['LC_ALL'] == 'C'
        names = command['selected_inventory']
        if profile == 'release':
            assert names == read('source223-gate-' + group + '-command.json')['selected_inventory']
        assert audit_log(names, (p / (stem + '.log')).read_text(), passed, failed) == ([failure] if failed else [])
        groups.append(dict(profile=profile, stage=group, passed=passed, failed=failed, ignored=0, inventory_verified=len(names)))
for stage in ['check', 'fmt', 'clippy', 'diff', 'gate-build', 'release-build']:
    result = read('source223-' + stage + '-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
    raw = (p / ('source223-' + stage + '.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
    for line in raw.splitlines():
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        assert item.get('message', {}).get('level') not in ['error', 'warning']
assert (p / 'raw-bytecode-constructor-inputs-gnu.stdout').read_text() == '((t (195 128 195 129 92 194 135)) 42 42)'
retained = p / 'source223-retained-inputs'
retained.mkdir()
files = []
for source in [p / 'source223-gate-libtest', p / 'source223-release-libtest', *sorted((p / 'fixture-images-source223').glob('*.pdmp'))]:
    target = retained / source.name
    digest = sha(source)
    shutil.copy2(source, target)
    assert sha(source) == sha(target) == digest
    files.append(dict(original=str(source), retained=str(target), sha256=digest, bytes=target.stat().st_size))
record = dict(status='both profiles complete; one GNU-invalid fixture remains failed', inputs_verified=len(manifest),
              strict_checks='passed with zero warnings', groups=groups, retained_files=files, failing_names=[failure],
              qualification='Original active-call mutation and surrogate-construction controls pass unchanged in both profiles. Each complete 930-test inventory has 929 passes and the same old raw-byte-code fixture failure. GNU confirms its Unicode characters encode as C3 80/C3 81, beginning with nonexistent constant index 3 in a two-slot vector; intended unibyte and byte8 code both produce the original expected 42. No assertion or runtime behavior has been weakened. Full validation and performance remain open.')
with (p / 'source223-results-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record, indent=2))
