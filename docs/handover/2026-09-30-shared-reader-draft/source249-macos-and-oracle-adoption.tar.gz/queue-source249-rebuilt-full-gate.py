from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys, time

p=Path(__file__).parent.resolve()
root=p.parent/'rebuilt-2026-10-01/emaxx'
gnu=root.parent/'emacs'
manifest=json.loads((p/'source249-manifest.json').read_text())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
unchanged=lambda:all(sha(root/n)==h for n,h in manifest.items())
state=dict(status='waiting for the rebuilt-oracle frozen process to exit',prior_pid=58661,goal_complete=False)
def save(name,data):
    with (p/('source249-rebuilt-'+name+'.json')).open('x') as f:json.dump(data,f,indent=2)
def save_state():
    (p/'source249-rebuilt-full-gate-queue-state.json').write_text(json.dumps(state,indent=2)+'\n')
save_state()
try:
    assert len(manifest)==476 and unchanged()
    selected=json.loads((p/'source249-selected-audit.json').read_text())
    assert selected['status']=='passed' and all(row['focused_passes']==172 and row['affected_passes']==955 for row in selected['profiles'].values())
    while True:
        process=subprocess.run(['ps','-p','58661','-o','command='],capture_output=True,text=True)
        if process.returncode==1 and not process.stdout.strip():break
        assert process.returncode==0 and 'retry-rebuilt-oracle-frozen-empty-target.py' in process.stdout,process.stdout+process.stderr
        time.sleep(5)
    prior=json.loads((p/'rebuilt-oracle-frozen-empty-target-result.json').read_text())
    assert prior['source_unchanged'] and prior['gnu_inputs_unchanged']
    state['prior_frozen_exit_code']=prior.get('exit_code')
    # Complete Rust validation is independent of the prior comparison verdict.
    # Preserve that verdict rather than treating a queued gate as a repair.
    env=dict(CARGO_TARGET_DIR=str(root/'target/oracle-validation'),CARGO_BUILD_JOBS='1',
             EMAXX_GC_VERIFY='1',LANG='C',LC_ALL='C',EMAXX_GNU_SOURCE_DIRECTORY=str(gnu),
             EMAXX_DUMP_SOURCE_DIRECTORY=str(gnu),EMACS_TEST_DIRECTORY=str(gnu/'test'))
    artifact=p/'full-gate-source249-rebuilt'
    command=[sys.executable,'tools/serial_grouped_gate.py','--scope','full','--artifact-root',str(artifact)]
    save('full-gate-command',dict(command=command,working_directory=str(root),source_manifest='source249-manifest.json',
                                base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
                                environment_override=env,qualification='Complete unchanged macOS Rust inventory against the rebuilt GNU installation, after the frozen comparison has exited. Existing ignores and native artifact identity contracts are preserved. Prior frozen verdict remains separate; no performance or full-goal claim.'))
    state.update(status='running complete rebuilt-oracle macOS Rust gate',current_command=command)
    save_state()
    start=time.monotonic()
    with (p/'source249-rebuilt-full-gate.log').open('x') as log:
        result=subprocess.run(command,cwd=root,env={**os.environ,**env},stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
    record=dict(exit_code=result.returncode,elapsed_seconds=time.monotonic()-start,source_unchanged=unchanged())
    summary_path=artifact/'summary.json'
    if summary_path.exists():
        summary=json.loads(summary_path.read_text())
        record['summary']=summary
        binary=summary.get('test_binary',{}).get('path')
        if binary and Path(binary).is_file():
            retained=p/'source249-rebuilt-full-gate-libtest'
            assert not retained.exists()
            shutil.copy2(binary,retained)
            record['immutable_binary']=dict(path=str(retained),sha256=sha(retained))
    save('full-gate-result',record)
    if summary_path.exists():
        command=[sys.executable,'tools/retain_rust_gate_artifacts.py','--summary',str(summary_path),
                 '--fixture-directory',str(root/'target/grouped-gate/fixture-images')]
        save('macos-retention-command',dict(command=command))
        retained=subprocess.run(command,cwd=root,stdin=subprocess.DEVNULL)
        save('macos-retention-result',dict(exit_code=retained.returncode))
        assert retained.returncode==0
    state.update(status='complete Rust process finished; raw evidence requires audit',exit_code=result.returncode,source_unchanged=unchanged())
except Exception as error:
    state.update(status='failed',error=repr(error))
finally:
    save_state()
    save('full-gate-queue-result',state)
print(json.dumps(state),flush=True)
raise SystemExit(0 if state.get('exit_code')==0 and state.get('source_unchanged') else 1)
