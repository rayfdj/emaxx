from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
rust = read('source249-rebuilt-macos-rust-audit.json')
adoption = read('rebuilt-gnu-adoption-result.json')
assert rust['status'] == 'passed' and rust['total_passed'] == 3100
assert adoption['runtime_inputs_unchanged'] == 476 and adoption['macos_frozen_mismatching'] == 6
files = {}
directory = p / 'full-gate-source249-rebuilt'
for file in directory.rglob('*'):
    if file.is_file() and file.suffix in ['.json', '.log', '.txt']:
        files[str(file.relative_to(p))] = file
helpers = {
    'audit-source249-rebuilt-macos-names.py', 'verify-source249-rebuilt-macos-rust.py',
    'adopt-rebuilt-gnu-macos-reference.py', 'queue-source249-rebuilt-full-gate.py',
    'queue-source249-rebuilt-full-tty.py', 'audit-source249-rebuilt-terminal.py',
    'package-source196-failure-and197-results.py', Path(__file__).name,
}
for file in p.iterdir():
    if not file.is_file() or file.suffix not in ['.json', '.log', '.txt', '.py']:
        continue
    name = file.name
    if name in helpers or name.startswith(('source249-rebuilt-full-gate-', 'source249-rebuilt-macos-', 'rebuilt-gnu-adoption-')) or name in [
        'source249-rebuilt-full-gate.log', 'rebuilt-gnu-canonical-inventory-from-full-run.txt',
        'source249-manifest.json', 'source249-rebuilt-full-tty-launch.json',
        'source249-rebuilt-full-tty-command.json',
        'source249-rebuilt-full-tty-queue-state-snapshot-20261001T1606Z.json',
    ]:
        files[name] = file
assert helpers <= files.keys()
package('source249-macos-and-oracle-adoption', files, dict(
    macos_rust=rust, oracle_adoption=adoption,
    terminal_launch=read('source249-rebuilt-full-tty-launch.json'),
    qualification='Closed complete source249 macOS Rust: 3100 passes, two existing ignores, native artifact identity, every raw library name and four retained executable/image inputs verified. The requested rebuilt GNU reference is explicitly adopted with the old pin/configuration preserved. Fresh GNU inventory from all 519 full-run reports is byte-identical to the unchanged committed inventory. Six macOS frozen diagnostic differences remain failures. Terminal12347 is active and its included auditor is prepared, not a passing result. The separate common-string draft and final architecture/performance goal remain unfinished.'))
