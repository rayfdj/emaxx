from pathlib import Path
import hashlib, json, shutil, subprocess

p = Path(__file__).parent.resolve()
root = p.parents[2]
candidate = p.parent / 'rebuilt-2026-10-01/emaxx'
gnu = candidate.parent / 'emacs'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda path: json.loads(path.read_text())
verification = read(p / 'gnu-macos-rebuild-20261001-verification.json')
mac = read(p / 'source249-rebuilt-macos-rust-audit.json')
frozen = read(p / 'source249-rebuilt-frozen-audit.json')
assert verification['inputs_unchanged'] and verification['artifacts_unchanged']
assert verification['same_capabilities_as_retained_source_abi_matched_build']
assert all(row['byte_identical'] for row in verification['manifests'])
assert mac['status'] == 'passed' and mac['total_passed'] == 3100 and mac['native_artifact_identity'] == 'passed'
assert frozen['verified_files'] == 519 and frozen['verified_outcomes'] == 7921 and frozen['mismatching_outcomes'] == 6
raw = Path(frozen['raw_root'])
summary = read(raw / 'summary.json')
lines = []
for name in summary['files']:
    report = read((raw / name).with_suffix('.compat') / 'oracle.json')
    assert report['file_status'] == 'loaded' and report['file_error'] is None
    lines.append(f"{name}: discovered={len(report['discovered_tests'])} selected={len(report['selected_tests'])}\n")
    lines.extend('  ' + test + '\n' for test in report['selected_tests'])
inventory = ''.join(lines).encode()
assert inventory == (root / 'compat/oracle_tests_all.txt').read_bytes()
with (p / 'rebuilt-gnu-canonical-inventory-from-full-run.txt').open('xb') as stream:
    stream.write(inventory)
before_lock = (root / 'compat/oracle.lock.json').read_bytes()
after_lock = (candidate / 'compat/oracle.lock.json').read_bytes()
before_local = (root / 'compat/oracle.local.json').read_bytes()
after_local = (candidate / 'compat/oracle.local.json').read_bytes()
old = json.loads(before_lock)
new = json.loads(after_lock)
assert old['emacs_binary_sha256'] == '591acf7b5da3582dca93367b6a69935dbff9c69a9310f05a1927fa230b428f8d'
assert new['emacs_binary_sha256'] == verification['binary_sha256'] == sha(gnu / 'src/emacs')
assert {key for key in old if old[key] != new[key]} == {'emacs_binary_sha256'}
assert old.keys() == new.keys()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=gnu, text=True).strip() == new['emacs_repo_commit']
assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=gnu, text=True)
capture_root = p / 'rebuilt-oracle-frozen-empty-target-gnu-inputs'
capture = read(capture_root / 'manifest.json')
for item in capture['files']:
    assert sha(Path(item['original'])) == sha(capture_root / item['artifact']) == item['sha256']
runtime = read(p / 'source249-manifest.json')
assert all(sha(root / name) == digest for name, digest in runtime.items())
for name, data in [('previous-lock.json', before_lock), ('replacement-lock.json', after_lock),
                   ('previous-local-config.json', before_local), ('replacement-local-config.json', after_local)]:
    with (p / ('rebuilt-gnu-adoption-' + name)).open('xb') as stream:
        stream.write(data)
(root / 'compat/oracle.lock.json').write_bytes(after_lock)
(root / 'compat/oracle.local.json').write_bytes(after_local)
assert all(sha(root / name) == digest for name, digest in runtime.items())
record = dict(status='replacement Darwin reference adopted', source_revision=new['emacs_repo_commit'],
              old_binary_sha256=old['emacs_binary_sha256'], replacement_binary_sha256=new['emacs_binary_sha256'],
              old_lock_sha256=hashlib.sha256(before_lock).hexdigest(), replacement_lock_sha256=sha(root / 'compat/oracle.lock.json'),
              changed_lock_fields=['emacs_binary_sha256'], runtime_inputs_unchanged=476,
              canonical_inventory_sha256=hashlib.sha256(inventory).hexdigest(), inventory_files=519, inventory_outcomes=7921,
              inventory_method='Exact list-format rendering of fresh GNU reports from all 519 files in the completed ordinary full frozen run, byte-identical to the committed canonical inventory. No separate list invocation or selector change.',
              complete_macos_rust_passes=3100, macos_frozen_matching=7915, macos_frozen_mismatching=6,
              actual_gnu_inputs_verified=capture['files'], goal_complete=False,
              qualification='Requested rebuild is an explicit baseline migration: same pristine revision, configure/capability contract, Apple libxml2 and byte-identical generated native ABI/C manifests. The previous pin remains preserved. Six existing build-feature skip diagnostics remain strict comparison failures; skips/expected failures are not passes. Main, Linux pin, runtime source249 and all inventories/selectors/timeouts remain unchanged. Final-source validation and performance remain open.')
with (p / 'rebuilt-gnu-adoption-result.json').open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps({key: record[key] for key in ['status', 'replacement_binary_sha256', 'inventory_files', 'inventory_outcomes', 'macos_frozen_mismatching']}, indent=2))
