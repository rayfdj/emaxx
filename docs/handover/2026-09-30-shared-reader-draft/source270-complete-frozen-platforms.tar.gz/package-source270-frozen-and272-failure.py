from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve();root=p.parents[2];out=root/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda n:json.loads((p/n).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
mac=read('source270-macos-frozen-audit.json');linux=read('source270-linux-frozen-raw-integrity-audit.json')
assert (mac['matching_outcomes'],mac['mismatching_outcomes'])==(7915,6)
assert (linux['files'],linux['outcomes'],linux['successful_processes'])==(519,7928,1038)
files={};links=[];raw=Path(mac['raw_root'])
for f in raw.rglob('*'):
 if not f.is_file():continue
 name=str(f.relative_to(raw))
 if f.is_symlink():links.append(dict(path=name,target=str(f.readlink()),sha256=sha(f.read_bytes()),bytes=f.stat().st_size));continue
 files['source270-macos-frozen-raw/'+name]=f
with (p/'source270-macos-frozen-tool-links.json').open('x') as outlinks:json.dump(dict(links=links,qualification='Harness system-tool links retained as target/hash; all raw test reports and load markers are included.'),outlinks,indent=2)
d=p/'source270-linux-frozen-artifacts'
for f in d.rglob('*'):
 if not f.is_file() or f.suffix=='.pdmp' or str(f.relative_to(d))=='oracle-inputs/emacs':continue
 assert not f.is_symlink();files[str(f.relative_to(p))]=f
helpers={'source270-manifest.json','source270-full-checkout.json','source270-full-launch.json','source270-full-frozen-command.json','source270-full-frozen-result.json','source270-full-frozen.log','source270-full-frozen-subject-inputs.json','source270-macos-frozen-audit.json','source270-macos-frozen-tool-links.json','source270-full-retained-gnu/manifest.json','source270-full-retained-gnu/config.h','source270-full-retained-gnu/Makefile','queue-source270-full-macos.py','audit-source270-macos-frozen.py','retain-source270-linux.py','audit-source270-frozen.py','verify-complete-frozen-receipts270.py','source270-frozen-audit-preparation.json','package-source196-failure-and197-results.py',Path(__file__).name}
for f in p.iterdir():
 if f.is_file() and f.name.startswith('source270-linux-frozen-') and f.suffix in {'.json','.log'}:files[f.name]=f
for n in helpers:assert (p/n).is_file(),n;files[n]=p/n
assert sum(n.endswith('.loaded') for n in files)==2076
package('source270-complete-frozen-platforms',files,dict(macos=mac,linux=linux,qualification='Exact0ecf6e11: Linux has519 files/7928 matching outcomes/1038 successful processes. Pinned macOS has519 files/7915 matches/six strict build-feature skip-diagnostic differences/1038 successful processes. The macOS comparison is failed, not normalized. All raw inventories, execution hashes, paired results and actual GNU/Emaxx inputs are checked. Terminal and newer runtimes are separate; no performance or full-goal completion claim.'))
failed=read('source272-linux-rust-failure-audit.json');assert failed['library_passed']==2279 and failed['library_failed']==2 and len(failed['unstarted_library_tests'])==751
files={};d=p/'source272-linux-rust-artifacts'
for f in d.rglob('*'):
 if not f.is_file() or f.suffix=='.pdmp' or str(f.relative_to(d)) in ['oracle-inputs/emacs','rust/retained-inputs/libtest']:continue
 assert not f.is_symlink();files[str(f.relative_to(p))]=f
for f in p.iterdir():
 if f.is_file() and f.name.startswith('source272-linux-rust-') and f.suffix in {'.json','.log'}:files[f.name]=f
for n in ['source272-manifest.json','source272-linux-retention-preparation.json','retain-source272-linux.py','audit-source272-linux-rust-failure.py','dispatch-source272-linux.py','package-source196-failure-and197-results.py',Path(__file__).name]:assert (p/n).is_file(),n;files[n]=p/n
package('source272-complete-linux-rust-failure',files,dict(failure=failed,qualification='Exacteb286e23 full Linux Rust remains failed:2279 passes/two GNU reference-assertion failures;751 library tests and both Cargo stages never run. The first empty-record and empty-vector samples differ by nine slots in GNU; all later samples agree. Neither control reaches its Emaxx comparison. The actual retained GNU binary/dump/configuration/Makefile match the earlier failure and success runs. The cause remains unresolved; no expected byte or selector is changed, and no later pass relabels this result.'))
