from pathlib import Path
import hashlib, json, subprocess, zipfile
p = Path(__file__).parent.resolve()
sha = lambda data: hashlib.sha256(data).hexdigest()
items = json.loads(subprocess.check_output(['gh', 'api', 'repos/rayfdj/emaxx/actions/runs/36816077037/artifacts'], text=True))
assert items['total_count'] == 1
item = items['artifacts'][0]
assert item['workflow_run']['head_sha'] == '6ee4bd1b9e79cef790c6dc88a64ef1896a2679f2'
archive = p / 'source238-linux-primitives-replay-artifact.zip'
command = ['gh', 'api', 'repos/rayfdj/emaxx/actions/artifacts/' + str(item['id']) + '/zip']
with archive.open('xb') as f:
    result = subprocess.run(command, stdin=subprocess.DEVNULL, stdout=f, stderr=subprocess.PIPE)
assert result.returncode == 0, result.stderr
assert 'sha256:' + sha(archive.read_bytes()) == item['digest']
destination = p / 'source238-linux-primitives-replay-artifacts'
destination.mkdir()
files = []
with zipfile.ZipFile(archive) as z:
    for member in z.infolist():
        if member.is_dir():
            continue
        name = Path(member.filename)
        assert not name.is_absolute() and '..' not in name.parts
        target = destination / name
        target.parent.mkdir(parents=True, exist_ok=True)
        data = z.read(member)
        with target.open('xb') as f:
            f.write(data)
        assert sha(target.read_bytes()) == sha(data)
        files.append(dict(path=member.filename, sha256=sha(data), bytes=len(data)))
with (p / 'source238-linux-primitives-replay-download.json').open('x') as f:
    json.dump(dict(command=command, artifact=item, zip_sha256=sha(archive.read_bytes()), files=files), f, indent=2)
print(json.dumps(dict(artifact_id=item['id'], files=len(files), zip_sha256=sha(archive.read_bytes()))))
print((destination / 'rust-replay/replay.log').read_text()[-6500:])
