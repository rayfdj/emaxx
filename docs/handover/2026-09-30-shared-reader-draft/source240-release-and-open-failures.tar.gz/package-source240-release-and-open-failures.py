from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile
p = Path(__file__).parent.resolve()
out = p.parents[2] / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
read = lambda name: json.loads((p / name).read_text())
allowed = {'.json', '.log', '.txt', '.py', '.stdout', '.stderr', '.el'}
patterns = ['source240-release-*', 'source240-ordinary-*', 'source240-manifest.json',
            'source240-coding-continuation-*', 'commit-source240-coding-continuation.py',
            'new-file-coding-probe.el', 'audit-source240-release.py', 'audit-source240-ordinary.py',
            'audit-source240-ordinary-and-reports.py', 'run-source240-release-and-ordinary.py',
            'source238-linux-primitives-replay-*', 'collect-source238-primitives-replay.py',
            'launch-source238-primitives-replay.py', 'audit-source238-primitives-replay.py',
            Path(__file__).name]
files = {str(file.relative_to(p)): file for pattern in patterns for file in p.glob(pattern)
         if file.is_file() and file.suffix in allowed}
files.update({str(file.relative_to(p)): file for file in (p / 'source238-linux-primitives-replay-artifacts').rglob('*')
              if file.is_file() and file.suffix in allowed})
release = read('source240-release-audit.json')
ordinary = read('source240-ordinary-audit.json')
replay = read('source238-linux-primitives-replay-audit.json')
assert [group['passed'] for group in release['groups']] == [160, 944]
assert len(ordinary['fixtures']) == 57 and replay['passed'] == 642
probe = read('source240-ordinary-new-file-coding-probe-comparison.json')
assert not probe['passed'] and not probe['exact_match']
assert all(result['exit_code'] == 0 and result['inputs_unchanged'] and result['source_unchanged'] for result in probe['outcomes'].values())
for editor, expected in [('gnu', b'(undecided-unix nil utf-8-unix utf-8-unix undecided-unix "created bytes\n")'),
                         ('emaxx', b'(undecided-unix nil prefer-utf-8-unix prefer-utf-8-unix undecided-unix "created bytes\n")')]:
    raw = (p / ('source240-ordinary-new-file-coding-probe-' + editor + '.stdout')).read_bytes()
    assert raw == expected
    assert sha(raw) == probe['outcomes'][editor]['stdout_sha256']
package('source240-release-and-open-failures', files,
        dict(release=release, ordinary=ordinary,
             new_file_coding_failure='Both ordinary processes exit 0. GNU records utf-8-unix after save; source240 records prefer-utf-8-unix. Both revisit as undecided-unix and read identical file bytes. This reproduces the coding metadata distinction behind the source238 terminal indicator failure; no repair claimed.',
             gnu_reference='fileio.c:choose_write_coding_system consults find-operation-coding-system and the unchanged Lisp select-safe-coding-system-function before recording last-coding-system-used. Current Emaxx current_write_coding instead falls back to prefer-utf-8 for ASCII. Repair should preserve GNU Lisp ownership, not special-case the scenario or alter its expected indicator.',
             linux_group_replay=replay,
             qualification='Source240 has 160 focused and 944 affected passes per profile, 61 total audited ordinary comparisons and the reporting repair. The additional new-file-coding probe remains failed. Full Mac supervisor43216 is still active; release supervisor43217 has exited. Source238 frozen recovery stays separate. Neither source240 runtime nor a coding-selection repair is applied to the task branch. Main and the full performance goal remain unchanged.'))
