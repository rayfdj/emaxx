from pathlib import Path
import hashlib, io, json, subprocess, tarfile
p = Path(__file__).parent.resolve()
root = p.parents[2]
sha = lambda data: hashlib.sha256(data).hexdigest()
def output(args):
    return subprocess.check_output(args, cwd=root, text=True).strip()
def save(name, data):
    with (p / name).open('x') as f:
        json.dump(data, f, indent=2)
assert output(['git', 'branch', '--show-current']) == 'runtime-char-tables'
assert output(['git', 'rev-parse', 'HEAD']) == '6ee4bd1b9e79cef790c6dc88a64ef1896a2679f2'
assert not output(['git', 'diff', '--cached', '--name-only'])
manifest = json.loads((p / 'source238-manifest.json').read_text())
assert len(manifest) == 446 and all(sha((root / name).read_bytes()) == digest for name, digest in manifest.items())
paths = ['HANDOVER.md', 'docs/runtime-representation-progress.md', 'docs/runtime-representation-correctness-recovery-draft.md']
stems = ['source238-complete-macos-and-selected', 'source238-linux-census-failure-and-replay',
         'source240-coding-recovery-draft', 'source238-complete-frozen-and-terminal-failure']
for stem in stems:
    prefix = 'docs/handover/2026-09-30-shared-reader-draft/' + stem
    paths += [prefix + '-manifest.json', prefix + '.tar.gz']
    record = json.loads((root / (prefix + '-manifest.json')).read_text())
    archive = root / (prefix + '.tar.gz')
    assert sha(archive.read_bytes()) == record['archive']['sha256']
    with tarfile.open(archive) as t:
        assert t.getnames() == [entry['path'] for entry in record['files']]
        for entry in record['files']:
            data = t.extractfile(entry['path']).read()
            assert sha(data) == entry['sha256'] and len(data) == entry['bytes']
subprocess.run(['git', 'diff', '--check'], cwd=root, check=True)
subprocess.run(['git', 'add', '--', *paths], cwd=root, check=True)
assert set(output(['git', 'diff', '--cached', '--name-only']).splitlines()) == set(paths)
subprocess.run(['git', 'diff', '--cached', '--check'], cwd=root, check=True)
tree = output(['git', 'write-tree'])
data = subprocess.check_output(['git', 'archive', tree, '--', *sorted(manifest)], cwd=root)
with tarfile.open(fileobj=io.BytesIO(data)) as t:
    assert all(sha(t.extractfile(name).read()) == digest for name, digest in manifest.items())
subprocess.run(['git', '-c', 'user.name=Ray', '-c', 'user.email=26018378+rayfdj@users.noreply.github.com',
                'commit', '-m', 'Record restored frozen match and separate coding recovery draft'], cwd=root, check=True)
head = output(['git', 'rev-parse', 'HEAD'])
assert output(['git', 'rev-parse', 'HEAD^{tree}']) == tree
assert not output(['git', 'status', '--porcelain'])
save('source240-coding-continuation-commit.json', dict(commit=head, runtime='a7e12de8bf4c9cf124e8982922c268f91e97aa6f',
     unchanged_runtime_inputs=446, paths=paths, source240='separate portable draft', goal_complete=False))
command = ['git', 'push', 'origin', 'HEAD:refs/heads/runtime-char-tables']
result = subprocess.run(command, cwd=root, stdin=subprocess.DEVNULL, capture_output=True, text=True)
save('source240-coding-continuation-push.json', dict(command=command, exit_code=result.returncode, stdout=result.stdout, stderr=result.stderr))
result.check_returncode()
remote = output(['git', 'ls-remote', '--heads', 'origin', 'refs/heads/runtime-char-tables'])
assert remote.split()[0] == head
save('source240-coding-continuation-remote.json', dict(commit=head, raw=remote))
print(json.dumps(dict(commit=head, status='evidence and separate draft pushed; task runtime remains source238; main unchanged')))
