from pathlib import Path
import hashlib, json, re
p = Path(__file__).parent.resolve()
root = p / 'source238-linux-primitives-replay-artifacts/rust-replay'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
summary = json.loads((root / 'summary.json').read_text())
assert summary['status'] == 'failed' and summary['exit_code'] == 101 and not summary['timed_out']
assert summary['git'] == summary['source_after'] == dict(head='6ee4bd1b9e79cef790c6dc88a64ef1896a2679f2', dirty=False)
names = summary['expected_tests']
assert names == summary['executed_tests'] and len(names) == len(set(names)) == 643
assert summary['ignored_tests'] == [] and summary['total_tests'] == 2996
original = read('source238-linux-rust-failure-audit.json')
group = next(group for group in original['groups'] if group['group'] == 'primitives')
raw = (root / 'replay.log').read_text()
starts = list(re.finditer(r'^test (\S+) \.\.\. ', raw, re.M))
assert [match[1] for match in starts] == names
verdicts = {}
for i, match in enumerate(starts):
    stop = starts[i+1].start() if i+1 < len(starts) else raw.index('\nfailures:\n')
    segment = raw[match.end():stop].strip()
    verdict = re.search(r'(?:^|\s)(ok|FAILED)$', segment)
    assert verdict, match[1]
    verdicts[match[1]] = verdict[1]
failed = [name for name, verdict in verdicts.items() if verdict == 'FAILED']
assert failed == original['failed_tests']
assert re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', raw, re.M) == [('FAILED', '642', '1', '0')]
assert 'oracle disagreed; program sent was:' in raw
assert '  left: "' + original['actual_gnu_output'] + '"' in raw
assert ' right: "' + original['expected_fixture_output'] + '"' in raw
assert sha(root / 'libtest') == summary['test_binary']['sha256'] == original['binary_sha256']
download = read('source238-linux-primitives-replay-download.json')
assert sha(p / 'source238-linux-primitives-replay-artifact.zip') == download['zip_sha256']
for entry in download['files']:
    file = root.parent / entry['path']
    assert sha(file) == entry['sha256'] and file.stat().st_size == entry['bytes']
for image in summary['fixture_images']:
    assert sha(root / image['artifact']) == image['sha256']
audit = dict(status='original GNU census failure reproduces in unchanged primitives group', run_id=36816077037,
             source_commit=summary['git']['head'], runtime_source='source238', passed=642, failed=failed,
             ignored=[], raw_verdicts=verdicts, binary_sha256=summary['test_binary']['sha256'],
             fixture_images=summary['fixture_images'], actual_gnu_output=original['actual_gnu_output'],
             goal_complete=False,
             qualification='All 643 original group controls run with the same Rust executable hash as the failed full run and passing single-test replay. The sole failure is the same GNU reference -9-slot first sample, before Emaxx evaluation. This narrows investigation to an order/environment-dependent reproduction; it does not establish the retaining root or justify changing expectations. Original full run remains failed. GNU executable identity was not hashed by these Rust jobs.')
with (p / 'source238-linux-primitives-replay-audit.json').open('x') as f:
    json.dump(audit, f, indent=2)
print(json.dumps({key: audit[key] for key in ['status', 'run_id', 'passed', 'failed', 'binary_sha256']}, indent=2))
