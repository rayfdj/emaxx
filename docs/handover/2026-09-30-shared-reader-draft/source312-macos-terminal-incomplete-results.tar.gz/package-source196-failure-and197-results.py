from pathlib import Path
import ast
import gzip
import hashlib
import io
import json
import re
import sys
import tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
namespace = {'re': re}
tree = ast.parse((p / 'audit-shared-reader196-fresh-selected.py').read_text())
audit_node = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'audit_log')
exec(compile(ast.Module(body=[audit_node], type_ignores=[]), '<raw-log-auditor>', 'exec'), namespace)
audit_log = namespace['audit_log']
sys.path.insert(0, str(root / 'tools'))
import grouped_gate

full = p / 'full-gate-source196-fresh'
summary = read('full-gate-source196-fresh/summary.json')
result = read('source196-fresh-full-gate-result.json')
assert summary['status'] == 'failed' and result['exit_code'] == 1 and result['source_unchanged']
assert summary['cargo_stages'] == []
assert sha(Path(result['immutable_binary']['path']).read_bytes()) == summary['test_binary']['sha256']
inventory = grouped_gate.parse_inventory((full / 'inventory.txt').read_text())
assert sha(('\n'.join(inventory) + '\n').encode()) == summary['inventory']['sha256']
groups, _ = grouped_gate.classify_inventory(inventory, 'full')
observed = []
for group in ['eval_01', 'eval_02', 'eval_03', 'eval_04', 'eval_05', 'primitives']:
    failed = int(group == 'primitives')
    passed = len(groups[group]) - failed
    failures = audit_log(groups[group], (full / ('repeat-01-' + group + '.log')).read_text(), passed, failed)
    if failed:
        assert failures == ['lisp::primitives::tests::native_keyboard_input_family_matches_gnu_kboard_contracts']
    observed.append({'group': group, 'passed': passed, 'failed': failed, 'failures': failures})
assert sum(item['passed'] for item in observed) == 2221
unexecuted = ['compat_runtime', 'tty', 'batch', 'lightweight']
assert all(not (full / ('repeat-01-' + group + '.log')).exists() for group in unexecuted)
diagnosis = read('source196-keyboard-contract-diagnosis.json')
assert len(diagnosis['comparisons']) == 10
for item in diagnosis['comparisons']:
    outputs = []
    for editor in ['gnu', 'emaxx']:
        stem = 'source196-keyboard-contract-%02d-%s' % (item['index'], editor)
        outcome = read(stem + '-result.json')
        assert outcome['exit_code'] == 0 and not outcome['timed_out']
        assert outcome['source_unchanged'] and outcome['inputs_unchanged']
        pair = [(p / (stem + '.' + suffix)).read_bytes() for suffix in ['stdout', 'stderr']]
        assert sha(pair[0]) == outcome['stdout_sha256'] and sha(pair[1]) == outcome['stderr_sha256']
        assert pair[0] == item['expected'].encode()
        outputs.append(pair)
    assert outputs[0] == outputs[1]
exact = read('source196-keyboard-contract-exact-result.json')
assert exact['exit_code'] == 101 and exact['inputs_unchanged'] and exact['source_unchanged']
audit = {'groups': observed, 'raw_passed': 2221, 'raw_failed': 1,
         'unexecuted': unexecuted + ['binary Cargo stage', 'integration Cargo stage'],
         'ordinary_original_contracts_matched': 10,
         'exact_test_replay': 'failed with same missing-input error',
         'qualification': 'Failed full macOS run remains failed. Ordinary batch passes do not certify the partial-startup Rust fixture. Full terminal and Linux runs remain separate.'}
with (p / 'source196-fresh-full-gate-failure-audit.json').open('x') as stream:
    json.dump(audit, stream, indent=2)

allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected'}

def package(stem, files, scope):
    inventory = []
    target = out / (stem + '.tar.gz')
    with target.open('xb') as stream:
        with gzip.GzipFile(fileobj=stream, mode='wb', mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode='w') as archive:
                for name, file in sorted(files.items()):
                    data = file.read_bytes()
                    info = tarfile.TarInfo(name)
                    info.mode = 0o644
                    info.size = len(data)
                    archive.addfile(info, io.BytesIO(data))
                    inventory.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
    with tarfile.open(target, 'r:gz') as archive:
        assert archive.getnames() == [item['path'] for item in inventory]
        for item in inventory:
            data = archive.extractfile(item['path']).read()
            assert sha(data) == item['sha256'] and len(data) == item['bytes']
    record = {'goal_complete': False, 'scope': scope,
              'archive': {'path': target.name, 'bytes': target.stat().st_size, 'sha256': sha(target.read_bytes())},
              'files': inventory, 'binaries': 'Not packaged; rebuild. Retained binary hashes identify local evidence only.'}
    with (out / (stem + '-manifest.json')).open('x') as stream:
        json.dump(record, stream, indent=2)
        stream.write('\n')
    print(stem, len(inventory), record['archive'], flush=True)

files = {str(f.relative_to(p)): f for f in full.rglob('*') if f.is_file() and f.suffix in allowed}
for f in p.iterdir():
    if f.is_file() and f.suffix in allowed and (f.name.startswith(('source196-fresh-full-gate-', 'source196-keyboard-contract-')) or f.name in ['source196-fresh-full-gate.log', 'source196-fresh-manifest.json', 'source196-complete.patch', 'diagnose-source196-keyboard-contract.py', 'run-source196-fresh-full-gate.py', Path(__file__).name]):
        files[f.name] = f
package('source196-macos-gate-failure', files, audit)

selected = read('source197-sibling-selected-evidence-audit.json')
files = {}
helpers = ['audit-source197-sibling-selected.py', 'audit-source197-patch.py', 'queue-source197-validation.py', 'queue-source197-sibling-validation.py', 'check-reader197.py', 'static-reader197.py', 'test-reader197.py', 'build-reader197.py', 'compare-recovered-continuation-fixtures.py', Path(__file__).name]
for f in p.iterdir():
    if f.is_file() and f.suffix in allowed and (f.name.startswith('source197-') or f.name in helpers):
        files[f.name] = f
package('source197-selected-validation', files, {'rust': selected['rust'],
        'ordinary_comparisons': 8, 'original_failure_preserved': True,
        'qualification': 'Restoring the missing sibling GNU source path makes the identical 32-test gate inventory pass. Release32 and eight ordinary exact comparisons pass. This is selected validation only; no complete-source or physical allocation/performance claim.'})
