from pathlib import Path
import hashlib, json, os, runpy, shutil, subprocess, sys, time

p = Path(__file__).parent.resolve()
read = lambda n: json.loads((p / n).read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
original = read('source312-full-tty-command.json')
root = Path(original['working_directory'])
manifest = read('source312-final-manifest.json')
assert all(sha(root / n) == h for n, h in manifest.items())
assert read('source312-full-queue-result.json')['status'] == 'complete macOS processes finished; raw evidence requires audit'
source = p / 'source312-full-frozen-subject'
# The dump contains relative native-library paths. Preserve the original
# directory depth while keeping this runner independent of Cargo's outputs.
destination = root / 'target/compat-subject/tty-retained'
destination.mkdir()
for name in ['emaxx', 'emaxx.pdmp']:
    shutil.copy2(source / name, destination / name)
    assert sha(source / name) == sha(destination / name) == original['inputs'][str(source / name)]
command = original['command'].copy()
command[4] = str(destination / 'emaxx')
inputs = {str(Path(n)) if not n.startswith(str(source) + '/') else str(destination / Path(n).name): h
          for n, h in original['inputs'].items()}
inputs[str(Path(__file__))] = sha(Path(__file__))
assert all(sha(Path(n)) == h for n, h in inputs.items())
record = dict(**{k: v for k, v in original.items() if k not in ['command', 'inputs', 'qualification']},
              command=command, inputs=inputs,
              qualification='Separate full terminal rerun after the preserved relocated-image startup failure. Same executable/image bytes, harness,226 scenarios, actions,timeouts,environment and strict comparison. Copies are now beside the original gate directory at the same depth, preserving dump-relative native paths. No source or image change.')
(p / 'source312-terminal-retry-command.json').open('x').write(json.dumps(record, indent=2))
started = time.monotonic()
with (p / 'source312-terminal-retry.log').open('xb') as log:
    result = subprocess.run(command, cwd=root, env=dict(os.environ, **original['environment_override']),
                            stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
receipt = dict(exit_code=result.returncode, elapsed_seconds=time.monotonic()-started,
               source_unchanged=all(sha(root / n) == h for n, h in manifest.items()),
               inputs_unchanged=all(sha(Path(n)) == h for n, h in inputs.items()),
               goal_complete=False, raw_audit='required')
(p / 'source312-terminal-retry-result.json').open('x').write(json.dumps(receipt, indent=2))
print(receipt, flush=True)
