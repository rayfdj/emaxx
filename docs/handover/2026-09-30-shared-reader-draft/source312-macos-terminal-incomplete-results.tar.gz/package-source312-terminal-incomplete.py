from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve();out=p.parents[2]/'docs/handover/2026-09-30-shared-reader-draft';sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda n:json.loads((p/n).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package');exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
audit=read('source312-macos-terminal-audit.json');assert audit['status']=='failed' and audit['fully_matching_scenarios']==173 and audit['matching_comparisons']==374 and audit['unexecuted_comparisons']==312 and not audit['divergent_labels']
names=['source312-terminal-retry-command.json','source312-terminal-retry-result.json','source312-terminal-retry.log','source312-macos-terminal-audit.json','source312-terminal-startup-failure-audit.json','source312-full-tty-command.json','source312-full-tty-result.json','source312-full-tty.log','source312-final-manifest.json','source312-final-modes.json','source312-macos-frozen-audit.json','source248-manifest.json','retry-source312-terminal.py','audit-source312-macos-terminal.py',Path(__file__).name,'package-source196-failure-and197-results.py']
files={n:p/n for n in names};assert all(f.is_file() for f in files.values())
package('source312-macos-terminal-incomplete-results',files,audit)
