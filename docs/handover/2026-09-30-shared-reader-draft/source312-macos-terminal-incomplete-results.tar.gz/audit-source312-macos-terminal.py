from pathlib import Path
import hashlib,json,re,runpy
p=Path(__file__).parent.resolve();read=lambda n:json.loads((p/n).read_text());sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
command=read('source312-terminal-retry-command.json');result=read('source312-terminal-retry-result.json');root=Path(command['working_directory']);manifest=read(command['source_manifest'])
assert len(manifest)==552 and all(sha(root/n)==h for n,h in manifest.items())
assert len(command['inputs'])==11 and all(sha(Path(n))==h for n,h in command['inputs'].items())
original=read('source312-full-tty-command.json');assert command['environment_override']==original['environment_override'] and command['inventory']==original['inventory']
previous=read('source248-manifest.json')
for n in ['tools/ttydiff.py','tools/fixtures/fieldnotes.org','tools/fixtures/fake_lsp_server.py']:assert manifest[n]==previous[n]
assert command['candidate_commit']=='7e894a667b0bc0076dcf0555fb1d1f6fcbfb648c'
frozen=read('source312-macos-frozen-audit.json');binary=Path(command['command'][4])
for n,item in frozen['subject_inputs'].items():assert sha(binary.parent/Path(n).name)==item['sha256']
for item in frozen['gnu_inputs']['files']:assert command['inputs'][item['original']]==item['sha256']
assert result['source_unchanged'] and result['inputs_unchanged']
raw = (p / 'source312-terminal-retry.log').read_text()
module = runpy.run_path(str(root / 'tools/ttydiff.py'), run_name='inventory_only')
scenarios = module['select_scenarios']([])
assert [s[0] for s in scenarios] == command['inventory']
assert len(scenarios) == 226
expected = {}
for scenario in scenarios:
    name, keys = scenario[0], scenario[2]
    labels = []
    final_label, final_filesystem = name, False
    for index, item in enumerate(keys):
        action = module['normalize_action'](item, index)
        if not action.checkpoint:
            continue
        label = f'{name}::{index + 1}:{action.name}'
        if index + 1 == len(keys):
            final_label, final_filesystem = label, action.filesystem
        else:
            labels.append(label)
            if action.filesystem:
                labels.append(label + ' filesystem')
    labels.append(final_label)
    if final_filesystem:
        labels.append(final_label + ' filesystem')
    expected[name] = labels
assert sum(map(len, expected.values())) == 686
starts = list(re.finditer(r'^RUN \[(\d+)/(\d+)\] (.+)$', raw, re.M))
assert len(starts) <= 226
assert [(m[1], m[2], m[3]) for m in starts] == [
    (str(i + 1), '226', s[0]) for i, s in enumerate(scenarios[:len(starts)])]
matches, divergent, partial, successful = [], [], [], []
for index, match in enumerate(starts):
    name = match[3]
    stop = starts[index + 1].start() if index + 1 < len(starts) else len(raw)
    segment = raw[match.end():stop]
    verdicts = re.findall(r'^(MATCH|DIVERGE) \[(.+)\]: (.+)$', segment, re.M)
    labels = [v[1] for v in verdicts]
    assert labels == expected[name][:len(labels)], name
    for kind, label, detail in verdicts:
        if kind == 'MATCH':
            assert re.fullmatch(r'text area identical \(\d+ rows\)|isolated fixture trees identical', detail)
            matches.append(label)
        else:
            assert re.fullmatch(r'\d+ terminal difference\(s\)', detail)
            divergent.append(label)
    if labels == expected[name] and all(v[0] == 'MATCH' for v in verdicts):
        successful.append(name)
    else:
        partial.append(dict(scenario=name, missing=expected[name][len(labels):],
                            raw_tail=segment[-4000:]))
unstarted = [s[0] for s in scenarios[len(starts):]]
unexecuted = sum(len(row['missing']) for row in partial) + sum(len(expected[name]) for name in unstarted)
assert len(matches) + len(divergent) + unexecuted == 686
passed = len(successful) == 226 and len(matches) == 686 and not divergent and not partial and not unstarted
assert (result['exit_code'] == 0) == passed
assert ('PASS: all scenarios match' in raw) == passed
record=dict(status='passed' if passed else 'failed',goal_complete=False,source_commit=command['candidate_commit'],inputs_verified=552,execution_inputs_verified=11,fully_matching_scenarios=len(successful),matching_comparisons=len(matches),matching_screen_comparisons=sum(not x.endswith(' filesystem') for x in matches),matching_filesystem_comparisons=sum(x.endswith(' filesystem') for x in matches),divergent_labels=divergent,partial_scenarios=partial,unstarted_scenarios=unstarted,unexecuted_comparisons=unexecuted,log_sha256=sha(p/'source312-terminal-retry.log'),gate_artifacts=frozen['subject_inputs'],qualification='Every raw screen/filesystem verdict verified against all unchanged226 scenarios/686 labels. Same frozen executable/image bytes retained at original path depth; every execution input unchanged. Original moved-image startup failure and six separately scoped macOS frozen diagnostic differences remain failed. No performance or full-goal completion claim.')
(p/'source312-macos-terminal-audit.json').open('x').write(json.dumps(record,indent=2));print({k:record[k] for k in ['status','fully_matching_scenarios','matching_comparisons','unexecuted_comparisons','divergent_labels']})
