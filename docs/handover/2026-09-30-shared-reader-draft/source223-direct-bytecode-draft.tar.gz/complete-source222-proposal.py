from pathlib import Path

p = Path(__file__).parent.resolve()
draft = p / 'source222-proposed'
root = p.parent / 'recovered-2026-09-30/string-bytes/emaxx'
fixtures = draft / 'tests/fixtures'
fixtures.mkdir(parents=True)
for target, data in [
    ('bytecode-live-fetch.el', (p / 'bytecode-live-fetch.el').read_bytes()),
    ('bytecode-live-fetch.expected', (p / 'bytecode-live-fetch-gnu.stdout').read_bytes() + b'\n'),
]:
    with (fixtures / target).open('xb') as stream:
        stream.write(data)

tests = (root / 'src/lisp/primitives/tests.rs').read_text() + '''

#[test]
fn bytecode_live_fetch_preserves_changed_widths_operands_and_suspended_callers() {
    let fixture = include_str!("../../../tests/fixtures/bytecode-live-fetch.el");
    let program = fixture.trim().strip_prefix("(prin1")
        .expect("ordinary fixture starts with prin1")
        .strip_suffix(')').expect("ordinary fixture closes prin1");
    let expected = include_str!("../../../tests/fixtures/bytecode-live-fetch.expected").trim_end();
    assert_oracle_contract_matches_interpreter(program, expected, "live bytecode byte cursor");
}
'''
with (draft / 'src/lisp/primitives/tests.rs').open('x') as stream:
    stream.write(tests)

vm = draft / 'src/lisp/bytecode/vm.rs'
with vm.open('a') as stream:
    stream.write('''

#[cfg(test)]
#[test]
fn canonical_bytecode_entry_borrows_the_actual_bytes_without_predecoding() {
    let _interp = Interpreter::new();
    let code = primitives::bytes_to_shared_unibyte_value(&[192, 135, 0]);
    let Kind::StringObject(state) = code.kind() else {
        panic!("canonical code string");
    };
    let function = Value::allocated_closure(&[
        Value::Integer(0), code, Value::vector([Value::Integer(73)]), Value::Integer(1),
    ]);
    let Kind::Closure(closure) = function.kind() else {
        panic!("actual closure");
    };
    // The invalid dead byte must not be decoded when an ordinary activation
    // starts. The separate diagnostic parser still rejects corrupt streams.
    let program = closure_program(closure).expect("entry reads fields, not dead instructions");
    assert_eq!(program.code.original().word(), code.word());
    assert!(program.code.legacy.is_none());
    program.code.with_bytes(|bytes| {
        let state = state.borrow();
        assert_eq!(bytes.as_ptr(), state.bytes().as_ptr());
        assert_eq!(bytes, &[192, 135, 0]);
    });
}
''')
print('Completed source222 proposal; source221 still unchanged')
