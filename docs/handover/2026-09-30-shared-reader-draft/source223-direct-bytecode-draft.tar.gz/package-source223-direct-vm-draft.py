from pathlib import Path
import ast, gzip, hashlib, io, json, re, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
tree = ast.parse((p / 'package-source196-failure-and197-results.py').read_text())
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
candidate = p.parent / 'recovered-2026-09-30/string-bytes/emaxx'
manifest = read('source223-manifest.json')
assert len(manifest) == 425 and all(sha((candidate / name).read_bytes()) == digest for name, digest in manifest.items())
assert read('source222-clippy-result.json')['exit_code'] == 101
assert not (p / 'source222-gate-controls-result.json').exists()
for stage in ['check', 'fmt', 'clippy', 'diff']:
    result = read('source223-' + stage + '-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
    raw = (p / ('source223-' + stage + '.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
assert read('bytecode-live-fetch-gnu-result.json')['exit_code'] == 0
assert not (p / 'bytecode-live-fetch-gnu.stderr').read_bytes()
assert (candidate / 'tests/fixtures/bytecode-live-fetch.expected').read_bytes() == (p / 'bytecode-live-fetch-gnu.stdout').read_bytes() + b'\n'
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected'}
files = {f.name: f for f in p.iterdir() if f.is_file() and f.suffix in allowed
         and f.name.startswith(('source222-', 'bytecode-live-fetch-'))}
names = ['source223-base.json', 'source223-manifest.json', 'source223-complete.patch', 'source223-launch.json',
         'bytecode-live-fetch.el', 'run-bytecode-live-fetch-reference.py', 'prepare-source222-direct-vm.py',
         'complete-source222-proposal.py', 'audit-source222-through223-patches.py', 'run-string-validation222.py',
         'freeze-string-candidate.py', 'check-string217.py', 'static-string217.py',
         'test-string-controls222.py', 'test-string-broad219.py', Path(__file__).name]
for stage in ['check', 'fmt', 'clippy', 'diff']:
    names += ['source223-' + stage + suffix for suffix in ['-command.json', '-result.json', '.log']]
files.update({name: p / name for name in names})
package('source223-direct-bytecode-draft', files, dict(status='isolated direct-bytecode draft; runtime outcomes separately recorded',
    source_inputs=425, strict_checks='passed with zero warnings', supervisor=read('source223-launch.json')['pid'],
    qualification='Canonical strings are fetched directly with byte-offset cursors. Removes decoded-code registry/offset tables/per-call Rc activation and obsolete string serial words/increments. Whole-program diagnostics retain their original test coverage. A non-ASCII immutable plain-string Rust API adapter remains and must be removed with that representation. This bundle assigns no runtime, release, full-validation or performance verdict. Source222 strict failure and all previous runtime failures remain preserved. No draft runtime is applied to the task branch.'))
