from pathlib import Path
import hashlib, json

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/string-bytes/emaxx'
manifest = json.loads((p / 'source221-manifest.json').read_text())
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
assert all(sha(root / name) == digest for name, digest in manifest.items())
draft = p / 'source222-proposed'
draft.mkdir()

def save(name, text):
    dest = draft / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    with dest.open('x') as stream:
        stream.write(text)

name = 'src/lisp/bytecode.rs'
s = (root / name).read_text()
s = s.replace('//! This phase covers decoding only: recognizing genuine objects, walking\n//! their opcode stream, and rejecting unsupported or corrupt bytecode\n//! with precise errors instead of misexecuting it (issue #10).',
              '//! Whole-program decoding remains available for diagnostics. Execution\n//! fetches instructions from the original string at its current byte cursor.')
s = s.replace('    /// A byte value GNU 30.2 leaves undefined', '    /// Execution reached the end of the actual code string.\n    EndOfCode { offset: usize },\n    /// A byte value GNU 30.2 leaves undefined', 1)
s = s.replace('        match self {\n            ByteCodeError::UnknownOpcode', '        match self {\n            ByteCodeError::EndOfCode { .. } => write!(f, "byte code ran off the end of its program"),\n            ByteCodeError::UnknownOpcode', 1)
s = s.replace('    let byte = code[offset];', '    let byte = *code.get(offset).ok_or(ByteCodeError::EndOfCode { offset })?;', 1)
s = s.replace('#[derive(Clone, Debug, PartialEq)]\npub enum ArgSpec', '#[derive(Clone, Copy, Debug, PartialEq)]\npub enum ArgSpec')
start = s.index('/// A validated genuine GNU byte-code function:')
end = s.index('// The reader stores raw high bytes', start)
s = s[:start] + '''/// The original code string. Mutable strings are always read directly.
///
/// The remaining immutable `Kind::String` Rust API adapter decodes non-ASCII
/// host text once at entry. It has no registry or mutation cache and must be
/// removed with the plain-string representation. Lisp reader/constructor and
/// restored code strings use canonical bytes and allocate nothing here.
#[derive(Clone, Debug)]
pub struct CodeBytes {
    original: Value,
    legacy: Option<Rc<[u8]>>,
}

impl CodeBytes {
    fn new(original: Value) -> Result<Self, ByteCodeError> {
        let legacy = match original.kind() {
            Kind::StringObject(state) => {
                if state.borrow().is_multibyte() {
                    return Err(ByteCodeError::NonUnibyteCode { char_index: 0 });
                }
                None
            }
            Kind::String(text) if text.is_ascii() => None,
            Kind::String(text) => Some(Rc::from(unibyte_bytes(&text)?)),
            _ => return Err(ByteCodeError::MalformedObject("code slot is not a string".into())),
        };
        Ok(Self { original, legacy })
    }

    pub(crate) fn original(&self) -> Value {
        self.original
    }

    /// BODY must not invoke Lisp, collect, or mutate the code string. The
    /// borrow ends before the VM dispatches a callback or switches frames.
    #[inline]
    pub(crate) fn with_bytes<R>(&self, body: impl FnOnce(&[u8]) -> R) -> R {
        if let Some(bytes) = &self.legacy {
            return body(bytes);
        }
        match self.original.kind() {
            Kind::StringObject(state) => body(state.borrow().bytes()),
            Kind::String(text) => body(text.as_bytes()),
            _ => unreachable!("validated code string"),
        }
    }
}

#[derive(Clone, Debug)]
pub struct ByteCodeObject {
    pub argspec: ArgSpec,
    pub code: CodeBytes,
    /// The original CLOSURE_CONSTANTS object, not a snapshot of its slots.
    pub constants: VectorRef,
    pub stack_depth: usize,
}

/// Decode only the instruction about to execute. Bounds checks protect Rust
/// indexing; no instruction inventory or offset table survives a callback.
#[inline]
fn fetch_instruction(code: &[u8], offset: usize, constants_len: usize) -> Result<Instr, ByteCodeError> {
    let instr = decode_instr(code, offset)?;
    match instr.op {
        Op::VarRef(index) | Op::VarSet(index) | Op::VarBind(index)
        | Op::Constant(index) | Op::Constant2(index) if usize::from(index) >= constants_len => {
            return Err(ByteCodeError::ConstantOutOfRange {
                offset, index: usize::from(index), constants_len,
            });
        }
        Op::Goto { target } | Op::GotoIfNil { target } | Op::GotoIfNonNil { target }
        | Op::GotoIfNilElsePop { target } | Op::GotoIfNonNilElsePop { target }
        | Op::PushCatch { target } | Op::PushConditionCase { target }
            if usize::from(target) >= code.len() => {
            return Err(ByteCodeError::JumpOutOfRange {
                offset, target: usize::from(target), code_len: code.len(),
            });
        }
        _ => {}
    }
    Ok(instr)
}

''' + s[end:]
start = s.index('fn string_text(value: &Value)')
end = s.index('/// Whether record slots', start)
s = s[:start] + s[end:]
s = s.replace('        Self::from_fields(slots.len(), |index| slots.get(index).copied())', '''        let object = Self::from_fields(slots.len(), |index| slots.get(index).copied())?;
        if let Some(object) = &object {
            // This public diagnostic parser retains its whole-program
            // validation contract. Ordinary closure entry skips that pass.
            object.code.with_bytes(|code| decode_program(code, object.constants.len()))?;
        }
        Ok(object)''', 1)
s = s.replace('''        let code_text = string_text(&code_slot)
            .ok_or_else(|| ByteCodeError::MalformedObject("code slot is not a string".into()))?;
        let code = unibyte_bytes(&code_text)?;''', '        let code = CodeBytes::new(code_slot)?;')
s = s.replace('        let decoded = decoded_code(&code_slot, &code, constants.len())?;\n', '')
s = s.replace('            #[cfg(test)]\n            code,\n            decoded,', '            code,')
s = s.replace('decode_program(&object.code, object.constants.len()).unwrap()', 'object.code.with_bytes(|code| decode_program(code, object.constants.len())).unwrap()')
s = s.replace('assert_eq!(object.code, vec![0o211, 0o207]);', 'object.code.with_bytes(|code| assert_eq!(code, &[0o211, 0o207]));')
assert not any(term in s for term in ['DecodedCode', 'decoded_code(', 'DECODED_CODE', 'pub decoded:'])
save(name, s)

name = 'src/lisp/bytecode/vm.rs'
s = (root / name).read_text()
s = s.replace('//! Execution of decoded GNU 30.2 bytecode', '//! Execution of GNU 30.2 bytecode from its authoritative string bytes')
s = s.replace('use std::rc::Rc;\n', '')
s = s.replace('Rc<BytecodeActivation>', 'BytecodeActivation')
s = s.replace('    let instrs = &object.decoded.instrs;\n    let mut at = *pc;', '    let mut at = *pc;\n    let mut instruction_start;')
s = s.replace('    object: &BytecodeActivation,\n    ops:', '    object: &BytecodeActivation,\n    code: &[u8],\n    ops:', 1)
s = s.replace('*pc = at - 1;', '*pc = instruction_start;', 1)
s = s.replace('let destination = object.instr_at($target as usize);', 'let destination = $target as usize;', 1)
s = s.replace('''        let Some(instr) = instrs.get(at) else {
            *pc = at;
            return FastExit::Slow;
        };
        let op = instr.op;
        at += 1;''', '''        instruction_start = at;
        let Ok(instr) = super::fetch_instruction(code, at, object.constants.len()) else {
            *pc = at;
            return FastExit::Slow;
        };
        let op = instr.op;
        at += instr.len;''', 1)
start = s.index('/// Transitional decoded VM activation')
end = s.index('    #[inline]\n    fn constant', start)
s = s[:start] + '''/// Entry fields read from the shared closure; no decoded program or heap
/// activation. Suspended frames retain these handles and a byte-offset PC.
#[derive(Clone)]
pub struct BytecodeActivation {
    pub argspec: ArgSpec,
    pub code: super::CodeBytes,
    pub constants: VectorRef,
    pub stack_depth: usize,
}

impl TraceLispRoots for BytecodeActivation {
    fn trace_lisp_roots(&self, marker: &mut LispRootMarker<'_>) {
        marker.value(&self.code.original());
        marker.value(&Value::Vector(self.constants));
        if let ArgSpec::Legacy(arguments) = &self.argspec {
            marker.value(arguments);
        }
    }
}

impl BytecodeActivation {
''' + s[end:]
start = s.index('    // lread.c constructs reader objects before execution.', s.index('fn build_activation'))
end = s.index('\npub(crate) fn closure_program', start)
s = s[:start] + '''    Ok(BytecodeActivation {
        argspec: object.argspec,
        code: object.code.clone(),
        constants: object.constants,
        stack_depth: object.stack_depth,
    })
}
''' + s[end:]
s = s.replace('    Ok(Rc::new(build_activation(&object)?))', '    build_activation(&object)')
s = s.replace('/// Read the actual PVEC_CLOSURE fields at entry. The decoded activation is\n/// temporary until dispatch fetches directly from authoritative string bytes.', '/// Read the actual PVEC_CLOSURE fields and dispatch from its code bytes.')
s = s.replace('    let program = Rc::new(build_activation(object)?);', '    let program = build_activation(object)?;')
s = s.replace('    let result = run_frames(interp, program, function, args, env);', '''    let result = if function.is_nil() {
        // Direct Rust execution also roots the code and legacy arglist; a
        // constants-only root cannot keep them alive across a callback.
        interp.with_lisp_stack_roots(&program, |interp| {
            run_frames(interp, program.clone(), function, args, env)
        })
    } else {
        run_frames(interp, program, function, args, env)
    };''', 1)
s = s.replace('    let mut pc = 0usize;\n    let trace_errors', '    let mut pc = 0usize;\n    let mut last_instruction = None;\n    let trace_errors', 1)
s = s.replace('let destination = program.instr_at($target as usize);', 'let destination = $target as usize;')
s = s.replace('''            let exit = run_fast(&program, &mut interp.bc_stack, &mut pc, &mut quitcounter);''', '''            // No Lisp callback, collection, or string store occurs in the
            // fast loop. Release its byte borrow before the full dispatch.
            let exit = program.code.with_bytes(|code| {
                run_fast(&program, code, &mut interp.bc_stack, &mut pc, &mut quitcounter)
            });''')
s = s.replace('''            let Some(instr) = program.decoded.instrs.get(pc) else {
                return Err(LispError::Signal(
                    "byte code ran off the end of its program".into(),
                ));
            };
            let op = instr.op;
            let offset = instr.offset;
            pc += 1;''', '''            let instr = program.code.with_bytes(|code| {
                super::fetch_instruction(code, pc, program.constants.len())
            }).map_err(|error| LispError::Signal(error.to_string()))?;
            last_instruction = Some(instr);
            let op = instr.op;
            let offset = instr.offset;
            pc += instr.len;''', 1)
s = s.replace('program: Rc::clone(&program),', 'program: program.clone(),')
s = s.replace('pc = program.instr_at(dest as usize);', 'pc = dest as usize;')
s = s.replace('pc = program.instr_at(handler.dest);', 'pc = handler.dest;')
s = s.replace('&& let Some(instr) = program.decoded.instrs.get(pc.wrapping_sub(1))', '&& let Some(instr) = last_instruction')
assert not any(term in s for term in ['.decoded', 'instr_at(', 'Rc::', 'Rc<'])
save(name, s)

name = 'src/lisp/eval/core.rs'
s = (root / name).read_text().replace('std::rc::Rc<crate::lisp::bytecode::vm::BytecodeActivation>', 'crate::lisp::bytecode::vm::BytecodeActivation')
save(name, s)

name = 'src/lisp/primitives/dispatch/predicates.rs'
s = (root / name).read_text()
start = s.index('                let slots = [Value::Integer(0), args[0], args[1], args[2]];', s.index('            "byte-code" =>'))
end = s.index('\n            }', start)
s = s[:start] + '''                if !(args[0].is_string()
                    && matches!(args[1].kind(), Kind::Vector(_))
                    && matches!(args[2].kind(), Kind::Integer(depth) if depth >= 0))
                {
                    return Err(LispError::Signal("Invalid byte-code".into()));
                }
                // bytecode.c:Fbyte_code accepts old multibyte code strings,
                // converts them with string-as-unibyte, then constructs an
                // ordinary closure which roots both code and constants.
                let code = if string_argument_multibyte(&args[0]) {
                    super::super::call(interp, "string-as-unibyte", &args[..1], env)?
                } else {
                    args[0]
                };
                let function = Value::allocated_closure(&[Value::Nil, code, args[1], args[2]]);
                let Kind::Closure(closure) = function.kind() else {
                    unreachable!("allocated bytecode closure")
                };
                crate::lisp::bytecode::vm::execute_closure(interp, closure, &[], env)''' + s[end:]
save(name, s)
print('Prepared', len(list(draft.rglob('*.rs'))), 'files without editing the running source221 checkout')
