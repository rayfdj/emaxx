from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve();out=p.parents[2]/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda n:json.loads((p/n).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
linux=read('source304-linux-rust-failure-audit.json');frozen=read('source304-linux-frozen-raw-integrity-audit.json');mac=read('source304-macos-rust-audit.json')
assert linux['status']=='failed' and linux['library_passed']==2291 and linux['library_failed']==1 and len(linux['unstarted_library_tests'])==758
assert frozen['status']==mac['status']=='passed' and frozen['files']==519 and frozen['outcomes']==7928 and mac['total_passed']==3139
for label,a in [('linux-rust',linux),('linux-frozen',frozen)]:
 base=Path(a.get('raw_artifact_directory',p/'source304-linux-rust-failure-artifacts/ordinary-linux-2b561470516c519f2198d2551c7b85b474defcfc'))
 for n,h in a.get('raw_files',a.get('downloaded_files')).items(): assert sha((base/n).read_bytes())==h,(label,n)
files={};excluded=[]
allowed={'.json','.log','.txt','.py','.patch','.stdout','.stderr','.h','.apparmor','.loaded'}
for name in ['source304-linux-rust-failure-artifacts','source304-linux-frozen-artifacts','full-gate-source304']:
 for f in (p/name).rglob('*'):
  if not f.is_file():continue
  if f.suffix in allowed or f.name=='Makefile':files[str(f.relative_to(p))]=f
  else:excluded.append(dict(path=str(f.relative_to(p)),bytes=f.stat().st_size,sha256=sha(f.read_bytes())))
for f in p.iterdir():
 if f.is_file() and f.suffix in allowed and (f.name.startswith('source304-linux-') or f.name.startswith('source304-macos-rust-')):files[f.name]=f
for n in ['source304-full-validation-launch.json','source304-full-launch.json','source304-full-checkout.json','source304-full-rust-command.json','source304-full-rust-result.json','source304-full-rust-binary.json','source304-full-rust-retention-result.json','source304-manifest.json','source304-applied-commit.json','source304-applied-push.json','source304-portable-complete.patch','source272-linux-rust-failure-audit.json','audit-source304-linux-rust-failure.py','audit-source304-linux-frozen.py','verify-complete-frozen-receipts279.py','audit-source304-macos-rust-names.py','verify-source304-macos-rust.py','package-source196-failure-and197-results.py',Path(__file__).name]:files[n]=p/n
package('source304-platform-validation-progress',files,dict(status='closed Linux frozen and failed Linux Rust; closed macOS Rust; macOS frozen and TTY remain separate',source_commit='2b561470516c519f2198d2551c7b85b474defcfc',linux_rust=dict(passed=2291,failed=1,ignored=0,unstarted_library=758,unstarted_cargo=['bins','integration']),linux_frozen=dict(files=519,outcomes=7928,successful_processes=1038),macos_rust=mac,excluded_binaries=excluded,goal_complete=False,qualification='Exact304 Linux frozen matches the complete pinned GNU inventory, including177 compiler controls; expected failures/skips remain distinct from passes. Exact304 Linux Rust failed the first GNU record census reference with-7 instead of2 before that test evaluated Emaxx, identical to the272 failure; all remaining output is equal and pins were verified. The unchanged original338-row column test passed. MacOS full Rust passes3139 tests withtwo existing ignores and native identity verified. These closed results do not certify the still-running macOS frozen/TTY checks, isolated305/306 drafts, final architecture/accounting/ownership or performance. The GNU census cause and source276 Emaxx negative remain unresolved.'))
