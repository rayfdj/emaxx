from pathlib import Path
import ast,hashlib,json
p=Path(__file__).parent.resolve()
old_names=['run-string-borrow-focused.py','audit-string-borrow-focused.py','test-string-borrow-broad.py','run-string-borrow-release.py','audit-string-borrow-release.py']
changes={}
for name in old_names:
 s=(p/name).read_text().replace('string-borrow-roots/emaxx','string-data-pools/emaxx').replace('target/string-borrow-validation','target/string-sblock-validation')
 s=s.replace('3024','3026').replace('3023','3025').replace('== 510','== 511').replace('verified=510','verified=511').replace('== 208','== 210').replace('selectors=208','selectors=210').replace('All 208 release','All 210 release').replace('==1062','==1064')
 if 'extra_names = {' in s:s=s.replace('extra_names = {',"extra_names = {\n    'string_sblocks_compact_unborrowed_data_and_hold_borrowed_blocks',\n    'string_sdata_resize_reuses_alignment_slop_and_preserves_contents',")
 if name=='test-string-borrow-broad.py':
  s=s.replace("print('Selected broad existing modules:'", "borrows=json.loads((p/('source272-'+profile+'-broad-command.json')).read_text())['selected_inventory']\nassert len(borrows)==1062 and set(borrows)<=set(names)\nprint('Selected broad existing modules:'")
  s=s.replace('All 1059 source270 affected-module controls remain, plus three new borrow/property/weak-root/exclusive-borrow controls.', 'All 1062 source272 affected-module controls remain, plus two new allocation/compaction/resize controls.')
 name2=name.replace('string-borrow','string-pools');ast.parse(s)
 with (p/name2).open('x') as out:out.write(s)
 changes[name2]=dict(predecessor=name,sha256=hashlib.sha256(s.encode()).hexdigest())
s=(p/'queue-source272-borrow-selected.py').read_text().replace('source272','source276').replace('string-borrow-roots/emaxx','string-data-pools/emaxx').replace("read('source270-manifest.json')","read('source272-manifest.json')").replace('len(manifest)==510','len(manifest)==511').replace("'272'","'276'").replace('string-borrow','string-pools')
s=s.replace("state=dict(status='waiting for source276 diagnostic validation'", "state=dict(status='waiting for source270 terminal/full macOS supervisor3079'")
a="    probe=read('source276-probe-result.json')"
b="""    assert read('source276-sblock-probe-audit.json')['status']=='passed'
    assert read('source272-full-withdrawal.json')['source272_mac_stages_executed']==0
    while True:
        assert unchanged() and baseline_unchanged()
        process=subprocess.run(['ps','-p','3079','-o','args='],capture_output=True,text=True)
        if process.returncode:
            assert process.returncode==1
            break
        assert process.stdout.strip().endswith('-B '+str(p/'queue-source270-full-macos.py'))
        time.sleep(10)
    probe=read('source276-probe-result.json')"""
assert a in s;s=s.replace(a,b);ast.parse(s)
with (p/'queue-source276-pools-selected.py').open('x') as out:out.write(s)
changes['queue-source276-pools-selected.py']=dict(predecessor='queue-source272-borrow-selected.py',sha256=hashlib.sha256(s.encode()).hexdigest())
with (p/'source276-selected-preparation.json').open('x') as out:json.dump(dict(helpers=changes,qualification='Exact511-input source276. All208 preceding focused selectors and1062 affected-module names remain; only two new allocator controls are added. Both existing ignores, all expected bytes, original comparison logic and timeouts remain. Queue waits for source270 terminal/full supervisor3079 to exit; source272 waiting supervisor is withdrawn before any stage.',goal_complete=False),out,indent=2)
print('Prepared complete inherited selected controls:210 focused and1064 affected tests per profile; not executed yet.')
