from pathlib import Path
import hashlib,json,subprocess,time
p=Path(__file__).parent.resolve();root=p.parents[2]
selected=p.parent/'recovered-2026-09-30/string-borrow-roots/emaxx'
candidate=p.parent/'recovered-2026-09-30/string-sblocks/emaxx'
gnu=p.parent/'rebuilt-2026-10-01/emacs'
base='b5a1558c6b88804cecdbee04a9bdbfab34209ac8'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
read=lambda n:json.loads((p/n).read_text())
manifest=read('source272-manifest.json')
assert len(manifest)==510 and all(sha(root/n)==sha(selected/n)==h for n,h in manifest.items())
assert read('source272-borrow-selected-audit.json')['status']=='passed'
state=read('source272-selected-result.json');assert len(state['results'])==6 and all(row['exit_code']==0 for row in state['results'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==base
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
assert not candidate.exists()
candidate.parent.mkdir(parents=True,exist_ok=True)
command=['git','worktree','add','--detach',str(candidate),base]
result=subprocess.run(command,cwd=root,capture_output=True,text=True)
with (p/'string-sblocks-checkout-command.json').open('x') as f:json.dump(dict(command=command,exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr),f,indent=2)
result.check_returncode()
(candidate.parent/'emacs').symlink_to(gnu,target_is_directory=True)
assert all(sha(candidate/n)==h for n,h in manifest.items())
record=dict(candidate=str(candidate),base_commit=base,source_inputs_verified=510,goal_complete=False,
            previous_goal_turn='progress: source272 repair, original negative and both-profile validation were applied and pushed; source270 full Rust was audited on both platforms; source272 full validation was launched.',
            qualification='Separate string allocation/compaction worktree. Source272 selected/full and source270 full checkouts remain unchanged. Constructor/header lifetime must support GNU sdata back-pointers before movable data is installed. No new implementation or validation outcome is claimed by checkout preparation.')
with (p/'string-sblocks-checkout.json').open('x') as f:json.dump(record,f,indent=2)
target=candidate/'target/string-sblock-validation';target.parent.mkdir()
command=['/bin/cp','-cR',str(selected/'target/string-borrow-validation'),str(target)]
started=time.monotonic()
with (p/'string-sblocks-cache-clone.log').open('xb') as log:
    result=subprocess.run(command,cwd=root,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
with (p/'string-sblocks-cache-clone.json').open('x') as f:json.dump(dict(command=command,exit_code=result.returncode,elapsed_seconds=time.monotonic()-started,qualification='APFS clone of completed selected272 cache into a new target; no running full-validation cache is copied or changed.'),f,indent=2)
result.check_returncode();print(json.dumps(record,indent=2))
