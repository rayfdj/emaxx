from pathlib import Path
import hashlib,json,subprocess,time
p=Path(__file__).parent.resolve();root=p.parents[2]
old=p.parent/'recovered-2026-09-30/string-sblock-root-words/emaxx'
c=p.parent/'recovered-2026-09-30/string-sblock-layout/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
m=json.loads((p/'source274-manifest.json').read_text());assert all(sha(old/n)==h for n,h in m.items())
state=json.loads((p/'source274-probe-result.json').read_text());assert state['status']=='failed' and state['results'][-1]['stage']=='clippy'
assert not c.exists();c.parent.mkdir(parents=True)
steps=[]
for label,cmd in [('checkout',['git','worktree','add','--detach',str(c),'b5a1558c6b88804cecdbee04a9bdbfab34209ac8']),('replay',['git','apply',str(p/'source274-sblocks.patch')])]:
 r=subprocess.run(cmd,cwd=root if label=='checkout' else c,capture_output=True,text=True);steps.append(dict(label=label,command=cmd,exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr));r.check_returncode()
assert all(sha(c/n)==h for n,h in m.items())
(c.parent/'emacs').symlink_to(p.parent/'rebuilt-2026-10-01/emacs',target_is_directory=True)
f=c/'src/lisp/alloc/strings/data.rs';s=f.read_text();assert s.count('.unwrap()')==2
s=s.replace('Layout::from_size_align(bytes, ALIGN).unwrap()','Layout::from_size_align(bytes, ALIGN).expect("allocated string block layout")').replace('Layout::from_size_align(BLOCK_BYTES, ALIGN).unwrap()','Layout::from_size_align(BLOCK_BYTES, ALIGN).expect("fixed string block layout")');assert '.unwrap()' not in s;f.write_text(s)
assert all(sha(c/n)==h for n,h in m.items() if n!='src/lisp/alloc/strings/data.rs')
t=c/'target/string-sblock-validation';t.parent.mkdir();cmd=['/bin/cp','-cR',str(old/'target/string-sblock-validation'),str(t)]
with (p/'source275-cache-clone.log').open('xb') as log:
 started=time.monotonic();r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL)
steps.append(dict(label='idle-cache-clone',command=cmd,exit_code=r.returncode,elapsed_seconds=time.monotonic()-started));r.check_returncode()
with (p/'source275-preparation.json').open('x') as out:json.dump(dict(candidate=str(c),steps=steps,source274_inputs_verified=len(m),only_edit='Explain the two validated layout invariants using expect, resolving Clippy unwrap_used without lint allowances. Runtime tests and assertions are unchanged.',qualification='Source273 compiler and source274 Clippy failures preserved unchanged; this is an unvalidated successor.',goal_complete=False),out,indent=2)
s=(p/'run-source274-sblocks.py').read_text().replace('source274','source275').replace('recovered-2026-09-30/string-sblock-root-words/emaxx','recovered-2026-09-30/string-sblock-layout/emaxx')
with (p/'run-source275-sblocks.py').open('x') as out:out.write(s)
print('Source275 prepared; source273/274 failures preserved.')
