from pathlib import Path
import hashlib,json,re
p=Path(__file__).parent.resolve();c=p.parent/'recovered-2026-09-30/string-data-pools/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();read=lambda n:json.loads((p/n).read_text())
m=read('source276-manifest.json');assert len(m)==511 and all(sha(c/n)==h for n,h in m.items())
s=read('source276-probe-result.json');assert len(s['results'])==7 and all(r['exit_code']==0 and r['source_unchanged'] and r['published_source_unchanged'] for r in s['results'])
for stage in ['fmt','check','clippy','diff','gate-build']:
 raw=(p/('source276-'+stage+'.log')).read_text();assert not re.search(r'^warning(?:\[.*\])?:',raw,re.M)
 for line in raw.splitlines():
  if line.startswith('{'):assert json.loads(line).get('message',{}).get('level') not in ['warning','error']
names=[n[:-6] for n in (p/'source276-gate-inventory.log').read_text().splitlines() if n.endswith(': test')];assert len(names)==len(set(names))==3026
prior=[n[:-6] for n in (p/'source272-gate-inventory.log').read_text().splitlines() if n.endswith(': test')];assert len(prior)==3024 and set(prior)<set(names)
extra={n.rsplit('::',1)[-1] for n in set(names)-set(prior)};assert extra=={'string_sblocks_compact_unborrowed_data_and_hold_borrowed_blocks','string_sdata_resize_reuses_alignment_slop_and_preserves_contents'}
command=read('source276-gate-probe-command.json')['command'];selected=[n for n in command if '::' in n];assert len(selected)==7
raw=(p/'source276-gate-probe.log').read_text();starts=list(re.finditer(r'^test (\S+) \.\.\. ',raw,re.M));verdicts={}
for i,start in enumerate(starts):
 end=starts[i+1].start() if i+1<len(starts) else raw.index('\ntest result:')
 block=raw[start.end():end].strip();final=re.search(r'(?:^|\s)(ok|FAILED|ignored)$',block);assert final,(start[1],block);assert start[1] not in verdicts;verdicts[start[1]]=final[1]
assert set(verdicts)==set(selected) and set(verdicts.values())=={'ok'}
assert re.findall(r'^test result: .*$',raw,re.M)==['test result: ok. 7 passed; 0 failed; 0 ignored; 0 measured; 3019 filtered out; finished in 0.02s']
assert raw.count('cannot collect while a string is mutably borrowed')==3
binary=read('source276-binary.json');assert sha(Path(binary['path']))==sha(Path(binary['built_artifact']))==binary['sha256']
result=dict(status='passed',source_inputs_verified=511,strict_checks='zero-warning pass',full_library_inventory=3026,prior3024_names_preserved=True,raw_verdicts=verdicts,passed=7,failed=0,ignored=0,binary=binary,patches=read('source276-freeze.json'),goal_complete=False,qualification='Seven gate-profile controls only. Three expected and caught exclusive-borrow panics remain visible in the passing control. Real pooling/relocation/reclamation/pointer-stability and aligned-resize assertions execute; the original property-root/weak/final-release controls remain. All source273 compiler and source274/275 Clippy failures remain failed. No broader/release/platform/performance or full-goal completion result is inferred.')
with (p/'source276-sblock-probe-audit.json').open('x') as out:json.dump(result,out,indent=2)
print(json.dumps({k:result[k] for k in ['status','passed','failed','ignored','source_inputs_verified','strict_checks']},indent=2))
