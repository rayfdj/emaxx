from pathlib import Path
p=Path(__file__).parent.resolve()
candidate=p.parent/'recovered-2026-09-30/string-sblocks/emaxx'
f=candidate/'src/lisp/alloc/strings.rs'
s=f.read_text().replace('//! are allocator overhead, not part of Lisp_String. Data currently has a\n//! separate exact allocation, including its NUL. GNU sblocks remain unfinished.','//! are allocator overhead, not part of Lisp_String. Data uses GNU sblocks;\n//! borrowed data blocks remain stationary until their Rust guards end.')
s=s.replace('use super::super::types', 'mod data;\npub(crate) use data::{PendingStringData, retire_string_data, string_data_size};\n#[cfg(test)]\npub(crate) fn string_data_census() -> (usize, usize, usize) { data::census() }\n\nuse super::super::types',1)
s=s.replace('StringCell::new(SharedStringState::empty(multibyte), kind == StringAllocation::Pure)','StringCell::new(SharedStringState::empty(multibyte), false)')
s=s.replace('        drop(guard);\n        StringObjectRef::from_raw(cell)','        drop(guard);\n        (*cell).pure = kind == StringAllocation::Pure;\n        StringObjectRef::from_raw(cell)')
s=s.replace('    LIVE_STRINGS.store(strings, Ordering::Relaxed);','    data::sweep();\n    LIVE_STRINGS.store(strings, Ordering::Relaxed);')
f.write_text(s)
f=candidate/'src/lisp/alloc.rs'
s=f.read_text().replace('    StringAllocation, allocate_string, borrowed_string_roots, live_string_object_census,','    StringAllocation, PendingStringData, retire_string_data, string_data_size, allocate_string, borrowed_string_roots, live_string_object_census,')
s=s.replace('pub(crate) mod vectors;','#[cfg(test)]\npub(crate) use strings::string_data_census;\npub(crate) mod vectors;')
f.write_text(s)
f=candidate/'src/lisp/types/string_data.rs'
s=f.read_text()
s=s.replace('use std::ptr::NonNull;', 'use std::ptr::{self, NonNull};\nuse crate::lisp::alloc::{StringAllocation, PendingStringData, retire_string_data, string_data_size};')
a=s.index('impl Drop for SharedStringState {');b=s.index('    /// character.c:Fstring',a)
s=s[:a]+'''impl Drop for SharedStringState {
    fn drop(&mut self) {
        let bytes = self.storage_bytes();
        if bytes != 0 {
            // SAFETY: the swept header exclusively owns its sdata entry;
            // no guard survives reclamation. Block freeing follows sweep.
            unsafe { retire_string_data(self.data, bytes) };
        }
    }
}

impl StringObjectRef {
    fn from_data(
        nbytes: usize,
        characters: usize,
        multibyte: bool,
        kind: StringAllocation,
        initialize: impl FnOnce(*mut u8) -> Vec<StringPropertySpan>,
    ) -> Self {
        crate::lisp::alloc::allocate_string(characters, multibyte, kind, |state| {
            assert!(nbytes < isize::MAX as usize - 16 && (multibyte || characters == nbytes));
            if nbytes == 0 {
                state.props = initialize(state.data.as_ptr()).into();
                return;
            }
            // SAFETY: STATE is exclusively borrowed at its final address.
            let data = unsafe { PendingStringData::new(state, nbytes, kind == StringAllocation::Pure) };
            let props = initialize(data.as_ptr());
            state.size = characters;
            state.size_byte = if multibyte { nbytes as isize } else { -1 };
            state.data = data.install();
            state.props = props.into();
        })
    }

    fn from_encoded(bytes: Vec<u8>, characters: usize, multibyte: bool, props: Vec<StringPropertySpan>) -> Self {
        Self::from_slice(&bytes, characters, multibyte, props, StringAllocation::Ordinary)
    }

    fn from_slice(bytes: &[u8], characters: usize, multibyte: bool, props: Vec<StringPropertySpan>, kind: StringAllocation) -> Self {
        Self::from_data(bytes.len(), characters, multibyte, kind, |data| {
            if !bytes.is_empty() {
                // SAFETY: the fresh output contains BYTES.len() writable bytes.
                unsafe { ptr::copy_nonoverlapping(bytes.as_ptr(), data, bytes.len()) };
            }
            props
        })
    }

''' + s[b:]
a=s.index('        let mut bytes = allocate_bytes(nbytes)?;',s.index('pub(crate) fn from_characters'))
b=s.index('    /// alloc.c:Fmake_string',a)
s=s[:a]+'''        validate_size(nbytes)?;
        Ok(Self::from_data(nbytes, characters.len(), nbytes != characters.len(), StringAllocation::Ordinary, |data| {
            let mut offset = 0;
            for &character in characters {
                let (encoded, width) = encode_character(character_code(character).expect("validated character")).expect("validated code");
                // SAFETY: validation summed these exact encoded widths.
                unsafe { ptr::copy_nonoverlapping(encoded.as_ptr(), data.add(offset), width) };
                offset += width;
            }
            Vec::new()
        }))
    }

''' + s[b:]
a=s.index('        let mut bytes = allocate_bytes(nbytes)?;',s.index('pub(crate) fn repeated_character'))
b=s.index('    pub(crate) fn from_unibyte',a)
s=s[:a]+'''        validate_size(nbytes)?;
        Ok(Self::from_data(nbytes, length, force_multibyte || width != 1, StringAllocation::Ordinary, |data| {
            // SAFETY: all writes remain inside the validated output extent;
            // doubling copies only already initialized, disjoint bytes.
            unsafe {
                if width == 1 && nbytes != 0 {
                    ptr::write_bytes(data, encoded[0], nbytes);
                } else if nbytes != 0 {
                    ptr::copy_nonoverlapping(encoded.as_ptr(), data, width);
                    let mut filled = width;
                    while filled < nbytes {
                        let count = filled.min(nbytes - filled);
                        ptr::copy_nonoverlapping(data, data.add(filled), count);
                        filled += count;
                    }
                }
            }
            Vec::new()
        }))
    }

''' + s[b:]
s=s.replace('Ok(Self::from_encoded_kind(bytes, characters, multibyte, Vec::new(), kind))','Ok(Self::from_slice(&bytes, characters, multibyte, Vec::new(), kind))')
a=s.index('    fn initialize_encoded(');b=s.index('    fn bytes_mut(',a)
s=s[:a]+'''    /// The caller has excluded all borrows before relocating this header's
    /// data during collection. Properties and the Lisp identity do not move.
    pub(crate) fn relocate_data(&mut self, data: NonNull<u8>) {
        self.data = data;
    }

'''+s[b:]
a=s.index('    fn replace_storage(');b=s.index('    pub(crate) fn bytes(',a)
s=s[:a]+'''    fn replace_storage(&mut self, bytes: Vec<u8>, characters: usize, multibyte: bool) {
        let nbytes = bytes.len();
        assert!(nbytes < isize::MAX as usize - 16 && (multibyte || characters == nbytes));
        let old_bytes = self.storage_bytes();
        if nbytes != 0 && old_bytes != 0 && string_data_size(nbytes) == string_data_size(old_bytes) {
            // SAFETY: allocation alignment slop covers the new bytes and NUL.
            unsafe {
                ptr::copy_nonoverlapping(bytes.as_ptr(), self.data.as_ptr(), nbytes);
                self.data.as_ptr().add(nbytes).write(0);
            }
        } else {
            let data = if nbytes == 0 {
                NonNull::from(&EMPTY_DATA)
            } else {
                // SAFETY: this exclusive borrow names a stable, impure header.
                let allocation = unsafe { PendingStringData::new(self, nbytes, false) };
                unsafe { ptr::copy_nonoverlapping(bytes.as_ptr(), allocation.as_ptr(), nbytes) };
                allocation.install()
            };
            if old_bytes != 0 {
                // SAFETY: replacement invalidates the exclusively owned data.
                unsafe { retire_string_data(self.data, old_bytes) };
            }
            self.data = data;
        }
        self.size = characters;
        self.size_byte = if multibyte { nbytes as isize } else { -1 };
    }

'''+s[b:]
s=s.replace('StringObjectRef::from_encoded(self.bytes().to_vec(), self.len(), self.is_multibyte(), self.props.to_vec())','StringObjectRef::from_slice(self.bytes(), self.len(), self.is_multibyte(), self.props.to_vec(), StringAllocation::Ordinary)')
s=s.replace('StringObjectRef::from_encoded_kind(self.bytes().to_vec(), self.len(), self.is_multibyte(), Vec::new(), kind)','StringObjectRef::from_slice(self.bytes(), self.len(), self.is_multibyte(), Vec::new(), kind)')
s=s.replace('let bytes = self.bytes()[offset(from)..offset(to)].to_vec();','let bytes = &self.bytes()[offset(from)..offset(to)];')
s=s.replace('StringObjectRef::from_encoded(bytes, to - from, self.is_multibyte(), props)','StringObjectRef::from_slice(bytes, to - from, self.is_multibyte(), props, StringAllocation::Ordinary)')
a=s.index('            let mut bytes = allocate_bytes(nbytes)?;',s.index('pub(crate) fn store_character'))
b=s.index('\n        }\n        Ok(true)',a)
s=s[:a]+'''            validate_size(nbytes)?;
            let old_bytes = self.storage_bytes();
            let tail = old_bytes - offset - old_width;
            if string_data_size(nbytes) == string_data_size(old_bytes) {
                // alloc.c:resize_string_data reuses alignment slop, and moves
                // the old tail including its NUL with overlap allowed.
                unsafe {
                    let data = self.data.as_ptr();
                    ptr::copy(data.add(offset + old_width), data.add(offset + width), tail + 1);
                    ptr::copy_nonoverlapping(encoded.as_ptr(), data.add(offset), width);
                }
            } else {
                // SAFETY: all three disjoint output ranges are initialized;
                // the pending entry supplies the final NUL and stable owner.
                let allocation = unsafe { PendingStringData::new(self, nbytes, false) };
                unsafe {
                    let data = allocation.as_ptr();
                    ptr::copy_nonoverlapping(self.data.as_ptr(), data, offset);
                    ptr::copy_nonoverlapping(encoded.as_ptr(), data.add(offset), width);
                    ptr::copy_nonoverlapping(self.data.as_ptr().add(offset + old_width), data.add(offset + width), tail);
                    retire_string_data(self.data, old_bytes);
                }
                self.data = allocation.install();
            }
            self.size_byte = nbytes as isize;''' + s[b:]
s=s.replace('fn allocate_bytes(length: usize) -> Result<Vec<u8>, LispError> {\n    if length >= isize::MAX as usize {\n        return Err(string_overflow());\n    }','fn validate_size(length: usize) -> Result<(), LispError> {\n    if length >= isize::MAX as usize - 16 { return Err(string_overflow()); }\n    Ok(())\n}\n\nfn allocate_bytes(length: usize) -> Result<Vec<u8>, LispError> {\n    validate_size(length)?;')
f.write_text(s)
print('Drafted sblock storage and direct character/copy/resize paths; not compiled or frozen.')
