from pathlib import Path
import hashlib,json,os,signal,subprocess,time
p=Path(__file__).parent.resolve();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
state=json.loads((p/'source272-full-queue-state.json').read_text());assert state['status']=='waiting for the existing source270 full macOS supervisor' and state['results']==[]
pid=27731;helper=p/'queue-source272-full-macos.py'
command=subprocess.check_output(['ps','-p',str(pid),'-o','args='],text=True).strip();assert command.endswith('-B '+str(helper))
assert state['fixed_inputs'][str(helper)]==sha(helper)
assert json.loads((p/'source276-sblock-probe-audit.json').read_text())['status']=='passed'
for suffix in ['rust-command.json','frozen-command.json','tty-command.json']:assert not (p/('source272-full-'+suffix)).exists()
with (p/'source272-full-withdrawn-state.json').open('x') as out:json.dump(state,out,indent=2)
os.kill(pid,signal.SIGTERM)
for _ in range(20):
 r=subprocess.run(['ps','-p',str(pid),'-o','args='],capture_output=True,text=True)
 if r.returncode:break
 time.sleep(.25)
assert r.returncode==1 and not r.stdout
result=dict(status='withdrawn while waiting; no validation stage executed',pid=pid,original_command=command,original_state_sha256=sha(p/'source272-full-withdrawn-state.json'),helper_sha256=sha(helper),reason='Prioritize source276 allocator gate/release validation after source270 terminal validation. Source276 includes the source272 borrow repair and passes strict checks plus seven allocator/borrow controls. Full validation remains required on the final selected source. No old failure or incomplete run is relabeled as passing.',source272_mac_stages_executed=0,goal_complete=False)
with (p/'source272-full-withdrawal.json').open('x') as out:json.dump(result,out,indent=2)
print(json.dumps(result,indent=2))
