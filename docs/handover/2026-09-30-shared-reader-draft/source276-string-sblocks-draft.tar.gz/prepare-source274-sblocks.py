from pathlib import Path
import hashlib,json,subprocess,time
p=Path(__file__).parent.resolve();root=p.parents[2]
old=p.parent/'recovered-2026-09-30/string-sblocks/emaxx'
c=p.parent/'recovered-2026-09-30/string-sblock-root-words/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
m=json.loads((p/'source273-manifest.json').read_text())
assert all(sha(old/n)==h for n,h in m.items())
state=json.loads((p/'source273-probe-result.json').read_text());assert state['status']=='failed' and state['results'][-1]['stage']=='check'
assert not c.exists();c.parent.mkdir(parents=True)
steps=[]
for label,command in [('checkout',['git','worktree','add','--detach',str(c),'b5a1558c6b88804cecdbee04a9bdbfab34209ac8']),('replay',['git','apply',str(p/'source273-sblocks.patch')])]:
 result=subprocess.run(command,cwd=root if label=='checkout' else c,capture_output=True,text=True);steps.append(dict(label=label,command=command,exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr));result.check_returncode()
assert all(sha(c/n)==h for n,h in m.items())
(c.parent/'emacs').symlink_to(p.parent/'rebuilt-2026-10-01/emacs',target_is_directory=True)
f=c/'src/lisp/native_comp/runtime.rs';s=f.read_text();a=s.index('    fn string_sblocks_compact_unborrowed_data_and_hold_borrowed_blocks()');b=s.index('    #[test]',a)
part=s[a:b];assert part.count('            &roots,')==2
part=part.replace('        let before = crate::lisp::alloc::string_data_census();','        let native_roots: Vec<_> = roots.iter().map(|value| value.word()).collect();\n        let before = crate::lisp::alloc::string_data_census();')
part=part.replace('            &roots,','            &native_roots,');f.write_text(s[:a]+part+s[b:])
assert all(sha(c/n)==h for n,h in m.items() if n!='src/lisp/native_comp/runtime.rs')
target=c/'target/string-sblock-validation';target.parent.mkdir()
cmd=['/bin/cp','-cR',str(old/'target/string-sblock-validation'),str(target)]
with (p/'source274-cache-clone.log').open('xb') as log:
 started=time.monotonic();result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL)
steps.append(dict(label='idle-cache-clone',command=cmd,exit_code=result.returncode,elapsed_seconds=time.monotonic()-started));result.check_returncode()
with (p/'source274-preparation.json').open('x') as out:json.dump(dict(candidate=str(c),steps=steps,source273_inputs_verified=len(m),only_edit='Pass the same roots as NativeWord values to NativeHeap::collect in the two new control calls. No production source or assertion changes.',qualification='Source273 compiler failure retained unchanged; this is an unvalidated successor.',goal_complete=False),out,indent=2)
s=(p/'run-source273-sblocks.py').read_text().replace('source273','source274').replace('recovered-2026-09-30/string-sblocks/emaxx','recovered-2026-09-30/string-sblock-root-words/emaxx')
with (p/'run-source274-sblocks.py').open('x') as out:out.write(s)
print('Source274 prepared; original failed source273 preserved.')
