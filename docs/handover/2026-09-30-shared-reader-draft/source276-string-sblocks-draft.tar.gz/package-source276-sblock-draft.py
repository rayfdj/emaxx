from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve();root=p.parents[2];out=root/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda n:json.loads((p/n).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
audit=read('source276-sblock-probe-audit.json');assert audit['status']=='passed' and audit['passed']==7 and audit['source_inputs_verified']==511
for n,stage in [(273,'check'),(274,'clippy'),(275,'clippy')]:
 s=read('source'+str(n)+'-probe-result.json');assert s['status']=='failed' and s['results'][-1]['stage']==stage and s['results'][-1]['exit_code']!=0
state=read('source276-selected-state.json')
with (p/'source276-selected-at-draft-packaging.json').open('x') as f:json.dump(state,f,indent=2)
files={};allow={'.json','.log','.patch','.py','.txt'}
exclude={'source276-selected-driver.log','source276-selected-state.json'}
for f in p.iterdir():
 if f.is_file() and f.suffix in allow and f.name.startswith(('source273-','source274-','source275-','source276-')) and f.name not in exclude:
  # At packaging the selected queue is waiting; only completed probe outputs
  # and the explicit queued-state snapshot belong to this immutable archive.
  files[f.name]=f
helpers={'prepare-string-sblocks.py','string-sblocks-checkout-command.json','string-sblocks-checkout.json','string-sblocks-cache-clone.json','string-sblocks-cache-clone.log','draft-stable-string-constructors.py','draft-string-sblock-storage.py','draft-string-sblock-controls.py','draft-string-sblock-concat.py','prepare-source273-validation.py','run-source273-sblocks.py','prepare-source274-sblocks.py','run-source274-sblocks.py','prepare-source275-sblocks.py','run-source275-sblocks.py','prepare-source276-sblocks.py','run-source276-sblocks.py','freeze-source275-sblock-patches.py','prepare-source276-freeze.py','freeze-source276-sblock-patches.py','audit-source276-sblock-probe.py','prepare-source276-selected.py','launch-source276-selected.py','queue-source276-pools-selected.py','run-string-pools-focused.py','audit-string-pools-focused.py','test-string-pools-broad.py','run-string-pools-release.py','audit-string-pools-release.py','source272-manifest.json','source272-gate-inventory.log','source272-gate-controls-command.json','source272-gate-broad-command.json','source272-release-broad-command.json','source270-gate-broad-command.json','source270-release-broad-command.json','source261-gate-broad-command.json','source261-release-broad-command.json','source263-gate-broad-command.json','source255-gate-inventory.log','source255-gate-controls-command.json','source249-gate-controls-command.json','source249-gate-broad-command.json','source249-release-broad-command.json','source272-full-withdrawal.json','source272-full-withdrawn-state.json','withdraw-source272-waiting-macos.py','package-source196-failure-and197-results.py',Path(__file__).name}
for n in helpers:assert (p/n).is_file(),n;files[n]=p/n
package('source276-string-sblocks-draft',files,dict(probe=audit,mechanisms=read('source276-gnu-mechanisms.json'),launch=read('source276-selected-launch.json'),selected_at_packaging=state,withdrawn_older_mac_queue=read('source272-full-withdrawal.json'),qualification='Unapplied source276 architectural draft; exact511-input complete/incremental patches and three preserved failed predecessors. Zero-warning strict checks and seven gate controls pass. Source272 borrow controls are preserved, with only the checked stable-constructor API migration in the exclusive-borrow test. Broader gate/release validation is queued after source270 terminal/full supervisor3079. No broader/platform/ordinary/performance or ownership/accounting/interval/VM completion result is claimed. Root runtime remains source272, main21d20f0e, and the full goal remains active.'))
