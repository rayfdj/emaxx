from pathlib import Path
p=Path(__file__).parent.resolve(); c=p.parent/'recovered-2026-09-30/string-sblocks/emaxx'
f=c/'src/lisp/primitives.rs';s=f.read_text().replace('SharedStringState, StringPropertySpan','StringObjectRef, StringPropertySpan');f.write_text(s)
f=c/'src/lisp/native_comp/runtime.rs';s=f.read_text();needle='    #[test]\n    fn pure_string_headers_survive_unrooted_gc_outside_the_ordinary_census()'
assert needle in s
addition=r'''    #[test]
    fn string_sblocks_compact_unborrowed_data_and_hold_borrowed_blocks() {
        use crate::lisp::types::StringObjectRef;
        #[inline(never)]
        fn make_strings() -> (Vec<Value>, Vec<Vec<u8>>) {
            let mut roots = Vec::new();
            let mut expected = Vec::new();
            for index in 0..768 {
                let length = if index % 41 == 0 { 1025 } else { 37 };
                let code = (index % 26 + usize::from(b'a')) as u32;
                let object = StringObjectRef::repeated_character(code, length, false).unwrap();
                if index % 47 == 31 {
                    roots.push(Value::StringObject(object));
                    expected.push(vec![code as u8; length]);
                }
            }
            for length in [1, 7, 8, 15, 16, 511, 1023, 1024, 1025, 8193] {
                roots.push(Value::StringObject(StringObjectRef::repeated_character(u32::from(b'z'), length, false).unwrap()));
                expected.push(vec![b'z'; length]);
            }
            (roots, expected)
        }
        let mut interpreter = Interpreter::new();
        let environment = Env::new();
        let mut heap = NativeHeap::new();
        heap.begin_call();
        let stack_marker = 0;
        heap.set_stack_bottom(std::ptr::from_ref(&stack_marker));
        let (roots, expected) = make_strings();
        let before = crate::lisp::alloc::string_data_census();
        let pointers: Vec<_> = roots.iter().map(|value| {
            let Kind::StringObject(object) = value.kind() else { panic!("string"); };
            object.borrow().bytes().as_ptr() as usize
        }).collect();
        let Kind::StringObject(pinned) = roots[0].kind() else { panic!("string"); };
        let guard = pinned.borrow();
        let held_bytes = guard.bytes();
        crate::lisp::alloc::clobber_stack();
        heap.collect(std::ptr::from_ref(&stack_marker), &roots, &mut interpreter, &environment);
        assert_eq!(held_bytes.as_ptr() as usize, pointers[0]);
        assert_eq!(held_bytes, expected[0]);
        let mut relocated = 0;
        for ((&value, contents), &previous) in roots.iter().zip(&expected).zip(&pointers) {
            let Kind::StringObject(object) = value.kind() else { panic!("string"); };
            assert_eq!(heap.decode(value.word()).unwrap().word(), value.word());
            let state = object.borrow();
            assert_eq!(state.bytes(), contents);
            let data = state.bytes().as_ptr();
            assert_eq!(data as usize % 8, 0);
            // SAFETY: live sdata owns its aligned back-pointer and NUL;
            // neither access extends beyond this string's allocation.
            unsafe {
                assert_eq!(data.sub(8).cast::<usize>().read(), object.identity());
                assert_eq!(data.add(contents.len()).read(), 0);
            }
            relocated += usize::from(data as usize != previous);
        }
        assert!(relocated > 0, "unborrowed live storage was compacted");
        let after = crate::lisp::alloc::string_data_census();
        assert!(after.0 < before.0 && after.1 < before.1, "actual data blocks and requested bytes are released");
        drop(guard);
        crate::lisp::alloc::clobber_stack();
        heap.collect(std::ptr::from_ref(&stack_marker), &roots, &mut interpreter, &environment);
        assert_ne!(pinned.borrow().bytes().as_ptr() as usize, pointers[0], "the released borrow no longer pins its sparse block");
        assert_eq!(pinned.borrow().bytes(), expected[0]);
    }

    #[test]
    fn string_sdata_resize_reuses_alignment_slop_and_preserves_contents() {
        use crate::lisp::types::StringObjectRef;
        let _interpreter = Interpreter::new();
        let object = StringObjectRef::repeated_character(u32::from(b'a'), 6, true).unwrap();
        let original = object.borrow().bytes().as_ptr() as usize;
        {
            let mut state = object.borrow_mut();
            assert!(state.store_character(2, 0x80).unwrap());
            assert_eq!(state.bytes(), b"aa\xc2\x80aaa");
            assert_eq!(state.bytes().as_ptr() as usize, original);
            assert_eq!(state.len(), 6);
            assert!(state.store_character(2, 0x20_0000).unwrap());
            assert_ne!(state.bytes().as_ptr() as usize, original);
            assert_eq!(state.len(), 6);
            assert_eq!(state.character_at(2), Some(0x20_0000));
            assert_eq!(&state.bytes()[..2], b"aa");
            assert_eq!(&state.bytes()[7..], b"aaa");
            // SAFETY: the allocation includes its initialized trailing NUL.
            unsafe { assert_eq!(state.bytes().as_ptr().add(state.storage_bytes()).read(), 0); }
            assert!(state.store_character(2, u32::from(b'a')).unwrap());
            assert_eq!(state.bytes(), b"aaaaaa");
        }
    }

'''
s=s.replace(needle,addition+needle);f.write_text(s)
print('Added allocator survival, pointer stability, compaction, reclamation and resize controls; not run.')
