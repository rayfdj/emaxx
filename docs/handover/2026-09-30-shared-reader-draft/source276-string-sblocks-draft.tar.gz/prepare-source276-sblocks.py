from pathlib import Path
import hashlib,json,subprocess,time
p=Path(__file__).parent.resolve();root=p.parents[2]
old=p.parent/'recovered-2026-09-30/string-sblock-layout/emaxx';c=p.parent/'recovered-2026-09-30/string-data-pools/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
m=json.loads((p/'source275-manifest.json').read_text());assert all(sha(old/n)==h for n,h in m.items())
state=json.loads((p/'source275-probe-result.json').read_text());assert state['status']=='failed' and state['results'][-1]['stage']=='clippy'
assert not c.exists();c.parent.mkdir(parents=True);steps=[]
for label,cmd in [('checkout',['git','worktree','add','--detach',str(c),'b5a1558c6b88804cecdbee04a9bdbfab34209ac8']),('replay',['git','apply',str(p/'source275-sblocks.patch')])]:
 r=subprocess.run(cmd,cwd=root if label=='checkout' else c,capture_output=True,text=True);steps.append(dict(label=label,command=cmd,exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr));r.check_returncode()
assert all(sha(c/n)==h for n,h in m.items());(c.parent/'emacs').symlink_to(p.parent/'rebuilt-2026-10-01/emacs',target_is_directory=True)
f=c/'src/lisp/native_comp/runtime.rs';s=f.read_text();a=s.index('    fn string_sblocks_compact_unborrowed_data_and_hold_borrowed_blocks()');b=s.index('    #[test]\n    fn pure_string_headers',a);part=s[a:b]
replacements=[('StringObjectRef::repeated_character(code, length, false).unwrap()', 'StringObjectRef::repeated_character(code, length, false).expect("valid string pool input")'),('StringObjectRef::repeated_character(u32::from(b\'z\'), length, false).unwrap()', 'StringObjectRef::repeated_character(u32::from(b\'z\'), length, false).expect("valid size-boundary input")'),('heap.decode(value.word()).unwrap()', 'heap.decode(value.word()).expect("rooted string remains allocated")'),('StringObjectRef::repeated_character(u32::from(b\'a\'), 6, true).unwrap()', 'StringObjectRef::repeated_character(u32::from(b\'a\'), 6, true).expect("valid multibyte resize input")'),('state.store_character(2, 0x80).unwrap()', 'state.store_character(2, 0x80).expect("two-byte character")'),('state.store_character(2, 0x20_0000).unwrap()', 'state.store_character(2, 0x20_0000).expect("five-byte character")'),('state.store_character(2, u32::from(b\'a\')).unwrap()', 'state.store_character(2, u32::from(b\'a\')).expect("ASCII replacement")')]
assert part.count('.unwrap()')==len(replacements)==7
for before,after in replacements:assert before in part;part=part.replace(before,after)
assert '.unwrap()' not in part;f.write_text(s[:a]+part+s[b:]);assert all(sha(c/n)==h for n,h in m.items() if n!='src/lisp/native_comp/runtime.rs')
t=c/'target/string-sblock-validation';t.parent.mkdir();cmd=['/bin/cp','-cR',str(old/'target/string-sblock-validation'),str(t)]
with (p/'source276-cache-clone.log').open('xb') as log:
 started=time.monotonic();r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL)
steps.append(dict(label='idle-cache-clone',command=cmd,exit_code=r.returncode,elapsed_seconds=time.monotonic()-started));r.check_returncode()
with (p/'source276-preparation.json').open('x') as out:json.dump(dict(candidate=str(c),steps=steps,source275_inputs_verified=len(m),only_edit='Supply invariant-specific expect messages for seven new test unwrap calls. Production code, test inputs and assertions are unchanged.',qualification='Source273 compiler and source274/275 Clippy failures preserved unchanged; this is an unvalidated successor.',goal_complete=False),out,indent=2)
s=(p/'run-source275-sblocks.py').read_text().replace('source275','source276').replace('recovered-2026-09-30/string-sblock-layout/emaxx','recovered-2026-09-30/string-data-pools/emaxx')
with (p/'run-source276-sblocks.py').open('x') as out:out.write(s)
print('Source276 prepared; all preceding draft failures preserved.')
