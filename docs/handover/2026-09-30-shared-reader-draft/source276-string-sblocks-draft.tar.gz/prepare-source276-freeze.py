from pathlib import Path
p=Path(__file__).parent.resolve()
s=(p/'freeze-source275-sblock-patches.py').read_text().replace('source275','source276').replace('string-sblock-layout/emaxx','string-data-pools/emaxx')
s=s.replace(' assert body(root)==body(candidate)', ''' original=body(root)
 if suffix=='exclusive_string_borrows_reject_gc_before_marking_or_sweeping':
  before='''+repr('''            let object = crate::lisp::alloc::allocate_string(
                crate::lisp::types::SharedStringState::from_storage(Vec::new(), 0, multibyte)
                    .expect("empty string"),
                false,
            );''')+'''
  after='''+repr('''            let object =
                crate::lisp::types::StringObjectRef::from_storage(Vec::new(), 0, multibyte)
                    .expect("empty string");''')+'''
  assert original.count(before)==1
  original=original.replace(before,after)
 assert original==body(candidate)''')
s=s.replace("('source274-sblocks.patch',base,read('source274-manifest.json'))]", "('source274-sblocks.patch',base,read('source274-manifest.json')),('source275-sblocks.patch',base,read('source275-manifest.json'))]")
s=s.replace("source272_borrow_controls='byte-identical'", "source272_borrow_controls='Two byte-identical; the exclusive-borrow test differs only by the exact stable empty-constructor API migration checked here. Every assertion remains identical.'")
s=s.replace('Source273 compiler and source274 Clippy failures', 'Source273 compiler and source274/275 Clippy failures')
with (p/'freeze-source276-sblock-patches.py').open('x') as out:out.write(s)
