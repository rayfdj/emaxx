from pathlib import Path
import hashlib,io,json,os,subprocess,tarfile,tempfile
p=Path(__file__).parent.resolve();root=p.parents[2]
candidate=p.parent/'recovered-2026-09-30/string-data-pools/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
read=lambda n:json.loads((p/n).read_text())
base='b5a1558c6b88804cecdbee04a9bdbfab34209ac8';main='21d20f0eec08f3c013d5d3eb3bd6e9cfc16b3199'
prior=read('source272-manifest.json');manifest=read('source276-manifest.json')
assert len(manifest)==511 and all(sha(candidate/n)==h for n,h in manifest.items())
assert all(sha(root/n)==h for n,h in prior.items())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=candidate,text=True).strip()==base
new={'src/lisp/alloc/strings/data.rs'};assert manifest.keys()-prior.keys()==new
changed=[n for n in manifest if prior.get(n)!=manifest[n]]
# Preserve every original source272 borrow-root test byte. Constructor API
# migrations in other tests are explicit in the full source patch.
runtime='src/lisp/native_comp/runtime.rs'
for suffix in ['borrowed_string_properties_survive_off_stack_guards_and_are_reclaimed_after_release','off_stack_string_borrows_enter_the_weak_table_fixed_point','exclusive_string_borrows_reject_gc_before_marking_or_sweeping']:
 def body(directory):
  s=(directory/runtime).read_text();a=s.index('    #[test]\n    fn '+suffix+'()');b=s.index('    #[test]',a+len('    #[test]'));return s[a:b]
 original=body(root)
 if suffix=='exclusive_string_borrows_reject_gc_before_marking_or_sweeping':
  before='            let object = crate::lisp::alloc::allocate_string(\n                crate::lisp::types::SharedStringState::from_storage(Vec::new(), 0, multibyte)\n                    .expect("empty string"),\n                false,\n            );'
  after='            let object =\n                crate::lisp::types::StringObjectRef::from_storage(Vec::new(), 0, multibyte)\n                    .expect("empty string");'
  assert original.count(before)==1
  original=original.replace(before,after)
 assert original==body(candidate)
added=b''
for n in sorted(new):
 r=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',n],cwd=candidate,capture_output=True);assert r.returncode==1 and not r.stderr;added+=r.stdout
patches={}
for label,commit in [('portable-incremental',base),('portable-complete',main)]:
 data=subprocess.check_output(['git','diff','--binary',commit,'--',*sorted(manifest)],cwd=candidate)+added
 f=p/('source276-'+label+'.patch')
 with f.open('xb') as out:out.write(data)
 patches[label]=dict(base=commit,sha256=sha(f),bytes=len(data))
assert (p/'source276-portable-incremental.patch').read_bytes()==(p/'source276-sblocks.patch').read_bytes()
replays=[('source273-sblocks.patch',base,read('source273-manifest.json')),('source274-sblocks.patch',base,read('source274-manifest.json')),('source275-sblocks.patch',base,read('source275-manifest.json'))]+[('source276-'+label+'.patch',row['base'],manifest) for label,row in patches.items()]
records=[]
for patch,commit,inputs in replays:
 tracked=set(subprocess.check_output(['git','ls-tree','-r','--name-only',commit],cwd=root,text=True).splitlines())
 archive=subprocess.check_output(['git','archive',commit,'--',*sorted(tracked & inputs.keys())],cwd=root)
 with tempfile.TemporaryDirectory(prefix='emaxx-sblock-replay-',dir='/private/tmp') as temporary:
  directory=Path(temporary)
  with tarfile.open(fileobj=io.BytesIO(archive)) as source:
   for member in source:
    assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
    dest=directory/member.name
    if member.isdir():dest.mkdir(parents=True,exist_ok=True)
    else:
     assert member.isfile();dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(source.extractfile(member).read());os.chmod(dest,0o755 if member.mode & 0o111 else 0o644)
  subprocess.run(['git','apply','--check',str(p/patch)],cwd=directory,check=True)
  subprocess.run(['git','apply',str(p/patch)],cwd=directory,check=True)
  assert all(sha(directory/n)==h for n,h in inputs.items())
  assert all((directory/n).stat().st_mode & 0o777==(candidate/n).stat().st_mode & 0o777 for n in inputs)
 records.append(dict(patch=patch,base=commit,inputs=len(inputs),sha256=sha(p/patch),bytes_and_modes='exact'))
with (p/'source276-freeze.json').open('x') as out:json.dump(dict(source='source276',inputs=511,changed_files=changed,patches=patches,replays=records,source272_borrow_controls='Two byte-identical; the exclusive-borrow test differs only by the exact stable empty-constructor API migration checked here. Every assertion remains identical.',goal_complete=False),out,indent=2)
gnu=p.parent/'rebuilt-2026-10-01/emacs'
record=dict(gnu_revision='636f166cfc86aa90d63f592fd99f3fdd9ef95ebd',gnu_inputs={n:sha(gnu/n) for n in ['src/alloc.c','src/lisp.h','src/character.c','src/fns.c']},mechanisms=['alloc.c:string header allocation before sdata creation','alloc.c:allocate_string_data: aligned sdata with owner back-pointer and NUL;8184-byte small blocks;individual blocks above1024 bytes','alloc.c:resize_string_data: reuse equal aligned extents, otherwise copy and retire old sdata','alloc.c:sweep_strings/free_large_strings/compact_small_strings: dead entry sizes, live owner relocation, block reclamation','alloc.c:Fmake_string and character.c:Fstring: validate size/characters, initialize final storage','fns.c:concat_to_string: validate then fill final storage without an intermediate byte vector'],rust_constraint='Live Rust shared borrows cannot have data moved or their borrowed header mutated. Their complete small blocks are temporarily removed from compaction, then made eligible on the next collection after guard release. No per-read lookup, registry or string pin allocation is added. Extra collection scanning/retained block slack is unmeasured.',pure_storage='Pure string bytes are packed in separate permanent immovable block chains. This is not a unified pure arena for every Lisp object. Headers retain the previous permanent/pure flags.',remaining=['actual text-property intervals','ordinary header and block metadata physical accounting, real counters and retained-memory reporting','public allocator/runtime ownership and serialization','GNU pin_string/raw VM stack and call profiling','transient host-text adapters, symbols and complete object authority','complete selected/platform/native/module/dump/startup/thread/GC/integration validation and final adversarial audit','locked16-workload performance criterion, unchanged3% ceiling'],qualification='Architectural draft only. Original source273 compiler and source274 Clippy failures remain recorded. Source275 strict/runtime outcomes are separate; no memory/time improvement or full-goal completion is claimed.',goal_complete=False)
with (p/'source276-gnu-mechanisms.json').open('x') as out:json.dump(record,out,indent=2)
print(json.dumps(records,indent=2))
