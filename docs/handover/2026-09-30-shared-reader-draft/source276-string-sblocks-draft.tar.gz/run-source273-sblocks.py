from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

p = Path(__file__).parent.resolve()
root = p.parents[2]
candidate = p.parent / 'recovered-2026-09-30/string-sblocks/emaxx'
gnu = p.parent / 'rebuilt-2026-10-01/emacs'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
baseline = json.loads((p / 'source272-manifest.json').read_text())
changed_files = set(subprocess.check_output(['git','diff','--name-only'],cwd=candidate,text=True).splitlines())
added_files = {'src/lisp/alloc/strings/data.rs'}
assert len(changed_files) == 16
assert all((candidate / name).is_file() for name in added_files)
assert len(baseline) == 510
assert all(sha(root / n) == h for n, h in baseline.items())
assert all(sha(candidate / n) == h for n, h in baseline.items() if n not in changed_files)

def save(suffix, data):
    with (p / ('source273-' + suffix + '.json')).open('x') as f:
        json.dump(data, f, indent=2)

def diff():
    data = subprocess.check_output(['git', 'diff', '--binary'], cwd=candidate)
    for name in sorted(added_files):
        result = subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',name],cwd=candidate,capture_output=True)
        assert result.returncode == 1 and not result.stderr
        data += result.stdout
    return data

with (p / 'source273-unformatted.patch').open('xb') as f:
    f.write(diff())
format_command = ['cargo', 'fmt', '--all']
with (p / 'source273-format.log').open('xb') as log:
    result = subprocess.run(format_command, cwd=candidate, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
save('format', dict(command=format_command, exit_code=result.returncode))
result.check_returncode()
assert all(sha(candidate / n) == h for n, h in baseline.items() if n not in changed_files)
assert set(subprocess.check_output(['git', 'diff', '--name-only'], cwd=candidate, text=True).splitlines()) == changed_files
with (p / 'source273-sblocks.patch').open('xb') as f:
    f.write(diff())
manifest = {n: sha(candidate / n) for n in sorted(set(baseline) | added_files)}
save('manifest', manifest)
unchanged = lambda: all(sha(candidate / n) == h for n, h in manifest.items())
env = dict(CARGO_TARGET_DIR=str(candidate / 'target/string-sblock-validation'), CARGO_BUILD_JOBS='1',
           LANG='C', LC_ALL='C', RUST_MIN_STACK='134217728', RUST_TEST_THREADS='1', EMAXX_GC_VERIFY='1',
           EMAXX_GNU_SOURCE_DIRECTORY=str(gnu), EMAXX_DUMP_SOURCE_DIRECTORY=str(gnu), EMACS_TEST_DIRECTORY=str(gnu / 'test'))
state = dict(status='starting', results=[], source_manifest='source273-manifest.json', goal_complete=False)

def run(stage, command):
    assert unchanged()
    state.update(status='running ' + stage, current_command=command)
    (p / 'source273-probe-state.json').write_text(json.dumps(state, indent=2) + '\n')
    save(stage + '-command', dict(command=command, working_directory=str(candidate), environment_override=env,
                                  source_manifest='source273-manifest.json', helper_sha256=sha(Path(__file__))))
    started = time.monotonic()
    with (p / ('source273-' + stage + '.log')).open('xb') as log:
        result = subprocess.run(command, cwd=candidate, env=dict(os.environ, **env), stdin=subprocess.DEVNULL,
                                stdout=log, stderr=subprocess.STDOUT)
    record = dict(stage=stage, exit_code=result.returncode, elapsed_seconds=time.monotonic() - started,
                  source_unchanged=unchanged(), published_source_unchanged=all(sha(root / n) == h for n, h in baseline.items()))
    save(stage + '-result', record)
    state['results'].append(record)
    assert record['source_unchanged'] and record['published_source_unchanged']
    return result.returncode

try:
    for stage, command in [
        ('fmt', ['cargo', 'fmt', '--all', '--check']),
        ('check', ['cargo', 'check', '--locked', '--all-targets', '--all-features']),
        ('clippy', ['cargo', 'clippy', '--locked', '--all-targets', '--all-features', '--', '-D', 'warnings']),
        ('diff', ['git', 'diff', '--check']),
    ]:
        assert run(stage, command) == 0
        assert not any(line.startswith('warning:') for line in (p / ('source273-' + stage + '.log')).read_text().splitlines())
    build = ['cargo', 'test', '--locked', '--all-features', '--profile', 'gate', '--lib', '--no-run', '--message-format=json-render-diagnostics']
    assert run('gate-build', build) == 0
    artifacts = []
    for line in (p / 'source273-gate-build.log').read_text().splitlines():
        if line.startswith('{'):
            message = json.loads(line)
            if message.get('reason') == 'compiler-artifact' and message.get('profile', {}).get('test') and message.get('executable') and message['target']['name'] == 'emaxx':
                artifacts.append(Path(message['executable']))
    assert len(artifacts) == 1
    binary = p / 'source273-gate-libtest'
    assert not binary.exists()
    shutil.copy2(artifacts[0], binary)
    assert sha(binary) == sha(artifacts[0])
    save('binary', dict(path=str(binary), sha256=sha(binary), built_artifact=str(artifacts[0])))
    assert run('gate-inventory', [str(binary), '--list', '--format', 'terse']) == 0
    names = [line[:-6] for line in (p / 'source273-gate-inventory.log').read_text().splitlines() if line.endswith(': test')]
    assert len(names) == len(set(names)) == 3026
    controls = [
        'string_sblocks_compact_unborrowed_data_and_hold_borrowed_blocks',
        'string_sdata_resize_reuses_alignment_slop_and_preserves_contents',
        'borrowed_string_properties_survive_off_stack_guards_and_are_reclaimed_after_release',
        'off_stack_string_borrows_enter_the_weak_table_fixed_point',
        'exclusive_string_borrows_reject_gc_before_marking_or_sweeping',
        'native_gc_traces_string_properties_and_reclaims_string_cycles',
        'pure_string_headers_survive_unrooted_gc_outside_the_ordinary_census',
    ]
    selectors = ['lisp::native_comp::runtime::tests::' + name for name in controls]
    assert all(name in names for name in selectors)
    run('gate-probe', [str(binary), '--test-threads=1', '--nocapture', '--exact', *selectors])
    state['status'] = 'finished; raw result requires audit'
except Exception as error:
    state.update(status='failed', error=repr(error))
finally:
    (p / 'source273-probe-state.json').write_text(json.dumps(state, indent=2) + '\n')
    save('probe-result', state)
print(json.dumps(state), flush=True)
sys.exit(0 if len(state['results']) == 7 and all(r['exit_code'] == 0 for r in state['results']) else 1)
