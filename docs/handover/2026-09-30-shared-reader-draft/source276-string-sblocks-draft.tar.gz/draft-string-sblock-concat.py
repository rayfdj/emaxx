from pathlib import Path
p=Path(__file__).parent.resolve();c=p.parent/'recovered-2026-09-30/string-sblocks/emaxx'
f=c/'src/lisp/types/string_data/concat.rs';s=f.read_text();s=s.replace('use super::{allocate_bytes, character_code, encode_character, string_overflow};','use super::{StringAllocation, character_code, encode_character, string_overflow, validate_size};\nuse std::ptr;')
a=s.index('fn extend_encoded(');b=s.index('fn copy_properties(',a)
s=s[:a]+'''struct Output {
    data: *mut u8,
    length: usize,
    filled: usize,
}

impl Output {
    fn extend(&mut self, bytes: &[u8]) {
        assert!(bytes.len() <= self.length - self.filled);
        if !bytes.is_empty() {
            // SAFETY: the constructor owns this fresh allocation, and the
            // checked range is disjoint from the input string/encoded word.
            unsafe { ptr::copy_nonoverlapping(bytes.as_ptr(), self.data.add(self.filled), bytes.len()) };
        }
        self.filled += bytes.len();
    }

    fn character(&mut self, code: u32, multibyte: bool) {
        if multibyte {
            let (encoded, width) = encode_character(code).expect("validated character");
            self.extend(&encoded[..width]);
        } else {
            self.extend(&[code as u8]);
        }
    }
}

'''+s[b:]
s=s.replace('        let mut bytes = allocate_bytes(nbytes)?;','        validate_size(nbytes)?;\n        Ok(Self::from_data(nbytes, characters, multibyte, StringAllocation::Ordinary, |data| {\n        let mut bytes = Output { data, length: nbytes, filled: 0 };')
s=s.replace('bytes.extend_from_slice(state.bytes());','bytes.extend(state.bytes());')
s=s.replace('extend_encoded(&mut bytes, code, true)?;','bytes.character(code, true);')
s=s.replace('extend_encoded(&mut bytes, character_code(value)?, multibyte)?;','bytes.character(character_code(value).expect("validated character"), multibyte);')
s=s.replace('                })?,\n            }\n        }\n        debug_assert_eq!(bytes.len(), nbytes);','                }).expect("validated sequence"),\n            }\n        }\n        assert_eq!(bytes.filled, nbytes);')
s=s.replace('        Ok(Self::from_encoded(bytes, characters, multibyte, merged))','        merged\n        }))')
f.write_text(s)
f=c/'src/lisp/types/string_data.rs';s=f.read_text();a=s.index('fn allocate_bytes(');b=s.index('pub(crate) fn encode_text(',a);s=s[:a]+s[b:]
s=s.replace('                allocation.install()\n            };','                crate::lisp::native_comp::note_lisp_allocation(string_data_size(nbytes));\n                allocation.install()\n            };')
s=s.replace('                self.data = allocation.install();\n            }\n            self.size_byte', '                self.data = allocation.install();\n                crate::lisp::native_comp::note_lisp_allocation(string_data_size(nbytes));\n            }\n            self.size_byte')
f.write_text(s)
print('Concat now fills final sdata directly; reallocations charge real sdata size to the existing GNU logical trigger. Full physical accounting remains open.')
