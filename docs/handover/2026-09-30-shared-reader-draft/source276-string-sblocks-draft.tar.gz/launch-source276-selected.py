from pathlib import Path
import ast,hashlib,json,os,subprocess,sys
p=Path(__file__).parent.resolve();c=p.parent/'recovered-2026-09-30/string-data-pools/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
names=[s[:-6] for s in (p/'source276-gate-inventory.log').read_text().splitlines() if s.endswith(': test')]
prior=json.loads((p/'source272-gate-controls-command.json').read_text())['selectors']
old=json.loads((p/'source249-gate-controls-command.json').read_text())['command']
base={n for n in old[1:] if '::' in n and not n.startswith('-')}
for helper in ['run-string-pools-focused.py','run-string-pools-release.py']:
 t=ast.parse((p/helper).read_text());extra=ast.literal_eval(next(n.value for n in t.body if isinstance(n,ast.Assign) and any(isinstance(a,ast.Name) and a.id=='extra_names' for a in n.targets)))
 selected=base|{n for n in names if n.rsplit('::',1)[-1] in extra}
 assert len(selected)==210 and set(prior)<=selected and selected<=set(names)
selected_broad=[n for n in names if n.startswith(('lisp::bytecode::','lisp::native_comp::runtime::','lisp::primitives::pdumper::','lisp::primitives::tests::','lisp::reader::','lisp::types::','lisp::primitives::compat_runtime_tests::'))]
assert len(selected_broad)==1064 and set(json.loads((p/'source272-gate-broad-command.json').read_text())['selected_inventory'])<=set(selected_broad)
command=[sys.executable,'-B',str(p/'queue-source276-pools-selected.py')]
with (p/'source276-selected-driver.log').open('xb') as log:
 process=subprocess.Popen(command,cwd=c,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env=dict(os.environ,PYTHONUNBUFFERED='1',PYTHONDONTWRITEBYTECODE='1'))
record=dict(pid=process.pid,command=command,candidate=str(c),source_manifest='source276-manifest.json',helper_sha256=sha(p/'queue-source276-pools-selected.py'),waits_for_pid=3079,preflight_focused_selectors=210,preflight_broad_selectors=1064,qualification='Launch only: waits for source270 full/terminal supervisor exit, then gate focused/broad and release focused/broad with all inherited controls and strict auditors. All source276 inputs remain frozen. No selected pass or full-goal completion claim.',goal_complete=False)
with (p/'source276-selected-launch.json').open('x') as out:json.dump(record,out,indent=2)
print(json.dumps(record,indent=2))
