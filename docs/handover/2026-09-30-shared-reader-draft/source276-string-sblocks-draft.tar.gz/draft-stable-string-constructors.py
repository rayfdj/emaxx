from pathlib import Path
import hashlib,json
p=Path(__file__).parent.resolve();root=p.parent/'recovered-2026-09-30/string-sblocks/emaxx'
manifest=json.loads((p/'source272-manifest.json').read_text())
assert all(hashlib.sha256((root/n).read_bytes()).hexdigest()==h for n,h in manifest.items())

file=root/'src/lisp/types/string_data.rs';s=file.read_text()
s=s.replace('StringPropertySpan, Value};','StringObjectRef, StringPropertySpan, Value};')
start=s.index('impl Clone for SharedStringState {');end=s.index('impl std::fmt::Debug',start)
s=s[:start]+s[end:]
start=s.index('    fn from_encoded(');end=s.index('    fn bytes_mut(',start)
s=s[:start]+'''    pub(crate) fn empty(multibyte: bool) -> Self {
        Self {
            size: 0,
            size_byte: if multibyte { 0 } else { -1 },
            props: StringProperties::default(),
            data: NonNull::from(&EMPTY_DATA),
        }
    }

    fn initialize_encoded(
        &mut self,
        bytes: Vec<u8>,
        characters: usize,
        multibyte: bool,
        props: Vec<StringPropertySpan>,
    ) {
        self.replace_storage(bytes, characters, multibyte);
        self.props = props.into();
    }

'''+s[end:]
start=s.index('    fn replace_storage(');end=s.index('    /// character.c:Fstring',start)
s=s[:start]+'''    fn replace_storage(&mut self, mut bytes: Vec<u8>, characters: usize, multibyte: bool) {
        let nbytes = bytes.len();
        assert!(nbytes < isize::MAX as usize && (multibyte || characters == nbytes));
        let data = if nbytes == 0 {
            NonNull::from(&EMPTY_DATA)
        } else {
            bytes.push(0);
            NonNull::new(Box::into_raw(bytes.into_boxed_slice()).cast::<u8>())
                .expect("boxed string allocation")
        };
        let old_nbytes = self.storage_bytes();
        if old_nbytes != 0 {
            // SAFETY: this exclusive header owns the old exact allocation.
            unsafe {
                drop(Box::from_raw(std::ptr::slice_from_raw_parts_mut(
                    self.data.as_ptr(), old_nbytes + 1,
                )));
            }
        }
        self.size = characters;
        self.size_byte = if multibyte { nbytes as isize } else { -1 };
        self.data = data;
    }

'''+s[end:]
start=s.index('    /// character.c:Fstring');end=s.index('    pub(crate) fn bytes(&self)',start)
constructors=s[start:end]
s=s[:start]+s[end:]
constructors=constructors.replace('pub(crate) fn new(', 'pub(crate) fn from_text(')
needle='''    pub(crate) fn from_storage(
        bytes: Vec<u8>,
        characters: usize,
        multibyte: bool,
    ) -> Result<Self, LispError> {'''
assert constructors.count(needle)==1
constructors=constructors.replace(needle,needle+'''
        Self::from_storage_kind(bytes, characters, multibyte, crate::lisp::alloc::StringAllocation::Ordinary)
    }

    pub(crate) fn from_storage_kind(
        bytes: Vec<u8>,
        characters: usize,
        multibyte: bool,
        kind: crate::lisp::alloc::StringAllocation,
    ) -> Result<Self, LispError> {''')
constructors=constructors.replace('Ok(Self::from_encoded(bytes, characters, multibyte, Vec::new()))', 'Ok(Self::from_encoded_kind(bytes, characters, multibyte, Vec::new(), kind))')
factory='''impl StringObjectRef {
    fn from_encoded(bytes: Vec<u8>, characters: usize, multibyte: bool, props: Vec<StringPropertySpan>) -> Self {
        Self::from_encoded_kind(bytes, characters, multibyte, props, crate::lisp::alloc::StringAllocation::Ordinary)
    }

    fn from_encoded_kind(bytes: Vec<u8>, characters: usize, multibyte: bool, props: Vec<StringPropertySpan>, kind: crate::lisp::alloc::StringAllocation) -> Self {
        crate::lisp::alloc::allocate_string(characters, multibyte, kind, |state| {
            state.initialize_encoded(bytes, characters, multibyte, props);
        })
    }

'''+constructors+'}\n\n'
at=s.index('impl SharedStringState {');s=s[:at]+factory+s[at:]
start=s.index('    pub(crate) fn clone_without_properties(');end=s.index('    /// fns.c:Fsubstring',start)
s=s[:start]+'''    pub(crate) fn copy_with_properties(&self) -> StringObjectRef {
        StringObjectRef::from_encoded(self.bytes().to_vec(), self.len(), self.is_multibyte(), self.props.to_vec())
    }

    pub(crate) fn copy_without_properties(&self, kind: crate::lisp::alloc::StringAllocation) -> StringObjectRef {
        StringObjectRef::from_encoded_kind(self.bytes().to_vec(), self.len(), self.is_multibyte(), Vec::new(), kind)
    }

'''+s[end:]
s=s.replace('fn substring(&self, from: usize, to: usize, properties: bool) -> Self', 'fn substring(&self, from: usize, to: usize, properties: bool) -> StringObjectRef')
s=s.replace('Self::from_encoded(bytes, to - from, self.is_multibyte(), props)', 'StringObjectRef::from_encoded(bytes, to - from, self.is_multibyte(), props)')
file.write_text(s)

file=root/'src/lisp/alloc/strings.rs';s=file.read_text()
s=s.replace('    pub fn borrow_mut(&self)', '    pub(crate) fn borrow_mut(&self)')
s=s.replace('''        let state = SharedStringState::from_storage(Vec::new(), 0, multibyte)
            .expect("empty string storage");''','''        let state = SharedStringState::empty(multibyte);''')
start=s.index('pub(crate) fn allocate_string(');end=s.index('    let head = FREE_LIST.load(',start)
s=s[:start]+'''/// Ordinary constructors canonicalize empties; restoration and purecopy
/// allocate distinct headers, as their GNU C paths require.
#[derive(Clone, Copy, PartialEq, Eq)]
pub(crate) enum StringAllocation {
    Ordinary,
    Restored,
    Pure,
}

/// Allocate the stable header before constructing its data. The initializer
/// sees the final header address and cannot move its state into host storage.
pub(crate) fn allocate_string(
    characters: usize,
    multibyte: bool,
    kind: StringAllocation,
    initialize: impl FnOnce(&mut SharedStringState),
) -> StringObjectRef {
    if kind == StringAllocation::Ordinary && characters == 0 {
        return empty_string(multibyte);
    }
'''+s[end:]
old='''    // SAFETY: free storage is fully initialized before publishing its handle.
    unsafe {
        cell.write(StringCell::new(state, pure));
        StringObjectRef::from_raw(cell)
    }
}'''
new='''    // SAFETY: initialize a valid empty header before exposing its final
    // address. The construction guard also rejects reentrant collection.
    let handle = unsafe {
        cell.write(StringCell::new(SharedStringState::empty(multibyte), kind == StringAllocation::Pure));
        (*cell).borrows.set(-1);
        let mut guard = StringBorrowMut(&*cell);
        initialize(&mut guard);
        drop(guard);
        StringObjectRef::from_raw(cell)
    };
    let state = handle.borrow();
    assert_eq!(state.len(), characters);
    assert_eq!(state.is_multibyte(), multibyte);
    if kind == StringAllocation::Pure {
        assert!(state.props.is_empty(), "pure strings have no intervals");
    } else {
        super::super::types::note_string_allocation(state.storage_bytes());
        LIVE_STRINGS.store(LIVE_STRINGS.load(Ordering::Relaxed) + 1, Ordering::Relaxed);
        LIVE_BYTES.store(LIVE_BYTES.load(Ordering::Relaxed) + state.storage_bytes(), Ordering::Relaxed);
        LIVE_SPANS.store(LIVE_SPANS.load(Ordering::Relaxed) + state.props.len(), Ordering::Relaxed);
    }
    drop(state);
    handle
}'''
assert s.count(old)==1;s=s.replace(old,new);file.write_text(s)
file=root/'src/lisp/alloc.rs';s=file.read_text().replace('allocate_restored_string, allocate_string, borrowed_string_roots, live_string_object_census,','StringAllocation, allocate_string, borrowed_string_roots, live_string_object_census,');file.write_text(s)

# Constructors now return the one-word handle directly. Keep the header type
# for borrow targets; callers no longer own or clone movable payloads.
for file in (root/'src/lisp').rglob('*.rs'):
    s=file.read_text();old=s
    s=s.replace('SharedStringState::new(', 'StringObjectRef::from_text(')
    for name in ['from_unibyte','from_storage','from_characters','repeated_character','concatenate']:
        s=s.replace('SharedStringState::'+name+'(', 'StringObjectRef::'+name+'(')
    s=s.replace('crate::lisp::types::string_object_value(', 'Value::StringObject(')
    if file!=root/'src/lisp/types.rs' and 'SharedStringState' in s and 'StringObjectRef::' in s:
        s=s.replace('Env, SharedStringState}', 'Env, StringObjectRef}')
        s=s.replace('LispError, SharedStringState, StringPropertySpan', 'LispError, StringObjectRef, StringPropertySpan')
        s=s.replace('ReaderForm, SharedStringState, StringPropertySpan', 'ReaderForm, StringObjectRef, StringPropertySpan')
        s=s.replace('use crate::lisp::types::SharedStringState;', 'use crate::lisp::types::StringObjectRef;')
    if s!=old:file.write_text(s)

file=root/'src/lisp/types.rs';s=file.read_text()
start=s.index('/// A string object with its own GNU-layout header');end=s.index('#[derive(Default)]\npub(crate) struct StringCensus',start)
s=s[:start]+s[end:]
s=s.replace('        make_uninterned_symbol_name, string_object_value,','        make_uninterned_symbol_name,')
s=s.replace('string_object_value(', 'Value::StringObject(')
s=s.replace('EnvFrame, Kind, LispError, SharedCons, SharedStringState, SymbolName, Value,','EnvFrame, Kind, LispError, SharedCons, StringObjectRef, SymbolName, Value,')
old='''        let value = Value::StringObject(StringObjectRef::from_text(
            text,
            Vec::new(),
            multibyte,
            Vec::new(),
        ));
        let Kind::StringObject(state) = value.kind() else {
            unreachable!("string constructor")
        };
        state'''
new='''        StringObjectRef::from_text(text, Vec::new(), multibyte, Vec::new())'''
assert s.count(old)==1;s=s.replace(old,new);file.write_text(s)
file=root/'src/lisp/types/string_data/concat.rs';s=file.read_text().replace('SharedStringState,','StringObjectRef,').replace('impl SharedStringState {','impl StringObjectRef {');file.write_text(s)
file=root/'src/lisp/primitives/coding.rs';s=file.read_text().replace('let copy = object.borrow().clone();','let copy = object.borrow().copy_with_properties();');file.write_text(s)
file=root/'src/lisp/eval.rs';s=file.read_text()
old='''crate::lisp::alloc::allocate_restored_string(
                    state.borrow().clone_without_properties(),
                )'''
assert s.count(old)==1;s=s.replace(old,'''state.borrow().copy_without_properties(crate::lisp::alloc::StringAllocation::Restored)''');file.write_text(s)
file=root/'src/lisp/primitives/purecopy.rs';s=file.read_text()
old='''            let copy = state.borrow().clone_without_properties();
            Value::StringObject(crate::lisp::alloc::allocate_string(copy, true))'''
assert s.count(old)==1;s=s.replace(old,'''            Value::StringObject(state.borrow().copy_without_properties(crate::lisp::alloc::StringAllocation::Pure))''');file.write_text(s)
file=root/'src/lisp/primitives/strings.rs';s=file.read_text()
old='''            if result.len() == 0 && !result.is_multibyte() {
                Ok(Value::String("".into()))
            } else {
                Ok(Value::StringObject(result))
            }'''
assert s.count(old)==1;s=s.replace(old,'            Ok(Value::StringObject(result))');file.write_text(s)
file=root/'src/lisp/primitives/dispatch/strings.rs';s=file.read_text()
old='''                if result.len() == 0 && !result.is_multibyte() {
                    // alloc.c returns the existing empty unibyte string.
                    return Ok(Value::String("".into()));
                }
'''
assert s.count(old)==1;s=s.replace(old,'');file.write_text(s)
file=root/'src/lisp/primitives/pdumper/load.rs';s=file.read_text()
old='''        let state = StringObjectRef::from_storage(bytes.to_vec(), size, multibyte)
            .map_err(|error| LoadError::Error(error.to_string()))?;'''
new='''        let mode = if kind == DumpType::EmptyString {
            crate::lisp::alloc::StringAllocation::Ordinary
        } else {
            crate::lisp::alloc::StringAllocation::Restored
        };
        let state = StringObjectRef::from_storage_kind(bytes.to_vec(), size, multibyte, mode)
            .map_err(|error| LoadError::Error(error.to_string()))?;'''
assert s.count(old)==1;s=s.replace(old,new).replace('Value::StringObject(crate::lisp::alloc::allocate_restored_string(state))','Value::StringObject(state)');file.write_text(s)

file=root/'src/lisp/native_comp/runtime.rs';s=file.read_text()
old='''            let object = crate::lisp::alloc::allocate_string(
                crate::lisp::types::StringObjectRef::from_storage(Vec::new(), 0, multibyte)
                    .expect("empty string"),
                false,
            );'''
new='''            let object = crate::lisp::types::StringObjectRef::from_storage(Vec::new(), 0, multibyte)
                .expect("empty string");'''
assert s.count(old)==1;s=s.replace(old,new)
old='''            let hidden = [
                StringObjectRef::from_unibyte(Vec::new()),
                StringObjectRef::from_storage(Vec::new(), 0, true).expect("empty multibyte"),
                StringObjectRef::from_unibyte(b"pure bytes".to_vec()),
            ]
            .map(|state| {
                Value::StringObject(crate::lisp::alloc::allocate_string(state, true)).word() ^ HIDE
            });'''
new='''            let hidden = [(Vec::new(), false), (Vec::new(), true), (b"pure bytes".to_vec(), false)]
                .map(|(bytes, multibyte)| {
                    let characters = bytes.len();
                    Value::StringObject(StringObjectRef::from_storage_kind(
                        bytes, characters, multibyte, crate::lisp::alloc::StringAllocation::Pure,
                    ).expect("pure string storage")).word() ^ HIDE
                });'''
assert s.count(old)==1;s=s.replace(old,new);file.write_text(s)
print('Drafted stable string constructors; not compiled or frozen.')
