from pathlib import Path
import ast
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
tree = ast.parse((p / 'package-source196-failure-and197-results.py').read_text())
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
names = ['source208-manifest.json', 'source208-base.json', 'source208-complete.patch',
         'source208-patch-replay-and-modes-audit.json', 'audit-source208-patch.py',
         'source208-controls-launch.json', 'queue-bytecode208.py', 'check-bytecode208.py',
         'static-bytecode208.py', 'test-bytecode-controls208.py', 'freeze-bytecode-candidate.py',
         'compare-recovered-continuation-fixtures.py', 'audit-bytecode-constructor-baseline.py',
         'source204-bytecode-constructor-audit.json', 'source204-bytecode-constructor-manifest.json',
         'bytecode-constructor-gnu-fields.el', 'bytecode-constructor-gnu-fields.expected', Path(__file__).name]
names += [f.name for f in p.glob('source204-bytecode-constructor-ordinary-*')]
package('source208-bytecode-constructor-draft', {name: p / name for name in names},
        dict(status='isolated partial constructor repair; validation running', inputs=418,
             supervisor=json.loads((p / 'source208-controls-launch.json').read_text())['pid'],
             negative_baseline=json.loads((p / 'source204-bytecode-constructor-audit.json').read_text()),
             qualification='The patch contains evaluator207 and constructor field validation plus six permanent controls. Bytecode layout and live code-string mutation repairs remain absent. Source206 original failures and this ordinary source204 negative baseline are preserved. No compile/runtime verdict is included in this launch archive.'))
