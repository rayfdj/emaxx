from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/bytecode-closure/emaxx'
manifest = json.loads((p / 'source208-manifest.json').read_text())
unchanged = lambda: all(hashlib.sha256((root / name).read_bytes()).hexdigest() == h for name, h in manifest.items())
steps = [['check-bytecode208.py', '208'], ['static-bytecode208.py', '208'],
         ['test-bytecode-controls208.py', '208', 'gate']]
results = []
for command in steps:
    assert unchanged()
    start = time.monotonic()
    process = subprocess.run([sys.executable, str(p / command[0]), *command[1:]], stdin=subprocess.DEVNULL)
    results.append(dict(command=command, exit_code=process.returncode, elapsed_seconds=time.monotonic()-start,
                        source_unchanged=unchanged()))
    if process.returncode or not unchanged():
        break
with (p / 'source208-controls-result.json').open('x') as f:
    json.dump(dict(steps=results, completed_unix=time.time(), source_unchanged=unchanged(),
                   qualification='Separate partial constructor repair. All six controls run as ordinary assertions; layout and mutation failures are preserved. No complete bytecode or runtime-goal claim.'), f, indent=2)
raise SystemExit(results[-1]['exit_code'] or (0 if unchanged() else 1))
