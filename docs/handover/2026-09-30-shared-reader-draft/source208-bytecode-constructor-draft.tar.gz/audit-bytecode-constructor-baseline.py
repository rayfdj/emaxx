from pathlib import Path
import hashlib
import json

p = Path(__file__).parent.resolve()
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
stem = 'source204-bytecode-constructor-ordinary-bytecode-constructor-gnu-fields'
comparison = json.loads((p / (stem + '-comparison.json')).read_text())
assert not comparison['passed'] and not comparison['exact_match']
outputs = {}
for editor in ['gnu', 'emaxx']:
    result = json.loads((p / (stem + '-' + editor + '.result.json')).read_text())
    command = json.loads((p / (stem + '-' + editor + '.command.json')).read_text())
    assert result == comparison['outcomes'][editor]
    assert result['exit_code'] == 0 and not result['timed_out']
    assert result['source_unchanged'] and result['inputs_unchanged']
    stdout = p / (stem + '-' + editor + '.stdout')
    assert sha(stdout) == result['stdout_sha256']
    assert (p / (stem + '-' + editor + '.stderr')).read_bytes() == b''
    assert all(sha(Path(name)) == digest for name, digest in command['inputs'].items())
    outputs[editor] = stdout.read_text()
expected = (p / 'bytecode-constructor-gnu-fields.expected').read_text().strip()
assert outputs['gnu'] == expected
assert expected.count('(error "Invalid byte-code object")') == 12
assert outputs['emaxx'] == expected.replace('(error "Invalid byte-code object")', 'accepted')
record = dict(status='same-input constructor mismatch confirmed', rejected_by_gnu_but_accepted_by_emaxx=12,
              shared_valid_controls=dict(descriptors=7, closure_lengths=[4, 5, 6, 7, 9], ascii_conversion_accepted=True),
              fixture_sha256=sha(p / 'bytecode-constructor-gnu-fields.el'),
              expected_sha256=sha(p / 'bytecode-constructor-gnu-fields.expected'),
              qualification='Ordinary source204 negative baseline. Both editors exit zero with empty stderr and unchanged recorded inputs. GNU validates field types before allocation, but does not reject a negative fixnum descriptor, dotted/cyclic cons descriptor, extra slots or uninterpreted opcode bytes. ASCII string-make-multibyte returns an accepted string here. No bytecode layout or execution repair is proved.')
with (p / 'source204-bytecode-constructor-audit.json').open('x') as f:
    json.dump(record, f, indent=2)
    f.write('\n')
print(json.dumps(record, indent=2))
