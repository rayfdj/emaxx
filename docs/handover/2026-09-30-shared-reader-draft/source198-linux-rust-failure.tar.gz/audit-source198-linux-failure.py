from pathlib import Path
import hashlib
import json
import re
import sys

p = Path(__file__).parent.resolve()
sys.path.insert(0, str(p.parents[2] / 'tools'))
import grouped_gate

root = p / 'linux-source198-rust-artifacts/rust'
read = lambda file: json.loads(file.read_text())
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
summary = read(root / 'summary.json')
state = read(p / 'source198-linux-rust-final-state.json')
head = '7e45db47438a39e97658bddaceba903e0e41c186'
assert state['status'] == 'completed' and state['conclusion'] == 'failure'
assert state['headSha'] == head and summary['git'] == {'head': head, 'dirty': False}
assert summary['status'] == 'failed' and summary['cargo_stages'] == []
retained = read(root / 'retained-inputs/manifest.json')
assert retained['gate_summary_sha256'] == sha(root / 'summary.json')
for entry in retained['files']:
    file = root / 'retained-inputs' / entry['artifact']
    assert sha(file) == entry['sha256'] and file.stat().st_size == entry['bytes']
assert sha(root / 'retained-inputs/libtest') == summary['test_binary']['sha256']
inventory = grouped_gate.parse_inventory((root / 'inventory.txt').read_text())
assert hashlib.sha256(('\n'.join(inventory) + '\n').encode()).hexdigest() == summary['inventory']['sha256']
groups, _ = grouped_gate.classify_inventory(inventory, 'full')
expected_failure = 'lisp::primitives::tests::suspended_bytecode_retains_operand_and_unwind_roots'
observed = []
for group in ['eval_01', 'eval_02', 'eval_03', 'eval_04', 'eval_05', 'primitives']:
    log = (root / ('repeat-01-' + group + '.log')).read_text()
    # Failed tests quote their fresh child's log in the failure section. Audit
    # that child separately; it must not inflate the parent's test inventory.
    parent = log.split('\nfailures:\n', 1)[0].split('\ntest result:', 1)[0]
    starts = list(re.finditer(r'^test (\S+) \.\.\. ', parent, re.M))
    assert [m[1] for m in starts] == sorted(groups[group]), group
    failures = []
    for index, match in enumerate(starts):
        end = starts[index + 1].start() if index + 1 < len(starts) else len(parent)
        verdict = parent[match.end():end].strip()
        if verdict.endswith('FAILED'):
            failures.append(match[1])
        else:
            assert re.search(r'(?:^|\s)ok$', verdict), (match[1], verdict)
    assert failures == ([expected_failure] if group == 'primitives' else [])
    summaries = re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered out;', log, re.M)
    passed = len(groups[group]) - len(failures)
    assert summaries[-1] == ('FAILED' if failures else 'ok', str(passed), str(len(failures)), '0', str(len(inventory) - len(groups[group])))
    if failures:
        assert len(summaries) == 2
        assert summaries[0] == ('FAILED', '0', '1', '0', str(len(inventory) - 1))
        assert 'left: "((1 t 0) (1 t 1))"' in log
        assert 'right: "((1 t 0) (1 t 0))"' in log
        assert 'tests.rs:25627:5' in log
    else:
        assert len(summaries) == 1
    observed.append({'group': group, 'passed': passed, 'failed': len(failures), 'failures': failures})
unexecuted = ['compat_runtime', 'tty', 'batch', 'lightweight']
assert all(not (root / ('repeat-01-' + name + '.log')).exists() for name in unexecuted)
assert sum(group['passed'] for group in observed) == 2231
record = {'status': 'failed', 'head': head, 'groups': observed, 'raw_passed': 2231,
          'raw_failed': 1, 'child_failure_audited_separately': True,
          'retained_artifact_hashes_verified': True,
          'unexecuted': unexecuted + ['binary Cargo stage', 'integration Cargo stage'],
          'qualification': 'The original suspended-bytecode reclamation assertion fails in Emaxx after the GNU control passes. The nested child summary also makes the strict grouped parser reject the run; this is not merely a reporting failure. No full Linux pass or diagnosis of the retaining root is claimed.'}
with (p / 'source198-linux-rust-failure-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record, indent=2))
