Command input previously used separate decoding paths in the frame, menus, minibuffers and keyboard macros. Those paths could repeat collecting keymap filters, retain copied macro events after Lisp replaced or stopped execution, and lose wrapped events or modifier bits.

Use one incremental reader with live keymaps and rooted event values. Read keyboard macros directly from the Lisp array and public index, preserve nested state through collecting callbacks and errors, and clear active macro execution when a saved image starts in a new process. Coordinate lookup now shares display-motion traversal, and unchanged GNU Lisp owns mouse-link translation.

Validated on a clean build of all 401 recorded runtime/test/build inputs:

- Formatting, compiler, Clippy `-D warnings` and diff checks pass.
- All 536 selected gate tests and 536 release tests pass, including the original GC survival/reclamation contracts.
- All 26 ordinary same-input GNU comparisons pass.
- All 17 selected terminal scenarios and 34 screen comparisons match.

Complete validation is running: [Linux Rust](https://github.com/rayfdj/emaxx/actions/runs/36741202335), [Linux frozen comparison](https://github.com/rayfdj/emaxx/actions/runs/36741207263), and the complete local macOS Rust and terminal inventories. Keep this PR in draft until those results are audited.

The portable handover retains the earlier failures, including a stale ordinary executable caused by preserved source timestamps. The copier is corrected; the clean rebuild uses a different executable and passes the unchanged failing fixture. GNU on macOS matches source/native ABI but is not the frozen Darwin executable.

This is a checkpoint toward the full runtime goal. Symbol authority, physical allocation accounting, broader reader contracts, final audit and locked performance parity remain open. The separately packaged source197 saved-state optimization is not applied to this PR's runtime.
