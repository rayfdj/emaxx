from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected', '.md'}
release = read('source231-release-audit.json')
ordinary = read('source231-ordinary-audit.json')
assert [g['passed'] for g in release['groups']] == [31, 937]
assert len(ordinary['fixtures']) == 54
files = {f.name: f for f in p.iterdir() if f.is_file() and f.suffix in allowed
         and f.name.startswith('source231-') and not f.name.startswith('source231-full-gate')}
names = ['audit-source231-release.py', 'audit-source231-ordinary.py', 'audit-source231-patches.py',
         'audit-shared-reader196-fresh-selected.py', 'run-string-validation231.py', 'check-string230.py',
         'static-string230.py', 'test-string-controls230.py', 'test-string-broad230.py',
         'run-source231-release.py', 'run-source231-build-and-ordinary.py', 'build-string230.py',
         'run-source231-ordinary.py', 'compare-source230-fixtures.py', 'freeze-string-ops-candidate.py',
         'source207-ordinary-comparisons-command.json', 'source230-gate-broad-command.json',
         Path(__file__).name]
files.update({name: p / name for name in names})
package('source231-release-and-ordinary-validation', files,
        dict(release=release, ordinary=ordinary,
             qualification='Fresh source231 release and ordinary comparisons pass with audited raw evidence and retained artifact identities. The same candidate has 31 audited focused gate passes. Its complete macOS run is separately active. No source231 complete terminal or Linux pass, no pinned Darwin certification and no performance claim. Earlier source230 focused failure remains preserved.'))
terminal = read('source229-terminal-failure-audit.json')
assert terminal['matching_comparisons'] == 353 and terminal['divergent_comparisons'] == 7
names = ['source229-terminal-failure-audit.json', 'audit-source229-terminal-failure.py',
         'source229-full-ttydiff-command.json', 'source229-full-ttydiff-result.json',
         'source229-full-ttydiff.log', 'run-source229-full-tty.py', 'source229-manifest.json',
         'source229-ordinary-artifacts.json', Path(__file__).name]
files = {name: p / name for name in names}
files.update({f.name: f for f in p.iterdir() if f.is_file() and f.suffix in allowed
              and (f.name.startswith('source229-quote-state-') or f.name == 'diagnose-source229-quote-state.py')})
package('source229-terminal-failure', files, terminal)
