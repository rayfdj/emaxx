from pathlib import Path
import hashlib
import json
import re
import runpy

p = Path(__file__).parent.resolve()
read = lambda name: json.loads((p / name).read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
command = read('source229-full-ttydiff-command.json')
result = read('source229-full-ttydiff-result.json')
root = Path(command['working_directory'])
manifest = read(command['source_manifest'])
assert len(manifest) == 432 and all(sha(root / name) == digest for name, digest in manifest.items())
assert len(command['inputs']) == 8
assert all(sha(Path(name)) == digest for name, digest in command['inputs'].items())
assert result['exit_code'] == 1 and result['source_unchanged'] and result['inputs_unchanged']
assert not result['complete_start_inventory']
raw = (p / 'source229-full-ttydiff.log').read_text()
module = runpy.run_path(str(root / 'tools/ttydiff.py'), run_name='inventory_only')
scenarios = module['select_scenarios']([])
assert [s[0] for s in scenarios] == command['inventory']
assert len(scenarios) == result['expected_scenarios'] == 226
expected = {}
for scenario in scenarios:
    name, keys = scenario[0], scenario[2]
    labels = []
    final_label, final_filesystem = name, False
    for index, item in enumerate(keys):
        action = module['normalize_action'](item, index)
        if not action.checkpoint:
            continue
        label = f'{name}::{index + 1}:{action.name}'
        if index + 1 == len(keys):
            final_label, final_filesystem = label, action.filesystem
        else:
            labels.append(label)
            if action.filesystem:
                labels.append(label + ' filesystem')
    labels.append(final_label)
    if final_filesystem:
        labels.append(final_label + ' filesystem')
    expected[name] = labels
assert sum(map(len, expected.values())) == 686
starts = list(re.finditer(r'^RUN \[(\d+)/(\d+)\] (.+)$', raw, re.M))
assert len(starts) == result['started_scenarios'] == 172
assert [(m[1], m[2], m[3]) for m in starts] == [
    (str(i + 1), '226', s[0]) for i, s in enumerate(scenarios[:172])]
matches, failures, partial, successful = [], [], [], []
for index, match in enumerate(starts):
    name = match[3]
    stop = starts[index + 1].start() if index + 1 < len(starts) else len(raw)
    segment = raw[match.end():stop]
    verdicts = re.findall(r'^(MATCH|DIVERGE) \[(.+)\]: (.+)$', segment, re.M)
    labels = [v[1] for v in verdicts]
    assert labels == expected[name][:len(labels)], name
    if index == 171:
        assert name == 'dired-batch-delete-files' and not verdicts
        assert 'gnu.wait_for_screen_text(' in segment
        assert "RuntimeError: editor did not display startup target 'ttydiff-dired-ba'" in segment
        assert '*scratch*' in segment
        partial.append(dict(scenario=name, missing=expected[name], reason='GNU startup readiness failure before comparison'))
        continue
    assert verdicts
    for kind, label, detail in verdicts:
        if kind == 'MATCH':
            assert re.fullmatch(r'text area identical \(\d+ rows\)|isolated fixture trees identical', detail)
            matches.append(label)
        else:
            assert re.fullmatch(r'\d+ terminal difference\(s\)', detail)
            failures.append(label)
    if verdicts[-1][0] == 'DIVERGE':
        assert all(v[0] == 'MATCH' for v in verdicts[:-1])
        partial.append(dict(scenario=name, missing=expected[name][len(labels):], reason='returned after divergence'))
    else:
        assert all(v[0] == 'MATCH' for v in verdicts) and labels == expected[name]
        successful.append(name)
assert len(matches) == 353 and len(failures) == 7 and len(successful) == 164
assert failures == [
    'hscroll-disabled',
    'help-key-then-quit::1:describe-forward-char-key',
    'help-function-then-quit::1:describe-forward-word',
    'buffer-switch-scratch::1:switch-to-scratch',
    'minibuffer-edit-abort::9:execute-command',
    'kill-buffer-confirm::4:kill-without-saving',
    'kill-buffer-cancel-save::9:kill-saved-buffer',
]
assert 'PASS: all scenarios match' not in raw
unstarted = [s[0] for s in scenarios[172:]]
assert len(unstarted) == 54
unexecuted = sum(len(item['missing']) for item in partial) + sum(len(expected[name]) for name in unstarted)
assert len(matches) + len(failures) + unexecuted == 686
record = dict(status='failed and incomplete terminal comparison', goal_complete=False,
              inputs_verified=len(manifest), execution_inputs_verified=len(command['inputs']),
              scheduled_scenarios=226, started_scenarios=172, fully_matching_scenarios=len(successful),
              matching_comparisons=len(matches), divergent_comparisons=len(failures),
              matching_screen_comparisons=sum(not label.endswith(' filesystem') for label in matches),
              matching_filesystem_comparisons=sum(label.endswith(' filesystem') for label in matches),
              divergent_labels=failures, partial_scenarios=partial, unstarted_scenarios=unstarted,
              unexecuted_comparisons=unexecuted, log_sha256=sha(p / 'source229-full-ttydiff.log'),
              ordinary_artifacts=read('source229-ordinary-artifacts.json'),
              qualification='All seven observed divergences involve quote display, including the echo area and wrap/cursor consequences. The final traceback is GNU startup readiness failure, not an Emaxx crash. No timeouts, selectors or comparison strictness changed. Every observed raw verdict is checked against its unchanged scenario prefix; omitted comparisons and all 54 unstarted scenarios remain unexecuted. This source/ABI-matched GNU is not the frozen Darwin executable. No full terminal, pinned-platform or performance pass.')
with (p / 'source229-terminal-failure-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: record[key] for key in ['status', 'inputs_verified', 'fully_matching_scenarios', 'matching_comparisons', 'divergent_comparisons', 'unexecuted_comparisons', 'divergent_labels']}, indent=2))
