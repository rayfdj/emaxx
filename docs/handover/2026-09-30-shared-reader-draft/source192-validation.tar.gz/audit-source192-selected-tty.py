from pathlib import Path
import hashlib,json,re,runpy
p=Path(__file__).parent.resolve()
tag="source192"
read=lambda suffix:json.loads((p/(tag+suffix)).read_text())
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
command=read("-selected-tty-command.json")
result=read("-selected-tty-result.json")
assert result["exit_code"]==0 and result["source_unchanged"] and result["inputs_unchanged"]
assert all(sha(f)==h for f,h in command["inputs"].items())
root=Path(command["working_directory"])
manifest=read("-manifest.json")
assert all(sha(root/f)==h for f,h in manifest.items())
module=runpy.run_path(str(root/"tools/ttydiff.py"))
entries=module["select_scenarios"](command["inventory"])
expected=[]
for entry in entries:
    name,_,keys,*_=entry
    if any(isinstance(key,module["Action"]) for key in keys):
        expected.extend(f"{name}::{i}:{key.name}" for i,key in enumerate(keys,1) if isinstance(key,module["Action"]) and key.checkpoint)
    else:
        expected.append(name)
log=(p/(tag+"-selected-tty.log")).read_text()
runs=re.findall(r"^RUN \[(\d+)/(\d+)\] (.+)$",log,re.M)
assert runs==[(str(i),str(len(entries)),entry[0]) for i,entry in enumerate(entries,1)]
actual=re.findall(r"^MATCH \[(.+)\]: text area identical \(22 rows\)$",log,re.M)
assert actual==expected,(actual,expected)
assert log.endswith("PASS: all scenarios match\n")
assert not re.search(r"^(FAIL|ERROR|SKIP|DIFF)",log,re.M)
with (p/(tag+"-selected-tty-evidence-audit.json")).open("x") as f:
    json.dump({"scenario_count":len(entries),"screen_comparisons":len(expected),"scenario_inventory":[entry[0] for entry in entries],"checkpoint_inventory":expected,"raw_inventory_verified":True,"source_and_inputs_verified":True,"qualification":"Selected screens only. Source/ABI-matched GNU is not the frozen Darwin executable; not performance evidence."},f,indent=2)
print(len(entries),"scenarios;",len(expected),"screen comparisons verified")
