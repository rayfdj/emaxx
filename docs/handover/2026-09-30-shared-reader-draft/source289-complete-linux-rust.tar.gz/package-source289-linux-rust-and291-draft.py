from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile,shutil
p=Path(__file__).parent.resolve();out=p/'source290-publication-stage';out.mkdir(exist_ok=True)
sha=lambda data:hashlib.sha256(data).hexdigest();read=lambda n:json.loads((p/n).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
allowed={'.json','.log','.txt','.py','.patch','.stdout','.stderr','.el','.expected','.h','.apparmor'}
r=read('source289-linux-rust-verification.json');assert r['total_passed']==3145 and r['source_commit']=='ae1fcb0f8cdaf9e8931eaa67e39cee783cc7a808'
files={};excluded=[]
for f in (p/'source289-linux-rust-artifacts').rglob('*'):
 if not f.is_file():continue
 name=str(f.relative_to(p))
 if f.suffix in allowed or f.name=='Makefile':files[name]=f
 else:excluded.append(dict(path=name,bytes=f.stat().st_size,sha256=sha(f.read_bytes())))
for f in p.iterdir():
 if f.is_file() and f.suffix in allowed and f.name.startswith('source289-linux-rust-'):files[f.name]=f
for n in ['audit-source289-linux-rust-names.py','verify-source289-linux-rust.py','source289-manifest.json','package-source196-failure-and197-results.py',Path(__file__).name]:files[n]=p/n
package('source289-complete-linux-rust',files,dict(status='closed full Linux Rust validation',audit=r,excluded_binaries=excluded,qualification='All3044 library names verified:3042 pass and two existing ignores. Binary61 and integration42 passes yield3145 total. Native artifact identity and all four retained inputs verify. Earlier GNU census failures and source276 Emaxx census failure remain unexplained; a passing current run does not erase them. Source289 frozen Linux is still separate, and complete macOS is unstarted. This does not certify source290 or291.',goal_complete=False))
files={n:p/n for n in ['source291-manifest.json','source291-draft.patch','source291-portable-incremental.patch','source291-portable-complete.patch','source291-portable-draft-audit.json','source291-preparation.json','run-source291-validation.py','replay-source291.py','finish-source291-selected.py','audit-source291-selected.py','compare-source291-generated-loaded.py','compare-vm-dispatch-fixtures.py','source290-manifest.json','source290-application-decision.json','source290-selected-closed-audit.json','package-source196-failure-and197-results.py',Path(__file__).name]}
snapshot=p/'source291-draft-validation-snapshot.json';snapshot.write_text(json.dumps(read('source291-validation-state.json'),indent=2));files[snapshot.name]=snapshot
package('source291-unfinished-inlining-draft',files,dict(status='portable unapplied unfinished source291 draft',portable=read('source291-portable-draft-audit.json'),validation_snapshot=read(snapshot.name),qualification='One annotation differs from held source290: compiler-chosen rather than forced Integer inlining. All528 inputs and modes replay exactly fromfc7db1dc and main21d20f0e. This is a launch snapshot; selected validation is still running, comparisons and timing pending. Do not treat this draft or snapshot as a passed runtime. Inspect later local receipts. Source290 and all slower results remain unchanged.',goal_complete=False))
