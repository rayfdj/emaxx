from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p/name).read_text())
node = next(node for node in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(node,ast.FunctionDef) and node.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
allowed = {'.json','.log','.txt','.py','.patch','.stdout','.stderr','.el','.expected'}
mac = read('source248-macos-rust-complete-audit.json')
linux = read('source248-linux-rust-complete-audit.json')
frozen = read('source248-linux-frozen-raw-integrity-audit.json')
terminal = read('source248-terminal-failure-audit.json')
assert mac['total_passed']==3098 and linux['total_passed']==3110
assert frozen['outcomes']==7928 and terminal['matching_comparisons']==295

def collect(patterns, directories):
    files = {str(path.relative_to(p)):path for pattern in patterns for path in p.glob(pattern)
             if path.is_file() and path.suffix in allowed and 'full-ttydiff-retry' not in path.name}
    excluded = []
    for directory in directories:
        for path in (p/directory).rglob('*'):
            if not path.is_file():
                continue
            if path.name in ['libtest','emacs'] or path.suffix=='.pdmp':
                excluded.append(dict(path=str(path.relative_to(p)),sha256=sha(path.read_bytes()),bytes=path.stat().st_size))
            else:
                files[str(path.relative_to(p))] = path
    return files,excluded

patterns = ['source248-macos-*','source248-full-gate-*','source248-full-gate.log',
            'source248-full-ttydiff*','source248-terminal-failure-audit.json',
            'source248-recursive-minibuffer-replay*','source248-linux-rust*','source248-linux-frozen*',
            'source248-manifest.json','source248-freeze.json','source248-ordinary-artifacts.json',
            'audit-source248-macos-names.py','verify-source248-macos-rust.py',
            'download-source248-linux-rust.py','audit-source248-linux-rust-names.py',
            'verify-source248-linux-rust.py','download-source248-linux-frozen.py',
            'audit-source248-frozen.py','verify-complete-frozen-receipts.py',
            'audit-source248-terminal-failure.py','run-source248-recursive-minibuffer-replay.py',
            'run-source248-full-gate.py','run-source248-full-tty.py','run-source248-full-tty-retry.py',
            Path(__file__).name]
files,excluded = collect(patterns,['full-gate-source248','source248-linux-rust-artifacts','source248-linux-frozen-artifacts'])
for name in ['source248-full-ttydiff-retry-launch.json','source248-full-ttydiff-retry-command.json']:
    files[name] = p/name
frozen_members = [name for name in files if name.startswith('source248-linux-frozen-artifacts/')]
assert len(frozen_members)==5202
assert sum(name.endswith('.loaded') for name in frozen_members)==1038
assert len([row for row in excluded if row['path'].startswith('source248-linux-frozen-artifacts/')])==2
package('source248-complete-rust-frozen-and-terminal-failure',files,
        dict(macos=mac,linux=linux,frozen=frozen,terminal=terminal,
             selected_terminal_replay=read('source248-recursive-minibuffer-replay-result.json'),
             terminal_retry=read('source248-full-ttydiff-retry-launch.json'),
             binaries_retained_locally=excluded,
             qualification='Complete source248 macOS3098/Linux3110 Rust passes with two existing ignores and native identity, and complete pinned Linux frozen519/7928/1038 pass, are audited against raw names, inventories, outcomes and hashes. Every downloaded frozen member except the two locally retained GNU binary/dump files is packaged, including all1038 load markers. Initial terminal run remains failed at GNU startup on scenario162 after161 complete scenarios/295 comparisons;391 comparisons never execute. Unchanged selected replay passes seven comparisons. Full terminal retry14540 is running after local Rust finished; its active logs are excluded. Earlier GNU census/Eglot causes, pinned Darwin, remaining correctness/architecture/accounting/ownership/audit and locked performance goal remain open.'))

patterns = ['source248-linux-gnu-trace-*','source248-general-translation-*',
            'source174-general-translation-*','source207-general-translation-*',
            'coding-translation-history*-audit.json','coding-live-conversion-translation.el',
            'probe-source248-general-translation.py','probe-coding-translation-history.py',
            'probe-coding-translation-history-original-location.py',
            'source174-ordinary-artifacts.json','source207-ordinary-artifacts.json',
            'download-source248-linux-gnu-trace.py','audit-source248-gnu-trace.py',
            'dispatch-source248-gnu-trace.py',Path(__file__).name]
files,excluded = collect(patterns,['source248-linux-gnu-trace-artifacts'])
assert sum(name.startswith('source248-linux-gnu-trace-artifacts/') for name in files)==53
trace = read('source248-linux-gnu-trace-audit.json')
assert trace['ordinary_matches']==20
history = read('coding-translation-history-original-location-audit.json')
assert all(row['matches_source248'] and not row['matches_gnu'] and row['exit_code']==0 for row in history['records'])
package('source248-gnu-trace-and-conversion-gap',files,
        dict(trace=trace,conversion=read('source248-general-translation-negative-audit.json'),
             history=history,binaries_retained_locally=excluded,
             qualification='Corrected GNU observer has20 ordinary matches, two successful GDB runs with exact argument vectors and16 decoded marked inventories equal to GNU slot returns. No live-object drop or original -7/-9 variation is reproduced; its cause remains open. A separate ordinary fixture proves current encode/decode operations ignore live translation tables, their mutation and standard-table composition. Original-location source174/main and source207 retained binary/image pairs produce the identical wrong output, so this specific gap predates the later migrations. The initial source174 relocation failure is retained and does not count as a runtime result. No runtime repair or full-goal completion is claimed.'))
