from pathlib import Path
import hashlib, json, os, re, runpy, subprocess, time

p = Path(__file__).parent.resolve()
read = lambda name: json.loads((p/name).read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
prior = read('source248-full-ttydiff-command.json')
assert read('source248-terminal-failure-audit.json')['fully_matching_scenarios'] == 161
assert read('source248-macos-rust-complete-audit.json')['status'] == 'passed'
root = Path(prior['working_directory'])
source = read('source248-manifest.json')
inputs = dict(prior['inputs'])
inputs[str(Path(__file__).resolve())] = sha(Path(__file__))
unchanged = lambda: all(sha(root/name)==digest for name,digest in source.items())
assert len(source)==472 and unchanged()
assert all(sha(Path(name))==digest for name,digest in inputs.items())
module = runpy.run_path(str(root/'tools/ttydiff.py'),run_name='inventory_only')
selection = ['recursive-minibuffer']
assert [row[0] for row in module['select_scenarios'](selection)] == selection
command = prior['command'] + selection
prefix = 'source248-recursive-minibuffer-replay'
with (p/(prefix+'-command.json')).open('x') as stream:
    json.dump(dict(command=command, working_directory=str(root), inputs=inputs,
                   source_manifest='source248-manifest.json',
                   environment_overrides=prior['environment_overrides'],
                   qualification='Selected replay of the unchanged scenario that stopped at GNU startup in the full run. Complete macOS Rust has finished; original timeout/actions/comparison and both executable/image pairs are unchanged. This does not repair or certify the failed full terminal run.'),stream,indent=2)
start = time.monotonic()
with (p/(prefix+'.log')).open('xb') as log:
    result = subprocess.run(command,cwd=root,env={**os.environ,**prior['environment_overrides']},
                            stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
raw = (p/(prefix+'.log')).read_text()
record = dict(exit_code=result.returncode,elapsed_seconds=time.monotonic()-start,
               source_unchanged=unchanged(),inputs_unchanged=all(sha(Path(name))==digest for name,digest in inputs.items()),
               matches=re.findall(r'^MATCH \[(.+)\]: (.+)$',raw,re.M),
               divergences=re.findall(r'^DIVERGE \[(.+)\]: (.+)$',raw,re.M),
               summary=raw.splitlines()[-1:],log_sha256=sha(p/(prefix+'.log')))
with (p/(prefix+'-result.json')).open('x') as stream:
    json.dump(record,stream,indent=2)
print(json.dumps(record,indent=2))
raise SystemExit(result.returncode or (0 if record['source_unchanged'] and record['inputs_unchanged'] and 'PASS: all scenarios match' in raw else 2))
