from pathlib import Path
import hashlib
import json
import re
import runpy

p = Path(__file__).parent.resolve()
read = lambda name: json.loads((p / name).read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
command = read('source248-full-ttydiff-command.json')
result = read('source248-full-ttydiff-result.json')
root = Path(command['working_directory'])
manifest = read(command['source_manifest'])
assert len(manifest) == 472 and all(sha(root / name) == digest for name, digest in manifest.items())
assert len(command['inputs']) == 8
assert all(sha(Path(name)) == digest for name, digest in command['inputs'].items())
assert result['exit_code'] == 1 and result['source_unchanged'] and result['inputs_unchanged']
assert not result['complete_start_inventory']
raw = (p / 'source248-full-ttydiff.log').read_text()
module = runpy.run_path(str(root / 'tools/ttydiff.py'), run_name='inventory_only')
scenarios = module['select_scenarios']([])
assert [s[0] for s in scenarios] == command['inventory']
assert len(scenarios) == result['expected_scenarios'] == 226
expected = {}
for scenario in scenarios:
    name, keys = scenario[0], scenario[2]
    labels = []
    final_label, final_filesystem = name, False
    for index, item in enumerate(keys):
        action = module['normalize_action'](item, index)
        if not action.checkpoint:
            continue
        label = f'{name}::{index + 1}:{action.name}'
        if index + 1 == len(keys):
            final_label, final_filesystem = label, action.filesystem
        else:
            labels.append(label)
            if action.filesystem:
                labels.append(label + ' filesystem')
    labels.append(final_label)
    if final_filesystem:
        labels.append(final_label + ' filesystem')
    expected[name] = labels
assert sum(map(len, expected.values())) == 686
starts = list(re.finditer(r'^RUN \[(\d+)/(\d+)\] (.+)$', raw, re.M))
assert len(starts) == result['started_scenarios'] == 162
assert [(m[1], m[2], m[3]) for m in starts] == [
    (str(i + 1), '226', s[0]) for i, s in enumerate(scenarios[:162])]
matches, failures, partial, successful = [], [], [], []
for index, match in enumerate(starts):
    name = match[3]
    stop = starts[index + 1].start() if index + 1 < len(starts) else len(raw)
    segment = raw[match.end():stop]
    verdicts = re.findall(r'^(MATCH|DIVERGE) \[(.+)\]: (.+)$', segment, re.M)
    labels = [v[1] for v in verdicts]
    assert labels == expected[name][:len(labels)], name
    if index == 161:
        assert name == 'recursive-minibuffer' and not verdicts
        assert 'gnu.wait_for_screen_text(' in segment
        assert "RuntimeError: editor did not display startup target 'ttydiff-recursiv'" in segment
        assert '*scratch*' in segment
        partial.append(dict(scenario=name, missing=expected[name], reason='GNU startup readiness failure before comparison'))
        continue
    assert verdicts
    for kind, label, detail in verdicts:
        if kind == 'MATCH':
            assert re.fullmatch(r'text area identical \(\d+ rows\)|isolated fixture trees identical', detail)
            matches.append(label)
        else:
            assert re.fullmatch(r'\d+ terminal difference\(s\)', detail)
            failures.append(label)
    if verdicts[-1][0] == 'DIVERGE':
        assert all(v[0] == 'MATCH' for v in verdicts[:-1])
        partial.append(dict(scenario=name, missing=expected[name][len(labels):], reason='returned after divergence'))
    else:
        assert all(v[0] == 'MATCH' for v in verdicts) and labels == expected[name]
        successful.append(name)
assert len(matches) == 295 and len(failures) == 0 and len(successful) == 161
assert failures == []
assert 'PASS: all scenarios match' not in raw
unstarted = [s[0] for s in scenarios[162:]]
assert len(unstarted) == 64
unexecuted = sum(len(item['missing']) for item in partial) + sum(len(expected[name]) for name in unstarted)
assert len(matches) + len(failures) + unexecuted == 686
record = dict(status='failed and incomplete terminal comparison', goal_complete=False,
              inputs_verified=len(manifest), execution_inputs_verified=len(command['inputs']),
              scheduled_scenarios=226, started_scenarios=162, fully_matching_scenarios=len(successful),
              matching_comparisons=len(matches), divergent_comparisons=len(failures),
              matching_screen_comparisons=sum(not label.endswith(' filesystem') for label in matches),
              matching_filesystem_comparisons=sum(label.endswith(' filesystem') for label in matches),
              divergent_labels=failures, partial_scenarios=partial, unstarted_scenarios=unstarted,
              unexecuted_comparisons=unexecuted, log_sha256=sha(p / 'source248-full-ttydiff.log'),
              ordinary_artifacts=read('source248-ordinary-artifacts.json'),
              qualification='GNU startup readiness fails on scenario 162 before a comparison. All 161 earlier scenarios match completely; 64 later scenarios never start. Every verdict and all eight execution inputs are verified, with unchanged selectors, actions, timeouts and comparison rules. This source/ABI-matched GNU is not the frozen Darwin executable. No complete terminal or performance pass.')
with (p / 'source248-terminal-failure-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: record[key] for key in ['status', 'inputs_verified', 'fully_matching_scenarios', 'matching_comparisons', 'divergent_comparisons', 'unexecuted_comparisons', 'divergent_labels']}, indent=2))
