from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
out = p.parents[2] / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
read = lambda name: json.loads((p / name).read_text())
audit = read('source240-macos-rust-complete-audit.json')
names = read('source240-macos-rust-name-audit.json')
assert audit['status'] == names['status'] == 'passed'
assert audit['total_passed'] == 3089 and audit['library_ignored'] == 2
assert names['raw_names_verified'] == 2992 and audit['retained_files_verified'] == 4
assert sha((p / 'full-gate-source240/summary.json').read_bytes()) == audit['summary_sha256']
allowed = {'.json', '.log', '.txt', '.py', '.patch'}
patterns = ['source240-full-gate*', 'source240-macos-*', 'source240-manifest.json',
            'source240-*.patch', 'source240-gate-inventory.txt',
            'audit-source240-macos-names.py', 'verify-source240-macos-rust.py',
            'run-source240-full-gate.py', 'launch-source240-complete.py', Path(__file__).name]
files = {str(file.relative_to(p)): file for pattern in patterns for file in p.glob(pattern)
         if file.is_file() and file.suffix in allowed}
files.update({str(file.relative_to(p)): file for file in (p / 'full-gate-source240').rglob('*')
              if file.is_file() and file.suffix in allowed})
package('source240-complete-macos', files,
        dict(macos=audit, raw_names=names,
             qualification='Source240 complete macOS Rust validation is closed: 3,089 passes, two existing ignores, native artifact identity and four retained executable/image hashes verified. Supervisor43216 has exited. Source240 still fails the separately preserved new-file coding and prompt probes. The file-coding repair is a separate draft. Root runtime is source238; no Linux, frozen, terminal or performance certification for source240 is inferred.'))
