from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve();out=p.parents[2]/'docs/handover/2026-09-30-shared-reader-draft';sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda n:json.loads((p/n).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package');exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
a=read('source304-macos-frozen-audit.json');assert a['matching_outcomes']==7915 and a['mismatching_outcomes']==6 and a['successful_processes']==1038
r=Path(a['raw_root']);assert sha((r/'summary.json').read_bytes())==a['summary_sha256'];allowed={'.json','.log','.stdout','.stderr','.loaded','.txt','.py','.patch'}
files={'frozen/'+str(f.relative_to(r)):f for f in r.rglob('*') if f.is_file() and f.suffix in allowed}
for n in ['source304-macos-frozen-audit.json','source304-full-frozen-result.json','source304-full-frozen-command.json','source304-full-frozen.log','source304-full-frozen-subject-inputs.json','source304-manifest.json','source304-full-checkout.json','source304-full-launch.json','audit-source304-macos-frozen.py','package-source196-failure-and197-results.py',Path(__file__).name]:files[n]=p/n
package('source304-macos-frozen-results',files,dict(status=a['status'],verified_files=519,matching_outcomes=7915,mismatching_outcomes=6,verified_outcomes=7921,successful_processes=1038,runner_summaries=a['runner_summaries'],qualification=a['qualification'],goal_complete=False))
