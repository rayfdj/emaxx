from pathlib import Path
import hashlib, json, subprocess, tarfile

p=Path(__file__).parent.resolve()
root=p.parents[2]
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def output(command):return subprocess.check_output(command,cwd=root,text=True).strip()
def save(name,value):
    with (p/name).open('x') as f:json.dump(value,f,indent=2)
assert output(['git','branch','--show-current'])=='runtime-char-tables'
assert output(['git','rev-parse','HEAD'])=='1d187ba63e485ec4ecfe0227c148287a230f8f09'
assert output(['git','remote','get-url','origin'])=='https://github.com/rayfdj/emaxx.git'
assert output(['git','diff','--cached','--name-only'])==''
manifest=json.loads((p/'source249-manifest.json').read_text())
assert len(manifest)==476 and all(sha(root/n)==h for n,h in manifest.items())
audit=json.loads((p/'source249-selected-audit.json').read_text())
assert audit['status']=='passed' and audit['ordinary_comparisons']==15
assert all(row['focused_passes']==172 and row['affected_passes']==955 for row in audit['profiles'].values())
assert json.loads((root/'compat/oracle.lock.json').read_text())['emacs_binary_sha256']=='591acf7b5da3582dca93367b6a69935dbff9c69a9310f05a1927fa230b428f8d'
paths=['HANDOVER.md','docs/oracle-build-contract.md','docs/runtime-representation-progress.md',
       'docs/runtime-representation-correctness-recovery-draft.md','src/lisp/primitives/coding.rs',
       'src/lisp/primitives/dispatch/search_coding.rs','src/lisp/primitives/tests.rs',
       'tests/fixtures/coding-post-read-character-count.el','tests/fixtures/coding-post-read-character-count.expected',
       'tests/fixtures/coding-post-read-fast-path.el','tests/fixtures/coding-post-read-fast-path.expected',
       'docs/handover/2026-09-30-shared-reader-draft/source248-current-requirement-review.json',
       'docs/handover/2026-09-30-shared-reader-draft/source249-root-application.json']
archives=[]
for stem in ['source248-complete-terminal-retry','source249-selected-and-setup','gnu-macos-rebuild-20261001']:
    base='docs/handover/2026-09-30-shared-reader-draft/'+stem
    record=json.loads((root/(base+'-manifest.json')).read_text())
    archive=root/(base+'.tar.gz')
    assert record['goal_complete'] is False and sha(archive)==record['archive']['sha256']
    assert archive.stat().st_size==record['archive']['bytes']
    with tarfile.open(archive) as contents:
        assert contents.getnames()==[item['path'] for item in record['files']]
        for item in record['files']:
            data=contents.extractfile(item['path']).read()
            assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
    archives.append(record['archive'])
    paths.extend([base+'-manifest.json',base+'.tar.gz'])
subprocess.run(['git','diff','--check'],cwd=root,check=True)
subprocess.run(['git','add','--',*paths],cwd=root,check=True)
assert set(output(['git','diff','--cached','--name-only']).splitlines())==set(paths)
subprocess.run(['git','diff','--cached','--check'],cwd=root,check=True)
subprocess.run(['git','-c','user.name=Ray','-c','user.email=26018378+rayfdj@users.noreply.github.com',
                'commit','-m','Match GNU post-read counts and ASCII decoding returns'],cwd=root,check=True)
head=output(['git','rev-parse','HEAD'])
assert output(['git','status','--porcelain'])==''
save('source249-applied-commit.json',dict(commit=head,runtime_source='source249',root_inputs=476,
                                       paths=paths,archives=archives,goal_complete=False))
command=['git','push','origin','HEAD:refs/heads/runtime-char-tables']
result=subprocess.run(command,cwd=root,stdin=subprocess.DEVNULL,capture_output=True,text=True)
save('source249-applied-push.json',dict(command=command,commit=head,exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr))
result.check_returncode()
assert output(['git','ls-remote','--heads','origin','refs/heads/runtime-char-tables']).split()[0]==head
print(json.dumps(dict(status='validated repair and rebuilt GNU evidence pushed',commit=head,runtime_source='source249',goal_complete=False)))
