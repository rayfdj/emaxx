from pathlib import Path
import ast, datetime, gzip, hashlib, io, json, subprocess, tarfile

p=Path(__file__).parent.resolve()
root=p.parents[2]
out=root/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda name:json.loads((p/name).read_text())
head=read('source249-applied-commit.json')['commit']
assert read('source249-applied-push.json')['exit_code']==0
manifest=read('source249-manifest.json')
assert len(manifest)==476 and all(sha((root/n).read_bytes())==h for n,h in manifest.items())
runs={}
for validation in ['rust','frozen']:
    run_id=read('source249-linux-'+validation+'-launch.json')['run_id']
    state=json.loads(subprocess.check_output(['gh','run','view',str(run_id),'--repo','rayfdj/emaxx','--json','status,conclusion,headSha,url'],cwd=root,text=True))
    assert state['headSha']==head
    runs[validation]=state
record=dict(observed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),runtime_commit=head,inputs_verified=476,
            linux=runs,mac_frozen_launch=read('rebuilt-oracle-frozen-empty-target-launch.json'),
            mac_rust_launch=read('source249-rebuilt-full-gate-launch.json'),
            mac_rust_state=read('source249-rebuilt-full-gate-queue-state.json'),
            goal_complete=False,qualification='Publication and launch snapshot only. Linux run states and the queued macOS gate are not passing results. The rebuilt-GNU comparison uses isolated candidate 1c0898fc with the same 476 runtime inputs; original Darwin pin remains on the task branch. Full source249 terminal validation, final audit and the architecture/performance requirements remain open.')
with (p/'source249-publication-state.json').open('x') as f:json.dump(record,f,indent=2)
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
names=['source249-applied-commit.json','source249-applied-push.json','publish-source249-applied.py','dispatch-source249-linux.py',
       'source249-linux-rust-dispatch.json','source249-linux-rust-launch.json','source249-linux-frozen-dispatch.json','source249-linux-frozen-launch.json',
       'source249-pr-body.md','source249-pr-payload.json','source249-pr-update.json','source249-pr-verified.json','update-source249-pr.py',
       'source249-rebuilt-full-gate-launch.json','queue-source249-rebuilt-full-gate.py','source249-publication-state.json',
       'source249-manifest.json','source249-root-application.json','rebuilt-oracle-frozen-empty-target-launch.json',
       'rebuilt-oracle-frozen-empty-target-command.json','rebuilt-oracle-frozen-empty-target-setup.json',
       'retry-rebuilt-oracle-frozen-empty-target.py','package-source196-failure-and197-results.py',Path(__file__).name]
package('source249-publication-and-launches',{name:p/name for name in names},record)
