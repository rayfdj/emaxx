This draft shares cons, vector and closure fields across the interpreter, bytecode VM and native execution, adds canonical Emacs byte storage for mutable strings, and executes bytecode from its live code string. Reader, completion, substring, interactive-command, display and file-writing paths use those fields; unchanged GNU Lisp retains file-writing policy.

Current runtime is `99e61fca563a8c2f597b20fc56a539cdd1c2f575` (source249), with 476 frozen runtime/test inputs. The latest repair follows `coding.c:decode_coding_object` and `code_convert_string`: post-read hooks receive decoded character counts, and ASCII string decoding returns before the hook, preserving NOCOPY identity while dropping properties from a copied result. The original negative fixtures retain their exact GNU outputs.

Audited source249 validation:

- Zero-warning formatting/check/Clippy/diff checks; 172 focused passes and two existing TTY ignores, plus 955 affected passes, in each of the gate and release profiles.
- Fifteen ordinary GNU comparisons match. Every prior selected control remains, with exactly two new post-read tests. The first selected run's ten missing-sibling-GNU setup failures are retained; restoring only that checkout link makes the same executable and full selection pass.
- [Complete Linux Rust](https://github.com/rayfdj/emaxx/actions/runs/36879095484) and [complete Linux frozen](https://github.com/rayfdj/emaxx/actions/runs/36879103495) are dispatched on the exact commit above. Their results are pending.
- Complete macOS frozen comparison is running on isolated candidate `1c0898fc`, whose runtime inputs match source249. The complete macOS Rust gate is queued after it. Full source249 terminal validation remains required.

GNU was rebuilt from pristine `636f166c` with the recorded Apple-libxml2 recipe. Its executable SHA-256 is `29cfb20de2474c040d439d4bdf69b4dfcfb7921464f1f686b6e1f6bcca7c74e5`. Finished capabilities match the retained reference; regenerated native ABI, C primitive and DEFSYM manifests are byte-identical to the committed files. The binary, dump, configuration and Makefile are retained. The proposed replacement pin remains isolated pending complete validation. The first macOS frozen launch stopped before tests on an unowned copied target; its unchanged retry uses a fresh build directory and retains that failure.

The preceding source248 checkpoint passed complete macOS/Linux Rust (3,098/3,110 passes, two existing ignores each), pinned Linux frozen (519 files/7,928 matching outcomes, with skips and expected failures reported separately), and all 226 terminal scenarios/686 comparisons. Its earlier failed runs remain preserved. Source249 requires its own complete results.

The draft remains unfinished. General encoding/decoding translations, remaining string/symbol representations and adapters, physical accounting, sound runtime ownership and borrows, final source validation and adversarial review, and the locked 16-workload/3% performance criterion remain open. Main remains `21d20f0e`. [HANDOVER.md](https://github.com/rayfdj/emaxx/blob/runtime-char-tables/HANDOVER.md) links the full goal, original failures and portable raw evidence.
