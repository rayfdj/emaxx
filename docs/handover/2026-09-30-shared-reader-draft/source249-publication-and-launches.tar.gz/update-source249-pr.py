from pathlib import Path
import json, subprocess

p=Path(__file__).parent.resolve()
root=p.parents[2]
head=json.loads((p/'source249-applied-commit.json').read_text())['commit']
rust=json.loads((p/'source249-linux-rust-launch.json').read_text())['state']['url']
frozen=json.loads((p/'source249-linux-frozen-launch.json').read_text())['state']['url']
body=f'''This draft shares cons, vector and closure fields across the interpreter, bytecode VM and native execution, adds canonical Emacs byte storage for mutable strings, and executes bytecode from its live code string. Reader, completion, substring, interactive-command, display and file-writing paths use those fields; unchanged GNU Lisp retains file-writing policy.

Current runtime is `{head}` (source249), with 476 frozen runtime/test inputs. The latest repair follows `coding.c:decode_coding_object` and `code_convert_string`: post-read hooks receive decoded character counts, and ASCII string decoding returns before the hook, preserving NOCOPY identity while dropping properties from a copied result. The original negative fixtures retain their exact GNU outputs.

Audited source249 validation:

- Zero-warning formatting/check/Clippy/diff checks; 172 focused passes and two existing TTY ignores, plus 955 affected passes, in each of the gate and release profiles.
- Fifteen ordinary GNU comparisons match. Every prior selected control remains, with exactly two new post-read tests. The first selected run's ten missing-sibling-GNU setup failures are retained; restoring only that checkout link makes the same executable and full selection pass.
- [Complete Linux Rust]({rust}) and [complete Linux frozen]({frozen}) are dispatched on the exact commit above. Their results are pending.
- Complete macOS frozen comparison is running on isolated candidate `1c0898fc`, whose runtime inputs match source249. The complete macOS Rust gate is queued after it. Full source249 terminal validation remains required.

GNU was rebuilt from pristine `636f166c` with the recorded Apple-libxml2 recipe. Its executable SHA-256 is `29cfb20de2474c040d439d4bdf69b4dfcfb7921464f1f686b6e1f6bcca7c74e5`. Finished capabilities match the retained reference; regenerated native ABI, C primitive and DEFSYM manifests are byte-identical to the committed files. The binary, dump, configuration and Makefile are retained. The proposed replacement pin remains isolated pending complete validation. The first macOS frozen launch stopped before tests on an unowned copied target; its unchanged retry uses a fresh build directory and retains that failure.

The preceding source248 checkpoint passed complete macOS/Linux Rust (3,098/3,110 passes, two existing ignores each), pinned Linux frozen (519 files/7,928 matching outcomes, with skips and expected failures reported separately), and all 226 terminal scenarios/686 comparisons. Its earlier failed runs remain preserved. Source249 requires its own complete results.

The draft remains unfinished. General encoding/decoding translations, remaining string/symbol representations and adapters, physical accounting, sound runtime ownership and borrows, final source validation and adversarial review, and the locked 16-workload/3% performance criterion remain open. Main remains `21d20f0e`. [HANDOVER.md](https://github.com/rayfdj/emaxx/blob/runtime-char-tables/HANDOVER.md) links the full goal, original failures and portable raw evidence.
'''
with (p/'source249-pr-body.md').open('x') as f:f.write(body)
payload=p/'source249-pr-payload.json'
with payload.open('x') as f:json.dump(dict(title='Share Lisp object fields and execute bytecode from live strings',body=body),f)
def api(*args):return json.loads(subprocess.check_output(['gh','api',*args],cwd=root,text=True))
updated=api('repos/rayfdj/emaxx/pulls/79','--method','PATCH','--input',str(payload))
verified=api('repos/rayfdj/emaxx/pulls/79')
assert verified['head']['sha']==head and verified['draft'] and verified['body']==body
assert verified['base']['sha']=='21d20f0eec08f3c013d5d3eb3bd6e9cfc16b3199'
for name,data in [('source249-pr-update.json',updated),('source249-pr-verified.json',verified)]:
    with (p/name).open('x') as f:json.dump(data,f,indent=2)
print(json.dumps(dict(head=head,url=verified['html_url'],draft=verified['draft'],main_unchanged=True)))
