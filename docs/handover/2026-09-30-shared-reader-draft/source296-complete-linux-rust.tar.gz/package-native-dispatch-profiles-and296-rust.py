from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
out = p.parents[2] / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
profile = read('source297-mixed-profile-result.json')
assert profile['inputs_unchanged'] and all(x['validation'] == 'completed' and x['samples'] == 20 for x in profile['results'])
assert all(sha(Path(n).read_bytes()) == h for n, h in profile['inputs'].items())
gc_counts = {}
files = {}
for row in profile['results']:
    directory = p / 'source297-mixed-profiles' / row['case'] / row['runner']
    assert sha((directory / 'sample.txt').read_bytes()) == row['profile_sha256']
    report = json.loads((directory / 'report.json').read_text())
    assert len(report['observations']) == 20
    gc_counts[row['case']] = [o['gc_count'] for o in report['observations']]
    assert all(o['result'] == row['result'] for o in report['observations'])
for f in (p / 'source297-mixed-profiles').rglob('*'):
    if f.is_file():
        files[str(f.relative_to(p))] = f
for name in ['source297-mixed-profile-result.json', 'profile-source297-mixed.py', 'package-source196-failure-and197-results.py', Path(__file__).name]:
    files[name] = p / name
package('source297-native-call-profiles', files, dict(
    status='three separate profiles verify60 body answers and execution modes', result=profile,
    gc_counts=gc_counts,
    qualification='Whole-process samples include driver/setup and explicit pre-body GC. Every timed-body GC delta is zero: collector samples are not timed-body costs. Native dispatch/function resolution and VM/native call entry remain measured leads. These instrumented durations are not acceptance measurements. All full-goal requirements remain open.', goal_complete=False))
artifact = p / 'source296-linux-rust-artifacts/ordinary-linux-68ca5d8819ddae6f699ac7eeae694b1b19867261'
capture = json.loads((artifact / 'oracle-inputs/manifest.json').read_text())
verification = json.loads((artifact / 'oracle-inputs/verification.json').read_text())
assert capture['status'] == 'captured' and verification['status'] == 'unchanged'
assert verification['capture_manifest_sha256'] == sha((artifact / 'oracle-inputs/manifest.json').read_bytes())
assert verification['files_verified'] == len(capture['files']) == 4 and not capture['source_tracked_changes']
prior = read('source292-linux-rust-oracle-audit.json')['capture']
assert capture['source_commit'] == prior['source_commit']
assert {x['artifact']: x['sha256'] for x in capture['files']} == {x['artifact']: x['sha256'] for x in prior['files']}
for x in capture['files']:
    f = artifact / 'oracle-inputs' / x['artifact']
    assert f.stat().st_size == x['bytes'] and sha(f.read_bytes()) == x['sha256']
oracle = dict(status='all4 retained pinned GNU inputs verified', capture=capture, verification=verification,
              qualification='No cause for prior GNU census failures is established by this passing run.', goal_complete=False)
with (p / 'source296-linux-rust-oracle-audit.json').open('x') as f:
    json.dump(oracle, f, indent=2)
files = {}
omitted = []
for f in artifact.rglob('*'):
    if not f.is_file():
        continue
    name = str(f.relative_to(p))
    if f.stat().st_size > 5_000_000:
        omitted.append(dict(path=name, bytes=f.stat().st_size, sha256=sha(f.read_bytes())))
    else:
        files[name] = f
for f in p.iterdir():
    if f.is_file() and f.suffix == '.json' and f.name.startswith('source296-linux-rust-'):
        files[f.name] = f
for name in ['source296-manifest.json', 'source296-applied-commit.json', 'source296-full-validation-launch.json',
             'audit-source296-linux-rust-names.py', 'verify-source296-linux-rust.py',
             'package-source196-failure-and197-results.py', Path(__file__).name]:
    files[name] = p / name
audit = read('source296-linux-rust-audit.json')
assert audit['status'] == 'passed' and audit['total_passed'] == 3147
package('source296-complete-linux-rust', files, dict(
    status='complete exact68ca5d88 Linux Rust gate raw-audited', audit=audit, oracle=oracle,
    omitted_large_artifacts=omitted,
    qualification='All3046 library names/verdicts and532 published source inputs verify.3147 passes/two existing ignores; native artifact identity passes. Retained local binaries/images are identified by hashes and must be rebuilt elsewhere. Frozen, macOS and later-source results remain separate. Earlier census failures remain unexplained; full-goal completion is not claimed.', goal_complete=False))
