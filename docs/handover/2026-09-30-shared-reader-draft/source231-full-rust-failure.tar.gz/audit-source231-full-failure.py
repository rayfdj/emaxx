from pathlib import Path
import hashlib, json, re, shutil, sys

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/string-ops/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read('source231-manifest.json')
assert len(manifest) == 440 and all(sha(root / name) == digest for name, digest in manifest.items())
sys.path.insert(0, str(root / 'tools'))
import grouped_gate

full = p / 'full-gate-source231'
summary = read('full-gate-source231/summary.json')
result = read('source231-full-gate-result.json')
assert result['exit_code'] == 1 and result['source_unchanged']
assert summary['status'] == 'failed' and summary['scope'] == 'full'
assert summary['cargo_stages'] == [] and summary['runs'] == []
assert summary['git'] == dict(dirty=True, head='21d20f0eec08f3c013d5d3eb3bd6e9cfc16b3199')
inventory = grouped_gate.parse_inventory((full / 'inventory.txt').read_text())
assert len(inventory) == summary['inventory']['total_tests'] == summary['inventory']['scheduled_tests'] == 2981
assert hashlib.sha256(('\n'.join(inventory) + '\n').encode()).hexdigest() == summary['inventory']['sha256']
groups, _ = grouped_gate.classify_inventory(inventory, 'full')
ignored = summary['inventory']['ignored_tests']
assert ignored == ['tty::tty_differential_end_to_end', 'tty::tty_smoke_end_to_end']
failures = [
    'anti_cheat::gate_tests::interpreter_fields_are_carried_or_documented',
    'anti_cheat::gate_tests::interpreter_roots_are_dumped_or_documented',
    'lisp::alloc::vectors::tests::vector_word_offsets_survive_mark_bitmap_boundaries',
    'lisp::eval::dump_roots::tests::every_reset_root_is_a_mark_phase_root',
    'lisp::tests::closure_reader_materialization_never_evaluates_slot_data',
]
seen, reports = [], []
for group, names in groups.items():
    stem = 'repeat-01-' + group
    report = json.loads((full / (stem + '.json')).read_text())
    raw = (full / (stem + '.log')).read_text()
    failed = len(failures) if group == 'lightweight' else 0
    count_ignored = len(ignored) if group == 'tty' else 0
    passed = len(names) - failed - count_ignored
    assert report['exit_code'] == (101 if failed else 0) and not report['timed_out']
    assert report['expected_tests'] == len(names)
    assert re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', raw, re.M) == [
        ('FAILED' if failed else 'ok', str(passed), str(failed), str(count_ignored))]
    starts = list(re.finditer(r'^test (\S+) \.\.\. ', raw, re.M))
    assert sorted(item[1] for item in starts) == sorted(names)
    for index, item in enumerate(starts):
        end = starts[index + 1].start() if index + 1 < len(starts) else raw.index('\n\nfailures:') if failed else raw.rindex('test result:')
        captured = raw[item.end():end].strip()
        if item[1] in ignored:
            assert captured.startswith('ignored'), item[1]
        else:
            expected = 'FAILED' if item[1] in failures else 'ok'
            assert re.search(r'(?:^|\s)' + expected + '$', captured), (item[1], captured)
        seen.append(item[1])
    reports.append(dict(group=group, passed=passed, failed=failed, ignored=count_ignored))
assert sorted(seen) == sorted(inventory) and len(seen) == len(set(seen)) == 2981
assert sum(g['passed'] for g in reports) == 2974
assert sum(g['failed'] for g in reports) == 5 and sum(g['ignored'] for g in reports) == 2
assert not (full / 'bins.log').exists() and not (full / 'integration.log').exists()
binary = Path(result['immutable_binary']['path'])
assert sha(binary) == result['immutable_binary']['sha256'] == summary['test_binary']['sha256']
images = sorted((root / 'target/grouped-gate/fixture-images').glob('loadup-' + sha(binary)[:8] + '-*.pdmp'))
assert len(images) == 1
retained = p / 'source231-full-failure-inputs'
retained.mkdir()
files = []
for source in [binary, *images]:
    target = retained / source.name
    digest = sha(source)
    shutil.copy2(source, target)
    assert sha(source) == sha(target) == digest
    files.append(dict(original=str(source), retained=str(target), sha256=digest, bytes=target.stat().st_size))
record = dict(status='complete library inventory failed; Cargo stages unexecuted', goal_complete=False,
              source_inputs_verified=440, raw_names_verified=2981, passed=2974, failed=5, ignored=2,
              groups=reports, failed_tests=failures, unexecuted=['binary Cargo stage', 'integration Cargo stage'],
              retained_files=files, summary_sha256=sha(full / 'summary.json'),
              diagnosis='Three failures concern stale bytecode root inventory metadata (bc_functions versus bc_live_programs); one reader assertion still requires a host record instead of the shared closure; one vector test reaches only three of four bitmap words and needs investigation without weakening coverage. No fixes or complete-pass claims follow from this audit.')
with (p / 'source231-full-failure-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: record[key] for key in ['status', 'raw_names_verified', 'passed', 'failed', 'ignored', 'failed_tests']}, indent=2))
