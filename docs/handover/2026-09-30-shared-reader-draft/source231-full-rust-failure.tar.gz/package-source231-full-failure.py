from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile
p=Path(__file__).parent.resolve();root=p.parents[2];out=root/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest();read=lambda name:json.loads((p/name).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
audit=read('source231-full-failure-audit.json');assert audit['passed']==2974 and audit['failed']==5 and audit['ignored']==2
full=p/'full-gate-source231';allowed={'.json','.log','.txt','.py','.patch'}
files={str(f.relative_to(p)):f for f in full.rglob('*') if f.is_file() and f.suffix in allowed}
names=['source231-full-failure-audit.json','audit-source231-full-failure.py','source231-manifest.json','source231-full-gate-command.json','source231-full-gate-result.json','source231-full-gate.log','source231-full-gate-launch.json','run-source231-full-gate.py',Path(__file__).name]
files.update({name:p/name for name in names})
package('source231-full-rust-failure',files,audit)
