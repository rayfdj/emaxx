from pathlib import Path
import hashlib,json,os,subprocess,sys,time
p=Path(__file__).parent.resolve()
tag="source195"
root=p.parent/"recovered-2026-09-30/macro-reader/emaxx"
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
manifest=json.loads((p/(tag+"-manifest.json")).read_text())
unchanged=lambda:all(sha(root/f)==h for f,h in manifest.items())
def read_if_closed(name):
    f=p/name
    if not f.exists():return None
    try:return json.loads(f.read_text())
    except json.JSONDecodeError:return None
while True:
    selected=read_if_closed(tag+"-selected-validation-result.json")
    terminal=read_if_closed(tag+"-selected-tty-result.json")
    not_run=read_if_closed(tag+"-selected-tty-not-run.json")
    failed=selected is not None and (not selected["all_completed"] or not selected["source_unchanged"] or any(s["exit_code"] for s in selected["steps"]))
    failed=failed or not_run is not None or (terminal is not None and (terminal["exit_code"] or not terminal["source_unchanged"] or not terminal["inputs_unchanged"]))
    if failed:
        with (p/(tag+"-full-local-supervisor-result.json")).open("x") as f:
            json.dump({"status":"not_run","reason":"selected prerequisites failed","selected":selected,"terminal":terminal,"terminal_not_run":not_run},f,indent=2)
        raise SystemExit(1)
    if selected is not None and terminal is not None:break
    for suffix,record in [("-selected-supervisor.json",selected),("-selected-tty-supervisor.json",terminal or not_run)]:
        if record is None:
            pid=json.loads((p/(tag+suffix)).read_text())["pid"]
            os.kill(pid,0)
    time.sleep(5)
assert unchanged()
children=[]
for kind in ["gate","tty"]:
    script=p/("run-"+tag+"-full-"+kind+".py")
    command=[sys.executable,str(script)]
    with (p/(tag+"-full-"+kind+"-driver.log")).open("x") as log:
        child=subprocess.Popen(command,cwd=root,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    with (p/(tag+"-full-"+kind+"-launch.json")).open("x") as f:
        json.dump({"pid":child.pid,"command":command,"started_unix":time.time(),"script_sha256":sha(script)},f,indent=2)
    children.append((kind,child))
    print(kind,child.pid,flush=True)
results=[]
for kind,child in children:
    code=child.wait()
    results.append({"kind":kind,"pid":child.pid,"exit_code":code,"source_unchanged":unchanged()})
with (p/(tag+"-full-local-supervisor-result.json")).open("x") as f:
    json.dump({"status":"finished","results":results,"source_unchanged":unchanged(),"completed_unix":time.time()},f,indent=2)
raise SystemExit(0 if unchanged() and all(r["exit_code"]==0 for r in results) else 1)
