from pathlib import Path
import ast
import gzip
import hashlib
import io
import json
import re
import tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())

def imported_function(file, name, namespace):
    tree = ast.parse((p / file).read_text())
    node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
    exec(compile(ast.Module(body=[node], type_ignores=[]), str(p / file), 'exec'), namespace)
    return namespace[name]

audit_log = imported_function('audit-shared-reader196-fresh-selected.py', 'audit_log', {'re': re})
package = imported_function('package-source196-failure-and197-results.py', 'package', globals())
old = read('source200-manifest.json')
new = read('source201-manifest.json')
assert set(old) == set(new) and len(new) == 410
changed = sorted(name for name in old if old[name] != new[name])
assert changed == ['src/lisp/native_comp/runtime/record_layout_tests.rs',
                   'tests/fixtures/vector-pseudovector-word-census.el',
                   'tests/fixtures/vector-pseudovector-word-census.expected']
checkout = Path(read('source201-base.json')['worktree'])
assert all(sha((checkout / name).read_bytes()) == digest for name, digest in new.items())

results = []
for tag, passed, failed in [('source200', 453, 1), ('source201', 454, 0)]:
    command = read(tag + '-gate-selected-command.json')
    result = read(tag + '-gate-selected-result.json')
    assert result['exit_code'] == (101 if failed else 0) and result['source_unchanged']
    names = command['selected_inventory']
    assert len(names) == 454
    failures = audit_log(names, (p / (tag + '-gate-selected.log')).read_text(), passed, failed)
    assert failures == (['lisp::native_comp::runtime::record_layout_tests::generic_record_census_includes_header_and_physical_rounding'] if failed else [])
    assert sha((p / (tag + '-gate-libtest')).read_bytes()) == command['binary_sha256']
    for test in ['threads_retain_lexical_caller_roots_across_separate_callee_environments',
                 'suspended_bytecode_retains_operand_and_unwind_roots']:
        assert any(name.endswith('::' + test) for name in names)
        assert not any(name.endswith('::' + test) for name in failures)
    for check in ['check', 'fmt', 'clippy', 'diff', 'gate-build', 'gate-focused']:
        state = read(tag + '-' + check + '-result.json')
        assert state['exit_code'] == 0 and state['source_unchanged']
    focused = read(tag + '-gate-focused-command.json')['selected_inventory']
    assert len(focused) == (7 if failed else 8)
    audit_log(focused, (p / (tag + '-gate-focused.log')).read_text(), len(focused), 0)
    results.append({'source': tag, 'passed': passed, 'failed': failed, 'failures': failures,
                    'binary_sha256': command['binary_sha256'], 'focused_passed': len(focused)})

prefix = 'source198-ordinary-vector-pseudovector-word-census-record-boundaries'
comparison = read(prefix + '-comparison.json')
assert comparison['passed'] is False and comparison['exact_match'] is False
outputs = []
for editor in ['gnu', 'emaxx']:
    stem = prefix + '-' + editor
    command = read(stem + '.command.json')
    result = read(stem + '.result.json')
    assert result == comparison['outcomes'][editor]
    assert result['exit_code'] == 0 and not result['timed_out']
    assert result['source_unchanged'] and result['inputs_unchanged']
    stdout = (p / (stem + '.stdout')).read_bytes()
    assert sha(stdout) == result['stdout_sha256']
    assert (p / (stem + '.stderr')).read_bytes() == b'' and result['stderr_hex'] == ''
    assert all(sha(Path(name).read_bytes()) == digest for name, digest in command['inputs'].items())
    outputs.append(stdout)
assert outputs[0] != outputs[1]
assert outputs[0] == (checkout / 'tests/fixtures/vector-pseudovector-word-census.expected').read_bytes().rstrip(b'\n')
assert (p / 'vector-pseudovector-word-census-record-boundaries.el').read_bytes() == (checkout / 'tests/fixtures/vector-pseudovector-word-census.el').read_bytes()
for data_slots, words in [(0, 2), (1, 3), (2, 4), (9, 11), (257, 259), (4094, 4096)]:
    assert ('(%d %d)' % (data_slots, words)).encode() in outputs[0]

record = {'rust': results, 'source201_inputs_verified': 410,
          'source200_to201_changed_inputs': changed,
          'gnu_record_data_slots_and_words': [[0, 2], [1, 3], [2, 4], [9, 11], [257, 259], [4094, 4096]],
          'negative_ordinary_comparison': prefix,
          'qualification': 'Source200 remains failed (453 passes, one obsolete record-footprint expectation). Source201 changes three inputs: that test and the ordinary census fixture/expectation, preserving all original sizes and assertions. Runtime inputs are identical. Source201 strict, eight focused and 454 selected gate controls pass; release, ordinary and complete validation remain separate. The baseline failures are source199, despite the copied queue qualification naming its own tag.'}
with (p / 'source200-failure-and201-gate-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')

allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected'}
helpers = [Path(__file__).name, 'audit-shared-reader196-fresh-selected.py',
           'package-source196-failure-and197-results.py', 'compare-recovered-continuation-fixtures.py']
files = {f.name: f for f in p.iterdir() if f.is_file() and f.suffix in allowed and
         (f.name.startswith(('source200-', prefix)) or f.name in helpers or
          f.name == 'vector-pseudovector-word-census-record-boundaries.el')}
package('source200-vector-selected-failure', files,
        {'status': 'failed', 'gate': results[0], 'unexecuted': ['release', 'ordinary'],
         'ordinary_gnu_boundary_control': 'Both processes succeed, outputs differ. All six original record boundary sizes independently verified against GNU.'})

helpers += ['freeze-vector-candidate.py', 'audit-source201-patch.py', 'queue-source201-validation.py',
            'check-reader201.py', 'static-reader201.py', 'test-reader201.py', 'build-reader201.py']
names = ['source201-base.json', 'source201-complete.patch', 'source201-manifest.json',
         'source201-patch-replay-and-modes-audit.json', 'source201-selected-supervisor.json',
         'source200-failure-and201-gate-audit.json']
files = {f.name: f for f in p.iterdir() if f.is_file() and f.suffix in allowed and
         (f.name in names + helpers or
          f.name.startswith(tuple('source201-' + part + '-' for part in ['check', 'fmt', 'clippy', 'diff', 'gate'])) or
          f.name in ['source201-check.log', 'source201-fmt.log', 'source201-clippy.log', 'source201-diff.log'])}
package('source201-vector-selected-gate', files,
        {'status': 'selected gate passed; unfinished candidate', 'gate': results[1],
         'qualification': record['qualification'], 'running_logs_excluded': True})
