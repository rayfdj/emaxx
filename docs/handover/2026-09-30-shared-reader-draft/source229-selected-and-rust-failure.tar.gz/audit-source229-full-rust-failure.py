from pathlib import Path
import ast,hashlib,json,re,shutil
p=Path(__file__).parent.resolve();root=p.parent/'recovered-2026-09-30/string-bytes/emaxx';full=p/'full-gate-source229'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
read=lambda name:json.loads((p/name).read_text())
manifest=read('source229-manifest.json')
assert len(manifest)==432 and all(sha(root/name)==digest for name,digest in manifest.items())
summary=read('full-gate-source229/summary.json');outcome=read('source229-full-gate-result.json')
assert outcome['exit_code']==1 and outcome['source_unchanged']
assert summary['status']=='failed' and summary['cargo_stages']==[] and summary['runs']==[]
assert sha(Path(outcome['immutable_binary']['path']))==summary['test_binary']['sha256']
node=next(n for n in ast.parse((p/'audit-shared-reader196-fresh-selected.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='audit_log')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<raw-auditor>','exec'))
inventory=[line[:-6] for line in (full/'inventory.txt').read_text().splitlines() if line.endswith(': test')]
assert len(inventory)==len(set(inventory))==2978
assert hashlib.sha256(('\n'.join(inventory)+'\n').encode()).hexdigest()==summary['inventory']['sha256']
groups=[]
for group,passed,failed in [('eval_01',386,0),('eval_02',294,1)]:
    expected=[name for name in inventory if name.startswith('lisp::eval::tests::'+group+'::')]
    result=read('full-gate-source229/repeat-01-'+group+'.json')
    assert not result['timed_out'] and result['exit_code']==(101 if failed else 0)
    failures=audit_log(expected,(full/('repeat-01-'+group+'.log')).read_text(),passed,failed)
    assert failures==(['lisp::eval::tests::eval_02::quoted_bytecode_reader_forms_are_materialized_as_records'] if failed else [])
    groups.append(dict(group=group,passed=passed,failed=failed,failures=failures,inventory_verified=len(expected)))
unexecuted=['eval_03','eval_04','eval_05','primitives','compat_runtime','tty','batch','lightweight']
assert all(not (full/('repeat-01-'+name+'.log')).exists() for name in unexecuted)
retained=p/'source229-full-failure-inputs';retained.mkdir()
sources=[Path(outcome['immutable_binary']['path']),*sorted((root/'target/grouped-gate/fixture-images').glob('loadup-d21414c3-*.pdmp'))]
assert len(sources)==2
files=[]
for source in sources:
    destination=retained/source.name;digest=sha(source);shutil.copy2(source,destination)
    assert sha(destination)==sha(source)==digest
    files.append(dict(original=str(source),retained=str(destination),sha256=digest,bytes=destination.stat().st_size))
comparison=read('source229-ordinary-quoted-bytecode-reader-closure-comparison.json')
assert comparison['passed'] and comparison['exact_match']
for editor in ['gnu','emaxx']:
    prefix='source229-ordinary-quoted-bytecode-reader-closure-'+editor
    command=read(prefix+'.command.json');result=read(prefix+'.result.json')
    assert result['exit_code']==0 and not result['timed_out'] and result['source_unchanged'] and result['inputs_unchanged']
    assert all(sha(Path(f))==h for f,h in command['inputs'].items())
    assert (p/(prefix+'.stdout')).read_bytes()==b'(t t nil 4 (192 135) nil nil)'
    assert (p/(prefix+'.stderr')).read_bytes()==b''
record=dict(status='complete Rust run failed at old host-record assertion',goal_complete=False,inputs_verified=432,passed=680,failed=1,groups=groups,unexecuted_groups=unexecuted,unexecuted_library_tests=2978-681,unexecuted_cargo_stages=['bins','integration'],retained_files=files,
    diagnosis='The unchanged quoted-bytecode Lisp form is a callable bytecode closure, not a record, in both ordinary GNU and source229. Both return the same four actual fields, opcode bytes and nil result. The full Rust test still requires the removed Kind::Record representation. Source230 changes that internal assertion to Kind::Closure and adds the unchanged GNU field/execution fixture; it has no validation verdict yet. The complete terminal run remains separate and active. This failed Rust run remains failed.')
with (p/'source229-full-rust-failure-audit.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps({k:v for k,v in record.items() if k!='retained_files'},indent=2))
