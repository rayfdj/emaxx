from pathlib import Path
import ast,hashlib,json,re,shutil
p=Path(__file__).parent.resolve();root=p.parent/'recovered-2026-09-30/string-ops/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();read=lambda name:json.loads((p/name).read_text())
manifest=read('source230-manifest.json');assert len(manifest)==440 and all(sha(root/name)==h for name,h in manifest.items())
node=next(n for n in ast.parse((p/'audit-shared-reader196-fresh-selected.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='audit_log')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<raw-auditor>','exec'))
inventory=[line[:-6] for line in (p/'source230-gate-inventory.txt').read_text().splitlines() if line.endswith(': test')]
assert len(inventory)==len(set(inventory))==2981
prefixes=('lisp::bytecode::','lisp::native_comp::runtime::','lisp::primitives::pdumper::','lisp::primitives::tests::','lisp::reader::','lisp::types::')
groups=[]
for stage,passed,failed in [('controls',30,1),('broad',937,0)]:
    stem='source230-gate-'+stage;command=read(stem+'-command.json');result=read(stem+'-result.json')
    assert result['exit_code']==(101 if failed else 0) and result['source_unchanged']
    assert command['environment_override']['LANG']==command['environment_override']['LC_ALL']=='C'
    assert sha(p/'source230-gate-libtest')==command['binary_sha256']
    names=command['selected_inventory'];assert len(names)==passed+failed
    if stage=='broad':assert names==[name for name in inventory if name.startswith(prefixes)]
    failures=audit_log(names,(p/(stem+'.log')).read_text(),passed,failed)
    assert failures==(['lisp::eval::tests::eval_02::quoted_bytecode_reader_forms_are_materialized_as_records'] if failed else [])
    groups.append(dict(stage=stage,passed=passed,failed=failed,ignored=0,inventory_verified=len(names),failures=failures))
for stage in ['check','fmt','clippy','diff','gate-build']:
    result=read('source230-'+stage+'-result.json');assert result['exit_code']==0 and result['source_unchanged']
    raw=(p/('source230-'+stage+'.log')).read_text();assert not re.search(r'^warning(?:\[.*\])?:',raw,re.M)
    for line in raw.splitlines():
        try:item=json.loads(line)
        except json.JSONDecodeError:continue
        assert item.get('message',{}).get('level') not in ['warning','error']
retained=p/'source230-retained-inputs';retained.mkdir()
sources=[p/'source230-gate-libtest',*sorted((p/'fixture-images-source230').glob('*.pdmp'))];assert len(sources)==2
files=[]
for source in sources:
    destination=retained/source.name;digest=sha(source);shutil.copy2(source,destination);assert sha(source)==sha(destination)==digest
    files.append(dict(original=str(source),retained=str(destination),sha256=digest,bytes=destination.stat().st_size))
record=dict(status='all affected-module tests pass; focused fixture setup failure retained',inputs_verified=440,strict_checks='zero warnings',gate_inventory=2981,groups=groups,retained_files=files,goal_complete=False,
    qualification='Every name and verdict in all 937 affected-module tests passes, with zero ignores. The 31 focused controls retain 30 passes/one added bare-interpreter fixture setup failure; that run remains failed. The original quoted-reader and closure-kind assertions pass before missing GNU cadr aborts the added fixture. Release and complete validation remain open. Source231 is a proposed test-setup correction only.')
with (p/'source230-results-audit.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps({k:v for k,v in record.items() if k!='retained_files'},indent=2))
