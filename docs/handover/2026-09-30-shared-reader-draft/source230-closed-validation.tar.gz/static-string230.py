from pathlib import Path
import hashlib,json,os,subprocess,sys,time
p=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28')
root=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/string-ops/emaxx')
tag='source'+sys.argv[1]
manifest=json.loads((p/(tag+'-manifest.json')).read_text())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def unchanged():return all(sha(root/f)==h for f,h in manifest.items())
env={'CARGO_TARGET_DIR':'/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/string-ops/emaxx/target/frame-validation','CARGO_BUILD_JOBS':'1'}
results={}
for name,cmd in [('fmt',['cargo','fmt','--all','--','--check']),('clippy',['cargo','clippy','--locked','--all-targets','--all-features','--','-D','warnings']),('diff',['git','diff','--check'])]:
    assert unchanged()
    with (p/(tag+'-'+name+'-command.json')).open('x') as f:json.dump({'command':cmd,'working_directory':str(root),'environment_override':env},f,indent=2)
    start=time.monotonic()
    with (p/(tag+'-'+name+'.log')).open('x') as log:
        r=subprocess.run(cmd,cwd=root,env={**os.environ,**env},stdout=log,stderr=subprocess.STDOUT,timeout=1800)
    result={'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'source_unchanged':unchanged()}
    with (p/(tag+'-'+name+'-result.json')).open('x') as f:json.dump(result,f,indent=2)
    results[name]=result;print(name,result,flush=True)
assert all(r['exit_code']==0 and r['source_unchanged'] for r in results.values()),results
