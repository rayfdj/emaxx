from pathlib import Path
import hashlib, json, subprocess, time
p=Path(__file__).parent.resolve()
control=json.loads((p/'source230-gate-controls-result.json').read_text())
assert control['exit_code']==101 and control['source_unchanged']
raw=(p/'source230-gate-controls.log').read_text()
assert '30 passed; 1 failed; 0 ignored;' in raw
assert 'evaluation failed: Symbol\'s function definition is void: cadr' in raw
assert raw.count('\nFAILED\n')==1
commands=[['python3',str(p/'build-string230.py'),'230'], ['python3',str(p/'run-source230-ordinary.py')]]
results=[]
for command in commands:
    print('START',command,flush=True)
    start=time.monotonic()
    run=subprocess.run(command,stdin=subprocess.DEVNULL)
    record=dict(command=command,exit_code=run.returncode,elapsed_seconds=time.monotonic()-start)
    results.append(record);print('END',record,flush=True)
    if run.returncode:break
with (p/'source230-ordinary-driver-result.json').open('x') as f:json.dump(results,f,indent=2)
raise SystemExit(next((entry['exit_code'] for entry in results if entry['exit_code']),0))
