from pathlib import Path
import json, subprocess, sys, time

p = Path(__file__).parent.resolve()
number = sys.argv[1]
tag = 'source' + number
stages = [
    ('check', ['python3', str(p / 'check-string230.py'), number]),
    ('strict', ['python3', str(p / 'static-string230.py'), number]),
    ('gate-controls', ['python3', str(p / 'test-string-controls230.py'), number, 'gate']),
    ('gate-broad', ['python3', str(p / 'test-string-broad230.py'), number, 'gate']),
]
results = []
for stage, command in stages:
    start = time.monotonic()
    print('START', stage, flush=True)
    result = subprocess.run(command, cwd=p.parents[2])
    results.append(dict(stage=stage, command=command, exit_code=result.returncode,
                        elapsed_seconds=time.monotonic() - start))
    print('END', stage, results[-1], flush=True)
    if result.returncode:
        receipt = p / (tag + '-gate-controls-result.json')
        if stage != 'gate-controls' or not receipt.exists():
            break
        executed = json.loads(receipt.read_text())
        if executed['exit_code'] != 101 or not executed['source_unchanged']:
            break
with (p / (tag + '-validation-result.json')).open('x') as stream:
    json.dump(results, stream, indent=2)
    stream.write('\n')
sys.exit(next((r['exit_code'] for r in results if r['exit_code']), 0))
