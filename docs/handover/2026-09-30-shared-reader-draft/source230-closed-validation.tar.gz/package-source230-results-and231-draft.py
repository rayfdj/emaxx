from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve();root=p.parents[2];out=root/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest();read=lambda name:json.loads((p/name).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
selected=read('source230-results-audit.json');ordinary=read('source230-ordinary-audit.json')
assert [(g['passed'],g['failed']) for g in selected['groups']]==[(30,1),(937,0)] and len(ordinary['fixtures'])==54
allowed={'.json','.log','.txt','.py','.patch','.stdout','.stderr','.el','.expected','.md'}
files={f.name:f for f in p.iterdir() if f.is_file() and f.suffix in allowed and f.name.startswith('source230-')}
names=['audit-source230-results.py','audit-source230-ordinary.py','audit-source230-patches.py','audit-shared-reader196-fresh-selected.py','run-string-validation230.py','check-string230.py','static-string230.py','test-string-controls230.py','test-string-broad230.py','run-source230-build-and-ordinary.py','build-string230.py','run-source230-ordinary.py','compare-source230-fixtures.py','source207-ordinary-comparisons-command.json','freeze-string-ops-candidate.py',Path(__file__).name]
files.update({name:p/name for name in names})
package('source230-closed-validation',files,dict(selected=selected,ordinary=ordinary,
    qualification='All 937 affected-module gate tests and 54 exact ordinary comparisons pass. The 31 focused controls retain the added bare-interpreter setup failure; no failed run is relabeled. The exact executable/images, source hashes, names and raw verdicts are audited. Source231 changes only the added test initialization. Release, complete platform, terminal, pinned compatibility, architecture/accounting and performance requirements remain open.'))
manifest=read('source231-manifest.json');candidate=p.parent/'recovered-2026-09-30/string-ops/emaxx';assert len(manifest)==440 and all(sha((candidate/name).read_bytes())==h for name,h in manifest.items())
names=['source231-base.json','source231-manifest.json','source231-complete.patch','source231-launch.json','source231-test-only-delta.json','source231-patch-replay-and-modes-audit.json','audit-source231-patches.py','run-string-validation231.py','check-string230.py','static-string230.py','test-string-controls230.py','run-source231-release.py','test-string-broad230.py','run-source231-full-gate.py','run-source231-build-and-ordinary.py','build-string230.py','run-source231-ordinary.py','compare-source230-fixtures.py',Path(__file__).name]
for stage in ['check','fmt','clippy','diff']:
    result=read('source231-'+stage+'-result.json');assert result['exit_code']==0 and result['source_unchanged']
    names+=['source231-'+stage+suffix for suffix in ['-command.json','-result.json','.log']]
package('source231-bytecode-fixture-startup-draft',{name:p/name for name in names},dict(status='test-only startup correction; strict checks pass; focused gate validation running',source_inputs=440,supervisor=read('source231-launch.json')['pid'],
    qualification='Only the added unchanged quoted-bytecode GNU fixture receives the normal batch preload; the original bare-reader/closure assertions and every production input remain unchanged from source230. All 440 inputs/modes replay exactly. The full gate will follow the 31 focused controls instead of repeating the already passing 937-test selected gate set. Release/full/ordinary launch helpers are prepared, not executed by this archive. No runtime or full-goal pass is assigned.'))
