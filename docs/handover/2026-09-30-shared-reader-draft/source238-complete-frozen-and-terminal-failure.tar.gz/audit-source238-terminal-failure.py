from pathlib import Path
import hashlib, json, re, runpy
p = Path(__file__).parent.resolve()
read = lambda name: json.loads((p / name).read_text())
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
command, result = read('source238-full-ttydiff-command.json'), read('source238-full-ttydiff-result.json')
root = Path(command['working_directory'])
manifest = read(command['source_manifest'])
assert len(manifest) == 446 and all(sha(root / name) == digest for name, digest in manifest.items())
assert len(command['inputs']) == 8 and all(sha(Path(name)) == digest for name, digest in command['inputs'].items())
assert result['exit_code'] == 1 and result['source_unchanged'] and result['inputs_unchanged']
assert result['complete_start_inventory'] and result['expected_scenarios'] == result['started_scenarios'] == 226
module = runpy.run_path(str(root / 'tools/ttydiff.py'), run_name='inventory_only')
scenarios = module['select_scenarios']([])
assert [row[0] for row in scenarios] == command['inventory']
raw = (p / 'source238-full-ttydiff.log').read_text()
starts = list(re.finditer(r'^RUN \[(\d+)/(\d+)\] (.+)$', raw, re.M))
assert [(m[1], m[2], m[3]) for m in starts] == [(str(i+1), '226', row[0]) for i, row in enumerate(scenarios)]
matches, failures, omitted = [], [], []
scheduled = 0
for i, scenario in enumerate(scenarios):
    name, actions = scenario[0], scenario[2]
    expected, final, filesystem = [], name, False
    for index, item in enumerate(actions):
        action = module['normalize_action'](item, index)
        if not action.checkpoint:
            continue
        label = f'{name}::{index+1}:{action.name}'
        if index + 1 == len(actions):
            final, filesystem = label, action.filesystem
        else:
            expected.append(label)
            if action.filesystem:
                expected.append(label + ' filesystem')
    expected.append(final)
    if filesystem:
        expected.append(final + ' filesystem')
    scheduled += len(expected)
    segment = raw[starts[i].end():starts[i+1].start() if i+1 < len(starts) else len(raw)]
    verdicts = re.findall(r'^(MATCH|DIVERGE) \[(.+)\]: (.+)$', segment, re.M)
    assert [label for _, label, _ in verdicts] == expected[:len(verdicts)]
    for kind, label, detail in verdicts:
        if kind == 'MATCH':
            assert re.fullmatch(r'text area identical \(\d+ rows\)|isolated fixture trees identical', detail)
            matches.append(label)
        else:
            assert kind == 'DIVERGE' and detail == '1 terminal difference(s)'
            failures.append(label)
    if name == 'find-alternate-file-missing-revisit':
        assert verdicts[-1][0] == 'DIVERGE'
        assert "gnu  : '-=-U:---  F1  missing.dat" in segment
        assert "emaxx: '-=--:---  F1  missing.dat" in segment
        omitted += expected[len(verdicts):]
    else:
        assert len(verdicts) == len(expected) and all(row[0] == 'MATCH' for row in verdicts)
assert scheduled == 686 and len(matches) + len(failures) + len(omitted) == scheduled
assert failures == ['find-alternate-file-missing-revisit::6:verify-created-file']
assert raw.rstrip().endswith('FAIL: 1 scenario(s) diverged')
record = dict(status='one terminal scenario fails', inputs_verified=446, execution_inputs_verified=8,
              started_scenarios=226, fully_matching_scenarios=225, scheduled_comparisons=scheduled,
              matching_comparisons=len(matches), divergent_labels=failures, unexecuted_labels=omitted,
              log_sha256=sha(p / 'source238-full-ttydiff.log'), goal_complete=False,
              qualification='The complete scenario inventory starts, with one coding-system indicator mismatch after saving a newly created alternate file. The failing scenario returns early, leaving its remaining filesystem/revisit comparisons unexecuted. All seven original quote-display divergence labels now match. No selectors, actions, timeouts or comparison logic changed. GNU is source/native-ABI matched, not the pinned Darwin executable.')
assert set(read('source229-terminal-failure-audit.json')['divergent_labels']) <= set(matches)
with (p / 'source238-terminal-failure-audit.json').open('x') as f:
    json.dump(record, f, indent=2)
print(json.dumps(record, indent=2))
