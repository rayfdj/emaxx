from pathlib import Path
import hashlib, json, subprocess, sys, zipfile
p = Path(__file__).parent.resolve()
run = '36812124904'
head = 'a7e12de8bf4c9cf124e8982922c268f91e97aa6f'
sha = lambda data: hashlib.sha256(data).hexdigest()
def save(name, data):
    with (p / name).open('x') as f:
        json.dump(data, f, indent=2)
state = json.loads(subprocess.check_output(['gh', 'run', 'view', run, '--repo', 'rayfdj/emaxx',
    '--json', 'headSha,status,conclusion,url,jobs'], text=True))
assert state['status'] == 'completed' and state['conclusion'] == 'success' and state['headSha'] == head
save('source238-linux-frozen-final-state.json', state)
items = json.loads(subprocess.check_output(['gh', 'api', 'repos/rayfdj/emaxx/actions/runs/' + run + '/artifacts'], text=True))
save('source238-linux-frozen-artifact-list.json', items)
assert items['total_count'] == 1
item = items['artifacts'][0]
assert item['workflow_run']['head_sha'] == head and not item['expired']
command = ['gh', 'api', 'repos/rayfdj/emaxx/actions/artifacts/' + str(item['id']) + '/zip']
archive = p / 'source238-linux-frozen-artifact.zip'
with archive.open('xb') as f:
    result = subprocess.run(command, stdin=subprocess.DEVNULL, stdout=f, stderr=subprocess.PIPE)
assert result.returncode == 0, result.stderr
assert 'sha256:' + sha(archive.read_bytes()) == item['digest']
destination = p / 'source238-linux-frozen-artifacts'
destination.mkdir()
files = []
with zipfile.ZipFile(archive) as z:
    for member in z.infolist():
        if member.is_dir():
            continue
        name = Path(member.filename)
        assert not name.is_absolute() and '..' not in name.parts
        target = destination / name
        target.parent.mkdir(parents=True, exist_ok=True)
        data = z.read(member)
        with target.open('xb') as f:
            f.write(data)
        assert sha(target.read_bytes()) == sha(data)
        files.append(dict(path=member.filename, sha256=sha(data), bytes=len(data)))
save('source238-linux-frozen-download.json', dict(command=command, artifact=item,
     zip_sha256=sha(archive.read_bytes()), files=files))
summaries = list(destination.rglob('summary.json'))
assert len(summaries) == 1, summaries
frozen = summaries[0].parent
subprocess.run([sys.executable, str(p / 'verify-complete-frozen-receipts.py'), str(frozen), head, run,
                str(p / 'source238-linux-frozen-complete-audit.json')], cwd=p.parents[2], check=True)
contract = frozen / 'contract.json'
report = json.loads(summaries[0].read_text())
for file in report['files']:
    directory = (frozen / file).with_suffix('.compat')
    execution = json.loads((directory / 'execution.json').read_text())
    assert execution['contract_sha256'] == sha(contract.read_bytes())
    assert all(sha((directory / name).read_bytes()) == digest for name, digest in execution['sha256'].items())
    records = [json.loads((directory / (runner + '.json')).read_text()) for runner in ['oracle', 'emaxx']]
    assert {r['name']: (r['status'], r['expected']) for r in records[0]['results']} == {
        r['name']: (r['status'], r['expected']) for r in records[1]['results']}
save('source238-linux-frozen-raw-integrity-audit.json', dict(status='all raw execution hashes and paired name/status/expectation outcomes verified',
     files=519, outcomes=7928, archive_members=len(files), contract_sha256=sha(contract.read_bytes()),
     zip_sha256=sha(archive.read_bytes()), qualification='Supplements the complete inventory/process audit. Raw GNU and Emaxx expected failures and skips remain distinct from passes.'))
print(json.dumps(dict(status='download and both audits pass', files=519, outcomes=7928, archive_members=len(files))))
