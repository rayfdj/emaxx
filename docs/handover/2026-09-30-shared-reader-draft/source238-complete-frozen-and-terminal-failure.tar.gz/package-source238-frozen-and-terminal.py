from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile
p = Path(__file__).parent.resolve()
out = p.parents[2] / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
read = lambda name: json.loads((p / name).read_text())
allowed = {'.json', '.log', '.txt', '.py', '.stdout', '.stderr'}
patterns = ['source238-linux-frozen-*', 'collect-source238-frozen.py', 'verify-complete-frozen-receipts.py',
            'source238-full-tty*', 'source238-terminal-failure-audit.json', 'source238-manifest.json',
            'run-source238-full-tty.py', 'audit-source238-terminal-failure.py', Path(__file__).name]
files = {str(file.relative_to(p)): file for pattern in patterns for file in p.glob(pattern)
         if file.is_file() and file.suffix in allowed}
files.update({str(file.relative_to(p)): file for file in (p / 'source238-linux-frozen-artifacts').rglob('*') if file.is_file()})
frozen = read('source238-linux-frozen-complete-audit.json')
terminal = read('source238-terminal-failure-audit.json')
assert frozen['verified_files'] == 519 and frozen['verified_outcomes'] == 7928
assert terminal['matching_comparisons'] == 682 and len(terminal['divergent_labels']) == 1
assert len(terminal['unexecuted_labels']) == 3
package('source238-complete-frozen-and-terminal-failure', files,
        dict(frozen=frozen, raw_integrity=read('source238-linux-frozen-raw-integrity-audit.json'), terminal=terminal,
             qualification='Exact a7e12de8 recovers the complete pinned Linux frozen match: 519 files, 7928 outcomes, 1038 successful processes. Per editor 7670 passes, 47 expected failures and 211 skips. The full local terminal gate remains failed: 225 of 226 scenarios wholly match, 682 comparisons match, one coding-indicator divergence and three unexecuted comparisons. Earlier failures remain preserved. No complete correctness, pinned Darwin, architecture or performance claim.'))
