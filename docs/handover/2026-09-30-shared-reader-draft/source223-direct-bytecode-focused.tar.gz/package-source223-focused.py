from pathlib import Path
import ast, gzip, hashlib, io, json, re, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
tree = ast.parse((p / 'package-source196-failure-and197-results.py').read_text())
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
tree = ast.parse((p / 'audit-shared-reader196-fresh-selected.py').read_text())
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'audit_log')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<raw-auditor>', 'exec'))
audit = read('source223-gate-controls-audit.json')
command = read('source223-gate-controls-command.json')
assert audit_log(command['selected_inventory'], (p / 'source223-gate-controls.log').read_text(), 17, 0) == []
assert sha((p / 'source223-gate-libtest').read_bytes()) == audit['binary_sha256'] == command['binary_sha256']
assert read('source223-gate-build-result.json')['exit_code'] == 0
names = ['source223-gate-controls-audit.json', 'source223-gate-controls-command.json', 'source223-gate-controls-result.json',
         'source223-gate-controls.log', 'source223-gate-build-command.json', 'source223-gate-build-result.json',
         'source223-gate-build.log', 'source223-gate-inventory.txt', 'source223-gate-broad-command.json',
         'source223-release-launch.json', 'run-source223-release.py', 'source223-launch.json',
         'test-string-controls222.py', 'test-string-broad219.py', 'run-string-validation222.py',
         'source223-manifest.json', Path(__file__).name]
package('source223-direct-bytecode-focused', {name: p / name for name in names}, audit)
