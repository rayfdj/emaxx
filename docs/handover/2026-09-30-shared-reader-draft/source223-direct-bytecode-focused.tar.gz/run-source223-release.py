from pathlib import Path
import json, subprocess, sys, time

p = Path(__file__).parent.resolve()
control = json.loads((p / 'source223-gate-controls-result.json').read_text())
assert control['exit_code'] == 0 and control['source_unchanged']
results = []
for stage, helper in [('release-controls', 'test-string-controls222.py'), ('release-broad', 'test-string-broad219.py')]:
    command = ['python3', str(p / helper), '223', 'release']
    start = time.monotonic()
    print('START', stage, flush=True)
    result = subprocess.run(command, cwd=p.parents[2])
    record = dict(stage=stage, command=command, exit_code=result.returncode, elapsed_seconds=time.monotonic() - start)
    results.append(record)
    print('END', stage, record, flush=True)
    if result.returncode:
        break
with (p / 'source223-release-driver-result.json').open('x') as stream:
    json.dump(results, stream, indent=2)
    stream.write('\n')
sys.exit(next((r['exit_code'] for r in results if r['exit_code']), 0))
