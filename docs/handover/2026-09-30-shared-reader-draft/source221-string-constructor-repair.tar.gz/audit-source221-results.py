from pathlib import Path
import ast, hashlib, json, re, shutil

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/string-bytes/emaxx'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read('source221-manifest.json')
assert len(manifest) == 423
assert all(sha(root / name) == digest for name, digest in manifest.items())
tree = ast.parse((p / 'audit-shared-reader196-fresh-selected.py').read_text())
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'audit_log')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<raw-auditor>', 'exec'))
failure = 'lisp::primitives::tests::bytecode_code_mutation_during_active_call_matches_gnu'
binary = p / 'source221-gate-libtest'
groups = []
for group, passed in [('controls', 14), ('broad', 927)]:
    command = read('source221-gate-' + group + '-command.json')
    result = read('source221-gate-' + group + '-result.json')
    assert result['exit_code'] == 101 and result['source_unchanged']
    assert sha(binary) == command['binary_sha256']
    names = command['selected_inventory']
    prior = read('source220-gate-' + group + '-command.json')['selected_inventory']
    assert set(prior) <= set(names)
    assert audit_log(names, (p / ('source221-gate-' + group + '.log')).read_text(), passed, 1) == [failure]
    assert command['environment_override']['LANG'] == command['environment_override']['LC_ALL'] == 'C'
    groups.append(dict(stage=group, passed=passed, failed=1, ignored=0, inventory_verified=len(names)))
for stage in ['check', 'fmt', 'clippy', 'diff', 'gate-build']:
    result = read('source221-' + stage + '-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
    raw = (p / ('source221-' + stage + '.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
    for line in raw.splitlines():
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        assert item.get('message', {}).get('level') not in ['error', 'warning']
    if stage in ['fmt', 'diff']:
        assert not raw
assert (root / 'tests/fixtures/canonical-string-constructors.expected').read_bytes() == (p / 'canonical-string-constructors-gnu.stdout').read_bytes() + b'\n'
retained = p / 'source221-retained-inputs'
retained.mkdir()
files = []
for source in [binary, *sorted((p / 'fixture-images-source221').glob('*.pdmp'))]:
    target = retained / source.name
    digest = sha(source)
    shutil.copy2(source, target)
    assert sha(source) == sha(target) == digest
    files.append(dict(original=str(source), retained=str(target), sha256=digest, bytes=target.stat().st_size))
record = dict(status='constructor repair passes; active-call bytecode mutation remains failed', inputs_verified=len(manifest),
              strict_checks='passed with zero warnings', groups=groups, failing_names=[failure], retained_files=files,
              qualification='Gate profile only. Full character construction, original canonical-byte differential, flags, errors and direct payload checks pass. All previous affected-module tests execute, plus the new constructor control. No release, complete final validation or performance claim. Earlier failures remain preserved.')
with (p / 'source221-results-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record, indent=2))
