from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
out = p.parents[2] / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected', '.h'}
selected = read('source295-selected-audit.json')
performance = read('single-line-performance-audit.json')
assert selected['status'] == 'passed' and selected['source_inputs_verified'] == 532
assert selected['ordinary_comparisons'] == 47
assert all(r['passed'] == 290 and r['failed'] == 0 and r['ignored'] == 2
           for r in selected['profiles'].values())
assert selected['retained_broad_probe_failure']['exact_match'] is False
assert performance['status'] == 'all 288 processes and actual results/modes verified'
assert read('single-line-performance-sequence-closed-result.json')['status'] == 'timing audited; source decision pending'
for audit in (selected, performance):
    assert all(sha(Path(name).read_bytes()) == digest for name, digest in audit['evidence_files'].items())
helpers = [
    'run-source295-validation.py', 'audit-single-line-selected.py',
    'compare-source295-generated-loaded.py', 'compare-source292-generated-loaded.py',
    'compare-vm-dispatch-fixtures.py', 'compare-buffer-line-broad-probe.py',
    'buffer_line_validation_support.py', 'verify-existing-portable-draft.py',
    'replay-buffer-line-drafts.py', 'finish-single-line-selected-closed.py',
    'source290-manifest.json', 'source290-selected-closed-audit.json',
    'source290-gate-inventory.log', 'source290-release-inventory.log',
    'source292-manifest.json', 'source292-selected-audit.json',
    'printer-varied-v3-293638f0.el', 'printer-varied-v3-gnu.stdout',
    'package-source196-failure-and197-results.py', Path(__file__).name,
]
files = {f.name: f for f in p.iterdir() if f.is_file() and f.suffix in allowed
         and f.name.startswith(('source295-', 'single-line-selection-', 'single-line-coordinator-'))}
files.update({name: p / name for name in helpers})
package('source295-single-line-selected', files, dict(
    status='closed fresh selected validation for source295', audit=selected,
    qualification='All 532 source inputs and modes replay exactly. Fresh gate/release/ordinary compilation is verified. Each selected profile has 290 passes and two existing external TTY ignores; 47 actual ordinary GNU comparisons pass. The entire broad probe retains 60 original display-column failures. No fixture, assertion, selector, timeout or comparison rule is weakened. Full-platform, accounting, ownership and final performance acceptance remain open.',
    goal_complete=False))
files = {}
for tag in ('source290', 'source292', 'source295'):
    for directory in sorted(p.glob(tag + '-single-line-pilot-*')) + [p / (tag + '-core-native')]:
        for f in directory.rglob('*'):
            if f.is_file() and f.suffix in allowed:
                files[str(f.relative_to(p))] = f
for f in p.iterdir():
    if f.is_file() and f.suffix in allowed and f.name.startswith('single-line-performance-'):
        files[f.name] = f
for name in ['measure-single-line.py', 'audit-single-line-performance.py',
             'finish-single-line-performance-closed.py', 'source295-application-decision.json',
             'package-source196-failure-and197-results.py', Path(__file__).name]:
    files[name] = p / name
package('source295-single-line-performance', files, dict(
    status='all 288 actual diagnostic results and modes verified', audit=performance,
    application_decision=read('source295-application-decision.json'),
    qualification='Three rotated repetitions of every unchanged 16-workload pilot for applied original290, LF-only corrected baseline292 and no-LF shortcut295. Every sample, unfavorable case and startup/total/RSS/GC report remains. Builds, tests and profiles were separate from timing. Allocation counters remain unavailable. This diagnostic does not certify calibrated nine-round acceptance or the unchanged upper 95% ratio of at most 1.03 for every case.',
    goal_complete=False))
