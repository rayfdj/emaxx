from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve();root=p.parents[2]
out=root/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest()
tree=ast.parse((p/'package-source196-failure-and197-results.py').read_text())
node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
names=['source207-full-ttydiff-command.json','source207-full-ttydiff-result.json','source207-full-ttydiff.log',
       'source207-complete-terminal-audit.json','verify-complete-reader-terminal-receipts.py',
       'source207-manifest.json','source207-base.json','source207-complete.patch','run-source207-full-tty.py',Path(__file__).name]
package('source207-complete-terminal',{name:p/name for name in names},json.loads((p/'source207-complete-terminal-audit.json').read_text()))
