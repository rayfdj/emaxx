from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve();root=p.parents[2];out=root/'docs/handover/2026-09-30-shared-reader-draft';sha=lambda data:hashlib.sha256(data).hexdigest()
tree=ast.parse((p/'package-source196-failure-and197-results.py').read_text());node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
files={}
for pattern in ['source204-runtime-*','source204-linux-*-dispatch.json','source204-linux-*-initial-state.json']:
 for f in p.glob(pattern):
  if f.is_file() and f.suffix in {'.json','.md'}:files[f.name]=f
for name in ['verify-source204-macos-rust.py','audit-source204-macos-names.py','audit-source204-linux-names.py',Path(__file__).name]:files[name]=p/name
head=json.loads((p/'source204-runtime-published-head.json').read_text())['head'];assert head=='d186d40bf014ca53d0a2652b4e2f2d921c5cb009'
for mode,run in [('rust',36764911748),('frozen',36764918696)]:
 state=json.loads((p/('source204-linux-'+mode+'-initial-state.json')).read_text());assert state['headSha']==head and state['databaseId']==run
package('source204-publication',files,{'published_head':head,'verified_inputs':410,'draft_pr':79,'linux_rust_run':36764911748,'linux_frozen_run':36764918696,'qualification':'Runtime publication and exact-head CI launch, not completed full validation. Post-run audit helpers are prepared but have not yet run.'})

files={f.name:f for f in p.glob('source204-allocation-counter-baseline-*') if f.is_file() and f.suffix in {'.json','.stdout','.stderr'}}
for name in ['allocation-counter-baseline.el','probe-allocation-counter-baseline.py',Path(__file__).name]:files[name]=p/name
comparison=json.loads((p/'source204-allocation-counter-baseline-comparison.json').read_text());assert comparison['matches'] is False
for editor in ['gnu','emaxx']:
 result=json.loads((p/('source204-allocation-counter-baseline-'+editor+'-result.json')).read_text());assert result['exit_code']==0 and result['source_unchanged'] and result['inputs_unchanged'] and not result['timed_out']
 for ext in ['stdout','stderr']:assert sha((p/('source204-allocation-counter-baseline-'+editor+'.'+ext)).read_bytes())==result[ext+'_sha256']
local_sources=['src/lisp/primitives/dispatch/misc_keymaps.rs','src/lisp/primitives/tests.rs','src/lisp/eval.rs','src/lisp/eval/variables.rs','src/lisp/eval/symbol_cells.rs','src/lisp/alloc.rs','src/lisp/alloc/symbols.rs','src/lisp/alloc/vectors.rs','src/lisp/types.rs','src/lisp/native_comp/runtime.rs','src/buffer.rs','compat/core_runtime_perf.json','docs/core-runtime-performance-contract.md']
identities={name:sha((root/name).read_bytes()) for name in local_sources}
identities['gnu/src/alloc.c']=sha((p.parent/'recovered-2026-09-30/emacs/src/alloc.c').read_bytes())
with (p/'source204-allocation-accounting-review-inputs.json').open('x') as f:json.dump({'source_head':head,'files':identities,'qualification':'Read-only architecture review of the recorded source. The observed counter failure does not measure total host allocation bytes or current elapsed performance.'},f,indent=2)
files['source204-allocation-accounting-review-inputs.json']=p/'source204-allocation-accounting-review-inputs.json'
package('source204-allocation-counter-baseline',files,{'source_head':head,'ordinary_comparison':'mismatch','sizes':[1,17,257],'observed_gap':'All seven exposed counters lack real updates; memory-use-counts signals unsupported. GNU allocates and reports actual objects/element lengths.','qualification':'Preserved negative baseline, no repair or accounting certification. Counter values must come from actual allocations, not requested loop sizes. Symbol authority, text-property representation, physical byte charges and forwarded variable semantics require completion.'})
