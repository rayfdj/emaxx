from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path(__file__).resolve().parents[3];p=Path(__file__).resolve().parent;recovered=p.parent/'recovered-2026-09-30'; checkout=recovered/'cons-roots/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
manifest=json.loads((p/'source204-manifest.json').read_text())
unchanged=lambda:all(sha(checkout/n)==h for n,h in manifest.items())
assert unchanged()
fixture=p/'allocation-counter-baseline.el'; helper=Path(__file__).resolve()
outputs={};records={}
for editor,binary in [('gnu',recovered/'emacs/src/emacs'),('emaxx',checkout/'target/frame-validation/release/emaxx')]:
 inputs={str(f):sha(f) for f in [fixture,helper,binary,binary.with_suffix('.pdmp')]}
 command=[str(binary),'-Q','--batch','--eval','(prin1 '+fixture.read_text()+')']
 stem='source204-allocation-counter-baseline-'+editor
 with (p/(stem+'-command.json')).open('x') as f:json.dump({'command':command,'working_directory':str(root),'environment_overrides':{'EMAXX_GC_VERIFY':'1'},'timeout_seconds':120,'inputs':inputs,'qualification':'Same ordinary Lisp input; uses source/ABI-matched GNU, not the pinned Darwin executable. No timing claim. Counter deltas are observations, not certification of physical bytes.'},f,indent=2)
 start=time.monotonic()
 try:
  run=subprocess.run(command,cwd=root,env={**os.environ,'EMAXX_GC_VERIFY':'1'},capture_output=True,timeout=120)
  code,stdout,stderr,timed_out=run.returncode,run.stdout,run.stderr,False
 except subprocess.TimeoutExpired as error:
  code,stdout,stderr,timed_out=None,error.stdout or b'',error.stderr or b'',True
 for suffix,data in [('.stdout',stdout),('.stderr',stderr)]:
  with (p/(stem+suffix)).open('xb') as f:f.write(data)
 record={'exit_code':code,'timed_out':timed_out,'elapsed_seconds':time.monotonic()-start,'stdout_sha256':hashlib.sha256(stdout).hexdigest(),'stderr_sha256':hashlib.sha256(stderr).hexdigest(),'inputs_unchanged':all(sha(Path(f))==h for f,h in inputs.items()),'source_unchanged':unchanged()}
 with (p/(stem+'-result.json')).open('x') as f:json.dump(record,f,indent=2)
 records[editor]=record;outputs[editor]=stdout
 assert code==0 and not timed_out and stderr==b'' and record['inputs_unchanged'] and record['source_unchanged']
 print(editor,stdout.decode(),flush=True)
assert outputs['gnu']!=outputs['emaxx']
assert b'(api 7 (t t t t t t t))' in outputs['gnu']
assert b'(api-error (error "GNU allocation counters are unavailable in the Rust ownership backend"))' in outputs['emaxx']
with (p/'source204-allocation-counter-baseline-comparison.json').open('x') as f:json.dump({'matches':False,'outcomes':records,'fixture_sha256':sha(fixture),'source_inputs':410,'qualification':'Confirmed allocation-counter mismatch on current source204. Both ordinary processes succeed. This negative baseline must remain visible after any repair; it is not a passing semantic comparison or physical accounting.'},f,indent=2)
