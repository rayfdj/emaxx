from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/common-strings/emaxx'
gnu = p.parent / 'rebuilt-2026-10-01/emacs'
prefix = 'source' + sys.argv[1]
assert sys.argv[1].isdecimal()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
manifest = json.loads((p / (prefix + '-manifest.json')).read_text())
unchanged = lambda: all(sha(root / name) == digest for name, digest in manifest.items())

def save(suffix, data):
    with (p / (prefix + '-' + suffix + '.json')).open('x') as stream:
        json.dump(data, stream, indent=2)

env = dict(CARGO_TARGET_DIR=str(root / 'target/common-string-validation'), CARGO_BUILD_JOBS='1',
           LANG='C', LC_ALL='C', RUST_MIN_STACK='134217728', RUST_TEST_THREADS='1',
           EMAXX_GC_VERIFY='1', EMAXX_IMAGE_TEMPLATE='1', EMAXX_FIXTURE_IMAGE_DIR=str(p / ('fixture-images-' + prefix)),
           EMAXX_GNU_SOURCE_DIRECTORY=str(gnu), EMAXX_DUMP_SOURCE_DIRECTORY=str(gnu), EMACS_TEST_DIRECTORY=str(gnu / 'test'))
assert unchanged()
for stage in ['check', 'fmt', 'clippy', 'diff']:
    receipt = json.loads((p / (prefix + '-' + stage + '-result.json')).read_text())
    assert receipt['exit_code'] == 0 and receipt['source_unchanged']
    log = (p / (prefix + '-' + stage + '.log')).read_text()
    assert not any(line.startswith('warning:') for line in log.splitlines())

def run(stage, command, metadata=None):
    record = dict(command=command, working_directory=str(root), environment_override=env,
                  source_manifest=prefix + '-manifest.json', helper_sha256=sha(Path(__file__)))
    record.update(metadata or {})
    save(stage + '-command', record)
    started = time.monotonic()
    with (p / (prefix + '-' + stage + '.log')).open('xb') as log:
        result = subprocess.run(command, cwd=root, env=dict(os.environ, **env), stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
    save(stage + '-result', dict(exit_code=result.returncode, elapsed_seconds=time.monotonic() - started, source_unchanged=unchanged()))
    assert unchanged()
    return result.returncode

command = ['cargo', 'test', '--locked', '--all-features', '--profile', 'gate', '--lib', '--no-run', '--message-format=json-render-diagnostics']
if run('gate-build', command):
    sys.exit(1)
artifacts = []
for line in (p / (prefix + '-gate-build.log')).read_text().splitlines():
    if line.startswith('{'):
        message = json.loads(line)
        if message.get('reason') == 'compiler-artifact' and message.get('profile', {}).get('test') and message.get('executable') and message['target']['name'] == 'emaxx':
            artifacts.append(Path(message['executable']))
assert len(artifacts) == 1
binary = p / (prefix + '-gate-libtest')
assert not binary.exists()
shutil.copy2(artifacts[0], binary)
assert sha(binary) == sha(artifacts[0])
if run('gate-inventory', [str(binary), '--list', '--format', 'terse']):
    sys.exit(1)
inventory = [line[:-6] for line in (p / (prefix + '-gate-inventory.log')).read_text().splitlines() if line.endswith(': test')]
assert len(inventory) == len(set(inventory))
old = json.loads((p / 'source249-gate-controls-command.json').read_text())['command']
selectors = {name for name in old[1:] if '::' in name and not name.startswith('-')}
assert len(selectors) == 174
extra_names = {
    'host_created_strings_preserve_mutation_properties_and_fill_errors',
    'vector_held_host_strings_preserve_binding_identity_and_mutation',
    'from_slots_parses_genuine_object',
    'cloning_string_reuses_the_text_allocation',
    'shared_text_equality_covers_shared_and_distinct_equal_allocations',
    'interned_symbol_names_reuse_one_text_allocation',
    'uninterned_symbol_names_remain_reclaimable',
    'uninterned_symbol_keeps_its_supplied_lisp_name',
    'native_strings_share_object_words_for_both_storage_forms',
    'native_gc_traces_string_properties_and_reclaims_string_cycles',
}
extra = [name for name in inventory if name.rsplit('::', 1)[-1] in extra_names]
assert {name.rsplit('::', 1)[-1] for name in extra} == extra_names
selectors.update(extra)
assert selectors <= set(inventory)
save('focused-inventory', dict(selectors=sorted(selectors), full_inventory_count=len(inventory), binary_sha256=sha(binary), prior_controls_preserved=174))
status = run('gate-controls', [str(binary), *sorted(selectors), '--exact', '--test-threads=1', '--nocapture'],
             dict(selectors=sorted(selectors), binary_sha256=sha(binary), expected_tests=len(selectors), existing_ignores=2))
retained = p / (prefix + '-focused-retained-inputs')
retained.mkdir()
files = [binary, *sorted((p / ('fixture-images-' + prefix)).glob('*.pdmp'))]
records = []
for path in files:
    destination = retained / path.name
    shutil.copy2(path, destination)
    assert sha(path) == sha(destination)
    records.append(dict(original=str(path), artifact=str(destination), sha256=sha(path), bytes=path.stat().st_size))
save('focused-retained-inputs', dict(files=records, qualification='Retains executable and every post-run image. Raw test verdicts require a separate audit; no pass is inferred from retention.'))
print(json.dumps(dict(prefix=prefix, exit_code=status, tests=len(selectors), source_unchanged=unchanged())), flush=True)
sys.exit(status)
