from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).parent.resolve();root=p.parent/'recovered-2026-09-30/string-ops/emaxx'
read=lambda name:json.loads((p/name).read_text());sha=lambda file:hashlib.sha256(file.read_bytes()).hexdigest()
manifest=read('source231-manifest.json');assert all(sha(root/name)==h for name,h in manifest.items())
binary=p/'source231-full-failure-inputs/source231-full-gate-libtest';digest=sha(binary)
assert digest==read('source231-full-gate-result.json')['immutable_binary']['sha256']
env_overrides={**read('source231-full-gate-command.json')['environment_override'],**read('full-gate-source231/summary.json')['environment']}
env={**os.environ,**env_overrides}
env.pop('EMAXX_IMAGE_TEMPLATE',None)
for name,extra in [('vector-isolated',['lisp::alloc::vectors::tests::vector_word_offsets_survive_mark_bitmap_boundaries','--exact','--nocapture','--test-threads=1']),('lightweight-repeat',read('full-gate-source231/repeat-01-lightweight.json')['command'][1:])]:
 command=[str(binary),*extra];stem='source231-diagnosis-no-template-'+name
 with (p/(stem+'-command.json')).open('x') as f:json.dump(dict(command=command,working_directory=str(root),environment_override=env_overrides,binary_sha256=digest,source_manifest='source231-manifest.json',environment_removed=['EMAXX_IMAGE_TEMPLATE'],qualification='The preceding diagnostic accidentally enabled image templates by setting the presence-based flag to 0. This replay removes it, matching the original lightweight group; preceding logs remain separate evidence.'),f,indent=2)
 start=time.monotonic()
 with (p/(stem+'.log')).open('x') as f:r=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=120)
 result=dict(exit_code=r.returncode,elapsed_seconds=time.monotonic()-start,source_unchanged=all(sha(root/name)==h for name,h in manifest.items()),binary_unchanged=sha(binary)==digest)
 with (p/(stem+'-result.json')).open('x') as f:json.dump(result,f,indent=2)
 print(name,result,flush=True)
