from pathlib import Path
import ast
import hashlib
import json
import re
import shutil
import sys

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/string-ops/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read('source232-manifest.json')
assert len(manifest) == 440
assert all(sha(root / name) == digest for name, digest in manifest.items())
previous = read('source231-manifest.json')
changed = sorted(name for name in manifest if manifest[name] != previous[name])
assert changed == ['src/lisp/alloc/vectors/tests.rs', 'src/lisp/eval/dump_roots.rs', 'src/lisp/mod.rs']
node = next(n for n in ast.parse((p / 'audit-shared-reader196-fresh-selected.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'audit_log')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<raw-auditor>', 'exec'))
sys.path.insert(0, str(root / 'tools'))
import grouped_gate

inventories, groups, files = {}, [], []
retained = p / 'source232-selected-retained-inputs'
assert not retained.exists()
for profile, count in [('gate', 2981), ('release', 2980)]:
    inventory = grouped_gate.parse_inventory((p / ('source232-' + profile + '-inventory.txt')).read_text())
    assert len(inventory) == len(set(inventory)) == count
    assert inventory == grouped_gate.parse_inventory((p / ('source231-' + profile + '-inventory.txt')).read_text())
    inventories[profile] = inventory
    classified, _ = grouped_gate.classify_inventory(inventory, 'full')
    for group, expected in [('controls', 31), ('lightweight', 545 if profile == 'gate' else 544)]:
        stem = 'source232-' + profile + '-' + group
        command, result = read(stem + '-command.json'), read(stem + '-result.json')
        assert result['exit_code'] == 0 and result['source_unchanged']
        assert sha(p / ('source232-' + profile + '-libtest')) == command['binary_sha256']
        assert command['environment_override']['LANG'] == command['environment_override']['LC_ALL'] == 'C'
        names = command['selected_inventory']
        assert len(names) == len(set(names)) == expected
        if group == 'controls':
            assert names == read('source231-' + profile + '-controls-command.json')['selected_inventory']
            assert command['command'][1:] == names + ['--exact', '--nocapture', '--test-threads=1']
        else:
            assert result['binary_unchanged']
            assert names == classified['lightweight']
            assert command['command'][1:] == read('full-gate-source231/repeat-01-lightweight.json')['command'][1:]
            assert command['environment_removed'] == ['EMAXX_IMAGE_TEMPLATE']
        assert audit_log(names, (p / (stem + '.log')).read_text(), expected, 0) == []
        groups.append(dict(profile=profile, group=group, passed=expected, failed=0, ignored=0))
for stage in ['check', 'fmt', 'clippy', 'diff', 'gate-build', 'release-build']:
    result = read('source232-' + stage + '-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
    raw = (p / ('source232-' + stage + '.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
    for line in raw.splitlines():
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        assert item.get('message', {}).get('level') not in ['error', 'warning']
assert all(stage['exit_code'] == 0 for stage in read('source232-validation-result.json'))
retained.mkdir()
for profile in inventories:
    binary = p / ('source232-' + profile + '-libtest')
    files.append(dict(retained=str(binary), sha256=sha(binary), bytes=binary.stat().st_size))
    images = sorted((p / 'fixture-images-source232').glob('loadup-' + sha(binary)[:8] + '-*.pdmp'))
    assert len(images) == 1
    for image in images:
        dest = retained / image.name
        shutil.copy2(image, dest)
        assert sha(image) == sha(dest)
        files.append(dict(original=str(image), retained=str(dest), sha256=sha(dest), bytes=dest.stat().st_size))
record = dict(status='selected gate and release validation passes', goal_complete=False,
              source_inputs_verified=440, changed_from_source231=changed,
              strict_checks='zero warnings', groups=groups, retained_files=files,
              qualification='All original five failed controls pass in the unchanged complete lightweight-group selectors in both profiles. All 31 focused bytecode/string controls also pass per profile. No runtime semantics are changed; root metadata and two local controls are repaired against GNU evidence while preserving their contracts. Post-run images are retained without a per-test image-use claim. Full macOS, Linux, terminal and performance requirements remain open.')
with (p / 'source232-selected-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: record[key] for key in ['status', 'source_inputs_verified', 'groups']}, indent=2))
