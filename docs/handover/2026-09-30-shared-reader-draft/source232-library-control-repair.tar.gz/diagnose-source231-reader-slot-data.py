from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).parent.resolve();root=p.parent/'recovered-2026-09-30/string-ops/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
manifest=json.loads((p/'source231-manifest.json').read_text());assert all(sha(root/n)==h for n,h in manifest.items())
artifacts=json.loads((p/'source231-ordinary-artifacts.json').read_text())
program='(prin1 (let ((reader-data-called nil)) (fset (quote reader-data-must-not-be-called) (lambda (&rest _) (setq reader-data-called t))) (let ((object (read "#[0 \"\" [] 0 (reader-data-must-not-be-called payload)]"))) (list (byte-code-function-p object) (recordp object) (length object) (equal (aref object 4) (quote (reader-data-must-not-be-called payload))) reader-data-called))))'
expected=b'(t nil 5 t nil)'
executables={'gnu':p.parent/'recovered-2026-09-30/emacs/src/emacs','emaxx':root/'target/frame-validation/release/emaxx'}
for editor,binary in executables.items():
 stem='source231-reader-slot-data-'+editor
 inputs={str(f):sha(f) for f in [binary,Path(str(binary)+'.pdmp')]}
 assert all(artifacts[str(f)]['sha256']==digest for f,digest in inputs.items())
 command=[str(binary),'-Q','--batch','--eval',program]
 with (p/(stem+'-command.json')).open('x') as f:json.dump(dict(command=command,working_directory=str(root),environment_override={'LANG':'C','LC_ALL':'C'},inputs=inputs),f,indent=2)
 start=time.monotonic();r=subprocess.run(command,cwd=root,env={**os.environ,'LANG':'C','LC_ALL':'C'},capture_output=True,timeout=60)
 for suffix,data in [('stdout',r.stdout),('stderr',r.stderr)]:
  with (p/(stem+'.'+suffix)).open('xb') as f:f.write(data)
 result=dict(exit_code=r.returncode,stdout=r.stdout.decode(),stderr=r.stderr.decode(),elapsed_seconds=time.monotonic()-start,source_unchanged=all(sha(root/n)==h for n,h in manifest.items()),inputs_unchanged=all(sha(Path(n))==h for n,h in inputs.items()))
 with (p/(stem+'-result.json')).open('x') as f:json.dump(result,f,indent=2)
 print(editor,result,flush=True)
 assert r.returncode==0 and r.stdout==expected and r.stderr==b'' and result['source_unchanged'] and result['inputs_unchanged']
