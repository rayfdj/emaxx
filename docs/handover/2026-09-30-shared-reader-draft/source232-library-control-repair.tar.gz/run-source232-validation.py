from pathlib import Path
import json, subprocess, sys, time

p = Path(__file__).parent.resolve()
stages = [
    ('check', ['python3', str(p / 'check-string230.py'), '232']),
    ('strict', ['python3', str(p / 'static-string230.py'), '232']),
    ('gate-controls', ['python3', str(p / 'test-string-controls230.py'), '232', 'gate']),
    ('gate-lightweight', ['python3', str(p / 'test-source232-lightweight.py'), 'gate']),
    ('release-controls', ['python3', str(p / 'test-string-controls230.py'), '232', 'release']),
    ('release-lightweight', ['python3', str(p / 'test-source232-lightweight.py'), 'release']),
]
results = []
for stage, command in stages:
    start = time.monotonic()
    print('START', stage, flush=True)
    result = subprocess.run(command, cwd=p.parents[2])
    record = dict(stage=stage, command=command, exit_code=result.returncode,
                  elapsed_seconds=time.monotonic() - start)
    results.append(record)
    print('END', stage, record, flush=True)
    if result.returncode:
        break
with (p / 'source232-validation-result.json').open('x') as stream:
    json.dump(results, stream, indent=2)
sys.exit(next((r['exit_code'] for r in results if r['exit_code']), 0))
