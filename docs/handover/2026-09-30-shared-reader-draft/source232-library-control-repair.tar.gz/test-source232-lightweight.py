from pathlib import Path
import hashlib, json, os, re, subprocess, sys, time

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/string-ops/emaxx'
profile = sys.argv[1]
assert profile in ['gate', 'release']
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read('source232-manifest.json')
unchanged = lambda: all(sha(root / name) == digest for name, digest in manifest.items())
assert unchanged()
sys.path.insert(0, str(root / 'tools'))
import grouped_gate

binary = p / ('source232-' + profile + '-libtest')
digest = sha(binary)
assert digest == read('source232-' + profile + '-controls-command.json')['binary_sha256']
inventory = grouped_gate.parse_inventory((p / ('source232-' + profile + '-inventory.txt')).read_text())
groups, _ = grouped_gate.classify_inventory(inventory, 'full')
names = groups['lightweight']
assert len(names) == (545 if profile == 'gate' else 544)
assert len(names) == len(set(names))
original = read('full-gate-source231/repeat-01-lightweight.json')['command'][1:]
command = [str(binary), *original]
env = grouped_gate.gate_environment(False)
overrides = read('source231-full-gate-command.json')['environment_override']
env.update(overrides)
assert 'EMAXX_IMAGE_TEMPLATE' not in env
stem = 'source232-' + profile + '-lightweight'
with (p / (stem + '-command.json')).open('x') as stream:
    json.dump(dict(command=command, working_directory=str(root), source_manifest='source232-manifest.json',
                   environment_override={name: env[name] for name in set(overrides) | {'LANG', 'LC_ALL', 'RUST_MIN_STACK', 'RUST_TEST_THREADS', 'RUST_BACKTRACE', 'EMAXX_FIXTURE_IMAGE_DIR'}},
                   environment_removed=['EMAXX_IMAGE_TEMPLATE'], binary_sha256=digest,
                   selected_inventory=names, qualification='Original complete lightweight-group selectors and no-template environment. The release inventory retains its one existing debug-only difference; no assertion, ignore or timeout changes.'), stream, indent=2)
start = time.monotonic()
with (p / (stem + '.log')).open('x') as log:
    completed = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=3600)
result = dict(exit_code=completed.returncode, elapsed_seconds=time.monotonic() - start,
              source_unchanged=unchanged(), binary_unchanged=sha(binary) == digest)
with (p / (stem + '-result.json')).open('x') as stream:
    json.dump(result, stream, indent=2)
print(stem, json.dumps(result), flush=True)
print('\n'.join((p / (stem + '.log')).read_text().splitlines()[-16:]), flush=True)
sys.exit(completed.returncode or (0 if result['source_unchanged'] and result['binary_unchanged'] else 1))
