from pathlib import Path
import json, subprocess, sys, time

p = Path(__file__).parent.resolve()
stages = [('check', 'check-string217.py', ['224']),
          ('strict', 'static-string217.py', ['224']),
          ('gate-controls', 'test-string-controls224.py', ['224', 'gate']),
          ('release-controls', 'test-string-controls224.py', ['224', 'release'])]
results = []
for stage, helper, args in stages:
    command = ['python3', str(p / helper), *args]
    print('START', stage, flush=True)
    start = time.monotonic()
    result = subprocess.run(command, cwd=p.parents[2])
    record = dict(stage=stage, command=command, exit_code=result.returncode, elapsed_seconds=time.monotonic() - start)
    results.append(record)
    print('END', stage, record, flush=True)
    if result.returncode:
        break
with (p / 'source224-validation-result.json').open('x') as stream:
    json.dump(results, stream, indent=2)
    stream.write('\n')
sys.exit(next((r['exit_code'] for r in results if r['exit_code']), 0))
