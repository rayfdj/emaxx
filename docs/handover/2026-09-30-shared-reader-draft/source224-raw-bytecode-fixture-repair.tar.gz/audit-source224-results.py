from pathlib import Path
import ast, hashlib, json, re, shutil

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/string-bytes/emaxx'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest, before = read('source224-manifest.json'), read('source223-manifest.json')
assert len(manifest) == 425 and manifest.keys() == before.keys()
assert [name for name in manifest if manifest[name] != before[name]] == ['src/lisp/bytecode/vm.rs']
assert all(sha(root / name) == digest for name, digest in manifest.items())
text = (root / 'src/lisp/bytecode/vm.rs').read_text()
reconstructed = text.replace('''                primitives::bytes_to_shared_unibyte_value(&[192, 193, 92, 135]),
                Value::vector([Value::Integer(40), Value::Integer(2)]),''', '''                Value::String("\\u{c0}\\u{c1}\\u{5c}\\u{87}".into()),
                Value::list([
                    Value::symbol("vector-literal"),
                    Value::Integer(40),
                    Value::Integer(2),
                ]),''').replace('''        // constant0; constant1; plus; return with constants [40 2].
        // bytecode.c:Fbyte_code converts multibyte input with
        // string-as-unibyte. Actual Unicode U+00C0/U+00C1 encode as
        // C3 80/C3 81, not the C0/C1 constant opcodes required here.''',
        '        // constant0; constant1; plus; return  with constants [40 2].')
assert hashlib.sha256(reconstructed.encode()).hexdigest() == before['src/lisp/bytecode/vm.rs']
node = next(n for n in ast.parse((p / 'audit-shared-reader196-fresh-selected.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'audit_log')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<raw-auditor>', 'exec'))
groups = []
for profile in ['gate', 'release']:
    stem = 'source224-' + profile + '-controls'
    command, result = read(stem + '-command.json'), read(stem + '-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
    assert sha(p / ('source224-' + profile + '-libtest')) == command['binary_sha256']
    names = command['selected_inventory']
    assert set(names) == set(read('source223-' + profile + '-controls-command.json')['selected_inventory']) | {
        'lisp::bytecode::vm::native_surface_tests::byte_code_primitive_executes_program'}
    assert audit_log(names, (p / (stem + '.log')).read_text(), 18, 0) == []
    groups.append(dict(profile=profile, passed=18, failed=0, ignored=0, inventory_verified=len(names)))
for stage in ['check', 'fmt', 'clippy', 'diff', 'gate-build', 'release-build']:
    result = read('source224-' + stage + '-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
    raw = (p / ('source224-' + stage + '.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
    for line in raw.splitlines():
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        assert item.get('message', {}).get('level') not in ['error', 'warning']
retained = p / 'source224-retained-inputs'
retained.mkdir()
files = []
for source in [p / 'source224-gate-libtest', p / 'source224-release-libtest', *sorted((p / 'fixture-images-source224').glob('*.pdmp'))]:
    target = retained / source.name
    digest = sha(source)
    shutil.copy2(source, target)
    assert sha(source) == sha(target) == digest
    files.append(dict(original=str(source), retained=str(target), sha256=digest, bytes=target.stat().st_size))
record = dict(status='GNU-backed fixture correction passes in both profiles', inputs_verified=len(manifest),
              production_runtime_unchanged_from='source223', strict_checks='passed with zero warnings',
              groups=groups, retained_files=files,
              qualification='Only the old raw byte-code test inputs and explanatory comment change. Both original result assertions are byte-for-byte preserved. All 18 controls pass in each fresh profile. Source223 broader failures remain recorded under source223, not relabeled as a passing source224 run. A separate review found eager destination validation on untaken branches; source225 is prepared to repair it. Stack capacity/accounting and the full goal remain open.')
with (p / 'source224-results-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record, indent=2))
