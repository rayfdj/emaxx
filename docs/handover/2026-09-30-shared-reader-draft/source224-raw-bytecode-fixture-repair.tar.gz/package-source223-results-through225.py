from pathlib import Path
import ast, gzip, hashlib, io, json, re, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
tree = ast.parse((p / 'package-source196-failure-and197-results.py').read_text())
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected'}

audit = read('source223-results-audit.json')
assert [(g['passed'], g['failed']) for g in audit['groups']] == [(17, 0), (929, 1), (17, 0), (929, 1)]
files = {f.name: f for f in p.iterdir() if f.is_file() and f.suffix in allowed
         and f.name.startswith(('source223-', 'raw-bytecode-constructor-inputs-'))}
helpers = ['audit-source223-results.py', 'run-source223-release.py', 'run-string-validation222.py',
           'test-string-controls222.py', 'test-string-broad219.py', 'raw-bytecode-constructor-inputs.el',
           'run-raw-bytecode-inputs-reference.py', Path(__file__).name]
files.update({name: p / name for name in helpers})
package('source223-direct-bytecode-results', files, audit)

audit = read('source224-results-audit.json')
assert all(g['passed'] == 18 and g['failed'] == 0 for g in audit['groups'])
files = {f.name: f for f in p.iterdir() if f.is_file() and f.suffix in allowed and f.name.startswith('source224-')}
helpers = ['audit-source224-results.py', 'prepare-source224-raw-fixture.py', 'run-source224-validation.py',
           'test-string-controls224.py', 'check-string217.py', 'static-string217.py', 'freeze-string-candidate.py',
           'audit-source224-through225-patches.py', Path(__file__).name]
files.update({name: p / name for name in helpers})
package('source224-raw-bytecode-fixture-repair', files, audit)

candidate = p.parent / 'recovered-2026-09-30/string-bytes/emaxx'
manifest = read('source225-manifest.json')
assert len(manifest) == 427 and all(sha((candidate / name).read_bytes()) == digest for name, digest in manifest.items())
for stage in ['check', 'fmt', 'clippy', 'diff']:
    result = read('source225-' + stage + '-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
    assert not re.search(r'^warning(?:\[.*\])?:', (p / ('source225-' + stage + '.log')).read_text(), re.M)
files = {f.name: f for f in p.iterdir() if f.is_file() and f.suffix in allowed
         and f.name.startswith(('bytecode-unused-destinations-', 'vm-stack-capacity-'))}
names = ['source225-base.json', 'source225-manifest.json', 'source225-complete.patch', 'source225-launch.json',
         'prepare-source225-branch-fetch.py', 'refine-source225-fast-fetch.py', 'run-string-validation225.py',
         'test-string-controls225.py', 'test-string-broad219.py', 'check-string217.py', 'static-string217.py',
         'freeze-string-candidate.py', 'source224-through225-patch-replay-and-modes-audit.json',
         'bytecode-unused-destinations.el', 'run-bytecode-unused-destinations-reference.py',
         'vm-stack-capacity.el', 'probe-vm-stack-capacity.py', Path(__file__).name]
for stage in ['check', 'fmt', 'clippy', 'diff']:
    names += ['source225-' + stage + suffix for suffix in ['-command.json', '-result.json', '.log']]
files.update({name: p / name for name in names})
package('source225-control-flow-draft', files, dict(status='isolated control-flow repair; runtime validation running', source_inputs=427,
    strict_checks='passed with zero warnings', supervisor=read('source225-launch.json')['pid'],
    qualification='Only actual PC fetches check code boundaries; untaken branch and unentered handler destinations do not signal early. A fetched instruction crosses fast/slow dispatch without a second decode. GNU same-input reference and Rust error/frame cleanup controls are permanent, but this draft assigns no runtime verdict. A separate ordinary source207 probe preserves a still-open stack-capacity mismatch: GNU accepts 262144/393216 declared slots while Emaxx overflows. Current Rust reserves 256K Lisp words and separate frames; GNU reserves 512K words including frames. No physical-accounting, complete-validation or performance claim.'))
