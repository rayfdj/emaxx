from pathlib import Path
import hashlib, json

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/string-bytes/emaxx'
manifest = json.loads((p / 'source223-manifest.json').read_text())
assert all(hashlib.sha256((root / name).read_bytes()).hexdigest() == digest for name, digest in manifest.items())
result = json.loads((p / 'raw-bytecode-constructor-inputs-gnu-result.json').read_text())
assert result['exit_code'] == 0 and result['inputs_unchanged']
assert (p / 'raw-bytecode-constructor-inputs-gnu.stdout').read_text() == '((t (195 128 195 129 92 194 135)) 42 42)'
name = 'src/lisp/bytecode/vm.rs'
old = (root / name).read_text()
start = old.index('    fn byte_code_primitive_executes_program()')
prefix, test = old[:start], old[start:]
before = '''                Value::String("\\u{c0}\\u{c1}\\u{5c}\\u{87}".into()),
                Value::list([
                    Value::symbol("vector-literal"),
                    Value::Integer(40),
                    Value::Integer(2),
                ]),'''
after = '''                primitives::bytes_to_shared_unibyte_value(&[192, 193, 92, 135]),
                Value::vector([Value::Integer(40), Value::Integer(2)]),'''
assert test.count(before) == 1
test = test.replace(before, after)
test = test.replace('        // constant0; constant1; plus; return  with constants [40 2].', '''        // constant0; constant1; plus; return with constants [40 2].
        // bytecode.c:Fbyte_code converts multibyte input with
        // string-as-unibyte. Actual Unicode U+00C0/U+00C1 encode as
        // C3 80/C3 81, not the C0/C1 constant opcodes required here.''')
target = p / 'source224-proposed' / name
target.parent.mkdir(parents=True)
with target.open('x') as stream:
    stream.write(prefix + test)
print('Prepared only the GNU-invalid test input; both original result assertions retained')
