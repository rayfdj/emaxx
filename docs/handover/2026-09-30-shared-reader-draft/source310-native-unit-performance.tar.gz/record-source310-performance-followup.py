from pathlib import Path
import hashlib, json, statistics
p=Path(__file__).parent.resolve()
read=lambda n:json.loads((p/n).read_text())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
audit=read('native-unit310-performance-audit.json')
profiles=read('source310-mixed-profile-result.json')
assert audit['status']=='all 192 processes and actual results/modes verified'
assert profiles['inputs_unchanged'] and len(profiles['results'])==3 and all(r['validation']=='completed' and r['samples']==20 for r in profiles['results'])
assert read('native-unit310-publication-validation-result.json')['status']=='timing and profiles closed; exact-source full macOS validation launched'
rows=[]
for case in audit['cases']:
 row={k:case[k] for k in ['case','emaxx_median_seconds','median_gnu_ratios','optimized_over_baseline']}
 row['process_medians']={}
 for tag,samples in case['samples'].items():
  row['process_medians'][tag]={}
  for editor in ['emaxx','oracle']:
   row['process_medians'][tag][editor]={key:statistics.median(s[editor]['process'][key] for s in samples) for key in ['startup_seconds','total_seconds','user_seconds','system_seconds','peak_rss_bytes']}
   row['process_medians'][tag][editor]['body_gc_count']=statistics.median(s[editor]['observation']['gc_count'] for s in samples)
   row['process_medians'][tag][editor]['body_gc_seconds']=statistics.median(s[editor]['observation']['gc_seconds'] for s in samples)
 rows.append(row)
record=dict(status='published correctness repair retained; diagnostic performance closed',commit=read('source310-applied-commit.json')['commit'],
 original_application_decision_sha256=sha(p/'source310-application-decision.json'),
 audit_sha256=sha(p/'native-unit310-performance-audit.json'),profiles_sha256=sha(p/'source310-mixed-profile-result.json'),
 raw_body_geometric_ratio=audit['geometric_mean_optimized_over_baseline'],gnu_geometric_ratios=audit['geometric_mean_gnu_ratios'],cases=rows,
 slower_cases=[dict(case=r['case'],ratio=r['optimized_over_baseline']) for r in rows if r['optimized_over_baseline']>1],
 profiles=profiles['results'],
 decision='Retain the GNU-layout unit and owner repair for actual object authority, reclamation and host-runtime ownership. The three-pilot body geometric ratio improves; native execution, cons allocation and list traversal remain slower in the raw medians and are not hidden or declared statistically significant.',
 qualification='All192 actual answers and execution modes match, with unchanged locked16 workloads and every sample retained. Profiling ran separately. Process/startup/body time, GC deltas and peak RSS remain distinct. Removing permanent native-unit retention changes the live graph; the explicit-GC gain is consistent with that repair but no isolated causal attribution or shutdown-cost estimate is established. The initial publication decision correctly records timing as pending at publication and is not rewritten. Missing real allocation counters, calibration, nine rounds, every-case upper95% ratio<=1.03, remaining architecture and complete final-source validation/audit still prevent goal completion.',goal_complete=False)
(p/'source310-performance-followup.json').open('x').write(json.dumps(record,indent=2))
print(json.dumps({k:record[k] for k in ['status','raw_body_geometric_ratio','gnu_geometric_ratios','slower_cases']},indent=2))
