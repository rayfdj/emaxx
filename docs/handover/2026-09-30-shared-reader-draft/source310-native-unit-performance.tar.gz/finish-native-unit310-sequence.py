from pathlib import Path
import hashlib, json, subprocess, sys, time

p = Path(__file__).parent.resolve()
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p / n).read_text())
helpers = {n: sha(p / n) for n in [Path(__file__).name, 'audit-native-unit310-selected-resumed.py',
    'native_fixed_validation_support.py', 'measure-native-unit310.py', 'audit-native-unit310-performance.py',
    'audit-source308-macos-terminal.py']}
state = dict(status='waiting for selected validation and ordinary GNU comparisons',
             helpers=helpers, results=[], goal_complete=False)
def save():
    (p / 'native-unit310-sequence-state.json').write_text(json.dumps(state, indent=2))
def wait_for(name):
    while not (p / name).exists():
        time.sleep(20)
    return read(name)
def run(stage, helper):
    assert all(sha(p / n) == h for n, h in helpers.items())
    command = [sys.executable, '-B', str(p / helper)]
    state['status'] = 'running ' + stage
    save()
    (p / ('native-unit310-sequence-' + stage + '-command.json')).open('x').write(json.dumps(
        dict(command=command, working_directory=str(p), helpers=helpers, timeout_seconds=21600), indent=2))
    start = time.monotonic()
    with (p / ('native-unit310-sequence-' + stage + '.log')).open('xb') as log:
        try:
            r = subprocess.run(command, cwd=p, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, timeout=21600)
            code, timed_out = r.returncode, False
        except subprocess.TimeoutExpired:
            code, timed_out = None, True
    result = dict(stage=stage, exit_code=code, timed_out=timed_out, elapsed_seconds=time.monotonic()-start,
                  helpers_unchanged=all(sha(p / n) == h for n, h in helpers.items()))
    state['results'].append(result)
    save()
    print(json.dumps(result), flush=True)
    assert code == 0 and not timed_out and result['helpers_unchanged'], result
save()
try:
    validation = wait_for('source310-resumed-validation-result.json')
    assert validation['status'] == 'strict, selected and ordinary build passed; raw audit and ordinary comparisons required'
    ordinary = wait_for('source310-resumed-ordinary-queue-result.json')
    assert ordinary['status'] == 'ordinary comparisons passed; independent raw audit required'
    run('selected-audit', 'audit-native-unit310-selected-resumed.py')
    assert read('source310-selected-audit.json')['status'] == 'passed'
    state['status'] = 'waiting for source308 terminal and oracle verification to finish before timing'
    save()
    mac = wait_for('source308-full-queue-result.json')
    assert mac['status'] == 'complete macOS processes finished; raw evidence requires audit'
    assert all(r['source_unchanged'] and r['fixed_inputs_unchanged'] and r['selected_source_unchanged']
               for r in mac['results'])
    assert any(r['stage'] == 'oracle-verify' and r['exit_code'] == 0 for r in mac['results'])
    # The six known frozen skip-diagnostic differences stay failed. A complete
    # terminal result is independently audited, without rewriting frozen status.
    run('source308-terminal-audit', 'audit-source308-macos-terminal.py')
    assert read('source308-macos-terminal-audit.json')['status'] == 'passed'
    run('performance', 'measure-native-unit310.py')
    run('performance-audit', 'audit-native-unit310-performance.py')
    state['status'] = 'selected correctness and diagnostic timing audited; application decision required'
except Exception as error:
    state.update(status='sequence stopped', error=repr(error))
finally:
    save()
    (p / 'native-unit310-sequence-result.json').open('x').write(json.dumps(state, indent=2))
print(json.dumps(state), flush=True)
sys.exit(0 if state['status'].startswith('selected correctness') else 1)
