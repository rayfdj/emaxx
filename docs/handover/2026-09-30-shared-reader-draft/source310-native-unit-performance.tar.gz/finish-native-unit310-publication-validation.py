from pathlib import Path
import hashlib, json, subprocess, sys, time

p = Path(__file__).parent.resolve()
root = p.parents[2]
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p / n).read_text())
commit = read('source310-applied-commit.json')['commit']
helpers = {n: sha(p / n) for n in [Path(__file__).name, 'profile-source310-mixed.py',
    'setup-source310-full-macos.py', 'queue-source310-full-macos.py', 'audit-source310-selected-for-full.py']}
state = dict(status='waiting for closed source310 diagnostic timing', commit=commit,
             helpers=helpers, results=[], goal_complete=False)
def save():
    (p / 'native-unit310-publication-validation-state.json').write_text(json.dumps(state, indent=2))
def run(stage, helper):
    assert all(sha(p / n) == h for n, h in helpers.items())
    command = [sys.executable, '-B', str(p / helper)]
    state['status'] = 'running ' + stage
    save()
    (p / ('native-unit310-publication-' + stage + '-command.json')).open('x').write(json.dumps(
        dict(command=command, working_directory=str(root), helpers=helpers, timeout_seconds=1800), indent=2))
    start = time.monotonic()
    with (p / ('native-unit310-publication-' + stage + '.log')).open('xb') as log:
        try:
            r = subprocess.run(command, cwd=root, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, timeout=1800)
            code, timed_out = r.returncode, False
        except subprocess.TimeoutExpired:
            code, timed_out = None, True
    result = dict(stage=stage, exit_code=code, timed_out=timed_out, elapsed_seconds=time.monotonic()-start,
                  helpers_unchanged=all(sha(p / n) == h for n, h in helpers.items()))
    state['results'].append(result)
    save()
    print(json.dumps(result), flush=True)
    assert code == 0 and not timed_out and result['helpers_unchanged'], result
save()
try:
    while not (p / 'native-unit310-sequence-result.json').exists():
        time.sleep(20)
    assert read('native-unit310-sequence-result.json')['status'] == 'selected correctness and diagnostic timing audited; application decision required'
    # Keep profiling separate from every authoritative pilot, then start the
    # complete local validation on the already published exact source.
    run('profiles', 'profile-source310-mixed.py')
    profiles = read('source310-mixed-profile-result.json')
    assert profiles['inputs_unchanged'] and len(profiles['results']) == 3
    assert all(r['validation'] == 'completed' and r['samples'] == 20 for r in profiles['results'])
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == commit
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True).strip()
    run('full-macos-launch', 'setup-source310-full-macos.py')
    assert read('source310-full-launch.json')['validation_commit'] == commit
    state['status'] = 'timing and profiles closed; exact-source full macOS validation launched'
except Exception as error:
    state.update(status='publication validation sequence stopped', error=repr(error))
finally:
    save()
    (p / 'native-unit310-publication-validation-result.json').open('x').write(json.dumps(state, indent=2))
print(json.dumps(state), flush=True)
