from pathlib import Path
import hashlib, json, re
from native_fixed_validation_support import audit_selected

p = Path(__file__).parent.resolve()
c = p.parent / 'recovered-2026-10-06/native-unit-owners/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p / n).read_text())
manifest = read('source310-manifest.json')
modes = read('source310-modes.json')
assert len(manifest) == len(modes) == 546
assert all(sha(c / n) == h and (c / n).stat().st_mode & 0o777 == modes[n] for n, h in manifest.items())
prior = read('source309-manifest.json')
assert all(manifest[n] == h for n, h in prior.items() if n.startswith(('tests/', 'tools/', 'compat/')))
assert manifest['src/anti_cheat.rs'] == prior['src/anti_cheat.rs']
for n in manifest:
    if n.endswith('.rs'):
        raw = (c / n).read_text()
        assert all(old not in raw for old in ['RecordKind::NativeCompUnit', 'NativeRegistry', 'struct LoadedUnit'])
original = read('source310-validation-result.json')
assert original['status'] == 'validation stopped'
assert all(r['exit_code'] == 0 and not r['timed_out'] and r['source_unchanged'] for r in original['results'][:-1])
assert original['results'][-1]['stage'] == 'gate-selected' and original['results'][-1]['exit_code'] == 101
assert sha(p / original['runner']) == original['runner_sha256']
recovery = read('source310-validation-input-recovery.json')
assert all(sha(p / n) == h for n, h in recovery['preserved_failed_attempt'].items())
assert recovery['original_failed_selection']['passed'] == 1032 and recovery['original_failed_selection']['failed'] == 4
assert len(recovery['auxiliary_inputs']) == 94
assert all(sha(c / n) == item['sha256'] and (c / n).stat().st_mode & 0o777 == item['mode']
           for n, item in recovery['auxiliary_inputs'].items())
restored = audit_selected((p / 'source310-resumed-restored-audit-controls.log').read_text(),
                          recovery['original_failed_selection']['failed_names'])
assert restored['passed'] == 4
state = read('source310-resumed-validation-result.json')
assert state['validation_input_recovery_sha256'] == sha(p / 'source310-validation-input-recovery.json')

assert state['status'] == 'strict, selected and ordinary build passed; raw audit and ordinary comparisons required'
assert all(r['exit_code'] == 0 and not r['timed_out'] and r['source_unchanged'] for r in state['results'])
assert sha(p / state['runner']) == state['runner_sha256']
new = {
    'lisp::alloc::vectors::tests::native_unit_allocation_has_actual_gnu_fields_and_direct_tagged_identity',
    'lisp::alloc::vectors::tests::native_unit_traces_seven_fields_from_a_subr_and_collects_the_unreachable_cycle',
    'lisp::native_comp::loader::tests::native_unit_relocations_decode_the_actual_allocation_without_a_registry',
    'lisp::native_comp::loader::tests::native_unit_reloads_preserve_the_owning_runtime_until_its_shutdown',
    'lisp::primitives::tests::native_unit_fields_preserve_gnu_printing_identity_properties_and_errors',
}
profiles = {}
for profile, required in [('gate', 3053), ('release', 3052)]:
    inventory = lambda tag: [line[:-6] for line in (p / f'{tag}-{profile}-inventory.log').read_text().splitlines() if line.endswith(': test')]
    names = inventory('source310-resumed')
    assert len(names) == len(set(names)) == required
    assert set(names) == set(inventory('source309')) | new
    baseline = set(read('source309-validation-result.json')['profiles'][profile]['selectors'])
    selected = [n for n in names if n in baseline or re.search(r'native|pdump|dump_|image|module|weak|thread|suspended|purecopy|hash|value_|print|command|completion|substitut|propert', n)]
    assert len(baseline) == 1035 and len(selected) == 1036 and baseline | new <= set(selected)
    assert len([n for n in selected if n.startswith('anti_cheat::')]) == 24
    record = state['profiles'][profile]
    assert record['selectors'] == selected
    focused = audit_selected((p / f'source310-resumed-{profile}-focused.log').read_text(), sorted(new))
    counts = audit_selected((p / f'source310-resumed-{profile}-selected.log').read_text(), selected)
    assert focused['passed'] == 5 and counts['passed'] == record['passed'] == 1036
    assert sha(Path(record['binary'])) == sha(Path(record['retained_binary'])) == record['binary_sha256']
    for item in record['retained_inputs']:
        assert sha(Path(item['original'])) == sha(Path(item['retained'])) == item['sha256']
    messages = [json.loads(line) for line in (p / (('source310-' if profile == 'gate' else 'source310-resumed-') + profile + '-build.log')).read_text().splitlines() if line.startswith('{')]
    artifacts = [a for a in messages if a.get('reason') == 'compiler-artifact' and a['target']['name'] == 'emaxx' and a.get('profile', {}).get('test') and a.get('executable')]
    assert len(artifacts) == 1 and artifacts[0]['fresh'] is False and artifacts[0]['executable'] == record['binary']
    profiles[profile] = dict(**counts, focused=focused, selectors=selected, binary_sha256=record['binary_sha256'])
for stage in ['fmt', 'check', 'clippy', 'diff', 'gate-build', 'release-build', 'ordinary-build']:
    prefix = 'source310-' if stage in ['fmt', 'check', 'clippy', 'diff', 'gate-build'] else 'source310-resumed-'
    raw = (p / (prefix + stage + '.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
    for line in raw.splitlines():
        if line.startswith('{'):
            assert json.loads(line).get('message', {}).get('level') not in ['warning', 'error']
artifacts = read('source310-ordinary-artifacts.json')
assert all(sha(Path(f)) == sha(Path(v['immutable_copy'])) == v['sha256'] for f, v in artifacts.items())
portable = read('source310-portable-draft-audit.json')
assert len(portable['patches']) == 2
for record in portable['patches']:
    assert record['inputs'] == 546 and record['bytes_and_modes'] == 'exact' and sha(p / record['patch']) == record['sha256']
ordinary = {}
names = list(read('source304-selected-audit.json')['ordinary_results']) + ['native-subr-authority', 'native-subr-c-names', 'native-subr-consumers', 'native-unit-authority']
assert len(names) == len(set(names)) == 52
for name in names:
    prefix = 'source310-ordinary-' + name
    comparison = read(prefix + '-comparison.json')
    assert comparison['passed'] and comparison['exact_match'], name
    outputs = []
    for editor in ['gnu', 'emaxx']:
        stem = prefix + '-' + editor
        result = read(stem + '.result.json')
        command = read(stem + '.command.json')
        assert all(sha(Path(f)) == h for f, h in command['inputs'].items())
        assert result['exit_code'] == 0 and not result['timed_out'] and result['inputs_unchanged'] and result['source_unchanged'] and result['expected_output'] is not False
        stdout, stderr = (p / (stem + '.stdout')).read_bytes(), (p / (stem + '.stderr')).read_bytes()
        assert stdout and not stderr and hashlib.sha256(stdout).hexdigest() == result['stdout_sha256']
        outputs.append(stdout)
    assert outputs[0] == outputs[1]
    ordinary[name] = comparison
driver = p / 'source310-native-c-names-loaded-driver.el'
assert driver.read_text() == ';; -*- coding: utf-8; lexical-binding: nil; -*-\n(prin1 ' + (c / 'tests/fixtures/native-subr-c-names.el').read_text() + ')\n'
for editor in ['gnu', 'emaxx']:
    command = read('source310-ordinary-native-subr-c-names-' + editor + '.command.json')
    assert command['command'][-2:] == ['-l', str(driver)]
assert read('source310-generated-loaded-comparison.json')['passed']
for editor in ['gnu', 'emaxx']:
    stem = 'source310-generated-loaded-' + editor
    result = read(stem + '-result.json')
    command = read(stem + '-command.json')
    assert all(sha(Path(f)) == h for f, h in command['inputs'].items())
    stdout = (p / (stem + '.stdout')).read_bytes()
    assert result['exit_code'] == 0 and not result['timed_out'] and result['inputs_unchanged'] and result['source_unchanged']
    assert len(stdout) == 4088269 and len(stdout.splitlines()) == 198 and stdout == (p / 'printer-varied-v3-gnu.stdout').read_bytes()
    assert not (p / (stem + '.stderr')).read_bytes()
queue = read('source310-resumed-ordinary-queue-result.json')
assert queue['status'] == 'ordinary comparisons passed; independent raw audit required'
assert all(sha(p / n) == h for n, h in queue['helpers'].items())
assert len(queue['steps']) == 8
assert all(r['exit_code'] == 0 and not r['timed_out'] and r['inputs_unchanged'] for r in queue['steps'])
for kind, stages in [('file', ['compile', 'execute']), ('active', ['compile-caller', 'compile-worker', 'execute'])]:
    for editor in ['gnu', 'source310']:
        directory = p / ('source310-' + kind + '-lifecycle-' + editor)
        for stage in stages:
            command = json.loads((directory / (stage + '-command.json')).read_text())
            result = json.loads((directory / (stage + '-result.json')).read_text())
            assert result['exit_code'] == 0 and not result['timed_out'] and result['inputs_unchanged']
            assert all(sha(Path(n)) == h for n, h in command['inputs'].items())
            assert sha(directory / (stage + '.stdout')) == result['stdout_sha256']
            assert sha(directory / (stage + '.stderr')) == result['stderr_sha256']

lifecycles = {}
for name, stems, dotted in [
    ('file-lifecycle', ['source310-file-lifecycle-gnu/execute', 'source310-file-lifecycle-source310/execute'], False),
    ('active-lifecycle', ['source310-active-lifecycle-gnu/execute', 'source310-active-lifecycle-source310/execute'], False),
    ('anonymous-lifecycle', ['source310-lifecycle-candidate-gnu', 'source310-lifecycle-candidate-source310'], True),
]:
    outputs = []
    for stem in stems:
        command = read(stem + ('.command.json' if dotted else '-command.json'))
        result = read(stem + ('.result.json' if dotted else '-result.json'))
        assert all(sha(Path(f)) == h for f, h in command['inputs'].items())
        assert result['exit_code'] == 0 and not result['timed_out'] and result['inputs_unchanged']
        stdout, stderr = (p / (stem + '.stdout')).read_bytes(), (p / (stem + '.stderr')).read_bytes()
        assert stdout and not stderr and sha(p / (stem + '.stdout')) == result['stdout_sha256']
        outputs.append(stdout)
    assert outputs[0] == outputs[1], name
    comparison = read('source310-ordinary-' + name + '-comparison.json')
    assert comparison['passed'] and comparison['exact_match'] and comparison['source_unchanged']
    lifecycles[name] = comparison
assert (p / 'source310-file-lifecycle-source310/execute.stdout').read_bytes() == (c / 'tests/fixtures/native-unit-lifecycle.expected').read_bytes().rstrip(b'\n')
assert (p / 'source310-ordinary-buffer-lf-line-index-emaxx.stdout').read_bytes() == (p / 'source302-line-broad-gnu.stdout').read_bytes()
assert read('source310-owner-negative2-result.json')['exit_code'] == 101
assert 'left: Symbol("accepted")' in (p / 'source310-owner-negative2.log').read_text()
evidence = {str(f): sha(f) for f in p.glob('source310-*') if f.is_file() and f.suffix in ['.json', '.log', '.stdout', '.stderr', '.patch', '.el', '.expected']}
result = dict(status='passed', source_inputs_verified=546, auxiliary_inputs_verified=94, recovery=recovery, original_attempt_status='failed', profiles=profiles, ordinary_comparisons=56,
              ordinary_results=ordinary, lifecycle_results=lifecycles, generated_rows=198,
              ordinary_artifacts=artifacts, portable_replays=portable['patches'], evidence_files=evidence, goal_complete=False,
              qualification='The actual88-byte native unit replaces its host record, strong native registry and permanent relocation roots. All1035 predecessor selected controls remain plus the actual-runtime ownership control. Both profiles and every ordinary comparison are independently audited. The initial selected attempt remains failed (1032 passes/four missing-generator failures); exact published auxiliary inputs were restored without changing the runtime, test binary, assertions or selectors. All four generator controls and the complete selection passed afterward; all94 auxiliary input bytes/modes are bound to the resumed runs. Metadata follows actual GNU, and native code survives active collection and becomes reclaimable after calls. Obsolete representation assertions are explicitly migrated, including removal of the deleted registry-is-empty assertion; semantic assertions and original fixture bytes remain. This is selected correctness evidence only; no complete platform, whole-runtime soundness, physical accounting or performance acceptance claim.')
(p / 'source310-selected-audit.json').open('x').write(json.dumps(result, indent=2))
print(json.dumps(dict(status='passed', source_inputs=546, passes_per_profile=1036, ordinary_comparisons=56)))
