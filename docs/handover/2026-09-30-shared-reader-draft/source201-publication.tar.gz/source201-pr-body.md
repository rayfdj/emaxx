Command, menu, keyboard-macro and minibuffer reads now share one incremental input decoder and the actual Lisp input/macro state. Collecting callbacks observe live maps, events and macro arrays; nested macro state uses GNU's two conses with scoped roots.

Vector allocation now uses eight-byte Lisp word alignment. A two-slot vector occupies 24 bytes instead of 32, and a six-slot closure occupies 56 instead of 64. The block bitmap stays 40 bytes; the free-list table grows from 1,024 to 2,032 bytes. Actual pseudovector census counts match GNU. These are allocation footprints, not measured timing or RSS improvements.

Validation for runtime source201 (`320d0a2e`):

- Strict compiler, formatting and Clippy checks pass; 454 gate tests, 454 release tests and 36 exact ordinary GNU comparisons pass with raw evidence audited.
- Complete macOS Rust and 226-scenario terminal runs are in progress. [Complete Linux Rust](https://github.com/rayfdj/emaxx/actions/runs/36756877353) and [Linux frozen compatibility](https://github.com/rayfdj/emaxx/actions/runs/36756885097) have been dispatched on this exact commit.
- Keep this PR in draft: predecessor source198 fails the original Linux suspended-bytecode reclamation assertion. [Replay with its retained executable and image](https://github.com/rayfdj/emaxx/actions/runs/36753517998) reproduces the failure. The separate debugger pass contains address-read errors; [a bounded five-process diagnosis](https://github.com/rayfdj/emaxx/actions/runs/36756891923) preserves every outcome and uses the original artifacts.

Source198 separately passed 3,051 macOS Rust tests, all 226 terminal scenarios / 686 comparisons, and 519 Linux frozen files / 7,928 matching outcomes. Those results do not certify source201. Earlier failures, GNU-backed corrections to invalid local expectations, inventories and artifact identities remain in the portable handover archives.

The full architectural and GNU-performance goal remains open. See HANDOVER.md and docs/runtime-representation-vector-allocation-draft.md for current requirements and reproduction evidence.
