from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
out = p.parents[2] / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
read = lambda name: json.loads((p / name).read_text())
ordinary = read('source244-ordinary-audit.json')
new = read('source244-selected-audit.json')
assert len(ordinary['fixtures']) == 57 and len(new['fixtures']) == 9
assert len(set(ordinary['fixtures'] + new['fixtures'])) == 66
commit = read('source244-checkpoint-commit.json')['commit']
linux = {label: read('source244-linux-' + label + '-launch.json') for label in ['rust', 'frozen']}
assert all(row['source_commit'] == row['state']['headSha'] == commit for row in linux.values())
allowed = {'.json', '.log', '.txt', '.py', '.stdout', '.stderr'}
patterns = ['source244-ordinary-*', 'source244-selected-audit.json', 'source244-manifest.json',
            'source244-checkpoint-*', 'source244-linux-*', 'launch-source244-linux.py',
            'commit-source244-checkpoint.py', 'run-source244-release-and-ordinary.py',
            'audit-source244-ordinary.py', 'audit-source244-selected.py',
            'compare-source230-fixtures.py', Path(__file__).name]
files = {str(file.relative_to(p)): file for pattern in patterns for file in p.glob(pattern)
         if file.is_file() and file.suffix in allowed}
package('source244-linux-launch-and-ordinary', files,
        dict(source_commit=commit, preceding_ordinary=ordinary, new_ordinary=new,
             total_distinct_ordinary_comparisons=66, linux_launches=linux,
             qualification='Exact pushed source244 runtime checkpoint. All 57 preceding ordinary comparisons and nine new comparisons pass; 66 distinct same-input comparisons in total. Linux Rust and full frozen jobs are dispatched on this commit, with no completion inferred. Complete local macOS/release/terminal validation remains active and its active logs are excluded. Earlier failed sources and the unresolved GNU census diagnosis remain preserved; main and the full goal are unchanged.'))
