from pathlib import Path
import ast
import hashlib
import json
import re
import shutil

p = Path(__file__).parent.resolve()
root = p.parents[2]
candidate = p.parent / 'recovered-2026-09-30/display-tables/emaxx'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read('source234-manifest.json')
assert len(manifest) == 442
assert all(sha(candidate / name) == sha(root / name) == digest for name, digest in manifest.items())
node = next(n for n in ast.parse((p / 'audit-shared-reader196-fresh-selected.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'audit_log')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<raw-auditor>', 'exec'))
command = read('source234-release-controls-command.json')
result = read('source234-release-controls-result.json')
names = command['selected_inventory']
assert len(names) == 37
assert set(read('source231-release-controls-command.json')['selected_inventory']) < set(names)
assert result['exit_code'] == 0 and result['source_unchanged']
assert command['command'][1:] == names + ['--exact', '--nocapture', '--test-threads=1']
assert command['environment_override']['LANG'] == command['environment_override']['LC_ALL'] == 'C'
assert audit_log(names, (p / 'source234-release-controls.log').read_text(), 37, 0) == []
binary = p / 'source234-release-libtest'
assert sha(binary) == command['binary_sha256']
for stage in ['check', 'fmt', 'clippy', 'diff', 'release-build']:
    result = read('source234-' + stage + '-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
    raw = (p / ('source234-' + stage + '.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
    for line in raw.splitlines():
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        assert item.get('message', {}).get('level') not in ['warning', 'error']
images = list((p / 'fixture-images-source234').glob('loadup-' + sha(binary)[:8] + '-*.pdmp'))
assert len(images) == 1
retained = p / 'source234-release-focused-retained-inputs'
retained.mkdir()
image = retained / images[0].name
shutil.copy2(images[0], image)
assert sha(images[0]) == sha(image)
record = dict(status='37 focused release controls pass', goal_complete=False,
              source_inputs_verified=442, passed=37, failed=0, ignored=0,
              strict_checks='passed with zero warnings',
              binary=dict(retained=str(binary), sha256=sha(binary)),
              image=dict(original=str(images[0]), retained=str(image), sha256=sha(image)),
              qualification='The new same-input GNU fixture and four unchanged Edebug controls pass, as does the original captured-interactive-closure mutation control and all 31 preceding bytecode/string controls. The retained source231 ordinary reproducer fails while GNU returns 17. Full macOS and release validation are separate; Linux must still verify the repair. Post-run image is retained without a per-test image-use claim. Seven display mismatches and the full architectural/performance requirements remain open.')
with (p / 'source234-release-focused-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps(record, indent=2))
