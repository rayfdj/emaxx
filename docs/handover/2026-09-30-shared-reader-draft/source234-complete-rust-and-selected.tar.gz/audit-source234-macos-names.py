from pathlib import Path
import hashlib
import json
import re

p = Path(__file__).parent.resolve()
root = p / "full-gate-source234"
summary = json.loads((root / "summary.json").read_text())
inventory = [line[:-6] for line in (root / "inventory.txt").read_text().splitlines() if line.endswith(": test")]
ignored = summary["inventory"]["ignored_tests"]
seen = []
for group in summary["runs"][0]["groups"]:
    log = (root / Path(group["log"]).name).read_text()
    starts = list(re.finditer(r"^test (\S+) \.\.\. ", log, re.M))
    assert len(starts) == group["expected_tests"], group["group"]
    for index, match in enumerate(starts):
        end = starts[index + 1].start() if index + 1 < len(starts) else log.rindex("test result:")
        captured = log[match.end():end].strip()
        if match[1] in ignored:
            assert captured.startswith("ignored"), match[1]
        else:
            assert re.search(r"(?:^|\s)ok$", captured), (match[1], captured)
        seen.append(match[1])
assert sorted(seen) == sorted(inventory) and len(seen) == len(set(seen))
with (p / "source234-macos-rust-name-audit.json").open("x") as stream:
    json.dump({"status": "passed", "raw_names_verified": len(seen),
               "inventory_sha256": hashlib.sha256((root / "inventory.txt").read_bytes()).hexdigest(),
               "qualification": "Every raw library test name and final libtest verdict matches the complete inventory, including the two existing ignores. Native test output before the final verdict is preserved. Complements the count, native identity and retained-artifact audit."}, stream, indent=2)
print("Verified", len(seen), "distinct raw test names and verdicts")
