Shared closure fields and canonical string bytes let interpreted, bytecode and native execution observe the same object and live code mutations. This checkpoint retains the direct cons/evaluator paths, word-aligned vector allocation, shared reader and keyboard-macro work, removes the detached bytecode program state, and repairs completion, concat and substring behavior against GNU.

Computed interactive arguments now follow `callint.c`: an interpreted closure supplies its captured environment, while bytecode and other commands evaluate through `Feval` with a nil lexical environment. Previously the shared bytecode closure's constants vector was mistaken for an environment, causing both Linux runs to abort in Edebug. A same-input ordinary probe reproduces the defect in the prior checkpoint. The new fixture covers varied constant-vector sizes, captured mutation, lexical isolation, dynamic binding, GC and error restoration. The five previous local library failures are repaired without weakening their contracts.

Validation on runtime `df42fda2a31144ecb25cd5102385a8a3660c173a`:

- Formatting, compiler, strict Clippy and diff checks pass with zero warnings.
- All 37 focused controls pass in both gate and release, including the new GNU differential and four unchanged Edebug controls.
- Full macOS, 938 affected release tests and 55 ordinary GNU comparisons are running separately. These launches are not complete passes.
- [Linux Rust](https://github.com/rayfdj/emaxx/actions/runs/36808140965) and [Linux frozen compatibility](https://github.com/rayfdj/emaxx/actions/runs/36808153594) are dispatched on this exact commit; Linux repair remains unverified.

The prior Linux failures remain recorded: 1,380 Rust passes before an abort, and 79 frozen files / 1,911 matching outcomes before the same assertion. The earlier terminal run retains seven display mismatches and a later GNU startup-readiness failure. The PR remains draft and main is unchanged. Plain-string and symbol authority, physical allocation accounting, stack capacity/layout, ownership review, final platform validation and the locked 16-workload performance criterion remain open. No GNU performance-parity claim is made. `HANDOVER.md` links the exact patches, raw evidence and remaining requirements.
