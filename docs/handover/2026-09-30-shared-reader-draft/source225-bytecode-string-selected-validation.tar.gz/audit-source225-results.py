from pathlib import Path
import ast
import hashlib
import json
import re
import shutil

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/string-bytes/emaxx'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read('source225-manifest.json')
assert len(manifest) == 427
assert all(sha(root / name) == digest for name, digest in manifest.items())
node = next(n for n in ast.parse((p / 'audit-shared-reader196-fresh-selected.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'audit_log')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<raw-auditor>', 'exec'))
prefixes = ('lisp::bytecode::', 'lisp::native_comp::runtime::', 'lisp::primitives::pdumper::',
            'lisp::primitives::tests::', 'lisp::reader::', 'lisp::types::')
groups = []
profile_inventories = {}
for profile in ['gate', 'release']:
    inventory = [line[:-6] for line in (p / ('source225-' + profile + '-inventory.txt')).read_text().splitlines()
                 if line.endswith(': test')]
    assert len(inventory) == len(set(inventory)) == (2976 if profile == 'gate' else 2975)
    profile_inventories[profile] = inventory
    if profile == 'release':
        assert set(profile_inventories['gate']) - set(inventory) == {
            'file_system::posix::tests::posix_file_drop_rejects_an_externally_closed_descriptor'}
        assert not set(inventory) - set(profile_inventories['gate'])
    for group, count in [('controls', 20), ('broad', 932)]:
        stem = 'source225-' + profile + '-' + group
        command, result = read(stem + '-command.json'), read(stem + '-result.json')
        assert result['exit_code'] == 0 and result['source_unchanged']
        assert sha(p / ('source225-' + profile + '-libtest')) == command['binary_sha256']
        assert command['environment_override']['LANG'] == command['environment_override']['LC_ALL'] == 'C'
        names = command['selected_inventory']
        assert len(names) == count
        if group == 'broad':
            assert names == [name for name in inventory if name.startswith(prefixes)]
        if profile == 'release':
            assert names == read('source225-gate-' + group + '-command.json')['selected_inventory']
        assert audit_log(names, (p / (stem + '.log')).read_text(), count, 0) == []
        groups.append(dict(profile=profile, stage=group, passed=count, failed=0, ignored=0, inventory_verified=len(names)))

for stage in ['check', 'fmt', 'clippy', 'diff', 'gate-build', 'release-build']:
    result = read('source225-' + stage + '-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
    raw = (p / ('source225-' + stage + '.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
    for line in raw.splitlines():
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        assert item.get('message', {}).get('level') not in ['error', 'warning']
assert all(stage['exit_code'] == 0 for stage in read('source225-validation-result.json'))
assert all(stage['exit_code'] == 0 for stage in read('source225-release-driver-result.json'))

names = read('source225-gate-controls-command.json')['selected_inventory']
raw = (p / 'source225-gate-controls.log').read_text()
first = 'test ' + names[0] + ' ... ok'
assert first in raw
mutants = {
    'missing-verdict': raw.replace(first, '', 1),
    'duplicate-verdict': raw.replace(first, first + '\n' + first, 1),
    'failed-verdict-under-green-summary': raw.replace(first, first.replace(' ... ok', ' ... FAILED'), 1),
    'missing-summary': raw[:raw.rindex('test result:')],
    'false-summary-total': raw.replace('20 passed; 0 failed;', '19 passed; 0 failed;', 1),
}
for label, invalid in mutants.items():
    try:
        audit_log(names, invalid, 20, 0)
    except (AssertionError, ValueError):
        pass
    else:
        raise AssertionError('Auditor accepted corrupt evidence: ' + label)

retained = p / 'source225-retained-inputs'
retained.mkdir()
files = []
images = sorted((p / 'fixture-images-source225').glob('*.pdmp'))
assert len(images) == 2
for source in [p / 'source225-gate-libtest', p / 'source225-release-libtest', *images]:
    target = retained / source.name
    digest = sha(source)
    shutil.copy2(source, target)
    assert sha(source) == sha(target) == digest
    files.append(dict(original=str(source), retained=str(target), sha256=digest, bytes=target.stat().st_size))
record = dict(status='selected validation passes in both profiles', inputs_verified=len(manifest),
              strict_checks='passed with zero warnings', groups=groups, retained_files=files,
              profile_inventory_counts={profile: len(names) for profile, names in profile_inventories.items()},
              existing_profile_difference='The unchanged cfg(debug_assertions) POSIX file-drop control is listed only in gate. Both affected-module selections contain the same 932 tests.',
              corrupt_logs_rejected=list(mutants), goal_complete=False,
              qualification='All 20 focused controls and every one of the 932 affected-module tests pass in both profiles; no ignores or exclusions. Original mutation, character, identity, rooting and census assertions remain. Earlier failed candidates remain failed historical evidence. This is selected validation of source225, not complete platform, pinned compatibility, stack-capacity, physical-accounting or performance certification. Images are retained post-run artifacts, not a per-test image-use transcript.')
with (p / 'source225-results-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record, indent=2))
