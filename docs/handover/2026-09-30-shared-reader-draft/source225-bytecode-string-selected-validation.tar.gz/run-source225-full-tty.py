from pathlib import Path
import hashlib,json,os,re,runpy,subprocess,time
root=Path("/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/string-bytes/emaxx")
p=Path("/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28")
artifacts=json.loads((p/"source225-ordinary-artifacts.json").read_text())
subject=root/"target/frame-validation/release/emaxx";gnu=Path("/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/emacs/src/emacs")
source=json.loads((p/"source225-manifest.json").read_text())
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def unchanged():return all(sha(root/name)==h for name,h in source.items())
assert json.loads((p/'source225-ordinary-audit.json').read_text())['status']=='all ordinary differential comparisons pass'
assert unchanged() and sha(subject)==artifacts[str(subject)]["sha256"] and sha(subject.with_suffix(".pdmp"))==artifacts[str(subject.with_suffix(".pdmp"))]["sha256"]
inputs={str(f):sha(f) for f in [subject,subject.with_suffix(".pdmp"),gnu,gnu.with_suffix(".pdmp"),root/"tools/ttydiff.py",root/"tools/fixtures/fieldnotes.org",root/"tools/fixtures/fake_lsp_server.py",Path(__file__)]}
overrides={"EMAXX_TTYDIFF_REQUIRE":"1","LANG":"C","LC_ALL":"C"}
module=runpy.run_path(str(root/"tools/ttydiff.py"),run_name="inventory_only")
inventory=[entry[0] for entry in module["select_scenarios"]([])]
assert len(inventory)==len(set(inventory))
command=["/usr/bin/caffeinate","-i","python3","tools/ttydiff.py",str(subject),str(gnu),"/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/emacs/lisp"]
with (p/"source225-full-ttydiff-command.json").open("x") as out:json.dump({"command":command,"working_directory":str(root),"environment_overrides":overrides,"inputs":inputs,"source_manifest":"source225-manifest.json","inventory":inventory,"qualification":"Complete default terminal inventory for source225 shared closure fields, canonical string bytes and direct bytecode execution, including all existing scenarios plus the three added reader controls. Both editors receive -Q and inherit HOME unchanged. Earlier failures remain preserved. Source/ABI-matched GNU is not the Darwin frozen executable; no pin, selector, assertion, timeout, settle or comparison changed. Caffeinate inhibits idle sleep only for this child. No performance or full-goal claim."},out,indent=2)
start=time.monotonic()
with (p/"source225-full-ttydiff.log").open("xb") as log:completed=subprocess.run(command,cwd=root,env={**os.environ,**overrides},stdout=log,stderr=subprocess.STDOUT)
text=(p/"source225-full-ttydiff.log").read_text(errors="replace")
observed=re.findall(r"^RUN \[(\d+)/(\d+)\] (.+)$",text,re.M)
complete=len(observed)==len(inventory) and all(int(a)==index+1 and int(b)==len(inventory) and name==inventory[index] for index,(a,b,name) in enumerate(observed))
record={"exit_code":completed.returncode,"elapsed_seconds":time.monotonic()-start,"source_unchanged":unchanged(),"inputs_unchanged":all(sha(Path(f))==h for f,h in inputs.items()),"expected_scenarios":len(inventory),"started_scenarios":len(observed),"complete_start_inventory":complete,"terminal_summary":text.splitlines()[-1:]}
with (p/"source225-full-ttydiff-result.json").open("x") as out:json.dump(record,out,indent=2)
print(json.dumps(record),flush=True)
raise SystemExit(completed.returncode or (0 if complete and record["source_unchanged"] and record["inputs_unchanged"] and "PASS: all scenarios match" in text else 2))
