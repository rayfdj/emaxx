from pathlib import Path
import ast
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
selected = read('source225-results-audit.json')
ordinary = read('source225-ordinary-audit.json')
assert all(group['passed'] == (20 if group['stage'] == 'controls' else 932)
           and group['failed'] == 0 and group['ignored'] == 0 for group in selected['groups'])
assert len(ordinary['fixtures']) == 48
manifest = read('source225-manifest.json')
assert len(manifest) == 427 and all(sha((root / name).read_bytes()) == digest for name, digest in manifest.items())
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected'}
files = {f.name: f for f in p.iterdir() if f.is_file() and f.suffix in allowed
         and f.name.startswith('source225-') and not f.name.startswith('source225-full-')}
helpers = [
    'audit-source225-results.py', 'audit-source225-ordinary.py',
    'audit-shared-reader196-fresh-selected.py', 'package-source196-failure-and197-results.py',
    'check-string217.py', 'static-string217.py', 'test-string-controls225.py',
    'test-string-broad219.py', 'run-string-validation225.py', 'run-source225-release.py',
    'build-string225.py', 'run-source225-ordinary.py', 'compare-source225-fixtures.py',
    'compare-source225-printing-fixtures.py', 'run-source225-full-gate.py',
    'run-source225-full-tty.py', 'source207-ordinary-comparisons-command.json',
    'source224-through225-patch-replay-and-modes-audit.json', Path(__file__).name,
]
files.update({name: p / name for name in helpers})
package('source225-bytecode-string-selected-validation', files,
        dict(status='source225 applied after audited selected validation; complete validation running',
             selected=selected, ordinary=ordinary,
             applied=read('source225-applied-to-task-branch.json'),
             complete_validation_launch=read('source225-complete-validation-launch.json'),
             qualification='Every raw selected verdict and ordinary process result is retained, including the original four redundant-print failures and separate unchanged-fixture replays. No running full-validation log or runtime verdict is packaged. Source225 runtime/test inputs now match the task branch; main remains source174. Final representation, stack/accounting, platform, pinned compatibility, adversarial audit and locked performance requirements remain open.'))
