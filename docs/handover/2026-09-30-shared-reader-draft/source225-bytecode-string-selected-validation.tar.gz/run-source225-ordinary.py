from pathlib import Path
import hashlib
import json
import subprocess
import time

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/string-bytes/emaxx'
read = lambda name: json.loads((p / name).read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
for name, entry in read('source225-ordinary-artifacts.json').items():
    assert sha(Path(name)) == entry['sha256'] == sha(Path(entry['immutable_copy']))
for stage in ['ordinary-build', 'ordinary-image']:
    result = read('source225-' + stage + '-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
fixtures = read('source207-ordinary-comparisons-command.json')['fixtures'] + [
    'bytecode-closure-shared-constants', 'bytecode-code-active-mutation-baseline',
    'bytecode-code-mutation-baseline', 'bytecode-constructor-gnu-fields',
    'bytecode-live-fetch', 'bytecode-unused-destinations',
    'canonical-string-bytes', 'canonical-string-constructors',
]
assert len(fixtures) == len(set(fixtures)) == 48
command = ['python3', str(p / 'compare-source225-fixtures.py'), 'source225', str(root), *fixtures]
with (p / 'source225-ordinary-comparisons-command.json').open('x') as stream:
    json.dump(dict(command=command, fixtures=fixtures,
                   qualification='All 40 source207 ordinary fixtures plus all eight new bytecode/string GNU differential fixtures. Both editors use -Q, C locale and their own executable/image. GNU is source/native-ABI matched, not the frozen Darwin executable. No timing claim.'), stream, indent=2)
    stream.write('\n')
start = time.monotonic()
with (p / 'source225-ordinary-comparisons.log').open('x') as log:
    result = subprocess.run(command, cwd=p.parents[2], stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
record = dict(exit_code=result.returncode, elapsed_seconds=time.monotonic() - start, fixtures=len(fixtures))
with (p / 'source225-ordinary-comparisons-result.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record), flush=True)
raise SystemExit(result.returncode)
