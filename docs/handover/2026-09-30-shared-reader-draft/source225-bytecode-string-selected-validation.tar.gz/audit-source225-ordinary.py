from pathlib import Path
import hashlib
import json
import re

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/string-bytes/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read('source225-manifest.json')
assert len(manifest) == 427 and all(sha(root / name) == digest for name, digest in manifest.items())
for stage in ['ordinary-build', 'ordinary-image']:
    result = read('source225-' + stage + '-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
    assert not re.search(r'^warning(?:\[.*\])?:', (p / ('source225-' + stage + '.log')).read_text(), re.M)
artifacts = read('source225-ordinary-artifacts.json')
for name, entry in artifacts.items():
    assert sha(Path(name)) == entry['sha256'] == sha(Path(entry['immutable_copy']))
result = read('source225-ordinary-comparisons-result.json')
assert result['exit_code'] == 1 and result['fixtures'] == 48
replay_result = read('source225-printing-comparisons-result.json')
assert replay_result['exit_code'] == 0 and replay_result['fixtures'] == 4
replayed = read('source225-printing-comparisons-command.json')['fixtures']
assert replayed == ['bytecode-live-fetch', 'bytecode-unused-destinations',
                    'canonical-string-bytes', 'canonical-string-constructors']
fixtures = read('source225-ordinary-comparisons-command.json')['fixtures']
assert len(fixtures) == len(set(fixtures)) == 48
assert fixtures[:40] == read('source207-ordinary-comparisons-command.json')['fixtures']
for fixture in fixtures:
    stem = 'source225-ordinary-' + fixture
    comparison = read(stem + '-comparison.json')
    if fixture in replayed:
        assert not comparison['passed'] and comparison['exact_match']
        fixture_path = root / ('tests/fixtures/' + fixture + '.el')
        assert fixture_path.read_text().startswith('(prin1\n')
        expected = fixture_path.with_suffix('.expected').read_bytes().rstrip(b'\n')
        for editor in ['gnu', 'emaxx']:
            original = comparison['outcomes'][editor]
            assert original['exit_code'] == 0 and original['stderr_hex'] == ''
            assert original['inputs_unchanged'] and original['source_unchanged']
            assert original['expected_output'] is False
            assert (p / (stem + '-' + editor + '.stdout')).read_bytes() == expected + expected
        stem = 'source225-printing-ordinary-' + fixture
        comparison = read(stem + '-comparison.json')
    assert comparison['passed'] and comparison['exact_match']
    outputs = []
    for editor in ['gnu', 'emaxx']:
        result = read(stem + '-' + editor + '.result.json')
        command = read(stem + '-' + editor + '.command.json')
        assert result == comparison['outcomes'][editor]
        assert result['exit_code'] == 0 and not result['timed_out']
        assert result['source_unchanged'] and result['inputs_unchanged']
        assert result['expected_output'] is not False
        assert command['environment_override']['LANG'] == command['environment_override']['LC_ALL'] == 'C'
        stdout = p / (stem + '-' + editor + '.stdout')
        assert sha(stdout) == result['stdout_sha256']
        assert (p / (stem + '-' + editor + '.stderr')).read_bytes() == b''
        assert all(sha(Path(name)) == digest for name, digest in command['inputs'].items())
        outputs.append(stdout.read_bytes())
    assert outputs[0] == outputs[1]
record = dict(status='all ordinary differential comparisons pass', fixtures=fixtures,
              inputs_verified=len(manifest), ordinary_artifacts=artifacts, goal_complete=False,
              original_run=dict(passed=44, failed=4, failed_names=replayed, diagnosis='The wrapper adds prin1 around four already self-printing fixtures; both editors produce exactly twice the expected bytes.'),
              unchanged_fixture_replays=dict(passed=4, failed=0, fixtures=replayed),
              qualification='All 40 preceding ordinary controls plus all eight new string/bytecode fixtures pass through normal -Q batch entry points with each editor using its own executable/image. The initial 44-pass/four-wrapper-failure run stays failed. Four separate replays remove only the redundant outer print; original fixture and expected bytes are unchanged. Exact output, zero exit, empty stderr, input hashes and C locale are audited. GNU is source/native-ABI matched, not the pinned Darwin executable. No full-platform, stack-capacity, physical-accounting or performance claim.')
with (p / 'source225-ordinary-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(dict(status=record['status'], fixtures=len(fixtures), inputs_verified=len(manifest)), indent=2))
