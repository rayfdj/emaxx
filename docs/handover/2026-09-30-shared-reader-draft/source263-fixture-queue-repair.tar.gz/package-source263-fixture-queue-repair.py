from pathlib import Path
import ast
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(node for node in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(node, ast.FunctionDef) and node.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
withdrawal = read('source263-fixture-queue-withdrawal.json')
assert withdrawal['status'] == 'withdrawn while waiting before runtime execution'
assert {row['pid'] for row in withdrawal['processes']} == {64601, 87187}
assert all(row['exited'] for row in withdrawal['processes'])
preflight = read('source263-fixture-queue-preflight.json')
assert preflight['source_inputs_verified'] == 500 and preflight['fixture_count'] == 28
assert all(sha(Path(name).read_bytes()) == digest for name, digest in preflight['inputs'].items())
for row in preflight['helper_changes']:
    assert sha((p / row['original']).read_bytes()) == row['original_sha256']
    assert sha((p / row['corrected']).read_bytes()) == row['corrected_sha256']
names = [
    'prepare-source263-fixture-queue-repair.py', 'replace-source263-waiting-fixture-queues.py',
    'source263-fixture-queue-preflight.json', 'source263-fixture-queue-withdrawal.json',
    'source263-validation-launch.json', 'source263-validation-queue-state.json',
    'source263-boundary-launch.json', 'source263-boundary-queue-state.json',
    'source263-fixture-validation-launch.json', 'source263-boundary-fixtures-launch.json',
    'source263-manifest.json', 'package-source196-failure-and197-results.py', Path(__file__).name,
]
for row in preflight['helper_changes']:
    names.extend([row['original'], row['corrected']])
states = {}
for stem in ['source263-fixture-validation', 'source263-boundary-fixtures']:
    state = read(stem + '-queue-state.json')
    states[stem] = state
    name = stem + '-at-packaging.json'
    with (p / name).open('x') as stream:
        json.dump(state, stream, indent=2)
    names.append(name)
files = {name: p / name for name in names}
assert len(files) == len(names) and all(path.is_file() for path in files.values())
package('source263-fixture-queue-repair', files, dict(
    withdrawal=withdrawal, launches={stem: read(stem + '-launch.json') for stem in states}, states=states,
    qualification='Before runtime execution, review found the queued ordinary wrapper named a nonexistent fixture. Both original waiting supervisors were withdrawn, preserving their helpers and waiting states. Corrected queues90568/90569 restore the actual original string-ordering-symbol-storage fixture and all28 fixture paths are verified. Runtime source, tests, expectations, selectors, timeouts and comparison rules stay unchanged. No source263 runtime pass or goal completion is claimed.'))
