from pathlib import Path
import ast
import hashlib
import json
import difflib

p = Path(__file__).parent.resolve()
candidate = p.parent / 'recovered-2026-09-30/string-ranges/emaxx'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
state = read('source263-validation-queue-state.json')
assert state['status'] == 'waiting for source261 full macOS supervisor to exit'
assert not (p / 'source263-gate-build-command.json').exists()
assert not (p / 'source263-validation-result.json').exists()
assert not (p / 'source263-boundary-queue-result.json').exists()
manifest = read('source263-manifest.json')
assert len(manifest) == 500 and all(sha(candidate / name) == digest for name, digest in manifest.items())
fixtures = state['stages'][-1][3:]
missing = [name for name in fixtures if not (candidate / ('tests/fixtures/' + name + '.el')).exists() and not (p / (name + '.el')).exists()]
assert missing == ['string-ranges-symbol-storage']
assert (candidate / 'tests/fixtures/string-ordering-symbol-storage.el').is_file()
records = []
for old_name, new_name in [
    ('queue-string-ranges263-validation.py', 'queue-string-ranges263-fixtures.py'),
    ('audit-source263-selected.py', 'audit-source263-selected-fixtures.py'),
    ('queue-source263-boundary-control.py', 'queue-source263-boundary-fixtures.py'),
]:
    original = (p / old_name).read_text()
    new = original
    if old_name.startswith('queue-string'):
        assert new.count("'string-ranges-symbol-storage'") == 1
        new = new.replace("'string-ranges-symbol-storage'", "'string-ordering-symbol-storage'")
        new = new.replace('source263-validation-queue-state.json', 'source263-fixture-validation-queue-state.json')
        new = new.replace('source263-validation-result.json', 'source263-fixture-validation-result.json')
        new = new.replace("try:\n    withdrawal =", "try:\n    assert json.loads((p / 'source263-fixture-queue-withdrawal.json').read_text())['status'] == 'withdrawn while waiting before runtime execution'\n    for fixture_name in fixtures:\n        assert (candidate / ('tests/fixtures/' + fixture_name + '.el')).is_file() or (p / (fixture_name + '.el')).is_file()\n    withdrawal =", 1)
    elif old_name.startswith('audit'):
        new = new.replace('source263-validation-result.json', 'source263-fixture-validation-result.json')
    else:
        new = new.replace('source263-validation-launch.json', 'source263-fixture-validation-launch.json')
        new = new.replace('assert prior_pid == 64601', 'assert isinstance(prior_pid, int) and prior_pid > 0')
        new = new.replace('queue-string-ranges263-validation.py', 'queue-string-ranges263-fixtures.py')
        new = new.replace('source263-validation-result.json', 'source263-fixture-validation-result.json')
        new = new.replace('audit-source263-selected.py', 'audit-source263-selected-fixtures.py')
        new = new.replace('source263-boundary-queue-', 'source263-boundary-fixtures-queue-')
        new = new.replace("'source263-boundary-' + stage", "'source263-boundary-fixtures-' + stage")
    ast.parse(new)
    with (p / new_name).open('x') as stream:
        stream.write(new)
    records.append(dict(original=old_name, original_sha256=sha(p / old_name), corrected=new_name, corrected_sha256=sha(p / new_name), diff=''.join(difflib.unified_diff(original.splitlines(True), new.splitlines(True), fromfile=old_name, tofile=new_name))))
corrected_fixtures = ['string-ordering-symbol-storage' if name == 'string-ranges-symbol-storage' else name for name in fixtures]
assert len(corrected_fixtures) == len(set(corrected_fixtures)) == 28
paths = {}
for name in corrected_fixtures:
    fixture = candidate / ('tests/fixtures/' + name + '.el')
    if not fixture.is_file():
        fixture = p / (name + '.el')
    paths[str(fixture)] = sha(fixture)
    expected = fixture.with_suffix('.expected')
    if expected.exists():
        paths[str(expected)] = sha(expected)
assert (candidate / 'tests/fixtures/string-ordering-symbol-storage.expected').read_bytes().rstrip(b'\n') == (p / 'source261-probe-string-ordering-symbol-storage-gnu.stdout').read_bytes()
with (p / 'source263-fixture-queue-preflight.json').open('x') as stream:
    json.dump(dict(status='prepared; not launched', source_inputs_verified=500, missing_original_fixture=missing, corrected_fixture='string-ordering-symbol-storage', fixture_count=28, inputs=paths, helper_changes=records, goal_complete=False, qualification='A queued wrapper typo is corrected before the first runtime stage. The original waiting helpers and state remain unchanged. No source, test, expected byte, selector, timeout or comparison rule changes.'), stream, indent=2)
print(json.dumps(dict(source_inputs_verified=500, fixtures_verified=28, corrected_helpers=[row['corrected'] for row in records])))
