from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import sys
import time

p = Path(__file__).parent.resolve()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
preflight = read('source263-fixture-queue-preflight.json')
assert all(sha(Path(name)) == digest for name, digest in preflight['inputs'].items())
for row in preflight['helper_changes']:
    assert sha(p / row['original']) == row['original_sha256']
    assert sha(p / row['corrected']) == row['corrected_sha256']
assert read('source261-full-queue-state.json')['status'] == 'running tty'
assert not (p / 'source261-full-queue-result.json').exists()
assert not (p / 'source263-gate-build-command.json').exists()
assert not (p / 'source263-validation-result.json').exists()
assert not (p / 'source263-boundary-selected-audit-command.json').exists()
assert not (p / 'source263-boundary-queue-result.json').exists()
rows = []
for stem, helper, expected_status in [
    ('source263-boundary', 'queue-source263-boundary-control.py', 'waiting for source263 selected validation'),
    ('source263-validation', 'queue-string-ranges263-validation.py', 'waiting for source261 full macOS supervisor to exit'),
]:
    launch = read(stem + '-launch.json')
    state = read(stem + '-queue-state.json')
    assert state['status'] == expected_status
    pid = launch['pid']
    process = subprocess.run(['ps', '-p', str(pid), '-o', 'command='], capture_output=True, text=True, check=True).stdout.strip()
    assert str(p / helper) in process and sha(p / helper) == launch['helper_sha256']
    children = subprocess.run(['pgrep', '-P', str(pid)], capture_output=True, text=True)
    assert children.returncode == 1 and not children.stdout.strip(), children.stdout
    rows.append(dict(pid=pid, process=process, helper=helper, helper_sha256=sha(p / helper), state_before=state, state_sha256=sha(p / (stem + '-queue-state.json'))))
for row in rows:
    os.kill(row['pid'], signal.SIGTERM)
    for attempt in range(50):
        result = subprocess.run(['ps', '-p', str(row['pid']), '-o', 'command='], capture_output=True, text=True)
        if result.returncode == 1 and not result.stdout.strip():
            break
        time.sleep(0.1)
    else:
        raise AssertionError('Waiting supervisor did not exit')
    row['exited'] = True
with (p / 'source263-fixture-queue-withdrawal.json').open('x') as stream:
    json.dump(dict(status='withdrawn while waiting before runtime execution', withdrawn_at_unix=time.time(), processes=rows, source_manifest_sha256=sha(p / 'source263-manifest.json'), preflight_sha256=sha(p / 'source263-fixture-queue-preflight.json'), reason='The selected wrapper names nonexistent string-ranges-symbol-storage instead of the original string-ordering-symbol-storage. Replace both waiting wrappers without changing runtime source, tests, expected output, selectors or timeouts. Original helpers and states remain preserved.', goal_complete=False), stream, indent=2)
for stem, helper in [
    ('source263-fixture-validation', 'queue-string-ranges263-fixtures.py'),
    ('source263-boundary-fixtures', 'queue-source263-boundary-fixtures.py'),
]:
    command = [sys.executable, '-B', str(p / helper)]
    with (p / (stem + '-driver.log')).open('xb') as log:
        process = subprocess.Popen(command, cwd=p, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True, env=dict(os.environ, PYTHONUNBUFFERED='1', PYTHONDONTWRITEBYTECODE='1'))
    with (p / (stem + '-launch.json')).open('x') as stream:
        json.dump(dict(pid=process.pid, command=command, helper_sha256=sha(p / helper), started_at_unix=time.time(), source_manifest='source263-manifest.json', qualification='Corrected queue after both original supervisors were withdrawn before runtime execution. Original helpers, states and withdrawal evidence are preserved. Await actual runtime results; no pass inferred.'), stream, indent=2)
    print(stem, process.pid, flush=True)
