from pathlib import Path
import ast,hashlib,json,shutil,subprocess
p=Path(__file__).parent.resolve();root=p.parents[2]
old=p.parent/'recovered-2026-10-06/native-subr-objects/emaxx'
c=p.parent/'recovered-2026-10-06/native-subr-decoding/emaxx'
g=p.parent/'rebuilt-2026-10-01/emacs'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
manifest=json.loads((p/'source305-manifest.json').read_text())
state=json.loads((p/'source305-validation-result.json').read_text())
assert state['status']=='validation stopped' and state['results'][-1]['stage']=='gate-focused'
assert state['results'][-1]['exit_code']==101 and state['profiles']=={}
assert len(manifest)==537 and all(sha(old/n)==h for n,h in manifest.items())
retained=p/'source305-failed-retained-inputs';retained.mkdir()
items=[]
for f in [p/'source305-gate-libtest',*sorted((p/'fixture-images-source305').glob('*.pdmp'))]:
 target=retained/f.name;shutil.copy2(f,target);assert sha(target)==sha(f)
 items.append(dict(original=str(f),retained=str(target),bytes=f.stat().st_size,sha256=sha(f)))
assert len(items)>=2
(p/'source305-failed-retained-inputs.json').open('x').write(json.dumps(items,indent=2))
assert not c.exists();c.parent.mkdir();(c.parent/'emacs').symlink_to(g,target_is_directory=True)
for command in [
 ['git','clone','--shared','--quiet','--no-checkout',str(root),str(c)],
 ['git','-C',str(c),'sparse-checkout','init','--no-cone'],
 ['git','-C',str(c),'sparse-checkout','set','--no-cone',*sorted({'/'+n for n in manifest}|{'/tools/','/compat/'})],
 ['git','-C',str(c),'checkout','--detach','2b561470516c519f2198d2551c7b85b474defcfc']]:
 subprocess.run(command,check=True)
for n in manifest:
 (c/n).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(old/n,c/n)
assert all(sha(c/n)==h for n,h in manifest.items())
f=c/'src/lisp/native_comp/runtime.rs';s=f.read_text()
a='''                    crate::lisp::alloc::VectorTag::Normal
                        | crate::lisp::alloc::VectorTag::Closure'''
assert s.count(a)==1
f.write_text(s.replace(a,'''                    crate::lisp::alloc::VectorTag::Normal
                        | crate::lisp::alloc::VectorTag::Subr
                        | crate::lisp::alloc::VectorTag::Closure'''))
assert [n for n,h in manifest.items() if sha(c/n)!=h]==['src/lisp/native_comp/runtime.rs']
runner=(p/'run-source305-validation.py').read_text().replace('source305','source306').replace('native-subr-objects/emaxx', 'native-subr-decoding/emaxx')
runner=runner.replace("base = read(p / 'source304-manifest.json')", "base = read(p / 'source305-manifest.json')")
runner=runner.replace("assert changes == sorted(changes) and len(changes) == 26, changes", "assert changes == ['src/lisp/native_comp/runtime.rs'], changes")
runner=runner.replace('recovered-2026-10-05/native-arithmetic-audit/emaxx/target/vm-dispatch-validation', 'recovered-2026-10-06/native-subr-objects/emaxx/target/vm-dispatch-validation')
ast.parse(runner);(p/'run-source306-validation.py').open('x').write(runner)
replay=(p/'replay-native-subr305.py').read_text().replace('Source305 removes', 'Source306 carries the305 migration and repairs the checked native-word decoder to accept allocator-verified PVEC_SUBR. The failed305 two-pass/two-failure run remains preserved. It removes')
ast.parse(replay);(p/'replay-native-subr306.py').open('x').write(replay)
(p/'source306-working-init.json').open('x').write(json.dumps(dict(status='decoder-only successor of preserved failed305',candidate=str(c),base='2b561470516c519f2198d2551c7b85b474defcfc',changed_from305=['src/lisp/native_comp/runtime.rs'],diagnosis='decode_word checked the exact allocated header against a whitelist that omitted Subr; Value and conservative tracing already support allocated native subrs. This adds the actual tag to that checked boundary without weakening its exact-pointer check. Both305 runtime failures are retained; every test/fixture and loader assertion remains unchanged.',goal_complete=False),indent=2))
print(c)
