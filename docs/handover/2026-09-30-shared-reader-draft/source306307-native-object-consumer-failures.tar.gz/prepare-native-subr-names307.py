from pathlib import Path
import hashlib,json,shutil,subprocess
p=Path(__file__).parent.resolve();root=p.parents[2]
old=p.parent/'recovered-2026-10-06/native-subr-decoding/emaxx'
c=p.parent/'recovered-2026-10-06/native-subr-names/emaxx'
g=p.parent/'rebuilt-2026-10-01/emacs'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
m=json.loads((p/'source306-manifest.json').read_text())
assert len(m)==537 and all(sha(old/n)==h for n,h in m.items())
assert not c.exists();c.parent.mkdir();(c.parent/'emacs').symlink_to(g,target_is_directory=True)
for cmd in [['git','clone','--shared','--quiet','--no-checkout',str(root),str(c)],['git','-C',str(c),'sparse-checkout','init','--no-cone'],['git','-C',str(c),'sparse-checkout','set','--no-cone',*sorted({'/'+n for n in m}|{'/tools/','/compat/','/tests/fixtures/'})],['git','-C',str(c),'checkout','--detach','2b561470516c519f2198d2551c7b85b474defcfc']]:subprocess.run(cmd,check=True)
for n in m:(c/n).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(old/n,c/n)
f=c/'src/lisp/native_comp/loader.rs';s=f.read_text();a='''            name: CString::new(symbol_name)
                .map_err(|_| super::lisp::native_ice("NUL in native name"))?,'''
b='''            // comp.c:make_subr uses xstrdup(SSDATA(symbol_name)): an
            // embedded NUL terminates the subr's C name, not the Lisp symbol.
            name: CString::new(symbol_name.split('\\0').next().unwrap_or_default())
                .expect("C name prefix contains no NUL"),'''
assert s.count(a)==1;f.write_text(s.replace(a,b))
f=c/'tests/fixtures/native-subr-c-names.el'
f.write_text('''(progn
  (require 'comp)
  (let ((lexical-binding t) rows)
    (dolist (parts '(("native-name-prefix-" "suffix")
                     ("native-name-λ-" "tail")
                     ("" "native-empty-prefix")))
      (let* ((name (intern (concat (car parts) (string 0) (cadr parts))))
             (prefix (car parts)))
        (fset name (lambda (argument) (+ argument 3)))
        (native-compile name)
        (let ((function (symbol-function name)))
          (unless (native-comp-function-p function)
            (error "Name fixture must execute native code"))
          (garbage-collect)
          (push (list (equal (symbol-name name)
                             (concat prefix (string 0) (cadr parts)))
                      (subr-name function)
                      (equal (prin1-to-string function)
                             (concat "#<subr " prefix ">"))
                      (funcall name 7) (funcall function 29)) rows))))
    (nreverse rows)))
''')
f=c/'src/lisp/primitives/tests.rs';s=f.read_text();a='#[test]\nfn native_subr_authority_preserves_gnu_metadata_calls_and_identity() {'
b='''#[test]
fn native_subr_c_names_follow_gnu_nul_termination_without_changing_symbols() {
    assert_oracle_contract_matches_interpreter(
        include_str!("../../../tests/fixtures/native-subr-c-names.el"),
        include_str!("../../../tests/fixtures/native-subr-c-names.expected").trim(),
        "native C names terminate at NUL while actual Lisp symbol identity remains intact",
    );
}

''';assert s.count(a)==1;f.write_text(s.replace(a,b+a))
(p/'source307-working-init.json').open('x').write(json.dumps(dict(status='working successor; not frozen or validated',candidate=str(c),base='2b561470516c519f2198d2551c7b85b474defcfc',GNU='comp.c:make_subr xstrdup(SSDATA(symbol_name)); actual GNU probe native-subr-nul-name-gnu confirms(t shortened-C-name 10).',repair='Preserve the full fset Lisp symbol, while its owned C name ends at the first NUL.306 CString::new rejected this valid named native function; do not promote it as complete. Add three actual named-native controls, including Unicode and an empty C prefix; every previous test/fixture stays.',goal_complete=False),indent=2))
print(c)
