from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).parent.resolve();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
name='lisp::eval::tests::eval_05::dabbrev_cross_buffer_cases_remain_order_independent_in_native_runner'
results=[]
for tag,folder in [('source304','recovered-2026-10-05/native-arithmetic-audit/emaxx'),('source306','recovered-2026-10-06/native-subr-decoding/emaxx')]:
 c=p.parent/folder;m=json.loads((p/(tag+'-manifest.json')).read_text());assert all(sha(c/n)==h for n,h in m.items())
 env=json.loads((p/(tag+'-gate-focused-command.json' if tag=='source306' else tag+'-gate-selected-command.json')).read_text())['environment_overrides']
 metadata=json.loads((p/(tag+'-gate-focused-command.json' if tag=='source306' else tag+'-gate-selected-command.json')).read_text())
 b=Path(metadata['command'][0]);assert b.is_file();h=sha(b)
 assert h==sha(p/(tag+'-gate-libtest')) and b.parent.name=='deps'
 command=[str(b),'--exact',name,'--test-threads=1','--nocapture']
 prefix=p/(tag+'-dabbrev-native-object-real-location')
 prefix.with_suffix('.command.json').open('x').write(json.dumps(dict(command=command,cwd=str(c),environment_overrides=env,binary_sha256=h,source_manifest=tag+'-manifest.json',timeout_seconds=600),indent=2))
 start=time.monotonic()
 with prefix.with_suffix('.log').open('xb') as f:r=subprocess.run(command,cwd=c,env={**os.environ,**env},stdout=f,stderr=subprocess.STDOUT,timeout=600)
 result=dict(source=tag,exit_code=r.returncode,elapsed_seconds=time.monotonic()-start,binary_unchanged=sha(b)==h,source_unchanged=all(sha(c/n)==h for n,h in m.items()))
 prefix.with_suffix('.result.json').open('x').write(json.dumps(result,indent=2));results.append(result);print(json.dumps(result),flush=True)
(p/'native-subr-dabbrev-real-location-comparison.json').open('x').write(json.dumps(results,indent=2))
