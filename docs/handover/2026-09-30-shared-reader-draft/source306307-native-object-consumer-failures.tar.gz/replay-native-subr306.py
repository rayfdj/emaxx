from pathlib import Path
import hashlib, json, subprocess, sys
p = Path(__file__).parent.resolve(); root = p.parents[2]
tag, directory = sys.argv[1:]; c = Path(directory)
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
m = json.loads((p/(tag+'-manifest.json')).read_text())
assert len(m) == 537 and all(sha(c/n) == h for n,h in m.items())
head = subprocess.check_output(['git','rev-parse','HEAD'], cwd=c, text=True).strip()
tracked = set(subprocess.check_output(['git','ls-files'], cwd=c, text=True).splitlines())
records = []
for kind,base in [('incremental',head),('complete','21d20f0eec08f3c013d5d3eb3bd6e9cfc16b3199')]:
    patch = subprocess.check_output(['git','diff','--binary',base,'--',*sorted(m)], cwd=c)
    for n in sorted(set(m)-tracked):
        r = subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',n], cwd=c, capture_output=True)
        assert r.returncode == 1 and not r.stderr
        patch += r.stdout
    pf = p / f'{tag}-portable-{kind}.patch'
    with pf.open('xb') as f: f.write(patch)
    replay = p / f'{tag}-replay-{kind}'; assert not replay.exists()
    subprocess.run(['git','clone','--shared','--quiet','--no-checkout',str(root),str(replay)], check=True)
    existing = set(subprocess.check_output(['git','ls-tree','-r','--name-only',base], cwd=replay, text=True).splitlines())
    subprocess.run(['git','checkout',base,'--',*sorted(existing & set(m))], cwd=replay, check=True)
    subprocess.run(['git','apply','--check',str(pf)], cwd=replay, check=True)
    subprocess.run(['git','apply',str(pf)], cwd=replay, check=True)
    assert all(sha(replay/n)==h and (replay/n).stat().st_mode & 0o777 == (c/n).stat().st_mode & 0o777 for n,h in m.items())
    records.append(dict(patch=pf.name, sha256=sha(pf), base=base, inputs=len(m), bytes_and_modes='exact'))
with (p/(tag+'-portable-draft-audit.json')).open('x') as f:
    json.dump(dict(status='portable unapplied draft verified', candidate=str(c), patches=records, goal_complete=False, qualification='Source306 carries the305 migration and repairs the checked native-word decoder to accept allocator-verified PVEC_SUBR. The failed305 two-pass/two-failure run remains preserved. It removes the persistent function, name and C-name maps and the detached native-function RecordKind. Calls, Lisp metadata, tracing and dumping read the actual GNU-layout88-byte subr. The preserved code15 dump codec constructs actual subrs, not runtime records. Four new contracts add actual layout/ABI, live and dead GC, current target/arity and same-input ordinary GNU metadata coverage. All old test names/assertions and fixture bytes remain except representation-only native-presence detections and equivalent real-unit suspension ownership fixtures. This is an unapplied draft, not full validation, physical-accounting completion or a performance claim.'), f, indent=2)
print(json.dumps(records))
