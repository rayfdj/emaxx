from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
from native_fixed_validation_support import audit_selected

p = Path(__file__).parent.resolve()
c = p.parent / 'recovered-2026-10-06/native-subr-names/emaxx'
g = p.parent / 'rebuilt-2026-10-01/emacs'
target = c / 'target/vm-dispatch-validation'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda f: json.loads(f.read_text())
base = read(p / 'source306-manifest.json')
names = sorted(set(base) | {'tests/fixtures/native-subr-c-names.el', 'tests/fixtures/native-subr-c-names.expected'})
manifest = {n: sha(c / n) for n in names}
assert len(manifest) == 539 and (c.parent / 'emacs').resolve() == g.resolve()
assert all(manifest[n] == h for n, h in base.items() if n.startswith('tests/'))
changes = [n for n, h in manifest.items() if base.get(n) != h]
assert changes == ['src/lisp/native_comp/loader.rs', 'src/lisp/primitives/print.rs', 'src/lisp/primitives/print/output.rs', 'src/lisp/primitives/tests.rs', 'tests/fixtures/native-subr-c-names.el', 'tests/fixtures/native-subr-c-names.expected'], changes
assert (c / 'src/anti_cheat.rs').read_bytes() == (p.parents[2] / 'src/anti_cheat.rs').read_bytes()
assert not any('NativeCompiledFunction' in (c / n).read_text() for n in names if n.endswith('.rs'))
with (p / 'source307-manifest.json').open('x') as stream:
    json.dump(manifest, stream, indent=2)
patch = subprocess.check_output(['git', 'diff', '--binary', '--', *names], cwd=c)
tracked = set(subprocess.check_output(['git', 'ls-files'], cwd=c, text=True).splitlines())
for n in sorted(set(manifest) - tracked):
    r = subprocess.run(['git', 'diff', '--no-index', '--binary', '--', '/dev/null', n], cwd=c, capture_output=True)
    assert r.returncode == 1 and not r.stderr
    patch += r.stdout
with (p / 'source307-draft.patch').open('xb') as stream:
    stream.write(patch)
env = dict(os.environ, CARGO_TARGET_DIR=str(target), CARGO_BUILD_JOBS='1', LANG='C', LC_ALL='C',
           RUST_MIN_STACK='134217728', RUST_TEST_THREADS='1', EMAXX_GC_VERIFY='1',
           EMAXX_GNU_SOURCE_DIRECTORY=str(g), EMAXX_DUMP_SOURCE_DIRECTORY=str(g), EMACS_TEST_DIRECTORY=str(g / 'test'),
           EMAXX_IMAGE_TEMPLATE='1', EMAXX_FIXTURE_IMAGE_DIR=str(p / 'fixture-images-source307'))
state = dict(status='starting', candidate=str(c), source_manifest='source307-manifest.json', changes=changes,
             results=[], profiles={}, goal_complete=False, runner=Path(__file__).name, runner_sha256=sha(Path(__file__)))
unchanged = lambda: all(sha(c / n) == h for n, h in manifest.items())

def save_state():
    (p / 'source307-validation-state.json').write_text(json.dumps(state, indent=2) + '\n')

def run(stage, command, timeout=1800):
    assert unchanged()
    record = dict(command=command, working_directory=str(c), timeout_seconds=timeout,
                  environment_overrides={k: v for k, v in env.items() if k.startswith(('CARGO_', 'EMAXX_', 'RUST_', 'EMACS_TEST')) or k in ('LANG', 'LC_ALL')})
    with (p / ('source307-' + stage + '-command.json')).open('x') as f:
        json.dump(record, f, indent=2)
    state['status'] = 'running ' + stage
    save_state()
    started = time.monotonic()
    with (p / ('source307-' + stage + '.log')).open('xb') as log:
        try:
            completed = subprocess.run(command, cwd=c, env=env, stdin=subprocess.DEVNULL,
                                       stdout=log, stderr=subprocess.STDOUT, timeout=timeout)
            code, timed_out = completed.returncode, False
        except subprocess.TimeoutExpired:
            code, timed_out = None, True
    result = dict(stage=stage, exit_code=code, timed_out=timed_out,
                  elapsed_seconds=time.monotonic() - started, source_unchanged=unchanged())
    with (p / ('source307-' + stage + '-result.json')).open('x') as f:
        json.dump(result, f, indent=2)
    state['results'].append(result)
    save_state()
    print(json.dumps(result), flush=True)
    assert code == 0 and not timed_out and result['source_unchanged'], result

try:
    assert not target.exists()
    target.parent.mkdir(exist_ok=True)
    source_cache = p.parent / 'recovered-2026-10-06/native-subr-objects/emaxx/target/vm-dispatch-validation'
    run('cache-clone', ['/bin/cp', '-cR', str(source_cache), str(target)])
    run('fresh-crate', ['cargo', 'clean', '--package', 'emaxx'])
    run('fresh-gate-crate', ['cargo', 'clean', '--package', 'emaxx', '--profile', 'gate'])
    run('fresh-release-crate', ['cargo', 'clean', '--package', 'emaxx', '--profile', 'release'])
    for stage, command in [
        ('fmt', ['cargo', 'fmt', '--all', '--', '--check']),
        ('check', ['cargo', 'check', '--locked', '--all-targets', '--all-features']),
        ('clippy', ['cargo', 'clippy', '--locked', '--all-targets', '--all-features', '--', '-D', 'warnings']),
        ('diff', ['git', 'diff', '--check']),
    ]:
        run(stage, command)
    for profile in ('gate', 'release'):
        run(profile + '-build', ['cargo', 'test', '--locked', '--profile', profile, '--all-features', '--lib', '--no-run', '--message-format=json'])
        artifacts = [json.loads(line) for line in (p / ('source307-' + profile + '-build.log')).read_text().splitlines() if line.startswith('{')]
        binaries = [Path(a['executable']) for a in artifacts if a.get('reason') == 'compiler-artifact' and a.get('profile', {}).get('test') and a.get('executable') and a['target']['name'] == 'emaxx' and 'lib' in a['target']['kind']]
        assert len(binaries) == 1
        assert all(a.get('fresh') is False for a in artifacts if a.get('reason') == 'compiler-artifact' and a['target']['name'] == 'emaxx' and a.get('profile', {}).get('test'))
        binary = binaries[0]
        retained = p / ('source307-' + profile + '-libtest')
        assert not retained.exists()
        shutil.copy2(binary, retained)
        assert sha(binary) == sha(retained)
        assert sha(binary) != sha(p / ('source304-' + profile + '-libtest'))
        run(profile + '-inventory', [str(binary), '--list'])
        inventory = [line[:-6] for line in (p / ('source307-' + profile + '-inventory.log')).read_text().splitlines() if line.endswith(': test')]
        prior = [line[:-6] for line in (p / ('source304-' + profile + '-inventory.log')).read_text().splitlines() if line.endswith(': test')]
        new_tests = {
            'lisp::alloc::vectors::tests::native_subr_allocation_has_gnu_fields_and_direct_tagged_identity',
            'lisp::alloc::vectors::tests::native_subr_marks_all_five_fields_and_releases_unreachable_cycles',
            'lisp::native_comp::loader::tests::native_subr_calls_read_actual_target_and_arity_fields',
            'lisp::primitives::tests::native_subr_authority_preserves_gnu_metadata_calls_and_identity',
            'lisp::primitives::tests::native_subr_c_names_follow_gnu_nul_termination_without_changing_symbols',
        }
        assert set(inventory) == set(prior) | new_tests and len(inventory) == len(set(inventory))
        baseline_selectors = set(read(p / 'source304-validation-result.json')['profiles'][profile]['selectors'])
        selectors = [n for n in inventory if n in baseline_selectors or re.search(r'native|pdump|dump_|image|module|weak|thread|suspended|purecopy|hash|value_|print', n)]
        assert baseline_selectors <= set(selectors) and new_tests <= set(selectors)
        # Run the new storage/GC/ABI/actual-GNU contracts before the full
        # affected selection, retaining separate actual verdicts for both.
        run(profile + '-focused', [str(binary), '--exact', '--test-threads=1', *sorted(new_tests)])
        focused = audit_selected((p / ('source307-' + profile + '-focused.log')).read_text(), sorted(new_tests))
        state.setdefault('focused', {})[profile] = focused
        save_state()
        run(profile + '-selected', [str(binary), '--exact', '--test-threads=1', *selectors])
        raw = (p / ('source307-' + profile + '-selected.log')).read_text()
        counts = audit_selected(raw, selectors)
        state['profiles'][profile] = dict(**counts, selectors=selectors,
                                          binary=str(binary), retained_binary=str(retained), binary_sha256=sha(binary))
        retained_inputs = []
        retained_dir = p / ('source307-' + profile + '-retained-inputs')
        retained_dir.mkdir()
        for original in [binary, *sorted(Path(env['EMAXX_FIXTURE_IMAGE_DIR']).glob('*.pdmp'))]:
            copy = retained_dir / original.name
            shutil.copy2(original, copy)
            assert sha(copy) == sha(original)
            retained_inputs.append(dict(original=str(original), retained=str(copy), sha256=sha(copy), bytes=copy.stat().st_size))
        assert len(retained_inputs) >= 2
        state['profiles'][profile]['retained_inputs'] = retained_inputs
        save_state()
    run('ordinary-build', ['cargo', 'build', '--locked', '--release', '--all-features', '--bin', 'emaxx', '--bin', 'make-fingerprint', '--bin', 'compat-harness', '--message-format=json'])
    ordinary_messages = [json.loads(line) for line in (p / 'source307-ordinary-build.log').read_text().splitlines() if line.startswith('{')]
    assert any(a.get('reason') == 'compiler-artifact' and a['target']['name'] == 'emaxx' and a.get('fresh') is False for a in ordinary_messages)
    env['EMAXX_IMAGE_FORCE'] = '1'
    run('ordinary-image', ['sh', 'tools/build-image.sh', str(target / 'release/emaxx')])
    del env['EMAXX_IMAGE_FORCE']
    artifacts = {}
    for f in [target / 'release/emaxx', target / 'release/emaxx.pdmp']:
        copy = p / ('source307-ordinary-' + f.name)
        assert not copy.exists()
        shutil.copy2(f, copy)
        assert sha(copy) == sha(f)
        artifacts[str(f)] = dict(sha256=sha(f), immutable_copy=str(copy), bytes=f.stat().st_size)
    with (p / 'source307-ordinary-artifacts.json').open('x') as f:
        json.dump(artifacts, f, indent=2)
    state['status'] = 'strict, selected and ordinary build passed; raw audit and ordinary comparisons required'
except Exception as error:
    state.update(status='validation stopped', error=repr(error))
finally:
    save_state()
    with (p / 'source307-validation-result.json').open('x') as f:
        json.dump(state, f, indent=2)
print(json.dumps(dict(status=state['status'], profiles={k: r['passed'] for k, r in state['profiles'].items()}, error=state.get('error'))), flush=True)
sys.exit(0 if state['status'].startswith('strict, selected') else 1)
