from pathlib import Path
import hashlib,io,json,re,subprocess,tarfile
p=Path(__file__).parent.resolve();root=p.parents[2];sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();read=lambda n:json.loads((p/n).read_text());head='6ab3346049f08a08c5fbb842fc3f737c22c40c75'
s=read('source313-local-validation-result.json');assert s['head']==head and s['status']=='passed: strict checks and both original census controls in gate and release'
manifest=read('source313-manifest.json');modes=read('source313-modes.json');assert len(manifest)==552 and set(manifest)==set(modes)
archive=subprocess.check_output(['git','archive',head,'--',*manifest],cwd=root)
with tarfile.open(fileobj=io.BytesIO(archive)) as src:
 for n,h in manifest.items():assert sha(root/n)==h and (root/n).stat().st_mode&0o777==modes[n] and hashlib.sha256(src.extractfile(n).read()).hexdigest()==h and src.getmember(n).mode&0o111==modes[n]&0o111
assert len(s['results'])==9
for r in s['results']:
 assert r['exit_code']==0 and not r['timed_out'] and r['source_unchanged']
 raw=(p/('source313-'+r['stage']+'.log')).read_text();assert not re.search(r'^warning(?:\[|:)',raw,re.M)
profiles={};controls=['lisp::primitives::tests::native_pseudovector_census_matches_gnu_word_layout','lisp::primitives::tests::native_vector_and_closure_census_matches_gnu_word_layout']
for profile in ['gate','release']:
 binary=read('source313-'+profile+'-binary.json');assert sha(Path(binary['original']))==sha(Path(binary['retained']))==binary['sha256']
 messages=[json.loads(x) for x in (p/('source313-'+profile+'-build.log')).read_text().splitlines() if x.startswith('{')];assert all(m.get('message',{}).get('level') not in ['warning','error'] for m in messages)
 selected=[m for m in messages if m.get('reason')=='compiler-artifact' and m['target']['name']=='emaxx' and m.get('profile',{}).get('test') and m.get('executable')];assert len(selected)==1 and not selected[0]['fresh'] and selected[0]['executable']==binary['original']
 raw=(p/('source313-'+profile+'-focused.log')).read_text();assert sorted(re.findall(r'^test (\S+) \.\.\. ok$',raw,re.M))==controls
 assert re.findall(r'^test result: (.*)$',raw,re.M)==[next(x for x in raw.splitlines() if x.startswith('test result: ')).removeprefix('test result: ')] and '2 passed; 0 failed; 0 ignored;' in raw
 cmd=read('source313-'+profile+'-focused-command.json');assert sorted(cmd['command'][3:])==controls and cmd['command'][1:3]==['--exact','--test-threads=1']
 inv=(p/('source313-'+profile+'-inventory.log')).read_text();names=[x[:-6] for x in inv.splitlines() if x.endswith(': test')];assert len(names)==len(set(names))==(3058 if profile=='gate' else 3057)
 profiles[profile]=dict(passed=2,failed=0,ignored=0,inventory=len(names),binary=binary)
assert read('source313-census-setup-audit.json')['status']=='40 ordinary GNU/Emaxx processes independently verified'
result=dict(status='passed',source_commit=head,source_inputs=552,source_manifest='source313-manifest.json',modes_manifest='source313-modes.json',changed_inputs=s['changed_inputs'],strict_checks=['fmt','check','clippy'],profiles=profiles,ordinary_processes=40,goal_complete=False,qualification='Only two fixture preambles differ from312; production, original constructors/sizes/assertions/expectations are byte-identical. Strict checks and fresh gate/release embedded-fixture controls passed; complete predecessor312 macOS Rust coverage remains separately bound to its exact source and artifacts. Linux313 and terminal312 have separate pending audits. This is not full-goal completion.')
(p/'source313-local-validation-audit.json').open('x').write(json.dumps(result,indent=2));print({k:result[k] for k in ['status','source_inputs','strict_checks','ordinary_processes']})
