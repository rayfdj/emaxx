from pathlib import Path
import hashlib, json, os, subprocess, time

p = Path(__file__).parent.resolve()
root = p.parents[2]
g = p.parent / 'rebuilt-2026-10-01/emacs'
candidate = p.parent / 'recovered-2026-10-06/bytecode-gc/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
destination = p / 'source313-census-setup-macos'
destination.mkdir()
results = []
for name in ['vector-closure-rounded-census', 'vector-pseudovector-word-census']:
    fixture = p / ('source313-' + name + '.el')
    expected_file = root / 'tests/fixtures' / (name + '.expected')
    expected = expected_file.read_bytes().rstrip(b'\n')
    for padding in [0, 8, 16, 32, 64, 128, 256, 1024, 4096, 8192]:
        for label, binary in [('gnu', g / 'src/emacs'), ('emaxx', candidate / 'target/gc-development/release/emaxx')]:
            stem = destination / (name + '-' + str(padding) + '-' + label)
            command = [str(binary), '-Q', '--batch', '--eval', '(prin1 ' + fixture.read_text() + ')']
            env = dict(LANG='C', LC_ALL='C', EMAXX_GC_VERIFY='1', CENSUS_SETUP_PADDING='a' * padding,
                       EMAXX_GNU_SOURCE_DIRECTORY=str(g), EMAXX_DUMP_SOURCE_DIRECTORY=str(g), EMACS_TEST_DIRECTORY=str(g / 'test'))
            inputs = {str(f): sha(f) for f in [binary, binary.with_suffix('.pdmp'), fixture, expected_file, Path(__file__)]}
            stem.with_suffix('.command.json').open('x').write(json.dumps(dict(command=command, cwd=str(root), environment_overrides=env, inputs=inputs, timeout_seconds=120), indent=2))
            started = time.monotonic()
            try:
                run = subprocess.run(command, cwd=root, env=dict(os.environ, **env), stdin=subprocess.DEVNULL, capture_output=True, timeout=120)
                code, out, err, timeout = run.returncode, run.stdout, run.stderr, False
            except subprocess.TimeoutExpired as error:
                code, out, err, timeout = None, error.stdout or b'', error.stderr or b'', True
            stem.with_suffix('.stdout').open('xb').write(out)
            stem.with_suffix('.stderr').open('xb').write(err)
            record = dict(fixture=name, padding=padding, editor=label, exit_code=code, timed_out=timeout,
                          elapsed_seconds=time.monotonic()-started, exact_expected=out == expected,
                          stderr_empty=not err, stdout_sha256=hashlib.sha256(out).hexdigest(),
                          stderr_sha256=hashlib.sha256(err).hexdigest(), inputs_unchanged=all(sha(Path(n)) == h for n, h in inputs.items()))
            stem.with_suffix('.result.json').open('x').write(json.dumps(record, indent=2))
            results.append(record)
            print(name, padding, label, code, record['exact_expected'], flush=True)
(p / 'source313-census-setup-macos-result.json').open('x').write(json.dumps(results, indent=2))
assert all(r['exit_code'] == 0 and not r['timed_out'] and r['exact_expected'] and r['stderr_empty'] and r['inputs_unchanged'] for r in results)
