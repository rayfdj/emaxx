from pathlib import Path
import hashlib,io,json,re,subprocess,sys,tarfile
p=Path(__file__).parent
root=Path(sys.argv[1]);head=sys.argv[2];out=Path(sys.argv[3])
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
s=json.loads((root/'summary.json').read_text())
assert s['status']=='passed' and s['scope']=='full'
assert s['git']=={'dirty':False,'head':'6ab3346049f08a08c5fbb842fc3f737c22c40c75'}
repository=p.parents[2]
checkout=repository
inputs=json.loads((p/'source313-manifest.json').read_text())
assert len(inputs)==552 and all(sha(checkout/name)==digest for name,digest in inputs.items())
assert head=='6ab3346049f08a08c5fbb842fc3f737c22c40c75'
data=subprocess.check_output(['git','archive',head,'--',*sorted(inputs)],cwd=repository)
with tarfile.open(fileobj=io.BytesIO(data)) as published:
    assert all(hashlib.sha256(published.extractfile(name).read()).hexdigest()==digest for name,digest in inputs.items())
modes=json.loads((p/'source313-modes.json').read_text())
auxiliary=json.loads((p/'source310-validation-input-recovery.json').read_text())['auxiliary_inputs']
assert len(auxiliary)==94 and set(modes)==set(inputs)
complete={name:dict(sha256=digest,mode=modes[name]) for name,digest in inputs.items()}
for name,entry in auxiliary.items():
    if name in complete: assert complete[name]=={k:entry[k] for k in ('sha256','mode')}
    complete[name]={k:entry[k] for k in ('sha256','mode')}
assert all(sha(checkout/name)==entry['sha256'] and (checkout/name).stat().st_mode & 0o777==entry['mode'] for name,entry in complete.items())
archive=subprocess.check_output(['git','archive',head,'--',*sorted(complete)],cwd=repository)
with tarfile.open(fileobj=io.BytesIO(archive)) as published:
    for name,entry in complete.items():
        member=published.getmember(name)
        assert member.mode & 0o111==entry['mode'] & 0o111
        assert hashlib.sha256(published.extractfile(member).read()).hexdigest()==entry['sha256']
state=json.loads((p/'source313-linux-rust-terminal.json').read_text())
assert state['status']=='completed' and state['conclusion']=='success' and state['headSha']==s['git']['head']
download=json.loads((p/'source313-linux-rust-download-files.json').read_text())
assert all(sha(p/'source313-linux-rust-artifacts'/name)==digest for name,digest in download['files'].items())
assert s['repetitions']==1 and len(s['runs'])==1
inv=s['inventory'];run=s['runs'][0]
assert run['expected_tests']==run['observed_outcomes']==inv['total_tests']==inv['scheduled_tests']
assert {g['group'] for g in run['groups']}==set(inv['groups']) and len(run['groups'])==len(inv['groups'])
pattern=r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;'
passed=ignored=0
for g in run['groups']:
    assert g['exit_code']==0 and not g['timed_out']
    r=g['result'];assert r['status']=='ok' and r['failed']==r['measured']==0
    assert r['passed']+r['ignored']==g['expected_tests']==inv['groups'][g['group']]
    assert r['ignored']==g['expected_ignored']
    raw=(root/Path(g['log']).name).read_text();m=re.findall(pattern,raw)
    assert len(m)==1 and m[0]==('ok',str(r['passed']),'0',str(r['ignored']),'0',str(r['filtered_out']))
    passed+=r['passed'];ignored+=r['ignored']
assert inv['ignored_tests']==['tty::tty_differential_end_to_end','tty::tty_smoke_end_to_end'] and ignored==2
cargo={}
assert [c['stage'] for c in s['cargo_stages']]==['bins','integration']
for c in s['cargo_stages']:
    assert c['exit_code']==0
    raw=(root/Path(c['log']).name).read_text();m=re.findall(pattern,raw)
    assert len(m)==len(c['results']) and len(m)>0
    for row,r in zip(m,c['results']):
        assert r['status']=='ok' and r['failed']==r['ignored']==r['measured']==r['filtered_out']==0
        assert row==('ok',str(r['passed']),'0','0','0','0')
    cargo[c['stage']]=sum(r['passed'] for r in c['results'])
integration=(root/'integration.log').read_text()
identity=[line for line in integration.splitlines() if line.startswith('test unchanged_gnu_sources_produce_identical_native_artifacts ')]
assert identity and all(line.endswith(' ... ok') for line in identity),identity
retain=root/'retained-inputs';r=json.loads((retain/'manifest.json').read_text())
assert r['status']=='retained' and r['gate_status']=='passed' and r['gate_summary_sha256']==sha(root/'summary.json')
for f in r['files']:
    path=retain/f['artifact'];assert path.stat().st_size==f['bytes'] and sha(path)==f['sha256']
assert next(f for f in r['files'] if f['artifact']=='libtest')['sha256']==s['test_binary']['sha256']
assert json.loads((p/'source313-linux-rust-name-audit.json').read_text())['raw_names_verified']==3066
result={'status':'passed','source_commit':'6ab3346049f08a08c5fbb842fc3f737c22c40c75','source_manifest':'source313-manifest.json','incremental_patch_sha256':sha(p/'source313-census-setup.patch'),'validation_checkout':s['git'],'verified_source_equivalent_inputs':len(inputs),'verified_auxiliary_inputs':len(auxiliary),'verified_unique_inputs':len(complete),'library_passed':passed,'library_ignored':ignored,'cargo_passed':cargo,'total_passed':passed+sum(cargo.values()),'native_artifact_identity':'passed','native_identity_raw_lines':identity,'retained_files_verified':len(r['files']),'test_binary_sha256':s['test_binary']['sha256'],'summary_sha256':sha(root/'summary.json'),'qualification':'Complete group and Cargo result summaries cross-checked with raw logs and unchanged inventory counts. Post-run retained images do not establish which individual test used each file. Frozen and terminal runs are separate.'}
with out.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result,indent=2))
