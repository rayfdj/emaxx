from pathlib import Path
import hashlib,io,json,os,re,shutil,subprocess,tarfile,time
p=Path(__file__).parent.resolve();root=p.parents[2];g=p.parent/'rebuilt-2026-10-01/emacs';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
head='6ab3346049f08a08c5fbb842fc3f737c22c40c75';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
prior=json.loads((p/'source312-final-manifest.json').read_text());manifest={n:sha(root/n) for n in prior};changed=[n for n in prior if prior[n]!=manifest[n]]
assert sorted(changed)==['tests/fixtures/vector-closure-rounded-census.el','tests/fixtures/vector-pseudovector-word-census.el']
(p/'source313-manifest.json').open('x').write(json.dumps(manifest,indent=2));(p/'source313-modes.json').open('x').write(json.dumps({n:(root/n).stat().st_mode&0o777 for n in manifest},indent=2))
patch=subprocess.check_output(['git','diff','--binary',head+'^',head],cwd=root);(p/'source313-census-setup.patch').open('xb').write(patch)
env_overrides=dict(LANG='C',LC_ALL='C',CARGO_BUILD_JOBS='2',RUST_MIN_STACK='134217728',RUST_TEST_THREADS='1',EMAXX_GC_VERIFY='1',EMAXX_GNU_SOURCE_DIRECTORY=str(g),EMAXX_DUMP_SOURCE_DIRECTORY=str(g),EMACS_TEST_DIRECTORY=str(g/'test'),EMAXX_IMAGE_TEMPLATE='1',EMAXX_FIXTURE_IMAGE_DIR=str(p/'fixture-images-source313'))
env=dict(os.environ,**env_overrides);state=dict(status='starting',head=head,changed_inputs=changed,results=[],goal_complete=False)
unchanged=lambda:all(sha(root/n)==h for n,h in manifest.items())
def save():(p/'source313-local-validation-state.json').write_text(json.dumps(state,indent=2))
def run(stage,cmd,timeout=1800):
 assert unchanged();state['status']='running '+stage;save();start=time.monotonic()
 (p/('source313-'+stage+'-command.json')).open('x').write(json.dumps(dict(command=cmd,cwd=str(root),environment_overrides=env_overrides,timeout_seconds=timeout),indent=2))
 with (p/('source313-'+stage+'.log')).open('xb') as f:
  try:code=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,timeout=timeout).returncode;timed_out=False
  except subprocess.TimeoutExpired:code=None;timed_out=True
 result=dict(stage=stage,exit_code=code,timed_out=timed_out,elapsed_seconds=time.monotonic()-start,source_unchanged=unchanged());state['results'].append(result);save();print(result,flush=True)
 assert code==0 and not timed_out and result['source_unchanged'],result
 return p/('source313-'+stage+'.log')
try:
 for stage,cmd in [('fmt',['cargo','fmt','--all','--','--check']),('check',['cargo','check','--locked','--all-targets','--all-features']),('clippy',['cargo','clippy','--locked','--all-targets','--all-features','--','-D','warnings'])]:run(stage,cmd)
 controls=['lisp::primitives::tests::native_vector_and_closure_census_matches_gnu_word_layout','lisp::primitives::tests::native_pseudovector_census_matches_gnu_word_layout']
 for profile in ['gate','release']:
  log=run(profile+'-build',['cargo','test','--locked','--profile',profile,'--all-features','--lib','--no-run','--message-format=json'])
  messages=[json.loads(x) for x in log.read_text().splitlines() if x.startswith('{')];assert not any(m.get('message',{}).get('level') in ['error','warning'] for m in messages)
  artifacts=[m for m in messages if m.get('reason')=='compiler-artifact' and m['target']['name']=='emaxx' and m.get('profile',{}).get('test') and m.get('executable')];assert len(artifacts)==1 and not artifacts[0]['fresh']
  binary=Path(artifacts[0]['executable']);retained=p/('source313-'+profile+'-libtest');shutil.copy2(binary,retained);assert sha(binary)==sha(retained)
  (p/('source313-'+profile+'-binary.json')).open('x').write(json.dumps(dict(original=str(binary),retained=str(retained),sha256=sha(binary)),indent=2))
  inv=run(profile+'-inventory',[str(binary),'--list']);names=[x[:-6] for x in inv.read_text().splitlines() if x.endswith(': test')];assert len(names)==len(set(names))==(3058 if profile=='gate' else 3057)
  log=run(profile+'-focused',[str(binary),'--exact','--test-threads=1',*controls]);raw=log.read_text();assert all('test '+n+' ... ok' in raw for n in controls) and '2 passed; 0 failed; 0 ignored;' in raw
  assert sha(binary)==sha(retained)
 assert unchanged();state['status']='passed: strict checks and both original census controls in gate and release'
except Exception as e:state.update(status='failed',error=repr(e))
finally:save();(p/'source313-local-validation-result.json').open('x').write(json.dumps(state,indent=2))
print(state['status'],flush=True)
