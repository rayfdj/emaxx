from pathlib import Path
import hashlib,io,json,re,subprocess,tarfile
p=Path(__file__).parent.resolve();root=p.parents[2];sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();read=lambda f:json.loads(f.read_text())
head='6ab3346049f08a08c5fbb842fc3f737c22c40c75';base='7e894a667b0bc0076dcf0555fb1d1f6fcbfb648c'
names=['vector-closure-rounded-census','vector-pseudovector-word-census'];paddings=[0,8,16,32,64,128,256,1024,4096,8192]
changed=subprocess.check_output(['git','diff','--name-only',base,head],cwd=root,text=True).splitlines();assert changed==['tests/fixtures/'+n+'.el' for n in names]
insertion=b'    ;; This is a whole-heap census. Finish startup reclamation before\n    ;; measuring a new object: the first two GNU collections can otherwise\n    ;; differ by an unrelated closure and its constants vector.\n    (garbage-collect)\n    (garbage-collect)\n'
for n in names:
 old=subprocess.check_output(['git','show',base+':tests/fixtures/'+n+'.el'],cwd=root);new=(root/'tests/fixtures'/str(n+'.el')).read_bytes();assert new.count(insertion)==1 and new.replace(insertion,b'',1)==old
 assert new==(p/('source313-'+n+'.el')).read_bytes()
 assert subprocess.check_output(['git','show',base+':tests/fixtures/'+n+'.expected'],cwd=root)==(root/'tests/fixtures'/str(n+'.expected')).read_bytes()
records=read(p/'source313-census-setup-macos-result.json');assert len(records)==40;expected={(n,k,e) for n in names for k in paddings for e in ['gnu','emaxx']};seen=set();inputs={}
for r in records:
 key=(r['fixture'],r['padding'],r['editor']);assert key in expected and key not in seen;seen.add(key)
 stem=p/'source313-census-setup-macos'/('-'.join(map(str,key)))
 cmd=read(stem.with_suffix('.command.json'));result=read(stem.with_suffix('.result.json'));assert result==r
 assert cmd['command'][-1]=='(prin1 '+(p/('source313-'+key[0]+'.el')).read_text()+')'
 assert cmd['command'][1:4]==['-Q','--batch','--eval'] and cmd['timeout_seconds']==120
 assert cmd['environment_overrides']['CENSUS_SETUP_PADDING']=='a'*key[1]
 assert r['exit_code']==0 and not r['timed_out'] and r['inputs_unchanged'] and r['exact_expected'] and r['stderr_empty']
 assert not stem.with_suffix('.stderr').read_bytes();assert stem.with_suffix('.stdout').read_bytes()==(root/'tests/fixtures'/str(key[0]+'.expected')).read_bytes().rstrip(b'\n')
 assert sha(stem.with_suffix('.stdout'))==r['stdout_sha256'] and sha(stem.with_suffix('.stderr'))==r['stderr_sha256']
 for n,h in cmd['inputs'].items():assert sha(Path(n))==h;inputs[n]=h
assert seen==expected
result=dict(status='40 ordinary GNU/Emaxx processes independently verified',base_commit=base,fixture_commit=head,production_sources='byte-identical to source312',changed_inputs=changed,paddings=paddings,raw_directory=str(p/'source313-census-setup-macos'),records=records,inputs=inputs,raw_files={str(f.relative_to(p)):sha(f) for f in (p/'source313-census-setup-macos').iterdir()},goal_complete=False,qualification='Two unconditional collections precede object measurements in both editors. All original constructors, sizes, assertions and exact expected bytes remain. No output correction, tolerance, retry-until-pass, workload reduction or runtime special case. This macOS differential evidence alone does not certify Linux; separate complete Linux Rust and GNU diagnosis required. The source312 full Rust failure and its actual GNU outputs remain preserved.')
(p/'source313-census-setup-audit.json').open('x').write(json.dumps(result,indent=2));print(result['status'])
