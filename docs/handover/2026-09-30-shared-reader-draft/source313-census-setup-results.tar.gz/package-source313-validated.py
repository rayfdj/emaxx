from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve();out=p.parents[2]/'docs/handover/2026-09-30-shared-reader-draft';sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda n:json.loads((p/n).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package');exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
local=read('source313-local-validation-audit.json');linux=read('source313-linux-rust-audit.json');census=read('source313-linux-census-audit.json');portable=read('source313-portable-audit.json')
assert local['status']==linux['status']==census['status']==portable['status']=='passed';assert linux['total_passed']==3167 and linux['library_ignored']==2;assert read('source313-linux-rust-name-audit.json')['raw_names_verified']==3066
files={};excluded=[];allowed={'.json','.log','.txt','.py','.patch','.stdout','.stderr','.el','.expected','.h','.c','.loaded','.apparmor'}
for name in ['source313-census-setup-macos','source313-linux-rust-artifacts','source313-linux-gnu-census-artifacts']:
 for f in (p/name).rglob('*'):
  if f.is_file():
   if f.suffix in allowed or f.name in ['Makefile','stdout','stderr']:files[str(f.relative_to(p))]=f
   else:excluded.append(dict(path=str(f.relative_to(p)),bytes=f.stat().st_size,sha256=sha(f.read_bytes())))
for f in p.iterdir():
 if f.name=='source313-linux-rust-download-retry.log':continue
 if f.is_file() and f.suffix in allowed and f.name.startswith('source313-') and not f.name.startswith('source313-merge-evidence-'):files[f.name]=f
helpers=['probe-source313-census-setup.py','validate-source313-local.py','audit-source313-census-setup.py','audit-source313-local-validation.py','audit-source313-portable.py','audit-source313-portable-initial.py','audit-source313-linux-rust.py','verify-source313-linux-rust.py','audit-source313-linux-census.py','collect-source313-linux.py','source310-validation-input-recovery.json',Path(__file__).name,'package-source196-failure-and197-results.py']
for n in helpers:files[n]=p/n
for profile in ['gate','release']:
 b=read('source313-'+profile+'-binary.json');f=Path(b['retained']);excluded.append(dict(path=f.name,bytes=f.stat().st_size,sha256=sha(f.read_bytes())))
assert all(f.is_file() for f in files.values())
package('source313-census-setup-results',files,dict(status='fixture-only correction validated on Linux and macOS',source_commit='6ab3346049f08a08c5fbb842fc3f737c22c40c75',local=local,linux_rust=linux,linux_census={k:census[k] for k in ['status','run_id','gnu_processes','rust_processes','rust_passes','primitive_group','complete_library_inventory','qualification']},portable=portable,excluded_binaries=excluded,goal_complete=False,qualification='Two unconditional pre-measurement collections remove startup reclamation from the object-footprint delta. Every original allocation size/constructor/expectation/assertion is preserved; production312 bytes are unchanged.40 local GNU/Emaxx runs, gate/release controls,18 Linux GNU runs,693 bounded Rust passes and the complete3167-pass Linux gate all audited. Earlier312 GNU-reference failures remain separately preserved.312 frozen/macOS/terminal results have their own exact artifact identities. Remaining architecture/accounting/soundness and calibrated every-case performance requirements are not complete.'))
