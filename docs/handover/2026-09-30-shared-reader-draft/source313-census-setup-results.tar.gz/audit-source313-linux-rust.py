from pathlib import Path
import hashlib,json,re,subprocess,sys
p=Path(__file__).parent.resolve();head='6ab3346049f08a08c5fbb842fc3f737c22c40c75';artifact=p/('source313-linux-rust-artifacts/ordinary-linux-'+head);root=artifact/'rust';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();read=lambda f:json.loads(f.read_text())
terminal=read(p/'source313-linux-rust-terminal.json');assert terminal['headSha']==head and terminal['status']=='completed' and terminal['conclusion']=='success'
files={str(f.relative_to(p/'source313-linux-rust-artifacts')):sha(f) for f in artifact.rglob('*') if f.is_file()}
(p/'source313-linux-rust-download-files.json').open('x').write(json.dumps(dict(files=files,run_id=37606546402,goal_complete=False),indent=2))
s=read(root/'summary.json');assert s['status']=='passed' and s['git']==dict(dirty=False,head=head)
inventory=[x[:-6] for x in (root/'inventory.txt').read_text().splitlines() if x.endswith(': test')]
prior=p/'source312-linux-rust-artifacts/ordinary-linux-7e894a667b0bc0076dcf0555fb1d1f6fcbfb648c/rust/inventory.txt'
old={x[:-6] for x in prior.read_text().splitlines() if x.endswith(': test')}
added=set()
assert len(inventory)==len(set(inventory))==3066 and set(inventory)==old
seen={}
for group in s['runs'][0]['groups']:
 raw=(root/Path(group['log']).name).read_text();starts=list(re.finditer(r'^test (\S+) \.\.\. ',raw,re.M));assert len(starts)==group['expected_tests']
 for i,m in enumerate(starts):
  end=starts[i+1].start() if i+1<len(starts) else raw.rindex('test result:');verdict=raw[m.end():end].strip();assert m[1] not in seen
  if m[1] in s['inventory']['ignored_tests']:assert verdict.startswith('ignored');seen[m[1]]='ignored'
  else:assert re.search(r'(?:^|\s)ok$',verdict),(m[1],verdict);seen[m[1]]='passed'
assert set(seen)==set(inventory)
(p/'source313-linux-rust-name-audit.json').open('x').write(json.dumps(dict(status='passed',raw_names_verified=len(seen),added_tests=sorted(added),raw_verdicts=seen,inventory_sha256=sha(root/'inventory.txt'),goal_complete=False),indent=2))
helper=p/'verify-source313-linux-rust.py'
subprocess.run([sys.executable,str(helper),str(root),head,str(p/'source313-linux-rust-audit.json')],check=True)
cap=artifact/'oracle-inputs';m=read(cap/'manifest.json');v=read(cap/'verification.json')
assert m['status']=='captured' and m['source_commit']=='636f166cfc86aa90d63f592fd99f3fdd9ef95ebd' and m['source_tracked_changes']==[]
assert v['status']=='unchanged' and v['files_verified']==4 and v['capture_manifest_sha256']==sha(cap/'manifest.json')
for item in m['files']:
 f=cap/item['artifact'];assert sha(f)==item['sha256'] and f.stat().st_size==item['bytes']
assert m['files'][0]['sha256']=='5e1721732427d69d8af63211f1e3833ec21e40f97f4b7f6cd4cb224b72cebfcf'
assert m['files'][1]['sha256']=='bf4974228f3b3ea4374cec75a38eeb2bd0e7dd944da5bec4e6ad0387092502ae'
(p/'source313-linux-rust-oracle-audit.json').open('x').write(json.dumps(dict(status='passed',capture=m,verification=v,goal_complete=False,qualification='The pinned Linux GNU inputs were retained before this run and verified unchanged after it. The full-source313 Rust pass, including both GNU census assertions, does not erase the preserved312 reference failures.313 changes only the two census preambles; constructor/size/expected coverage and production source remain unchanged.'),indent=2))
print('Complete Linux source313 raw names, counts, artifact identities and retained GNU inputs verified')
