from pathlib import Path
import hashlib,io,json,re,subprocess,sys,tarfile
p=Path(__file__).parent.resolve();root=p.parents[2];sys.path.insert(0,str(root/'tools'));import grouped_gate as gate
head='6ab3346049f08a08c5fbb842fc3f737c22c40c75';d=p/('source313-linux-gnu-census-artifacts/ordinary-linux-'+head+'/gnu-census');sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();read=lambda f:json.loads(f.read_text())
t=read(p/'source313-linux-gnu-census-terminal.json');assert t['headSha']==head and t['status']=='completed' and t['conclusion']=='success'
s=read(d/'summary.json');assert s['status']=='diagnostic completed' and s['failed_processes']==0 and s['git']==s['source_after']==dict(head=head,dirty=False) and s['compiled_inputs_unchanged'] and s['inputs_unchanged']
source=read(d/'source-before.json');archive=subprocess.check_output(['git','archive',head,'--',*source],cwd=root)
with tarfile.open(fileobj=io.BytesIO(archive)) as src:assert all(hashlib.sha256(src.extractfile(n).read()).hexdigest()==h for n,h in source.items())
assert s['oracle_source_commit']=='636f166cfc86aa90d63f592fd99f3fdd9ef95ebd'
for f in s['retained_files']:assert sha(d/f['artifact'])==f['sha256'] and (d/f['artifact']).stat().st_size==f['bytes']
assert sha(d/'gnu-inputs/emacs')=='5e1721732427d69d8af63211f1e3833ec21e40f97f4b7f6cd4cb224b72cebfcf'
assert sha(d/'gnu-inputs/emacs.pdmp')=='bf4974228f3b3ea4374cec75a38eeb2bd0e7dd944da5bec4e6ad0387092502ae'
for remote,h in s['inputs'].items():
 marker='/emaxx/tests/' if '/emaxx/tests/' in remote else '/emaxx/tools/' if '/emaxx/tools/' in remote else None
 if marker:
  n=('tests/' if 'tests' in marker else 'tools/')+remote.split(marker,1)[1]
  assert sha(root/n)==h
 else:assert sha(d/'gnu-inputs'/Path(remote).name)==h
fixture=(root/'tests/fixtures/vector-closure-rounded-census.el').read_text();expected=(root/'tests/fixtures/vector-closure-rounded-census.expected').read_bytes().strip();seen=set()
for r in s['gnu_runs']:
 key=(r['stage'],r['repetition'],r['variant']);assert key not in seen;seen.add(key)
 assert r['exit_code']==0 and not r['timed_out'] and r['passed'] and r['expected_output']
 assert r['command'][1:4]==['--batch','-Q','--eval'] and r['command'][-1]=='(prin1 '+fixture+')'
 assert (d/r['stdout_file']).read_bytes()==expected and not (d/r['stderr_file']).read_bytes()
 assert sha(d/r['stdout_file'])==r['stdout_sha256'] and sha(d/r['stderr_file'])==r['stderr_sha256']
assert seen=={(stage,repetition,variant) for stage in ['before','after'] for repetition in [1,2,3] for variant in ['full','single','group']}
inv=s['inventory'];all_names=gate.parse_inventory((d/'full-inventory.log').read_text());assert all_names==inv['all'] and len(all_names)==3066
control='lisp::primitives::tests::native_vector_and_closure_census_matches_gnu_word_layout';assert inv['single']==[control] and inv['single_ignored']==inv['group_ignored']==[]
assert set(inv['group'])=={n for n in all_names if n.startswith('lisp::primitives::tests::')} and len(inv['group'])==691
assert 'lisp::primitives::tests::native_pseudovector_census_matches_gnu_word_layout' in inv['group']
assert [r['label'] for r in s['rust_runs']]==['single-before','group','single-after'];passes=0
for r in s['rust_runs']:
 assert r['exit_code']==0 and not r['timed_out'] and r['passed'];raw=(d/r['log_file']).read_text();assert sha(d/r['log_file'])==r['log_sha256'];names=inv['group'] if r['label']=='group' else inv['single'];starts=list(re.finditer(r'^test (\S+) \.\.\. ',raw,re.M));assert sorted(m[1] for m in starts)==names and r['executed_tests']==names
 for i,m in enumerate(starts):
  end=starts[i+1].start() if i+1<len(starts) else raw.rindex('test result:');assert re.search(r'(?:^|\s)ok$',raw[m.end():end].strip()),m[1]
 actual=gate.parse_test_result(raw);assert actual==r['result'] and actual['passed']==len(names) and actual['failed']==actual['ignored']==0;passes+=len(names)
assert passes==693 and sha(d/'libtest')==s['test_binary']['sha256']
result=dict(status='passed',source_commit=head,run_id=37606558967,gnu_processes=18,rust_processes=3,rust_passes=693,primitive_group=691,complete_library_inventory=3066,retained_inputs=len(s['retained_files']),published_compiled_inputs=len(source),raw_files={str(f.relative_to(d)):sha(f) for f in d.rglob('*') if f.is_file()},goal_complete=False,qualification='All eighteen GNU actual outputs and every raw Rust name/verdict verified across single/group/single. Both census controls pass in the full primitives group. The fixture adds two unconditional collections before measurement; no constructor, size, expected byte, timeout or selector is removed. Retained executables/images and source hashes verified. This bounded diagnostic is not the full Linux gate and does not erase312 failures.')
(p/'source313-linux-census-audit.json').open('x').write(json.dumps(result,indent=2));print({k:result[k] for k in ['status','gnu_processes','rust_processes','rust_passes']})
