from pathlib import Path
import hashlib,io,json,os,subprocess,tarfile,tempfile
p=Path(__file__).parent.resolve();root=p.parents[2];sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();read=lambda n:json.loads((p/n).read_text())
head='6ab3346049f08a08c5fbb842fc3f737c22c40c75';base='7e894a667b0bc0076dcf0555fb1d1f6fcbfb648c';manifest=read('source313-manifest.json');modes=read('source313-modes.json');prior=read('source312-final-manifest.json')
assert len(manifest)==len(modes)==len(prior)==552;changed=[n for n in manifest if manifest[n]!=prior[n]];assert sorted(changed)==['tests/fixtures/vector-closure-rounded-census.el','tests/fixtures/vector-pseudovector-word-census.el']
patch=p/'source313-census-setup.patch';assert subprocess.check_output(['git','diff','--binary',base,head],cwd=root)==patch.read_bytes()
destination=Path(tempfile.mkdtemp(prefix='source313-portable-',dir='/private/tmp'));archive=subprocess.check_output(['git','archive',base,'--',*manifest],cwd=root)
with tarfile.open(fileobj=io.BytesIO(archive)) as source:
 for member in source.getmembers():
  path=Path(member.name);assert not path.is_absolute() and '..' not in path.parts and (member.isfile() or member.isdir())
 source.extractall(destination)
assert all(sha(destination/n)==h for n,h in prior.items())
prior_modes=read('source312-final-modes.json');assert prior_modes==modes
for n,mode in prior_modes.items():
 assert (destination/n).stat().st_mode&0o111==mode&0o111
 os.chmod(destination/n,mode)
r=subprocess.run(['git','apply','--check',str(patch)],cwd=destination,capture_output=True);assert r.returncode==0,r.stderr
r=subprocess.run(['git','apply',str(patch)],cwd=destination,capture_output=True);assert r.returncode==0,r.stderr
assert all(sha(destination/n)==h and (destination/n).stat().st_mode&0o777==modes[n] for n,h in manifest.items())
result=dict(status='passed',base_commit=base,source_commit=head,verified_inputs=552,all_modes_verified=True,changed_inputs=changed,incremental_patch_sha256=sha(patch),preceding_complete_patch_sha256=sha(p/'source312-final-portable-complete.patch'),replay_directory=str(destination),goal_complete=False,qualification='The only313 source changes replay onto the exact312 Git archive and reproduce all552 runtime/test/build bytes and modes. All production sources and original expected outputs remain unchanged.The isolated replay uses the recorded312 file permissions before patch application; Git tracks only executable bits. An earlier in-repository replay incorrectly let parent Git skip the fixture paths and is preserved as a setup failure.312 complete portable replay is separately preserved; no unexecuted runtime change is included.')
(p/'source313-portable-audit.json').open('x').write(json.dumps(result,indent=2));print(result['status'],result['verified_inputs'])
