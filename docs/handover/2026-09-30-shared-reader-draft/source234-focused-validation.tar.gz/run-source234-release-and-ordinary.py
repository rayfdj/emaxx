from pathlib import Path
import json
import subprocess
import sys
import time

p = Path(__file__).parent.resolve()
control = json.loads((p / 'source234-release-controls-result.json').read_text())
assert control['exit_code'] == 0 and control['source_unchanged']
stages = [
    ('release-broad', 'test-source234-broad.py', ['234', 'release']),
    ('ordinary-build-and-image', 'build-source234.py', ['234']),
    ('ordinary-comparisons', 'run-source234-ordinary.py', []),
]
results = []
for label, helper, arguments in stages:
    command = [sys.executable, str(p / helper), *arguments]
    print('START', label, flush=True)
    start = time.monotonic()
    result = subprocess.run(command, stdin=subprocess.DEVNULL)
    record = dict(stage=label, command=command, exit_code=result.returncode,
                  elapsed_seconds=time.monotonic() - start)
    results.append(record)
    print('END', label, json.dumps(record), flush=True)
    if result.returncode:
        break
with (p / 'source234-release-and-ordinary-result.json').open('x') as stream:
    json.dump(results, stream, indent=2)
raise SystemExit(results[-1]['exit_code'])
