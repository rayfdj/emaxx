from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import time

root = Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/display-tables/emaxx')
out = Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28')
manifest = json.loads((out / 'source234-manifest.json').read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def unchanged():
    return all(sha(root / name) == digest for name, digest in manifest.items())


def save(name, data):
    with (out / name).open('x') as stream:
        json.dump(data, stream, indent=2)
        stream.write('\n')


assert unchanged()
for profile in ['gate']:
    focused = json.loads((out / ('source234-' + profile + '-controls-result.json')).read_text())
    assert focused['exit_code'] == 0 and focused['source_unchanged']
assert (out / 'source234-complete.patch').is_file()
env = os.environ.copy()
overrides = {
    'CARGO_TARGET_DIR': str((root / 'target/frame-validation').resolve()),
    'CARGO_BUILD_JOBS': '1', 'EMAXX_GC_VERIFY': '1', 'LANG': 'C', 'LC_ALL': 'C',
    'EMAXX_GNU_SOURCE_DIRECTORY': '/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/emacs',
    'EMAXX_DUMP_SOURCE_DIRECTORY': '/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/emacs',
    'EMACS_TEST_DIRECTORY': '/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/emacs/test',
}
env.update(overrides)
artifact = out / 'full-gate-source234'
command = ['python3', 'tools/serial_grouped_gate.py', '--scope', 'full',
           '--artifact-root', str(artifact)]
save('source234-full-gate-command.json', {
    'command': command, 'working_directory': str(root),
    'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'source_manifest': 'source234-manifest.json',
    'environment_override': overrides,
    'qualification': 'Complete original inventoried macOS gate for source234, with 442 exact input hashes. All 37 focused gate controls pass before launch. The interactive metadata repair follows GNU callint.c and existing Feval; the original four Edebug controls and captured-closure control remain unchanged. Source232 library-control repairs are included. The failed source231 Linux runs, source232 first image-relocation failure and all prior failures remain preserved. This run uses the original build executable and its own standard fixture cache, separate from relocated selected-test artifacts. Release and ordinary validation are separate. No pinned compatibility or performance certification.'
})
start = time.monotonic()
with (out / 'source234-full-gate.log').open('x') as log:
    completed = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
result = {'exit_code': completed.returncode, 'elapsed_seconds': time.monotonic() - start,
          'source_unchanged': unchanged()}
summary_path = artifact / 'summary.json'
if summary_path.exists():
    summary = json.loads(summary_path.read_text())
    result['summary'] = summary
    binary = summary.get('test_binary')
    if binary:
        if isinstance(binary, dict):
            binary = binary.get('path')
        if binary and Path(binary).is_file():
            saved = out / 'source234-full-gate-libtest'
            assert not saved.exists()
            shutil.copy2(binary, saved)
            result['immutable_binary'] = {'path': str(saved), 'sha256': sha(saved)}
save('source234-full-gate-result.json', result)
print(json.dumps({k: v for k, v in result.items() if k != 'summary'}), flush=True)
raise SystemExit(0 if completed.returncode == 0 and result['source_unchanged'] else 1)
