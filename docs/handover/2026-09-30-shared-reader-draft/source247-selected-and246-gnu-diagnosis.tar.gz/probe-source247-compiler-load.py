from pathlib import Path
import hashlib, json, os, shutil, subprocess, time

p = Path(__file__).parent.resolve()
root = p.parents[2]
recovered = p.parent / 'recovered-2026-09-30'
checkout = recovered / 'coding-properties/emaxx'
gnu = recovered / 'emacs'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
manifest = json.loads((p / 'source247-manifest.json').read_text())
unchanged = lambda: all(sha(checkout / name) == digest for name, digest in manifest.items())
assert len(manifest) == 470 and unchanged()
work = p / 'source247-compiler-load'
work.mkdir()
records = []
for editor, binary in [('gnu', gnu / 'src/emacs'), ('emaxx', checkout / 'target/frame-validation/release/emaxx')]:
    directory = work / editor
    directory.mkdir()
    source = directory / 'comp-tests.el'
    shutil.copy2(gnu / 'test/src/comp-tests.el', source)
    shutil.copytree(gnu / 'test/src/comp-resources', directory / 'comp-resources')
    original_inputs = [source, *(directory / 'comp-resources').rglob('*.el')]
    inputs = {str(f): sha(f) for f in [binary, binary.with_suffix('.pdmp'), Path(__file__), *original_inputs]}
    command = [str(binary), '-Q', '--batch', '--eval',
               f'(startup-redirect-eln-cache {json.dumps(str(directory / "eln-cache"))})',
               '-L', str(gnu / 'test'), '-l', str(source), '--eval', "(prin1 'loaded)"]
    overrides = {'LANG': 'C', 'LC_ALL': 'C'}
    stem = p / ('source247-compiler-load-' + editor)
    with Path(str(stem) + '-command.json').open('x') as f:
        json.dump(dict(command=command, working_directory=str(root), environment_overrides=overrides,
                       inputs=inputs, timeout_seconds=3600,
                       qualification='Original upstream compiler-test load, with byte-identical resources in separate per-editor directories and independent native caches. Ordinary executables/images and C locale; no advice, assertion or native-source change. Load success alone is not a test-suite verdict.'), f, indent=2)
    start = time.monotonic()
    try:
        result = subprocess.run(command, cwd=root, env={**os.environ, **overrides},
                                stdin=subprocess.DEVNULL, capture_output=True, timeout=3600)
        code, stdout, stderr, timed_out = result.returncode, result.stdout, result.stderr, False
    except subprocess.TimeoutExpired as error:
        code, stdout, stderr, timed_out = None, error.stdout or b'', error.stderr or b'', True
    for suffix, data in [('stdout', stdout), ('stderr', stderr)]:
        with Path(str(stem) + '.' + suffix).open('xb') as f:f.write(data)
    record = dict(editor=editor, exit_code=code, timed_out=timed_out,
                  elapsed_seconds=time.monotonic() - start,
                  stdout_sha256=hashlib.sha256(stdout).hexdigest(),
                  stderr_sha256=hashlib.sha256(stderr).hexdigest(),
                  source_unchanged=unchanged(),
                  inputs_unchanged=all(sha(Path(name)) == digest for name, digest in inputs.items()))
    with Path(str(stem) + '-result.json').open('x') as f:json.dump(record, f, indent=2)
    records.append(record)
    print(json.dumps(record), flush=True)
    print(stdout.decode(errors='replace')[-8000:], flush=True)
    print(stderr.decode(errors='replace')[-8000:], flush=True)
with (p / 'source247-compiler-load-result.json').open('x') as f:json.dump(records, f, indent=2)

assert all(record['exit_code'] == 0 and not record['timed_out'] and record['source_unchanged'] and record['inputs_unchanged'] for record in records)
assert all((p / ('source247-compiler-load-' + record['editor'] + '.stdout')).read_bytes() == b'loaded' for record in records)
