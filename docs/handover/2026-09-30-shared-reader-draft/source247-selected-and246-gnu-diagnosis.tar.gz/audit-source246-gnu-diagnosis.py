from pathlib import Path
import hashlib, io, json, re, subprocess, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
artifact = p / 'source246-linux-gnu-census-artifacts'
d = artifact / 'gnu-census'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_text())
download = read(p / 'source246-linux-gnu-census-download.json')
assert download['run_id'] == 36842893035
assert sha((p / 'source246-linux-gnu-census-artifact.zip').read_bytes()) == download['archive_sha256']
assert all(sha((artifact / name).read_bytes()) == digest
           for name, digest in download['files'].items())
s = read(d / 'summary.json')
head = 'de944b6a19257a50f9d873fa9b43b43fd28b0d7b'
assert s['status'] == 'diagnostic completed' and s['failed_processes'] == 0
assert s['inputs_unchanged'] and s['compiled_inputs_unchanged']
assert s['source_after'] == s['git'] == dict(head=head, dirty=False)
manifest = read(p / 'source246-manifest.json')
compiled = read(d / 'source-before.json')
assert len(manifest) == 468 and len(compiled) == 461
assert all(manifest[name] == digest for name, digest in compiled.items())
for commit in [head, 'aaf31ce70abc920f9fc3395c01db7ffc57328f81']:
    blob = subprocess.check_output(['git', 'archive', commit, '--', *sorted(manifest)], cwd=root)
    with tarfile.open(fileobj=io.BytesIO(blob)) as archive:
        assert all(sha(archive.extractfile(name).read()) == digest for name, digest in manifest.items())
fixture = root / 'tests/fixtures/vector-closure-rounded-census.el'
expected = (root / 'tests/fixtures/vector-closure-rounded-census.expected').read_bytes().rstrip(b'\n')
assert len(s['gnu_runs']) == 18
matrix = set()
for run in s['gnu_runs']:
    matrix.add((run['stage'], run['repetition'], run['variant']))
    assert run['exit_code'] == 0 and not run['timed_out'] and run['passed'] and run['expected_output']
    assert run['command'][-1] == '(prin1 ' + fixture.read_text() + ')'
    for output in ['stdout', 'stderr']:
        data = (d / run[output + '_file']).read_bytes()
        assert sha(data) == run[output + '_sha256']
        assert data == (expected if output == 'stdout' else b'')
assert matrix == {(stage, repetition, variant) for stage in ['before', 'after']
                  for repetition in [1, 2, 3] for variant in ['full', 'single', 'group']}

def listed(name):
    return [line[:-6] for line in (d / name).read_text().splitlines() if line.endswith(': test')]

all_names, single, group = (listed(name + '-inventory.log') for name in ['full', 'single', 'group'])
assert len(all_names) == len(set(all_names)) == 3007
assert len(single) == 1 and len(group) == 654
assert group == [name for name in all_names if name.startswith('lisp::primitives::tests::')]
assert single == [name for name in group if name.endswith('::native_vector_and_closure_census_matches_gnu_word_layout')]
assert not listed('single-ignored.log') and not listed('group-ignored.log')
assert len(s['rust_runs']) == 3
for run, names in zip(s['rust_runs'], [single, group, single]):
    raw = (d / run['log_file']).read_bytes()
    assert sha(raw) == run['log_sha256']
    verdicts = re.findall(r'^test (\S+) \.\.\. (ok|FAILED|ignored)\s*$', raw.decode(), re.M)
    assert verdicts == [(name, 'ok') for name in names]
    assert run['executed_tests'] == names
    result = run['result']
    assert result['status'] == 'ok' and result['passed'] == len(names)
    assert result['failed'] == result['ignored'] == result['measured'] == 0
    assert result['filtered_out'] == 3007 - len(names)
    assert run['passed'] and run['exit_code'] == 0 and not run['timed_out']
assert len(s['retained_files']) == 8
for item in s['retained_files']:
    data = (d / item['artifact']).read_bytes()
    assert len(data) == item['bytes'] and sha(data) == item['sha256']
failed = read(p / 'source246-linux-rust-failure-audit.json')
assert failed['status'] == 'failed' and failed['library_failed'] == 2
assert sha((d / 'libtest').read_bytes()) == s['test_binary']['sha256'] == failed['binary_sha256']
assert s['oracle_source_commit'] == failed['oracle_capture']['source_commit']
assert s['oracle_source_commit'] == '636f166cfc86aa90d63f592fd99f3fdd9ef95ebd'
gnu_inputs = {}
for item in failed['oracle_capture']['files']:
    data = (d / 'gnu-inputs' / item['artifact']).read_bytes()
    assert len(data) == item['bytes'] and sha(data) == item['sha256']
    gnu_inputs[item['artifact']] = item['sha256']
diagnostic_image = next(item['sha256'] for item in s['retained_files']
                        if item['artifact'].startswith('fixture-images/'))
failed_image = next(item['sha256'] for item in failed['retained_files']
                   if item['artifact'].startswith('fixture-images/'))
record = dict(status='passed bounded diagnosis; full failure remains unresolved', run_id=36842893035,
              source_commit=head, gnu_probes=18, rust_passes=[1, 654, 1], full_inventory=3007,
              retained_files_verified=8, compiled_inputs_verified=461, source_inputs_verified=468,
              rust_binary_matches_failed_full=True, gnu_inputs_match_failed_full=gnu_inputs,
              diagnostic_emaxx_image_sha256=diagnostic_image, failed_full_emaxx_image_sha256=failed_image,
              goal_complete=False,
              qualification='All raw processes, names, verdicts and hashes pass. The GNU executable, dump, configuration and Makefile, and the Rust test executable match the failed full run byte for byte. Emaxx images differ, but both full-run failures occur before either Emaxx comparison. The original fixtures, assertions, timeouts and group inventory are unchanged. This narrows diagnosis to execution context or nondeterministic behavior; no retaining root or environment cause is established. The failed full run remains failed; this is not full validation or performance evidence.')
with (p / 'source246-linux-gnu-census-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps(record, indent=2))
