from pathlib import Path
import ast, hashlib, json, re, shutil, sys

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/coding-properties/emaxx'
profile = sys.argv[1] if len(sys.argv) > 1 else 'gate'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'audit-source238-release.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'audit_log')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<raw-verdict-auditor>', 'exec'))
manifest = read('source247-manifest.json')
assert len(manifest) == 470 and all(sha(root / name) == digest for name, digest in manifest.items())
command = read('source247-' + profile + '-controls-command.json')
result = read('source247-' + profile + '-controls-result.json')
assert result['exit_code'] == 0 and result['source_unchanged']
names = command['selected_inventory']
previous = read('source246-' + profile + '-controls-command.json')['selected_inventory']
assert len(names) == len(set(names)) == 171
assert set(previous) <= set(names)
assert set(names) - set(previous) == {'lisp::primitives::tests::coding_candidates_resolve_translation_symbols_through_live_properties'}
ignored = ['tty::tty_differential_end_to_end', 'tty::tty_smoke_end_to_end']
audit_log(names, (p / ('source247-' + profile + '-controls.log')).read_text(), ignored)
for stage in ['check', 'fmt', 'clippy', 'diff', profile + '-build']:
    stage_result = read('source247-' + stage + '-result.json')
    assert stage_result['exit_code'] == 0 and stage_result['source_unchanged']
    raw = (p / ('source247-' + stage + '.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
    for line in raw.splitlines():
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        assert row.get('message', {}).get('level') not in ['warning', 'error']
binary = p / ('source247-' + profile + '-libtest')
assert sha(binary) == command['binary_sha256']
images = sorted((p / 'fixture-images-source247').glob('loadup-' + sha(binary)[:8] + '-*.pdmp'))
assert len(images) == 1
retained = p / ('source247-' + profile + '-focused-retained-inputs')
retained.mkdir()
files = []
for source in [binary, *images]:
    destination = retained / source.name
    digest = sha(source)
    shutil.copy2(source, destination)
    assert sha(source) == sha(destination) == digest
    files.append(dict(original=str(source), retained=str(destination), sha256=digest, bytes=destination.stat().st_size))
record = dict(status='passed', profile=profile, passed=169, failed=0, ignored=ignored,
              names=names, inputs_verified=470, retained_files=files, strict_checks='zero-warning pass',
              qualification='Every preceding selected control remains present and passes; the additional unchanged GNU-backed fixture passes. It covers nil/t translation symbols and dynamic non-nil/nil overriding properties. The separately observed first-nil duplicate property bug remains outside this repair. Complete upstream/compiler, frozen, terminal, Linux and performance evidence remains separate.')
with (p / ('source247-' + profile + '-focused-audit.json')).open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps({key: record[key] for key in ['status', 'profile', 'passed', 'ignored', 'strict_checks']}, indent=2))
