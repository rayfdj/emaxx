from pathlib import Path
import json, subprocess, sys, time
p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/coding-properties/emaxx'
stages = [
    ['check-source247.py', '247'], ['static-source247.py', '247'],
    ['test-source247-controls.py', '247', 'gate'], ['build-source247.py', '247'],
    ['compare-source230-fixtures.py', 'source247', str(root),
     'coding-candidate-symbol-properties', 'coding-candidate-translation', 'coding-candidate-character-identities', 'coding-candidate-inventory', 'file-write-coding-selection', 'new-file-coding-lifecycle', 'file-write-order',
     'canonical-coding-character-storage', 'canonical-coding-identity-storage',
     'canonical-coding-conversion-storage', 'copied-canonical-string-storage', 'coding-error-object-storage'],
    ['probe-source247-compiler-load.py'],
    ['test-source247-broad.py', '247', 'gate'],
]
results = []
for name, *args in stages:
    command = [sys.executable, str(p / name), *args]
    start = time.monotonic()
    result = subprocess.run(command, stdin=subprocess.DEVNULL)
    results.append(dict(command=command, exit_code=result.returncode, elapsed_seconds=time.monotonic()-start))
    if result.returncode:
        break
with (p / 'source247-validation-result.json').open('x') as f:
    json.dump(results, f, indent=2)
raise SystemExit(results[-1]['exit_code'])
