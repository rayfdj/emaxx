from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
selected = read('source247-selected-audit.json')
focused = read('source247-gate-focused-audit.json')
diagnosis = read('source246-linux-gnu-census-audit.json')
assert len(read('source247-validation-result.json')) == 7
assert all(row['exit_code'] == 0 for row in read('source247-validation-result.json'))
assert selected['affected_passes'] == 952 and selected['ordinary_comparisons'] == 12
assert focused['passed'] == 169 and diagnosis['rust_passes'] == [1, 654, 1]
assert diagnosis['gnu_probes'] == 18 and diagnosis['rust_binary_matches_failed_full']
correction = dict(status='narrative correction only', record='source247-selected-audit.json',
    sha256=sha((p / 'source247-selected-audit.json').read_bytes()),
    correction='The historical original compiler-file load failure was on source243, not source244. Source244 repaired that failure. Source247 also passes the unchanged load. No machine field or raw result changes.')
with (p / 'source247-selected-qualification-correction.json').open('x') as stream:
    json.dump(correction, stream, indent=2)
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected', '.h'}
patterns = ['source247-*', '*source247*.py', 'source246-linux-gnu-census-*',
            'download-source246-linux-gnu-census.py', 'audit-source246-gnu-diagnosis*.py',
            'compare-source230-fixtures.py', 'audit-source238-release.py',
            'package-source196-failure-and197-results.py']
files = {str(f.relative_to(p)): f for pattern in patterns for f in p.glob(pattern)
         if f.is_file() and f.suffix in allowed}
for directory in ['source246-linux-gnu-census-artifacts', 'source247-gate-focused-retained-inputs',
                  'source247-selected-retained-inputs']:
    files.update({str(f.relative_to(p)): f for f in (p / directory).rglob('*')
                  if f.is_file() and (f.suffix in allowed or f.name == 'Makefile')})
files[Path(__file__).name] = Path(__file__)
package('source247-selected-and246-gnu-diagnosis', files, dict(
    source247_focused_passes=169, source247_existing_ignores=2,
    source247_affected_passes=952, source247_ordinary_matches=12,
    source247_original_compiler_load='both editors succeed',
    source247_inputs=470, gnu_diagnosis=diagnosis,
    qualification='Closed source247 selected pipeline and source246 bounded Linux GNU diagnosis. Source248 remains a separate executing draft and no result for it is packaged. Root runtime is source246. The failed full Linux Rust result is preserved; neither the passing diagnosis nor matching executable inputs identifies its cause or supplies full certification. The compiler-load narrative correction and initial raw-auditor failure are retained. No complete platform, general coding, pinned Darwin or performance claim.'))
