from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

p = Path(__file__).parent.resolve()
root = p.parent / "recovered-2026-09-30/macro-reader/emaxx"
manifest = json.loads((p / "source193-manifest.json").read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
unchanged = lambda: all(sha(root / name) == digest for name, digest in manifest.items())
steps = [["check-reader193.py", "193"], ["static-reader193.py", "193"],
         ["test-reader193.py", "193", "gate"], ["test-reader193.py", "193", "release"],
         ["build-reader193.py", "193"],
         ["compare-recovered-continuation-fixtures.py", "source193", str(root),
          "input-decode-general", "input-decode-extra", "input-decode-pipeline",
          "input-decode-reader-contract", "input-decode-case-state", "input-decode-xt-setup", "input-decode-case-variants", "input-decode-command-reader", "input-decode-macro-shared", "input-decode-autoload-prefix", "input-decode-first-unbound", "input-decode-shift-tab-variants", "input-decode-remapped-undefined", "input-decode-map-authority", "input-decode-tab-map-installation", "input-decode-minibuffer-shared", "input-decode-minibuffer-queue", "input-decode-mouse-menu-cases", "input-decode-mouse-raw-mutation", "input-decode-menu-bar", "input-decode-position-lookup", "input-decode-macro-live-array", "input-decode-macro-raw-array", "input-decode-macro-nested-roots", "input-decode-macro-read-order"]]
results = []
for args in steps:
    assert unchanged()
    result = subprocess.run([sys.executable, str(p / args[0]), *args[1:]], check=False)
    results.append({"script": args, "exit_code": result.returncode, "source_unchanged": unchanged()})
    if result.returncode or not unchanged():
        break
with (p / "source193-selected-validation-result.json").open("x") as stream:
    json.dump({"steps": results, "all_completed": len(results) == len(steps),
               "source_unchanged": unchanged(), "completed_unix": time.time(),
               "qualification": "Selected common-reader integration only; full-source compatibility, broader reader contracts and complete goal requirements remain open."}, stream, indent=2)
raise SystemExit(0 if len(results) == len(steps) and all(item["exit_code"] == 0 and item["source_unchanged"] for item in results) else 1)
