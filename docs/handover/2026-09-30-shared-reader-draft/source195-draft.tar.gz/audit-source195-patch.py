from pathlib import Path
import hashlib, io, json, subprocess, tarfile, tempfile
p=Path(__file__).parent.resolve(); repository=p.parents[2]
base='21d20f0eec08f3c013d5d3eb3bd6e9cfc16b3199'
archive=subprocess.check_output(['git','archive',base,'--','src','tests','Cargo.toml','Cargo.lock','build.rs','.cargo','compat/emacs_compat_runner.el','tools/ttydiff.py','tools/fixtures/fieldnotes.org','tools/fixtures/fake_lsp_server.py'],cwd=repository)
sha=lambda data:hashlib.sha256(data).hexdigest()
results=[]
for tag in ['source195']:
    manifest=json.loads((p/(tag+'-manifest.json')).read_text());patch=p/(tag+'-complete.patch')
    with tempfile.TemporaryDirectory(prefix=tag+'-replay-',dir='/private/tmp') as directory:
        root=Path(directory)
        baseline_modes = {}
        with tarfile.open(fileobj=io.BytesIO(archive)) as source:
            for member in source:
                relative=Path(member.name)
                assert not relative.is_absolute() and '..' not in relative.parts
                if member.isdir():continue
                assert member.isfile(),member.name
                target=root/relative;target.parent.mkdir(parents=True,exist_ok=True)
                target.write_bytes(source.extractfile(member).read())
                target.chmod(member.mode & 0o777)
                baseline_modes[str(relative)] = member.mode & 0o777
        baseline={str(f.relative_to(root)):sha(f.read_bytes()) for f in root.rglob('*') if f.is_file()}
        subprocess.run(['git','apply','--check',str(patch)],cwd=root,check=True)
        subprocess.run(['git','apply',str(patch)],cwd=root,check=True)
        actual={str(f.relative_to(root)):sha(f.read_bytes()) for f in root.rglob('*') if f.is_file()}
        assert all(actual.get(name)==digest for name,digest in manifest.items())
        for name in manifest:
            expected_mode = baseline_modes.get(name, 0o644)
            assert bool((root / name).stat().st_mode & 0o111) == bool(expected_mode & 0o111), (tag, name)
        additions=set(actual)-set(baseline)
        assert additions<=set(manifest),additions-set(manifest)
        assert all(baseline.get(name)==digest for name,digest in actual.items() if name not in manifest)
    results.append({'source':tag,'base_commit':base,'patch_sha256':sha(patch.read_bytes()),'manifest_sha256':sha((p/(tag+'-manifest.json')).read_bytes()),'inputs_replayed_and_verified':len(manifest),'executable_modes_verified':True,'passed':True})
with (p/'source195-patch-replay-and-modes-audit.json').open('x') as f:
    json.dump({'results':results,'qualification':'Exact patch replay only. Compiler, runtime and terminal outcomes are separately recorded; this does not turn failed or unexecuted validation into passes.'},f,indent=2)
print(json.dumps(results,indent=2))
