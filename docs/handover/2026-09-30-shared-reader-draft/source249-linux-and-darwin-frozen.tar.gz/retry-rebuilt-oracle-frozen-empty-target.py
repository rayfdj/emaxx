from pathlib import Path
import hashlib, json, os, subprocess, sys, time

p=Path(__file__).parent.resolve()
root=p.parents[2]
subject=p.parent/'rebuilt-2026-10-01/emaxx'
gnu=subject.parent/'emacs'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
manifest=json.loads((p/'source249-manifest.json').read_text())
unchanged=lambda:all(sha(subject/n)==h for n,h in manifest.items())
previous=json.loads((p/'rebuilt-oracle-frozen-result.json').read_text())
command=json.loads((p/'rebuilt-oracle-frozen-comparison-command.json').read_text())
capture=p/'rebuilt-oracle-frozen-empty-target-gnu-inputs'
state=dict(status='preparing empty target replay',original_exit_code=previous['exit_code'],goal_complete=False)
def save(name,data):
    with (p/('rebuilt-oracle-frozen-empty-target-'+name+'.json')).open('x') as f:json.dump(data,f,indent=2)
assert previous['exit_code']==2 and previous['source_unchanged'] and previous['gnu_inputs_unchanged']
assert 'refusing unowned non-empty Cargo target' in (p/'rebuilt-oracle-frozen-comparison.log').read_text()
assert unchanged()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=subject,text=True).strip()==previous['candidate_commit']
assert subprocess.check_output(['git','status','--porcelain'],cwd=subject,text=True).strip()==''
target=subject/'target/compat-subject'
retained=subject/'target/compat-subject-unclaimed-copy'
assert target.is_dir() and not (target/'.emaxx-source-root').exists() and not retained.exists()
target.rename(retained)
save('setup',dict(original_target=str(target),preserved_unclaimed_copy=str(retained),empty_target_required=True,
                  source_unchanged=unchanged(),harness_sha256=sha(Path(command['command'][0])),
                  qualification='The first frozen launch stopped before any comparison because a manually copied nonempty target had no ownership marker. Preserve that directory and let the unchanged harness create its own fresh target. No marker is fabricated; no source, oracle, inventory, selector or timeout changes.'))
save('command',command)
subprocess.run([sys.executable,'-B',str(root/'tools/retain_oracle_artifacts.py'),'capture','--oracle-source',str(gnu),'--output',str(capture)],check=True)
started=time.monotonic()
try:
    with (p/'rebuilt-oracle-frozen-empty-target.log').open('x') as log:
        result=subprocess.run(command['command'],cwd=command['working_directory'],env={**os.environ,**command['environment_override']},
                              stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,timeout=command['timeout_seconds'])
    state.update(status='frozen process finished; raw evidence requires audit',exit_code=result.returncode)
except Exception as error:
    state.update(status='failed',error=repr(error))
finally:
    verification=subprocess.run([sys.executable,'-B',str(root/'tools/retain_oracle_artifacts.py'),'verify','--output',str(capture)])
    state.update(elapsed_seconds=time.monotonic()-started,source_unchanged=unchanged(),gnu_inputs_unchanged=verification.returncode==0,
                 candidate_commit=previous['candidate_commit'])
    save('result',state)
print(json.dumps(state),flush=True)
raise SystemExit(0 if state.get('exit_code')==0 and state['source_unchanged'] and state['gnu_inputs_unchanged'] else 1)
