from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

p = Path(__file__).parent.resolve()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()

def save(name, value):
    with (p / name).open('x') as stream:
        json.dump(value, stream, indent=2)

state_command = ['gh', 'run', 'view', '36879095484', '--repo', 'rayfdj/emaxx', '--json', 'status,conclusion,headSha,url']
state = json.loads(subprocess.check_output(state_command))
save('source249-linux-rust-final-state.json', state)
assert state['status'] == 'completed' and state['conclusion'] == 'success'
assert state['headSha'] == '99e61fca563a8c2f597b20fc56a539cdd1c2f575'
archive = p / 'source249-linux-rust-artifact.zip'
command = ['gh', 'api', 'repos/rayfdj/emaxx/actions/artifacts/11173305291/zip']
save('source249-linux-rust-download-command.json', {'state_command': state_command, 'archive_command': command, 'helper_sha256': sha(Path(__file__))})
with archive.open('xb') as output:
    subprocess.run(command, stdout=output, check=True)
root = p / 'source249-linux-rust-artifacts'
files = {}
with zipfile.ZipFile(archive) as source:
    for entry in source.infolist():
        if entry.is_dir():
            continue
        digest = hashlib.sha256(source.read(entry)).hexdigest()
        assert sha(root / entry.filename) == digest, entry.filename
        files[entry.filename] = digest
assert set(files) == {str(path.relative_to(root)) for path in root.rglob('*') if path.is_file()}
save('source249-linux-rust-download.json', {'archive_sha256': sha(archive), 'files': files, 'artifact_id': 11173305291, 'run_id': 36879095484})
oracle = root / 'oracle-inputs'
manifest = json.loads((oracle / 'manifest.json').read_text())
verification = json.loads((oracle / 'verification.json').read_text())
assert manifest['status'] == 'captured' and manifest['source_tracked_changes'] == []
assert manifest['source_commit'] == '636f166cfc86aa90d63f592fd99f3fdd9ef95ebd'
assert {row['artifact'] for row in manifest['files']} == {'emacs', 'emacs.pdmp', 'config.h', 'Makefile'}
for row in manifest['files']:
    path = oracle / row['artifact']
    assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256']
assert verification['status'] == 'unchanged' and verification['files_verified'] == 4
assert verification['capture_manifest_sha256'] == sha(oracle / 'manifest.json')
save('source249-linux-rust-oracle-audit.json', {'status': 'retained GNU inputs verified', 'run_id': 36879095484, 'files_verified': 4, 'files': manifest['files'], 'source_commit': manifest['source_commit'], 'verification': verification})
print('Downloaded archive and all extracted bytes agree; four actual GNU inputs verified')
