from pathlib import Path
import hashlib
import json
import re
import shutil

p = Path(__file__).parent.resolve()
subject = p.parent / 'rebuilt-2026-10-01/emaxx'
root = subject / 'target/compat/frozen-1790865620713923000-58667'
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
summary = read(root / 'summary.json')
manifest_path = subject / 'compat/oracle_tests_all.txt'
lock = read(subject / 'compat/oracle.lock.json')
inventory = {}
current = None
for line in manifest_path.read_text().splitlines():
    match = re.fullmatch(r'(\S+): discovered=(\d+) selected=(\d+)', line)
    if match:
        current = match[1]
        assert current not in inventory
        inventory[current] = dict(discovered=int(match[2]), selected=int(match[3]), names=[])
    elif line.strip():
        assert current and line.startswith('  ')
        inventory[current]['names'].append(line.strip())
assert len(inventory) == 519 and sum(row['selected'] for row in inventory.values()) == 7921
assert all(len(row['names']) == len(set(row['names'])) == row['selected'] for row in inventory.values())
assert summary['mode'] == 'frozen' and summary['scope'] == 'Frozen' and summary['name_filter'] is None
assert summary['selector'] == lock['selector_default']
assert set(summary['files']) == set(inventory) and len(summary['files']) == 519
assert summary['total_files'] == 519 and summary['matching_files'] == 518 and summary['mismatching_files'] == 1
assert (summary['matching_outcomes'], summary['mismatching_outcomes'], summary['total_outcomes']) == (7915, 6, 7921)
assert summary['mismatches'] == ['test/src/emacs-tests.el'] and summary['unsuccessful_files'] == []
frozen = summary['frozen_manifest']
assert frozen['sha256'] == sha(manifest_path) == 'a1f87443aad516a128001595d7c69fbbaace40b420d8cd1e9e5ec178aa2fd615'
assert frozen['recorded_files'] == frozen['executed_files'] == 519
assert frozen['required_outcomes'] == frozen['compared_outcomes'] == 7921 and frozen['historical_load_errors'] == 0
provenance = summary['provenance']
assert provenance['subject_git_head'] == '1c0898fc58f1f7e2fffc5a245a1f8ff7894832a0' and not provenance['subject_git_dirty']
assert provenance['oracle_sha256'] == lock['emacs_binary_sha256'] == '29cfb20de2474c040d439d4bdf69b4dfcfb7921464f1f686b6e1f6bcca7c74e5'
assert provenance['oracle_repo_commit'] == lock['emacs_repo_commit'] and provenance['oracle_native_compilation']
source = read(p / 'source249-manifest.json')
assert len(source) == 476 and all(sha(subject / name) == digest for name, digest in source.items())
counts = {runner: dict(total=0, passed=0, failed=0, skipped=0, unexpected=0) for runner in ['emaxx', 'oracle']}
mismatches = []
processes = 0
for file, expected in inventory.items():
    directory = (root / file).with_suffix('.compat')
    comparison = read(directory / 'comparison.json')
    assert comparison['file'] == file and comparison['execution_issues'] == []
    assert comparison['matching_outcomes'] + comparison['mismatching_outcomes'] == expected['selected']
    if file == 'test/src/emacs-tests.el':
        assert not comparison['matches'] and comparison['matching_outcomes'] == 1 and comparison['mismatching_outcomes'] == 6
        assert [issue['kind'] for issue in comparison['issues']] == ['failure_message'] * 6
    else:
        assert comparison['matches'] and comparison['issues'] == [] and comparison['mismatching_outcomes'] == 0
    execution = read(directory / 'execution.json')
    assert execution['contract_sha256'] == sha(root / 'contract.json')
    assert all(sha(directory / name) == digest for name, digest in execution['sha256'].items())
    pair = {}
    for runner in counts:
        report = read(directory / (runner + '.json'))
        assert report['file'] == file and report['file_error'] is None and report['file_status'] == 'loaded'
        assert report['selector'] == summary['selector'] and len(report['discovered_tests']) == expected['discovered']
        assert set(report['selected_tests']) == set(expected['names']) and len(report['selected_tests']) == expected['selected']
        results = report['results']
        assert len(results) == len({row['name'] for row in results}) == expected['selected']
        assert {row['name'] for row in results} == set(expected['names'])
        observed = {key: sum(row['status'] == key for row in results) for key in ['passed', 'failed', 'skipped']}
        observed.update(total=len(results), unexpected=sum(not row['expected'] for row in results))
        assert observed == report['summary'] and observed['unexpected'] == 0
        for key, count in observed.items():
            counts[runner][key] += count
        pair[runner] = {row['name']: row for row in results}
        process = read(directory / (runner + '.execution.json'))['process']
        assert process['exit_code'] == 0 and process['test_started'] and not process['timed_out'] and process['timeout_phase'] is None
        processes += 1
        if file == 'test/src/comp-tests.el':
            assert len(results) == 177 and all(row['status'] == 'passed' and row['expected'] for row in results)
    assert {name: (row['status'], row['expected']) for name, row in pair['oracle'].items()} == {
        name: (row['status'], row['expected']) for name, row in pair['emaxx'].items()}
    if file == 'test/src/emacs-tests.el':
        for name, oracle in pair['oracle'].items():
            emaxx = pair['emaxx'][name]
            if oracle['message'] != emaxx['message']:
                assert name.startswith('emacs-tests/seccomp/')
                assert oracle['status'] == emaxx['status'] == 'skipped'
                assert oracle['condition_type'] == emaxx['condition_type'] == 'ert-test-skipped'
                assert 'system-configuration-features' in oracle['message'] and 'system-configuration-features' in emaxx['message']
                assert 'ACL GLIB GNUTLS' in oracle['message'] and '\"\"' in emaxx['message']
                mismatches.append(dict(name=name, oracle=oracle['message'], emaxx=emaxx['message']))
assert len(mismatches) == 6 and processes == 1038 and counts == summary['runner_summaries']
capture_root = p / 'rebuilt-oracle-frozen-empty-target-gnu-inputs'
capture = read(capture_root / 'manifest.json')
verification = read(capture_root / 'verification.json')
assert verification['status'] == 'unchanged' and verification['files_verified'] == 4
assert verification['capture_manifest_sha256'] == sha(capture_root / 'manifest.json')
for entry in capture['files']:
    assert sha(capture_root / entry['artifact']) == entry['sha256']
    assert (capture_root / entry['artifact']).stat().st_size == entry['bytes']
retained = p / 'source249-rebuilt-frozen-subject-inputs'
retained.mkdir()
inputs = {}
for original, digest in {provenance['subject_binary']: provenance['subject_sha256'], **provenance['runtime_images_sha256']}.items():
    path = Path(original)
    assert sha(path) == digest
    if path.name == 'emacs.pdmp':
        continue
    destination = retained / path.name
    shutil.copy2(path, destination)
    assert sha(destination) == digest
    inputs[str(path)] = dict(sha256=digest, retained=str(destination))
result = dict(status='failed: six existing feature-reporting skip diagnostics differ', verified_files=519,
              matching_outcomes=7915, mismatching_outcomes=6, verified_outcomes=7921,
              successful_processes=processes, runner_summaries=counts, differences=mismatches,
              source_inputs_verified=476, candidate_commit=provenance['subject_git_head'],
              subject_inputs=inputs, gnu_inputs=capture, gnu_verification=verification,
              summary_sha256=sha(root / 'summary.json'), raw_root=str(root), goal_complete=False,
              qualification='Every inventory, raw execution hash, result count and process checked. All 177 original compiler outcomes pass in both editors. This is a failed strict comparison; skips and expected failures are not passes. Emaxx deliberately does not claim GNU autoconf features (existing finding 65); no capability string or comparison rule was changed. This audit does not adopt the proposed replacement oracle pin or establish performance parity.')
with (p / 'source249-rebuilt-frozen-audit.json').open('x') as stream:
    json.dump(result, stream, indent=2)
print(json.dumps({key: result[key] for key in ['status', 'verified_files', 'matching_outcomes', 'mismatching_outcomes', 'successful_processes']}))
