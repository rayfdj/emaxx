from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
rust = read('source249-linux-rust-audit.json')
names = read('source249-linux-rust-name-audit.json')
frozen = read('source249-linux-frozen-raw-integrity-audit.json')
mac = read('source249-rebuilt-frozen-audit.json')
assert rust['status'] == 'passed' and rust['total_passed'] == 3112
assert frozen['files'] == 519 and frozen['outcomes'] == 7928 and frozen['successful_processes'] == 1038
assert mac['matching_outcomes'] == 7915 and mac['mismatching_outcomes'] == 6 and mac['successful_processes'] == 1038
files = {}
for dirname in ['source249-linux-rust-artifacts', 'source249-linux-frozen-artifacts']:
    directory = p / dirname
    for file in directory.rglob('*'):
        if not file.is_file():
            continue
        name = str(file.relative_to(directory))
        if file.suffix == '.pdmp' or name in ['oracle-inputs/emacs', 'rust/retained-inputs/libtest']:
            continue
        assert not file.is_symlink()
        files[dirname + '/' + name] = file
macroot = Path(mac['raw_root'])
tool_links = []
for file in macroot.rglob('*'):
    if not file.is_file():
        continue
    name = str(file.relative_to(macroot))
    if file.is_symlink():
        tool_links.append(dict(path=name, target=str(file.readlink()), sha256=sha(file.read_bytes()), bytes=file.stat().st_size))
        continue
    files['source249-rebuilt-frozen-raw/' + name] = file
with (p / 'source249-rebuilt-frozen-tool-links.json').open('x') as stream:
    json.dump(dict(links=tool_links, qualification='Existing harness tool links are recorded by target and hash, not copied system executables. Every raw test and load marker is packaged.'), stream, indent=2)
allowed = {'.json', '.log', '.txt', '.py', '.stdout', '.stderr', '.el', '.expected'}
helpers = {
    'download-source249-linux-rust.py', 'download-source249-linux-frozen.py',
    'audit-source249-linux-rust-names.py', 'verify-source249-linux-rust.py',
    'audit-source249-frozen.py', 'verify-complete-frozen-receipts.py',
    'audit-source249-rebuilt-frozen.py', 'retry-rebuilt-oracle-frozen-empty-target.py',
    'package-source196-failure-and197-results.py', Path(__file__).name,
}
for file in p.iterdir():
    if file.is_file() and file.suffix in allowed and (
        file.name.startswith(('source249-linux-rust-', 'source249-linux-frozen-', 'source249-rebuilt-frozen-', 'rebuilt-oracle-frozen-empty-target-'))
        or file.name in helpers or file.name == 'source249-manifest.json'):
        files[file.name] = file
for file in (p / 'rebuilt-oracle-frozen-empty-target-gnu-inputs').iterdir():
    if file.name not in ['emacs', 'emacs.pdmp']:
        files['rebuilt-oracle-frozen-empty-target-gnu-inputs/' + file.name] = file
assert helpers <= files.keys()
assert sum(name.endswith('.loaded') and name.startswith('source249-linux-frozen-artifacts/') for name in files) == 1038
assert sum(name.endswith('.loaded') and name.startswith('source249-rebuilt-frozen-raw/') for name in files) == 1038
package('source249-linux-and-darwin-frozen', files, dict(
    linux_rust=rust, linux_raw_names=names, linux_frozen=frozen,
    darwin_frozen=mac,
    qualification='Source249 complete Linux Rust and pinned Linux frozen pass with all raw names/outcomes and actual GNU input bytes verified. The rebuilt Darwin full comparison remains failed: six existing build-feature skip diagnostics differ among 7921 outcomes. No feature string or comparison rule was changed. All raw reports, logs and load markers are portable; large executable/image bytes and original CI ZIPs remain locally retained by hash. Darwin replacement pin adoption, complete macOS Rust/terminal auditing, the isolated common-string draft and the full architecture/performance goal remain separate.'))
