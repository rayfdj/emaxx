from pathlib import Path
import hashlib,json,os,subprocess,sys,time
p=Path(__file__).parent.resolve();root=p.parents[2];gnu=p.parent/'rebuilt-2026-10-01/emacs'
candidate=p.parent/'recovered-2026-10-03/vm-dispatch-full/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
read=lambda n:json.loads((p/n).read_text())
commit=read('source286-applied-commit.json')['commit']
manifest=read('source286-manifest.json')
assert len(manifest)==522 and all(sha(root/n)==h for n,h in manifest.items())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==commit
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
assert read('source286-selected-audit.json')['status']=='passed'
assert read('vm-dispatch-performance-audit.json')['status']=='all 288 processes and actual results/modes verified'
assert all(r['validation']=='completed' for r in read('source286-call-profile-result.json')['results'])
assert not candidate.exists() and not (p/'source286-full-checkout.json').exists()
candidate.parent.mkdir(parents=True,exist_ok=True)
assert not (candidate.parent/'emacs').exists()
result=subprocess.run(['git','worktree','add','--detach',str(candidate),commit],cwd=root,capture_output=True,text=True)
with (p/'source286-full-checkout-command.json').open('x') as f:json.dump(dict(commit=commit,exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr),f,indent=2)
result.check_returncode()
(candidate.parent/'emacs').symlink_to(gnu,target_is_directory=True)
assert all(sha(candidate/n)==h for n,h in manifest.items())
assert not subprocess.check_output(['git','status','--porcelain'],cwd=candidate,text=True).strip()
record=dict(candidate=str(candidate),validation_commit=commit,source_inputs_verified=522,source_manifest='source286-manifest.json',gnu_source=str(gnu),goal_complete=False,qualification='Fresh clean exact-runtime-commit checkout for full macOS Rust,frozen and terminal validation. Selected source286 remains frozen. Target cache is cloned only by the supervisor after its selected predecessor exits.')
with (p/'source286-full-checkout.json').open('x') as f:json.dump(record,f,indent=2)
helper=p/'queue-source286-full-macos.py';command=[sys.executable,'-B',str(helper)]
with (p/'source286-full-driver.log').open('xb') as log:
    proc=subprocess.Popen(command,cwd=root,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env=dict(os.environ,PYTHONUNBUFFERED='1',PYTHONDONTWRITEBYTECODE='1'))
launch=dict(pid=proc.pid,command=command,helper_sha256=sha(helper),validation_commit=commit,launched_at_unix=time.time(),stdin='DEVNULL',start_new_session=True,goal_complete=False,qualification='Full macOS validation launched on a clean exact-source286 commit; no outcome inferred.')
with (p/'source286-full-launch.json').open('x') as f:json.dump(launch,f,indent=2)
print(json.dumps(launch,indent=2))
