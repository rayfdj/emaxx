from pathlib import Path
import hashlib, io, json, os, re, subprocess, sys, tarfile, tempfile

p = Path(__file__).parent.resolve(); root = p.parents[2]
tag = sys.argv[1]
assert tag in ('source286', 'source287')
c = p.parent / 'recovered-2026-10-03' / ('vm-opcode-dispatch' if tag == 'source286' else 'remainder-corrected-baseline') / 'emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p / n).read_text())
m = read(tag + '-manifest.json'); base = read('source284-manifest.json')
assert len(m) == 522 and all(sha(c / n) == h for n,h in m.items())
assert all(m[n] == h for n,h in base.items() if n.startswith('tests/'))
original_tests = subprocess.check_output(['git','show','9c5b5356:src/lisp/primitives/tests.rs'], cwd=root, text=True)
test_source, count = re.subn(r'\n#\[test\]\nfn bytecode_direct_dispatch_preserves_gnu_stack_arithmetic_and_branches\(\) \{\n.*?\n\}\n\Z', '', (c/'src/lisp/primitives/tests.rs').read_text(), flags=re.S)
assert count == 1 and test_source == original_tests
state = read(tag + ('-validation-result.json' if tag == 'source286' else '-build-result.json'))
if tag == 'source287':
    assert state['results'][-1]['stage'] == 'ordinary-image' and state['results'][-1]['exit_code'] == 1
    state['results'] = state['results'][:-1] + read('source287-image-retry-result.json')['results']
assert all(r['exit_code'] == 0 and not r['timed_out'] and r['source_unchanged'] for r in state['results'])
profiles = {}
if tag == 'source286':
    for profile in ('gate','release'):
        r = state['profiles'][profile]
        assert r['passed'] == 118 and r['failed'] == r['ignored'] == 0
        inventory = [line[:-6] for line in (p/(tag+'-'+profile+'-inventory.log')).read_text().splitlines() if line.endswith(': test')]
        prior = [line[:-6] for line in (p/('source284-'+profile+'-inventory.log')).read_text().splitlines() if line.endswith(': test')]
        assert set(inventory) == set(prior) | {'lisp::primitives::tests::bytecode_direct_dispatch_preserves_gnu_stack_arithmetic_and_branches'}
        names = [n for n in inventory if re.search(r'byte_?code|threads_retain_lexical_caller_roots|native.*(?:arity|calling|unwind|handler)|numeric|arithmetic|remainder|modulo|bignum|float', n)]
        assert names == r['selectors']
        raw = (p/(tag+'-'+profile+'-selected.log')).read_text()
        assert re.findall(r'^test (\S+) \.\.\. ok$', raw, re.M) == names
        assert 'test result: ok. 118 passed; 0 failed; 0 ignored;' in raw
        assert sha(Path(r['binary'])) == sha(Path(r['retained_binary'])) == r['binary_sha256']
        for item in r['retained_inputs']:
            assert sha(Path(item['original'])) == sha(Path(item['retained'])) == item['sha256']
        profiles[profile] = r
else:
    assert all(m[n] == base[n] for n in ('src/lisp/bytecode.rs','src/lisp/bytecode/vm.rs'))
ordinary = {}
names = list(read('source284-selected-audit.json')['ordinary_results']) + ['bytecode-direct-dispatch']
assert len(names) == 42
for name in names:
    comparison = read(tag+'-ordinary-'+name+'-comparison.json')
    assert comparison['passed'] and comparison['exact_match']
    outputs, programs = [], []
    for editor in ('gnu','emaxx'):
        stem = tag+'-ordinary-'+name+'-'+editor
        command, result = read(stem+'.command.json'), read(stem+'.result.json')
        assert all(sha(Path(n)) == h for n,h in command['inputs'].items())
        assert result == comparison['outcomes'][editor]
        assert result['exit_code'] == 0 and not result['timed_out'] and result['source_unchanged'] and result['inputs_unchanged']
        out, err = (p/(stem+'.stdout')).read_bytes(), (p/(stem+'.stderr')).read_bytes()
        assert out and not err and hashlib.sha256(out).hexdigest() == result['stdout_sha256'] and err.hex() == result['stderr_hex']
        assert result['expected_output'] is not False
        if name != 'bytecode-direct-dispatch':
            assert out == (p/('source284-ordinary-'+name+'-'+editor+'.stdout')).read_bytes()
        else:
            assert out == (c/'tests/fixtures/bytecode-direct-dispatch.expected').read_bytes().rstrip(b'\n')
        outputs.append(out); programs.append(command['command'][-1])
    assert outputs[0] == outputs[1] and programs[0] == programs[1]
    ordinary[name] = dict(passed=True, stdout_sha256=hashlib.sha256(outputs[0]).hexdigest(), stdout_bytes=len(outputs[0]))
assert read(tag+'-generated-loaded-comparison.json')['passed']
for editor in ('gnu','emaxx'):
    stem = tag+'-generated-loaded-'+editor
    command, result = read(stem+'-command.json'), read(stem+'-result.json')
    assert all(sha(Path(n)) == h for n,h in command['inputs'].items())
    assert result['exit_code'] == 0 and not result['timed_out'] and result['source_unchanged'] and result['inputs_unchanged']
    assert command['command'][-2:] == ['-l',str(p/'printer-varied-v3-293638f0.el')]
    out = (p/(stem+'.stdout')).read_bytes()
    assert len(out) == 4088269 and len(out.splitlines()) == 198
    assert out == (p/'printer-varied-v3-gnu.stdout').read_bytes() and not (p/(stem+'.stderr')).read_bytes()
artifacts = read(tag+'-ordinary-artifacts.json')
assert all(sha(Path(n)) == sha(Path(r['immutable_copy'])) == r['sha256'] for n,r in artifacts.items())
stages = ['fmt','check','clippy','diff','ordinary-build']
if tag == 'source286': stages += ['gate-build','release-build']
for stage in stages:
    raw = (p/(tag+'-'+stage+'.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:',raw,re.M)
    for line in raw.splitlines():
        if line.startswith('{'):
            assert json.loads(line).get('message',{}).get('level') not in ('warning','error')
patches = []
tracked_now = set(subprocess.check_output(['git','ls-files'],cwd=c,text=True).splitlines())
for label, commit in [('incremental','9c5b535614c5237dbd8e2e47f1dbe258bf7316be'),('complete','21d20f0eec08f3c013d5d3eb3bd6e9cfc16b3199')]:
    data = subprocess.check_output(['git','diff','--binary',commit,'--',*sorted(m)],cwd=c)
    for n in sorted(set(m)-tracked_now):
        r = subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',n],cwd=c,capture_output=True)
        assert r.returncode == 1 and not r.stderr; data += r.stdout
    patch = p/(tag+'-portable-'+label+'.patch')
    with patch.open('xb') as f:f.write(data)
    tracked = set(subprocess.check_output(['git','ls-tree','-r','--name-only',commit],cwd=root,text=True).splitlines())
    archive = subprocess.check_output(['git','archive',commit,'--',*sorted(tracked&m.keys())],cwd=root)
    with tempfile.TemporaryDirectory(prefix='emaxx-vm-replay-',dir='/private/tmp') as temp:
        target = Path(temp)
        with tarfile.open(fileobj=io.BytesIO(archive)) as source:
            for item in source:
                assert not Path(item.name).is_absolute() and '..' not in Path(item.name).parts
                dest = target/item.name
                if item.isdir():dest.mkdir(parents=True,exist_ok=True)
                else:
                    assert item.isfile();dest.parent.mkdir(parents=True,exist_ok=True)
                    dest.write_bytes(source.extractfile(item).read());os.chmod(dest,0o755 if item.mode&0o111 else 0o644)
        subprocess.run(['git','apply','--check',str(patch)],cwd=target,check=True)
        subprocess.run(['git','apply',str(patch)],cwd=target,check=True)
        assert all(sha(target/n) == h and (target/n).stat().st_mode&0o777 == (c/n).stat().st_mode&0o777 for n,h in m.items())
    patches.append(dict(patch=patch.name,sha256=sha(patch),base=commit,verified_inputs=522,bytes_and_modes='exact'))
evidence = {str(f):sha(f) for f in p.glob(tag+'-*') if f.is_file() and f.suffix in ('.json','.log','.stdout','.stderr','.patch')}
record = dict(status='passed', source_inputs_verified=522, profiles=profiles, ordinary_comparisons=43,
              ordinary_results=ordinary, generated_rows=198, generated_bytes=4088269,
              ordinary_artifacts=artifacts, portable_replays=patches, evidence_files=evidence,
              qualification='Bounded selected validation with all prior tests/fixtures preserved. The earlier GNU reference-vector syntax error, strict Clippy failure and actual baseline remainder mismatch remain recorded. Source287 is the correctness-only comparator; source286 also dispatches directly on canonical opcodes. Full final-platform validation and performance acceptance remain open.', goal_complete=False)
with (p/(tag+'-selected-audit.json')).open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(dict(status='passed',source=tag,profiles={k:r['passed'] for k,r in profiles.items()},ordinary_comparisons=43,source_inputs=522)))
