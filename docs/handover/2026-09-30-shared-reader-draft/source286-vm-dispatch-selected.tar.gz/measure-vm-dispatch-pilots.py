from pathlib import Path
import hashlib, json, os, subprocess, sys, time
p = Path(__file__).parent.resolve()
g = p.parent / 'rebuilt-2026-10-01/emacs'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda n: json.loads((p/n).read_text())
variants = {
    'source284': ('reader-bounds-ascii', 'reader-character-validation'),
    'source287': ('remainder-corrected-baseline', 'vm-dispatch-validation'),
    'source286': ('vm-opcode-dispatch', 'vm-dispatch-validation'),
}
inputs = {}
for tag, (directory,target) in variants.items():
    c = p.parent/'recovered-2026-10-03'/directory/'emaxx'
    assert read(tag+'-selected-audit.json')['status'] == 'passed'
    manifest = read(tag+'-manifest.json')
    assert all(sha(c/n) == h for n,h in manifest.items())
    binary = c/'target'/target/'release/emaxx'
    for path,r in read(tag+'-ordinary-artifacts.json').items():
        assert sha(Path(path)) == sha(Path(r['immutable_copy'])) == r['sha256']
    for n in ('tools/core_runtime_perf.py','compat/core_runtime_perf.json','compat/core_runtime_perf.el'):
        assert sha(c/n) == read('source284-manifest.json')[n]
    inputs[tag] = dict(root=c,binary=binary,native=p/(tag+'-core-native'),manifest=manifest)
state = dict(status='starting native preparation', rounds=3,
             schedule=[['source284','source287','source286'],['source287','source286','source284'],['source286','source284','source287']],
             qualification='Three rotated repetitions of the unchanged full16 pilot, 288 normal editor processes. This diagnostic comparison separates the remainder correction from direct VM dispatch. It does not change or satisfy the full nine-round calibrated performance contract. No build, validation or profiling jobs run during timing.', results=[], goal_complete=False)
def save():
    (p/'vm-dispatch-performance-state.json').write_text(json.dumps(state,indent=2)+'\n')
def run(stage, tag, args):
    item = inputs[tag]
    command = [sys.executable,'-B','tools/core_runtime_perf.py',*args,'--source',str(g),'--oracle',str(g/'src/emacs'),'--emaxx',str(item['binary']),'--diagnostic']
    with (p/('vm-dispatch-performance-'+stage+'-command.json')).open('x') as f:
        json.dump(dict(command=command,working_directory=str(item['root']),source_manifest=tag+'-manifest.json',environment_overrides=dict(LANG='C',LC_ALL='C')),f,indent=2)
    state['status'] = 'running '+stage; save(); start=time.monotonic()
    with (p/('vm-dispatch-performance-'+stage+'.log')).open('xb') as log:
        r = subprocess.run(command,cwd=item['root'],env=dict(os.environ,LANG='C',LC_ALL='C'),stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
    result = dict(stage=stage,source=tag,exit_code=r.returncode,elapsed_seconds=time.monotonic()-start,
                  source_unchanged=all(sha(item['root']/n)==h for n,h in item['manifest'].items()))
    with (p/('vm-dispatch-performance-'+stage+'-result.json')).open('x') as f:json.dump(result,f,indent=2)
    state['results'].append(result);save();print(json.dumps(result),flush=True)
    assert result['exit_code']==0 and result['source_unchanged']
try:
    run('source287-prepare','source287',['prepare','--output',str(inputs['source287']['native'])])
    for item in inputs.values():
        for editor in ('oracle','emaxx'):
            artifact=json.loads((item['native']/editor/'artifact.json').read_text())
            assert artifact['completed'] and sha(item['native']/editor/'comp-test-funcs.eln')==artifact['sha256']
    for round_number,order in enumerate(state['schedule']):
        for tag in order:
            output=p/(tag+'-vm-comparison-pilot-'+str(round_number))
            run(tag+'-pilot-'+str(round_number),tag,['pilot','--pilot-runner','both','--native-dir',str(inputs[tag]['native']),'--output',str(output)])
    state['status']='all diagnostic comparisons finished; raw audit required'
except Exception as error:
    state.update(status='diagnostic comparison stopped',error=repr(error))
finally:
    save()
    with (p/'vm-dispatch-performance-result.json').open('x') as f:json.dump(state,f,indent=2)
sys.exit(0 if state['status'].startswith('all diagnostic') else 1)
