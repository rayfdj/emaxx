from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys, time

p = Path(__file__).parent.resolve()
c = p.parent / 'recovered-2026-10-03/remainder-corrected-baseline/emaxx'
optimized = p.parent / 'recovered-2026-10-03/vm-opcode-dispatch/emaxx'
g = p.parent / 'rebuilt-2026-10-01/emacs'
target = c / 'target/vm-dispatch-validation'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
manifest = json.loads((p / 'source287-manifest.json').read_text())
unchanged = lambda: all(sha(c / n) == h for n, h in manifest.items())
assert unchanged() and len(manifest) == 522 and not target.exists()
base = json.loads((p / 'source284-manifest.json').read_text())
for n in ['src/lisp/bytecode.rs', 'src/lisp/bytecode/vm.rs']:
    assert sha(c / n) == base[n]
env = dict(os.environ, CARGO_TARGET_DIR=str(target), CARGO_BUILD_JOBS='1', LANG='C', LC_ALL='C',
           EMAXX_GNU_SOURCE_DIRECTORY=str(g), EMAXX_DUMP_SOURCE_DIRECTORY=str(g),
           EMAXX_IMAGE_TEMPLATE='1', EMAXX_IMAGE_FORCE='1')
state = dict(status='starting', candidate=str(c), source_manifest='source287-manifest.json', results=[], goal_complete=False)
def save():
    (p / 'source287-build-state.json').write_text(json.dumps(state, indent=2) + '\n')
def run(stage, command):
    assert unchanged()
    with (p / ('source287-' + stage + '-command.json')).open('x') as f:
        json.dump(dict(command=command, working_directory=str(c), timeout_seconds=1800,
                       environment_overrides={k:v for k,v in env.items() if k.startswith(('CARGO_', 'EMAXX_')) or k in ('LANG','LC_ALL')}), f, indent=2)
    state['status'] = 'running ' + stage; save(); start = time.monotonic()
    with (p / ('source287-' + stage + '.log')).open('xb') as log:
        try:
            r = subprocess.run(command, cwd=c, env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, timeout=1800)
            code, timed_out = r.returncode, False
        except subprocess.TimeoutExpired:
            code, timed_out = None, True
    result = dict(stage=stage, exit_code=code, timed_out=timed_out, elapsed_seconds=time.monotonic()-start, source_unchanged=unchanged())
    with (p / ('source287-' + stage + '-result.json')).open('x') as f: json.dump(result, f, indent=2)
    state['results'].append(result); save(); print(json.dumps(result), flush=True)
    assert code == 0 and not timed_out and result['source_unchanged'], result
try:
    target.parent.mkdir(exist_ok=True)
    run('cache-clone', ['cp', '-cR', str(optimized / 'target/vm-dispatch-validation'), str(target)])
    run('fresh-crate', ['cargo', 'clean', '--release', '-p', 'emaxx'])
    run('fmt', ['cargo', 'fmt', '--all', '--', '--check'])
    run('check', ['cargo', 'check', '--locked', '--all-targets', '--all-features'])
    run('clippy', ['cargo', 'clippy', '--locked', '--all-targets', '--all-features', '--', '-D', 'warnings'])
    run('diff', ['git', 'diff', '--check'])
    run('ordinary-build', ['cargo', 'build', '--locked', '--release', '--all-features', '--bin', 'emaxx'])
    run('ordinary-image', ['sh', 'tools/build-image.sh', str(target / 'release/emaxx')])
    artifacts = {}
    for f in [target / 'release/emaxx', target / 'release/emaxx.pdmp']:
        copy = p / ('source287-ordinary-' + f.name)
        assert not copy.exists(); shutil.copy2(f, copy); assert sha(copy) == sha(f)
        artifacts[str(f)] = dict(sha256=sha(f), immutable_copy=str(copy), bytes=f.stat().st_size)
    with (p / 'source287-ordinary-artifacts.json').open('x') as f: json.dump(artifacts, f, indent=2)
    names = list(json.loads((p / 'source284-selected-audit.json').read_text())['ordinary_results']) + ['bytecode-direct-dispatch']
    assert len(names) == 42
    run('ordinary-fixtures', [sys.executable, '-B', str(p / 'compare-vm-dispatch-fixtures.py'), 'source287', str(c), *names])
    run('ordinary-generated', [sys.executable, '-B', str(p / 'compare-source287-generated-loaded.py')])
    state['status'] = 'corrected baseline built; 43 ordinary GNU comparisons passed; raw audit required'
except Exception as error:
    state.update(status='baseline validation stopped', error=repr(error))
finally:
    save()
    with (p / 'source287-build-result.json').open('x') as f: json.dump(state, f, indent=2)
sys.exit(0 if state['status'].startswith('corrected baseline built') else 1)
