from pathlib import Path

p = Path(__file__).parent.resolve()
c = p.parent / 'recovered-2026-10-06/native-subr-objects/emaxx'

def edit(name, body):
    f = c / name
    f.write_text(body(f.read_text()))

def replace(s, old, new):
    assert s.count(old) == 1, (old[:100], s.count(old))
    return s.replace(old, new)

def types(s):
    s = replace(s, 'pub use crate::lisp::alloc::vectors::NativeFunctionRef;\n#![allow(dead_code)]', '#![allow(dead_code)]\n\npub use crate::lisp::alloc::vectors::NativeFunctionRef;')
    return s
edit('src/lisp/types.rs', types)

def loader(s):
    s = s.replace('use std::collections::HashMap;\n','').replace('use std::ffi::c_void;', 'use std::ffi::{CString, c_void};')
    s = s.replace('use crate::lisp::types::{Env, Kind, LispError, Value};','use crate::lisp::types::{Env, Kind, LispError, NativeFunctionRef, Value};\nuse crate::lisp::alloc::vectors::native_functions::NativeFunctionSpec;')
    start = s.index('    functions: HashMap<u64, NativeFunction>,')
    end = s.index('\n}', start)
    s = s[:start]+s[end:]
    s = replace(s, 'self.units.is_empty()\n            && self.functions.is_empty()\n            && self.function_names.is_empty()\n            && self.function_c_names.is_empty()', 'self.units.is_empty()')
    s = s.replace('            .chain(self.functions.keys().copied())\n','')
    start = s.index('    fn function(&self, record_id: u64)')
    end = s.index('\n}\n', start)
    s = s[:start]+s[end:]
    s = replace(s, '''let native_function = matches!(actual.kind(), Kind::Record(id)
            if interpreter.find_record(id).is_some_and(|record|
                record.kind == RecordKind::NativeCompiledFunction));''', 'let native_function = matches!(actual.kind(), Kind::NativeFunction(_));')
    s = replace(s, 'let (min_args, convention, max_args) = native_arity(dynamic, min_args, &max_value)?;', 'let (min_args, _, _) = native_arity(dynamic, min_args, &max_value)?;')
    start = s.index('        let function = interpreter.create_pseudovector(\n            RecordKind::NativeCompiledFunction,')
    end = s.index('\n        if matches!(kind, RegistrationKind::Lambda)',start)
    s = s[:start]+'''        let function = Value::NativeFunction(NativeFunctionRef::new(NativeFunctionSpec {
            target,
            min_args: min_args as i16,
            max_args: max_value.as_integer().map_or(-2, |n| n as i16),
            name: CString::new(symbol_name).map_err(|_| super::lisp::native_ice("NUL in native name"))?,
            c_name: CString::new(c_name).map_err(|_| super::lisp::native_ice("NUL in native C name"))?,
            doc: rest.first().copied().unwrap_or(Value::Nil).as_integer()? as isize,
            fields: [rest.get(1).copied().unwrap_or(Value::Nil),
                     rest.get(2).copied().unwrap_or(Value::Nil), arguments[6], lambda_list, arguments[4]],
        }));
        // Registration can call Lisp before fset or the unit lambda guard owns
        // the subr. Keep the actual object rooted for that publication interval.
        let mut roots = crate::lisp::alloc::RootedVec::new();
        roots.push(function);
''' + s[end:]
    start = s.index('pub(crate) fn call_active_function(')
    end = s.index('\nfn invalid_function(',start)
    section = s[start:end]
    section = section.replace('record_id: u64','native: NativeFunctionRef').replace('            record_id,','            native,').replace('        record_id,','        native,')
    section = replace(section,'let function = with_active_registry(|registry| registry.function(record_id)).flatten()?;', 'if ACTIVE_REGISTERED_RUNTIME.get().is_null() && !super::runtime::has_current_runtime() {\n        return None;\n    }\n    let function = descriptor(native);')
    old_start = section.index('    let function = registry\n        .function(record_id)')
    old_end = section.index('    check_arity(function, arguments.len())?;',old_start)
    section = section[:old_start]+'    let function = descriptor(native);\n'+section[old_end:]
    old_start = section.index('    let record = interpreter\n        .find_record(record_id)')
    old_end = section.index('    let parameters = lambda_list.to_vec()?;',old_start)
    section = section[:old_start]+'    let lambda_list = native.lambda_list();\n'+section[old_end:]
    section = section.replace('interpreter.record_value(record_id)','Value::NativeFunction(native)')
    s = s[:start]+section+s[end:]
    start = s.index('pub(crate) fn function_target(')
    end = s.index('/// pdumper.c:dump_do_dump_relocation', start)
    s = s[:start]+'''fn descriptor(function: NativeFunctionRef) -> NativeFunction {
    let dynamic = function.is_dynamic();
    let maximum = function.max_args_word();
    let (convention, max_args) = if maximum < 0 {
        (if dynamic { NativeCallingConvention::Fixed } else { NativeCallingConvention::Many }, None)
    } else {
        native_function_signature(dynamic, maximum as usize)
    };
    NativeFunction { target: function.target(), convention,
        min_args: function.min_args() as usize, max_args, dynamic }
}

pub(crate) fn function_target(function: NativeFunctionRef) -> (*mut c_void, NativeCallingConvention) {
    let descriptor = descriptor(function);
    (descriptor.target.cast_mut(), descriptor.convention)
}

''' + s[end:]
    start = s.index('pub(crate) struct DumpedNativeFunction {')
    end = s.index('\n}',start)
    s = s[:start]+'''pub(crate) struct DumpedNativeFunction {
    pub(crate) function: NativeFunctionRef,
''' + s[end:]
    start = s.index('    let record_id = function.record_id;',s.index('pub(super) fn resolve_dumped_function('))
    end = s.index('    let unit_file = interpreter',start)
    s = s[:start]+'''    let function = function.function;
    let Kind::Record(unit_record_id) = function.unit().kind() else {
        return Err(dump_load_error("dumped native function has no compilation unit".into()));
    };
''' + s[end:]
    s = s.replace('let c_name = function.c_name.as_str();','let c_name = function.c_name();')
    start = s.index('    let (min_args, convention, max_args) = native_arity(',s.index('pub(super) fn resolve_dumped_function('))
    end = s.index('    let (lambda_guard, lambda_name_index)',start)
    s = s[:start]+'    function.set_target(target);\n\n'+s[end:]
    start = s.index('pub(super) fn resolve_dumped_function(')
    end = s.index('/// comp.c:native_function_doc',start)
    section = s[start:end].replace('let subr = interpreter.record_value(record_id);','let subr = Value::NativeFunction(function);')
    s = s[:start]+section+s[end:]
    start = s.index('pub(crate) fn active_direct_function(')
    end = s.index('\n#[cfg(test)]',start)
    s = s[:start]+'''pub(crate) fn direct_function(native: NativeFunctionRef) -> Option<DirectNativeFunction> {
    let function = descriptor(native);
    (!function.dynamic).then_some(DirectNativeFunction {
        target: function.target, convention: function.convention,
        min_args: function.min_args, max_args: function.max_args,
    })
}
''' + s[end:]
    return s
edit('src/lisp/native_comp/loader.rs', loader)

def runtime(s):
    s = s.replace('        record_id: u64,\n        function: super::loader::DirectNativeFunction,','        native: crate::lisp::types::NativeFunctionRef,\n        function: super::loader::DirectNativeFunction,')
    s = replace(s, '                record_id,\n                function,','                native,\n                function,')
    s = replace(s, '                // SAFETY: the active call\'s interpreter, live for the call.\n                unsafe { &*active.interpreter }.record_value(record_id),','                Value::NativeFunction(native),')
    s = replace(s, '''Kind::Record(record_id) => {
            super::loader::active_direct_function(record_id.id).map(|function| {
                DirectFuncallTarget::Native {
                    record_id: record_id.id,
                    function,
                }
            })
        }''', '''Kind::NativeFunction(native) => super::loader::direct_function(native)
            .map(|function| DirectFuncallTarget::Native { native, function }),''')
    return s
edit('src/lisp/native_comp/runtime.rs', runtime)

def state(s):
    start=s.index('    pub(crate) fn call_function(');end=s.index('    pub(crate) fn register(',start)
    section=s[start:end].replace('record_id: u64','function: crate::lisp::types::NativeFunctionRef').replace('            record_id,','            function,')
    s=s[:start]+section+s[end:]
    start=s.index('    pub(crate) fn function_name(');end=s.index('    /// The image loader',start);s=s[:start]+s[end:]
    start=s.index('    pub(crate) fn install_trampoline(');end=s.index('    pub(crate) fn compile_current_unit(',start)
    section=s[start:end].replace('record_id: u64','function: crate::lisp::types::NativeFunctionRef')
    a=section.index('        let (target, _convention)');b=section.index('        self.runtime',a)
    section=section[:a]+'        let (target, _convention): (*mut c_void, _) = loader::function_target(function);\n'+section[b:]
    return s[:start]+section+s[end:]
edit('src/lisp/native_comp/state.rs', state)

def module(s):
    start=s.index('pub(crate) fn call_function(');end=s.index('pub(crate) fn function_documentation(',start)
    section=s[start:end].replace('record_id: u64','function: crate::lisp::types::NativeFunctionRef').replace('record_id, arguments','function, arguments')
    s=s[:start]+section+s[end:]
    start=s.index('pub(crate) fn function_documentation(');a=s.index('    let (index, unit_id) = {',start);b=s.index('    let docs = interpreter',a)
    section=s[start:a].replace('record_id: u64','function: crate::lisp::types::NativeFunctionRef')
    section+='''    let index = usize::try_from(function.doc_index()).map_err(|_| lisp::native_ice("negative native documentation index"))?;
    let Kind::Record(unit_id) = function.unit().kind() else {
        return Err(lisp::native_ice("native function has no compilation unit"));
    };
'''
    s=s[:start]+section+s[b:]
    start=s.index('pub(crate) fn function_name(');end=s.index('/// pdumper.c:pdumper_load',start);s=s[:start]+s[end:]
    start=s.index('pub(crate) fn install_trampoline(');end=s.index('pub(crate) fn call_lisp(',start)
    section=s[start:end].replace('record_id: u64','function: crate::lisp::types::NativeFunctionRef')
    section=section.replace('if let Some((target, _convention)) = loader::active_function_target(record_id) {','if runtime::has_current_runtime() {\n        let (target, _convention) = loader::function_target(function);').replace('.install_trampoline(subroutine_index, record_id)','.install_trampoline(subroutine_index, function)')
    return s[:start]+section+s[end:]
edit('src/lisp/native_comp/mod.rs', module)

def evaluator(s):
    s = s.replace('            Kind::BuiltinFunc(_)\n            | Kind::Closure(_)', '            Kind::BuiltinFunc(_)\n            | Kind::NativeFunction(_)\n            | Kind::Closure(_)')
    s = s.replace('                Kind::Closure(_) => break resolution,','                Kind::Closure(_) | Kind::NativeFunction(_) => break resolution,')
    s = s.replace('RecordKind::NativeCompiledFunction | RecordKind::ModuleFunction','RecordKind::ModuleFunction')
    start=s.index('            Kind::Record(id)\n                if self\n                    .find_record(id)\n                    .is_some_and(|record| record.kind == RecordKind::NativeCompiledFunction)')
    end=s.index('            Kind::Record(id)',start+40)
    section=s[start:end]
    a=section.index('                let backtrace_function')
    section='            Kind::NativeFunction(function) => {\n'+section[a:]
    section=section.replace('Value::Record(id)','Value::NativeFunction(function)').replace('call_function(interp, env, id.id, args)','call_function(interp, env, function, args)')
    return s[:start]+section+s[end:]
edit('src/lisp/eval/core.rs', evaluator)

def gc(s):
    s=s.replace('            Kind::Closure(value) => value.mark_bit().is_marked(self.epoch),','            Kind::Closure(value) => value.mark_bit().is_marked(self.epoch),\n            Kind::NativeFunction(value) => value.mark_bit().is_marked(self.epoch),')
    s=s.replace('            Kind::Closure(value) => value.mark_bit().mark(self.epoch),','            Kind::Closure(value) => value.mark_bit().mark(self.epoch),\n            Kind::NativeFunction(value) => value.mark_bit().mark(self.epoch),')
    anchor='    fn trace_fields(&mut self, interp: &Interpreter, value: &Value) {\n        match value.kind() {'
    s=replace(s,anchor,anchor+'\n            Kind::NativeFunction(function) => {\n                for field in function.fields() { self.enqueue(&field); }\n            }')
    # Copy the actual object, publish its identity before traversing any child.
    anchor='            Kind::LispRecord(record) => {\n                let key = record.identity();'
    s=replace(s,anchor,'''            Kind::NativeFunction(function) => {
                let key = function.identity();
                if let Some(copied) = self.vectors.get(&key) { return *copied; }
                let copy = crate::lisp::types::NativeFunctionRef::new(
                    crate::lisp::alloc::vectors::native_functions::NativeFunctionSpec {
                        target: function.target(), min_args: function.min_args(),
                        max_args: function.max_args_word(), doc: function.doc_index(),
                        name: std::ffi::CString::new(function.name()).expect("valid stored C name"),
                        c_name: std::ffi::CString::new(function.c_name()).expect("valid stored C name"),
                        fields: [Value::Nil; 5],
                    });
                let copied = Value::NativeFunction(copy);
                self.vectors.insert(key, copied);
                copy.set_fields(function.fields().map(|field| self.copy(&field)));
                copied
            }
'''+anchor)
    return s
edit('src/lisp/eval.rs', gc)
edit('src/lisp/alloc.rs', lambda s:s.replace('        Kind::Closure(lambda) => Some(lambda.mark_bit().is_marked(epoch)),','        Kind::Closure(lambda) => Some(lambda.mark_bit().is_marked(epoch)),\n        Kind::NativeFunction(function) => Some(function.mark_bit().is_marked(epoch)),'))
print('Migrated registration/call metadata out of the three maps; dump and metadata integration still pending')
