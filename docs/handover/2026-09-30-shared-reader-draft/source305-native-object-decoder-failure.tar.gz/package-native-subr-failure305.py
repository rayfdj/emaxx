from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve();out=p.parents[2]/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda n:json.loads((p/n).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package');exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
a=read('source305-focused-failure-audit.json');assert a['passed']==a['failed']==2 and a['source_inputs']==537
assert all(sha(Path(n).read_bytes())==h for n,h in a['evidence_files'].items())
allowed={'.json','.log','.py','.txt','.patch','.stdout','.stderr','.el','.expected'}
files={f.name:f for f in p.iterdir() if f.is_file() and f.suffix in allowed and f.name.startswith(('source305-','source304-native-subr-negative.'))}
for n in ['source304-manifest.json','source304-gate-inventory.log','source304-native-object-authority-review.json','run-source305-validation.py','native_fixed_validation_support.py','replay-native-subr305.py','probe-native-subr-gnu305.py','prepare-native-subr-validation305.py','edit-native-subr-authority305.py','edit-native-subr-authority305-fixed.py','edit-native-subr-consumers305.py','edit-native-subr-dumping305.py','finish-native-object-review305.py','audit-native-subr-failure305.py','audit-native-subr-failure305-fixed.py','package-source196-failure-and197-results.py',Path(__file__).name]: files[n]=p/n
package('source305-native-object-decoder-failure',files,dict(status=a['status'],passed=2,failed=2,ignored=0,source_inputs=537,fixture_images_produced=0,audit=dict(path='source305-focused-failure-audit.json',sha256=sha((p/'source305-focused-failure-audit.json').read_bytes())),goal_complete=False,qualification=a['qualification']))
