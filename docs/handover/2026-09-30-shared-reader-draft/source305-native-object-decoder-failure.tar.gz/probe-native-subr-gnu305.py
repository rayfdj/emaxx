from pathlib import Path
import subprocess, json, hashlib, time
p=Path(__file__).parent
c=p.parent/'recovered-2026-10-06/native-subr-objects/emaxx'
g=p.parent/'rebuilt-2026-10-01/emacs'
f=c/'tests/fixtures/native-subr-authority.el'
program='(prin1 '+f.read_text()+')'
command=[str(g/'src/emacs'),'-Q','--batch','--eval',program]
hash=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
inputs={str(x):hash(x) for x in [f,g/'src/emacs',g/'src/emacs.pdmp']}
start=time.monotonic()
r=subprocess.run(command,cwd=c,capture_output=True,timeout=180)
for name,data in [('stdout',r.stdout),('stderr',r.stderr)]:
    (p/f'source305-gnu-subr-probe.{name}').open('xb').write(data)
assert all(hash(Path(n))==h for n,h in inputs.items())
record=dict(command=command,inputs=inputs,elapsed_seconds=time.monotonic()-start,exit_code=r.returncode)
(p/'source305-gnu-subr-probe.json').open('x').write(json.dumps(record,indent=2))
print(r.returncode,r.stdout.decode(),r.stderr.decode())
assert r.returncode==0
(c/'tests/fixtures/native-subr-authority.expected').write_bytes(r.stdout+b'\n')
