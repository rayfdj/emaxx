from pathlib import Path
import re
p=Path(__file__).parent.resolve();c=p.parent/'recovered-2026-10-06/native-subr-objects/emaxx'
def edit(name,fn):
    f=c/name;f.write_text(fn(f.read_text()))
def replace(s,old,new):
    assert s.count(old)==1,(old[:90],s.count(old));return s.replace(old,new)

def writer(s):
    s=s.replace('    Subr(u32),','    Subr(u32),\n    NativeFunction(usize),')
    s=s.replace('        Kind::BuiltinFunc(name) => ObjectKey::Subr(name.id()),','        Kind::BuiltinFunc(name) => ObjectKey::Subr(name.id()),\n        Kind::NativeFunction(function) => ObjectKey::NativeFunction(function.identity()),')
    s=s.replace('            Kind::BuiltinFunc(_) => DumpType::Subr,','            Kind::BuiltinFunc(_) => DumpType::Subr,\n            Kind::NativeFunction(_) => DumpType::Record,')
    s=s.replace('            Kind::BuiltinFunc(name) => (self.dump_subr(&name)?, DumpType::Subr),','            Kind::BuiltinFunc(name) => (self.dump_subr(&name)?, DumpType::Subr),\n            Kind::NativeFunction(function) => (self.dump_native_function(function)?, DumpType::Record),')
    old='''            RecordKind::NativeCompiledFunction => {
                let offset = self.dump_native_function(interp, id, object, &type_tag, &slots)?;
                Ok((offset, DumpType::Record))
            }'''
    s=replace(s,old,'''            RecordKind::NativeCompiledFunction => {
                Err(self.unsupported(object, "obsolete host native function record"))
            }''')
    start=s.index('    fn dump_native_function(');end=s.index('        let start = self.object_start()?;',start)
    s=s[:start]+'''    fn dump_native_function(
        &mut self,
        function: crate::lisp::types::NativeFunctionRef,
    ) -> Result<u32, DumpError> {
        // Keep the existing native-subr image codec, including old images.
        // Its obsolete host-record id is zero; object offsets own identity.
        // No record or name registry is created while executing or loading it.
        let id = 0;
        let type_tag = Value::symbol("subr");
        let slots = [Value::Nil, Value::Integer(i64::from(function.min_args())),
            if function.max_args_word() < 0 { Value::symbol("many") }
            else { Value::Integer(i64::from(function.max_args_word())) }, Value::Nil,
            function.native_type(), Value::Integer(function.doc_index() as i64),
            function.interactive(), function.command_modes(), function.unit(),
            function.lambda_list(), if function.is_dynamic() { Value::T } else { Value::Nil }];
        let name = function.name();
        let c_name = function.c_name();
''' + s[end:]
    return s
edit('src/lisp/primitives/pdumper/context.rs',writer)

def reader(s):
    anchor='''                    let type_tag = self.symbol_or_immediate_at(offset + 16)?;
                    self.interp.install_record(record_state_for_load('''
    s=replace(s,anchor,'''                    let type_tag = self.symbol_or_immediate_at(offset + 16)?;
                    if record_kind == RecordKind::NativeCompiledFunction {
                        if nslots != 11 || self.relocs.get(&offset) != Some(&DumpRelocKind::NativeSubr) {
                            return Err(LoadError::Error("invalid native subr image record".into()));
                        }
                        let function = crate::lisp::types::NativeFunctionRef::blank();
                        self.objects.insert(offset, Value::NativeFunction(function));
                        native_function_records.push((offset, function, nslots));
                        continue;
                    }
                    self.interp.install_record(record_state_for_load(''')
    start=s.index('                        RecordKind::NativeCompiledFunction => {');end=s.index('                        _ => {}',start)
    s=s[:start]+s[end:]
    anchor='''                    let record = self
                        .interp
                        .find_record_mut(id)
                        .ok_or_else(|| LoadError::Error(format!("record {id} was installed")))?;
                    record.slots = slots;'''
    s=replace(s,anchor,'''                    if let Kind::NativeFunction(function) = self.objects[&offset].kind() {
                        let integer = |value: Value| value.as_integer()
                            .map_err(|error| LoadError::Error(error.to_string()));
                        let minimum = integer(slots[1])? as i16;
                        let maximum = if slots[2].as_symbol().ok() == Some("many") { -2 }
                            else { integer(slots[2])? as i16 };
                        function.set_arity(minimum, maximum);
                        function.set_doc_index(integer(slots[5])? as isize);
                        function.set_fields([slots[6], slots[7], slots[8], slots[9], slots[4]]);
                    } else {
                        let record = self.interp.find_record_mut(id)
                            .ok_or_else(|| LoadError::Error(format!("record {id} was installed")))?;
                        record.slots = slots;
                    }''')
    start=s.index('        for (offset, id, nslots) in native_function_records {');end=s.index('        for (offset, id, nslots) in obarray_records {',start)
    s=s[:start]+'''        for (offset, function, nslots) in native_function_records {
            let names_at = offset + 32 + 8 * nslots as u32;
            let name = self.value_at(names_at)?;
            let c_name = self.value_at(names_at + 8)?;
            let text = |value: Value, what: &str| {
                let text = string_like(&value).map(|string| string.text)
                    .ok_or_else(|| LoadError::Error(format!("native function {what} is not a string")))?;
                std::ffi::CString::new(text)
                    .map_err(|_| LoadError::Error(format!("NUL in native function {what}")))
            };
            let name = text(name, "name")?;
            let c_name = text(c_name, "C name")?;
            // SAFETY: this load's newly allocated object is unpublished. No
            // borrowed C-name view exists while the initial names are replaced.
            unsafe { &mut *function.as_ptr() }.set_names(name, c_name);
            native_functions.push(crate::lisp::native_comp::DumpedNativeFunction { function });
        }
''' + s[end:]
    return s
edit('src/lisp/primitives/pdumper/load.rs',reader)

def ownership_test(s):
    start=s.index('        registry\n            .function_names\n            .insert(23, "before-suspension".into());')
    end=start+len('        registry\n            .function_names\n            .insert(23, "before-suspension".into());')
    s=s[:start]+'''        // The function-name maps have gone. Exercise the registry's real
        // remaining owners: stable loaded-unit allocations across suspension.
        let unit = |record_id| Rc::new(LoadedUnit {
            library: libloading::os::unix::Library::this().into(), record_id,
            loaded_once: Cell::new(false), load_ongoing: Cell::new(false),
            _data: Value::Nil, _impure_data: Value::Nil, _optimization_qualities: Value::Nil,
            data_relocations: std::ptr::null_mut(), data_relocation_count: 0,
            impure_relocations: std::ptr::null_mut(), impure_relocation_count: 0,
        });
        let before = unit(23);
        let suspended = unit(29);
        registry.units.push(Rc::clone(&before));
''' + s[end:]
    s=replace(s,'''                    assert_eq!(
                        interpreter.native_compiler.registry.function_name(23),
                        Some("before-suspension")
                    );''','''                    assert!(Rc::ptr_eq(&interpreter.native_compiler.registry.unit(23).unwrap(), &before));''')
    s=replace(s,'''                    interpreter
                        .native_compiler
                        .registry
                        .function_names
                        .insert(29, "while-suspended".into());''','''                    interpreter.native_compiler.registry.units.push(Rc::clone(&suspended));''')
    s=replace(s,'''        assert_eq!(registry.function_name(23), Some("before-suspension"));
        assert_eq!(registry.function_name(29), Some("while-suspended"));''','''        assert!(Rc::ptr_eq(&registry.unit(23).unwrap(), &before));
        assert!(Rc::ptr_eq(&registry.unit(29).unwrap(), &suspended));''')
    return s
edit('src/lisp/native_comp/loader.rs',ownership_test)

def tests(s):
    pattern=r'matches!\((interp|temacs)\.raw_function_binding\(name, &env\)\.map\(\|v\| v\.kind\(\)\), Some\(Kind::Record\(id\)\)\s+if \1\.find_record\(id\)\.is_some_and\(\|record\|\s+record\.kind == crate::lisp::eval::RecordKind::NativeCompiledFunction\)\)'
    s,count=re.subn(pattern,lambda m:'matches!('+m[1]+'.raw_function_binding(name, &env).map(|v| v.kind()), Some(Kind::NativeFunction(_)))',s)
    assert count==2,count
    return s
edit('src/lisp/primitives/tests.rs',tests)
print('Connected native image relocation and preserved actual loader-owner suspension checks')
