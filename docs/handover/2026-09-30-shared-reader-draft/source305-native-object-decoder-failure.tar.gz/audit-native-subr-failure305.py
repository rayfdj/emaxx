from pathlib import Path
import hashlib,json,re
p=Path(__file__).parent.resolve();c=p.parent/'recovered-2026-10-06/native-subr-objects/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
read=lambda n:json.loads((p/n).read_text())
m=read('source305-manifest.json');s=read('source305-validation-result.json')
assert len(m)==537 and all(sha(c/n)==h for n,h in m.items())
assert s['status']=='validation stopped' and s['results'][-1]['stage']=='gate-focused' and s['results'][-1]['exit_code']==101
assert all(r['source_unchanged'] and not r['timed_out'] for r in s['results'])
assert all(r['exit_code']==0 for r in s['results'][:-1])
for stage in ['fmt','check','clippy','diff']:
 raw=(p/f'source305-{stage}.log').read_text();assert not re.search(r'^warning[\[:]',raw,re.M)
raw=(p/'source305-gate-focused.log').read_text()
verdicts=dict(re.findall(r'^test (\S+) \.\.\. (ok|FAILED)$',raw,re.M));assert len(verdicts)==4
assert sum(v=='ok' for v in verdicts.values())==sum(v=='FAILED' for v in verdicts.values())==2
assert re.findall(r'^test result:.*',raw,re.M)==['test result: FAILED. 2 passed; 2 failed; 0 ignored; 0 measured; 3042 filtered out; finished in 3.53s']
assert 'actual subr relocation: SignalValue' in raw and 'unknown native Lisp word' in raw and 'comp_unit_relocations_match' in raw
assert not list((p/'fixture-images-source305').glob('*.pdmp'))
inventory=[x[:-6] for x in (p/'source305-gate-inventory.log').read_text().splitlines() if x.endswith(': test')]
prior=[x[:-6] for x in (p/'source304-gate-inventory.log').read_text().splitlines() if x.endswith(': test')]
assert len(inventory)==len(set(inventory))==3046 and set(inventory)==set(prior)|set(verdicts)
for item in read('source305-failed-retained-inputs.json'):
 assert sha(Path(item['retained']))==item['sha256'] and Path(item['retained']).stat().st_size==item['bytes']
portable=read('source305-portable-draft-audit.json')
for item in portable['patches']:assert sha(p/item['patch'])==item['sha256'] and item['inputs']==537
inputs=[p/f'source305-{stage}.log' for stage in ['fmt','check','clippy','diff','gate-build','gate-inventory','gate-focused']]
inputs += [p/n for n in ['source305-manifest.json','source305-validation-result.json','source305-failed-retained-inputs.json','source305-portable-draft-audit.json','run-source305-validation.py','source304-native-subr-negative.json','source304-native-subr-negative.stdout','source304-native-subr-negative.stderr','source305-gnu-subr-probe.json','source305-gnu-subr-probe.stdout','source305-gnu-subr-probe.stderr',Path(__file__).name]]
record=dict(status='failed focused native-object draft; unapplied',source_inputs=537,inventory=len(inventory),passed=2,failed=2,ignored=0,raw_verdicts=verdicts,unstarted='broader gate selection, all release validation and ordinary candidate comparisons',retained_inputs=read('source305-failed-retained-inputs.json'),fixture_images_produced=0,evidence_files={str(f):sha(f) for f in inputs},portable=portable,goal_complete=False,qualification='Physical88-byte GNU subr layout, direct tagged identity and all-five-field GC survival/eventual cyclic reclamation pass. Checked native relocation decoding rejects the new allocated Subr because its exact-allocator-header whitelist omitted that tag; the unchanged loader agreement assertion also fails. All4 contracts and assertions remain. No failed305 binary is promoted. The original304 same-input ordinary metadata probe also fails GNU value< against a static subr; that baseline failure is separate from these305 decoder failures. GNU actual output is retained. Source306 adds only the omitted allocated tag to the checked boundary; it must validate independently.')
(p/'source305-focused-failure-audit.json').open('x').write(json.dumps(record,indent=2));print(json.dumps({k:record[k] for k in ['status','passed','failed','ignored','fixture_images_produced']}))
