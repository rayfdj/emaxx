from pathlib import Path
import re
p=Path(__file__).parent.resolve()
c=p.parent/'recovered-2026-10-06/native-subr-objects/emaxx'

def edit(name,fn):
    f=c/name;f.write_text(fn(f.read_text()))

def replace(s,old,new):
    assert s.count(old)==1,(old[:90],s.count(old));return s.replace(old,new)

def storage(s):
    anchor='    pub(crate) fn fields(&self) -> [Value; 5] {'
    return replace(s,anchor,'''    pub(crate) fn interactive(&self) -> Value { self.interactive.get() }
    pub(crate) fn command_modes(&self) -> Value { self.command_modes.get() }
    pub(crate) fn native_type(&self) -> Value { self.native_type.get() }
    pub(crate) fn arity_value(&self) -> Value {
        Value::cons(Value::Integer(i64::from(self.min_args())),
            if self.max_args_word() < 0 { Value::symbol("many") }
            else { Value::Integer(i64::from(self.max_args_word())) })
    }
'''+anchor)
edit('src/lisp/alloc/vectors/native_functions.rs',storage)

def loader(s):
    start=s.index('    if ACTIVE_REGISTERED_RUNTIME.get().is_null()',s.index('pub(crate) fn call_active_function('))
    end=s.index('\n}\n',start)
    s=s[:start]+'''    let function = descriptor(native);
    super::runtime::with_current_runtime(|runtime| {
        check_arity(function, arguments.len())?;
        invoke_function(function, native, runtime, interpreter, environment, arguments)
    })'''+s[end:]
    start=s.index('fn call_function_with_runtime(');end=s.index('fn invoke_function(',start)
    return s[:start]+s[end:]
edit('src/lisp/native_comp/loader.rs',loader)

def module(s):
    start=s.index('    if runtime::has_current_runtime()',s.index('pub(crate) fn install_trampoline('))
    end=s.index('    interpreter\n        .native_compiler',start)
    return s[:start]+'''    if let Some(result) = runtime::with_current_runtime(|runtime| {
        runtime.install_trampoline(subroutine_index, function.target().cast_mut())
    }) {
        return result.map_err(|error| lisp::native_ice(&error));
    }
'''+s[end:]
edit('src/lisp/native_comp/mod.rs',module)

def metadata_arms(s):
    # Only the exact old native-subr arms are removed; surrounding primitive
    # validation and every other callable kind stay intact.
    pattern=r'Kind::Record\(id\)\s+if interp\.find_record\(id\)\.is_some_and\(\|record\| \{\s+record\.kind == crate::lisp::eval::RecordKind::NativeCompiledFunction\s+\}\) =>\s+\{'
    matches=list(re.finditer(pattern,s))
    for m in reversed(matches):
        depth=1;i=m.end()
        while depth:
            if s[i]=='{':depth+=1
            elif s[i]=='}':depth-=1
            i+=1
        old=s[m.end():i-1]
        if 'Value::cons(record.slots[1], record.slots[2])' in old:
            body='Ok(function.arity_value())'
        elif 'function_name(interp, id.id)' in old:
            body='Ok(Value::string(function.name()))'
        elif 'record.slots[10].is_truthy()' in old:
            body='Ok(if function.is_dynamic() { function.lambda_list() } else { Value::T })'
        elif '.slots[8]' in old:
            body='Ok(function.unit())'
        elif '.slots[4]' in old:
            body='Ok(function.native_type())'
        elif 'function_documentation(interp, env, id.id)' in old:
            body='crate::lisp::native_comp::function_documentation(interp, env, function)'
        elif old.strip()=='Value::T':body='Value::T'
        else:raise AssertionError(old)
        s=s[:m.start()]+'Kind::NativeFunction(function) => { '+body+' }'+s[i:]
    return s

for name in ['src/lisp/primitives/dispatch/buffer_meta.rs','src/lisp/primitives/dispatch/misc.rs','src/lisp/primitives/dispatch/predicates.rs','src/lisp/primitives/numeric_time.rs']:
    edit(name,metadata_arms)
edit('src/lisp/primitives/dispatch/predicates.rs',lambda s:s.replace('Kind::NativeFunction(function) => { Value::T }','Kind::NativeFunction(_) => Value::T'))
edit('src/lisp/primitives/dispatch/buffer_meta.rs',lambda s:replace(s,'matches!(args[0].kind(), Kind::Record(id) if interp.find_record(id).is_some_and(|record| record.kind == crate::lisp::eval::RecordKind::NativeCompiledFunction))','matches!(args[0].kind(), Kind::NativeFunction(_))'))

def trampoline(s):
    start=s.index('                let Kind::Record(trampoline_id)',s.index('"comp--install-trampoline" =>'))
    end=s.index('                let original = interp.lookup_function',start)
    s=s[:start]+'''                let Kind::NativeFunction(trampoline) = args[1].kind() else {
                    return Err(wrong_type_argument("subrp", args[1]));
                };
'''+s[end:]
    return s.replace('                    trampoline_id.id,','                    trampoline,')
edit('src/lisp/primitives/dispatch/comp.rs',trampoline)

def completion(s):
    start=s.index('        if record.kind == crate::lisp::eval::RecordKind::NativeCompiledFunction {')
    end=s.index('\n    }',start)
    s=s[:start]+s[end:]
    anchor='    // callint.c\'s cons-lambda branch:'
    return replace(s,anchor,'''    if let Kind::NativeFunction(function) = func.kind() {
        let spec = function.interactive();
        return (!spec.is_nil()).then(|| spec.to_vec().ok()).flatten();
    }
'''+anchor)
edit('src/lisp/primitives/completion.rs',completion)

def types(s):
    old='''                        // data.c:Ftype_of answers `subr' for every
                        // PVEC_SUBR; only `cl-type-of' distinguishes native
                        // functions, special forms, and primitives.
                        if record.kind == crate::lisp::eval::RecordKind::NativeCompiledFunction {
                            return Ok(Value::symbol("subr"));
                        }
'''
    s=replace(s,old,'')
    s=s.replace('                    Kind::Record(id) => {\n                        let record = interp.find_record(id).ok_or_else', '                    Kind::NativeFunction(_) => "subr",\n                    Kind::Record(id) => {\n                        let _record = interp.find_record(id).ok_or_else')
    return s
edit('src/lisp/primitives/dispatch/misc_keymaps.rs',types)
edit('src/lisp/primitives/buffers.rs',lambda s:s.replace('        Kind::Finalizer(_) => "finalizer",','        Kind::NativeFunction(_) => "native-comp-function",\n        Kind::Finalizer(_) => "finalizer",'))

def pure(s):
    start=s.index('    if matches!(value.kind(), Kind::Record(id)\n        if interp.find_record(id).is_some_and(|record|\n            record.kind == crate::lisp::eval::RecordKind::NativeCompiledFunction))')
    end=s.index('    match value.kind() {',start)
    s=s[:start]+s[end:]
    return s.replace('        | Kind::BuiltinFunc(_)','        | Kind::BuiltinFunc(_)\n        | Kind::NativeFunction(_)')
edit('src/lisp/primitives/purecopy.rs',pure)

def values(s):
    s=s.replace('(Kind::BuiltinFunc(a), Kind::BuiltinFunc(b)) => a == b,','(Kind::BuiltinFunc(a), Kind::BuiltinFunc(b)) => a == b,\n        (Kind::NativeFunction(a), Kind::NativeFunction(b)) => a.ptr_eq(&b),')
    s=s.replace('matches!(value.kind(), Kind::BuiltinFunc(_) | Kind::Closure(_))','matches!(value.kind(), Kind::BuiltinFunc(_) | Kind::NativeFunction(_) | Kind::Closure(_))')
    s=s.replace('crate::lisp::eval::RecordKind::NativeCompiledFunction\n                    | crate::lisp::eval::RecordKind::ModuleFunction','crate::lisp::eval::RecordKind::ModuleFunction')
    return s
edit('src/lisp/primitives/values.rs',values)
print('Moved callable metadata consumers to the actual native subr fields')
