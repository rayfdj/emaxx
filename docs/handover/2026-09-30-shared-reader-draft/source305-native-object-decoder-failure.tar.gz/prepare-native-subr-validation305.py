from pathlib import Path
import ast
p=Path(__file__).parent
s=(p/'run-source304-validation.py').read_text().replace('source304','source305').replace('source303','source304')
s=s.replace("recovered-2026-10-05/native-arithmetic-audit/emaxx", "recovered-2026-10-06/native-subr-objects/emaxx")
s=s.replace("names = sorted(set(base) | {'tests/fixtures/native-binary-arithmetic.el', 'tests/fixtures/native-binary-arithmetic.expected'})", "names = sorted(set(base) | {'src/lisp/alloc/vectors/native_functions.rs', 'tests/fixtures/native-subr-authority.el', 'tests/fixtures/native-subr-authority.expected'})")
s=s.replace('len(manifest) == 534','len(manifest) == 537')
s=s.replace("assert changes == ['src/anti_cheat.rs', 'src/lisp/native_comp/runtime.rs']", "assert changes == sorted(changes) and len(changes) == 26, changes\nassert (c / 'src/anti_cheat.rs').read_bytes() == (p.parents[2] / 'src/anti_cheat.rs').read_bytes()\nassert not any('NativeCompiledFunction' in (c / n).read_text() for n in names if n.endswith('.rs'))")
s=s.replace('recovered-2026-10-05/buffer-display-columns/emaxx/target/vm-dispatch-validation', 'recovered-2026-10-05/native-arithmetic-audit/emaxx/target/vm-dispatch-validation')
a=s.index("        required_boundary_test = ")
b=s.index("        run(profile + '-selected'", a)
s=s[:a]+'''        new_tests = {
            'lisp::alloc::vectors::tests::native_subr_allocation_has_gnu_fields_and_direct_tagged_identity',
            'lisp::alloc::vectors::tests::native_subr_marks_all_five_fields_and_releases_unreachable_cycles',
            'lisp::native_comp::loader::tests::native_subr_calls_read_actual_target_and_arity_fields',
            'lisp::primitives::tests::native_subr_authority_preserves_gnu_metadata_calls_and_identity',
        }
        assert set(inventory) == set(prior) | new_tests and len(inventory) == len(set(inventory))
        baseline_selectors = set(read(p / 'source304-validation-result.json')['profiles'][profile]['selectors'])
        selectors = [n for n in inventory if n in baseline_selectors or re.search(r'native|pdump|dump_|image|module|weak|thread|suspended|purecopy|hash|value_', n)]
        assert baseline_selectors <= set(selectors) and new_tests <= set(selectors)
        # Run the new storage/GC/ABI/actual-GNU contracts before the full
        # affected selection, retaining separate actual verdicts for both.
        run(profile + '-focused', [str(binary), '--exact', '--test-threads=1', *sorted(new_tests)])
        focused = audit_selected((p / ('source305-' + profile + '-focused.log')).read_text(), sorted(new_tests))
        state.setdefault('focused', {})[profile] = focused
        save_state()
''' +s[b:]
# Count discovered inputs independently at launch. The exact list is retained.
s=s.replace('len(changes) == 26', 'len(changes) == 26')
ast.parse(s);(p/'run-source305-validation.py').open('x').write(s)
s=(p/'replay-native-audit304.py').read_text().replace('len(m) == 534','len(m) == 537')
a=s.index("qualification='Source304");b=s.index("'), f, indent=2)",a)
s=s[:a]+"qualification='Source305 removes the persistent function, name and C-name maps and the detached native-function RecordKind. Calls, Lisp metadata, tracing and dumping read the actual GNU-layout88-byte subr. The preserved code15 dump codec constructs actual subrs, not runtime records. Four new contracts add actual layout/ABI, live and dead GC, current target/arity and same-input ordinary GNU metadata coverage. All old test names/assertions and fixture bytes remain except representation-only native-presence detections and equivalent real-unit suspension ownership fixtures. This is an unapplied draft, not full validation, physical-accounting completion or a performance claim."+s[b:]
ast.parse(s);(p/'replay-native-subr305.py').open('x').write(s)
print('Prepared source305 fresh validation and portable replay helpers')
