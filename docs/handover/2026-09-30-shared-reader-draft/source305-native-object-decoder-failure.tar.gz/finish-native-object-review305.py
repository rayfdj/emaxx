from pathlib import Path
p = Path(__file__).parent
c = p.parent / 'recovered-2026-10-06/native-subr-objects/emaxx'
def replace(name, old, new):
    f=c/name
    text=f.read_text()
    assert text.count(old)==1, (name,old,text.count(old))
    f.write_text(text.replace(old,new))
replace('src/lisp/eval.rs', '    NativeCompiledFunction,\n', '')
replace('src/lisp/eval.rs', '''            // Both configured structs are 88 bytes on the supported GNU
            // 64-bit ABI (comp.h and lisp.h:Lisp_Subr).
            Self::NativeCompUnit | Self::NativeCompiledFunction => 11,''', '''            // comp.h:Lisp_Native_Comp_Unit is 88 bytes on this GNU ABI.
            Self::NativeCompUnit => 11,''')
f=c/'src/lisp/primitives/values.rs'
s=f.read_text(); assert s.count('        | crate::lisp::eval::RecordKind::NativeCompiledFunction\n')==2
f.write_text(s.replace('        | crate::lisp::eval::RecordKind::NativeCompiledFunction\n',''))
replace('src/lisp/primitives/buffers.rs', '                crate::lisp::eval::RecordKind::NativeCompiledFunction => "native-comp-function",\n', '')
replace('src/lisp/primitives/pdumper/context.rs', '        RecordKind::NativeCompiledFunction => 15,\n', '')
replace('src/lisp/primitives/pdumper/context.rs', '        15 => RecordKind::NativeCompiledFunction,\n', '        // Code 15 is the native subr codec, not a runtime host record.\n')
replace('src/lisp/primitives/pdumper/context.rs', '''            RecordKind::NativeCompiledFunction => {
                Err(self.unsupported(object, "obsolete host native function record"))
            }
''', '')
replace('src/lisp/primitives/pdumper/context.rs', 'u64::from(record_kind_code(RecordKind::NativeCompiledFunction))', 'u64::from(NATIVE_SUBR_CODE)')
replace('src/lisp/primitives/pdumper/context.rs', '/// The record kinds the image distinguishes (eval.rs:RecordKind), as\n', '''// The serialized native-subr discriminator is retained for image compatibility.
// It never names a RecordKind or installs a detached runtime record.
pub(crate) const NATIVE_SUBR_CODE: u32 = 15;

/// The record kinds the image distinguishes (eval.rs:RecordKind), as
''')
replace('src/lisp/primitives/pdumper/load.rs', '''                    let record_kind = record_kind_from_code(kind_code).ok_or_else(|| {
                        LoadError::Error(format!("unknown record kind {kind_code} at {offset}"))
                    })?;
                    let nslots''','''                    let nslots''')
replace('src/lisp/primitives/pdumper/load.rs', '                    if record_kind == RecordKind::NativeCompiledFunction {', '                    if kind_code == NATIVE_SUBR_CODE {')
replace('src/lisp/primitives/pdumper/load.rs', '''                    self.interp.install_record(record_state_for_load(
                        id,
                        record_kind,''', '''                    let record_kind = record_kind_from_code(kind_code).ok_or_else(|| {
                        LoadError::Error(format!("unknown record kind {kind_code} at {offset}"))
                    })?;
                    self.interp.install_record(record_state_for_load(
                        id,
                        record_kind,''')
replace('src/lisp/primitives/values.rs', '''    // fns.c:value_cmp treats distinct pseudovectors without a dedicated
''', '''    // fns.c:value_cmp gives all PVEC_SUBR objects the same unordered
    // relation, including a native subr compared with a static DEFUN subr.
    if matches!(left.kind(), Kind::BuiltinFunc(_) | Kind::NativeFunction(_))
        || matches!(right.kind(), Kind::BuiltinFunc(_) | Kind::NativeFunction(_))
    {
        return if matches!(left.kind(), Kind::BuiltinFunc(_) | Kind::NativeFunction(_))
            && matches!(right.kind(), Kind::BuiltinFunc(_) | Kind::NativeFunction(_))
        {
            Ok(if left.eq_value(*right) {
                ValueOrder::Equal
            } else {
                ValueOrder::Unordered
            })
        } else {
            Err(type_mismatch_signal(left, right))
        };
    }

    // fns.c:value_cmp treats distinct pseudovectors without a dedicated
''')
