from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/macro-saved-state/emaxx'
tag = 'source198'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
manifest = json.loads((p / (tag + '-manifest.json')).read_text())
unchanged = lambda: all(sha(root / f) == h for f, h in manifest.items())
selected = json.loads((p / (tag + '-selected-validation-result.json')).read_text())
audit = json.loads((p / (tag + '-selected-evidence-audit.json')).read_text())
assert selected['passed'] and selected['all_completed'] and selected['source_unchanged']
assert all(item['raw_passed'] == 542 and item['raw_failed'] == 0 for item in audit['rust'])
assert len(audit['ordinary_source198']) == 28 and unchanged()

def launch(kind, script, handle):
    assert unchanged()
    command = [sys.executable, str(p / script)]
    with (p / (tag + '-' + kind + '-driver.log')).open('x') as log:
        child = subprocess.Popen(command, cwd=root, stdin=subprocess.DEVNULL,
                                 stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    with (p / (tag + '-' + handle + '.json')).open('x') as stream:
        json.dump({'pid': child.pid, 'command': command, 'started_unix': time.time(),
                   'script_sha256': sha(p / script)}, stream, indent=2)
    print(kind, child.pid, flush=True)
    return child

# Rust and terminal validation have separate prerequisites and artifacts.
# Start full Rust after its audited gate/release and ordinary comparisons.
# Serialize the actual PTY runs to avoid competing terminal harnesses.
gate = launch('full-gate', 'run-source198-full-gate.py', 'full-gate-launch')
results = []
try:
    previous = json.loads((p / 'source196-fresh-full-tty-launch.json').read_text())
    while True:
        result = p / 'source196-fresh-full-ttydiff-result.json'
        if result.exists():
            try:
                json.loads(result.read_text())
                break
            except json.JSONDecodeError:
                pass
        os.kill(previous['pid'], 0)
        time.sleep(5)
    while True:
        try:
            os.kill(previous['pid'], 0)
        except ProcessLookupError:
            break
        time.sleep(1)
    tty = launch('selected-tty', 'run-source198-selected-tty.py', 'selected-tty-supervisor')
    code = tty.wait()
    results.append({'kind': 'selected-tty', 'pid': tty.pid, 'exit_code': code})
    if code == 0:
        checked = subprocess.run([sys.executable, str(p / 'audit-source198-selected-tty.py')], stdin=subprocess.DEVNULL)
        results.append({'kind': 'selected-tty-audit', 'exit_code': checked.returncode})
        if checked.returncode == 0:
            full = launch('full-tty', 'run-source198-full-tty.py', 'full-tty-launch')
            results.append({'kind': 'full-tty', 'pid': full.pid, 'exit_code': full.wait()})
except Exception as error:
    results.append({'kind': 'terminal-queue', 'exit_code': 1, 'error': repr(error)})
results.append({'kind': 'full-gate', 'pid': gate.pid, 'exit_code': gate.wait()})
with (p / (tag + '-full-local-supervisor-result.json')).open('x') as stream:
    json.dump({'status': 'finished', 'results': results, 'source_unchanged': unchanged(),
               'completed_unix': time.time(),
               'qualification': 'Full Rust follows audited selected prerequisites. Actual terminal runs are serialized after the previous candidate, and full terminal follows its own selected raw audit. Every result remains separately scoped.'}, stream, indent=2)
raise SystemExit(0 if unchanged() and len(results) == 4 and all(item['exit_code'] == 0 for item in results) else 1)
