from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve();out=p.parents[2]/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest();read=lambda n:json.loads((p/n).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
assert read('source294-manifest.json')==read('source293-manifest.json')
old=read('source293-validation-result.json')
assert len(old['results'])==14 and all(r['exit_code']==0 for r in old['results'])
assert all(read('source293-stale-cache-review.json')['evidence'][profile]['cargo_emaxx_fresh']==[True] for profile in ('gate','release'))
allowed={'.json','.log','.py','.patch','.txt','.stdout','.stderr'}
files={f.name:f for f in p.glob('source293-*') if f.is_file() and f.suffix in allowed}
names=['source294-preparation.json','source294-manifest.json','source294-draft.patch','run-source294-validation.py',
       'source292-validation-closed-result.json','source292-manifest.json','source292-portable-draft-audit.json',
       'source292-gate-build.log','source292-release-build.log','source292-image-setup-review.json',
       'buffer-line-timing-withdrawal.json','buffer-selection-v3-withdrawal.json',
       'buffer_line_validation_support.py','compare-vm-dispatch-fixtures.py','replay-buffer-line-drafts.py',
       'compare-source292-generated-loaded.py','compare-source294-generated-loaded.py','compare-buffer-line-broad-probe.py',
       'audit-buffer-line-selected-fresh.py','run-buffer-line-finalize-fresh.py',
       'measure-buffer-line-fresh.py','audit-buffer-line-fresh-performance.py','finish-buffer-line-performance-fresh.py',
       'package-source196-failure-and197-results.py',Path(__file__).name]
for name in names:files[name]=p/name
for name in ['source294-validation-state.json','buffer-selection-fresh-state.json','buffer-performance-sequence-fresh-state.json']:
    copy=p/(name.removesuffix('.json')+'-launch-snapshot.json')
    with copy.open('x') as f:json.dump(read(name),f,indent=2)
    files[copy.name]=copy
for row in read('source294-validation-state-launch-snapshot.json')['results']:
    for suffix in ['.log','-command.json','-result.json']:
        name='source294-'+row['stage']+suffix;files[name]=p/name
package('source293-stale-cache-and294-launch',files,dict(status='source293 stale validation rejected; source294 fresh build running',stale_review=read('source293-stale-cache-review.json'),source294_snapshot=read('source294-validation-state-launch-snapshot.json'),qualification='All532 source inputs in294 equal293 exactly. Existing293 portable patches reconstruct294 bytes/modes. Its reused292 gate/release binaries do not certify the line-lookup change despite passing semantic output. The old coordinators were terminated before any timing; all outputs and withdrawal receipts remain. Source294 explicitly cleans both profiles, requires compiler artifacts fresh=false and binaries distinct from292. Selected tests and timing are pending, not passes. The broader original display-column defect remains open.',goal_complete=False))
