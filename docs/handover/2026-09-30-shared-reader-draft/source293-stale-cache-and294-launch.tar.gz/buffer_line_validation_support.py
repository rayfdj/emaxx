import re

EXISTING_IGNORES = {
    'tty::tty_differential_end_to_end',
    'tty::tty_smoke_end_to_end',
}

def audit_selected(raw, selectors):
    starts = list(re.finditer(r'^test (\S+) \.\.\. ', raw, re.M))
    assert [m[1] for m in starts] == selectors
    assert len(selectors) == len(set(selectors))
    ignored = []
    for index, match in enumerate(starts):
        end = starts[index+1].start() if index+1 < len(starts) else raw.rindex('test result:')
        captured = raw[match.end():end].strip()
        if match[1] in EXISTING_IGNORES:
            assert captured.startswith('ignored, '), (match[1], captured)
            ignored.append(match[1])
        else:
            assert re.search(r'(?:^|\s)ok$', captured), (match[1], captured)
    passed = len(selectors) - len(ignored)
    assert set(ignored) == EXISTING_IGNORES
    assert f'test result: ok. {passed} passed; 0 failed; {len(ignored)} ignored;' in raw
    return dict(passed=passed, failed=0, ignored=len(ignored), ignored_names=ignored)
