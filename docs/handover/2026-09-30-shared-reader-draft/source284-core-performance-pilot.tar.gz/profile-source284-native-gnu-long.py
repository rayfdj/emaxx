from pathlib import Path
import hashlib
import json
import os
import runpy
import signal
import subprocess
import threading
import time

p = Path(__file__).parent.resolve()
root = p.parents[2]
gnu = p.parent / 'rebuilt-2026-10-01/emacs'
selected = p.parent / 'recovered-2026-10-03/reader-bounds-ascii/emaxx'
out = p / 'source284-native-gnu-long-profile'
out.mkdir(exist_ok=False)
read = lambda f: json.loads(f.read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
module = runpy.run_path(str(root / 'tools/core_runtime_perf.py'), run_name='profile_only')
contract = read(root / 'compat/core_runtime_perf.json')
cases = {c['id']: c for c in contract['cases']}
assert read(p / 'source284-performance-result.json')['status'] == 'performance pilot processes complete; raw audit required'
assert read(p / 'source284-performance-pilot-audit.json')['status'] == 'all 32 pilot processes and16 paired results/modes verified'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == read(p / 'source284-applied-commit.json')['commit']
binaries = {'oracle': gnu / 'src/emacs'}
inputs = {str(f): sha(f) for f in [Path(__file__), root / 'tools/core_runtime_perf.py', root / 'compat/core_runtime_perf.json', root / 'compat/core_runtime_perf.el']}
for runner, binary in binaries.items():
    for f in (binary, binary.with_suffix('.pdmp'), p / 'source284-core-native' / runner / 'comp-test-funcs.eln'):
        inputs[str(f)] = sha(f)
results = []
for name in ('bytecode-to-native',):
    case = cases[name]
    for runner, binary in binaries.items():
        location = out / name / runner
        location.mkdir(parents=True)
        report_path = location / 'report.json'
        native = p / 'source284-core-native' / runner / 'comp-test-funcs.eln'
        # Profiling only: repeat the exact locked-size body80 times for sample visibility.
        # This is deliberately excluded from the uninstrumented pilot timings.
        expression = f'(progn (message "CORE-PROFILE-START") (core-perf-run {module["lisp"](name)} {case["n"]} 0 80 {module["lisp"](gnu)} {module["lisp"](native)} {module["lisp"](report_path)}))'
        command = module['command'](binary, gnu) + ['-l', str(root / 'compat/core_runtime_perf.el'), '--eval', expression]
        environment = module['environment'](location / 'environment', gnu)
        started, epoch = time.monotonic(), time.time()
        outcome = {}
        with (location / 'stdout.txt').open('xb') as stdout, (location / 'stderr.txt').open('xb') as stderr:
            process = subprocess.Popen(command, cwd=root, env=environment, stdin=subprocess.DEVNULL,
                                       stdout=stdout, stderr=stderr, start_new_session=True)

            def reap():
                _, status, usage = os.wait4(process.pid, 0)
                process.returncode = os.waitstatus_to_exitcode(status)
                outcome.update(exit=process.returncode, total_seconds=time.monotonic() - started,
                               user_seconds=usage.ru_utime, system_seconds=usage.ru_stime,
                               peak_rss_bytes=int(usage.ru_maxrss))

            waiter = threading.Thread(target=reap)
            waiter.start()
            while 'CORE-PROFILE-START' not in (location / 'stderr.txt').read_text() and waiter.is_alive() and time.monotonic() - started < 20:
                time.sleep(0.02)
            sample_command = ['/usr/bin/sample', str(process.pid), '2', '1', '-mayDie', '-file', str(location / 'sample.txt')]
            sampled = subprocess.run(sample_command, capture_output=True, text=True, timeout=30)
            (location / 'sample.stdout').write_text(sampled.stdout)
            (location / 'sample.stderr').write_text(sampled.stderr)
            waiter.join(120)
            timed_out = waiter.is_alive()
            if timed_out:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                waiter.join()
        text = (location / 'stdout.txt').read_text()
        ready = [line for line in text.splitlines() if line.startswith('CORE-PERF-READY ')]
        process_record = dict(command=command, pid=process.pid, timeout=timed_out,
                              startup_seconds=float(ready[0].split()[1]) - epoch if len(ready) == 1 else None,
                              profile_command=sample_command, profile_exit=sampled.returncode,
                              environment={k: environment[k] for k in ('HOME', 'LANG', 'LC_ALL', 'TZ', 'EMACS_TEST_DIRECTORY')}, **outcome)
        (location / 'process.json').write_text(json.dumps(process_record, indent=2))
        try:
            report = read(report_path)
            observations = module['validate_report'](report, process_record, case, contract, text, 0, 80)
            assert sampled.returncode == 0 and (location / 'sample.txt').is_file()
            result = dict(case=name, runner=runner, validation='completed', samples=len(observations),
                          result=observations[0]['result'], modes=report['modes'], profile_sha256=sha(location / 'sample.txt'))
        except Exception as error:
            result = dict(case=name, runner=runner, validation='failed', error=repr(error))
        results.append(result)
        (location / 'validation.json').write_text(json.dumps(result, indent=2))
        print(json.dumps(result), flush=True)
assert all(sha(Path(n)) == h for n, h in inputs.items())
assert len(results) == 1
raw = (out / 'bytecode-to-native/oracle/sample.txt').read_text()
assert raw.split('Call graph:',1)[1].split('Total number in stack',1)[0].strip(), 'empty profile call graph'
record = dict(results=results, inputs=inputs, inputs_unchanged=True,
              qualification='Initial GNU native profile had an empty call graph despite successful workload and sampler exits; this bounded successor retains the original and requires actual stacks. Separate2-second macOS sample profiles at1ms intervals, GNU-only successor running80 repetitions of the unchanged locked-size body. Instrumented durations are not performance evidence. All raw reports, process outcomes and sample trees are retained; no local full-validation job ran concurrently.', goal_complete=False)
with (p / 'source284-native-gnu-long-profile-result.json').open('x') as f:
    json.dump(record, f, indent=2)
raise SystemExit(0 if all(r['validation'] == 'completed' for r in results) else 1)
