from pathlib import Path
import ast
import gzip
import hashlib
import io
import json
import runpy
import tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = p / 'source284-publication-stage'
out.mkdir(exist_ok=True)
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
audit = read(p / 'source284-performance-pilot-audit.json')
assert audit['status'] == 'all 32 pilot processes and16 paired results/modes verified'
assert all(sha(Path(n).read_bytes()) == h for n, h in audit['evidence_files'].items())
module = runpy.run_path(str(root / 'tools/core_runtime_perf.py'), run_name='profile_audit_only')
contract = read(root / 'compat/core_runtime_perf.json')
cases = {c['id']: c for c in contract['cases']}
profile_rows = []
for base, samples in [('source284-call-profiles', 20), ('source284-native-gnu-long-profile', 80)]:
    for location in sorted((p / base).glob('*/*')):
        if not location.is_dir():
            continue
        report = read(location / 'report.json')
        process = read(location / 'process.json')
        observations = module['validate_report'](report, process, cases[location.parent.name], contract,
                                                (location / 'stdout.txt').read_text(), 0, samples)
        assert all(row['result'] == cases[location.parent.name]['result'] for row in observations)
        sample = (location / 'sample.txt').read_text()
        stack_text = sample.split('Call graph:', 1)[1].split('Total number in stack', 1)[0].strip()
        populated = bool(stack_text)
        assert populated or (base == 'source284-call-profiles' and location.parent.name == 'bytecode-to-native' and location.name == 'oracle')
        profile_rows.append(dict(directory=str(location.relative_to(p)), checked_samples=samples,
                                 result=observations[0]['result'], modes=report['modes'],
                                 call_graph_populated=populated, sample_sha256=sha(sample.encode())))
assert len(profile_rows) == 5 and sum(row['call_graph_populated'] for row in profile_rows) == 4
for name in ('source284-call-profile-result.json', 'source284-native-gnu-long-profile-result.json'):
    result = read(p / name)
    assert result['inputs_unchanged'] and all(sha(Path(n).read_bytes()) == h for n, h in result['inputs'].items())
files = {}
allowed = {'.json', '.txt', '.py', '.el', '.patch', '.log', '.stdout', '.stderr'}
for base in ('source284-core-native', 'source284-core-pilot-all', 'source284-call-profiles', 'source284-native-gnu-long-profile'):
    for f in (p / base).rglob('*'):
        if f.is_file() and f.suffix in allowed:
            files[str(f.relative_to(p))] = f
for f in p.iterdir():
    if f.is_file() and f.suffix in allowed and (
            f.name.startswith(('source284-performance-', 'source284-call-profile-', 'source284-native-gnu-long-profile-'))
            or f.name in ('run-source284-performance-pilot.py', 'audit-source284-performance-pilot.py',
                          'profile-source284-calls.py', 'profile-source284-native-gnu-long.py',
                          'package-source196-failure-and197-results.py', Path(__file__).name)):
        files[f.name] = f
scope = dict(status='diagnostic pilot complete; GNU parity not satisfied', audit=audit, profiles=profile_rows,
             dependencies=['source284-reader-printer-selected'],
             qualification=(
                 'All16 locked workloads and32 ordinary processes completed with equal actual results and modes. '
                 'One sample per editor/workload gives a3.0547 geometric mean Emaxx/GNU time ratio, range1.0942 to9.5751; '
                 'these are diagnostic samples, not resolved confidence intervals. Emaxx allocation counters report unavailable, not zero. '
                 'All work sizes, modes, timeout600 and tolerance1.03 are unchanged. Native preparation used identical upstream source bytes and each editor own artifact. '
                 'Profiling followed timing with no concurrent local validation. Four original20-repeat profile workloads pass, but the first GNU native sample has no stacks '
                 'despite sampler exit0; it is not usable profile evidence. A GNU-only80-repeat successor captures actual stacks and passes every original result/mode check. '
                 'Profile durations are excluded from timing evidence. CPU samples identify VM dispatch, closure setup, function lookup/backtrace and native entry bookkeeping '
                 'as candidate costs, not proof that any can be removed without semantics/ownership work. Full validation, physical counters, calibrated repeated timing, '
                 'remaining architecture and adversarial review remain open.'), goal_complete=False)
package('source284-core-performance-pilot', files, scope)
