from pathlib import Path
import hashlib
import json
import math
import runpy

p = Path(__file__).parent.resolve()
root = p.parents[2]
directory = p / 'source284-core-pilot-all'
read = lambda f: json.loads(f.read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
module = runpy.run_path(str(root / 'tools/core_runtime_perf.py'), run_name='audit_only')
state = read(p / 'source284-performance-result.json')
assert state['status'] == 'performance pilot processes complete; raw audit required'
assert all(r['exit_code'] == 0 and r['source_unchanged'] and r['measurement_inputs_unchanged'] for r in state['results'])
contract = read(directory / 'contract.json')
assert contract == read(root / 'compat/core_runtime_perf.json')
assert len(contract['cases']) == 16 and contract['parity_ratio_limit'] == 1.03
provenance = read(directory / 'provenance.json')
assert provenance['source_commit'] == state['source_commit'] == read(p / 'source284-applied-commit.json')['commit']
assert provenance['source_status'] == '' and provenance['frozen_oracle_identity']
assert all(sha(Path(n)) == h for n, h in provenance['input_sha256'].items())
assert read(directory / 'final-inputs.json') == dict(unchanged=True, input_sha256=provenance['input_sha256'])
cases = {c['id']: c for c in contract['cases']}
records = read(directory / 'runs.json')
assert len(records) == 32
assert {(r['round'], r['runner'], r['case_id']) for r in records} == {(0, runner, name) for runner in ('oracle', 'emaxx') for name in cases}
rows = []
evidence = {}
for case in contract['cases']:
    paired = {}
    for runner in ('oracle', 'emaxx'):
        location = directory / 'round-00' / case['id'] / runner
        record = read(location / 'validation.json')
        assert record == next(r for r in records if r['case_id'] == case['id'] and r['runner'] == runner)
        process = read(location / 'process.json')
        report = read(location / 'report.json')
        observations = module['validate_report'](report, process, case, contract, (location / 'stdout.txt').read_text(), 0, 1)
        assert record['validation'] == 'completed' and record['process'] == process and record['observations'] == observations
        assert report['modes'] == record['modes'] == case['modes']
        assert len(observations) == 1 and observations[0]['result'] == case['result']
        paired[runner] = dict(seconds=observations[0]['seconds'], result=observations[0]['result'],
                              modes=report['modes'], gc_count=observations[0]['gc_count'],
                              startup_seconds=process['startup_seconds'], total_seconds=process['total_seconds'],
                              peak_rss_bytes=process['peak_rss_bytes'], allocation_before=observations[0]['allocation_before'],
                              allocation_after=observations[0]['allocation_after'])
        for file in location.iterdir():
            if file.is_file():
                evidence[str(file)] = sha(file)
    assert paired['oracle']['result'] == paired['emaxx']['result'] and paired['oracle']['modes'] == paired['emaxx']['modes']
    rows.append(dict(case=case['id'], ratio=paired['emaxx']['seconds'] / paired['oracle']['seconds'], **paired))
summary = read(directory / 'summary.json')
recomputed = module['summarize'](records, contract['cases'], dict(contract, rounds=1), ['oracle', 'emaxx'], False, False)
recomputed.update(action='pilot', certification_eligible=False, inputs_unchanged=True)
assert recomputed == summary
assert summary['complete_inventory'] and not summary['criterion_satisfied']
assert all(r['long_enough'] and r['same_modes'] and not r['allocation_counters_available'] for r in summary['cases'])
record = dict(status='all 32 pilot processes and16 paired results/modes verified', source_commit=state['source_commit'],
              geometric_mean_ratio=summary['geometric_mean_ratio'], cases=rows, evidence_files=evidence,
              qualification='One paired sample per locked workload; diagnostic timings, not a confidence interval or parity certification. Every Emaxx result equals the actual GNU result and locked expected value; modes match. GNU identity and all measured inputs match their recorded hashes. All bodies exceed100ms. Emaxx allocation counters explicitly report unavailable; physical accounting remains incomplete. No compiler, local validation or profiling job ran concurrently. Required repeated calibrated measurement and broader correctness/architecture remain open.',
              goal_complete=False)
with (p / 'source284-performance-pilot-audit.json').open('x') as f:
    json.dump(record, f, indent=2)
print(json.dumps(dict(status=record['status'], geometric_mean_ratio=record['geometric_mean_ratio'],
                      ratios={r['case']: round(r['ratio'], 4) for r in rows}), indent=2))
