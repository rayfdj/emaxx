from pathlib import Path
import hashlib,json,os,subprocess,sys,time

p=Path(__file__).parent.resolve();root=p.parents[2]
c=p.parent/'recovered-2026-10-03/reader-bounds-ascii/emaxx';g=p.parent/'rebuilt-2026-10-01/emacs'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();read=lambda n:json.loads((p/n).read_text())
head=read('source284-applied-commit.json')['commit'];manifest=read('source284-manifest.json')
assert read('source284-selected-audit.json')['status']=='passed'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
assert all(sha(root/n)==sha(c/n)==h for n,h in manifest.items())
binary=c/'target/reader-character-validation/release/emaxx'
for n,r in read('source284-ordinary-artifacts.json').items():assert sha(Path(n))==r['sha256']
native=p/'source284-core-native';pilot=p/'source284-core-pilot-all'
assert not native.exists() and not pilot.exists()
measurement_inputs={str(root/n):sha(root/n) for n in ['tools/core_runtime_perf.py','compat/core_runtime_perf.json','compat/core_runtime_perf.el']}
state=dict(status='starting performance preparation',source_commit=head,source_manifest='source284-manifest.json',measurement_inputs=measurement_inputs,results=[],goal_complete=False)
def save_state():(p/'source284-performance-state.json').write_text(json.dumps(state,indent=2)+'\n')
def run(stage,args):
    command=[sys.executable,'-B','tools/core_runtime_perf.py',*args,'--source',str(g),'--oracle',str(g/'src/emacs'),'--emaxx',str(binary),'--diagnostic']
    record=dict(command=command,working_directory=str(root),source_commit=head,qualification='Unchanged locked16 workloads/sizes/modes; one-round pilot is diagnostic, not parity certification. No local validation/build/profiling job runs concurrently.')
    with (p/('source284-performance-'+stage+'-command.json')).open('x') as f:json.dump(record,f,indent=2)
    state.update(status='running '+stage);save_state();start=time.monotonic()
    with (p/('source284-performance-'+stage+'.log')).open('xb') as log:
        r=subprocess.run(command,cwd=root,env=dict(os.environ,LANG='C',LC_ALL='C'),stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
    result=dict(stage=stage,exit_code=r.returncode,elapsed_seconds=time.monotonic()-start,source_unchanged=all(sha(c/n)==h for n,h in manifest.items()),measurement_inputs_unchanged=all(sha(Path(n))==h for n,h in measurement_inputs.items()))
    with (p/('source284-performance-'+stage+'-result.json')).open('x') as f:json.dump(result,f,indent=2)
    state['results'].append(result);save_state();print(json.dumps(result),flush=True);return result
try:
    prep=run('prepare',['prepare','--output',str(native)])
    assert prep['exit_code']==0 and prep['source_unchanged'] and prep['measurement_inputs_unchanged']
    result=run('pilot',['pilot','--pilot-runner','both','--native-dir',str(native),'--output',str(pilot)])
    assert result['source_unchanged'] and result['measurement_inputs_unchanged']
    state['status']='performance pilot processes complete; raw audit required'
except Exception as error:state.update(status='performance preparation or runner failed',error=repr(error))
finally:
    save_state()
    with (p/'source284-performance-result.json').open('x') as f:json.dump(state,f,indent=2)
print(json.dumps(state),flush=True)
sys.exit(0 if state['status']=='performance pilot processes complete; raw audit required' else 1)
