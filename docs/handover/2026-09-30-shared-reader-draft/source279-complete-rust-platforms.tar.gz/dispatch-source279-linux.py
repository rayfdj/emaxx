from pathlib import Path
import json, re, subprocess

p=Path(__file__).parent.resolve()
root=p.parents[2]
head=json.loads((p/'source279-applied-commit.json').read_text())['commit']
def save(name,value):
    with (p/name).open('x') as f:json.dump(value,f,indent=2)
assert json.loads((p/'source279-applied-push.json').read_text())['exit_code']==0
assert subprocess.check_output(['git','ls-remote','--heads','origin','refs/heads/runtime-char-tables'],cwd=root,text=True).split()[0]==head
launches=[]
for validation in ['rust','frozen']:
    command=['gh','workflow','run','frozen-run.yml','--repo','rayfdj/emaxx','--ref','runtime-char-tables','-f','validation='+validation]
    result=subprocess.run(command,cwd=root,stdin=subprocess.DEVNULL,capture_output=True,text=True)
    prefix='source279-linux-'+validation
    save(prefix+'-dispatch.json',dict(command=command,commit=head,exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr))
    result.check_returncode()
    match=re.fullmatch(r'https://github.com/rayfdj/emaxx/actions/runs/(\d+)\s*',result.stdout)
    assert match,result.stdout
    run_id=int(match[1])
    state=json.loads(subprocess.check_output(['gh','run','view',str(run_id),'--repo','rayfdj/emaxx','--json','status,conclusion,headSha,url'],cwd=root,text=True))
    assert state['headSha']==head
    launch=dict(run_id=run_id,state=state,source_commit=head,runtime_source='source279',
                qualification='Exact pushed source279 pooled-string/error-recovery checkpoint. Requires audited511 inputs, zero-warning strict checks,211 focused passes/two existing ignores and1067 affected passes in both profiles, plus37 ordinary GNU comparisons. Preserves source278 three-abort negative and unexplained source276 broad Emaxx census failure. No full-platform, process-wide OOM, ownership/accounting or performance completion is inferred from dispatch.')
    save(prefix+'-launch.json',launch)
    launches.append(launch)
print(json.dumps(launches))
