from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve();root=p.parents[2]
out=root/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda name:json.loads((p/name).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
allowed={'.json','.log','.txt','.py','.h','.el','.expected','.stdout','.stderr','.patch'}
def include_tree(files,name):
    for file in (p/name).rglob('*'):
        if file.is_file() and (file.suffix in allowed or file.name=='Makefile'):
            assert not file.is_symlink()
            files[str(file.relative_to(p))]=file
def add(files,names):
    for name in names:
        assert (p/name).is_file(),name
        files[name]=p/name
common=['source279-manifest.json','package-source196-failure-and197-results.py',Path(__file__).name]
mac,linux=[read('source279-'+platform+'-rust-audit.json') for platform in ['macos','linux']]
assert mac['status']==linux['status']=='passed'
assert mac['total_passed']==3126 and linux['total_passed']==3138
assert mac['library_ignored']==linux['library_ignored']==2
files={}
for name in ['full-gate-source279','source279-linux-rust-artifacts','source279-full-retained-gnu']:
    include_tree(files,name)
for f in p.iterdir():
    if f.is_file() and f.suffix in allowed and f.name.startswith(('source279-linux-rust-','source279-macos-rust-','source279-full-rust')):
        files[f.name]=f
add(files,common+['source279-full-checkout.json','source279-full-launch.json','queue-source279-full-macos.py','source279-full-oracle-capture-command.json','source279-full-oracle-capture-result.json','retain-source279-linux.py','verify-source279-macos-rust.py','verify-source279-linux-rust.py','audit-source279-macos-rust-names.py','audit-source279-linux-rust-names.py','audit-source279-macos-gnu-inputs.py','dispatch-source279-linux.py','source279-linux-retention-preparation.json','source279-linux-audit-preparation.json'])
package('source279-complete-rust-platforms',files,dict(macos=mac,linux=linux,qualification='Exact applied source279 d64040a7 passes full Rust validation:3126 macOS/3138 Linux, two existing ignores each. All3029/3037 library names, native artifact identity and retained GNU/Rust inputs are verified. Earlier failed runs remain failed. This does not certify the separately frozen printer draft, all correctness, architecture or performance. Current macOS frozen/terminal are separate.',goal_complete=False))
frozen=read('source279-linux-frozen-complete-audit.json')
assert frozen['verified_files']==519 and frozen['verified_outcomes']==7928 and frozen['successful_processes']==1038
files={};include_tree(files,'source279-linux-frozen-artifacts')
for f in p.iterdir():
    if f.is_file() and f.suffix in allowed and f.name.startswith('source279-linux-frozen-'):files[f.name]=f
add(files,common+['retain-source279-linux.py','audit-source279-frozen.py','verify-complete-frozen-receipts279.py','dispatch-source279-linux.py','source279-linux-audit-preparation.json'])
reports=list((p/'source279-linux-frozen-artifacts').rglob('eglot-tests.compat/oracle.json'))
assert len(reports)==1
eglot={}
for editor in ['oracle','emaxx']:
    report=json.loads((reports[0].parent/(editor+'.json')).read_text())
    row=next(row for row in report['results'] if row['name']=='eglot-test-rust-completion-exit-function')
    assert row['status']=='passed' and row['expected']
    eglot[editor]=row
package('source279-complete-linux-frozen',files,dict(frozen=frozen,raw_integrity=read('source279-linux-frozen-raw-integrity-audit.json'),eglot=eglot,qualification='All519 files,7928 paired outcomes and1038 processes verified against the unchanged Linux inventory and exact GNU pin. Both editors report7670 passes,47 expected failures and211 skips. The Eglot case completes and passes all original assertions in both editors; this new pass does not erase or explain the earlier GNU timeout. The separate user-authorized macOS retry additionally captures identical actual final buffer bytes. No performance or universal no-cheating claim.',goal_complete=False))
draft=read('source281-freeze-and-ordinary-bounded-audit.json')
closed=read('source281-closed-partial-audit.json')
assert draft['source_inputs']==514 and draft['generated_rows']==198
assert closed['status']=='closed incomplete candidate; do not apply'
replay=read('source281-five-sockets-permitted-result.json')
assert replay['exit_code']==0 and replay['source_unchanged'] and replay['binary_unchanged']
assert 'test result: ok. 5 passed; 0 failed; 0 ignored;' in (p/'source281-five-sockets-permitted.log').read_text()
files={f.name:f for f in p.iterdir() if f.is_file() and f.suffix in allowed and f.name.startswith(('source280-','source281-','source279-printer-streams-negative','printer-varied-v3','printer-native-literals'))}
add(files,common+['draft-source280-printer.py','draft-source280-printer-destinations.py','run-source280-printer-checks.py','run-source281-printer-checks.py','build-source281-printer-ordinary.py','compare-printer-character-fixtures.py','compare-source281-generated-loaded.py','probe-printer-native-literals.py','freeze-source281-printer.py','freeze-source281-printer-bounded.py','audit-source281-closed-partial.py','replay-source281-socket-permitted.py','replay-source281-five-sockets-permitted.py','queue-source281-printer-selected.py','launch-source281-selected.py','run-printer-characters-focused.py','audit-printer-characters-focused.py','test-printer-characters-broad.py','run-printer-characters-release.py','audit-printer-characters-release.py'])
c=p.parent/'recovered-2026-09-30/string-print-decoder/emaxx'
for name in ['printer-full-range-streams.el','printer-full-range-streams.expected']:files['fixtures/'+name]=c/'tests/fixtures'/name
package('source281-canonical-printer-unfinished',files,dict(bounded=draft,closed_partial=closed,permitted_five_socket_replay=replay,dependencies=['source279-string-allocation-selected','source279-varied-output-and-eglot-retry'],qualification='UNAPPLIED and incomplete. Both280/281 replay514 input bytes/modes from d64040a7 and main21d20f0e.280 compiler error remains;281 strict checks and one stream control pass.37 prior ordinary outputs,one new stream fixture and all198 generated rows match GNU. Empty-output --eval invocation is invalid coverage and retained; whole-file successor produces4088269 exact bytes. Native constant probe still fails:279 compiler error,281 corrupted reloaded codes. Focused214 passes/one socket-permission failure/two ignores; affected690 passes/five socket-permission failures before withdrawal,one interrupted and375 unrun; release never started. Exact same-binary permitted socket replays pass,without recategorizing incomplete suites. Supervisor85186 withdrawn. Applied runtime279 and main unchanged; full goal incomplete.',goal_complete=False))
