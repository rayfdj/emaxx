from pathlib import Path
import hashlib
import json
import subprocess
import sys
import zipfile

p = Path(__file__).parent.resolve()
mode = sys.argv[1]
assert mode in ['rust', 'frozen']
prefix = 'source279-linux-' + mode
launch = json.loads((p / (prefix + '-launch.json')).read_text())
run_id = launch['run_id']
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def save(suffix, value):
    with (p / (prefix + '-' + suffix + '.json')).open('x') as stream:
        json.dump(value, stream, indent=2)


state_command = ['gh', 'run', 'view', str(run_id), '--repo', 'rayfdj/emaxx',
                 '--json', 'status,conclusion,headSha,url']
state = json.loads(subprocess.check_output(state_command))
assert state['status'] == 'completed', 'Run still active; no closed evidence is written'
assert state['headSha'] == launch['source_commit'] == 'd64040a7efe9a5039750b7c0b8feb7796c57fe79'
save('final-state', state)
listing_command = ['gh', 'api', 'repos/rayfdj/emaxx/actions/runs/' + str(run_id) + '/artifacts']
listing = json.loads(subprocess.check_output(listing_command))
save('artifact-listing', dict(command=listing_command, response=listing))
artifacts = [row for row in listing['artifacts'] if row['name'] == 'ordinary-linux-' + state['headSha']]
assert len(artifacts) == 1 and not artifacts[0]['expired'], 'Expected retained artifact is absent or ambiguous'
artifact = artifacts[0]
assert artifact['workflow_run']['id'] == run_id and artifact['workflow_run']['head_sha'] == state['headSha']
archive = p / (prefix + '-artifact.zip')
command = ['gh', 'api', 'repos/rayfdj/emaxx/actions/artifacts/' + str(artifact['id']) + '/zip']
save('download-command', dict(state_command=state_command, archive_command=command,
                             helper_sha256=sha(Path(__file__))))
with archive.open('xb') as output:
    subprocess.run(command, stdin=subprocess.DEVNULL, stdout=output, check=True)
root = p / (prefix + '-artifacts')
root.mkdir()
files = {}
with zipfile.ZipFile(archive) as source:
    for entry in source.infolist():
        if entry.is_dir():
            continue
        relative = Path(entry.filename)
        assert not relative.is_absolute() and '..' not in relative.parts
        assert entry.filename not in files
        assert (entry.external_attr >> 16) & 0o170000 != 0o120000, 'Unexpected symbolic-link entry'
        data = source.read(entry)
        destination = root / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open('xb') as output:
            output.write(data)
        digest = hashlib.sha256(data).hexdigest()
        assert sha(destination) == digest
        files[entry.filename] = digest
assert set(files) == {str(path.relative_to(root)) for path in root.rglob('*') if path.is_file()}
save('download', dict(archive_sha256=sha(archive), files=files, artifact_id=artifact['id'],
                     run_id=run_id, conclusion=state['conclusion'],
                     qualification='All downloaded/extracted bytes agree. A successful download is not a passing validation result. Failed run conclusions remain failed.'))
log_command = ['gh', 'run', 'view', str(run_id), '--repo', 'rayfdj/emaxx', '--log']
with (p / (prefix + '-workflow.log')).open('xb') as output:
    subprocess.run(log_command, stdin=subprocess.DEVNULL, stdout=output, check=True)
oracle = root / 'oracle-inputs'
if (oracle / 'manifest.json').is_file() and (oracle / 'verification.json').is_file():
    manifest = json.loads((oracle / 'manifest.json').read_text())
    verification = json.loads((oracle / 'verification.json').read_text())
    assert manifest['status'] == 'captured' and manifest['source_tracked_changes'] == []
    assert manifest['source_commit'] == '636f166cfc86aa90d63f592fd99f3fdd9ef95ebd'
    assert {row['artifact'] for row in manifest['files']} == {'emacs', 'emacs.pdmp', 'config.h', 'Makefile'}
    for row in manifest['files']:
        path = oracle / row['artifact']
        assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256']
    assert verification['status'] == 'unchanged' and verification['files_verified'] == 4
    assert verification['capture_manifest_sha256'] == sha(oracle / 'manifest.json')
    save('oracle-audit', dict(status='retained GNU inputs verified', run_id=run_id,
                            files_verified=4, files=manifest['files'], source_commit=manifest['source_commit'],
                            verification=verification))
print(json.dumps(dict(run_id=run_id, conclusion=state['conclusion'], archive_sha256=sha(archive),
                      extracted_files=len(files), qualification='Raw validation verdicts still require audit.')))
