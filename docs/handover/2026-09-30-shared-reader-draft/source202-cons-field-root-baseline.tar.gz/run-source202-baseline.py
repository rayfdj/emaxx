from pathlib import Path
import json,os,subprocess,sys,time
p=Path(__file__).parent.resolve()
root=p.parent/'recovered-2026-09-30/cons-roots/emaxx'
command=['cargo','clean','-p','emaxx','--profile','gate']
env={**os.environ,'CARGO_TARGET_DIR':str(root/'target/frame-validation')}
r=subprocess.run(command,cwd=root,env=env,capture_output=True,text=True)
with (p/'source202-clean-result.json').open('x') as f:json.dump(dict(command=command,exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr),f,indent=2)
if r.returncode:sys.exit(r.returncode)
r=subprocess.run([sys.executable,str(p/'test-cons202.py'),'202','gate'],stdin=subprocess.DEVNULL)
with (p/'source202-baseline-result.json').open('x') as f:json.dump(dict(exit_code=r.returncode,completed_unix=time.time(),qualification='New architectural controls against source201 runtime. Failure is expected and must be checked against raw verdicts.'),f,indent=2)
sys.exit(r.returncode)
