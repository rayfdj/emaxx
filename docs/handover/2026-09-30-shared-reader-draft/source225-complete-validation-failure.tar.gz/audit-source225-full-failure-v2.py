from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/string-bytes/emaxx'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read('source225-manifest.json')
assert len(manifest) == 427 and all(sha(root / name) == digest for name, digest in manifest.items())
processes = subprocess.run(['ps', '-p', '82034,82035', '-o', 'pid=,ppid=,stat=,command='], capture_output=True, text=True)
assert processes.returncode == 1 and not processes.stdout.strip()
full = p / 'full-gate-source225'
summary = read('full-gate-source225/summary.json')
outcome = read('source225-full-gate-result.json')
group = read('full-gate-source225/repeat-01-eval_01.json')
assert outcome['exit_code'] == 1 and outcome['source_unchanged']
assert summary['status'] == 'failed' and summary['cargo_stages'] == [] and summary['runs'] == []
assert group['exit_code'] == -6 and not group['timed_out'] and group['expected_tests'] == 386
assert sha(Path(outcome['immutable_binary']['path'])) == summary['test_binary']['sha256']
inventory = [line[:-6] for line in (full / 'inventory.txt').read_text().splitlines() if line.endswith(': test')]
raw = (full / 'repeat-01-eval_01.log').read_text()
starts = list(re.finditer(r'^test (\S+) \.\.\. ', raw, re.M))
names = [match[1] for match in starts]
assert names == [name for name in inventory if name.startswith('lisp::eval::tests::eval_01::')][:len(names)]
assert names[-1] == 'lisp::eval::tests::eval_01::file_remote_p_parses_tramp_style_names'
for index, item in enumerate(starts[:-1]):
    assert re.search(r'(?:^|\s)ok$', raw[item.end():starts[index + 1].start()].strip())
assert 'string constructor must supply valid Lisp characters: Signal("unibyte string holds character 0x5bc6, not a byte")' in raw
assert 'test result:' not in raw
tty = read('source225-full-ttydiff-result.json')
assert tty['exit_code'] == 1 and tty['source_unchanged'] and tty['inputs_unchanged']
assert tty['expected_scenarios'] == 226 and tty['started_scenarios'] == 8
tty_log = (p / 'source225-full-ttydiff.log').read_text()
assert len(re.findall(r'^MATCH \[', tty_log, re.M)) == 7
assert 'RUN [8/226] org-open' in tty_log and 'anic. aborting.' in tty_log
retained = p / 'source225-full-failure-inputs'
retained.mkdir()
files = []
sources = [Path(outcome['immutable_binary']['path']), *sorted((root / 'target/grouped-gate/fixture-images').glob('loadup-39f62a62-*.pdmp'))]
assert len(sources) == 2
for source in sources:
    target = retained / source.name
    digest = sha(source)
    shutil.copy2(source, target)
    assert sha(source) == sha(target) == digest
    files.append(dict(original=str(source), retained=str(target), sha256=digest, bytes=target.stat().st_size))
for name, digest in read('source225-full-ttydiff-command.json')['inputs'].items():
    assert sha(Path(name)) == digest
record = dict(status='both complete runs failed', goal_complete=False, inputs_verified=427,
              rust=dict(passed_before_abort=len(names) - 1, aborted_test=names[-1], raw_exit=-6, scheduled_first_group=386,
                        unstarted_first_group=386 - len(names), later_groups_and_cargo_stages='not executed'),
              terminal=dict(matched_scenarios=7, aborted_scenario='org-open', unstarted_scenarios=218),
              retained_files=files, ordinary_artifacts=read('source225-ordinary-artifacts.json'),
              supervisors_exited=[82034, 82035],
              diagnosis='The full Rust trace reaches try_completion from native regexp-opt-group and panics while encoding U+5BC6 into a result incorrectly marked unibyte. The terminal failure is a native regexp-opt-group non-unwinding panic; its screen capture does not preserve the original panic message. No full validation, Linux run or runtime publication is claimed.')
with (p / 'source225-full-failure-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: value for key, value in record.items() if key not in ['retained_files', 'ordinary_artifacts']}, indent=2))
