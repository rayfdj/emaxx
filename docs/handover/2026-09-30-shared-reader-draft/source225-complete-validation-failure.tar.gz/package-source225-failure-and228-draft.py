from pathlib import Path
import ast
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected'}
audit = read('source225-full-failure-audit.json')
assert audit['rust']['passed_before_abort'] == 161 and audit['terminal']['matched_scenarios'] == 7
files = {f.name: f for f in p.iterdir() if f.is_file() and f.suffix in allowed
         and f.name.startswith(('source225-full-', 'completion-result-storage-'))}
full = p / 'full-gate-source225'
files.update({str(f.relative_to(p)): f for f in full.rglob('*') if f.is_file() and f.suffix in allowed})
helpers = ['source225-complete-validation-launch.json', 'source225-manifest.json',
           'source225-complete.patch', 'source225-ordinary-artifacts.json',
           'completion-result-storage.el', 'audit-source225-full-failure.py',
           'audit-source225-full-failure-v2.py', 'run-source225-full-gate.py',
           'run-source225-full-tty.py', Path(__file__).name]
files.update({name: p / name for name in helpers})
package('source225-complete-validation-failure', files, audit)

manifest = read('source228-manifest.json')
candidate = p.parent / 'recovered-2026-09-30/string-bytes/emaxx'
assert len(manifest) == 429 and all(sha((candidate / name).read_bytes()) == digest for name, digest in manifest.items())
names = [
    'source228-launch.json', 'source226-through228-patch-replay-and-modes-audit.json',
    'audit-source226-through228-patches.py', 'freeze-string-candidate.py',
    'run-string-validation228.py', 'test-string-controls228.py', 'test-string-broad219.py',
    'check-string217.py', 'static-string217.py', 'completion-result-storage.el', Path(__file__).name,
]
for number in [226, 227, 228]:
    names += ['source' + str(number) + suffix for suffix in ['-base.json', '-manifest.json', '-complete.patch']]
files = {name: p / name for name in names}
package('source228-completion-storage-draft', files,
        dict(status='isolated completion repair; validation running', source_inputs=429,
             supervisor=read('source228-launch.json')['pid'],
             qualification='GNU minibuf.c Ftry_completion selects a best candidate and returns its substring or the original unchanged input. This draft preserves the chosen encoding, copied properties and extended characters, and removes the obsolete materialized common-prefix helper. Source226 retained that unused helper; source227 accidentally removed the neighboring filter helper too; both are unexecuted drafts. Source228 restores that unchanged neighbor. All three complete patches and file modes replay exactly. This bundle assigns no compiler, runtime, full-platform or performance verdict. Source225 complete failures remain preserved; no draft runtime is published.'))
