from pathlib import Path
import hashlib, json, re, subprocess

p = Path(__file__).parent.resolve()
root = p.parents[2]
c = p.parent / 'recovered-2026-10-05/vm-integer-path/emaxx'
tag = 'source290'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read(tag + '-manifest.json')
prior_manifest = read('source289-manifest.json')
assert len(manifest) == 528 and all(sha(c / name) == digest for name, digest in manifest.items())
assert all(manifest[name] == digest for name, digest in prior_manifest.items() if name.startswith('tests/'))
prior_tests = (p.parent / 'recovered-2026-10-05/vm-call-entry/emaxx/src/lisp/primitives/tests.rs').read_text()
tests, count = re.subn(r'\n#\[test\]\nfn bytecode_integer_boundaries_preserve_gnu_results_types_and_errors\(\) \{\n.*?\n\}\n\Z', '', (c / 'src/lisp/primitives/tests.rs').read_text(), flags=re.S)
assert count == 1 and tests == prior_tests
prior_root = p.parent / 'recovered-2026-10-05/vm-call-entry/emaxx'
prior_vm = (prior_root / 'src/lisp/bytecode/vm.rs').read_text()
current_vm = (c / 'src/lisp/bytecode/vm.rs').read_text()
# All inline VM test modules follow the production dispatch. The only
# setup adjustment replaces the removed infallible wrapper conversion;
# every original assertion and callback remains byte-identical.
prior_tail = prior_vm[prior_vm.index('mod tests {'):]
current_tail = current_vm[current_vm.index('mod tests {'):]
prior_tail = prior_tail.replace('let program = build_activation(&object).expect("decoded program");', 'let program = object.clone();')
assert current_tail == prior_tail
state = read(tag + '-validation-result.json')
assert len(state['results']) == 14
assert all(row['exit_code'] == 0 and not row['timed_out'] and row['source_unchanged'] for row in state['results'])
profiles = {}
new_test = 'lisp::primitives::tests::bytecode_integer_boundaries_preserve_gnu_results_types_and_errors'
selector = r'byte_?code|threads_retain_lexical_caller_roots|native_comp::runtime::|native.*(?:arity|calling|unwind|handler|argument)|numeric|arithmetic|remainder|modulo|bignum|float|integer|fixnum|lisp::types::|lisp::alloc::'
for profile in ('gate', 'release'):
    record = state['profiles'][profile]
    assert record['passed'] == len(record['selectors']) and record['failed'] == record['ignored'] == 0
    inventory = [line[:-6] for line in (p / (tag + '-' + profile + '-inventory.log')).read_text().splitlines() if line.endswith(': test')]
    prior = [line[:-6] for line in (p / ('source289-' + profile + '-inventory.log')).read_text().splitlines() if line.endswith(': test')]
    assert len(inventory) == len(set(inventory)) and set(inventory) == set(prior) | {new_test}
    names = [name for name in inventory if re.search(selector, name)]
    assert names == record['selectors']
    raw = (p / (tag + '-' + profile + '-selected.log')).read_text()
    assert re.findall(r'^test (\S+) \.\.\. ok$', raw, re.M) == names
    assert f'test result: ok. {len(names)} passed; 0 failed; 0 ignored;' in raw
    assert sha(Path(record['binary'])) == sha(Path(record['retained_binary'])) == record['binary_sha256']
    for item in record['retained_inputs']:
        assert sha(Path(item['original'])) == sha(Path(item['retained'])) == item['sha256']
    profiles[profile] = record

ordinary = {}
names = list(read('source289-selected-audit.json')['ordinary_results']) + ['bytecode-integer-boundaries']
assert len(names) == 45
for name in names:
    comparison = read(tag + '-ordinary-' + name + '-comparison.json')
    assert comparison['passed'] and comparison['exact_match']
    outputs, programs = [], []
    for editor in ('gnu', 'emaxx'):
        stem = tag + '-ordinary-' + name + '-' + editor
        command, result = read(stem + '.command.json'), read(stem + '.result.json')
        assert all(sha(Path(path)) == digest for path, digest in command['inputs'].items())
        assert result == comparison['outcomes'][editor]
        assert result['exit_code'] == 0 and not result['timed_out'] and result['source_unchanged'] and result['inputs_unchanged']
        out, err = (p / (stem + '.stdout')).read_bytes(), (p / (stem + '.stderr')).read_bytes()
        assert out and not err and hashlib.sha256(out).hexdigest() == result['stdout_sha256'] and err.hex() == result['stderr_hex']
        assert result['expected_output'] is not False
        if name != 'bytecode-integer-boundaries':
            assert out == (p / ('source289-ordinary-' + name + '-' + editor + '.stdout')).read_bytes()
        else:
            assert out == (c / 'tests/fixtures/bytecode-integer-boundaries.expected').read_bytes().rstrip(b'\n')
        outputs.append(out)
        programs.append(command['command'][-1])
    assert outputs[0] == outputs[1] and programs[0] == programs[1]
    ordinary[name] = dict(passed=True, stdout_sha256=hashlib.sha256(outputs[0]).hexdigest(), stdout_bytes=len(outputs[0]))
assert read(tag + '-generated-loaded-comparison.json')['passed']
for editor in ('gnu', 'emaxx'):
    stem = tag + '-generated-loaded-' + editor
    command, result = read(stem + '-command.json'), read(stem + '-result.json')
    assert all(sha(Path(path)) == digest for path, digest in command['inputs'].items())
    assert result['exit_code'] == 0 and not result['timed_out'] and result['source_unchanged'] and result['inputs_unchanged']
    assert command['command'][-2:] == ['-l', str(p / 'printer-varied-v3-293638f0.el')]
    out = (p / (stem + '.stdout')).read_bytes()
    assert len(out) == 4088269 and len(out.splitlines()) == 198
    assert out == (p / 'printer-varied-v3-gnu.stdout').read_bytes() and not (p / (stem + '.stderr')).read_bytes()
artifacts = read(tag + '-ordinary-artifacts.json')
assert all(sha(Path(path)) == sha(Path(row['immutable_copy'])) == row['sha256'] for path, row in artifacts.items())
for stage in ('fmt', 'check', 'clippy', 'diff', 'ordinary-build', 'gate-build', 'release-build'):
    raw = (p / (tag + '-' + stage + '.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
    for line in raw.splitlines():
        if line.startswith('{'):
            assert json.loads(line).get('message', {}).get('level') not in ('warning', 'error')
portable = read(tag + '-portable-draft-audit.json')
assert len(portable['patches']) == 2
for row in portable['patches']:
    assert row['inputs'] == 528 and row['bytes_and_modes'] == 'exact' and sha(p / row['patch']) == row['sha256']
evidence = {str(path): sha(path) for path in p.glob(tag + '-*') if path.is_file() and path.suffix in ('.json', '.log', '.stdout', '.stderr', '.patch')}
record = dict(status='passed', source_inputs_verified=528, profiles=profiles,
              ordinary_comparisons=46, ordinary_results=ordinary,
              generated_rows=198, generated_bytes=4088269,
              ordinary_artifacts=artifacts, portable_replays=portable['patches'], evidence_files=evidence,
              qualification='Bounded selected validation. All prior tests, assertions and fixtures are preserved. The 588-row added GNU boundary fixture covers arithmetic results, fixnum/bignum types, errors and collection; its actual outputs matched baseline289 before candidate execution. Integer construction uses the same range/tagging and bignum allocation, outlined for inlining. VM results update existing slots and fallback dispatch no longer repeats the same predicates. Complete final validation, physical accounting/ownership and GNU performance acceptance remain open', goal_complete=False)
with (p / (tag + '-selected-audit.json')).open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps(dict(status='passed', source=tag, profiles={k: r['passed'] for k, r in profiles.items()}, ordinary_comparisons=46, source_inputs=528)))
