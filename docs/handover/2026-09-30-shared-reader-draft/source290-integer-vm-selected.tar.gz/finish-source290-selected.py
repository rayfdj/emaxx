from pathlib import Path
import hashlib, json, os, subprocess, sys, time

p = Path(__file__).parent.resolve()
c = p.parent / 'recovered-2026-10-05/vm-integer-path/emaxx'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
fixed = {str(p / name): sha(p / name) for name in (
    'compare-vm-dispatch-fixtures.py', 'compare-source290-generated-loaded.py',
    'audit-source290-selected.py', Path(__file__).name)}
state = dict(status='waiting for source290 validation', fixed_inputs=fixed, results=[], goal_complete=False)

def save():
    (p / 'source290-finish-finish-state.json').write_text(json.dumps(state, indent=2) + '\n')

def wait_for(name, status):
    state['status'] = status
    save()
    while not (p / name).exists():
        print(status, flush=True)
        time.sleep(30)
    return read(name)

def run(stage, command):
    assert all(sha(Path(path)) == digest for path, digest in fixed.items())
    state['status'] = 'running ' + stage
    save()
    started = time.monotonic()
    with (p / ('source290-finish-' + stage + '-command.json')).open('x') as stream:
        json.dump(dict(command=command, working_directory=str(p), fixed_inputs=fixed), stream, indent=2)
    with (p / ('source290-finish-' + stage + '.log')).open('xb') as log:
        result = subprocess.run(command, cwd=p, env=os.environ, stdin=subprocess.DEVNULL,
                                stdout=log, stderr=subprocess.STDOUT)
    record = dict(stage=stage, exit_code=result.returncode, elapsed_seconds=time.monotonic() - started,
                  helpers_unchanged=all(sha(Path(path)) == digest for path, digest in fixed.items()))
    with (p / ('source290-finish-' + stage + '-result.json')).open('x') as stream:
        json.dump(record, stream, indent=2)
    state['results'].append(record)
    save()
    print(json.dumps(record), flush=True)
    assert result.returncode == 0 and record['helpers_unchanged']

try:
    validation = wait_for('source290-validation-result.json', 'waiting for source290 validation')
    assert validation['status'] == 'strict, selected and ordinary build passed; raw audit and ordinary comparisons required'
    names = list(read('source289-selected-audit.json')['ordinary_results']) + ['bytecode-integer-boundaries']
    assert len(names) == 45
    run('source290-ordinary', [sys.executable, '-B', str(p / 'compare-vm-dispatch-fixtures.py'), 'source290', str(c), *names])
    run('source290-generated', [sys.executable, '-B', str(p / 'compare-source290-generated-loaded.py')])
    run('source290-selected-audit', [sys.executable, '-B', str(p / 'audit-source290-selected.py')])
    state['status'] = 'candidate selected correctness audited; performance and application pending'
except Exception as error:
    state.update(status='post-validation sequence stopped', error=repr(error))
finally:
    save()
    with (p / 'source290-finish-finish-result.json').open('x') as stream:
        json.dump(state, stream, indent=2)
print(json.dumps(dict(status=state['status'], error=state.get('error'))), flush=True)
sys.exit(0 if state['status'].startswith('candidate correctness') else 1)
