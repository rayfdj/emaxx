from pathlib import Path
import hashlib,json,subprocess
p=Path(__file__).parent.resolve();root=p.parents[2];c=p.parent/'recovered-2026-10-05/vm-integer-path/emaxx'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
m=json.loads((p/'source290-manifest.json').read_text());assert len(m)==528 and all(sha(c/n)==h for n,h in m.items())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=c,text=True).strip()
tracked=set(subprocess.check_output(['git','ls-files'],cwd=c,text=True).splitlines());records=[]
for kind,base in [('incremental',head),('complete','21d20f0eec08f3c013d5d3eb3bd6e9cfc16b3199')]:
 patch=subprocess.check_output(['git','diff','--binary',base,'--',*sorted(m)],cwd=c)
 for n in sorted(set(m)-tracked):
  r=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',n],cwd=c,capture_output=True);assert r.returncode==1 and not r.stderr;patch+=r.stdout
 pf=p/f'source290-portable-{kind}.patch';pf.write_bytes(patch)
 replay=p/f'source290-replay-{kind}';assert not replay.exists()
 subprocess.run(['git','clone','--shared','--quiet','--no-checkout',str(root),str(replay)],check=True)
 existing=set(subprocess.check_output(['git','ls-tree','-r','--name-only',base],cwd=replay,text=True).splitlines())
 subprocess.run(['git','checkout',base,'--',*sorted(existing&set(m))],cwd=replay,check=True)
 subprocess.run(['git','apply','--check',str(pf)],cwd=replay,check=True)
 subprocess.run(['git','apply',str(pf)],cwd=replay,check=True)
 assert all(sha(replay/n)==h and (replay/n).stat().st_mode&0o777==(c/n).stat().st_mode&0o777 for n,h in m.items())
 records.append(dict(patch=pf.name,sha256=sha(pf),base=base,inputs=len(m),bytes_and_modes='exact'))
record=dict(status='portable unapplied draft verified',candidate=str(c),source_manifest='source290-manifest.json',patches=records,goal_complete=False,qualification='Selected correctness validation is separate and still running at capture. This draft outlines integer allocation, updates existing operand slots and removes duplicate pre-dispatch. All original test assertions and fixture bytes remain; the 588-row added boundary fixture matches actual GNU and prior289. No performance result is implied.')
with (p/'source290-portable-draft-audit.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(records))
