from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

p = Path(__file__).parent.resolve()
root = p.parent / "recovered-2026-09-30/macro-saved-state/emaxx"
tag = "source197"
manifest = json.loads((p / (tag + "-manifest.json")).read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
unchanged = lambda: all(sha(root / name) == digest for name, digest in manifest.items())

steps = [["check-reader197.py", "197"], ["static-reader197.py", "197"]]
results = []
for args in steps:
    assert unchanged()
    run = subprocess.run([sys.executable, str(p / args[0]), *args[1:]])
    results.append({"script": args, "exit_code": run.returncode, "source_unchanged": unchanged()})
    if run.returncode or not unchanged():
        break
if all(result["exit_code"] == 0 and result["source_unchanged"] for result in results):
    # Keep the current reader candidate's selected publication checks ahead
    # of this separate optimization; do not compete with its release build.
    while True:
        terminal = p / "source196-fresh-selected-tty-result.json"
        not_run = p / "source196-fresh-selected-tty-not-run.json"
        if terminal.exists() or not_run.exists():
            break
        handle = json.loads((p / "source196-fresh-selected-tty-supervisor.json").read_text())
        os.kill(handle["pid"], 0)
        time.sleep(5)
    later = [["test-reader197.py", "197", "gate"],
             ["test-reader197.py", "197", "release"],
             ["build-reader197.py", "197"],
             ["compare-recovered-continuation-fixtures.py", tag, str(root),
              "input-decode-macro-shared", "input-decode-macro-live-array",
              "input-decode-macro-raw-array", "input-decode-macro-nested-roots",
              "input-decode-macro-read-order", "input-decode-macro-reclamation",
              "input-decode-minibuffer-shared", "input-decode-minibuffer-queue"]]
    steps.extend(later)
    for args in later:
        assert unchanged()
        run = subprocess.run([sys.executable, str(p / args[0]), *args[1:]])
        results.append({"script": args, "exit_code": run.returncode, "source_unchanged": unchanged()})
        if run.returncode or not unchanged():
            break

passed = (len(results) == 6 and all(result["exit_code"] == 0 and result["source_unchanged"] for result in results))
with (p / (tag + "-selected-validation-result.json")).open("x") as stream:
    json.dump({"steps": results, "passed": passed, "all_completed": len(results) == 6,
               "source_unchanged": unchanged(), "completed_unix": time.time(),
               "qualification": "Separate macro saved-state candidate. Selected checks only; no complete final-source, physical allocation, or performance claim."}, stream, indent=2)
raise SystemExit(0 if passed else 1)
