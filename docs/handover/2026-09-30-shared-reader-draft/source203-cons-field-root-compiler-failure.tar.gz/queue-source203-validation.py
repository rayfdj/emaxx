from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/cons-roots/emaxx'
manifest = json.loads((p / 'source203-manifest.json').read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
unchanged = lambda: all(sha(root / f) == h for f, h in manifest.items())
fixtures = json.loads((p / 'source196-fresh-selected-validation-result.json').read_text())['steps'][-1]['script'][3:]
fixtures += ['input-decode-macro-reclamation', 'input-decode-down-event-binding']
fixtures += ['vector-closure-rounded-census', 'vector-pseudovector-word-census', 'shared-vector-native-words', 'shared-positioned-symbol-native-words', 'shared-string-native-words', 'char-table-identity', 'char-table-authoritative-values', 'char-table-range-uniprop']
fixtures += ['runtime-cons-mutation', 'purecopy-five-kinds-gc', 'unwind-payload-reclamation', 'reader-callable-gc']
assert len(fixtures) == len(set(fixtures)) == 40
steps = [
    ['check-cons203.py', '203'],
    ['static-cons203.py', '203'],
    ['test-cons203.py', '203', 'gate'],
    ['test-cons203.py', '203', 'release'],
    ['build-cons203.py', '203'],
    ['compare-recovered-continuation-fixtures.py', 'source203', str(root), *fixtures],
]
results = []
for args in steps:
    assert unchanged()
    started = time.monotonic()
    completed = subprocess.run([sys.executable, str(p / args[0]), *args[1:]], stdin=subprocess.DEVNULL)
    result = {'script': args, 'exit_code': completed.returncode,
              'source_unchanged': unchanged(), 'elapsed_seconds': time.monotonic() - started}
    results.append(result)
    if completed.returncode or not result['source_unchanged']:
        break
passed = len(results) == len(steps) and all(item['exit_code'] == 0 and item['source_unchanged'] for item in results)
with (p / 'source203-selected-validation-result.json').open('x') as stream:
    json.dump({'steps': results, 'passed': passed, 'all_completed': len(results) == len(steps),
               'source_unchanged': unchanged(), 'completed_unix': time.time(),
               'qualification': 'Selected direct cons field and GNU root validation. Preserves the original source198 Linux failure and source202 negative controls. Complete final-source and performance validation remain required.'}, stream, indent=2)
raise SystemExit(0 if passed else 1)
