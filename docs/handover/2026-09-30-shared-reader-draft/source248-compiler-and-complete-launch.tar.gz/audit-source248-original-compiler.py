from pathlib import Path
import hashlib, json

p = Path(__file__).parent.resolve()
candidate = p.parent / 'recovered-2026-09-30/coding-property-order/emaxx'
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
manifest = read(p / 'source248-manifest.json')
assert len(manifest) == 472 and all(sha(candidate / name) == digest for name, digest in manifest.items())
frozen = p / 'source246-linux-frozen-artifacts/compat/frozen-1790845634876444518-5828/test/src/comp-tests.compat'
original = read(frozen / 'oracle.json')
reports = {}
assert read(p / 'source248-upstream-compiler-audit.json')['status'] == 'passed'
for editor in ['gnu', 'emaxx']:
    prefix = 'source248-upstream-compiler-' + editor
    command = read(p / (prefix + '-command.json'))
    result = read(p / (prefix + '-result.json'))
    report_path = p / 'source248-upstream-compiler' / editor / 'report.json'
    report = read(report_path)
    assert result['exit_code'] == 0 and not result['timed_out']
    assert result['source_unchanged'] and result['inputs_unchanged']
    assert sha(report_path) == result['report_sha256']
    assert all(sha(Path(name)) == digest for name, digest in command['inputs'].items())
    for suffix in ['stdout', 'stderr']:
        assert sha(p / (prefix + '.' + suffix)) == result[suffix + '_sha256']
    for field in ['file', 'selector', 'discovered_tests', 'selected_tests']:
        assert report[field] == original[field], (editor, field)
    assert report['file_status'] == 'loaded' and report['file_error'] is None
    assert len(report['results']) == len({row['name'] for row in report['results']}) == 177
    assert {row['name'] for row in report['results']} == set(original['selected_tests'])
    assert all(row['status'] == 'passed' and row['expected'] for row in report['results'])
    assert report['summary'] == dict(total=177, passed=177, failed=0, skipped=0, unexpected=0)
    reports[editor] = dict(report_sha256=sha(report_path), outcomes=177)
record = dict(status='passed', inputs_verified=472, outcomes_per_editor=177, reports=reports,
              original_frozen_report_sha256=sha(frozen / 'oracle.json'), goal_complete=False,
              qualification='Every original frozen compiler name, discovered metadata, selector and expected verdict matches the new ordinary comparison. All 177 tests pass in both normal editors. Local GNU is source/native-ABI matched, not pinned Darwin. Complete source248 platform/release/frozen validation remains required.')
with (p / 'source248-upstream-compiler-raw-audit.json').open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps(record, indent=2))
