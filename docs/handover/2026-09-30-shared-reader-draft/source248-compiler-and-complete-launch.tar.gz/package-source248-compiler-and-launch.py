from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
out = root / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
compiler = read('source248-upstream-compiler-raw-audit.json')
assert compiler['status'] == 'passed' and compiler['outcomes_per_editor'] == 177
assert read('source248-root-application.json')['inputs'] == 472
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected'}
patterns = ['source248-upstream-compiler-*', 'compare-source248-upstream-compiler.py',
            'audit-source248-original-compiler.py', 'source248-root-application.json',
            'source248-complete-launch-result.json', 'source248-full-gate-launch.json',
            'source248-release-and-ordinary-launch.json', 'source248-full-ttydiff-launch.json',
            'source248-manifest.json', 'source248-*.patch', 'source248-freeze.json',
            'source248-patch-replay-audit.json', 'source248-selected-audit.json',
            'source248-gate-focused-audit.json', 'source246-linux-gnu-trace-*',
            'run-source248-full-gate.py', 'run-source248-full-tty.py',
            'run-source248-release-and-ordinary.py', 'launch-source248-complete.py',
            'source246-recovered-commit.json', 'source246-recovered-push.json', Path(__file__).name]
files = {str(f.relative_to(p)): f for pattern in patterns for f in p.glob(pattern)
         if f.is_file() and f.suffix in allowed}
files.update({str(f.relative_to(p)): f for f in (p / 'source248-upstream-compiler').rglob('*')
              if f.is_file() and f.suffix in allowed})
assert not any(name in files for name in ['source248-full-gate.log', 'source248-full-ttydiff.log',
    'source248-ordinary-comparisons.log', 'source248-release-controls.log', 'source248-release-broad.log'])
package('source248-compiler-and-complete-launch', files, dict(compiler=compiler,
    applied_inputs=472, launched=read('source248-complete-launch-result.json'),
    gnu_diagnosis=read('source246-linux-gnu-trace-launch.json'),
    qualification='All original 177 compiler tests pass GNU/source248 with frozen inventories and raw process hashes verified. The root runtime now matches all 472 validated candidate inputs. Complete macOS4528, release/preceding ordinary4529 and terminal4530 are launched; active logs are excluded. GNU-only GC diagnosis36848112001 is separately queued on 2dd1dea8. No complete source248 platform or performance pass is claimed, and full goal remains open.'))
