from pathlib import Path
import hashlib, json, subprocess, sys

p = Path(__file__).parent.resolve()
read = lambda name: json.loads((p / name).read_text())
stages = read('source248-validation-result.json')
assert len(stages) == 7 and all(stage['exit_code'] == 0 for stage in stages)
assert read('source248-gate-focused-audit.json')['passed'] == 170
selected = read('source248-selected-audit.json')
assert selected['affected_passes'] == 953 and selected['ordinary_comparisons'] == 13
assert read('source248-upstream-compiler-raw-audit.json')['outcomes_per_editor'] == 177
records = []
for label, name in [('full-gate', 'run-source248-full-gate.py'),
                    ('release-and-ordinary', 'run-source248-release-and-ordinary.py'),
                    ('full-ttydiff', 'run-source248-full-tty.py')]:
    helper = p / name
    with (p / ('source248-' + label + '-driver.log')).open('x') as log:
        child = subprocess.Popen([sys.executable, '-B', str(helper)], stdin=subprocess.DEVNULL,
                                 stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    record = dict(pid=child.pid, command=[sys.executable, '-B', str(helper)],
                  helper_sha256=hashlib.sha256(helper.read_bytes()).hexdigest(),
                  source_manifest='source248-manifest.json', qualification='Launch is not a passing result.')
    with (p / ('source248-' + label + '-launch.json')).open('x') as stream:json.dump(record, stream, indent=2)
    records.append(record)
with (p / 'source248-complete-launch-result.json').open('x') as stream:json.dump(records, stream, indent=2)
print(json.dumps(records, indent=2), flush=True)
