from pathlib import Path
import hashlib, json, subprocess, sys, time
p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/coding-property-order/emaxx'
read = lambda name: json.loads((p / name).read_text())
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
assert all(stage['exit_code'] == 0 for stage in read('source248-validation-result.json'))
assert read('source248-selected-audit.json')['affected_passes'] == 953
assert read('source248-selected-audit.json')['ordinary_comparisons'] == 13
for name, entry in read('source248-ordinary-artifacts.json').items():
    assert sha(Path(name)) == entry['sha256'] == sha(Path(entry['immutable_copy']))
fixtures = read('source238-ordinary-comparisons-command.json')['fixtures']
assert len(fixtures) == len(set(fixtures)) == 57
command = [sys.executable, str(p / 'compare-source230-fixtures.py'), 'source248', str(root), *fixtures]
with (p / 'source248-ordinary-comparisons-command.json').open('x') as f:
    json.dump(dict(command=command, fixtures=fixtures,
                   qualification='All 57 prior ordinary comparisons, unchanged, in addition to the thirteen already passing file-writing/coding/copy fixtures. Same normal -Q entry points and C locale. No pinned Darwin or performance claim.'), f, indent=2)
start = time.monotonic()
with (p / 'source248-ordinary-comparisons.log').open('x') as log:
    result = subprocess.run(command, cwd=root, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
record = dict(exit_code=result.returncode, elapsed_seconds=time.monotonic() - start, fixtures=57)
with (p / 'source248-ordinary-comparisons-result.json').open('x') as f:
    json.dump(record, f, indent=2)
results = [dict(command=command, **record)]
if result.returncode == 0:
    for name in ['test-source248-controls.py', 'test-source248-broad.py']:
        command = [sys.executable, str(p / name), '248', 'release']
        start = time.monotonic()
        result = subprocess.run(command, stdin=subprocess.DEVNULL)
        results.append(dict(command=command, exit_code=result.returncode, elapsed_seconds=time.monotonic() - start))
        if result.returncode:
            break
with (p / 'source248-release-and-ordinary-result.json').open('x') as f:
    json.dump(results, f, indent=2)
raise SystemExit(results[-1]['exit_code'])
