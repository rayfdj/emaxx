from pathlib import Path
import hashlib, json, os, subprocess, time

p = Path(__file__).parent.resolve()
root = p.parents[2]
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
fixture = p / 'coding-live-conversion-translation.el'
current = json.loads((p / 'source248-general-translation-negative-audit.json').read_text())
assert current['fixture_sha256'] == sha(fixture)
gnu_output = (p / 'source248-general-translation-gnu.stdout').read_bytes()
new_output = (p / 'source248-general-translation-emaxx.stdout').read_bytes()
records = []
for version in [174, 207]:
    label = 'source' + str(version)
    artifacts = json.loads((p / (label + '-ordinary-artifacts.json')).read_text())
    for entry in artifacts.values():
        path = Path(entry['immutable_copy'])
        assert sha(path) == entry['sha256'] and path.stat().st_size == entry['bytes']
    binary = Path(next(name for name in artifacts if Path(name).name == 'emaxx'))
    assert all(sha(Path(name)) == entry['sha256'] for name, entry in artifacts.items())
    image = binary.with_suffix('.pdmp')
    command = [str(binary), '-Q', '--batch', '--eval', '(prin1 ' + fixture.read_text() + ')']
    inputs = {str(path): sha(path) for path in [fixture, Path(__file__), binary, image]}
    prefix = label + '-general-translation-original-location'
    with (p / (prefix + '-command.json')).open('x') as stream:
        json.dump(dict(command=command, inputs=inputs, working_directory=str(root),
                       environment_overrides={'LANG':'C', 'LC_ALL':'C'}, timeout_seconds=120,
                       qualification='Original-location baseline executable/image, byte-identical to the retained artifact receipt. This preserves native paths embedded relative to the executable; the earlier relocated launch failure remains separate. No rebuild or baseline source change.'), stream, indent=2)
    start = time.monotonic()
    result = subprocess.run(command, cwd=root, env={**os.environ, 'LANG':'C', 'LC_ALL':'C'},
                            stdin=subprocess.DEVNULL, capture_output=True, timeout=120)
    for suffix, data in [('stdout', result.stdout), ('stderr', result.stderr)]:
        with (p / (prefix + '.' + suffix)).open('xb') as stream:
            stream.write(data)
    row = dict(source=label, exit_code=result.returncode, elapsed_seconds=time.monotonic()-start,
               stdout_sha256=hashlib.sha256(result.stdout).hexdigest(),
               stderr_sha256=hashlib.sha256(result.stderr).hexdigest(),
               matches_gnu=result.stdout == gnu_output, matches_source248=result.stdout == new_output,
               inputs_unchanged=all(sha(Path(name)) == digest for name,digest in inputs.items()))
    with (p / (prefix + '-result.json')).open('x') as stream:
        json.dump(row, stream, indent=2)
    print(json.dumps(row), result.stdout.decode(errors='replace'), result.stderr.decode(errors='replace'), flush=True)
    assert result.returncode == 0 and not result.stderr and row['inputs_unchanged']
    records.append(row)
with (p / 'coding-translation-history-original-location-audit.json').open('x') as stream:
    json.dump(dict(records=records, fixture_sha256=sha(fixture),
                   qualification='Same-input comparison against recorded source174/main and fully frozen-matching source207 executable/image pairs. Establishes the history only of this specific live conversion-table fixture; it does not excuse other regressions or certify general coding correctness.'), stream, indent=2)
