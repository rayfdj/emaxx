from pathlib import Path
import json, re, subprocess

p = Path(__file__).parent.resolve()
root = p.parents[2]
head = '163064c97cfb430b7b269ad15cb7db499b77879e'

def save(name, value):
    with (p / name).open('x') as stream:
        json.dump(value, stream, indent=2)

assert subprocess.check_output(['git', 'ls-remote', '--heads', 'origin',
    'refs/heads/runtime-char-tables'], cwd=root, text=True).split()[0] == head
launches = []
for validation in ['gnu-census-trace']:
    command = ['gh', 'workflow', 'run', 'frozen-run.yml', '--repo', 'rayfdj/emaxx',
               '--ref', 'runtime-char-tables', '-f', 'validation=' + validation]
    result = subprocess.run(command, cwd=root, stdin=subprocess.DEVNULL,
                            capture_output=True, text=True)
    prefix = 'source248-linux-gnu-trace'
    save(prefix + '-dispatch.json', dict(command=command, commit=head,
        exit_code=result.returncode, stdout=result.stdout, stderr=result.stderr))
    result.check_returncode()
    match = re.fullmatch(r'https://github.com/rayfdj/emaxx/actions/runs/(\d+)\s*', result.stdout)
    assert match, result.stdout
    run_id = int(match[1])
    state = json.loads(subprocess.check_output(['gh', 'run', 'view', str(run_id),
        '--repo', 'rayfdj/emaxx', '--json', 'status,conclusion,headSha,url'], cwd=root, text=True))
    assert state['headSha'] == head
    launch = dict(run_id=run_id, state=state, source_commit=head, runtime_source='source248',
        qualification='GNU-only diagnostic retry after restoring the startup shell required by GDB argument escaping and adding actual inferior argv equality verification. The previous observer failed before any GC snapshot. Original fixtures and expected outputs remain unchanged; static checks pass but actual Linux execution is pending. Full source248 Rust/frozen continue independently on fa7578ac, with identical 472 runtime inputs. No runtime correctness or GC root cause is inferred from this dispatch.')
    save(prefix + '-launch.json', launch)
    launches.append(launch)
print(json.dumps(launches))
