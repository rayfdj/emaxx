(progn
  (require 'cl-lib)
  (let ((encode-table (make-char-table 'translation-table nil))
        (decode-table (make-char-table 'translation-table nil))
        (standard-encode (make-char-table 'translation-table nil))
        (standard-decode (make-char-table 'translation-table nil)))
    (aset encode-table 65 9731)
    (aset encode-table 9731 66)
    (aset decode-table 9731 81)
    (aset decode-table 65 82)
    (aset standard-encode 9731 67)
    (aset standard-decode 81 83)
    (put 'runtime-conversion-encode 'translation-table encode-table)
    (put 'runtime-conversion-decode 'translation-table decode-table)
    (define-coding-system 'runtime-live-conversion "Live conversion table control."
      :coding-type 'utf-8 :mnemonic ?R :charset-list '(unicode)
      :encode-translation-table 'runtime-conversion-encode
      :decode-translation-table 'runtime-conversion-decode)
    (let ((standard-translation-table-for-encode nil)
          (standard-translation-table-for-decode nil))
      (cl-labels
          ((convert ()
             (list
              (string-to-list
               (encode-coding-string (string 65 88 9731) 'runtime-live-conversion))
              (string-to-list
               (decode-coding-string (unibyte-string 226 152 131 65 88)
                                     'runtime-live-conversion)))))
        (list
         (convert)
         (let ((enable-character-translation nil)) (convert))
         (progn (aset encode-table 65 68) (aset decode-table 9731 69) (convert))
         (progn
           (aset encode-table 65 9731)
           (aset decode-table 9731 81)
           (let ((standard-translation-table-for-encode standard-encode)
                 (standard-translation-table-for-decode standard-decode))
             (convert))))))))
