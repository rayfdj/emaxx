from pathlib import Path
import hashlib, json, subprocess

p = Path(__file__).parent.resolve()
root = p.parents[2]
prefix = 'source248-linux-gnu-trace'
base = p / (prefix + '-artifacts')
out = base / 'gnu-census-trace'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_text())
head = '163064c97cfb430b7b269ad15cb7db499b77879e'
download = read(p / (prefix + '-download.json'))
assert len(download['files']) == 55
assert all(sha((base / name).read_bytes()) == digest for name,digest in download['files'].items())
s = read(out / 'summary.json')
assert s['git'] == dict(head=head, dirty=False)
assert s['status'] == 'GC diagnosis completed' and s['inputs_unchanged']
assert len(s['runs']) == 22
for absolute, digest in s['inputs'].items():
    relative = absolute.removeprefix('/home/runner/work/emaxx/emaxx/emaxx/')
    assert relative != absolute
    assert sha(subprocess.check_output(['git','show',head+':'+relative],cwd=root)) == digest
capture = read(out / 'gnu-inputs/manifest.json')
assert capture == s['oracle_capture']
assert capture['source_commit'] == '636f166cfc86aa90d63f592fd99f3fdd9ef95ebd'
assert capture['source_tracked_changes'] == [] and len(capture['files']) == 4
prior = p / 'source246-linux-gnu-trace-artifacts/gnu-census-trace/gnu-inputs'
for row in capture['files']:
    actual = out / 'gnu-inputs' / row['artifact']
    assert actual.stat().st_size == row['bytes'] and sha(actual.read_bytes()) == row['sha256']
    assert sha((prior / row['artifact']).read_bytes()) == row['sha256']
assert s['oracle_after']['status'] == 'unchanged' and s['oracle_after']['files_verified'] == 4
assert s['oracle_after']['capture_manifest_sha256'] == sha((out/'gnu-inputs/manifest.json').read_bytes())
for row in s['runs']:
    assert row['exit_code'] == 0 and not row['timed_out']
    for suffix in ['stdout', 'stderr']:
        assert sha((out/row[suffix+'_file']).read_bytes()) == row[suffix+'_sha256']
    assert not (out/row['stderr_file']).read_bytes()

traces = []
for fixture, total_collections in [('vector-closure-rounded-census',36), ('vector-pseudovector-word-census',64)]:
    rows = [row for row in s['runs'] if row['label'].startswith(fixture)]
    assert len(rows) == 11
    ordinary, debugger = rows[:-1], rows[-1]
    assert [row['padding_bytes'] for row in ordinary] == [None,0,8,16,32,64,128,256,1024,4096]
    expected = (root/('tests/fixtures/'+fixture+'.expected')).read_bytes().rstrip(b'\n')
    program = '(prin1 '+(root/('tests/fixtures/'+fixture+'.el')).read_text()+')'
    command = [capture['files'][0]['original'],'--batch','-Q','--eval',program]
    for row in ordinary:
        assert row['command'] == command and row['expected_output']
        assert (out/row['stdout_file']).read_bytes() == expected
    assert debugger['ordinary_mismatch_observed'] is False
    stdout = (out/debugger['stdout_file']).read_text()
    assert expected.decode() in stdout and 'exited normally' in stdout
    assert 'Python Exception' not in stdout and 'Traceback (most recent call last)' not in stdout
    events = [json.loads(line.split('GNU_CENSUS_TRACE ',1)[1]) for line in stdout.splitlines() if 'GNU_CENSUS_TRACE ' in line]
    assert events == read(out/(fixture+'-trace-events.json')) and len(events) == debugger['trace_events'] == 26
    assert [event['argv'] for event in events if event['event']=='inferior argument vector'] == [command]
    entered = [event for event in events if event['event']=='explicit GC entered']
    sweeps = [event for event in events if event['event']=='marked vector inventory']
    returns = [event for event in events if event['event']=='explicit GC returned']
    for group in [entered,sweeps,returns]:
        assert [event['collection'] for event in group] == list(range(1,9))
    completed = [event for event in events if event['event']=='observer completed']
    assert len(completed) == 1 and completed[0]['errors'] == []
    assert completed[0]['explicit_collections'] == total_collections and completed[0]['captured_sweeps'] == 8
    previous = {}
    for event,returned in zip(sweeps,returns):
        objects = {row['address']:row for row in event['objects']}
        assert len(objects) == len(event['objects'])
        live = {}
        for address,row in objects.items():
            header = row['header']
            assert header == row['words'][0] and row['marked'] == bool(header & (1<<63))
            size = header & ((1<<63)-1)
            kind = (size>>24)&63 if size&(1<<62) else 0
            assert kind == row['kind_number'] and kind != 1
            if kind == 12:
                nbytes = 16+((row['words'][1]+63)//64)*8
            elif size & (1<<62):
                nbytes = (1+(size&4095)+((size>>12)&4095))*8
            else:
                nbytes = (1+size)*8
            assert nbytes == row['bytes'] and len(row['words']) == min(136,nbytes)//8
            if row['marked']:
                live[address] = row
        assert event['live_objects'] == len(live)
        assert event['live_slots'] == sum(row['bytes']//8 for row in live.values()) == returned['total_vector_slots']
        assert event['dropped_previous_live'] == [row for address,row in previous.items() if address not in live]
        assert not event['dropped_previous_live']
        for ref in event['stack']['candidates']:
            row = objects[ref['object_address']]
            assert row['address'] <= ref['word'] < row['address']+row['bytes']
            assert ref['offset'] == ref['word']-row['address']
        previous = live
    traces.append(dict(fixture=fixture, collections_observed=8, explicit_collections=total_collections,
                       live_slots=[event['live_slots'] for event in sweeps], previous_live_objects_dropped=0,
                       actual_argument_vector='matches ordinary GNU command', returned_census='matches decoded inventories'))
record = dict(status='diagnostic completed; mismatch not reproduced', run_id=36850342459, commit=head,
              downloaded_files_verified=55, ordinary_matches=20, traces=traces,
              retained_gnu_inputs=capture['files'], goal_complete=False,
              qualification='The corrected observer runs both unchanged fixtures with exact inferior argv. All twenty ordinary processes match; both GDB processes exit normally and return the expected Lisp output. All sixteen marked inventories independently sum to GNU returned slot counts. No previously live object drops within those observations, so the earlier -7/-9 results and their retaining root are not explained. Four retained GNU inputs match the earlier failed full run and are verified unchanged. This is diagnostic evidence, not full source248 or performance validation.')
with (p/(prefix+'-audit.json')).open('x') as stream:
    json.dump(record,stream,indent=2)
print(json.dumps({k:v for k,v in record.items() if k!='retained_gnu_inputs'},indent=2))
