from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
out = p.parents[2] / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda b: hashlib.sha256(b).hexdigest()
read = lambda n: json.loads((p / n).read_text())
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
audit = read('source310-macos-terminal-audit.json')
assert audit['raw_comparisons_passed'] and audit['matching_comparisons'] == 686
assert len(audit['execution_input_drift']) == 1
correction = dict(
    status='executable identity limitation; raw failures and matches retained',
    goal_complete=False,
    terminal=audit,
    initial_audit_failure='The first independent terminal audit stopped at the recorded executable hash mismatch; no passing receipt was emitted.',
    frozen_retention_limit='The source310-macos-frozen-abort archive retains the executable available after the separate ERC harness replay (0dcadc0d...), not the earlier executable recorded when terminal validation began (28ab0011...). Treat that retained binary as the later crashing replay input, not proven retention of the original full-frozen process image. Source and dump are unchanged; the old runtime crash is independently reproduced with recorded executable identities in source312-erc-repair.',
    cause='An ERC diagnostic invoked compat-harness in the same checkout while the terminal suite ran. Its build step reused target/compat-subject/gate/emaxx. The current and retained post-replay binary hashes agree, but differ from the terminal command receipt. Per-scenario executable hashes were not captured.',
    consequence='No unchanged-artifact terminal certification is claimed. Exact-source final validation must use an isolated build directory with no diagnostic rebuilds during execution.')
(p / 'source310-executable-retention-correction.json').open('x').write(json.dumps(correction, indent=2))
names = [
    'source310-macos-terminal-audit.json', 'source310-executable-retention-correction.json',
    'audit-source310-macos-terminal.py', 'audit-source310-macos-terminal-qualified.py',
    'source310-full-tty-command.json', 'source310-full-tty-result.json', 'source310-full-tty.log',
    'source310-full-queue-result.json', 'source310-full-queue-state.json',
    'source310-erc-replay-command.json', 'source310-erc-replay-result.json', 'source310-erc-replay.log',
    'source310-macos-frozen-abort-audit.json', 'source310-manifest.json',
    'source248-manifest.json', 'source248-full-ttydiff-retry-command.json',
    'queue-source310-full-macos.py', 'package-source196-failure-and197-results.py', Path(__file__).name,
]
files = {n: p / n for n in names}
assert all(f.is_file() for f in files.values())
package('source310-macos-terminal-qualified-results', files, correction)
