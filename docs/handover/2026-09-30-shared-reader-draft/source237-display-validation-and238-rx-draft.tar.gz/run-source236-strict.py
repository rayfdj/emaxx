from pathlib import Path
import json,os,subprocess,sys,time
p=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28')
results=[]
for name in ['check-source235.py','static-source235.py']:
    command=[sys.executable,str(p/name),'236']
    start=time.monotonic()
    result=subprocess.run(command,stdin=subprocess.DEVNULL)
    results.append({'command':command,'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start})
    if result.returncode:break
with (p/'source236-strict-driver-result.json').open('x') as f:json.dump(results,f,indent=2)
raise SystemExit(results[-1]['exit_code'])
