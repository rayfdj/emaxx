from pathlib import Path
import json,subprocess,sys,time
p=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28')
assert (p/'source238-complete.patch').is_file()
results=[]
for name,args in [('check-source238.py',['238']),('static-source238.py',['238']),('test-source238-controls.py',['238','gate']),('build-source238.py',['238']),('validate-source238-rx.py',[])]:
 command=[sys.executable,str(p/name),*args];start=time.monotonic()
 result=subprocess.run(command,stdin=subprocess.DEVNULL)
 results.append({'command':command,'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start})
 if result.returncode:break
with (p/'source238-validation-result.json').open('x') as f:json.dump(results,f,indent=2)
raise SystemExit(results[-1]['exit_code'])
