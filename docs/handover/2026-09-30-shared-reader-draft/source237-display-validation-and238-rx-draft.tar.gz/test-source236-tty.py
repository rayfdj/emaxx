from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys,time
p=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28')
root=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/tty-render/emaxx')
tag='source'+sys.argv[1]
profile=sys.argv[2]
manifest=json.loads((p/(tag+'-manifest.json')).read_text())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def unchanged():return all(sha(root/name)==value for name,value in manifest.items())
def save(suffix,data):
    with (p/(tag+'-'+suffix+'.json')).open('x') as stream:json.dump(data,stream,indent=2);stream.write('\n')
env={'CARGO_TARGET_DIR':'/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/tty-render/emaxx/target/frame-validation','CARGO_BUILD_JOBS':'1',
     'LANG':'C','LC_ALL':'C','RUST_MIN_STACK':'134217728','RUST_TEST_THREADS':'1','EMAXX_GC_VERIFY':'1','EMAXX_IMAGE_TEMPLATE':'1',
     'EMAXX_FIXTURE_IMAGE_DIR':str(p/('fixture-images-'+tag)),
     'EMAXX_GNU_SOURCE_DIRECTORY':'/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/emacs',
     'EMAXX_DUMP_SOURCE_DIRECTORY':'/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/emacs',
     'EMACS_TEST_DIRECTORY':'/Users/nbmhqa186/projects/emaxx/target/runtime-goal/recovered-2026-09-30/emacs/test'}
def run(stage,command,extra=None):
    assert unchanged()
    save(stage+'-command',{'command':command,'working_directory':str(root),'environment_override':env,**(extra or {})})
    start=time.monotonic()
    with (p/(tag+'-'+stage+'.log')).open('x') as log:
        result=subprocess.run(command,cwd=root,env={**os.environ,**env},stdout=log,stderr=subprocess.STDOUT,timeout=3600)
    record={'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,'source_unchanged':unchanged()}
    save(stage+'-result',record)
    print(stage,json.dumps(record),flush=True)
    return result.returncode or (0 if record['source_unchanged'] else 2)
code=run(profile+'-build',['cargo','test','--locked','--all-features','--profile',profile,'--lib','--no-run','--message-format=json-render-diagnostics'])
if code:sys.exit(code)
artifacts=[]
for line in (p/(tag+'-'+profile+'-build.log')).read_text().splitlines():
    try:item=json.loads(line)
    except json.JSONDecodeError:continue
    if item.get('reason')=='compiler-artifact' and item.get('profile',{}).get('test') and item.get('executable'):artifacts.append(item['executable'])
assert len(artifacts)==1
binary=p/(tag+'-'+profile+'-libtest');assert not binary.exists();shutil.copy2(artifacts[0],binary)
listed=subprocess.run([str(binary),'--list','--format','terse'],cwd=root,env={**os.environ,**env},capture_output=True,text=True,check=True)
(p/(tag+'-'+profile+'-inventory.txt')).write_text(listed.stdout)
inventory=[line[:-6] for line in listed.stdout.splitlines() if line.endswith(': test')]
names=[name for name in inventory if name.startswith('tty::')]
assert len(names)==64
code=run(profile+'-controls',[str(binary),*names,'--exact','--nocapture','--test-threads=1'],{'binary_sha256':sha(binary),'selected_inventory':names})
print((p/(tag+'-'+profile+'-controls.log')).read_text(),flush=True)
sys.exit(code)
