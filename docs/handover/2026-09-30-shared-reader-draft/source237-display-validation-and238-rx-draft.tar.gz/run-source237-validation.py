from pathlib import Path
import json,subprocess,sys,time
p=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28')
results=[]
for name in ['run-source237-strict.py','run-source237-selected.py']:
    command=[sys.executable,str(p/name)]
    start=time.monotonic(); result=subprocess.run(command,stdin=subprocess.DEVNULL)
    results.append({'command':command,'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start})
    if result.returncode:break
with (p/'source237-validation-result.json').open('x') as f:json.dump(results,f,indent=2)
raise SystemExit(results[-1]['exit_code'])
