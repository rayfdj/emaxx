from pathlib import Path
import json,os,subprocess,sys,time
p=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28')
strict=json.loads((p/'source236-strict-driver-result.json').read_text())
assert len(strict)==2 and all(stage['exit_code']==0 for stage in strict)
results=[]
for name,args in [('test-source236-tty.py',['236','gate']),('build-source235.py',['236'])]:
    command=[sys.executable,str(p/name),*args]
    start=time.monotonic()
    result=subprocess.run(command,stdin=subprocess.DEVNULL)
    results.append({'command':command,'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start})
    if result.returncode:break
with (p/'source236-selected-driver-result.json').open('x') as f:json.dump(results,f,indent=2)
raise SystemExit(results[-1]['exit_code'])
