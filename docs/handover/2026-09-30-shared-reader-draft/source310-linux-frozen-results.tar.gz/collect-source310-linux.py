from pathlib import Path
import hashlib, json, subprocess, sys, time

p = Path(__file__).parent.resolve()
root = p.parents[2]
read = lambda n: json.loads((p / n).read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
launch = read('source310-full-validation-launch.json')
head = launch['commit']
helpers = {name: sha(p / name) for name in [Path(__file__).name, 'audit-source310-linux-rust.py', 'verify-source310-linux-rust.py', 'audit-source310-linux-frozen.py', 'verify-complete-frozen-receipts279.py']}
state = dict(status='waiting for exact-source Linux workflows', commit=head, helpers=helpers, results=[], goal_complete=False)
def save():
    (p / 'source310-linux-collection-state.json').write_text(json.dumps(state, indent=2))
def run(stage, command, timeout=900):
    assert all(sha(p / n) == h for n, h in helpers.items())
    (p / ('source310-linux-collection-' + stage + '-command.json')).open('x').write(json.dumps(dict(command=command, working_directory=str(root), timeout_seconds=timeout), indent=2))
    start = time.monotonic()
    with (p / ('source310-linux-collection-' + stage + '.log')).open('xb') as log:
        try:
            r = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT, timeout=timeout)
            code, timed_out = r.returncode, False
        except subprocess.TimeoutExpired:
            code, timed_out = None, True
    result = dict(stage=stage, exit_code=code, timed_out=timed_out, elapsed_seconds=time.monotonic()-start)
    state['results'].append(result)
    save()
    assert code == 0 and not timed_out, result
save()
try:
    pending = dict(launch['runs'])
    while pending:
        for kind, record in list(pending.items()):
            command = ['gh', 'run', 'view', str(record['databaseId']), '--repo', 'rayfdj/emaxx', '--json', 'status,conclusion,headSha,jobs,createdAt,updatedAt,url']
            response = subprocess.run(command, capture_output=True, text=True, timeout=60)
            if response.returncode:
                # Preserve a transient request failure; it is never a test pass.
                state.setdefault('poll_errors', []).append(dict(time=time.time(), command=command, exit_code=response.returncode, stderr=response.stderr))
                save()
                continue
            current = json.loads(response.stdout)
            assert current['headSha'] == head
            state[kind] = dict(status=current['status'], conclusion=current['conclusion'], url=current['url'])
            save()
            if current['status'] == 'completed':
                (p / ('source310-linux-' + kind + '-terminal.json')).open('x').write(json.dumps(current, indent=2))
                pending.pop(kind)
        if pending:
            time.sleep(45)
    # Avoid artifact transfer or hashing load during the local timing/profile run.
    state['status'] = 'Linux workflows closed; waiting for local timing and profiles'
    save()
    while not (p / 'native-unit310-publication-validation-result.json').exists():
        time.sleep(20)
    for kind, record in launch['runs'].items():
        state['status'] = 'downloading ' + kind
        save()
        destination = p / ('source310-linux-' + kind + '-artifacts')
        assert not destination.exists()
        run('download-' + kind, ['gh', 'run', 'download', str(record['databaseId']), '--repo', 'rayfdj/emaxx', '--dir', str(destination)])
        if read('source310-linux-' + kind + '-terminal.json')['conclusion'] == 'success':
            state['status'] = 'auditing ' + kind
            save()
            run('audit-' + kind, [sys.executable, '-B', str(p / ('audit-source310-linux-' + kind + '.py'))])
        else:
            state.setdefault('failed_workflows', []).append(kind)
    state['status'] = ('Linux workflow failures retained; diagnosis required' if state.get('failed_workflows') else 'both complete Linux runs downloaded and independently audited')
except Exception as error:
    state.update(status='Linux evidence collection stopped', error=repr(error))
finally:
    state['helpers_unchanged'] = all(sha(p / n) == h for n, h in helpers.items())
    save()
    (p / 'source310-linux-collection-result.json').open('x').write(json.dumps(state, indent=2))
print(json.dumps(state), flush=True)
