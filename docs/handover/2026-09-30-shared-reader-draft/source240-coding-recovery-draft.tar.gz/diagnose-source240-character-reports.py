from pathlib import Path
import hashlib, json, os, subprocess, time

p = Path(__file__).parent.resolve()
r = p.parent / 'recovered-2026-09-30'
runner = r / 'rx-repair/emaxx/compat/emacs_compat_runner.el'
assert runner.read_bytes() == (r / 'coding-repair/emaxx/compat/emacs_compat_runner.el').read_bytes()
fixture = p / 'character-report-probe.el'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
outcomes = []
for editor, binary in [('gnu', r / 'emacs/src/emacs'),
                       ('source238', r / 'rx-repair/emaxx/target/frame-validation/release/emaxx'),
                       ('source240', r / 'coding-repair/emaxx/target/frame-validation/release/emaxx')]:
    stem = 'source240-character-report-' + editor
    report = p / (stem + '-report.json')
    assert not report.exists()
    env = dict(LANG='C', LC_ALL='C', EMACS_TEST_DIRECTORY=str(r / 'emacs/test'),
               EMAXX_BATCH_RESULT_FILE=str(report), EMAXX_COMPAT_RELATIVE_FILE='character-report-probe.el',
               EMAXX_COMPAT_RUNNER=editor, EMAXX_COMPAT_SELECTOR='t')
    command = [str(binary), '-Q', '--batch', '-L', str(r / 'emacs/test'), '-l', str(runner),
               '-l', str(fixture), '--eval', '(emaxx-compat-run t)']
    inputs = {str(file): sha(file) for file in [binary, binary.with_suffix('.pdmp'), runner, fixture]}
    with (p / (stem + '-command.json')).open('x') as f:
        json.dump(dict(command=command, environment_override=env, inputs=inputs,
                       qualification='Same ASCII fixture and unchanged structured runner; four known ERT outcomes carrying U+F8FF. Local GNU source/ABI matches but is not the pinned Darwin binary.'), f, indent=2)
    start = time.monotonic()
    with (p / (stem + '.stdout')).open('xb') as out, (p / (stem + '.stderr')).open('xb') as err:
        result = subprocess.run(command, cwd=r / 'coding-repair/emaxx', env={**os.environ, **env},
                                stdin=subprocess.DEVNULL, stdout=out, stderr=err, timeout=120)
    record = dict(editor=editor, exit_code=result.returncode, elapsed_seconds=time.monotonic() - start,
                   inputs_unchanged=all(sha(Path(name)) == digest for name, digest in inputs.items()),
                   report_exists=report.exists(), report_sha256=sha(report) if report.exists() else None,
                   stdout_sha256=sha(p / (stem + '.stdout')), stderr_sha256=sha(p / (stem + '.stderr')))
    with (p / (stem + '-result.json')).open('x') as f:
        json.dump(record, f, indent=2)
    outcomes.append(record)
    print(json.dumps(record), flush=True)
with (p / 'source240-character-report-outcomes.json').open('x') as f:
    json.dump(outcomes, f, indent=2)
