from pathlib import Path
import json, subprocess, sys, time

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/coding-repair/emaxx'
stages = [
    ['check-source240.py', '240'],
    ['static-source240.py', '240'],
    ['test-source240-controls.py', '240', 'gate'],
    ['build-source240.py', '240'],
    ['compare-source230-fixtures.py', 'source240', str(root),
     'canonical-coding-character-storage', 'canonical-coding-identity-storage',
     'canonical-coding-conversion-storage', 'copied-canonical-string-storage'],
    ['test-source240-broad.py', '240', 'gate'],
]
results = []
for name, *args in stages:
    command = [sys.executable, str(p / name), *args]
    start = time.monotonic()
    result = subprocess.run(command, stdin=subprocess.DEVNULL)
    results.append(dict(command=command, exit_code=result.returncode,
                        elapsed_seconds=time.monotonic() - start))
    if result.returncode:
        break
with (p / 'source240-validation-result.json').open('x') as f:
    json.dump(results, f, indent=2)
raise SystemExit(results[-1]['exit_code'])
