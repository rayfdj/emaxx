from pathlib import Path
import hashlib, json, subprocess, sys, time
p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/coding-repair/emaxx'
read = lambda name: json.loads((p / name).read_text())
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
assert all(stage['exit_code'] == 0 for stage in read('source240-validation-result.json'))
assert read('source240-broad-audit.json')['passed'] == 944
assert read('source240-ordinary-and-report-audit.json')['ordinary_processes_verified'] == 8
for name, entry in read('source240-ordinary-artifacts.json').items():
    assert sha(Path(name)) == entry['sha256'] == sha(Path(entry['immutable_copy']))
fixtures = read('source238-ordinary-comparisons-command.json')['fixtures']
assert len(fixtures) == len(set(fixtures)) == 57
command = [sys.executable, str(p / 'compare-source230-fixtures.py'), 'source240', str(root), *fixtures]
with (p / 'source240-ordinary-comparisons-command.json').open('x') as f:
    json.dump(dict(command=command, fixtures=fixtures,
                   qualification='All 57 prior ordinary comparisons, unchanged, in addition to the four already passing new coding/copy fixtures. Same normal -Q entry points and C locale. No pinned Darwin or performance claim.'), f, indent=2)
start = time.monotonic()
with (p / 'source240-ordinary-comparisons.log').open('x') as log:
    result = subprocess.run(command, cwd=root, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
record = dict(exit_code=result.returncode, elapsed_seconds=time.monotonic() - start, fixtures=57)
with (p / 'source240-ordinary-comparisons-result.json').open('x') as f:
    json.dump(record, f, indent=2)
results = [dict(command=command, **record)]
if result.returncode == 0:
    for name in ['test-source240-controls.py', 'test-source240-broad.py']:
        command = [sys.executable, str(p / name), '240', 'release']
        start = time.monotonic()
        result = subprocess.run(command, stdin=subprocess.DEVNULL)
        results.append(dict(command=command, exit_code=result.returncode, elapsed_seconds=time.monotonic() - start))
        if result.returncode:
            break
with (p / 'source240-release-and-ordinary-result.json').open('x') as f:
    json.dump(results, f, indent=2)
raise SystemExit(results[-1]['exit_code'])
