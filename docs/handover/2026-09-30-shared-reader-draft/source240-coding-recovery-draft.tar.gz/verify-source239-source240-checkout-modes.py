from pathlib import Path
import hashlib, io, json, os, subprocess, tarfile, tempfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
candidate = p.parent / 'recovered-2026-09-30/coding-repair/emaxx'
sha = lambda data: hashlib.sha256(data).hexdigest()
base = '6ee4bd1b9e79cef790c6dc88a64ef1896a2679f2'
base_manifest = json.loads((p / 'source238-manifest.json').read_text())
archive = subprocess.check_output(['git', 'archive', base, '--', *sorted(base_manifest)], cwd=root)
records = []
for source, count in [('source239', 452), ('source240', 454)]:
    manifest = json.loads((p / (source + '-manifest.json')).read_text())
    assert len(manifest) == count
    patch = p / (source + '-incremental.patch')
    with tempfile.TemporaryDirectory(prefix='emaxx-coding-patch-', dir='/private/tmp') as temp:
        temp = Path(temp)
        with tarfile.open(fileobj=io.BytesIO(archive)) as t:
            for member in t:
                assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
                path = temp / member.name
                if member.isdir():
                    path.mkdir(parents=True, exist_ok=True)
                else:
                    assert member.isfile()
                    path.parent.mkdir(parents=True, exist_ok=True)
                    path.write_bytes(t.extractfile(member).read())
                    os.chmod(path, 0o755 if member.mode & 0o111 else 0o644)
        for name, digest in base_manifest.items():
            assert sha((temp / name).read_bytes()) == digest
        subprocess.run(['git', 'apply', '--check', str(patch)], cwd=temp, check=True)
        subprocess.run(['git', 'apply', str(patch)], cwd=temp, check=True)
        for name, digest in manifest.items():
            assert sha((temp / name).read_bytes()) == digest, (source, name)
            assert ((temp / name).stat().st_mode & 0o777) == ((candidate / name).stat().st_mode & 0o777), name
    records.append(dict(source=source, inputs=count, patch_sha256=sha(patch.read_bytes()),
                        base_commit=base, file_bytes_and_modes='exact replay'))
current = json.loads((p / 'source240-manifest.json').read_text())
assert all(sha((candidate / name).read_bytes()) == digest for name, digest in current.items())
with (p / 'source239-source240-patch-replay-audit.json').open('x') as f:
    json.dump(dict(status='exact', candidates=records, qualification='Portable draft replay using Git checkout modes (0644/0755). The first audit extracted archive mode 0664 verbatim and failed on .cargo/config.toml before writing a passing receipt; its script is retained. This corrects extraction setup, not source bytes or executable bits. Not validation of runtime behavior. Source239 has two failed new controls; source240 is separately under validation. Task branch runtime remains source238.'), f, indent=2)
print(json.dumps(records, indent=2))
