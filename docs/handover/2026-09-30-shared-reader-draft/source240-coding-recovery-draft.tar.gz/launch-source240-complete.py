from pathlib import Path
import hashlib, json, subprocess, sys
p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/coding-repair/emaxx'
manifest = json.loads((p / 'source240-manifest.json').read_text())
assert all(hashlib.sha256((root / name).read_bytes()).hexdigest() == digest for name, digest in manifest.items())
assert all(stage['exit_code'] == 0 for stage in json.loads((p / 'source240-validation-result.json').read_text()))
for suffix, helper in [('full-gate', 'run-source240-full-gate.py'),
                       ('release-and-ordinary', 'run-source240-release-and-ordinary.py')]:
    command = [sys.executable, str(p / helper)]
    launch = p / ('source240-' + suffix + '-launch.json')
    assert not launch.exists()
    with (p / ('source240-' + suffix + '-driver.log')).open('x') as log:
        process = subprocess.Popen(command, cwd=root, stdin=subprocess.DEVNULL, stdout=log,
                                   stderr=subprocess.STDOUT, start_new_session=True)
    record = dict(pid=process.pid, command=command, source_manifest='source240-manifest.json',
                   helper_sha256=hashlib.sha256((p / helper).read_bytes()).hexdigest(),
                   qualification='Detached validation of immutable isolated source240. Read the result receipt before claiming completion; do not restart active processes.')
    with launch.open('x') as f:
        json.dump(record, f, indent=2)
    print(json.dumps(record), flush=True)
