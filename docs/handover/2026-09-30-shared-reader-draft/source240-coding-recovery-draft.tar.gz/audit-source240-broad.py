from pathlib import Path
import ast, hashlib, json, re
p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/coding-repair/emaxx'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'audit-source238-release.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'audit_log')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<raw-verdict-auditor>', 'exec'))
manifest = read('source240-manifest.json')
assert len(manifest) == 454 and all(sha(root / name) == digest for name, digest in manifest.items())
stages = read('source240-validation-result.json')
assert len(stages) == 6 and all(stage['exit_code'] == 0 for stage in stages)
command, result = read('source240-gate-broad-command.json'), read('source240-gate-broad-result.json')
assert result['exit_code'] == 0 and result['source_unchanged']
assert sha(p / 'source240-gate-libtest') == command['binary_sha256']
inventory = [line[:-6] for line in (p / 'source240-gate-inventory.txt').read_text().splitlines() if line.endswith(': test')]
assert len(inventory) == len(set(inventory)) == 2992
prefixes = ('lisp::bytecode::', 'lisp::native_comp::runtime::', 'lisp::primitives::pdumper::',
            'lisp::primitives::tests::', 'lisp::reader::', 'lisp::types::')
names = command['selected_inventory']
assert len(names) == 944 and names == [name for name in inventory if name.startswith(prefixes)]
assert set(read('source238-release-broad-command.json')['selected_inventory']) <= set(names)
assert command['command'][1:] == names + ['--exact', '--nocapture', '--test-threads=1']
audit_log(names, (p / 'source240-gate-broad.log').read_text(), [])
audit = dict(status='all affected gate modules pass', passed=944, failed=0, ignored=[], names=names,
             inventory=2992, inputs_verified=454, binary_sha256=command['binary_sha256'], goal_complete=False,
             qualification='Every previous affected-module control plus four new GNU-backed coding/copy controls. Full macOS, Linux, frozen, terminal and release validation remain separate; no performance claim.')
with (p / 'source240-broad-audit.json').open('x') as f:
    json.dump(audit, f, indent=2)
print(json.dumps({key: audit[key] for key in ['status', 'passed', 'failed', 'inventory']}, indent=2))
