from pathlib import Path
import copy, hashlib, json, re

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/coding-repair/emaxx'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read('source240-manifest.json')
assert len(manifest) == 454 and all(sha(root / name) == digest for name, digest in manifest.items())
for stage in ['ordinary-build', 'ordinary-image']:
    result = read('source240-' + stage + '-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
    assert not re.search(r'^warning(?:\[.*\])?:', (p / ('source240-' + stage + '.log')).read_text(), re.M)
artifacts = read('source240-ordinary-artifacts.json')
for name, entry in artifacts.items():
    assert sha(Path(name)) == entry['sha256'] == sha(Path(entry['immutable_copy']))
fixtures = ['canonical-coding-character-storage', 'canonical-coding-identity-storage',
            'canonical-coding-conversion-storage', 'copied-canonical-string-storage']
for fixture in fixtures:
    stem = 'source240-ordinary-' + fixture
    comparison = read(stem + '-comparison.json')
    assert comparison['passed'] and comparison['exact_match']
    program = (root / ('tests/fixtures/' + fixture + '.el')).read_text()
    expected = (root / ('tests/fixtures/' + fixture + '.expected')).read_bytes().rstrip(b'\n')
    for editor in ['gnu', 'emaxx']:
        result = read(stem + '-' + editor + '.result.json')
        command = read(stem + '-' + editor + '.command.json')
        assert result == comparison['outcomes'][editor]
        assert result['exit_code'] == 0 and not result['timed_out'] and result['expected_output']
        assert result['source_unchanged'] and result['inputs_unchanged']
        assert command['environment_override']['LANG'] == command['environment_override']['LC_ALL'] == 'C'
        assert command['command'][1:] == ['-Q', '--batch', '--eval', '(prin1 ' + program + ')']
        assert command['fixture_mode'] == 'print-return-value'
        assert all(sha(Path(name)) == digest for name, digest in command['inputs'].items())
        stdout = p / (stem + '-' + editor + '.stdout')
        assert stdout.read_bytes() == expected and sha(stdout) == result['stdout_sha256']
        assert (p / (stem + '-' + editor + '.stderr')).read_bytes() == b''
reports = {}
for editor in ['gnu', 'source238', 'source240']:
    stem = 'source240-character-report-' + editor
    result = read(stem + '-result.json')
    command = read(stem + '-command.json')
    assert result['inputs_unchanged']
    assert all(sha(Path(name)) == digest for name, digest in command['inputs'].items())
    assert sha(p / (stem + '.stdout')) == result['stdout_sha256']
    assert sha(p / (stem + '.stderr')) == result['stderr_sha256']
    if editor == 'source238':
        assert result['exit_code'] == 255 and not result['report_exists']
        assert not (p / (stem + '-report.json')).exists()
        assert b'Wrong type argument: character' in (p / (stem + '.stderr')).read_bytes()
        continue
    assert result['exit_code'] == 0 and result['report_exists']
    file = p / (stem + '-report.json')
    assert sha(file) == result['report_sha256']
    report = json.loads(file.read_bytes())
    assert report['runner'] == editor
    assert report['summary'] == dict(total=4, passed=1, failed=2, skipped=1, unexpected=1)
    assert report['file_status'] == 'loaded' and report['file_error'] is None
    assert [(row['name'], row['status'], row['expected']) for row in report['results']] == [
        ('character-report-expected-fail', 'failed', True), ('character-report-fail', 'failed', False),
        ('character-report-pass', 'passed', True), ('character-report-skip', 'skipped', True)]
    semantic = copy.deepcopy(report)
    semantic.pop('runner')
    for row in semantic['results']:
        assert isinstance(row['duration_ns'], int) and row['duration_ns'] >= 0
        row.pop('duration_ns')
        if row['status'] != 'passed':
            assert '\uf8ff' in row['message']
    reports[editor] = semantic
assert reports['gnu'] == reports['source240']
audit = dict(status='ordinary comparisons and character-bearing report repair verified',
             fixtures=fixtures, ordinary_processes_verified=8, report_processes_verified=3,
             source238_report='exit 255, no report', source240_report='all four known outcomes and U+F8FF messages match GNU',
             report_comparison='All JSON fields except editor label and per-test duration are compared. Raw reports are retained unchanged; the original compatibility runner is unchanged.',
             artifacts=artifacts, inputs_verified=454, goal_complete=False,
             qualification='Four new ordinary -Q comparisons, not the full frozen inventory. The intentional unexpected failure remains unexpected; expected failures and skips are not passes. This repairs the reproduced U+F8FF report-writing failure, without claiming every possible report or coding system. GNU source/ABI matches but is not the pinned Darwin executable.')
with (p / 'source240-ordinary-and-report-audit.json').open('x') as f:
    json.dump(audit, f, indent=2)
print(json.dumps({key: audit[key] for key in ['status', 'ordinary_processes_verified', 'report_processes_verified', 'source238_report', 'source240_report']}, indent=2))
