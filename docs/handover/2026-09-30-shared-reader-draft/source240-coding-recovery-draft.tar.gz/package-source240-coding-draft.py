from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile
p = Path(__file__).parent.resolve()
out = p.parents[2] / 'docs/handover/2026-09-30-shared-reader-draft'
sha = lambda data: hashlib.sha256(data).hexdigest()
node = next(n for n in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
read = lambda name: json.loads((p / name).read_text())
allowed = {'.json', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.el', '.expected'}
patterns = [
    'source239-*', 'source240-manifest.json', 'source240-*.patch',
    'source240-validation-*', 'source240-validation.log',
    'source240-gate-*', 'source240-focused-audit.json', 'source240-broad-audit.json',
    'source240-ordinary-artifacts.json', 'source240-ordinary-and-report-audit.json',
    'source240-ordinary-build-*', 'source240-ordinary-build.log',
    'source240-ordinary-image-*', 'source240-ordinary-image.log',
    'source240-ordinary-canonical-coding-*', 'source240-ordinary-copied-canonical-*',
    'source240-character-report-*', 'character-report-probe.el',
    'coding-character-storage-probe.el', 'coding-identity-storage-probe.el',
    'coding-conversion-storage-probe.el', 'copied-canonical-string-storage-probe.el',
    'source240-full-gate-launch.json', 'source240-full-gate-command.json',
    'source240-release-and-ordinary-launch.json',
    'audit-source239-failure.py', 'audit-source240-*.py',
    'verify-source239-source240-*.py', 'check-source239.py', 'static-source239.py',
    'run-source239-*.py', 'test-source239-controls.py', 'build-source239.py',
    'check-source240.py', 'static-source240.py', 'run-source240-*.py',
    'test-source240-*.py', 'build-source240.py', 'launch-source240-complete.py',
    'diagnose-source240-character-reports.py', 'compare-source230-fixtures.py',
    Path(__file__).name,
]
for stage in ['check', 'fmt', 'clippy', 'diff']:
    patterns += ['source240-' + stage + '-*', 'source240-' + stage + '.log']
files = {str(file.relative_to(p)): file for pattern in patterns for file in p.glob(pattern)
         if file.is_file() and file.suffix in allowed}
failed = read('source239-failure-audit.json')
focused = read('source240-focused-audit.json')
broad = read('source240-broad-audit.json')
ordinary = read('source240-ordinary-and-report-audit.json')
assert failed['passed'] == 155 and len(failed['failed']) == 2
assert focused['passed'] == 160 and len(focused['ignored']) == 2
assert broad['passed'] == 944 and ordinary['ordinary_processes_verified'] == 8
assert all(stage['exit_code'] == 0 for stage in read('source240-validation-result.json'))
assert not any('driver.log' in name or 'source240-full-gate.log' in name or
               name.startswith('source240-release-') and not name.endswith('launch.json') for name in files)
package('source240-coding-recovery-draft', files,
        dict(prior_source239_failure=failed, patch_replay=read('source239-source240-patch-replay-audit.json'),
             focused=focused, broad=broad, ordinary_and_report=ordinary,
             full_macos_launch=read('source240-full-gate-launch.json'),
             release_launch=read('source240-release-and-ordinary-launch.json'),
             qualification='Separate unfinished 454-input draft; root branch runtime remains source238. Exact portable patches replay from 6ee4bd1b. Strict checks have zero warnings, 160 focused passes/two pre-existing ignores, 944 affected gate passes and four ordinary comparisons. The original failed draft and source238 report-writing failure remain failed evidence. The new report preserves all four known outcomes and U+F8FF messages. Full macOS, release/remaining ordinary, Linux, terminal, frozen and performance validation are not certified. Active logs are excluded.'))
