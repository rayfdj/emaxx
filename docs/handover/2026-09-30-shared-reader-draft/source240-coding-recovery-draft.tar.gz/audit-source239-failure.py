from pathlib import Path
import hashlib, json, re, shutil

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/coding-repair/emaxx'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read('source239-manifest.json')
assert len(manifest) == 452 and all(sha(root / name) == digest for name, digest in manifest.items())
c = read('source239-gate-controls-command.json')
r = read('source239-gate-controls-result.json')
assert r['exit_code'] == 101 and r['source_unchanged']
names = c['selected_inventory']
assert len(names) == len(set(names)) == 159
raw = (p / 'source239-gate-controls.log').read_text()
assert re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', raw, re.M) == [('FAILED', '155', '2', '2')]
starts = list(re.finditer(r'^test (\S+) \.\.\. ', raw, re.M))
assert [m[1] for m in starts] == names
ignored = ['tty::tty_differential_end_to_end', 'tty::tty_smoke_end_to_end']
failed = ['lisp::primitives::tests::coding_conversions_preserve_extended_characters_regions_and_eol',
          'lisp::primitives::tests::coding_encoders_preserve_gnu_identity_properties_and_byte_results']
for index, match in enumerate(starts):
    end = starts[index + 1].start() if index + 1 < len(starts) else raw.rindex('test result:')
    block = raw[match.end():end].split('\n\nfailures:')[0].strip()
    if match[1] in ignored:
        assert block.startswith('ignored,')
    else:
        assert re.search(r'(?:^|\s)' + ('FAILED' if match[1] in failed else 'ok') + '$', block), match[1]
for stage in ['check', 'fmt', 'clippy', 'diff', 'gate-build']:
    result = read('source239-' + stage + '-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
    raw = (p / ('source239-' + stage + '.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
    for line in raw.splitlines():
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        assert row.get('message', {}).get('level') not in ['warning', 'error']
assert len(read('source239-validation-result.json')) == 3
binary = p / 'source239-gate-libtest'
assert sha(binary) == c['binary_sha256']
images = sorted((p / 'fixture-images-source239').glob('loadup-' + sha(binary)[:8] + '-*.pdmp'))
assert len(images) == 1
retained = p / 'source239-failed-retained-inputs'
retained.mkdir()
files = []
for source in [binary, *images]:
    target = retained / source.name
    digest = sha(source)
    shutil.copy2(source, target)
    assert sha(source) == sha(target) == digest
    files.append(dict(original=str(source), retained=str(target), sha256=digest, bytes=target.stat().st_size))
audit = dict(status='failed', inputs_verified=452, strict_checks='zero-warning pass',
             passed=155, failed=failed, ignored=ignored, names=names, retained_files=files,
             unexecuted_stages=['ordinary-build', 'ordinary-image', 'ordinary-comparisons', 'gate-broad'],
             goal_complete=False,
             qualification='All previous selected controls and the full-range character/file-byte control pass. Two unchanged new GNU fixtures fail after propertize has already replaced extended characters with U+F8FF. Their expected bytes and original failure logs remain immutable. The shared copy/propertize diagnosis must be repaired before claiming this draft passes; it is not applied to the task branch.')
with (p / 'source239-failure-audit.json').open('x') as f:
    json.dump(audit, f, indent=2)
print(json.dumps(dict(status=audit['status'], passed=155, failed=failed, retained_files=files), indent=2))
