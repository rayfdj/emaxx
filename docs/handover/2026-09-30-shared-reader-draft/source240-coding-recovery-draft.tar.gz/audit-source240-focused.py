from pathlib import Path
import ast, hashlib, json, re, shutil

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/coding-repair/emaxx'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(n for n in ast.parse((p / 'audit-source238-release.py').read_text()).body
            if isinstance(n, ast.FunctionDef) and n.name == 'audit_log')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<raw-verdict-auditor>', 'exec'))
manifest = read('source240-manifest.json')
assert len(manifest) == 454 and all(sha(root / name) == digest for name, digest in manifest.items())
c = read('source240-gate-controls-command.json')
r = read('source240-gate-controls-result.json')
assert r['exit_code'] == 0 and r['source_unchanged']
names = c['selected_inventory']
assert len(names) == len(set(names)) == 162
assert set(names) - set(read('source239-gate-controls-command.json')['selected_inventory']) == {
    'lisp::primitives::tests::copied_and_propertized_strings_preserve_canonical_bytes_and_properties',
    'lisp::primitives::tests::propertize_preserves_existing_string_properties',
    'lisp::primitives::tests::text_property_copies_follow_add_text_properties_order'}
assert set(read('source239-gate-controls-command.json')['selected_inventory']) <= set(names)
ignored = ['tty::tty_differential_end_to_end', 'tty::tty_smoke_end_to_end']
audit_log(names, (p / 'source240-gate-controls.log').read_text(), ignored)
for stage in ['check', 'fmt', 'clippy', 'diff', 'gate-build']:
    result = read('source240-' + stage + '-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
    raw = (p / ('source240-' + stage + '.log')).read_text()
    assert not re.search(r'^warning(?:\[.*\])?:', raw, re.M)
    for line in raw.splitlines():
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        assert row.get('message', {}).get('level') not in ['warning', 'error']
binary = p / 'source240-gate-libtest'
assert sha(binary) == c['binary_sha256']
images = sorted((p / 'fixture-images-source240').glob('loadup-' + sha(binary)[:8] + '-*.pdmp'))
assert len(images) == 1
retained = p / 'source240-focused-retained-inputs'
retained.mkdir()
files = []
for source in [binary, *images]:
    target = retained / source.name
    digest = sha(source)
    shutil.copy2(source, target)
    assert sha(source) == sha(target) == digest
    files.append(dict(original=str(source), retained=str(target), sha256=digest, bytes=target.stat().st_size))
audit = dict(status='strict and focused gate pass', inputs_verified=454, strict_checks='zero-warning pass',
             passed=160, failed=0, ignored=ignored, names=names, retained_files=files,
             goal_complete=False,
             qualification='All source239 controls pass with unchanged fixtures, plus an added GNU-backed canonical-copy control and both existing property-copy controls. Copying uses actual string bytes and shallow property values. Full-range UTF-8/raw-text output, identity, conversion hooks, narrowed file regions and forced GC are covered. Ordinary, broad, release and complete platform validation remain separate. No general coding-system, arbitrary JSON-report, pinned Darwin or performance certification. Task branch still uses source238.')
with (p / 'source240-focused-audit.json').open('x') as f:
    json.dump(audit, f, indent=2)
print(json.dumps(dict(status=audit['status'], passed=160, ignored=ignored, retained_files=files), indent=2))
