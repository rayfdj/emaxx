from pathlib import Path
import json, subprocess, sys, time

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/coding-repair/emaxx'
stages = [
    ['check-source239.py', '239'],
    ['static-source239.py', '239'],
    ['test-source239-controls.py', '239', 'gate'],
    ['build-source239.py', '239'],
    ['compare-source230-fixtures.py', 'source239', str(root),
     'canonical-coding-character-storage', 'canonical-coding-identity-storage',
     'canonical-coding-conversion-storage'],
    ['test-source239-broad.py', '239', 'gate'],
]
results = []
for name, *args in stages:
    command = [sys.executable, str(p / name), *args]
    start = time.monotonic()
    result = subprocess.run(command, stdin=subprocess.DEVNULL)
    results.append(dict(command=command, exit_code=result.returncode,
                        elapsed_seconds=time.monotonic() - start))
    if result.returncode:
        break
with (p / 'source239-validation-result.json').open('x') as f:
    json.dump(results, f, indent=2)
raise SystemExit(results[-1]['exit_code'])
