from pathlib import Path
import hashlib, json, subprocess, sys
p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/string-ranges/emaxx'
tag = 'source' + sys.argv[1]
assert sys.argv[1].isdecimal()
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
files = [*root.joinpath('src').rglob('*.rs'), *root.joinpath('tests').rglob('*')]
files += [root / name for name in ['Cargo.toml', 'Cargo.lock', 'build.rs', 'tools/ttydiff.py', 'tools/fixtures/fieldnotes.org', 'tools/fixtures/fake_lsp_server.py']]
files += list(root.joinpath('.cargo').glob('*'))
files += [root / name for name in ['compat/emacs_compat_runner.el', 'src/lisp/bytecode/fixture-oracle-30.2.elc', 'src/lisp/bytecode/fixture-oracle2-30.2.elc', 'src/lisp/bytecode/fixture-oracle3-30.2.elc']]
manifest = {str(file.relative_to(root)): sha(file) for file in sorted(set(files)) if file.is_file()}
assert len(manifest) == 500
assert json.loads((p / (tag + '-manifest.json')).read_text()) == manifest
untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=root, text=True).splitlines()
extra = b''
for name in sorted(set(untracked) & set(manifest)):
    result = subprocess.run(['git', 'diff', '--no-index', '--binary', '--', '/dev/null', name], cwd=root, capture_output=True)
    assert result.returncode == 1 and not result.stderr
    extra += result.stdout
patches = {}
for label, base in [('portable-incremental', 'dbf1fbb2a7764af75b5c015e9da545bde78ad64c'),
                    ('portable-complete', '21d20f0eec08f3c013d5d3eb3bd6e9cfc16b3199')]:
    patch = subprocess.check_output(['git', 'diff', '--binary', base, '--', *sorted(manifest)], cwd=root) + extra
    target = p / (tag + '-' + label + '.patch')
    with target.open('xb') as f:
        f.write(patch)
    patches[label] = dict(base=base, sha256=sha(target), bytes=len(patch))
record = dict(inputs=500, patches=patches, candidate=str(root), goal_complete=False,
              qualification='Isolated range and numeric case repair atop source262. compare-strings reads actual canonical bytes, promotes unibyte octets before numeric casing, uses live buffer case tables, checks both strings before ranges, and clamps only too-large positive fixnum ends. Numeric casing uses exact table keys instead of raw-byte aliases. Four unchanged GNU fixtures preserve the ordinary negatives, including the failed main character-matrix process. Published source261 and frozen queued source262 remain unchanged. Strict and runtime evidence is separate; no completion or performance claim.')
with (p / (tag + '-freeze.json')).open('x') as f:
    json.dump(record, f, indent=2)
print(json.dumps(record, indent=2))
