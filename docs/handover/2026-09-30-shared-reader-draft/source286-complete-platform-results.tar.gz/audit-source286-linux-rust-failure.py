from pathlib import Path
import hashlib, json, re

p = Path(__file__).parent.resolve()
root = p / 'source286-linux-rust-artifacts/ordinary-linux-654aca96a1144aeeb9c302e77a982524072d4593/rust'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
read = lambda file: json.loads(file.read_text())
s = read(root / 'summary.json')
assert s['status'] == 'failed' and s['scope'] == 'full'
assert s['git'] == {'head': '654aca96a1144aeeb9c302e77a982524072d4593', 'dirty': False}
assert s['runs'] == s['cargo_stages'] == []
inventory = [line[:-6] for line in (root / 'inventory.txt').read_text().splitlines() if line.endswith(': test')]
assert len(inventory) == len(set(inventory)) == 3042 == s['inventory']['scheduled_tests']
assert hashlib.sha256(('\n'.join(inventory) + '\n').encode()).hexdigest() == s['inventory']['sha256']
verdicts = {}
groups = []
for group in ['eval_01', 'eval_02', 'eval_03', 'eval_04', 'eval_05', 'primitives']:
    raw = (root / ('repeat-01-' + group + '.log')).read_text()
    starts = list(re.finditer(r'^test (\S+) \.\.\. ', raw, re.M))
    assert len(starts) == s['inventory']['groups'][group]
    found = []
    for index, match in enumerate(starts):
        end = starts[index + 1].start() if index + 1 < len(starts) else raw.rindex('test result:')
        block = raw[match.end():end].split('\n\nfailures:')[0].strip()
        final = re.search(r'(?:^|\s)(ok|FAILED)$', block)
        assert final, (match[1], block)
        assert match[1] not in verdicts and match[1] in inventory
        verdicts[match[1]] = final[1]
        found.append(final[1])
    passed, failed = found.count('ok'), found.count('FAILED')
    summary = re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', raw, re.M)
    assert summary == [('FAILED' if failed else 'ok', str(passed), str(failed), '0')]
    groups.append(dict(group=group, passed=passed, failed=failed, ignored=0))
failed = [name for name, verdict in verdicts.items() if verdict == 'FAILED']
assert failed == ['lisp::primitives::tests::native_vector_and_closure_census_matches_gnu_word_layout']
assert sum(row['passed'] for row in groups) == 2285 and len(verdicts) == 2286
raw = (root / 'repeat-01-primitives.log').read_text()
assert 'oracle disagreed; program sent was:' in raw
actual = [json.loads(value) for value in re.findall(r'^  left: (".*")$', raw, re.M)]
expected = [json.loads(value) for value in re.findall(r'^ right: (".*")$', raw, re.M)]
assert len(actual) == len(expected) == 1
assert actual[0].startswith('(((0 -9)') and expected[0].startswith('(((0 0)')
assert actual[0].replace('(((0 -9)', '(((0 0)', 1) == expected[0]
assert actual[0] == read(p / 'source272-linux-rust-failure-audit.json')['actual_gnu_output'][1]
for name in ['bytecode_direct_dispatch_preserves_gnu_stack_arithmetic_and_branches',
             'native_printed_string_constants_keep_full_character_codes_and_sharing',
             'printer_preserves_full_character_codes_in_strings_buffers_and_callbacks',
             'read_from_string_preserves_gnu_range_error_arguments_and_order',
             'reader_consumes_internal_character_bytes_without_host_text_loss']:
    assert verdicts['lisp::primitives::tests::' + name] == 'ok'
retained = root / 'retained-inputs'
record = read(retained / 'manifest.json')
assert record['status'] == 'retained' and record['gate_status'] == 'failed'
assert record['gate_summary_sha256'] == sha(root / 'summary.json')
assert len(record['files']) == 2
for entry in record['files']:
    file = retained / entry['artifact']
    assert file.stat().st_size == entry['bytes'] and sha(file) == entry['sha256']
assert sha(retained / 'libtest') == s['test_binary']['sha256']
terminal = read(p / 'source286-linux-rust-terminal-state.json')
assert terminal['status']=='completed' and terminal['conclusion']=='failure' and terminal['headSha']==s['git']['head']
downloaded_files = {str(f.relative_to(root.parent)): sha(f) for f in root.parent.rglob('*') if f.is_file()}
unstarted = sorted(set(inventory) - set(verdicts))
assert len(unstarted) == 756
oracle_root = root.parent / 'oracle-inputs'
oracle = read(oracle_root / 'manifest.json')
verification = read(oracle_root / 'verification.json')
assert oracle['status'] == 'captured' and oracle['source_tracked_changes'] == []
assert oracle['source_commit'] == '636f166cfc86aa90d63f592fd99f3fdd9ef95ebd'
assert verification['status'] == 'unchanged' and verification['files_verified'] == 4
assert verification['capture_manifest_sha256'] == sha(oracle_root / 'manifest.json')
assert [row['artifact'] for row in oracle['files']] == ['emacs','emacs.pdmp','config.h','Makefile']
for entry in oracle['files']:
    file = oracle_root / entry['artifact']
    assert sha(file) == entry['sha256'] and file.stat().st_size == entry['bytes']
assert oracle['files'][0]['sha256'] == '5e1721732427d69d8af63211f1e3833ec21e40f97f4b7f6cd4cb224b72cebfcf'
assert oracle['files'][1]['sha256'] == 'bf4974228f3b3ea4374cec75a38eeb2bd0e7dd944da5bec4e6ad0387092502ae'
audit = dict(status='failed', source_commit=s['git']['head'], run_id=37254821073,
             library_passed=2285, library_failed=1, library_ignored=0,
             unstarted_library_tests=unstarted, unstarted_cargo_stages=['bins', 'integration'],
             failed_tests=failed, groups=groups, raw_verdicts=verdicts,
             actual_gnu_output=actual, expected_fixture_output=expected,
             binary_sha256=s['test_binary']['sha256'], retained_files=record['files'],
             oracle_capture=oracle, oracle_after_verification=verification, goal_complete=False,
             downloaded_files=downloaded_files,
             qualification='The helper asserts GNU output before creating or evaluating Emaxx. The single failure is the existing GNU vector census reference assertion: the first empty-vector sample is-9 rather than0; all later samples match. Its actual GNU output is byte-identical to the source272 failure. The pinned GNU executable,dump,configuration and Makefile were retained before the gate and verified unchanged afterward. The cause remains unresolved and the expectation is unchanged. All four preceding printer/reader controls and the new bytecode direct-dispatch control pass on Linux. The remaining756 library names (including two existing ignores) and both Cargo stages never run. This failed full run is not certified by selected or performance results.')

with (p / 'source286-linux-rust-failure-audit.json').open('x') as f:
    json.dump(audit, f, indent=2)
print(json.dumps({key: audit[key] for key in ['status', 'library_passed', 'library_failed', 'failed_tests']}, indent=2))
