from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve();out=p/'source286-publication-stage'
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda n:json.loads((p/n).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
assert read('source286-macos-rust-verification.json')['total_passed']==3131
assert read('source286-linux-rust-failure-audit.json')['library_passed']==2285
assert read('source286-linux-frozen-raw-integrity-audit.json')['outcomes']==7928
allowed={'.json','.log','.txt','.py','.h','.apparmor','.el','.expected'}
files={};excluded=[]
for directory in (p/'full-gate-source286',p/'source286-full-retained-gnu',p/'source286-linux-rust-artifacts',p/'source286-linux-frozen-artifacts'):
    for f in directory.rglob('*'):
        if not f.is_file():continue
        relative=str(f.relative_to(p))
        if f.suffix in allowed or f.name=='Makefile':files[relative]=f
        else:excluded.append(dict(path=relative,bytes=f.stat().st_size,sha256=sha(f.read_bytes())))
for f in p.iterdir():
    if f.is_file() and f.suffix in allowed and f.name.startswith(('source286-linux-','source286-macos-rust-','source286-full-rust-')):
        files[f.name]=f
for name in ('audit-source286-macos-rust-names.py','verify-source286-macos-rust.py','audit-source286-linux-rust-failure.py','audit-source286-linux-frozen.py','verify-complete-frozen-receipts279.py','package-source196-failure-and197-results.py','source286-manifest.json','source272-linux-rust-failure-audit.json',Path(__file__).name):
    files[name]=p/name
oracle=read('source286-full-retained-gnu/manifest.json')
for item in oracle['files']:
    assert sha(Path(item['original']).read_bytes())==sha((p/'source286-full-retained-gnu'/item['artifact']).read_bytes())==item['sha256']
scope=dict(status='complete macOS Rust and Linux evidence; explicit Linux Rust failure',
           macos_rust=read('source286-macos-rust-verification.json'),linux_rust=read('source286-linux-rust-failure-audit.json'),
           linux_frozen=read('source286-linux-frozen-raw-integrity-audit.json'),excluded_binaries=excluded,
           macos_gnu_inputs_verified_after_rust=True,
           qualification='Exact runtime654aca96:3131 macOS Rust passes/two existing ignores including native artifact identity; all7928 Linux frozen outcomes match in519 files/1038 successful processes. Linux Rust remains failed after2285 passes on the same GNU first empty-vector census assertion(-9 versus0), before Emaxx in that control. The new opcode fixture passes;756 library names and both Cargo stages never run. Current macOS frozen/terminal supervisor remains live and those unfinished logs are excluded. GNU original and retained inputs are checked here without impersonating the supervisor final verification. These results do not certify source288 or complete the architecture/performance goal.',goal_complete=False)
package('source286-closed-rust-linux',files,scope)
