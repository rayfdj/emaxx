from pathlib import Path
import ast, gzip, hashlib, io, json, tarfile

p = Path(__file__).parent.resolve()
out = p / 'source286-publication-stage'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
node = next(node for node in ast.parse((p / 'package-source196-failure-and197-results.py').read_text()).body
            if isinstance(node, ast.FunctionDef) and node.name == 'package')
exec(compile(ast.Module(body=[node], type_ignores=[]), '<portable-packager>', 'exec'))
queue = read('source286-full-queue-result.json')
assert queue['status'] == 'complete macOS processes finished; raw evidence requires audit'
assert queue['results'][-1]['stage'] == 'oracle-verify' and queue['results'][-1]['exit_code'] == 0
assert read('source286-macos-terminal-audit.json')['inputs_verified'] == 522
previous = read('source286-publication-stage/source286-closed-rust-linux-manifest.json')
files = {}
for item in previous['files']:
    original = p / item['path']
    assert sha(original.read_bytes()) == item['sha256']
    files[item['path']] = original
excluded = list(previous['scope']['excluded_binaries'])
frozen = Path(read('source286-macos-frozen-audit.json')['raw_root'])
for file in frozen.rglob('*'):
    if not file.is_file():
        continue
    name = 'macos-frozen/' + str(file.relative_to(frozen))
    if name.startswith('macos-frozen/tools/') and file.name in ('cargo', 'rustc', 'rustdoc', 'rust-analyzer'):
        excluded.append(dict(path=name, bytes=file.stat().st_size, sha256=sha(file.read_bytes())))
    else:
        files[name] = file
allowed = {'.json', '.log', '.txt', '.py', '.h', '.el', '.expected'}
for file in p.iterdir():
    if file.is_file() and file.suffix in allowed and file.name.startswith(('source286-full-', 'source286-macos-')):
        files[file.name] = file
for file in (p / 'source286-full-retained-gnu').rglob('*'):
    if file.is_file() and (file.suffix in allowed or file.name == 'Makefile'):
        files[str(file.relative_to(p))] = file
for name in ('audit-source286-macos-frozen.py', 'audit-source286-macos-terminal.py',
             'queue-source286-full-macos.py', 'package-source286-closed-rust-linux.py', Path(__file__).name):
    files[name] = p / name
oracle = read('source286-full-retained-gnu/manifest.json')
verification = read('source286-full-retained-gnu/verification.json')
assert verification['status'] == 'unchanged' and verification['files_verified'] == 4
assert verification['capture_manifest_sha256'] == sha((p / 'source286-full-retained-gnu/manifest.json').read_bytes())
for item in oracle['files']:
    assert sha(Path(item['original']).read_bytes()) == sha((p / 'source286-full-retained-gnu' / item['artifact']).read_bytes()) == item['sha256']
scope = dict(status='closed source286 platform evidence with explicit failures',
             macos_rust=read('source286-macos-rust-verification.json'),
             macos_frozen=read('source286-macos-frozen-audit.json'),
             macos_terminal=read('source286-macos-terminal-audit.json'),
             linux_rust=read('source286-linux-rust-failure-audit.json'),
             linux_frozen=read('source286-linux-frozen-raw-integrity-audit.json'),
             final_macos_gnu_verification=verification, excluded_binaries=excluded,
             qualification='Exact654aca96:3131 macOS Rust passes/two existing ignores; all7928 Linux frozen outcomes match. macOS frozen remains failed on six existing feature-reporting skip diagnostics, with7915 matches and1038 successful processes. Linux Rust remains failed after2285 passes at the GNU first empty-vector reference assertion(-9 versus0), before Emaxx in that control;756 library names and both Cargo stages are unrun. Terminal outcomes and missing comparisons are exactly those in the separate complete raw audit. No failed or unrun case becomes a pass. These closed source286 results do not certify later drafts or the full architectural/performance goal.', goal_complete=False)
package('source286-complete-platform-results', files, scope)
