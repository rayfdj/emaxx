from pathlib import Path
import ast,gzip,hashlib,io,json,tarfile
p=Path(__file__).parent.resolve();root=p.parents[2];out=root/'docs/handover/2026-09-30-shared-reader-draft'
sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda n:json.loads((p/n).read_text())
node=next(n for n in ast.parse((p/'package-source196-failure-and197-results.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='package')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<portable-packager>','exec'))
a=read('source272-linux-frozen-raw-integrity-audit.json');assert a['raw_audit']['matching_outcomes']==7927 and a['raw_audit']['mismatching_outcomes']==1
files={};d=p/'source272-linux-frozen-artifacts'
for f in d.rglob('*'):
 if not f.is_file() or f.suffix=='.pdmp' or str(f.relative_to(d))=='oracle-inputs/emacs':continue
 assert not f.is_symlink();files[str(f.relative_to(p))]=f
for f in p.iterdir():
 if f.is_file() and f.name.startswith('source272-linux-frozen-') and f.suffix in {'.json','.log'}:files[f.name]=f
for n in ['source272-manifest.json','source272-linux-retention-preparation.json','retain-source272-linux.py','prepare-source272-frozen-failure-audit.py','verify-source272-frozen-failure-receipts.py','audit-source272-frozen-failure.py','dispatch-source272-linux.py','package-source196-failure-and197-results.py',Path(__file__).name]:assert (p/n).is_file(),n;files[n]=p/n
assert sum(n.endswith('.loaded') for n in files)==1038
package('source272-complete-linux-frozen-failure',files,dict(failure=a,qualification=a['qualification']))
