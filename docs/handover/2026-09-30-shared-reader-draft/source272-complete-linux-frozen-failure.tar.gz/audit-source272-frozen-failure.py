from pathlib import Path
import hashlib,json,subprocess,sys
p=Path(__file__).parent.resolve();root=p.parents[2]
d=p/'source272-linux-frozen-artifacts';raw=d/'compat/frozen-1790895076878508789-5621'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();read=lambda f:json.loads(f.read_text())
head='eb286e230b414fc753b37b4008566950b98fc867';run=36937049816
cmd=[sys.executable,'-B',str(p/'verify-source272-frozen-failure-receipts.py'),str(raw),head,str(run),str(p/'source272-linux-frozen-failure-audit.json')]
subprocess.run(cmd,cwd=root,check=True,stdout=subprocess.DEVNULL)
download=read(p/'source272-linux-frozen-download.json');assert download['conclusion']=='failure' and download['run_id']==run
assert len(download['files'])==5204 and sha(p/'source272-linux-frozen-artifact.zip')==download['archive_sha256']
assert set(download['files'])=={str(f.relative_to(d)) for f in d.rglob('*') if f.is_file()}
for n,h in download['files'].items():assert sha(d/n)==h,n
m=read(p/'source272-manifest.json');assert len(m)==510 and all(sha(root/n)==h for n,h in m.items())
o=read(d/'oracle-inputs/manifest.json');v=read(d/'oracle-inputs/verification.json')
assert o['status']=='captured' and o['source_tracked_changes']==[] and o['source_commit']=='636f166cfc86aa90d63f592fd99f3fdd9ef95ebd'
assert v['status']=='unchanged' and v['files_verified']==4 and v['capture_manifest_sha256']==sha(d/'oracle-inputs/manifest.json')
assert {e['artifact'] for e in o['files']}=={'emacs','emacs.pdmp','config.h','Makefile'}
for e in o['files']:assert sha(d/'oracle-inputs'/e['artifact'])==e['sha256'] and (d/'oracle-inputs'/e['artifact']).stat().st_size==e['bytes']
assert o['files'][0]['sha256']=='5e1721732427d69d8af63211f1e3833ec21e40f97f4b7f6cd4cb224b72cebfcf'
a=read(p/'source272-linux-frozen-failure-audit.json')
r=dict(status=a['status'],run_id=run,commit=head,raw_audit=a,archive_members=5204,archive_sha256=download['archive_sha256'],source_inputs_verified=510,actual_gnu_inputs=o,actual_gnu_verification=v,goal_complete=False,qualification='All519 files/7928 paired outcomes/1038 successful processes/raw execution hashes and downloaded members verified. Exactly one unexpected GNU Eglot completion timeout differs; Emaxx has7670 passes/47 expected failures/211 skips and no unexpected outcome. This full comparison remains failed. The same failure signature occurred in source244; no cause or external-tool fix is inferred, no timeout changes and no pass-after-retry claim. Source276 allocator draft and all performance goals remain separate.')
with (p/'source272-linux-frozen-raw-integrity-audit.json').open('x') as f:json.dump(r,f,indent=2)
print(json.dumps({k:r[k] for k in ['status','run_id','commit','archive_members','source_inputs_verified']},indent=2))
