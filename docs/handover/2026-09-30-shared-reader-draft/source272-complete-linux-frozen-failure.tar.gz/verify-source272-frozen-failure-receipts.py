from pathlib import Path
import hashlib,json,re,sys
root=Path(sys.argv[1]);head=sys.argv[2];run_id=int(sys.argv[3]);out=Path(sys.argv[4])
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
s=json.loads((root/'summary.json').read_text());lock=json.loads(Path('compat/oracle.lock.linux.json').read_text());manifest=Path('compat/oracle_tests_all_linux.txt')
expected={};current=None
for line in manifest.read_text().splitlines():
    m=re.fullmatch(r'(\S+): discovered=(\d+) selected=(\d+)',line)
    if m:
        current=m[1];assert current not in expected;expected[current]={'discovered':int(m[2]),'selected':int(m[3]),'names':[]}
    elif line.strip():
        assert current and line.startswith('  ');expected[current]['names'].append(line.strip())
assert len(expected)==519 and sum(v['selected'] for v in expected.values())==7928
assert all(len(v['names'])==v['selected']==len(set(v['names'])) for v in expected.values())
assert s['mode']=='frozen' and s['scope']=='Frozen' and s['name_filter'] is None
assert s['selector']==lock['selector_default']
assert len(s['files'])==len(set(s['files']))==519 and set(s['files'])==set(expected)
assert s['total_files']==519 and s['matching_files']==518 and s['mismatching_files']==1
assert s['matching_outcomes']==7927 and s['total_outcomes']==7928 and s['mismatching_outcomes']==1
failed_file='test/lisp/progmodes/eglot-tests.el'
failed_name='eglot-test-rust-completion-exit-function'
assert s['mismatches']==s['unsuccessful_files']==[failed_file]
fm=s['frozen_manifest'];assert fm['sha256']==sha(manifest) and fm['recorded_files']==fm['executed_files']==519 and fm['required_outcomes']==fm['compared_outcomes']==7928 and fm['historical_load_errors']==0
prov=s['provenance'];assert prov['subject_git_head']==head and not prov['subject_git_dirty']
assert prov['oracle_sha256']==lock['emacs_binary_sha256'] and prov['oracle_repo_commit']==lock['emacs_repo_commit'] and prov['oracle_native_compilation']
assert json.loads((root/'head.json').read_text())['commit']==head
counts={r:{k:0 for k in ['total','passed','failed','skipped','unexpected']} for r in ['emaxx','oracle']};processes=0;outcomes=0
for file,inventory in expected.items():
    directory=(root/file).with_suffix('.compat')
    c=json.loads((directory/'comparison.json').read_text())
    assert c['file']==file
    if file == failed_file:
        assert not c['matches'] and c['mismatching_outcomes']==1 and c['matching_outcomes']==51
        assert [i['kind'] for i in c['issues']]==['result_expectation','test_status','condition_type']
        assert [i['kind'] for i in c['execution_issues']]==['unexpected_outcome']
        assert all(failed_name in i['detail'] for i in c['issues']+c['execution_issues'])
    else:
        assert c['matches'] and not c['issues'] and not c['execution_issues'] and c['mismatching_outcomes']==0
    assert c['matching_outcomes']+c['mismatching_outcomes']==inventory['selected'];outcomes+=c['matching_outcomes']
    execution=json.loads((directory/'execution.json').read_text())
    assert execution['contract_sha256']==sha(root/'contract.json')
    assert all(sha(directory/name)==digest for name,digest in execution['sha256'].items())
    paired={}

    for runner in counts:
        report=json.loads((directory/(runner+'.json')).read_text())
        assert report['file']==file and report['file_error'] is None and report['file_status']=='loaded' and report['selector']==s['selector']
        assert len(report['discovered_tests'])==inventory['discovered']
        selected=report['selected_tests'];assert len(selected)==len(set(selected))==inventory['selected'] and set(selected)==set(inventory['names'])
        results=report['results'];assert len(results)==len(set(r['name'] for r in results))==len(selected) and {r['name'] for r in results}==set(selected)
        observed={k:sum(r['status']==k for r in results) for k in ['passed','failed','skipped']};observed.update(total=len(results),unexpected=sum(not r['expected'] for r in results))
        assert observed==report['summary'] and observed['unexpected']==(1 if file==failed_file and runner=='oracle' else 0)
        paired[runner]={r['name']:(r['status'],r['expected']) for r in results}
        if file==failed_file:
            row=next(r for r in results if r['name']==failed_name)
            if runner=='oracle':
                assert row['status']=='failed' and not row['expected'] and row['condition_type']=='jsonrpc-error'
                assert row['message']=='(jsonrpc-error "request id=2 failed:" (jsonrpc-error-message . "Timed out"))'
            else:
                assert row['status']=='passed' and row['expected']
        if file=='test/src/comp-tests.el':
            assert len(results)==177 and all(r['status']=='passed' and r['expected'] for r in results)
        for key,n in observed.items():counts[runner][key]+=n
        process=json.loads((directory/(runner+'.execution.json')).read_text())['process']
        assert process['exit_code']==0 and process['test_started'] and not process['timed_out'] and process['timeout_phase'] is None
        processes+=1
    differences=[name for name in paired['oracle'] if paired['oracle'][name]!=paired['emaxx'][name]]
    assert differences==([failed_name] if file==failed_file else [])
assert counts==s['runner_summaries'] and outcomes==7927 and processes==1038
result={'status':'failed: one GNU Eglot timeout differs from an Emaxx pass','run_id':run_id,'published_commit':head,'verified_files':len(expected),'matching_outcomes':outcomes,'mismatching_outcomes':1,'verified_outcomes':7928,'successful_processes':processes,'runner_summaries':counts,'pinned_oracle_sha256':prov['oracle_sha256'],'frozen_manifest':fm,'summary_sha256':sha(root/'summary.json'),'qualification':'All 519 files and 7928 paired outcomes were processed. Every inventory, raw execution hash, outcome, comparison issue and process is verified. The original compiler file passes all 177 tests in both editors. The sole mismatch is an unexpected GNU JSON-RPC timeout; no normalization or full pass is claimed. Existing expected failures and skips remain distinct from passes. Emaxx executable/image identities come from runner provenance. Actual GNU executable/dump/configuration/Makefile inputs are separately retained and verified by the wrapper audit. The macOS pin is adopted; final validation and performance requirements remain open.'}
with out.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result,indent=2))
