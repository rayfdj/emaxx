from pathlib import Path
p=Path(__file__).parent.resolve()
s=(p/'audit-source244-linux-frozen-failure.py').read_text()
s=s.replace('Binaries and images are identified by runner provenance, not downloaded executable bytes. Darwin pin and final performance requirements remain open.', 'Emaxx executable/image identities come from runner provenance. Actual GNU executable/dump/configuration/Makefile inputs are separately retained and verified by the wrapper audit. The macOS pin is adopted; final validation and performance requirements remain open.')
with (p/'verify-source272-frozen-failure-receipts.py').open('x') as f:f.write(s)
