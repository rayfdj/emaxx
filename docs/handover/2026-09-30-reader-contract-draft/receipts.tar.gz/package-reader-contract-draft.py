from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
checkout = p.parent / "recovered-2026-09-30/reader-contract/emaxx"
read = lambda name: json.loads((p / name).read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
manifest = read("source178-manifest.json")
assert len(manifest) == 360 and all(sha((checkout / name).read_bytes()) == digest for name, digest in manifest.items())
assert read("source178-patch-replay-audit.json")["status"] == "passed"
for tag, count in [("source177", 306), ("source178", 308)]:
    completed = read(tag + "-selected-validation-result.json")
    assert completed["all_completed"] and completed["source_unchanged"]
    assert all(item["exit_code"] == 0 and item["source_unchanged"] for item in completed["steps"])
    for profile in ["gate", "release"]:
        stem = tag + "-" + profile + "-selected"
        command = read(stem + "-command.json")
        names = command["selected_inventory"]
        assert len(names) == len(set(names)) == count
        log = (p / (stem + ".log")).read_text()
        assert re.findall(r"^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;", log, re.M) == [("ok", str(count), "0", "0")]
        starts = list(re.finditer(r"^test (\S+) \.\.\. ", log, re.M))
        assert sorted(item[1] for item in starts) == sorted(names)
        for index, item in enumerate(starts):
            end = starts[index + 1].start() if index + 1 < len(starts) else log.rindex("test result:")
            assert re.search(r"(?:^|\s)ok$", log[item.end():end].strip()), item[1]
        assert sha((p / (tag + "-" + profile + "-libtest")).read_bytes()) == command["binary_sha256"]
fixtures = ["input-decode-general", "input-decode-extra", "input-decode-pipeline",
            "input-decode-reader-contract", "input-decode-case-state", "input-decode-xt-setup",
            "input-decode-case-variants"]
for name in fixtures:
    comparison = read("source178-ordinary-" + name + "-comparison.json")
    assert comparison["passed"] and comparison["exact_match"], name
    for editor, outcome in comparison["outcomes"].items():
        assert outcome["exit_code"] == 0 and not outcome["timed_out"]
        assert outcome["inputs_unchanged"] and outcome["source_unchanged"] and outcome["stderr_hex"] == ""
        prefix = "source178-ordinary-" + name + "-" + editor
        assert sha((p / (prefix + ".stdout")).read_bytes()) == outcome["stdout_sha256"]
        assert (p / (prefix + ".stderr")).read_bytes() == b""
for name in ["input-decode-reader-contract", "input-decode-case-state", "input-decode-xt-mouse"]:
    assert not read("source177-ordinary-" + name + "-comparison.json")["passed"]

helpers = {"package-reader-contract-draft.py", "check-reader178.py", "static-reader178.py",
           "test-reader178.py", "build-reader178.py", "queue-source178-validation.py",
           "queue-source177-validation.py", "test-decoder177.py", "check-decoder.py",
           "static-decoder.py", "build-decoder.py", "compare-recovered-continuation-fixtures.py"}
suffixes = {".json", ".log", ".txt", ".py", ".patch", ".el", ".expected", ".stdout", ".stderr", ".d"}
files = {f.name: f for f in p.iterdir() if f.is_file() and f.suffix in suffixes
         and (f.name.startswith(("source177-", "source178-", "input-decode-reader-contract", "input-decode-case-state", "input-decode-case-variants", "input-decode-xt-mouse", "input-decode-xt-setup")) or f.name in helpers)}
out = root / "docs/handover/2026-09-30-reader-contract-draft"
out.mkdir(exist_ok=False)
inventory = []
with (out / "receipts.tar.gz").open("xb") as stream:
    with gzip.GzipFile(fileobj=stream, mode="wb", filename="", mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w") as archive:
            for name, f in sorted(files.items()):
                data = f.read_bytes()
                info = tarfile.TarInfo(name)
                info.mode = 0o644
                info.size = len(data)
                archive.addfile(info, io.BytesIO(data))
                inventory.append({"path": name, "bytes": len(data), "sha256": sha(data)})
with tarfile.open(out / "receipts.tar.gz", "r:gz") as archive:
    assert archive.getnames() == [item["path"] for item in inventory]
    for item in inventory:
        data = archive.extractfile(item["path"]).read()
        assert sha(data) == item["sha256"] and len(data) == item["bytes"]
data = (out / "receipts.tar.gz").read_bytes()
record = {
    "status": "isolated source178 reader repairs pass selected checks; frontend integration unfinished",
    "base_commit": "ebfdbf9547b76e23013f8ce70f417aed02a744c2",
    "source_manifest": "source178-manifest.json", "complete_patch": "source178-complete.patch",
    "verified_inputs": len(manifest), "gate_passed": 308, "release_passed": 308,
    "ordinary_exact_gnu_comparisons": len(fixtures), "ordinary_inventory": fixtures,
    "predecessor": "Source177 passes 306 gate and 306 release controls and four ordinary contracts, but both additional reader/case-state comparisons differ. Its XTerm event value is repaired, while the raw batch output still lacks GNU's terminal-control bytes; that whole-output comparison remains failed.",
    "remaining": "Share incremental reading with the terminal and minibuffer loops; review mouse prefixes/fallbacks, reader arguments, raw event bookkeeping and buffer/terminal switches. Complete new-source full validation remains required. Production remains separately validated source174.",
    "qualification": "All four formerly omitted embedded files are now included in source178's pre-run manifest. New cases were established with actual GNU runs; no valid original assertion, ignore, selector or timeout was weakened. GNU is source/ABI matched, not the frozen Darwin executable. No performance, architecture-completion or full-goal completion claim.",
    "archive": {"path": "receipts.tar.gz", "bytes": len(data), "sha256": sha(data)}, "files": inventory,
}
(out / "manifest.json").write_text(json.dumps(record, indent=2) + "\n")
print("Verified", len(inventory), "closed reader receipts;", len(data), "archive bytes")
