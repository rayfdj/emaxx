from pathlib import Path
import hashlib
import json
import subprocess

p = Path(__file__).resolve().parent
w = p.parent / 'recovered-2026-10-10/symbol-fields/emaxx'
gate = p / 'fields-draft5-edebug-owner'
source = json.loads((gate / 'source-after.json').read_text())
assert json.loads((gate / 'focused.json').read_text())['exit_code'] == 0
for name, row in source.items():
    path = w / name
    assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256'], name
    assert oct(path.stat().st_mode & 0o777) == row['mode'], name
before = subprocess.check_output(['git', 'diff', '--binary'], cwd=w)
assert before == (gate / 'tracked.patch').read_bytes()
with (p / 'fields-draft5.patch').open('xb') as stream:
    stream.write(before)


def replace(text, before, after):
    assert text.count(before) == 1, before[:120]
    return text.replace(before, after)


path = w / 'src/lisp/alloc/symbols.rs'
t = path.read_text()
t = replace(t, 'use super::super::types::{MarkBit, Value};', 'use super::super::types::{MarkBit, SymbolName, Value};\nuse std::cell::Cell;')
t = replace(t, '    pub(crate) plist: std::cell::Cell<Value>,', '''    pub(crate) plist: std::cell::Cell<Value>,
    /// Lisp_Symbol.val: a value word or an alias object, selected by state.
    pub(crate) payload: Cell<SymbolPayload>,
    pub(crate) flags: Cell<u8>,
    pub(crate) state: Cell<u8>,''')
marker = 'pub(super) const SYMBOL_CELL_SIZE: usize = std::mem::size_of::<SymbolCell>();'
implementation = '''// VALUE_PRESENT retains the existing distinction between an absent binding
// and a localized, explicitly void default until localized storage is moved.
const VALUE_PRESENT: u8 = 1;
const ALIAS: u8 = 2;
const PLAIN_STORE: u8 = 4;

#[derive(Clone, Copy)]
pub(crate) union SymbolPayload {
    value: Value,
    alias: SymbolName,
}

impl SymbolPayload {
    pub(crate) fn unbound() -> Self {
        Self { value: Value::Unbound }
    }
}

impl Default for SymbolPayload {
    fn default() -> Self {
        Self::unbound()
    }
}

impl SymbolCell {
    pub(crate) fn value(&self) -> Option<Value> {
        (self.state.get() & VALUE_PRESENT != 0).then(|| {
            // SAFETY: VALUE_PRESENT is set only with the value union member.
            unsafe { self.payload.get().value }
        })
    }

    pub(crate) fn set_value(&self, value: Value) {
        assert!(self.alias().is_none(), "plain store into a symbol alias");
        self.payload.set(SymbolPayload { value });
        self.state.set(self.state.get() | VALUE_PRESENT);
    }

    pub(crate) fn replace_bound_value(&self, value: Value) -> bool {
        if self.state.get() & VALUE_PRESENT == 0 {
            return false;
        }
        self.payload.set(SymbolPayload { value });
        true
    }

    pub(crate) fn take_value(&self) -> Option<Value> {
        let value = self.value()?;
        self.payload.set(SymbolPayload::unbound());
        self.state.set(self.state.get() & !VALUE_PRESENT);
        Some(value)
    }

    pub(crate) fn alias(&self) -> Option<SymbolName> {
        (self.state.get() & ALIAS != 0).then(|| {
            // SAFETY: ALIAS is set only with the alias union member.
            unsafe { self.payload.get().alias }
        })
    }

    pub(crate) fn set_alias(&self, target: SymbolName) {
        self.payload.set(SymbolPayload { alias: target });
        self.state.set(ALIAS);
    }

    pub(crate) fn clear_alias(&self) -> bool {
        if self.state.get() & ALIAS == 0 {
            return false;
        }
        self.payload.set(SymbolPayload::unbound());
        self.state.set(0);
        true
    }

    pub(crate) fn plain_store(&self) -> bool {
        self.state.get() & PLAIN_STORE != 0
    }

    pub(crate) fn set_plain_store(&self, plain: bool) {
        self.state.set(if plain {
            self.state.get() | PLAIN_STORE
        } else {
            self.state.get() & !PLAIN_STORE
        });
    }

    pub(crate) fn value_or_alias_root(&self) -> Option<Value> {
        self.value().or_else(|| self.alias().map(Value::Symbol))
    }
}

'''
t = replace(t, marker, implementation + marker)
t = replace(t, '//! epoch word. The function and plist are authoritative object fields;\n//! the value/redirect and enumeration adapters still live in interpreter\n//! tables and must move out before this migration is complete.', '//! epoch word. Name, value/alias, function, plist and flags are authoritative\n//! object fields. Per-interpreter enumeration and id adapters remain; they\n//! must be removed before this migration is complete.')
path.write_text(t)

path = w / 'src/lisp/types.rs'
t = path.read_text()
for indent in [20,16]:
    space = ' ' * indent
    marker = '\n' + space + 'plist: Cell::new(Value::Nil),'
    t = replace(t, marker, marker + '\n' + space + 'payload: Cell::new(Default::default()),\n' + space + 'flags: Cell::new(0),\n' + space + 'state: Cell::new(0),')
path.write_text(t)

path = w / 'src/lisp/eval/symbol_cells.rs'
t = path.read_text()
start = t.index('#[derive(Clone)]\nstruct SymbolCell')
end = t.index('/// A cell\'s value, alias target and flags', start)
t = t[:start] + '''#[derive(Clone, Default)]
struct SymbolCell {
    /// Enumeration metadata only; all Lisp payloads live in the symbol.
    symbol: Option<SymbolName>,
    plist_position: Option<NonZeroU32>,
    function_position: Option<NonZeroU32>,
    alias_position: Option<NonZeroU32>,
    position: Option<NonZeroU32>,
}

impl SymbolCell {
    fn value(&self) -> Option<Value> {
        self.symbol?.cell().value()
    }

    fn alias(&self) -> Option<SymbolName> {
        self.symbol?.cell().alias()
    }

    fn function(&self) -> Option<Value> {
        let function = self.symbol?.cell().function.get();
        (!function.is_nil()).then_some(function)
    }
}

''' + t[end:]
t = replace(t, '''            if let Some(alias) = cell.alias() {
                cell.payload = SymbolPayload { alias: copy(alias) };
            }
''', '')
t = replace(t, '        self.cell(symbol.id()).and_then(SymbolCell::value)', '        symbol.cell().value()')
t = replace(t, '''        let id = SymbolName::id_of(name)?;
        self.cell(id).and_then(SymbolCell::value)''', '        SymbolName::find(name)?.cell().value()')
t = replace(t, '''        self.existing_cell_mut(symbol.id())
            .is_some_and(|cell| cell.replace_bound_value(value))''', '        symbol.cell().replace_bound_value(value)')
t = replace(t, '''        // Callers resolve aliases before a plain store. The image installer
        // clears the old redirect explicitly before restoring a value.
        assert!(
            cell.alias_position.is_none(),
            "plain store into a symbol alias"
        );
        let previous = cell.value();
        cell.payload = SymbolPayload { value };
        if previous.is_none() {''', '''        let previous = symbol.cell().value();
        symbol.cell().set_value(value);
        if cell.position.is_none() {''')
start = t.index('    pub(crate) fn remove(&mut self, symbol: &SymbolName)')
end = t.index('    fn compact_if_sparse', start)
t = t[:start] + '''    pub(crate) fn remove(&mut self, symbol: &SymbolName) -> Option<Value> {
        let previous = symbol.cell().take_value();
        if let Some(cell) = self.existing_cell_mut(symbol.id())
            && cell.position.take().is_some()
        {
            self.bound -= 1;
        }
        previous
    }

    pub(crate) fn remove_by_name(&mut self, name: &str) -> Option<Value> {
        self.remove(&SymbolName::find(name)?)
    }

''' + t[end:]
start = t.index('    /// Interned symbols are rooted by the process obarray.')
end = t.index('    /// Remove weak side cells', start)
t = t[:start] + t[end:]
start = t.index('    #[cfg(test)]\n    pub(crate) fn map_values')
end = t.index('    // --- the function cell', start)
t = t[:start] + t[end:]
t = replace(t, '        self.cell(symbol.id()).and_then(SymbolCell::alias)', '        symbol.cell().alias()')
t = replace(t, '''        let id = SymbolName::id_of(name)?;
        self.cell(id).and_then(SymbolCell::alias)''', '        SymbolName::find(name)?.cell().alias()')
t = replace(t, '        self.cell(symbol.id()).is_some_and(|cell| cell.plain_store)', '        symbol.cell().plain_store()')
t = replace(t, '''        if let Some(cell) = self.existing_cell_mut(symbol.id()) {
            cell.plain_store = plain;
        }''', '        symbol.cell().set_plain_store(plain);')
t = replace(t, '''        let had_value = cell.take_value().is_some();
        let first_alias = cell.alias_position.is_none();
        cell.plain_store = false;
        cell.payload = SymbolPayload { alias: target };''', '''        let had_value = cell.position.take().is_some();
        let first_alias = cell.alias_position.is_none();
        symbol.cell().set_alias(target);''')
start = t.index('    #[cfg(test)]\n    pub(crate) fn clear_alias_by_name')
end = t.index('    pub(crate) fn aliases_len', start)
t = t[:start] + '''    #[cfg(test)]
    pub(crate) fn clear_alias_by_name(&mut self, name: &str) -> bool {
        SymbolName::find(name).is_some_and(|symbol| self.clear_alias(&symbol))
    }

    fn clear_alias(&mut self, symbol: &SymbolName) -> bool {
        let cleared = symbol.cell().clear_alias();
        if let Some(cell) = self.existing_cell_mut(symbol.id())
            && cell.alias_position.take().is_some()
        {
            self.aliases -= 1;
        }
        cleared
    }

''' + t[end:]
start = t.index('        match self.cell(symbol.id()) {', t.index('    pub(crate) fn snapshot'))
end = t.index('\n    /// Install a cell', start)
t = t[:start] + '''        SymbolCellSnapshot {
            value: symbol.cell().value(),
            alias: symbol.cell().alias(),
            flags: symbol.cell().flags.get(),
        }
    }
''' + t[end:]
t = t.replace('self.clear_alias(symbol.id())', 'self.clear_alias(symbol)')
t = replace(t, '                self.remove_by_name(symbol.as_str());', '                self.remove(symbol);')
t = replace(t, '''        let cell = self.cell_mut(symbol);
        cell.flags = snapshot.flags;
        cell.plain_store = false;''', '''        symbol.cell().flags.set(snapshot.flags);
        symbol.cell().set_plain_store(false);''')
t = replace(t, '''        self.cell(symbol.id())
            .is_some_and(|cell| cell.flags & flag != 0)''', '        symbol.cell().flags.get() & flag != 0')
start = t.index('    pub(crate) fn has_flag_by_name')
end = t.index("\nimpl<'a> IntoIterator", start)
t = t[:start] + '''    pub(crate) fn has_flag_by_name(&self, name: &str, flag: u8) -> bool {
        SymbolName::find(name).is_some_and(|symbol| self.has_flag(&symbol, flag))
    }

    pub(crate) fn set_flag(&mut self, symbol: &SymbolName, flag: u8) -> bool {
        symbol.cell().set_plain_store(false);
        let old = symbol.cell().flags.get();
        symbol.cell().flags.set(old | flag);
        old & flag == 0
    }

    pub(crate) fn set_flag_by_name(&mut self, name: &str, flag: u8) -> bool {
        self.set_flag(&SymbolName::intern_str(name), flag)
    }

    pub(crate) fn clear_flag_by_name(&mut self, name: &str, flag: u8) {
        if let Some(symbol) = SymbolName::find(name) {
            symbol.cell().flags.set(symbol.cell().flags.get() & !flag);
        }
    }
}
''' + t[end:]
t = replace(t, '''        let roots = cells.permanent_roots().collect::<Vec<_>>();
        assert!(!roots.contains(&old_value));
        assert!(roots.contains(&Value::Symbol(first)));
        let mut reached = crate::lisp::eval::LispReachability::default();
        reached.mark(&interp, &Value::Symbol(symbol));''', '''        let mut reached = crate::lisp::eval::LispReachability::default();
        reached.mark(&interp, &Value::Symbol(symbol));
        assert!(!reached.contains(&old_value));
        assert!(reached.contains(&Value::Symbol(first)));''')
t = replace(t, '''        let roots = cells.permanent_roots().collect::<Vec<_>>();
        assert!(!roots.contains(&old_value) && !roots.contains(&Value::Symbol(first)));
        assert!(roots.contains(&Value::Symbol(second)));
        let mut reached = crate::lisp::eval::LispReachability::default();
        reached.mark(&interp, &Value::Symbol(symbol));''', '''        let mut reached = crate::lisp::eval::LispReachability::default();
        reached.mark(&interp, &Value::Symbol(symbol));
        assert!(!reached.contains(&old_value) && !reached.contains(&Value::Symbol(first)));
        assert!(reached.contains(&Value::Symbol(second)));''')
t = replace(t, '            std::mem::size_of::<SymbolPayload>(),', '            std::mem::size_of_val(&symbol.cell().payload),')
t = replace(t, 'assert_eq!(std::mem::size_of::<SymbolCell>(), 40);', 'assert_eq!(std::mem::size_of::<SymbolCell>(), 24);')
t = replace(t, 'assert_eq!(std::mem::size_of::<crate::lisp::alloc::SymbolCell>(), 56);', 'assert_eq!(std::mem::size_of::<crate::lisp::alloc::SymbolCell>(), 72);')
t = t.replace('// Two words moved into the allocated header.', '// Payload and flag words moved into the allocated header.')
t = replace(t, '''//! symbols per editor. Function and plist words live on those allocated
//! objects and are read directly; this table retains only their enumeration
//! metadata. Value/alias payloads and flags still use the old dense-id table.
//! Those remaining payloads, indexes and the value/alias GC fixed-point walk
//! must be removed before allocated authority is complete. GC follows the
//! actual function/plist fields when it reaches a symbol object.''', '''//! symbols per editor. All mutable payloads and flags live on those objects
//! and ordinary field access reads them directly. This table retains only
//! enumeration metadata, whose dense-id indexes and weak cleanup still need
//! removal. GC follows the actual fields when it reaches a symbol; the
//! per-interpreter value/alias tracing and its fixed-point walk are gone.''')
t = t.replace('//! Remaining per-interpreter value and enumeration adapters.', '//! Remaining per-interpreter enumeration adapters.')
t = t.replace("/// Interned symbols, indexed by id.", "/// Interned enumeration metadata, indexed by id.")
path.write_text(t)

path = w / 'src/lisp/eval.rs'
t = path.read_text()
start = t.index('/// While symbols are shared between interpreter instances,')
end = t.index('/// Retire weak per-instance cells', start)
t = t[:start] + t[end:]
t = replace(t, '        while mark_reached_symbol_fields(self, &mut marked) {}\n', '')
t = replace(t, '            let mut changed = mark_reached_symbol_fields(self, &mut marked);', '            let mut changed = false;')
t = replace(t, '''        for value in self.globals.permanent_roots() {
            mark(&value);
        }
''', '')
t = replace(t, '            clone.globals.map_values(|value| c.copy(&value));\n', '')
marker = '        copied.install_copied_name(self.copy(&symbol.lisp_name()));'
t = replace(t, marker, marker + '''
        if let Some(alias) = symbol.cell().alias() {
            copied.cell().set_alias(self.copy_symbol(alias));
        } else if let Some(value) = symbol.cell().value() {
            copied.cell().set_value(self.copy(&value));
        }
        copied.cell().flags.set(symbol.cell().flags.get());
        copied.cell().set_plain_store(symbol.cell().plain_store());''')
marker = '                self.enqueue(&symbol.cell().function.get());'
t = replace(t, marker, '''                if let Some(root) = symbol.cell().value_or_alias_root() {
                    self.enqueue(&root);
                }
''' + marker)
path.write_text(t)

path = w / 'src/lisp/types/symbols.rs'
t = path.read_text()
marker = '            mark(&name.cell().function.get());'
t = replace(t, marker, '''            if let Some(root) = name.cell().value_or_alias_root() {
                mark(&root);
            }
''' + marker)
path.write_text(t)
print('Moved value/alias and flags into allocated symbols; removed duplicate field tracing. Uncompiled draft.')
