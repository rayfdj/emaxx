from pathlib import Path
import hashlib
import io
import json
import re
import subprocess
import tarfile
import tempfile

p = Path(__file__).resolve().parent
r = p.parents[2]
previous = p.parent / 'symbol-obarray-2026-10-09'
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
gate = p / 'fields-draft3-owned-fixtures'
source = read(gate / 'source.json')
assert len(source) == 566


def stage(directory, name, status=0, compiler=False):
    receipt = read(directory / (name + '.json'))
    assert receipt['exit_code'] == status
    for stream in ['stdout', 'stderr']:
        path = directory / (name + '.' + stream)
        assert sha(path) == receipt[stream + '_sha256']
        if compiler:
            assert not re.search(r'^warning(?:\[.*?\])?:', path.read_text(), re.M)
    return receipt


for name in ['fmt', 'check', 'clippy', 'diff']:
    stage(gate, name, compiler=True)
new = {
    'lisp::eval::tests::eval_02::separately_constructed_editors_own_canonical_symbols',
    'lisp::eval::tests::eval_02::symbol_function_and_plist_follow_allocated_identity',
}
profiles = {}
for profile, label, old in [('gate', 'fields-draft3-owned-fixtures', 'image-draft6-relocation'),
                            ('release', 'fields-draft3-release', 'image-draft6-release')]:
    directory = p / label
    assert read(directory / 'source.json') == read(directory / 'source-after.json') == source
    selection = read(directory / 'selection.json')
    assert len(selection) == 234 and set(selection) == set(read(previous / old / 'selection.json')) | new
    inventory = lambda path: [line[:-6] for line in path.read_text().splitlines() if line.endswith(': test')]
    names = inventory(directory / 'inventory.stdout')
    old_names = inventory(previous / old / 'inventory.stdout')
    assert len(names) == len(set(names)) == len(old_names) + 2
    assert set(names) == set(old_names) | new
    for name in ['build', 'inventory', 'focused']:
        stage(directory, name, compiler=name == 'build')
    verdicts = re.findall(r'^test (\S+) \.\.\. (ok|FAILED|ignored)\s*$', (directory / 'focused.stdout').read_text(), re.M)
    assert len(verdicts) == 234 and dict(verdicts) == dict.fromkeys(selection, 'ok')
    binary = read(directory / 'binary.json')
    assert sha(Path(binary['retained'])) == binary['sha256']
    profiles[profile] = dict(passed=234, failed=0, ignored=0, inventory=len(names), executable=binary)

failures = []
for label, name, detail in [
    ('fields-draft1-function-plist', 'clippy', 'Two collapsible_if findings; no tests executed. Fixed with equivalent let chains, without lint suppressions.'),
    ('fields-draft2-function-plist', 'focused', '229 passes and four failures: cross-editor expected symbol identity, shared-object field isolation, a relocated char-table purpose, and lookup in the new owner rather than the original host owner.'),
]:
    directory = p / label
    receipt = stage(directory, name, 101)
    failures.append(dict(directory=label, stage=name, exit_code=101, detail=detail,
                         source_sha256=sha(directory / 'source.json'),
                         receipt_sha256=sha(directory / (name + '.json')),
                         stdout_sha256=receipt['stdout_sha256'], stderr_sha256=receipt['stderr_sha256']))
raw = (p / 'fields-draft2-function-plist/focused.stdout').read_text()
failed_names = re.findall(r'^test (\S+) \.\.\. FAILED\s*$', raw, re.M)
assert len(failed_names) == len(set(failed_names)) == 4
assert 'test result: FAILED. 229 passed; 4 failed; 0 ignored;' in raw

patch = p / 'fields-draft3.patch'
assert patch.read_bytes() == (gate / 'tracked.patch').read_bytes()
base = '265d5ba3405cebe7692560cc29722be65d62237b'
available = set(subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', base], cwd=r, text=True).splitlines())
raw = subprocess.check_output(['git', 'archive', base, '--', *[name for name in source if name in available]], cwd=r)
with tempfile.TemporaryDirectory(prefix='emaxx-fields-replay-') as temporary:
    replay = Path(temporary)
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        for entry in archive.getmembers():
            if entry.isfile():
                target = replay / entry.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(archive.extractfile(entry).read())
                target.chmod(0o755 if entry.mode & 0o111 else 0o644)
    subprocess.run(['git', 'apply', str(patch)], cwd=replay, check=True)
    for name, row in source.items():
        assert sha(replay / name) == row['sha256'], name
        assert oct((replay / name).stat().st_mode & 0o777) == row['mode'], name
    fixture = (replay / 'tests/fixtures/symbol-allocated-fields.el').read_text()
    assert (p / 'allocated-symbol-fields-gnu.el').read_text() == '(prin1 ' + fixture.rstrip() + ')\n(terpri)\n'

oracle = read(p / 'allocated-symbol-fields-gnu.json')
assert oracle['exit_code'] == 0 and oracle['stdout'] == '(t t t t t t t t t)\n' and oracle['stderr'] == ''
assert (p / 'allocated-symbol-fields-gnu.stdout').read_text() == oracle['stdout']
assert (p / 'allocated-symbol-fields-gnu.stderr').read_text() == oracle['stderr']
assert sha(p / 'allocated-symbol-fields-gnu.el') == oracle['fixture_sha256']
assert sha(Path(oracle['command'][0])) == oracle['binary_sha256']

result = dict(checkpoint='unfinished allocated function/plist and private-constructor ownership draft3',
    status='strict and selected gate/release passed', source_inputs_verified=len(source), profiles=profiles,
    previous_controls_retained=232, new_controls=sorted(new),
    patch=dict(path=patch.name, sha256=sha(patch), base=base, replayed_source_inputs=len(source)),
    preserved_failures=failures, original_failed_tests=failed_names, gnu_predicates=9,
    physical_sizes=dict(allocated_symbol_bytes=56, remaining_metadata_bytes=40, combined_populated_symbol_bytes=96,
                        previous_combined_populated_symbol_bytes=96),
    qualification='All earlier inventory names and selected controls remain. Local fixtures now create distinct objects for editor isolation, build expected symbols in the tested owner, check the actual relocated char-table purpose plus its complete printed payload, and restore the original host owner before lifetime checks. The parked-editor GC survival and host weak reclamation requirements remain. GNU confirms independent objects and shared-object field mutation with the exact new fixture. This is selected validation only. Ordinary mode comparisons, full gates and physical allocation accounting remain open. Values/aliases/flags, IDs, enumeration and weak-field GC adapters are still per-interpreter; no total-memory or timing improvement is claimed. A later debugger-owner probe is separate and not certified here.',
    goal_complete=False)
with (p / 'fields-draft3-audit.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({key:result[key] for key in ['status','source_inputs_verified','profiles','patch']},indent=2))
