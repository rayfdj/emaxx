"""Sample unchanged locked GC bodies; diagnostic, never a timing certificate."""
from pathlib import Path
import importlib.util
import json
import os
import subprocess

p = Path(__file__).resolve().parent
r = p.parents[2]
g = p.parent / 'rebuilt-2026-10-01/emacs'
u = p.parent / 'recovered-2026-10-12/symbol-identity/emaxx'
out = p / 'source324-macos-locked-gc-profile'
out.mkdir(exist_ok=False)
spec = importlib.util.spec_from_file_location('core_perf', r / 'tools/core_runtime_perf.py')
perf = importlib.util.module_from_spec(spec)
spec.loader.exec_module(perf)
source = json.loads((p / 'source324-source.json').read_text())
production = {name: row for name, row in source.items() if name.startswith('src/') or name in ['Cargo.toml', 'Cargo.lock', 'build.rs']}
for name, row in production.items():
    assert perf.sha256(u / name) == row['sha256'] == perf.sha256(r / name), name
contract = perf.parse_json(perf.CONTRACT.read_text())
perf.validate_contract(contract)
case = next(case for case in contract['cases'] if case['id'] == 'explicit-gc')
assert case['n'] == 32
binaries = {'oracle': g / 'src/emacs', 'emaxx': u / 'target/release/emaxx'}
inputs = {str(path): perf.sha256(path) for exe in binaries.values() for path in [exe, exe.with_suffix('.pdmp')]}
inputs.update({str(path): perf.sha256(path) for path in [perf.CONTRACT, perf.WORKLOAD, r / 'tools/core_runtime_perf.py', Path(__file__)]})
state = dict(status='prepared', production_inputs=production, inputs=inputs, results=[], goal_complete=False,
    qualification='Diagnostic macOS whole-process samples including startup, preparation and result checking. Twelve repetitions of the unchanged locked32-collection body and100000-cell live graph; ordinary shared Lisp and strict result/mode validator. Concurrent correctness work makes elapsed times ineligible for performance claims. Retained identity5 release production bytes match source324; this is not a fresh clean-source platform gate or an explanation of the Linux baseline/candidate regression by itself.')
perf.write_json(out / 'state.json', state)
for runner, binary in binaries.items():
    directory = out / runner
    environment = perf.environment(out / 'environment' / runner, g)
    report = directory / 'report.json'
    argv = perf.command(binary, g) + ['-l', str(perf.WORKLOAD), '--eval',
        f'(core-perf-run "explicit-gc" 32 0 12 {perf.lisp(g)} nil {perf.lisp(report)})']
    sampler = []
    original_popen = subprocess.Popen
    sample_log = (out / (runner + '-sample.log')).open('xb')

    def with_sampler(*args, **kwargs):
        child = original_popen(*args, **kwargs)
        command = ['/usr/bin/sample', str(child.pid), '12', '1', '-mayDie', '-fullPaths', '-file', str(out / (runner + '-sample.txt'))]
        sampler.append((command, original_popen(command, stdout=sample_log, stderr=subprocess.STDOUT)))
        return child

    state.update(status='profiling ' + runner)
    perf.write_json(out / 'state.json', state)
    print('START', runner, flush=True)
    # Add only a sampling observer to the ordinary runner's process creation;
    # keep its command, environment, timeout, rusage and validation unchanged.
    subprocess.Popen = with_sampler
    try:
        process = perf.run_process(argv, directory, environment, contract['timeout_seconds'])
    finally:
        subprocess.Popen = original_popen
    assert len(sampler) == 1
    sample_command, sample_process = sampler[0]
    sample_exit = sample_process.wait(timeout=30)
    sample_log.close()
    observations = perf.validate_report(perf.parse_json(report.read_text()), process, case, contract,
        (directory / 'stdout.txt').read_text(), 0, 12)
    assert all(row['gc_count'] >= case['n'] for row in observations)
    row = dict(runner=runner, process=process, observations=observations,
        sample_command=sample_command, sample_exit=sample_exit,
        sample_exists=(out / (runner + '-sample.txt')).exists())
    state['results'].append(row)
    perf.write_json(out / 'state.json', state)
    print('END', runner, process['exit'], 'validated', len(observations), 'sample exit', sample_exit, flush=True)
assert all(perf.sha256(Path(name)) == digest for name, digest in inputs.items())
assert len({row['result'] for result in state['results'] for row in result['observations']}) == 1
state.update(status='closed; inspect profiles', inputs_unchanged=True,
    raw_files={str(path.relative_to(out)):perf.sha256(path) for path in out.rglob('*') if path.is_file() and path.name != 'state.json'})
perf.write_json(out / 'state.json', state)
