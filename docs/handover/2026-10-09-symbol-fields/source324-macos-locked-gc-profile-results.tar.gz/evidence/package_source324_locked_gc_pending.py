from pathlib import Path
import json

p = Path(__file__).resolve().parent
ns = {'__file__': str(p / 'package_source323_base.py')}
exec((p / 'package_source323_base.py').read_text(), ns)
ns['destination'] = p / 'pending-publication-source324'
audit = json.loads((p / 'source324-macos-locked-gc-profile/audit.json').read_text())
assert len(audit['rows']) == 2 and all(row['validated_observations'] == 12 for row in audit['rows'])
ns['package']('source324-macos-locked-gc-profile-results',
    [('evidence/source324-macos-locked-gc-profile', p / 'source324-macos-locked-gc-profile')],
    [('evidence/' + name, p / name) for name in ['profile_source324_locked_gc_macos.py', 'package_source323_base.py', Path(__file__).name]],
    dict(checkpoint='diagnostic sampling of the unchanged locked explicit-GC body', audit=audit,
        qualification='24 actual results and execution modes checked, all32 collections observed in every repetition. Whole-process macOS sample data includes startup/preparation/checking and multiple threads. Exact executable/image bytes retained locally and excluded explicitly from portable packaging. The largest selected Emaxx self rows are marking and the collection/sweep function. This is neither authoritative timing nor a causal explanation of the Linux10.54% pilot regression.'))
