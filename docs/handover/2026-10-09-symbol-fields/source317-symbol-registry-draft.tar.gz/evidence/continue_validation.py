from pathlib import Path
import json,subprocess,time,os,datetime
p=Path(__file__).resolve().parent
receipt=p/'registry-draft1-release/focused.json'; end=p/'registry-draft1-release/source-after.json'; state_path=p/'continued-validation-state.json'
assert not state_path.exists()
state=dict(status='waiting for release control receipt',pid=os.getpid(),started=datetime.datetime.now(datetime.timezone.utc).isoformat(),goal_complete=False)
def save():state_path.write_text(json.dumps(state,indent=2)+'\n')
save()
for _ in range(540):
 if receipt.exists():
  row=json.loads(receipt.read_text())
  if row['exit_code']!=0:raise RuntimeError('Release controls failed; ordinary run not started')
  if end.exists():break
 time.sleep(10)
else:raise RuntimeError('Release controls did not finish; ordinary run not started')
state['status']='running ordinary comparisons';save()
code=subprocess.run(['python3',str(p/'ordinary.py')],cwd=p).returncode
state.update(status='terminal; audit raw results',exit_code=code);save()
raise SystemExit(code)
