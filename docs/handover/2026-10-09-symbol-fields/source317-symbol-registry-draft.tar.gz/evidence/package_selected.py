from pathlib import Path
import gzip,hashlib,io,json,tarfile
p=Path(__file__).resolve().parent;w=p.parent/'recovered-2026-10-09/symbol-ownership/emaxx';destination=w/'docs/handover/2026-10-09-symbol-fields'
sha=lambda b:hashlib.sha256(b).hexdigest();audit=json.loads((p/'selected-audit.json').read_text());assert audit['replay_verified']
members={};excluded=[]
for path in sorted(p.rglob('*')):
 if not path.is_file():continue
 name=str(path.relative_to(p))
 if name.endswith('.tar.gz') or '__pycache__' in path.parts:continue
 data=path.read_bytes()
 if path.name in ['libtest','public-instances'] or path.suffix=='.pdmp':
  excluded.append(dict(path=str(path),bytes=len(data),sha256=sha(data)))
 else:members['evidence/'+name]=data
members['contents.json']=(json.dumps({name:dict(bytes=len(data),sha256=sha(data)) for name,data in members.items()},indent=2)+'\n').encode()
buffer=io.BytesIO()
with gzip.GzipFile(fileobj=buffer,mode='wb',mtime=0) as zipped:
 with tarfile.open(fileobj=zipped,mode='w') as archive:
  for name,data in sorted(members.items()):
   info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
data=buffer.getvalue();path=destination/'source317-symbol-registry-draft.tar.gz';assert not path.exists();path.write_bytes(data)
with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as archive:
 assert set(archive.getnames())==set(members)
 assert all(archive.extractfile(name).read()==data for name,data in members.items())
manifest=dict(checkpoint='source317 unapplied draft',base=audit['base'],archive=dict(path=path.name,bytes=len(data),sha256=sha(data),members=len(members)),selected_audit=audit,excluded_retained_inputs=excluded,qualification='Selected-only continuation of source316, not part of PR81 production runtime. All raw selected/ordinary observations, the first missing-source-layout failures, public-instance isolation negative, earlier launcher/setup failures, exact patch and helpers remain retained. Large executables/images are held locally and identified by hash. Full platform/frozen/timing validation and per-instance allocated-symbol authority remain open.',goal_complete=False)
(destination/'source317-symbol-registry-draft-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest['archive']))
