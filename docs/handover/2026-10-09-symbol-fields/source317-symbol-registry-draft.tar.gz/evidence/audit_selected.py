from pathlib import Path
import hashlib,io,json,re,subprocess,tarfile,tempfile
p=Path(__file__).resolve().parent;w=p.parent/'recovered-2026-10-09/symbol-registry/emaxx';base='4dcf9f6a9b651545a9fba49934131e5488f0a05d'
read=lambda f:json.loads(f.read_text());sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
source=read(p/'registry-draft1/source.json');assert len(source)==562
assert all(sha(w/name)==row['sha256'] and oct((w/name).stat().st_mode & 0o777)==row['mode'] for name,row in source.items())
new_test='lisp::types::tests::symbol_ids_resolve_across_serialized_host_threads_and_expire_with_the_object'
previous=p.parent/'symbol-ownership-2026-10-09'
controls=set(read(previous/'redirect-draft1/selection.json'));assert len(controls)==128
verdicts=lambda f:dict(re.findall(r'^test (\S+) \.\.\. (ok|FAILED|ignored)\s*$',f.read_text(),re.M))
first=p/'registry-draft1';failed=read(first/'focused.json');first_verdicts=verdicts(first/'focused.stdout')
selection=read(first/'selection.json');assert len(selection)==len(set(selection))==175 and controls<=set(selection)
assert failed['exit_code']==101 and len(first_verdicts)==175
assert sum(v=='ok' for v in first_verdicts.values())==143 and sum(v=='FAILED' for v in first_verdicts.values())==32
for stream in ['stdout','stderr']:assert sha(first/('focused.'+stream))==failed[stream+'_sha256']
for label in ['fmt','check','clippy','diff']:
 row=read(first/(label+'.json'));assert row['exit_code']==0
 for stream in ['stdout','stderr']:
  file=first/(label+'.'+stream);assert sha(file)==row[stream+'_sha256'];assert not re.search(r'^warning(?:\[.*?\])?:',file.read_text(),re.M)
replay=p/'registry-draft1-gnu-layout';replayed=read(replay/'receipt.json')
assert replayed['exit_code']==0 and replayed['source_unchanged'] and replayed['source_inputs']==source and replayed['selection']==selection
assert replayed['environment_overrides']==read(first/'environment.json')
assert replayed['binary']==read(first/'binary.json')
assert sha(Path(replayed['binary']['retained']))==replayed['binary']['sha256']
for stream in ['stdout','stderr']:assert sha(replay/('focused.'+stream))==replayed[stream+'_sha256']
assert verdicts(replay/'focused.stdout')==dict.fromkeys(selection,'ok')
assert '175 passed; 0 failed; 0 ignored;' in (replay/'focused.stdout').read_text()
profiles={}
for label,directory,prior in [('gate',first,previous/'redirect-draft1'),('release',p/'registry-draft1-release',previous/'redirect-draft1-release')]:
 inventory={line[:-6] for line in (directory/'inventory.stdout').read_text().splitlines() if line.endswith(': test')}
 old={line[:-6] for line in (prior/'inventory.stdout').read_text().splitlines() if line.endswith(': test')}
 assert inventory-old=={new_test} and old<=inventory
 assert read(directory/'source.json')==source
 if label=='release':
  assert read(directory/'source-after.json')==source and read(directory/'focused.json')['exit_code']==0
  assert read(directory/'selection.json')==selection
  assert verdicts(directory/'focused.stdout')==dict.fromkeys(selection,'ok')
  assert '175 passed; 0 failed; 0 ignored;' in (directory/'focused.stdout').read_text()
 binary=read(directory/'binary.json');assert sha(Path(binary['retained']))==binary['sha256']
 profiles[label]=dict(selected=175,inventory=len(inventory),binary_sha256=binary['sha256'])
ordinary=p/'registry-draft1-ordinary';summary=read(ordinary/'summary.json');assert summary==dict(processes=18,passed=18,failed=0,source_inputs=562,goal_complete=False)
assert read(ordinary/'source.json')==source
before=read(ordinary/'artifacts-before.json');assert before==read(ordinary/'artifacts-after.json')
for name,row in before.items():assert sha(Path(name))==row['sha256']
results=read(ordinary/'results.json');assert len(results)==18
pairs={}
for row in results:
 label='-'.join([row['fixture'],row['mode'],row['editor']]);process=read(ordinary/(label+'.json'))
 assert process['exit_code']==0 and not process['timed_out'] and process['timeout_seconds']==180
 for stream in ['stdout','stderr']:assert sha(ordinary/(label+'.'+stream))==process[stream+'_sha256']
 output=(ordinary/(label+'.stdout')).read_text();assert output==row['stdout'] and output.strip()==row['expected'] and row['passed']
 key=(row['fixture'],row['mode']);pairs.setdefault(key,{})[row['editor']]=output
 if row['mode'] in ['native','bytecode']:
  assert output.startswith('((t t t t) ' if row['fixture']=='symbol-redirect-lifetime' else '(t ')
assert len(pairs)==9 and all(set(pair)=={'gnu','emaxx'} and pair['gnu']==pair['emaxx'] for pair in pairs.values())
# The only change inside the previous test module is the additional host-entry
# lifetime test. No old selector, assertion, expected fixture or timeout changes.
old=subprocess.check_output(['git','show',base+':src/lisp/types.rs'],cwd=w,text=True)
current=(w/'src/lisp/types.rs').read_text();marker='#[cfg(test)]\nmod tests {'
old_tests=old[old.index(marker):];new_tests=current[current.index(marker):]
start=new_tests.index('    #[test]\n    fn symbol_ids_resolve_across_serialized_host_threads_and_expire_with_the_object')
end=new_tests.index('    #[test]\n',start+len('    #[test]\n'))
assert new_tests[:start]+new_tests[end:]==old_tests
patch=p/'registry-draft1.patch';assert patch.read_bytes()==subprocess.check_output(['git','diff','--binary'],cwd=w)
raw=subprocess.check_output(['git','archive',base,'--',*source],cwd=w)
with tempfile.TemporaryDirectory(prefix='emaxx-symbol-registry-replay-') as temporary:
 root=Path(temporary)
 with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
  for entry in archive.getmembers():
   if entry.isfile():
    target=root/entry.name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(archive.extractfile(entry).read());target.chmod(0o755 if entry.mode & 0o111 else 0o644)
 subprocess.run(['git','apply',str(patch)],cwd=root,check=True)
 assert all(sha(root/name)==row['sha256'] and oct((root/name).stat().st_mode & 0o777)==row['mode'] for name,row in source.items())
negative=read(p/'isolation-flushed/run.json');assert not negative['matches'] and negative['source_unchanged']
assert all(row['exit_code']==0 for row in negative['processes'])
assert (p/'isolation-flushed/gnu-first.stdout').read_text()=='(t owner-one)\n'
assert (p/'isolation-flushed/gnu-second.stdout').read_text()=='(t nil)\n'
assert (p/'isolation-flushed/emaxx-two-editors.stdout').read_text()=='(t owner-one)\n(nil owner-one)\n'
for row in negative['processes']:
 for stream in ['stdout','stderr']:assert sha(p/'isolation-flushed'/(row['label']+'.'+stream))==row[stream+'_sha256']
result=dict(checkpoint='source317 selected draft',base=base,source_inputs_verified=562,profiles=profiles,ordinary_processes=18,ordinary_comparisons=9,original_controls_retained=128,old_test_bodies_unchanged=True,patch_sha256=sha(patch),replay_verified=True,first_cohort=dict(passed=143,failed=32,ignored=0,reason='required GNU sibling source layout absent; original failures retained'),corrected_gate='The same binary, selection, input bytes/modes and environment overrides pass after installing the missing ../emacs link',ownership_negative='Source316 public editor calls share mutable symbol-name properties; first GNU answer (t owner-one), second (t nil), Emaxx second (nil owner-one). The registry cleanup does not claim to repair that separate allocated-symbol ownership gap.',goal_complete=False,qualification='Strict and selected gate/release evidence plus nine ordinary GNU comparisons. Full platform, frozen and timing evidence remain required. Earlier launch/setup failures and the public-instance ownership negative remain retained. This removes redundant registry/key storage, not the per-interpreter symbol field adapter or process-shared symbol pool.')
(p/'selected-audit.json').open('x').write(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
