use emaxx::batch::{BatchRunOptions, BatchRunOutcome, run_batch_with_large_stack};
fn main() {
    for path in std::env::args().skip(1) {
        let source = std::fs::read_to_string(&path).expect("read same Lisp input");
        let result = run_batch_with_large_stack(BatchRunOptions {
            no_loadup: true,
            no_site_lisp: true,
            eval: vec![source],
            ..Default::default()
        });
        assert_eq!(result.expect("ordinary owned editor entry"), BatchRunOutcome::Exit(0));
    }
}
