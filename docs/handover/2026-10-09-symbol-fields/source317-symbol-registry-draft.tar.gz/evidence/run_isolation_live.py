from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).resolve().parent/'isolation-live'
p.mkdir(exist_ok=False)
prior=p.parent/'isolation-baseline-lto'
w=p.parent.parent/'recovered-2026-10-09/symbol-ownership/emaxx'
gnu=p.parent.parent/'rebuilt-2026-10-01/emacs'
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
for name in ['first.el','second.el']:
 original=(prior/name).read_text()
 (p/name).write_text('(progn (setq purify-flag nil)\n'+original+')\n')
record=dict(setup_correction='The first public-API probe used a bare Emaxx whose purify-flag was still true, unlike the normal GNU instance. It failed on the first string property store and never observed a second editor. Set purify-flag nil explicitly in both editors before the otherwise unchanged forms. The earlier failure remains preserved.',executable={str(path):sha(path) for path in [prior/'public-instances',gnu/'src/emacs',gnu/'src/emacs.pdmp']},inputs={name:sha(p/name) for name in ['first.el','second.el']},processes=[],goal_complete=False)
(p/'run.json').write_text(json.dumps(record,indent=2)+'\n')
def run(label,command):
 start=time.monotonic()
 result=subprocess.run(command,cwd=w,env={**os.environ,'LANG':'C','LC_ALL':'C','EMAXX_GNU_SOURCE_DIRECTORY':str(gnu),'EMAXX_DUMP_SOURCE_DIRECTORY':str(gnu),'EMACS_TEST_DIRECTORY':str(gnu/'test')},capture_output=True,timeout=180)
 (p/(label+'.stdout')).write_bytes(result.stdout); (p/(label+'.stderr')).write_bytes(result.stderr)
 record['processes'].append(dict(label=label,command=command,exit_code=result.returncode,elapsed_seconds=time.monotonic()-start,stdout_sha256=sha(p/(label+'.stdout')),stderr_sha256=sha(p/(label+'.stderr'))))
 (p/'run.json').write_text(json.dumps(record,indent=2)+'\n')
 print(label,result.returncode,result.stdout.decode(errors='replace'),result.stderr.decode(errors='replace')[-2000:],flush=True)
 return result
first=run('gnu-first',[str(gnu/'src/emacs'),'-Q','--batch','-l',str(p/'first.el')])
second=run('gnu-second',[str(gnu/'src/emacs'),'-Q','--batch','-l',str(p/'second.el')])
subject=run('emaxx-two-editors',[str(prior/'public-instances'),str(p/'first.el'),str(p/'second.el')])
record.update(matches=subject.returncode==0 and subject.stdout==first.stdout+second.stdout,original_gnu_ok=first.returncode==second.returncode==0)
(p/'run.json').write_text(json.dumps(record,indent=2)+'\n')
print('MATCHES',record['matches'],flush=True)
