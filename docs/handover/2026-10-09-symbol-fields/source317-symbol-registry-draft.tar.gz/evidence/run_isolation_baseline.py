from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).resolve().parent/'isolation-baseline'
o=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/symbol-ownership-2026-10-09')
w=o.parent/'recovered-2026-10-09/symbol-ownership/emaxx'
gnu=o.parent/'rebuilt-2026-10-01/emacs'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
rows=[json.loads(line) for line in (o/'redirect-draft1-ordinary/build.stdout').read_text().splitlines() if line.startswith('{')]
libs=[row for row in rows if row.get('reason')=='compiler-artifact' and row.get('target',{}).get('name')=='emaxx' and row['target']['kind']==['lib']]
assert len(libs)==1
lib=Path(next(name for name in libs[0]['filenames'] if name.endswith('.rlib')))
source=json.loads((o/'redirect-draft1/source.json').read_text())
assert all(sha(w/name)==row['sha256'] for name,row in source.items())
paths=sorted({name for row in rows if row.get('reason')=='build-script-executed' for name in row.get('linked_paths',[])})
command=['rustc','--edition=2024','--extern','emaxx='+str(lib),'-L','dependency='+str(w/'target/release/deps')]
for path in paths: command+=['-L',path]
command += [str(p/'public_instances.rs'),'-o',str(p/'public-instances')]
record=dict(source_inputs=source,library=dict(path=str(lib),sha256=sha(lib),compiler_artifact=libs[0]),original_compile_failure='The initial unsaved rustc invocation used the stale top-level target/release/libemaxx.rlib. It failed with E0432/E0560 before executing any editor. The corrected invocation selects the actual library reported by the retained source316 Cargo build.',processes=[],goal_complete=False)
(p/'run.json').write_text(json.dumps(record,indent=2)+'\n')
def run(label,cmd):
 start=time.monotonic()
 result=subprocess.run(cmd,cwd=w,env={**os.environ,'LANG':'C','LC_ALL':'C','EMAXX_GNU_SOURCE_DIRECTORY':str(gnu),'EMAXX_DUMP_SOURCE_DIRECTORY':str(gnu),'EMACS_TEST_DIRECTORY':str(gnu/'test')},capture_output=True,timeout=180)
 (p/(label+'.stdout')).write_bytes(result.stdout); (p/(label+'.stderr')).write_bytes(result.stderr)
 row=dict(label=label,command=cmd,exit_code=result.returncode,elapsed_seconds=time.monotonic()-start,stdout_sha256=sha(p/(label+'.stdout')),stderr_sha256=sha(p/(label+'.stderr')))
 record['processes'].append(row); (p/'run.json').write_text(json.dumps(record,indent=2)+'\n')
 print(label,result.returncode,result.stdout.decode(errors='replace'),result.stderr.decode(errors='replace')[-1800:],flush=True)
 return result
assert run('compile',command).returncode==0
record['executable']={str(path):sha(path) for path in [p/'public-instances',gnu/'src/emacs',gnu/'src/emacs.pdmp']}
first=run('gnu-first',[str(gnu/'src/emacs'),'-Q','--batch','-l',str(p/'first.el')])
second=run('gnu-second',[str(gnu/'src/emacs'),'-Q','--batch','-l',str(p/'second.el')])
subject=run('emaxx-two-editors',[str(p/'public-instances'),str(p/'first.el'),str(p/'second.el')])
assert first.returncode==second.returncode==subject.returncode==0
record.update(matches=subject.stdout==first.stdout+second.stdout,source_unchanged=all(sha(w/name)==row['sha256'] for name,row in source.items()),qualification='Two sequential public owned Emaxx editor calls are compared with separate ordinary GNU editor instances executing exactly the same Lisp forms. Mutable symbol-name properties must not cross independent editor instances. This is a targeted ownership observation, not frozen or performance validation.')
(p/'run.json').write_text(json.dumps(record,indent=2)+'\n')
print('MATCHES',record['matches'],flush=True)
