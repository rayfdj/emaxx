from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).resolve().parent; w=p.parent/'recovered-2026-10-09/symbol-registry/emaxx'
original=p/'registry-draft1'; out=p/'registry-draft1-gnu-layout'; out.mkdir(exist_ok=False)
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
source=json.loads((original/'source.json').read_text()); selection=json.loads((original/'selection.json').read_text()); env=json.loads((original/'environment.json').read_text()); binary=json.loads((original/'binary.json').read_text())
def verify():
 assert all(sha(w/name)==row['sha256'] and oct((w/name).stat().st_mode & 0o777)==row['mode'] for name,row in source.items())
 assert sha(Path(binary['original']))==sha(Path(binary['retained']))==binary['sha256']
verify()
command=[binary['original'],'--exact','--test-threads=1',*selection]
start=time.monotonic()
with (out/'focused.stdout').open('wb') as stdout,(out/'focused.stderr').open('wb') as stderr:
 result=subprocess.run(command,cwd=w,env={**os.environ,**env},stdout=stdout,stderr=stderr)
verify()
receipt=dict(command=command,environment_overrides=env,exit_code=result.returncode,elapsed_seconds=time.monotonic()-start,source_unchanged=True,source_inputs=source,binary=binary,selection=selection,stdout_sha256=sha(out/'focused.stdout'),stderr_sha256=sha(out/'focused.stderr'),only_setup_change='../emacs now resolves to the same contracted GNU source; no Rust/test/fixture/binary/selection/environment override changed',goal_complete=False)
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('UNCHANGED BINARY COHORT',result.returncode,len(selection),flush=True)
print((out/'focused.stdout').read_text()[-2500:],flush=True)
if result.returncode: raise SystemExit(result.returncode)
assert f'test result: ok. {len(selection)} passed; 0 failed; 0 ignored;' in (out/'focused.stdout').read_text()
raise SystemExit(subprocess.run(['python3',str(p/'validate.py'),'registry-draft1-release','focus','release'],cwd=w).returncode)
