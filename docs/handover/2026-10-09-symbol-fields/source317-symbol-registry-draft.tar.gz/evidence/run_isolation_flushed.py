from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).resolve().parent/'isolation-flushed'
p.mkdir(exist_ok=False)
prior=p.parent/'isolation-baseline-lto'
live=p.parent/'isolation-live'
w=p.parent.parent/'recovered-2026-10-09/symbol-ownership/emaxx'
gnu=p.parent.parent/'rebuilt-2026-10-01/emacs'
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
for name in ['first.el','second.el']:(p/name).write_bytes((live/name).read_bytes())
(p/'public_instances.rs').write_text('''use emaxx::batch::{BatchRunOptions, BatchRunOutcome, run_batch_process_with_large_stack};
fn main() {
    for path in std::env::args().skip(1) {
        let source = std::fs::read_to_string(&path).expect("read same Lisp input");
        let result = run_batch_process_with_large_stack(BatchRunOptions {
            no_loadup: true,
            no_site_lisp: true,
            eval: vec![source],
            ..Default::default()
        }, |outcome| {
            assert_eq!(outcome, BatchRunOutcome::Exit(0));
            Ok(0)
        });
        assert_eq!(result.expect("ordinary owned editor entry and flushed shutdown"), 0);
    }
}
''')
original=json.loads((prior/'run.json').read_text())
compile=original['processes'][0]['command'][:]
compile[-3]=str(p/'public_instances.rs');compile[-1]=str(p/'public-instances')
record=dict(source_inputs=original['source_inputs'],library=original['library'],setup_corrections=['isolation-baseline retains launcher failures before any editor ran','isolation-baseline-lto retains the bare purify-flag failure before the second editor','isolation-live retains two successful Emaxx calls but no flushed stdout, so it did not capture either answer and cannot establish an ownership mismatch','This launcher uses the public process entry and its normal flushed shutdown; Lisp inputs, source316 library and compiler options match the previous probe'],inputs={name:sha(p/name) for name in ['first.el','second.el','public_instances.rs']},processes=[],goal_complete=False)
(p/'run.json').write_text(json.dumps(record,indent=2)+'\n')
def run(label,command):
 start=time.monotonic()
 result=subprocess.run(command,cwd=w,env={**os.environ,'LANG':'C','LC_ALL':'C','EMAXX_GNU_SOURCE_DIRECTORY':str(gnu),'EMAXX_DUMP_SOURCE_DIRECTORY':str(gnu),'EMACS_TEST_DIRECTORY':str(gnu/'test')},capture_output=True,timeout=240)
 (p/(label+'.stdout')).write_bytes(result.stdout);(p/(label+'.stderr')).write_bytes(result.stderr)
 record['processes'].append(dict(label=label,command=command,exit_code=result.returncode,elapsed_seconds=time.monotonic()-start,stdout_sha256=sha(p/(label+'.stdout')),stderr_sha256=sha(p/(label+'.stderr'))))
 (p/'run.json').write_text(json.dumps(record,indent=2)+'\n')
 print(label,result.returncode,result.stdout.decode(errors='replace'),result.stderr.decode(errors='replace')[-2000:],flush=True)
 return result
assert run('compile',compile).returncode==0
record['executable']={str(path):sha(path) for path in [p/'public-instances',gnu/'src/emacs',gnu/'src/emacs.pdmp']}
first=run('gnu-first',[str(gnu/'src/emacs'),'-Q','--batch','-l',str(p/'first.el')])
second=run('gnu-second',[str(gnu/'src/emacs'),'-Q','--batch','-l',str(p/'second.el')])
subject=run('emaxx-two-editors',[str(p/'public-instances'),str(p/'first.el'),str(p/'second.el')])
assert first.returncode==second.returncode==subject.returncode==0
assert first.stdout and second.stdout and len(subject.stdout.splitlines())==2
record.update(matches=subject.stdout==first.stdout+second.stdout,source_unchanged=all(sha(w/name)==row['sha256'] for name,row in record['source_inputs'].items()),qualification='Two public owned editor instances execute the same Lisp as two separate normal GNU editor instances, with purify-flag explicitly nil in both. Both actual Lisp answers are captured through normal flushed shutdown. This is a targeted ownership baseline; it does not certify full compatibility or performance.')
(p/'run.json').write_text(json.dumps(record,indent=2)+'\n')
print('MATCHES',record['matches'],flush=True)
