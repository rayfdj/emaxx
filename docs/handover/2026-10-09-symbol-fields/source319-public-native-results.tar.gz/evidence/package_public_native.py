from pathlib import Path
import gzip,hashlib,io,json,tarfile
p=Path(__file__).resolve().parent
w=p.parent/'recovered-2026-10-09/symbol-ownership/emaxx'
destination=w/'docs/handover/2026-10-09-symbol-fields'
sha=lambda b:hashlib.sha256(b).hexdigest()
audit=json.loads((p/'public-native-audit.json').read_text())
assert audit['integration_passed']==3 and audit['restored_public_processes']==12
members={};excluded=[]
for label in ['obarray-draft4-public-integration','obarray-draft4-restored-native-public','obarray-draft4-restored-public-native-image']:
 for path in sorted((p/label).rglob('*')):
  if not path.is_file():continue
  data=path.read_bytes();name=str(path.relative_to(p))
  if path.suffix in ['.rlib','.pdmp'] or path.name=='libtest':
   excluded.append(dict(path=str(path),bytes=len(data),sha256=sha(data)))
  else:members['evidence/'+name]=data
for name in ['public-native-audit.json','audit_public_native.py','integration_ownership.py','probe_restored_native_instances.py','probe_restored_instances_native_image.py','package_public_native.py']:
 members['evidence/'+name]=(p/name).read_bytes()
members['contents.json']=(json.dumps({name:dict(bytes=len(data),sha256=sha(data)) for name,data in members.items()},indent=2)+'\n').encode()
buffer=io.BytesIO()
with gzip.GzipFile(fileobj=buffer,mode='wb',mtime=0) as zipped:
 with tarfile.open(fileobj=zipped,mode='w') as archive:
  for name,data in sorted(members.items()):
   info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
data=buffer.getvalue();path=destination/'source319-public-native-results.tar.gz'
assert not path.exists();path.write_bytes(data)
with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as archive:
 assert set(archive.getnames())==set(members)
 assert all(archive.extractfile(name).read()==data for name,data in members.items())
manifest=dict(checkpoint='source319 unapplied owner draft4 public integration and native continuation',archive=dict(path=path.name,bytes=len(data),sha256=sha(data),members=len(members)),audit=audit,excluded_large_test_inputs=excluded,goal_complete=False)
(destination/'source319-public-native-results-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest['archive']))
