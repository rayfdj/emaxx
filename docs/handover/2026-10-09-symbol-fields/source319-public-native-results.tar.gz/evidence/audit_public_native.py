from pathlib import Path
import hashlib,json,re,subprocess
p=Path(__file__).resolve().parent
w=p.parent/'recovered-2026-10-09/symbol-obarray/emaxx'
read=lambda f:json.loads(f.read_text())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
source=read(p/'obarray-draft4-hash-owner/source.json')
assert len(source)==563 and all(sha(w/n)==v['sha256'] and oct((w/n).stat().st_mode&0o777)==v['mode'] for n,v in source.items())
d=p/'obarray-draft4-public-integration';receipt=read(d/'ownership.json')
assert read(d/'source.json')==read(d/'source-after.json')==source
assert receipt['exit_code']==0
for stream in ['stdout','stderr']:
 f=d/('ownership.'+stream);assert sha(f)==receipt[stream+'_sha256'];assert not re.search(r'^warning(?:\[.*?\])?:',f.read_text(),re.M)
names=['public_editor_calls_serialize_allocation_collection_and_shutdown','public_ert_entry_preserves_complete_inventory_and_unexpected_failures','public_ert_entry_reports_top_level_errors_as_owned_host_data']
verdicts=re.findall(r'^test (\S+) \.\.\. (ok|FAILED|ignored)\s*$',(d/'ownership.stdout').read_text(),re.M)
assert len(verdicts)==3 and dict(verdicts)==dict.fromkeys(names,'ok')
assert 'test result: ok. 3 passed; 0 failed; 0 ignored;' in (d/'ownership.stdout').read_text()
prior=p/'obarray-draft4-restored-native-public';failure=read(prior/'run.json')
assert failure['source_unchanged'] and failure['source_inputs']==source
assert len(failure['processes'])==3 and [r['exit_code'] for r in failure['processes']]==[0,0,101]
assert not failure['comparisons'][0]['matches'] and failure['comparisons'][0]['emaxx']==''
for row in failure['processes']:
 for stream in ['stdout','stderr']:assert sha(prior/(row['label']+'.'+stream))==row[stream+'_sha256']
error=(prior/'native-owner-emaxx-two-editors.stderr').read_text()
assert 'read same Lisp input' in error and 'native-compiler-error' in error and 'No such file or directory' in error
restored=p/'obarray-draft4-restored-public-native-image';record=read(restored/'run.json')
assert record['source_unchanged'] and record['source_inputs']==source
assert sha(restored/'native-owner.el')==sha(prior/'native-owner.el')
assert record['library']['sha256']==read(p/'obarray-draft4-public/run.json')['library']['sha256']
assert sha(Path(record['library']['path']))==record['library']['sha256']
assert (restored/'ordinary_cli.rs').read_text()==(w/'src/main.rs').read_text().replace('fn main() -> ExitCode {','pub fn cli_main() -> ExitCode {')
assert len(record['processes'])==14 and len(record['comparisons'])==4
for row in record['processes']:
 assert row['exit_code']==0 and not row['timed_out']
 assert row['timeout_seconds']=={'compile':1200,'image-build':1800}.get(row['label'],300)
 for stream in ['stdout','stderr']:assert sha(restored/(row['label']+'.'+stream))==row[stream+'_sha256']
for row in record['comparisons']:
 label=row['label'];gnu=(restored/(label+'-gnu-first.stdout')).read_text()+(restored/(label+'-gnu-second.stdout')).read_text();emaxx=(restored/(label+'-emaxx-two-editors.stdout')).read_text()
 assert row['matches'] and row['gnu']==gnu==row['emaxx']==emaxx
assert record['comparisons'][-1]['label']=='native-owner' and record['comparisons'][-1]['gnu']=='(t t t t)\n(t t t t)\n'
artifacts=[];retained=p/'obarray-draft4-native-retained-inputs';retained.mkdir(exist_ok=False)
for index,(name,digest) in enumerate(record['artifacts'].items()):
 f=Path(name);assert sha(f)==digest;copy=retained/(str(index)+'-'+f.name)
 subprocess.run(['cp','-c',str(f),str(copy)],check=True);assert sha(copy)==digest
 artifacts.append(dict(original=name,retained=str(copy),sha256=digest,bytes=copy.stat().st_size))
result=dict(status='public integration and restored native comparisons passed',source_inputs_verified=563,integration_passed=3,integration_names=names,restored_public_processes=12,restored_public_comparisons=record['comparisons'],retained_inputs=artifacts,prior_failure=dict(status='preserved failed native-worker launcher',exit_code=101,gnu=failure['comparisons'][0]['gnu'],emaxx=failure['comparisons'][0]['emaxx'],cause='The standalone launcher handled dump/fingerprint options but treated native compiler child CLI options as file paths. The corrected launcher delegates CLI options to the unchanged normal CLI. Production library and Lisp program are unchanged.'),goal_complete=False,qualification='All 563 inputs match strict, selected and ordinary validation. Existing integration assertions are unchanged, including concurrent host entries, collection, nested version calls and complete visible ERT failures. Two successive editors load valid images and native-compile a function that returns their own canonical symbol, then force GC; GNU and Emaxx outputs and actual native predicates agree. This does not complete native artifact identity, complete platform/frozen/terminal validation, private interpreter image cloning, allocated-field authority or performance acceptance.')
(p/'public-native-audit.json').open('x').write(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['status','source_inputs_verified','integration_passed','restored_public_processes','goal_complete']},indent=2))
