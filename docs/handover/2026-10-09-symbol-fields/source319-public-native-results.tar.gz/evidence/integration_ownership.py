from pathlib import Path
import sys
p=Path(__file__).resolve().parent
sys.argv=[str(p/'validate.py'),'obarray-draft4-public-integration']
exec((p/'validate.py').read_text().split("if 'strict' in sys.argv:")[0])
run('ownership',['cargo','test','--locked','--offline','--profile','gate','--all-features','--test','runtime_ownership','--','--test-threads=1'])
(destination/'source-after.json').write_text(json.dumps(manifest(),indent=2)+'\n')
