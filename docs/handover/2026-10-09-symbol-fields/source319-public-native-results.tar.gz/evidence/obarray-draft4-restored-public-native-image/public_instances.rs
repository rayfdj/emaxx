#[path = "ordinary_cli.rs"] mod ordinary_cli;
use emaxx::batch::{BatchRunOptions, BatchRunOutcome, run_batch_process_with_large_stack};
fn main() -> std::process::ExitCode {
    if std::env::args().any(|arg| arg.starts_with("-")) { return ordinary_cli::cli_main(); }
    for path in std::env::args().skip(1) {
        let source = std::fs::read_to_string(&path).expect("read same Lisp input");
        let result = run_batch_process_with_large_stack(BatchRunOptions {
            no_loadup: false,
            no_site_lisp: true,
            eval: vec![source],
            ..Default::default()
        }, |outcome| {
            assert_eq!(outcome, BatchRunOutcome::Exit(0));
            Ok(0)
        });
        assert_eq!(result.expect("ordinary owned editor entry and flushed shutdown"), 0);
    }
    std::process::ExitCode::SUCCESS
}
