(progn (prin1 (list (consp (pdumper-stats)) (eq (hash-table-test (make-hash-table :test 'eq)) 'eq))) (terpri))
