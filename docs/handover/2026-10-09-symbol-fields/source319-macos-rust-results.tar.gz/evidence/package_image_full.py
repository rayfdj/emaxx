from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).resolve().parent
w = p.parents[2]
destination = w / 'docs/handover/2026-10-09-symbol-fields'
read = lambda path: json.loads(path.read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
audit = read(p / 'source319-macos-rust-audit.json')
assert audit['status'] == 'passed' and audit['total_passed'] == 3169
members, excluded = {}, []
for path in sorted((p / 'image-draft6-full').rglob('*')):
    if not path.is_file():
        continue
    name = str(path.relative_to(p))
    data = path.read_bytes()
    if len(data) > 1_000_000 and (path.name == 'libtest' or path.suffix == '.pdmp'):
        excluded.append(dict(path=str(path), bytes=len(data), sha256=sha(data)))
    else:
        members['evidence/' + name] = data
for name in ['source319-macos-rust-audit.json', 'image-draft6-audit.json', 'image-draft6.patch',
             'close_macos_image.py', 'validate_image.py', 'package_image_full.py']:
    members['evidence/' + name] = (p / name).read_bytes()
members['contents.json'] = (json.dumps({name: dict(bytes=len(data), sha256=sha(data)) for name, data in members.items()}, indent=2) + '\n').encode()
buffer = io.BytesIO()
with gzip.GzipFile(fileobj=buffer, mode='wb', mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode='w') as archive:
        for name, data in sorted(members.items()):
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o644
            archive.addfile(info, io.BytesIO(data))
data = buffer.getvalue()
path = destination / 'source319-macos-rust-results.tar.gz'
assert not path.exists()
path.write_bytes(data)
with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
    assert set(archive.getnames()) == set(members)
    assert all(archive.extractfile(name).read() == value for name, value in members.items())
manifest = dict(checkpoint='source319 unapplied draft, full macOS Rust gate', archive=dict(path=path.name, bytes=len(data), sha256=sha(data), members=len(members)), audit=audit, excluded_large_inputs=excluded, goal_complete=False, qualification='The source319 symbol-owner and image-copy draft passes the complete macOS Rust gate, with all raw inventories, per-test verdicts, Cargo logs, wrapper receipts and source captures retained. Four large libtest/image inputs remain locally retained and identified here. The exact source also passes 232 selected controls in both profiles and twelve ordinary GNU comparisons. Linux, macOS frozen/terminal and performance evidence are still separate and pending. The allocated-field prototype has its own validation and is not included. The complete goal remains open.')
(destination / 'source319-macos-rust-results-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest['archive']))
