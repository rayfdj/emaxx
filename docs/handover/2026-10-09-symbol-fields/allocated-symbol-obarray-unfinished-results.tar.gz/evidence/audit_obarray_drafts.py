from pathlib import Path
import hashlib,json,re
p=Path(__file__).resolve().parent;read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
replay=read(p/'fields-draft12-15-replay.json');results=[]
expected={12:('check',101),13:('focused',101),14:('check',101),15:('focused',101)}
for number,(failed_stage,status) in expected.items():
 d=p/('fields-draft'+str(number)+'-gate');source=read(d/'source.json');row=next(x for x in replay if x['draft']==number);assert row['source_inputs']==len(source) and row['replayed'];assert sha(p/row['patch'])==row['sha256']
 stages={}
 for name in ['fmt','check','clippy','diff','build','inventory','focused']:
  receipt=d/(name+'.json')
  if not receipt.exists():continue
  q=read(receipt);assert q['exit_code']==(status if name==failed_stage else 0)
  for stream in ['stdout','stderr']:assert sha(d/(name+'.'+stream))==q[stream+'_sha256']
  stages[name]=dict(exit_code=q['exit_code'],receipt_sha256=sha(receipt))
 assert failed_stage in stages
 entry=dict(draft=number,source_inputs=len(source),patch=row,stages=stages)
 if failed_stage=='focused':
  binary=read(d/'binary.json');assert sha(Path(binary['retained']))==binary['sha256']
  selected=read(d/'selection.json');raw=(d/'focused.stdout').read_text();verdicts=re.findall(r'^test (\S+) \.\.\. (ok|FAILED|ignored)\s*$',raw,re.M)
  assert len(verdicts)==len(set(selected))==len(selected) and set(dict(verdicts))==set(selected)
  passed=sum(v=='ok' for _,v in verdicts);failures=[n for n,v in verdicts if v=='FAILED'];assert not any(v=='ignored' for _,v in verdicts)
  assert f'test result: FAILED. {passed} passed; {len(failures)} failed; 0 ignored;' in raw
  names={x[:-6] for x in (d/'inventory.stdout').read_text().splitlines() if x.endswith(': test')}
  prior_names={x[:-6] for x in (p/'fields-draft11-gate/inventory.stdout').read_text().splitlines() if x.endswith(': test')}
  prior_selection=set(read(p/'fields-draft11-gate/selection.json'));assert prior_names<=names and prior_selection<=set(selected)
  entry.update(passed=passed,failed=failures,selection=len(selected),inventory=len(names),binary=binary,previous_names_preserved=len(prior_names),previous_selected_controls_preserved=len(prior_selection))
  assert (passed,len(failures))==({13:(235,3),15:(377,2)}[number])
 results.append(entry)
neg=p/'fields-draft12-obarray-negative'
for editor in ['gnu','emaxx']:
 q=read(neg/(editor+'.json'));assert q['exit_code']==0
 for stream in ['stdout','stderr']:assert sha(neg/(editor+'.'+stream))==q[stream+'_sha256']
assert (neg/'gnu.stdout').read_text()=='(t t t t t t t t)' and (neg/'emaxx.stdout').read_text()=='(nil t t t t t t t)'
assert read(neg/'gnu.json')['command'][1:]==read(neg/'emaxx.json')['command'][1:]
q=read(p/'fields-draft14-reader-gnu/receipt.json');assert q['exit_code']==0 and (p/'fields-draft14-reader-gnu/stdout').read_text()=='(t t t t)'
assert sha(p/'fields-draft14-reader-gnu/stdout')==q['stdout_sha256'] and sha(p/'fields-draft14-reader-gnu/stderr')==q['stderr_sha256']
result=dict(status='unfinished; all four attempts and GNU evidence verified',attempts=results,latest_patch=results[-1]['patch'],gnu_order_negative=dict(predicates=8,gnu='(t t t t t t t t)',prior_emaxx='(nil t t t t t t t)'),gnu_reader_membership=dict(predicates=4,gnu='(t t t t)'),qualification='Draft15 passes strict checks and 377 of 379 selected controls. It removes dense/sparse metadata and all four field-history vectors, with actual owner enumeration and direct field writes. Unpositioned readers now resolve atoms in the active obarray; eval-buffer/region read one form before evaluation. Earlier compile failures, three draft13 failures and both draft15 failures remain explicit. The EIEIO expected-value fixture constructs symbols in another independent editor; the dump native-function fixture expects the same first item from distinct hash-table layouts. Neither failure is counted as a pass or waived; diagnose and preserve equivalent or stronger GNU-backed coverage before validating the prototype. Remaining name/id, localized/forwarded and host-owner adapters, descriptor reclamation, physical accounting and all full-goal requirements remain.',goal_complete=False)
(p/'fields-draft15-unfinished-audit.json').open('x').write(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'latest_passed':377,'latest_failed':results[-1]['failed'],'inputs':results[-1]['source_inputs']},indent=2))
