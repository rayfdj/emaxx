from pathlib import Path
import hashlib
import io
import json
import re
import subprocess
import tarfile
import tempfile

p = Path(__file__).resolve().parent
r = p.parents[2]
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
base = '47a05b26876319b28e590a666f9277a2abf46d5a'
gate = p / 'image-draft8-edebug-owner'
source = read(gate / 'source.json')
assert len(source) == 565
for name, row in source.items():
    assert sha(r / name) == row['sha256'] and oct((r / name).stat().st_mode & 0o777) == row['mode'], name


def stage(directory, name, status=0, compiler=False):
    receipt = read(directory / (name + '.json'))
    assert receipt['exit_code'] == status
    for stream in ['stdout', 'stderr']:
        path = directory / (name + '.' + stream)
        assert sha(path) == receipt[stream + '_sha256']
        if compiler:
            assert not re.search(r'^warning(?:\[.*?\])?:', path.read_text(), re.M)
    return receipt


for name in ['fmt', 'check', 'clippy', 'diff']:
    stage(gate, name, compiler=True)
new = {'lisp::eval::tests::eval_02::owned_edebug_symbols_preserve_the_debugged_callers_context'}
profiles = {}
for profile, label, old in [('gate', 'image-draft8-edebug-owner', 'image-draft6-relocation'),
                            ('release', 'image-draft8-release', 'image-draft6-release')]:
    directory = p / label
    assert read(directory / 'source.json') == read(directory / 'source-after.json') == source
    selection = read(directory / 'selection.json')
    assert len(selection) == 233 and set(selection) == set(read(p / old / 'selection.json')) | new
    inventory = lambda path: [line[:-6] for line in path.read_text().splitlines() if line.endswith(': test')]
    names, old_names = inventory(directory / 'inventory.stdout'), inventory(p / old / 'inventory.stdout')
    assert len(names) == len(set(names)) == len(old_names) + 1 and set(names) == set(old_names) | new
    for name in ['build', 'inventory', 'focused']:
        stage(directory, name, compiler=name == 'build')
    verdicts = re.findall(r'^test (\S+) \.\.\. (ok|FAILED|ignored)\s*$', (directory / 'focused.stdout').read_text(), re.M)
    assert len(verdicts) == 233 and dict(verdicts) == dict.fromkeys(selection, 'ok')
    binary = read(directory / 'binary.json')
    assert sha(Path(binary['retained'])) == binary['sha256']
    profiles[profile] = dict(passed=233, failed=0, ignored=0, inventory=len(names), executable=binary)
negative = p / 'image-draft7-edebug-negative'
stage(negative, 'focused', 101)
assert 'test result: FAILED. 0 passed; 1 failed; 0 ignored;' in (negative / 'focused.stdout').read_text()
assert 'a later editor must retain the lexical context of its debugged call' in (negative / 'focused.stdout').read_text()
patch = p / 'image-draft8.patch'
data = subprocess.check_output(['git', 'diff', '--binary', base, '--', 'src', 'tests'], cwd=r)
with patch.open('xb') as stream:
    stream.write(data)
raw = subprocess.check_output(['git', 'archive', base, '--', *source], cwd=r)
with tempfile.TemporaryDirectory(prefix='emaxx-edebug-owner-replay-') as temporary:
    replay = Path(temporary)
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        for entry in archive.getmembers():
            if entry.isfile():
                target = replay / entry.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(archive.extractfile(entry).read())
                target.chmod(0o755 if entry.mode & 0o111 else 0o644)
    subprocess.run(['git', 'apply', str(patch)], cwd=replay, check=True)
    for name, row in source.items():
        assert sha(replay / name) == row['sha256'] and oct((replay / name).stat().st_mode & 0o777) == row['mode'], name
result = dict(checkpoint='source320 debugger symbol ownership repair', status='strict and selected gate/release passed',
    source_inputs_verified=565, previous_controls_retained=232, new_controls=sorted(new), profiles=profiles,
    patch=dict(path=patch.name, sha256=sha(patch), base=base, replayed_source_inputs=565),
    preserved_negative=dict(directory=negative.name, receipt_sha256=sha(negative / 'focused.json'),
        source_sha256=sha(negative / 'source.json'), stdout_sha256=sha(negative / 'focused.stdout')),
    qualification='Source319 cached edebug-entered as one process-wide symbol ID. The negative retains the missing lexical context in a later owned editor. The repair keeps a direct Qsymbol reference with that editor and relocates it when copying an image, without a per-call name or TLS lookup. The new control uses two actual editor scopes and checks inactive, active and cleared debugger states. All previous controls and inventory names remain. The source319 full platform and timing evidence is historical; this follow-up still needs its own ordinary, full platform and compatibility validation. The allocated-field prototype remains separate. The full goal is incomplete.',
    goal_complete=False)
with (p / 'source320-owner-fix-audit.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({key:result[key] for key in ['status','source_inputs_verified','profiles','patch']},indent=2))
