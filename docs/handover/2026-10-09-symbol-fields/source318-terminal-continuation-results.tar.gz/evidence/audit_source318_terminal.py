from pathlib import Path
import hashlib
import json
import re
import runpy

p = Path(__file__).resolve().parent
out = p / "source318-terminal"
read = lambda f: json.loads(f.read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
command, state = read(out / "command.json"), read(out / "state.json")
assert "exit_code" in state, "the terminal process has not ended"
w = Path(command["working_directory"])
source = command["source_inputs"]
assert len(source) == 562
for name, row in source.items():
    assert sha(w / name) == row["sha256"], name
    assert oct((w / name).stat().st_mode & 0o777) == row["mode"], name
for name, digest in command["inputs"].items():
    assert sha(Path(name)) == digest, name
assert state["source_unchanged"] and state["inputs_unchanged"]
assert sha(out / "run.log") == state["log_sha256"]
assert sha(out / "screens.jsonl") == state["screens_sha256"]
module = runpy.run_path(str(w / "tools/ttydiff.py"), run_name="inventory_only")
scenarios = module["select_scenarios"]([])
assert [s[0] for s in scenarios] == command["inventory"]


def labels(scenario):
    name, keys = scenario[0], scenario[2]
    result, final_label, final_fs = [], name, False
    for index, item in enumerate(keys):
        action = module["normalize_action"](item, index)
        if not action.checkpoint:
            continue
        label = f"{name}::{index+1}:{action.name}"
        if index + 1 == len(keys):
            final_label, final_fs = label, action.filesystem
        else:
            result.append(label)
            if action.filesystem:
                result.append(label + " filesystem")
    result.append(final_label)
    if final_fs:
        result.append(final_label + " filesystem")
    return result


expected = [label for scenario in scenarios for label in labels(scenario)]
assert len(scenarios) == 226 and len(expected) == 686
assert len(set(expected)) == 686
raw = (out / "run.log").read_text()
runs = re.findall(r"^RUN \[(\d+)/226\] (.+)$", raw, re.M)
assert runs == [(str(i + 1), s[0]) for i, s in enumerate(scenarios[:len(runs)])]
verdicts = re.findall(r"^(MATCH|DIVERGE) \[(.+)\]: (.+)$", raw, re.M)
observed = [v[1] for v in verdicts]
assert observed == expected[:len(observed)], "missing, duplicated or reordered comparison"
snapshots = [json.loads(line) for line in (out / "screens.jsonl").read_text().splitlines()]
assert [s["label"] for s in snapshots] == [n for n in observed if not n.endswith(" filesystem")]
reported = {label: verdict for verdict, label, _ in verdicts}
full_screen_differences = []
for snapshot in snapshots:
    assert len(snapshot["screens"]) == 2
    gnu, candidate = snapshot["screens"]
    assert len(gnu["lines"]) == len(candidate["lines"]) == 24
    different = [key for key in ("lines", "attrs", "cursor") if gnu[key] != candidate[key]]
    if different:
        full_screen_differences.append(dict(label=snapshot["label"], fields=different,
                                            harness_verdict=reported[snapshot["label"]]))
failures = [label for verdict, label, _ in verdicts if verdict != "MATCH"]
matches = [label for verdict, label, _ in verdicts if verdict == "MATCH"]
unexecuted = expected[len(observed):]
passed = len(runs) == 226 and not failures and not unexecuted
assert (state["exit_code"] == 0) == passed
assert ("PASS: all scenarios match" in raw) == passed
record = dict(status="passed" if passed else "failed", exit_code=state["exit_code"],
    runtime_commit=command["runtime_commit"], source_inputs_verified=len(source),
    execution_inputs_verified=len(command["inputs"]), selected_scenarios=226,
    started_scenarios=len(runs), selected_comparisons=686, matching_comparisons=len(matches),
    divergent_labels=failures, unexecuted_labels=unexecuted,
    screen_comparisons=len(snapshots), filesystem_comparisons=sum(n.endswith(" filesystem") for n in observed),
    full_screen_differences=full_screen_differences, elapsed_seconds=state["elapsed_seconds"],
    evidence={str(f.relative_to(p)):sha(f) for f in [out/"command.json", out/"state.json", out/"run.log", out/"screens.jsonl", Path(__file__)]},
    qualification="One ordinary terminal attempt, with the original 226-scenario inventory, actions, comparisons and deadlines. The observer retains all 24 rows, attributes and cursor coordinates independently of the harness verdict. This validates source318 only; source319 ownership drafts and full-goal performance acceptance remain separate.",
    goal_complete=False)
(p / "source318-terminal-audit.json").open("x").write(json.dumps(record, indent=2) + "\n")
print(json.dumps(record, indent=2))
