from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

p=Path(__file__).resolve().parent
destination=p.parents[2]/"docs/handover/2026-10-09-symbol-fields"
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda path:json.loads(path.read_text())
original=read(p/"source318-terminal-audit.json")
tail=read(p/"source318-terminal-tail-audit.json")
assert original["exit_code"]==1 and tail["distinct_matching_comparisons_across_attempts"]==686
members={}
for directory in [p/"source318-terminal",p/"source318-terminal-tail"]:
    for path in sorted(directory.rglob("*")):
        if path.is_file():
            members["evidence/"+str(path.relative_to(p))]=path.read_bytes()
for name in ["source318-terminal-audit.json","source318-terminal-tail-audit.json","audit_source318_terminal.py","audit_source318_terminal_tail.py","source318_terminal.py","source318_terminal_tail.py","observe_terminal.py","package_terminal.py"]:
    members["evidence/"+name]=(p/name).read_bytes()
members["contents.json"]=(json.dumps({name:dict(bytes=len(data),sha256=sha(data)) for name,data in members.items()},indent=2)+"\n").encode()
buffer=io.BytesIO()
with gzip.GzipFile(fileobj=buffer,mode="wb",mtime=0) as zipped:
    with tarfile.open(fileobj=zipped,mode="w") as archive:
        for name,data in sorted(members.items()):
            entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o644
            archive.addfile(entry,io.BytesIO(data))
data=buffer.getvalue()
path=destination/"source318-terminal-continuation-results.tar.gz"
assert not path.exists()
path.write_bytes(data)
with tarfile.open(fileobj=io.BytesIO(data),mode="r:gz") as archive:
    assert set(archive.getnames())==set(members)
    assert all(archive.extractfile(name).read()==payload for name,payload in members.items())
manifest=dict(checkpoint="source318 terminal continuation",archive=dict(path=path.name,bytes=len(data),sha256=sha(data),members=len(members)),original_audit=original,tail_audit=tail,
    qualification="All 226 scenarios and 686 distinct comparison labels have matching observations across separate attempts. All 658 complete screen snapshots agree in every row, cell attribute and cursor coordinate; 28 comparisons check filesystem state. The original full run still fails GNU startup readiness in scenario184. This is not a single complete passing ordinary run or a diagnosis of that failure. Both supervisors have exited. Runtime and performance completion remain unproven.",goal_complete=False)
(destination/"source318-terminal-continuation-results-manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
print(json.dumps(manifest["archive"]))
