"""Record complete screens without changing the ordinary terminal harness."""
from pathlib import Path
import importlib.util
import json
import sys

output = Path(sys.argv[1]).resolve()
spec = importlib.util.spec_from_file_location("ordinary_ttydiff", "tools/ttydiff.py")
tty = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = tty
spec.loader.exec_module(tty)
original_report = tty.report_comparison
events = output.open("x")


def report(label, gnu, emaxx):
    events.write(json.dumps(dict(label=label, screens=[
        dict(lines=screen.lines(), attrs=screen.attr_rows(),
             cursor=[screen.row, screen.col]) for screen in [gnu, emaxx]
    ])) + "\n")
    events.flush()
    return original_report(label, gnu, emaxx)


tty.report_comparison = report
sys.argv = ["tools/ttydiff.py"] + sys.argv[2:]
try:
    tty.main()
finally:
    events.close()
