from pathlib import Path
import hashlib
import json
import re
import runpy

p = Path(__file__).resolve().parent
out = p / "source318-terminal-tail"
read = lambda f: json.loads(f.read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
command, state = read(out / "command.json"), read(out / "state.json")
original = read(p / "source318-terminal-audit.json")
assert state["exit_code"] == 0 and len(state["results"]) == 43
w = Path(command["working_directory"])
for name, row in command["source_inputs"].items():
    assert sha(w/name) == row["sha256"] and oct((w/name).stat().st_mode & 0o777) == row["mode"], name
for name, digest in command["inputs"].items():
    assert sha(Path(name)) == digest, name
module = runpy.run_path(str(w / "tools/ttydiff.py"), run_name="inventory_only")


def labels(scenario):
    name, keys = scenario[0], scenario[2]
    result, final_label, final_fs = [], name, False
    for index, item in enumerate(keys):
        action = module["normalize_action"](item, index)
        if not action.checkpoint:
            continue
        label = f"{name}::{index+1}:{action.name}"
        if index + 1 == len(keys):
            final_label, final_fs = label, action.filesystem
        else:
            result.append(label)
            if action.filesystem:
                result.append(label + " filesystem")
    result.append(final_label)
    if final_fs:
        result.append(final_label + " filesystem")
    return result


expected = {scenario[0]:labels(scenario) for scenario in module["select_scenarios"]([])}
assert len(expected) == 226 and sum(map(len, expected.values())) == 686
assert [r["scenario"] for r in state["results"]] == command["selection"]
matches, screens, filesystem = [], 0, 0
for result in state["results"]:
    name = result["scenario"]
    assert result["exit_code"] == 0 and result["source_unchanged"] and result["inputs_unchanged"]
    log, snapshots_file = out/(name+".log"), out/(name+".screens.jsonl")
    assert sha(log) == result["log_sha256"]
    assert sha(snapshots_file) == result["screens_sha256"]
    assert read(out/(name+".result.json")) == result
    raw = log.read_text()
    assert re.findall(r"^RUN \[(.+)\] (.+)$", raw, re.M) == [("1/1", name)]
    verdicts = re.findall(r"^(MATCH|DIVERGE) \[(.+)\]: (.+)$", raw, re.M)
    assert [row[1] for row in verdicts] == expected[name]
    assert all(row[0] == "MATCH" for row in verdicts)
    assert "PASS: all scenarios match" in raw
    snapshots = [json.loads(line) for line in snapshots_file.read_text().splitlines()]
    assert [row["label"] for row in snapshots] == [n for n in expected[name] if not n.endswith(" filesystem")]
    for snapshot in snapshots:
        gnu, candidate = snapshot["screens"]
        assert len(gnu["lines"]) == len(candidate["lines"]) == 24
        assert all(gnu[key] == candidate[key] for key in ["lines", "attrs", "cursor"]), snapshot["label"]
    screens += len(snapshots)
    filesystem += sum(n.endswith(" filesystem") for n in expected[name])
    matches.extend(expected[name])
assert matches == original["unexecuted_labels"] and len(matches) == 256
for name, digest in original["evidence"].items():
    assert sha(p/name) == digest, name
assert original["exit_code"] == 1 and original["matching_comparisons"] == 430
assert not original["divergent_labels"] and not original["full_screen_differences"]
record = dict(status="passed separate unfinished-scenario observations", runtime_commit=command["runtime_commit"],
    source_inputs_verified=len(command["source_inputs"]), execution_inputs_verified=len(command["inputs"]),
    scenarios=43, comparisons=len(matches), screen_comparisons=screens, filesystem_comparisons=filesystem,
    distinct_scenarios_observed_across_attempts=226, distinct_matching_comparisons_across_attempts=686,
    all_raw_screen_fields_identical=True, original_failure="GNU startup readiness in eglot-xref-rename-edits; original full attempt remains exit1 after 430 matches.",
    evidence={str(f.relative_to(p)):sha(f) for f in [out/"command.json", out/"state.json", p/"source318-terminal-audit.json", Path(__file__)]},
    qualification="This is not one complete passing ordinary run. Each of the 43 unfinished scenarios was observed once through the unchanged ordinary harness, actions and deadlines, with identical executables/images. The separate pass does not explain or erase the original GNU startup failure. Source319 and full-goal validation/performance remain separate.",
    goal_complete=False)
(p/"source318-terminal-tail-audit.json").open("x").write(json.dumps(record,indent=2)+"\n")
print(json.dumps(record,indent=2))
