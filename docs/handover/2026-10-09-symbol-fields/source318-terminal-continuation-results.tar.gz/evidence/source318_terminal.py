from pathlib import Path
import datetime
import hashlib
import json
import os
import runpy
import subprocess
import sys
import time

p = Path(__file__).resolve().parent
w = p.parent / "recovered-2026-10-09/symbol-ownership/emaxx"
g = p.parent / "rebuilt-2026-10-01/emacs"
out = p / "source318-terminal"
out.mkdir(exist_ok=False)
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
source = read(p / "payload-draft1/source.json")
state = dict(status="queued behind macOS frozen tail", pid=os.getpid(),
             started=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             goal_complete=False)


def save():
    (out / "state.json").write_text(json.dumps(state, indent=2) + "\n")


def verify_source():
    assert len(source) == 562
    for name, row in source.items():
        assert sha(w / name) == row["sha256"], name
        assert oct((w / name).stat().st_mode & 0o777) == row["mode"], name


save()
try:
    deadline = time.monotonic() + 3600
    while "exit_code" not in read(p / "source318-macos-tail/state.json"):
        assert time.monotonic() < deadline, "tail queue deadline reached"
        time.sleep(5)
    verify_source()
    longer = read(p / "source318-tramp-longer-audit.json")
    contract = read(Path(longer["raw_root"]) / "contract.json")
    provenance = contract["provenance"]
    destination = w / "target/compat-subject/tty-source318"
    destination.mkdir(exist_ok=False)
    subject = Path(provenance["subject_binary"])
    inputs = {}
    for name, digest in [("emaxx", provenance["subject_sha256"]),
                         ("emaxx.pdmp", provenance["runtime_images_sha256"][str(subject.with_suffix(".pdmp"))])]:
        original, retained = subject.parent / name, destination / name
        assert sha(original) == digest
        subprocess.run(["cp", "-c", str(original), str(retained)], check=True)
        assert sha(retained) == digest
        inputs[str(retained)] = digest
    for path in [g / "src/emacs", g / "src/emacs.pdmp", g / "src/config.h",
                 g / "src/Makefile", w / "tools/ttydiff.py",
                 w / "tools/fixtures/fieldnotes.org", w / "tools/fixtures/fake_lsp_server.py",
                 p / "observe_terminal.py", Path(__file__)]:
        inputs[str(path)] = sha(path)
    assert inputs[str(g / "src/emacs")] == provenance["oracle_sha256"]
    assert inputs[str(g / "src/emacs.pdmp")] == provenance["runtime_images_sha256"][str(g / "src/emacs.pdmp")]
    inventory = runpy.run_path(str(w / "tools/ttydiff.py"), run_name="inventory_only")
    names = [entry[0] for entry in inventory["select_scenarios"]([])]
    previous = read(p.parent / "resume-2026-09-28/source312-full-tty-command.json")
    assert names == previous["inventory"] and len(names) == 226
    command = ["/usr/bin/caffeinate", "-i", sys.executable, "-u",
               str(p / "observe_terminal.py"), str(out / "screens.jsonl"),
               str(destination / "emaxx"), str(g / "src/emacs"), str(g / "lisp")]
    environment = dict(EMAXX_TTYDIFF_REQUIRE="1", LANG="C", LC_ALL="C")
    record = dict(command=command, working_directory=str(w),
                  environment_override=environment, source_inputs=source, inputs=inputs,
                  inventory=names, runtime_commit="93b6546f9c54aaecf2237cc751e3f94591066969",
                  qualification="All 226 ordinary scenarios, original actions, deadlines and comparisons. The observer records full screens and returns the unchanged harness verdict. Same-depth retained copies preserve relative native paths. No retry or deadline extension.")
    (out / "command.json").write_text(json.dumps(record, indent=2) + "\n")
    state.update(status="running all 226 ordinary terminal scenarios")
    save()
    print(state["status"], flush=True)
    start = time.monotonic()
    with (out / "run.log").open("xb") as log:
        result = subprocess.run(command, cwd=w, env={**os.environ, **environment},
                                stdin=subprocess.DEVNULL, stdout=log,
                                stderr=subprocess.STDOUT, timeout=21600)
    verify_source()
    assert all(sha(Path(name)) == digest for name, digest in inputs.items())
    state.update(status="terminal; inspect raw evidence", exit_code=result.returncode,
                 elapsed_seconds=time.monotonic() - start, source_unchanged=True,
                 inputs_unchanged=True, log_sha256=sha(out / "run.log"),
                 screens_sha256=sha(out / "screens.jsonl"))
    save()
    print(json.dumps(state), flush=True)
except BaseException as error:
    state.update(status="failed; preserve raw evidence", error=str(error))
    save()
    raise
