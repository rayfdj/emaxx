from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time

p = Path(__file__).resolve().parent
out = p / "source318-terminal-tail"
out.mkdir(exist_ok=False)
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
previous = read(p / "source318-terminal/command.json")
audit = read(p / "source318-terminal-audit.json")
assert audit["exit_code"] == 1 and audit["matching_comparisons"] == 430
selection = previous["inventory"][183:]
assert len(selection) == 43 and selection[0] == "eglot-xref-rename-edits"
w = Path(previous["working_directory"])
inputs = previous["inputs"] | {str(Path(__file__).resolve()): sha(__file__)}


def verify():
    for name, row in previous["source_inputs"].items():
        assert sha(w / name) == row["sha256"], name
        assert oct((w / name).stat().st_mode & 0o777) == row["mode"], name
    assert all(sha(name) == digest for name, digest in inputs.items())


verify()
record = {key: previous[key] for key in ["working_directory", "source_inputs", "runtime_commit"]}
record.update(selection=selection, inputs=inputs, environment_override=previous["environment_override"],
    qualification="One separate ordinary observation of each of the 43 unfinished scenarios, using the unchanged source318 executable/image, GNU, harness, actions and deadlines. Earlier full-run GNU startup failure remains failed. Full screens are recorded without changing the comparison.")
(out / "command.json").write_text(json.dumps(record, indent=2) + "\n")
state = dict(status="running", pid=os.getpid(), started=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             results=[], goal_complete=False)


def save():
    (out / "state.json").write_text(json.dumps(state, indent=2) + "\n")


save()
for index, name in enumerate(selection):
    state.update(status="running " + name)
    save()
    prefix = out / name
    command = ["/usr/bin/caffeinate", "-i", sys.executable, "-u", str(p / "observe_terminal.py"),
               str(prefix.with_suffix(".screens.jsonl")), *previous["command"][-3:], name]
    print(f"RUN {index+1}/{len(selection)} {name}", flush=True)
    started = time.monotonic()
    with prefix.with_suffix(".log").open("xb") as log:
        child = subprocess.run(command, cwd=w, env={**os.environ, **record["environment_override"]},
                               stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
    verify()
    result = dict(scenario=name, command=command, exit_code=child.returncode,
                  elapsed_seconds=time.monotonic()-started, log_sha256=sha(prefix.with_suffix(".log")),
                  screens_sha256=sha(prefix.with_suffix(".screens.jsonl")), source_unchanged=True, inputs_unchanged=True)
    prefix.with_suffix(".result.json").write_text(json.dumps(result, indent=2) + "\n")
    state["results"].append(result)
    save()
    print(json.dumps(result), flush=True)
state.update(status="terminal; inspect all raw results", exit_code=int(any(r["exit_code"] for r in state["results"])))
save()
print(state["status"], flush=True)
