from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

p = Path(__file__).resolve().parent
w = p.parent / 'recovered-2026-10-09/symbol-ownership/emaxx'
old = p / 'redirect-draft1-ordinary'
d = p / 'redirect-draft1-native-named'
d.mkdir(exist_ok=False)
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
source = read(old / 'source.json')
identities = read(old / 'artifacts-before.json')
environment = read(old / 'environment.json')
def verify():
    assert all(sha(w / name) == row['sha256'] and oct((w / name).stat().st_mode & 0o777) == row['mode'] for name, row in source.items())
    assert all(sha(Path(name)) == row['sha256'] for name, row in identities.items())
verify()
(d / 'source.json').write_text(json.dumps(source, indent=2) + '\n')
(d / 'artifacts-before.json').write_text(json.dumps(identities, indent=2) + '\n')
(d / 'environment.json').write_text(json.dumps(environment, indent=2) + '\n')
results = []
expected = '((t t t t) ' + (w / 'tests/fixtures/symbol-redirect-lifetime.expected').read_text().strip() + ')'
for editor in ['gnu', 'emaxx']:
    name = 'symbol-redirect-lifetime-native-' + editor
    original = read(old / (name + '.json'))
    assert original['exit_code'] == 255 and not original['timed_out']
    assert 'No applicable method:' in (old / (name + '.stderr')).read_text()
    command = original['command'].copy()
    assert command[-1].count('(native-compile (symbol-function name))') == 1
    command[-1] = command[-1].replace('(native-compile (symbol-function name))', '(native-compile name)')
    start = time.monotonic()
    with (d / (name + '.stdout')).open('wb') as out, (d / (name + '.stderr')).open('wb') as err:
        result = subprocess.run(command, cwd=w, env={**os.environ, **environment}, stdout=out, stderr=err, timeout=180)
    record = dict(command=command, original_command=original['command'], cwd=str(w), exit_code=result.returncode, timed_out=False, timeout_seconds=180, elapsed_seconds=time.monotonic()-start, stdout_sha256=sha(d / (name + '.stdout')), stderr_sha256=sha(d / (name + '.stderr')))
    (d / (name + '.json')).write_text(json.dumps(record, indent=2) + '\n')
    output = (d / (name + '.stdout')).read_text()
    results.append(dict(fixture='symbol-redirect-lifetime', mode='native', editor=editor, exit_code=result.returncode, expected=expected, stdout=output, passed=result.returncode == 0 and output.strip() == expected))
    (d / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
    print(editor, result.returncode, output, flush=True)
    verify()
(d / 'artifacts-after.json').write_text(json.dumps(identities, indent=2) + '\n')
summary = dict(processes=2, passed=sum(row['passed'] for row in results), failed=sum(not row['passed'] for row in results), original_failed_processes=2, qualification='GNU comp.el:comp--spill-lap-function has symbol, list and filename methods, not an interpreted-function-object method. Only the native helper compiler argument changes from symbol-function(name) to name. The exact fixture, three helper bodies, top-level form, mode predicates, runtime sources, executable/images, environment and 180-second deadline remain unchanged. Original failed launcher processes stay failed.', goal_complete=False)
(d / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
assert all(row['passed'] for row in results) and results[0]['stdout'] == results[1]['stdout']
