from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).resolve().parent
w = p.parent / 'recovered-2026-10-08/symbol-plists/emaxx'
destination = w / 'docs/handover/2026-10-09-symbol-fields'
read = lambda path: json.loads(path.read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
audit = read(p / 'selected-audit.json')
assert audit['replay_verified'] and audit['ordinary_audited'] and audit['ordinary_successful_processes'] == 18
members, excluded = {}, []
for name in ['redirect-draft1', 'redirect-draft1-release', 'redirect-draft1-ordinary', 'redirect-draft1-native-named', 'redirect-baseline', 'redirect-baseline-frame']:
    for path in sorted((p / name).rglob('*')):
        if not path.is_file():
            continue
        data = path.read_bytes()
        if path.name == 'libtest':
            excluded.append(dict(path=str(path), bytes=len(data), sha256=sha(data)))
        else:
            members['evidence/' + str(path.relative_to(p))] = data
for name in ['redirect-draft1.patch', 'selected-audit.json', 'profiles-audit.json', 'gnu-redirect-review.json', 'validate.py', 'ordinary.py', 'native_named_replay.py', 'audit_redirect_selected.py', 'continue_validation.py', 'validation-state.json', 'release-supervisor.log', 'ordinary-supervisor.log', 'package_redirect.py']:
    members['evidence/' + name] = (p / name).read_bytes()
members['contents.json'] = (json.dumps({name: dict(bytes=len(data), sha256=sha(data)) for name, data in members.items()}, indent=2) + '\n').encode()
buffer = io.BytesIO()
with gzip.GzipFile(fileobj=buffer, mode='wb', mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode='w') as archive:
        for name, data in sorted(members.items()):
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o644
            archive.addfile(info, io.BytesIO(data))
data = buffer.getvalue()
path = destination / 'source316-symbol-redirect-draft.tar.gz'
assert not path.exists()
path.write_bytes(data)
with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
    assert set(archive.getnames()) == set(members)
    assert all(archive.extractfile(name).read() == value for name, value in members.items())
manifest = dict(checkpoint='source316 separately packaged and unapplied draft', archive=dict(path=path.name, bytes=len(data), sha256=sha(data), members=len(members)), audit=audit, excluded_large_inputs=excluded, goal_complete=False, qualification='This cumulative patch includes source315 and the value/alias union on base2712c057; it replays all 562 inputs. Strict checks and 128 focused tests in each profile pass. Eighteen successful ordinary processes cover nine GNU/Emaxx comparisons, including three compiled helpers and their compiled caller. The first two native launcher failures and the earlier conservative-stack fixture mismatch remain retained. There is no source316 complete Rust/Linux/frozen/performance certification. Source314 remains the PR runtime.')
(destination / 'source316-symbol-redirect-draft-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest['archive']))
