from pathlib import Path
import datetime
import json
import os
import subprocess
import sys
import time

p = Path(__file__).resolve().parent
record = dict(status='waiting for the running gate cohort', pid=os.getpid(), started=datetime.datetime.now(datetime.timezone.utc).isoformat(), stages=[], goal_complete=False)
state = p / 'validation-state.json'
assert not state.exists(), 'do not duplicate this validation queue'
def save(): state.write_text(json.dumps(record, indent=2) + '\n')
save()
deadline = time.monotonic() + 7200
while not (p / 'redirect-draft1/source-after.json').exists():
    for receipt in (p / 'redirect-draft1').glob('*.json'):
        result = json.loads(receipt.read_text())
        if isinstance(result, dict) and 'exit_code' in result and result['exit_code'] != 0:
            record.update(status='stopped after prerequisite failure', prerequisite=str(receipt))
            save()
            raise SystemExit(1)
    if time.monotonic() > deadline:
        record.update(status='queue deadline expired without prerequisite completion')
        save()
        raise SystemExit(1)
    time.sleep(10)
for stage, command in [
    ('release', [sys.executable, str(p / 'validate.py'), 'redirect-draft1-release', 'focus', 'release']),
    ('ordinary', [sys.executable, str(p / 'ordinary.py')]),
]:
    record.update(status='running', current_stage=stage, command=command)
    save()
    with (p / (stage + '-supervisor.log')).open('wb') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    record['stages'].append(dict(stage=stage, command=command, exit_code=result.returncode))
    save()
    if result.returncode:
        record['status'] = 'stopped after failed stage'
        save()
        raise SystemExit(result.returncode)
record['status'] = 'selected validation terminal; independent audit required'
save()
