from pathlib import Path
import hashlib
import io
import json
import re
import subprocess
import sys
import tarfile
import tempfile

p = Path(__file__).resolve().parent
root = p.parents[2]
w = p.parent / 'recovered-2026-10-09/symbol-ownership/emaxx'
previous = p.parent / 'symbol-values-2026-10-09'
base = '2712c05779e47ec9b8a7c89121d1a79fdcc42596'
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
source = read(p / 'redirect-draft1/source.json')
old_source = read(previous / 'compact-draft1/source.json')
assert len(source) == 562 and set(old_source) < set(source)
assert {name for name in old_source if old_source[name] != source[name]} == {'src/lisp/eval/symbol_cells.rs', 'src/lisp/primitives/tests.rs'}
assert set(source) - set(old_source) == {'tests/fixtures/symbol-redirect-lifetime.el', 'tests/fixtures/symbol-redirect-lifetime.expected'}
assert all(sha(w / name) == row['sha256'] and oct((w / name).stat().st_mode & 0o777) == row['mode'] for name, row in source.items())
for stage in ['fmt', 'check', 'clippy', 'diff']:
    d = p / 'redirect-draft1'
    record = read(d / (stage + '.json'))
    assert record['exit_code'] == 0
    for stream in ['stdout', 'stderr']:
        assert sha(d / (stage + '.' + stream)) == record[stream + '_sha256']
    assert not re.search(r'^warning(?:\[.*?\])?:', (d / (stage + '.stderr')).read_text(), re.M)
profiles = {}
added_names = {
    'lisp::eval::symbol_cells::tests::alias_payload_replaces_the_value_and_traces_only_its_current_target',
    'lisp::primitives::tests::symbol_alias_redirects_preserve_handover_fields_and_reclaim_replaced_targets',
}
for profile, suffix in [('gate', ''), ('release', '-release')]:
    d = p / ('redirect-draft1' + suffix)
    old = previous / ('compact-draft1' + suffix)
    assert read(d / 'source.json') == read(d / 'source-after.json') == source
    record = read(d / 'focused.json')
    assert record['exit_code'] == 0
    selected = read(d / 'selection.json')
    assert set(read(old / 'selection.json')) | added_names == set(selected) and len(selected) == 128
    output = (d / 'focused.stdout').read_text()
    assert sha(d / 'focused.stdout') == record['stdout_sha256'] and sha(d / 'focused.stderr') == record['stderr_sha256']
    starts = list(re.finditer(r'^test (\S+) \.\.\. ', output, re.M))
    seen = []
    for index, match in enumerate(starts):
        end = starts[index + 1].start() if index + 1 < len(starts) else output.rindex('test result:')
        assert re.search(r'(?:^|\s)ok$', output[match.end():end].strip()), match[1]
        seen.append(match[1])
    assert sorted(seen) == selected and len(seen) == len(set(seen))
    assert 'test result: ok. 128 passed; 0 failed; 0 ignored;' in output
    inventory = {line[:-6] for line in (d / 'inventory.stdout').read_text().splitlines() if line.endswith(': test')}
    old_inventory = {line[:-6] for line in (old / 'inventory.stdout').read_text().splitlines() if line.endswith(': test')}
    assert old_inventory | added_names == inventory
    messages = [json.loads(line) for line in (d / 'build.stdout').read_text().splitlines() if line.startswith('{')]
    assert not any(message.get('message', {}).get('level') in ['warning', 'error'] for message in messages)
    binary = read(d / 'binary.json')
    assert sha(Path(binary['retained'])) == binary['sha256']
    profiles[profile] = dict(passed=len(seen), inventory=len(inventory), retained_binary=binary)

# Audit the explicitly documented correction of the historical test-only
# alias-removal expectation. Every other pre-existing storage test byte remains.
old_tests = (p.parent / 'recovered-2026-10-09/symbol-values/emaxx/src/lisp/eval/symbol_cells.rs').read_text().split('#[cfg(test)]\nmod tests {', 1)[1]
new_tests = (w / 'src/lisp/eval/symbol_cells.rs').read_text().split('#[cfg(test)]\nmod tests {', 1)[1]
start = new_tests.index('    #[test]\n    fn alias_payload_replaces_')
end = new_tests.index('    #[test]\n    fn compact_fields_', start)
new_tests = new_tests[:start] + new_tests[end:]
new_tests = new_tests.replace('assert_eq!(std::mem::size_of::<SymbolCell>(), 56);', 'assert_eq!(std::mem::size_of::<SymbolCell>(), 64);')
new_tests = new_tests.replace('        assert!(cells.value(&symbol).is_none());\n        assert_eq!(cells.bound_len(), 0);\n        cells.clear_alias_by_name("symbol-cells-word");', '        cells.clear_alias_by_name("symbol-cells-word");')
correction = '''        // GNU's SET_SYMBOL_ALIAS overwrites the previous value. The test-only
        // redirect removal leaves an unbound plain cell, never that old value.
        assert!(cells.value(&symbol).is_none());
        cells.insert(&symbol, Value::Integer(3));
'''
assert correction in new_tests
new_tests = new_tests.replace(correction, '')
assert new_tests == old_tests

ordinary_audited = '--profiles-only' not in sys.argv
rows = []
original_failures = []
if ordinary_audited:
    d = p / 'redirect-draft1-ordinary'
    assert read(d / 'source.json') == source
    original_rows = read(d / 'results.json')
    fixtures = ['symbol-field-lifetime', 'symbol-field-weak-finalizer', 'symbol-load-history-lifetime', 'symbol-plist-put-sharing', 'symbol-redirect-lifetime']
    expected = {(fixture, mode, editor) for fixture in fixtures for mode in (['interpreted', 'bytecode', 'native'] if fixture in ['symbol-plist-put-sharing', 'symbol-redirect-lifetime'] else ['interpreted']) for editor in ['gnu', 'emaxx']}
    assert len(original_rows) == 18 and {(row['fixture'], row['mode'], row['editor']) for row in original_rows} == expected
    original_failures = [row for row in original_rows if not row['passed']]
    assert len(original_failures) == 2 and {(row['fixture'], row['mode']) for row in original_failures} == {('symbol-redirect-lifetime', 'native')}
    for row in original_failures:
        label = '-'.join([row['fixture'], row['mode'], row['editor']])
        record = read(d / (label + '.json'))
        assert record['exit_code'] == 255 and not record['timed_out']
        assert (d / (label + '.stdout')).read_text() == row['stdout']
        assert 'No applicable method:' in (d / (label + '.stderr')).read_text()
        assert all(sha(d / (label + '.' + stream)) == record[stream + '_sha256'] for stream in ['stdout', 'stderr'])
    followup = p / 'redirect-draft1-native-named'
    replay_rows = read(followup / 'results.json')
    assert len(replay_rows) == 2 and read(followup / 'summary.json')['failed'] == 0
    assert read(followup / 'source.json') == source
    assert read(followup / 'artifacts-before.json') == read(followup / 'artifacts-after.json') == read(d / 'artifacts-before.json')
    assert read(followup / 'environment.json') == read(d / 'environment.json')
    for row in replay_rows:
        label = '-'.join([row['fixture'], row['mode'], row['editor']])
        record = read(followup / (label + '.json'))
        original_command = read(d / (label + '.json'))['command']
        expected_command = original_command.copy()
        expected_command[-1] = expected_command[-1].replace('(native-compile (symbol-function name))', '(native-compile name)')
        assert record['command'] == expected_command and record['original_command'] == original_command
    rows = [row for row in original_rows if row['passed']] + replay_rows
    assert len(rows) == 18 and {(row['fixture'], row['mode'], row['editor']) for row in rows} == expected
    for row in rows:
        directory = followup if row['fixture'] == 'symbol-redirect-lifetime' and row['mode'] == 'native' else d
        label = '-'.join([row['fixture'], row['mode'], row['editor']])
        record = read(directory / (label + '.json'))
        assert record['exit_code'] == 0 and not record['timed_out']
        wanted = (w / 'tests/fixtures' / (row['fixture'] + '.expected')).read_text().strip()
        if row['mode'] != 'interpreted':
            wanted = ('((t t t t) ' if row['fixture'] == 'symbol-redirect-lifetime' else '(t ') + wanted + ')'
        output = (directory / (label + '.stdout')).read_text()
        assert output == row['stdout'] and output.strip() == row['expected'] == wanted and row['passed']
        assert sha(directory / (label + '.stdout')) == record['stdout_sha256'] and sha(directory / (label + '.stderr')) == record['stderr_sha256']
    for fixture, mode, _ in expected:
        pair = [row['stdout'] for row in rows if row['fixture'] == fixture and row['mode'] == mode]
        assert pair[0] == pair[1]
    identities = read(d / 'artifacts-before.json')
    assert identities == read(d / 'artifacts-after.json')
    assert all(sha(Path(name)) == row['sha256'] for name, row in identities.items())
auxiliary = read(p.parent / 'symbol-progress-2026-10-08/auxiliary-inputs.json')
assert all(sha(w / name) == digest for name, digest in auxiliary.items())

patch = subprocess.check_output(['git', 'diff', '--binary', base], cwd=w)
for name in sorted(set(source) - set(old_source)):
    diff = subprocess.run(['git', 'diff', '--no-index', '--binary', '/dev/null', name], cwd=w, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    assert diff.returncode == 1 and not diff.stderr
    patch += diff.stdout
(p / 'redirect-draft1.patch').write_bytes(patch)
base_files = set(subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', base], cwd=root, text=True).splitlines())
data = subprocess.check_output(['git', 'archive', base, '--', *sorted(set(source) & base_files)], cwd=root)
replay = Path(tempfile.mkdtemp(prefix='emaxx-redirect-symbol-replay-'))
with tarfile.open(fileobj=io.BytesIO(data)) as archive:
    for member in archive.getmembers():
        if not member.isfile():
            continue
        assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
        target = replay / member.name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(archive.extractfile(member).read())
        target.chmod(0o755 if member.mode & 0o111 else 0o644)
subprocess.run(['git', 'apply', '--whitespace=error-all', str(p / 'redirect-draft1.patch')], cwd=replay, check=True)
assert all(sha(replay / name) == row['sha256'] and oct((replay / name).stat().st_mode & 0o777) == row['mode'] for name, row in source.items())
result = dict(checkpoint='source316 draft', base=base, profiles=profiles, source_inputs=len(source), auxiliary_inputs=len(auxiliary), ordinary_audited=ordinary_audited, ordinary_processes=len(rows)+len(original_failures), ordinary_successful_processes=len(rows), ordinary_comparisons=len(rows)//2, preserved_failed_launcher_processes=len(original_failures), replay_verified=True, replay_directory=str(replay), patch_sha256=hashlib.sha256(patch).hexdigest(), original_test_selectors_retained=True, existing_test_corrections=['physical cell size 64 to 56 bytes', 'test-only alias removal cannot restore the old overwritten value; value/flag checks retained after a new plain store'], goal_complete=False, qualification='Selected gate/release controls, exact source replay, and ordinary comparisons only if ordinary_audited is true. The first ordinary cohort has 16 passes/two native launcher failures; only those two were repeated using GNU native-compile by function name. Every original failure is retained. The entry and all three fixture helpers are confirmed native in both successful followups. Value and alias now share a single payload. Allocated-symbol ownership and full-goal architecture, accounting, platform validation and performance acceptance remain incomplete.')
(p / ('selected-audit.json' if ordinary_audited else 'profiles-audit.json')).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['source_inputs', 'ordinary_processes', 'replay_verified', 'patch_sha256', 'existing_test_corrections']}))
