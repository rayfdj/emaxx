import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root = Path('/Users/nbmhqa186/projects/emaxx')
worktree = root / 'target/runtime-goal/recovered-2026-10-09/symbol-ownership/emaxx'
evidence = root / 'target/runtime-goal/symbol-ownership-2026-10-09'
destination = evidence / 'redirect-draft1-ordinary'
destination.mkdir(exist_ok=False)
gnu = root / 'target/runtime-goal/rebuilt-2026-10-01/emacs'
overrides = json.loads((evidence/'redirect-draft1/environment.json').read_text())
overrides.pop('EMAXX_FIXTURE_IMAGE_DIR')
overrides.pop('EMAXX_IMAGE_TEMPLATE')
overrides['EMAXX_IMAGE_FORCE'] = '1'
environment = {**os.environ, **overrides}
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
source = json.loads((evidence/'redirect-draft1/source.json').read_text())
def check_source():
    for name, row in source.items():
        assert sha(worktree/name) == row['sha256'], name
        assert oct((worktree/name).stat().st_mode & 0o777) == row['mode'], name
check_source()
(destination/'source.json').write_text(json.dumps(source,indent=2)+'\n')
(destination/'environment.json').write_text(json.dumps(overrides,indent=2)+'\n')
def run(label, command, timeout):
    start=time.monotonic()
    print('START',label,flush=True)
    with (destination/(label+'.stdout')).open('wb') as out, (destination/(label+'.stderr')).open('wb') as err:
        try:
            result=subprocess.run(command,cwd=worktree,env=environment,stdout=out,stderr=err,timeout=timeout)
            status=result.returncode
            timed_out=False
        except subprocess.TimeoutExpired:
            status=None
            timed_out=True
    receipt=dict(command=command,cwd=str(worktree),exit_code=status,timed_out=timed_out,
                 timeout_seconds=timeout,elapsed_seconds=time.monotonic()-start,
                 stdout_sha256=sha(destination/(label+'.stdout')),
                 stderr_sha256=sha(destination/(label+'.stderr')))
    (destination/(label+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
    check_source()
    print('END',label,status,round(receipt['elapsed_seconds'],2),flush=True)
    return receipt
build=run('build',['cargo','build','--locked','--offline','--release','--all-features',
                  '--bin','emaxx','--bin','make-fingerprint','--message-format=json'],1800)
assert build['exit_code']==0, 'ordinary binary build failed'
binary=worktree/'target/release/emaxx'
image=run('image',['sh','tools/build-image.sh',str(binary)],1800)
assert image['exit_code']==0, 'ordinary image build failed'
artifacts=[binary,binary.with_suffix('.pdmp'),gnu/'src/emacs',gnu/'src/emacs.pdmp']
identities={str(path):dict(sha256=sha(path),bytes=path.stat().st_size) for path in artifacts}
(destination/'artifacts-before.json').write_text(json.dumps(identities,indent=2)+'\n')
fixtures=['symbol-field-lifetime','symbol-field-weak-finalizer','symbol-load-history-lifetime','symbol-plist-put-sharing','symbol-redirect-lifetime']
results=[]
for fixture in fixtures:
    program=(worktree/'tests/fixtures'/ (fixture+'.el')).read_text()
    expected=(worktree/'tests/fixtures'/(fixture+'.expected')).read_text().strip()
    modes=['interpreted','bytecode','native'] if fixture in ['symbol-plist-put-sharing','symbol-redirect-lifetime'] else ['interpreted']
    for mode in modes:
        if mode=='interpreted':
            expression='(prin1 '+program+')'
            wanted=expected
        else:
            library='bytecomp' if mode=='bytecode' else 'comp'
            compiler='byte-compile' if mode=='bytecode' else 'native-compile'
            predicate='byte-code-function-p' if mode=='bytecode' else 'native-comp-function-p'
            expression=f"(progn (require '{library}) (let ((function ({compiler} '(lambda () {program})))) (prin1 (list ({predicate} function) (funcall function)))))"
            wanted='(t '+expected+')'
            if fixture == 'symbol-redirect-lifetime':
                # Install the fixture's unchanged defuns, then compile every
                # helper and the exact last form. Re-evaluating its full progn
                # here would replace the helpers with interpreted definitions.
                import json
                helpers = '(symbol-redirect-fill symbol-redirect-read symbol-redirect-observe)'
                expression = f"(progn (require '{library}) (let* ((forms (cdr (read {json.dumps(program)}))) (names '{helpers})) (mapc #'eval (butlast forms)) (dolist (name names) (fset name ({compiler} (symbol-function name)))) (let ((function ({compiler} (cons 'lambda (cons nil (last forms)))))) (prin1 (list (cons ({predicate} function) (mapcar (lambda (name) ({predicate} (symbol-function name))) names)) (funcall function))))))"
                wanted = '((t t t t) ' + expected + ')'
        outputs={}
        for editor, executable in [('gnu',gnu/'src/emacs'),('emaxx',binary)]:
            label=fixture+'-'+mode+'-'+editor
            receipt=run(label,[str(executable),'-Q','--batch','--eval',expression],180)
            outputs[editor]=(destination/(label+'.stdout')).read_text()
            row=dict(fixture=fixture,mode=mode,editor=editor,exit_code=receipt['exit_code'],
                     expected=wanted,stdout=outputs[editor],passed=receipt['exit_code']==0 and outputs[editor].strip()==wanted)
            results.append(row)
            (destination/'results.json').write_text(json.dumps(results,indent=2)+'\n')
        print('MATCH',fixture,mode,outputs['gnu']==outputs['emaxx'],flush=True)
for name, identity in identities.items():
    assert sha(Path(name))==identity['sha256'], 'artifact changed: '+name
check_source()
(destination/'artifacts-after.json').write_text(json.dumps(identities,indent=2)+'\n')
summary=dict(processes=len(results),passed=sum(row['passed'] for row in results),
             failed=sum(not row['passed'] for row in results),source_inputs=len(source),goal_complete=False)
(destination/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
raise SystemExit(0 if summary['failed']==0 else 1)
