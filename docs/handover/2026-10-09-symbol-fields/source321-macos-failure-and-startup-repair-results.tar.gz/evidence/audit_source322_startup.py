from pathlib import Path
import hashlib,json,re,subprocess
p=Path(__file__).resolve().parent;r=p.parents[2];read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
sources=read(p/'source322-startup-gate2/source.json');previous=read(p/'image-draft10-final-owner/source.json')
assert len(sources)==len(previous)==565
assert [n for n in sources if sources[n]!=previous[n]]==['src/startup.rs']
before=subprocess.check_output(['git','show','6392d517178d6134fc120616dde1f548a6929349:src/startup.rs'],cwd=r,text=True)
after=(r/'src/startup.rs').read_text();old='''crate::compat::project_root()
            .join("../emacs/lisp")''';new='''crate::compat::configured_gnu_source_root()
            .join("lisp")'''
assert before.count(old)==1 and after==before.replace(old,new)
assert before.index(old)>before.index('#[cfg(test)]')
def stage(d,n,status=0):
 q=read(d/(n+'.json'));assert q['exit_code']==status
 for stream in ['stdout','stderr']:assert sha(d/(n+'.'+stream))==q[stream+'_sha256']
 return q
for n in ['fmt','check','clippy','diff']:
 stage(p/'source322-startup-gate2',n)
 for stream in ['stdout','stderr']:assert not re.search(r'^warning(?:\[.*?\])?:',(p/'source322-startup-gate2'/(n+'.'+stream)).read_text(),re.M)
profiles={}
for profile,label,old_label in [('gate','source322-startup-gate2','image-draft10-final-owner'),('release','source322-startup-release','image-draft10-release')]:
 d=p/label;assert read(d/'source.json')==read(d/'source-after.json')==sources
 selection=read(d/'selection.json');assert len(selection)==6 and all(n.startswith('startup::tests::') for n in selection)
 names=lambda f:{x[:-6] for x in f.read_text().splitlines() if x.endswith(': test')}
 assert names(d/'inventory.stdout')==names(p/old_label/'inventory.stdout')
 for n in ['build','inventory','focused']:stage(d,n)
 verdicts=re.findall(r'^test (\S+) \.\.\. (ok|FAILED|ignored)\s*$' ,(d/'focused.stdout').read_text(),re.M)
 assert len(verdicts)==6 and dict(verdicts)==dict.fromkeys(selection,'ok')
 assert 'test result: ok. 6 passed; 0 failed; 0 ignored;' in (d/'focused.stdout').read_text()
 binary=read(d/'binary.json');assert sha(Path(binary['retained']))==binary['sha256']
 profiles[profile]=dict(passed=6,ignored=0,inventory=len(names(d/'inventory.stdout')),binary=binary)
d=p/'source322-startup-empty-path-observation'
for editor in ['gnu','emaxx']:
 q=stage(d,editor);assert (d/(editor+'.stdout')).read_text()=='(t t t)' and not (d/(editor+'.stderr')).read_text()
assert read(d/'gnu.json')['command'][1:]==read(d/'emaxx.json')['command'][1:]
failed=p/'source322-startup-gate';stage(failed,'check',101)
result=dict(status='strict and six startup controls per profile passed',source_inputs_verified=565,unchanged_inputs=564,only_changed_input='src/startup.rs',production_source_unchanged=True,source_base='6392d517178d6134fc120616dde1f548a6929349',profiles=profiles,ordinary_gnu_and_emaxx=dict(predicates=3,comparisons=1,actual_results='(t t t)',directory=str(d)),previous_failed_compile=str(failed),qualification='Only the existing startup fixture selects the configured GNU Lisp root. The exact three entries, original-string sharing, environment restoration and dump-phase assertions are unchanged. Full source321 macOS failure stays failed; this selected repair does not certify complete source322 validation. GNU lread.c:load_path_default/init_lread choose installation/source paths, substitute defaults for every empty EMACSLOADPATH item and ignore the environment during dumping. The observed ordinary paired run confirms three entries and the required sharing.',goal_complete=False)
(p/'source322-startup-audit.json').open('x').write(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['status','production_source_unchanged','source_inputs_verified']},indent=2))
