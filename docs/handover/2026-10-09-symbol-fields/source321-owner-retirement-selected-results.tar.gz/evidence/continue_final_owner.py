from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
p=Path(__file__).resolve().parent
root=p.parents[2]
state_path=p/'final-owner-continuation-state.json'
assert not state_path.exists()
state=dict(status='waiting for selected candidate checks',started=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),results=[],goal_complete=False)
def save(): state_path.write_text(json.dumps(state,indent=2)+'\n')
def wait_pass(path, timeout):
 end=time.monotonic()+timeout
 while not path.exists():
  assert time.monotonic()<end, str(path)+' did not finish'
  time.sleep(5)
 data=json.loads(path.read_text());assert data['exit_code']==0, str(path)+' failed'
def run(stage,command):
 state['status']='running '+stage;save();print(state['status'],flush=True)
 start=time.monotonic()
 log=p/('final-owner-'+stage+'-supervisor.log')
 with log.open('xb') as out:
  result=subprocess.run(command,cwd=root,stdout=out,stderr=subprocess.STDOUT)
 row=dict(stage=stage,command=command,exit_code=result.returncode,elapsed_seconds=time.monotonic()-start,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
 state['results'].append(row);save();print(json.dumps(row),flush=True)
 assert result.returncode==0, stage+' failed'
try:
 save()
 wait_pass(p/'image-draft10-final-owner/focused.json',1800)
 run('release',[sys.executable,str(p/'validate_final_owner.py'),'image-draft10-release','focus','release'])
 run('ordinary',[sys.executable,str(p/'ordinary_final_owner.py')])
 state['status']='complete; inspect raw evidence';save()
except BaseException as e:
 state['status']='failed; preserve raw evidence';state['error']=str(e);save();raise
