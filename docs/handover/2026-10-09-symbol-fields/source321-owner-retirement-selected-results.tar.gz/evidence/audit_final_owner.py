from pathlib import Path
import hashlib
import io
import json
import re
import subprocess
import tarfile
import tempfile

p = Path(__file__).resolve().parent
r = p.parents[2]
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
base = '4905b3e7c7aabe2e25886fe1e0611715db93ec6d'
gate = p / 'image-draft10-final-owner'
source = read(gate / 'source.json')
assert len(source) == 565
for name, row in source.items():
    assert sha(r / name) == row['sha256'] and oct((r / name).stat().st_mode & 0o777) == row['mode'], name


def stage(directory, name, status=0, compiler=False):
    receipt = read(directory / (name + '.json'))
    assert receipt['exit_code'] == status
    for stream in ['stdout', 'stderr']:
        path = directory / (name + '.' + stream)
        assert sha(path) == receipt[stream + '_sha256']
        if compiler:
            assert not re.search(r'^warning(?:\[.*?\])?:', path.read_text(), re.M)
    return receipt


for name in ['fmt', 'check', 'clippy', 'diff']:
    stage(gate, name, compiler=True)
new = {'lisp::eval::tests::eval_02::canonical_symbol_weak_keys_follow_the_editors_lifetime', 'batch::tests::session_path_does_not_discover_the_gnu_test_tree'}
inventory_new = {'lisp::eval::tests::eval_02::canonical_symbol_weak_keys_follow_the_editors_lifetime'}
profiles = {}
for profile, label, old in [('gate', 'image-draft10-final-owner', 'image-draft8-edebug-owner'),
                            ('release', 'image-draft10-release', 'image-draft8-release')]:
    directory = p / label
    assert read(directory / 'source.json') == read(directory / 'source-after.json') == source
    selection = read(directory / 'selection.json')
    assert len(selection) == 235 and set(selection) == set(read(p / old / 'selection.json')) | new
    inventory = lambda path: [line[:-6] for line in path.read_text().splitlines() if line.endswith(': test')]
    names, old_names = inventory(directory / 'inventory.stdout'), inventory(p / old / 'inventory.stdout')
    assert len(names) == len(set(names)) == len(old_names) + 1 and set(names) == set(old_names) | inventory_new
    for name in ['build', 'inventory', 'focused']:
        stage(directory, name, compiler=name == 'build')
    verdicts = re.findall(r'^test (\S+) \.\.\. (ok|FAILED|ignored)\s*$', (directory / 'focused.stdout').read_text(), re.M)
    assert len(verdicts) == 235 and dict(verdicts) == dict.fromkeys(selection, 'ok')
    binary = read(directory / 'binary.json')
    assert sha(Path(binary['retained'])) == binary['sha256']
    profiles[profile] = dict(passed=235, failed=0, ignored=0, inventory=len(names), executable=binary)
negative = p.parent / 'allocated-symbols-2026-10-10/fields-draft8-retirement-negative'
stage(negative, 'focused', 101)
assert 'test result: FAILED. 0 passed; 1 failed; 0 ignored;' in (negative / 'focused.stdout').read_text()
assert "a retired editor's canonical symbols are not permanent weak roots" in (negative / 'focused.stdout').read_text()
patch = p / 'image-draft10.patch'
data = subprocess.check_output(['git', 'diff', '--binary', base, '--', 'src', 'tests'], cwd=r)
with patch.open('xb') as stream:
    stream.write(data)
raw = subprocess.check_output(['git', 'archive', base, '--', *source], cwd=r)
with tempfile.TemporaryDirectory(prefix='emaxx-edebug-owner-replay-') as temporary:
    replay = Path(temporary)
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        for entry in archive.getmembers():
            if entry.isfile():
                target = replay / entry.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(archive.extractfile(entry).read())
                target.chmod(0o755 if entry.mode & 0o111 else 0o644)
    subprocess.run(['git', 'apply', str(patch)], cwd=replay, check=True)
    for name, row in source.items():
        assert sha(replay / name) == row['sha256'] and oct((replay / name).stat().st_mode & 0o777) == row['mode'], name
result = dict(checkpoint='source321 owner retirement and configured path control', status='strict and selected gate/release passed',
    source_inputs_verified=565, previous_controls_retained=233, new_controls=sorted(new), profiles=profiles,
    patch=dict(path=patch.name, sha256=sha(patch), base=base, replayed_source_inputs=565),
    preserved_negative=dict(directory=negative.name, receipt_sha256=sha(negative / 'focused.json'),
        source_sha256=sha(negative / 'source.json'), stdout_sha256=sha(negative / 'focused.stdout')),
    qualification='The same canonical-symbol shortcut retained a weak key after its editor retired. The negative is preserved in the allocated-field prototype; this published-runtime follow-up passes the identical parked-owner survival and retirement control in both profiles. Weak survival now tests the actual object mark, following GNU alloc.c. The only other change corrects an existing startup fixture to use the configured GNU source path; the runtime startup implementation and environment-independence assertions are unchanged. Actual GNU processes verify unchanged load-path with and without EMACS_TEST_DIRECTORY. Source320 Linux, failed macOS Rust and timing results remain separate historical evidence. Full validation, remaining architecture and final performance acceptance are open',
    goal_complete=False)
with (p / 'source321-owner-retirement-audit.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({key:result[key] for key in ['status','source_inputs_verified','profiles','patch']},indent=2))
