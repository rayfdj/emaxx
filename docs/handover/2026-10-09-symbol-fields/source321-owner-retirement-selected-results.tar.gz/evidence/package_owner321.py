from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).resolve().parent
r = p.parents[2]
fp = p.parent / 'allocated-symbols-2026-10-10'
destination = r / 'docs/handover/2026-10-09-symbol-fields'
read = lambda path: json.loads(path.read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()


def package(name, trees, files, information):
    members, excluded = {}, []

    def add(name, path):
        data = path.read_bytes()
        if len(data) > 1_000_000 and (path.name in ['libtest', 'emaxx', 'emacs'] or path.suffix == '.pdmp'):
            excluded.append(dict(path=str(path), bytes=len(data), sha256=sha(data)))
        else:
            assert name not in members
            members[name] = data

    for prefix, directory in trees:
        for path in sorted(directory.rglob('*')):
            if path.is_file():
                add(prefix + '/' + str(path.relative_to(directory)), path)
    for prefix, path in files:
        add(prefix, path)
    members['contents.json'] = (json.dumps({key:dict(bytes=len(data), sha256=sha(data)) for key,data in members.items()},indent=2)+'\n').encode()
    buffer = io.BytesIO()
    with gzip.GzipFile(fileobj=buffer, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for key, data in sorted(members.items()):
                entry = tarfile.TarInfo(key)
                entry.size, entry.mode = len(data), 0o644
                archive.addfile(entry, io.BytesIO(data))
    data = buffer.getvalue()
    path = destination / (name + '.tar.gz')
    with path.open('xb') as stream:
        stream.write(data)
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
        assert set(archive.getnames()) == set(members)
        assert all(archive.extractfile(key).read() == value for key,value in members.items())
    manifest = dict(archive=dict(path=path.name, bytes=len(data), sha256=sha(data), members=len(members)),
                    excluded_large_inputs=excluded, goal_complete=False, **information)
    with (destination / (name + '-manifest.json')).open('x') as stream:
        json.dump(manifest, stream, indent=2)
        stream.write('\n')
    print(json.dumps(manifest['archive']), flush=True)


audit = read(p / 'source321-owner-retirement-audit.json')
ordinary = read(p / 'source321-ordinary-audit.json')
assert all(v['passed']==235 for v in audit['profiles'].values())
assert ordinary['comparisons']==12
package('source321-owner-retirement-selected-results',
    [('evidence/'+label,p/label) for label in ['image-draft9-retirement-mark','image-draft9-release',
      'image-draft10-final-owner','image-draft10-release','image-draft10-ordinary']]
    + [('evidence/fields-draft8-retirement-negative',fp/'fields-draft8-retirement-negative')],
    [('evidence/'+name,p/name) for name in ['source321-owner-retirement-audit.json','source321-ordinary-audit.json',
      'image-draft10.patch','audit_final_owner.py','audit_final_owner_ordinary.py','validate_final_owner.py',
      'validate_owner_retirement.py','ordinary_final_owner.py','continue_final_owner.py','continue_owner_retirement.py',
      'owner-retirement-preparation.json','owner-retirement-continuation-state.json','owner-retirement-release-supervisor.log',
      'final-owner-continuation-state.json','final-owner-release-supervisor.log','final-owner-ordinary-supervisor.log',
      'load-path-gnu-audit.json','load-path-gnu-unset.stdout','load-path-gnu-unset.stderr',
      'load-path-gnu-test-tree.stdout','load-path-gnu-test-tree.stderr','package_owner321.py']]
    + [('evidence/previous/'+label+'/'+name,p/label/name) for label in ['image-draft8-edebug-owner','image-draft8-release'] for name in ['selection.json','inventory.stdout']],
    dict(checkpoint='source321 owner retirement and configured startup fixture',audit=audit,ordinary_audit=ordinary))
