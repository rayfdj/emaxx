from pathlib import Path
import hashlib
import json
import sys
import urllib.error
import urllib.request
import zipfile

p = Path(__file__).resolve().parent
artifact_id, digest, run_id, label = sys.argv[1:]
assert artifact_id.isdecimal() and run_id.isdecimal()
assert label in ['source314-linux-rust', 'source314-linux-frozen']
destination = p / label
destination.mkdir(exist_ok=False)
namespace = {}
exec((p / 'github_ci.py').read_text().split('operation=sys.argv[1]')[0], namespace)

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None

request = urllib.request.Request(
    'https://api.github.com/repos/rayfdj/emaxx/actions/artifacts/' + artifact_id + '/zip',
    headers={'Authorization': 'Basic ' + namespace['authorization'],
             'Accept': 'application/vnd.github+json', 'User-Agent': 'emaxx-runtime-validation'})
try:
    with urllib.request.build_opener(NoRedirect).open(request, timeout=30) as response:
        data = response.read()
except urllib.error.HTTPError as error:
    assert error.code in (301, 302, 303, 307, 308), error.code
    location = error.headers['Location']
    assert location.startswith('https://')
    # The temporary artifact URL receives no GitHub credential.
    with urllib.request.urlopen(location, timeout=45) as response:
        data = response.read()
assert hashlib.sha256(data).hexdigest() == digest
archive = destination / 'artifact.zip'
archive.write_bytes(data)
with zipfile.ZipFile(archive) as zipped:
    for member in zipped.infolist():
        name = Path(member.filename)
        assert not name.is_absolute() and '..' not in name.parts
    zipped.extractall(destination / 'raw')
receipt = dict(artifact_id=int(artifact_id), run_id=int(run_id),
               source_commit=namespace['commit'], sha256=digest, bytes=len(data))
(destination / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
