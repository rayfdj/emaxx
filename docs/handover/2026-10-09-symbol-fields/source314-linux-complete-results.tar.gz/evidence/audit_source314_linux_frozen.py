from pathlib import Path
import hashlib, json, subprocess, sys
p = Path(__file__).parent.resolve(); root = p.parents[2]
artifact = p / 'source314-linux-frozen/raw'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda f: json.loads(f.read_text())
head = '2712c05779e47ec9b8a7c89121d1a79fdcc42596'
terminal = read(p/'source314-linux-status.json');assert terminal['commit']==head
run = next(row for row in terminal['runs'] if row['id']==37869845574)
assert run['status']=='completed' and run['conclusion']=='success'
summaries = list(artifact.rglob('summary.json')); assert len(summaries) == 1
frozen = summaries[0].parent
subprocess.run([sys.executable, str(p/'verify_complete_linux_frozen.py'), str(frozen), head,
                '37869845574', str(p/'source314-linux-frozen-complete-audit.json')], cwd=root, check=True)
summary = read(summaries[0])
for file in summary['files']:
    directory = (frozen/file).with_suffix('.compat')
    execution = read(directory/'execution.json')
    assert execution['contract_sha256'] == sha(frozen/'contract.json')
    assert all(sha(directory/n) == h for n,h in execution['sha256'].items())
    pair = [read(directory/(runner+'.json')) for runner in ('oracle','emaxx')]
    assert {r['name']:(r['status'],r['expected']) for r in pair[0]['results']} == {r['name']:(r['status'],r['expected']) for r in pair[1]['results']}
    if file == 'test/src/comp-tests.el':
        assert all(len(report['results']) == 177 and all(r['status']=='passed' and r['expected'] for r in report['results']) for report in pair)
capture = read(artifact/'oracle-inputs/manifest.json')
verification = read(artifact/'oracle-inputs/verification.json')
assert capture['status'] == 'captured' and verification['status'] == 'unchanged'
assert verification['capture_manifest_sha256'] == sha(artifact/'oracle-inputs/manifest.json')
assert verification['files_verified'] == len(capture['files']) == 4 and not capture['source_tracked_changes']
assert capture['source_commit'] == summary['provenance']['oracle_repo_commit']
for item in capture['files']:
    f = artifact/'oracle-inputs'/item['artifact']
    assert f.stat().st_size == item['bytes'] and sha(f) == item['sha256']
assert capture['files'][0]['sha256'] == summary['provenance']['oracle_sha256']
files = {str(f.relative_to(artifact)):sha(f) for f in artifact.rglob('*') if f.is_file()}
result = dict(status='passed', files=519, outcomes=7928, successful_processes=1038,
              source_commit=head, run_id=37869845574, raw_artifact_directory=str(artifact),
              raw_files=files, oracle_capture=capture, oracle_verification=verification,
              qualification='Complete source314 Linux frozen inventory, outputs, execution hashes and retained GNU inputs verified. Expected failures and skips remain distinct from passes. The separate Rust workflow has its own complete raw audit; earlier GNU reference failures and macOS diagnostic differences remain preserved. These frozen results do not certify later candidates, macOS or full-goal completion', goal_complete=False)
with (p/'source314-linux-frozen-raw-integrity-audit.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps({k:result[k] for k in ('status','files','outcomes','successful_processes')}))
