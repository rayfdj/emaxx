import base64
import datetime
import json
import os
from pathlib import Path
import subprocess
import sys
import urllib.error
import urllib.request

evidence=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/symbol-progress-2026-10-08')
commit=json.loads((evidence/'source314-commit.json').read_text())['commit']
credential_process=subprocess.run(['git','credential','fill'],input='protocol=https\nhost=github.com\npath=rayfdj/emaxx.git\n\n',text=True,capture_output=True,timeout=25,check=True,env={**os.environ,'GIT_TERMINAL_PROMPT':'0'})
credential=dict(line.split('=',1) for line in credential_process.stdout.splitlines() if '=' in line)
authorization=base64.b64encode((credential.get('username','x-access-token')+':'+credential['password']).encode()).decode()
def request(path, method='GET', body=None):
    url='https://api.github.com/repos/rayfdj/emaxx/'+path
    encoded=json.dumps(body).encode() if body is not None else None
    headers={'Authorization':'Basic '+authorization,'Accept':'application/vnd.github+json','User-Agent':'emaxx-runtime-validation'}
    if encoded is not None:headers['Content-Type']='application/json'
    req=urllib.request.Request(url,data=encoded,method=method,headers=headers)
    with urllib.request.urlopen(req,timeout=30) as response:
        raw=response.read()
        return response.status,json.loads(raw) if raw else None
operation=sys.argv[1]
if operation=='dispatch':
    receipt=evidence/'source314-linux-dispatch.json'
    assert not receipt.exists(), 'do not duplicate dispatches'
    _,ref=request('git/ref/heads/runtime-char-tables')
    assert ref['object']['sha']==commit
    record=dict(commit=commit,ref='runtime-char-tables',started=datetime.datetime.now(datetime.timezone.utc).isoformat(),dispatches=[],goal_complete=False)
    receipt.write_text(json.dumps(record,indent=2)+'\n')
    for validation in ['rust','frozen','core-runtime-pair']:
        body=dict(ref='runtime-char-tables',inputs=dict(validation=validation))
        if validation=='core-runtime-pair':body['inputs']['baseline_revision']='b724bab0d945a68f1049233b6212930525a25ded'
        status,_=request('actions/workflows/frozen-run.yml/dispatches','POST',body)
        record['dispatches'].append(dict(body=body,http_status=status))
        receipt.write_text(json.dumps(record,indent=2)+'\n')
        print('DISPATCH',validation,status,flush=True)
elif operation=='status':
    _,data=request('actions/workflows/frozen-run.yml/runs?event=workflow_dispatch&per_page=30')
    runs=[row for row in data['workflow_runs'] if row['head_sha']==commit]
    summary=[]
    for row in runs:
        _,jobs=request('actions/runs/'+str(row['id'])+'/jobs')
        summary.append(dict(id=row['id'],url=row['html_url'],status=row['status'],conclusion=row['conclusion'],created_at=row['created_at'],jobs=[dict(id=job['id'],name=job['name'],status=job['status'],conclusion=job['conclusion'],steps=job['steps']) for job in jobs['jobs']]))
    record=dict(commit=commit,observed=datetime.datetime.now(datetime.timezone.utc).isoformat(),runs=summary)
    (evidence/'source314-linux-status.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps([dict(id=row['id'],url=row['url'],status=row['status'],conclusion=row['conclusion'],active_steps=[step['name'] for job in row['jobs'] for step in job['steps'] if step['status']=='in_progress']) for row in summary],indent=2))
else:
    raise ValueError('unknown operation')
