from pathlib import Path
import hashlib
import io
import json
import re
import subprocess
import sys
import tarfile

evidence = Path(__file__).resolve().parent
repository = evidence.parents[2]
checkout = evidence.parent / 'recovered-2026-10-08/symbol-plists/emaxx'
artifact = evidence / 'source314-linux-rust/raw'
root = artifact / 'rust'
head = '2712c05779e47ec9b8a7c89121d1a79fdcc42596'
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
summary = read(root / 'summary.json')
assert summary['status'] == 'passed' and summary['scope'] == 'full'
assert summary['git'] == {'dirty': False, 'head': head}
terminal = read(evidence / 'source314-linux-status.json')
assert terminal['commit'] == head
run_receipt = next(r for r in terminal['runs'] if r['id'] == 37869843422)
assert run_receipt['status'] == 'completed' and run_receipt['conclusion'] == 'success'
source = read(evidence / 'symbol-draft4/source.json')
assert len(source) == 560
for name, entry in source.items():
    assert sha(checkout / name) == entry['sha256'], name
    assert oct((checkout / name).stat().st_mode & 0o777) == entry['mode'], name
published = subprocess.check_output(['git', 'archive', head, '--', *source], cwd=repository)
with tarfile.open(fileobj=io.BytesIO(published)) as archive:
    for name, entry in source.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == entry['sha256']
        mode = '0o755' if archive.getmember(name).mode & 0o111 else '0o644'
        assert mode == entry['mode']
inventory = [line[:-6] for line in (root / 'inventory.txt').read_text().splitlines() if line.endswith(': test')]
assert len(inventory) == len(set(inventory)) == 3072
assert summary['inventory']['ignored_tests'] == ['tty::tty_differential_end_to_end', 'tty::tty_smoke_end_to_end']
assert summary['repetitions'] == 1 and len(summary['runs']) == 1
run = summary['runs'][0]
assert run['expected_tests'] == run['observed_outcomes'] == summary['inventory']['scheduled_tests'] == 3072
assert {group['group'] for group in run['groups']} == set(summary['inventory']['groups'])
assert len(run['groups']) == len(summary['inventory']['groups'])
pattern = r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;'
seen = []
passed = ignored = 0
for group in run['groups']:
    assert group['exit_code'] == 0 and not group['timed_out']
    result = group['result']
    assert result['status'] == 'ok' and result['failed'] == result['measured'] == 0
    assert result['passed'] + result['ignored'] == group['expected_tests'] == summary['inventory']['groups'][group['group']]
    assert result['ignored'] == group['expected_ignored']
    log = (root / Path(group['log']).name).read_text()
    assert re.findall(pattern, log) == [('ok', str(result['passed']), '0', str(result['ignored']), '0', str(result['filtered_out']))]
    starts = list(re.finditer(r'^test (\S+) \.\.\. ', log, re.M))
    assert len(starts) == group['expected_tests']
    for index, match in enumerate(starts):
        end = starts[index + 1].start() if index + 1 < len(starts) else log.rindex('test result:')
        verdict = log[match.end():end].strip()
        if match[1] in summary['inventory']['ignored_tests']:
            assert verdict.startswith('ignored')
        else:
            assert re.search(r'(?:^|\s)ok$', verdict), (match[1], verdict)
        seen.append(match[1])
    passed += result['passed']
    ignored += result['ignored']
assert sorted(seen) == sorted(inventory) and len(seen) == len(set(seen))
assert ignored == 2
assert [stage['stage'] for stage in summary['cargo_stages']] == ['bins', 'integration']
cargo = {}
for stage in summary['cargo_stages']:
    assert stage['exit_code'] == 0
    log = (root / Path(stage['log']).name).read_text()
    assert not re.search(r'^warning(?:\[.*?\])?:', log, re.M)
    rows = re.findall(pattern, log)
    assert len(rows) == len(stage['results']) > 0
    for row, result in zip(rows, stage['results']):
        assert result['status'] == 'ok'
        assert result['failed'] == result['ignored'] == result['measured'] == result['filtered_out'] == 0
        assert row == ('ok', str(result['passed']), '0', '0', '0', '0')
    cargo[stage['stage']] = sum(result['passed'] for result in stage['results'])
identity = [line for line in (root / 'integration.log').read_text().splitlines() if line.startswith('test unchanged_gnu_sources_produce_identical_native_artifacts ')]
assert len(identity) == 1 and identity[0].endswith(' ... ok')

retained = root / 'retained-inputs'
record = read(retained / 'manifest.json')
assert record['status'] == 'retained' and record['gate_status'] == 'passed'
assert record['gate_summary_sha256'] == sha(root / 'summary.json')
for entry in record['files']:
    path = retained / entry['artifact']
    assert sha(path) == entry['sha256'] and path.stat().st_size == entry['bytes']
assert next(entry for entry in record['files'] if entry['artifact'] == 'libtest')['sha256'] == summary['test_binary']['sha256']
result = dict(status='passed', source_commit=head, validation_checkout=summary['git'],
              unchanged_source_inputs=len(source), raw_library_names_verified=len(seen), library_passed=passed,
              library_ignored=ignored, cargo_passed=cargo, total_passed=passed + sum(cargo.values()),
              native_artifact_identity='passed', retained_files_verified=len(record['files']),
              test_binary_sha256=summary['test_binary']['sha256'], summary_sha256=sha(root / 'summary.json'),
              qualification='Full Linux gate records a clean source314 checkout. All 560 frozen runtime inputs match the published commit; every raw library name/verdict, Cargo summary and retained artifact identity is checked. Post-run fixture images do not identify per-test use. Frozen, macOS and performance evidence is separate.',
              goal_complete=False)

prior = evidence.parent / 'resume-2026-09-28/source313-linux-rust-artifacts/ordinary-linux-6ab3346049f08a08c5fbb842fc3f737c22c40c75/rust/inventory.txt'
old_inventory = {line[:-6] for line in prior.read_text().splitlines() if line.endswith(': test')}
assert old_inventory <= set(inventory) and len(set(inventory) - old_inventory) == 6
cap = artifact / 'oracle-inputs'
capture = read(cap / 'manifest.json')
verification = read(cap / 'verification.json')
assert capture['source_commit'] == '636f166cfc86aa90d63f592fd99f3fdd9ef95ebd' and not capture['source_tracked_changes']
assert capture['status'] == 'captured' and verification['status'] == 'unchanged'
assert verification['capture_manifest_sha256'] == sha(cap / 'manifest.json')
assert verification['files_verified'] == len(capture['files']) == 4
for item in capture['files']:
    assert sha(cap / item['artifact']) == item['sha256']
    assert (cap / item['artifact']).stat().st_size == item['bytes']
assert capture['files'][0]['sha256'] == '5e1721732427d69d8af63211f1e3833ec21e40f97f4b7f6cd4cb224b72cebfcf'
assert capture['files'][1]['sha256'] == 'bf4974228f3b3ea4374cec75a38eeb2bd0e7dd944da5bec4e6ad0387092502ae'
result['oracle_inputs_verified'] = 4
result['existing_library_names_preserved'] = len(old_inventory)
result['added_library_tests'] = sorted(set(inventory) - old_inventory)
result['run_id'] = 37869843422
with (evidence / 'source314-linux-rust-audit.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(result, indent=2))
