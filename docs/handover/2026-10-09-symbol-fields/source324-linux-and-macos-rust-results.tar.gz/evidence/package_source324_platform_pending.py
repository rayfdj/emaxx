from pathlib import Path
import json

p = Path(__file__).resolve().parent
ns = {'__file__': str(p / 'package_source323_base.py')}
exec((p / 'package_source323_base.py').read_text(), ns)
destination = p / 'pending-publication-source324'
destination.mkdir(exist_ok=True)
ns['destination'] = destination
read = lambda path: json.loads(path.read_text())
entries = lambda names: [('evidence/' + name, p / name) for name in names]
assert read(p / 'source324-linux-rust-audit.json')['total_passed'] == 3190
assert read(p / 'source324-macos-rust-audit.json')['total_passed'] == 3178
assert read(p / 'source324-linux-frozen-raw-integrity-audit.json')['status'] == 'passed'
ns['package']('source324-linux-and-macos-rust-results',
    entries(['source324-linux-rust/raw', 'source324-linux-frozen/raw', 'source324-macos-full']),
    entries(['source324-commit.json', 'source324-source.json', 'source324-linux-dispatch.json',
        'source324-linux-status.json', 'source324_ci.py', 'fetch_source324_artifacts.py',
        'source324-linux-rust/receipt.json', 'source324-linux-frozen/receipt.json',
        'source324-linux-rust-audit.json', 'audit_source324_linux_rust.py',
        'audit_source324_linux_rust.invalid-head.py',
        'source324-linux-frozen-complete-audit.json', 'source324-linux-frozen-raw-integrity-audit.json',
        'audit_source324_linux_frozen.py', 'verify_complete_linux_frozen.py',
        'source324-macos-rust-audit.json', 'audit_source324_macos_rust.py', 'validate_source324.py',
        'package_source323_base.py', Path(__file__).name]),
    dict(checkpoint='source324 complete Linux validation and full macOS Rust gate',
        source_commit=read(p / 'source324-commit.json')['commit'],
        linux_rust=read(p / 'source324-linux-rust-audit.json'),
        linux_frozen=read(p / 'source324-linux-frozen-complete-audit.json'),
        macos_rust=read(p / 'source324-macos-rust-audit.json'),
        qualification='Source324 has3190 Linux and3178 macOS Rust passes, each with only two existing ignores, exact native artifact identity and all prior library names preserved. Full Linux frozen has519 files/7928 matching outcomes/1038 successful processes. All572 source inputs match the immutable commit; raw verdicts, inventories and retained artifact hashes are independently checked. The first Linux audit helper rejected its accidentally changed expected commit immediately, before reporting any result; its failed source is retained beside the corrected auditor. MacOS frozen and terminal are still separate and unfinished; performance has its own diagnostic audit. Large retained binary/image bytes are explicitly excluded from the portable text archive.'))
