from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess
import sys
import time

p = Path(__file__).resolve().parent
r = p.parents[2]
g = p.parent / 'rebuilt-2026-10-01/emacs'
out = p / 'source324-macos-full'
out.mkdir(exist_ok=False)
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
source = read(p / 'source324-source.json')
commit = read(p / 'source324-commit.json')['commit']
assert len(source) == 572
overrides = dict(LANG='C', LC_ALL='C', CARGO_BUILD_JOBS='1', CARGO_NET_OFFLINE='true',
    RUST_TEST_THREADS='1', RUST_MIN_STACK='134217728', EMAXX_GC_VERIFY='1',
    EMAXX_IMAGE_TEMPLATE='1', EMAXX_GNU_SOURCE_DIRECTORY=str(g),
    EMAXX_DUMP_SOURCE_DIRECTORY=str(g), EMACS_TEST_DIRECTORY=str(g / 'test'),
    EMAXX_FIXTURE_IMAGE_DIR=str(r / 'target/grouped-gate/fixture-images'))
state = dict(status='preflight', pid=os.getpid(), started=datetime.datetime.now(datetime.timezone.utc).isoformat(), commit=commit, results=[], goal_complete=False)


def save():
    (out / 'state.json').write_text(json.dumps(state, indent=2) + '\n')


def verify():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=r, text=True).strip() == commit
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=r).strip()
    for name, row in source.items():
        f = r / name
        assert sha(f) == row['sha256'] and oct(f.stat().st_mode & 0o777) == row['mode'], name


save()
try:
    verify()
    (out / 'source.json').write_text(json.dumps(source, indent=2) + '\n')
    (out / 'environment.json').write_text(json.dumps(overrides, indent=2) + '\n')
    (out / 'tracked.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary'], cwd=r))
    commands = [
        ('fmt', ['cargo', 'fmt', '--all', '--', '--check']),
        ('check', ['cargo', 'check', '--locked', '--offline', '--all-targets', '--all-features']),
        ('clippy', ['cargo', 'clippy', '--locked', '--offline', '--all-targets', '--all-features', '--', '-D', 'warnings']),
        ('diff', ['git', 'diff', '--check']),
        ('full', [sys.executable, 'tools/serial_grouped_gate.py', '--scope', 'full', '--artifact-root', str(out / 'full')]),
    ]
    for name, command in commands:
        verify()
        state.update(status='running ' + name, current_command=command)
        save()
        print('START', name, flush=True)
        start = time.monotonic()
        with (out / (name + '.stdout')).open('xb') as stdout, (out / (name + '.stderr')).open('xb') as stderr:
            result = subprocess.run(command, cwd=r, env={**os.environ, **overrides}, stdout=stdout, stderr=stderr)
        row = dict(command=command, cwd=str(r), exit_code=result.returncode, elapsed_seconds=time.monotonic() - start, stdout_sha256=sha(out / (name + '.stdout')), stderr_sha256=sha(out / (name + '.stderr')))
        (out / (name + '.json')).write_text(json.dumps(row, indent=2) + '\n')
        state['results'].append(dict(stage=name, **row))
        save()
        print('END', name, result.returncode, round(row['elapsed_seconds'], 2), flush=True)
        verify()
        if name == 'full' and (out / 'full/summary.json').exists():
            sys.path.insert(0, str(r / 'tools'))
            import retain_rust_gate_artifacts
            state['retention'] = retain_rust_gate_artifacts.retain(out / 'full/summary.json', r / 'target/grouped-gate/fixture-images')
            save()
        if result.returncode:
            raise RuntimeError(name + ' failed; original stdout/stderr and raw results retained')
        for stream in ['stdout', 'stderr']:
            assert not re.search(r'^warning(?:\[.*?\])?:', (out / (name + '.' + stream)).read_text(), re.M), 'Unresolved compiler warning'
    verify()
    (out / 'source-after.json').write_text(json.dumps(source, indent=2) + '\n')
    state.update(status='passed; audit full raw inventory next', source_unchanged=True)
    save()
except BaseException as error:
    state.update(status='failed; preserve raw evidence', error=str(error))
    save()
    raise
