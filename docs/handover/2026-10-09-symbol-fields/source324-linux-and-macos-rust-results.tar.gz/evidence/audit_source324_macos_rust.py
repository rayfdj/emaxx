from pathlib import Path
import hashlib
import io
import json
import re
import subprocess
import sys
import tarfile

evidence = Path(__file__).resolve().parent
repository = evidence.parents[2]
checkout = repository
root = evidence / 'source324-macos-full/full'
head = json.loads((evidence / 'source324-commit.json').read_text())['commit']
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
summary = read(root / 'summary.json')
assert summary['status'] == 'passed' and summary['scope'] == 'full'
assert summary['git'] == {'dirty': False, 'head': head}
source = read(evidence / 'source324-macos-full/source.json')
assert len(source) == 572
post_run_source = {name: dict(sha256=sha(checkout / name), mode=oct((checkout / name).stat().st_mode & 0o777)) for name in source}
assert source == post_run_source
assert source == read(evidence / 'source324-macos-full/source-after.json') == read(evidence / 'source324-source.json')
published = subprocess.check_output(['git', 'archive', head, '--', *source], cwd=repository)
with tarfile.open(fileobj=io.BytesIO(published)) as archive:
    for name, entry in source.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == entry['sha256']
        assert ('0o755' if archive.getmember(name).mode & 0o111 else '0o644') == entry['mode']
receipt = read(evidence / 'source324-macos-full/full.json')
assert receipt['exit_code'] == 0
for stream in ['stdout', 'stderr']:
    assert sha(evidence / ('source324-macos-full/full.' + stream)) == receipt[stream + '_sha256']

inventory = [line[:-6] for line in (root / 'inventory.txt').read_text().splitlines() if line.endswith(': test')]
assert len(inventory) == len(set(inventory)) == 3081
assert summary['inventory']['ignored_tests'] == ['tty::tty_differential_end_to_end', 'tty::tty_smoke_end_to_end']
assert summary['repetitions'] == 1 and len(summary['runs']) == 1
run = summary['runs'][0]
assert run['expected_tests'] == run['observed_outcomes'] == summary['inventory']['scheduled_tests'] == 3081
assert {group['group'] for group in run['groups']} == set(summary['inventory']['groups'])
assert len(run['groups']) == len(summary['inventory']['groups'])
pattern = r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;'
seen = []
passed = ignored = 0
for group in run['groups']:
    assert group['exit_code'] == 0 and not group['timed_out']
    result = group['result']
    assert result['status'] == 'ok' and result['failed'] == result['measured'] == 0
    assert result['passed'] + result['ignored'] == group['expected_tests'] == summary['inventory']['groups'][group['group']]
    assert result['ignored'] == group['expected_ignored']
    log = (root / Path(group['log']).name).read_text()
    assert re.findall(pattern, log) == [('ok', str(result['passed']), '0', str(result['ignored']), '0', str(result['filtered_out']))]
    starts = list(re.finditer(r'^test (\S+) \.\.\. ', log, re.M))
    assert len(starts) == group['expected_tests']
    for index, match in enumerate(starts):
        end = starts[index + 1].start() if index + 1 < len(starts) else log.rindex('test result:')
        verdict = log[match.end():end].strip()
        if match[1] in summary['inventory']['ignored_tests']:
            assert verdict.startswith('ignored')
        else:
            assert re.search(r'(?:^|\s)ok$', verdict), (match[1], verdict)
        seen.append(match[1])
    passed += result['passed']
    ignored += result['ignored']
assert sorted(seen) == sorted(inventory) and len(seen) == len(set(seen))
assert ignored == 2
assert [stage['stage'] for stage in summary['cargo_stages']] == ['bins', 'integration']
cargo = {}
for stage in summary['cargo_stages']:
    assert stage['exit_code'] == 0
    log = (root / Path(stage['log']).name).read_text()
    assert not re.search(r'^warning(?:\[.*?\])?:', log, re.M)
    rows = re.findall(pattern, log)
    assert len(rows) == len(stage['results']) > 0
    for row, result in zip(rows, stage['results']):
        assert result['status'] == 'ok'
        assert result['failed'] == result['ignored'] == result['measured'] == result['filtered_out'] == 0
        assert row == ('ok', str(result['passed']), '0', '0', '0', '0')
    cargo[stage['stage']] = sum(result['passed'] for result in stage['results'])
assert cargo == {'bins': 60, 'integration': 39}
assert passed == 3079
identity = [line for line in (root / 'integration.log').read_text().splitlines() if line.startswith('test unchanged_gnu_sources_produce_identical_native_artifacts ')]
assert len(identity) == 1 and identity[0].endswith(' ... ok')

retained = root / 'retained-inputs'
assert retained.exists()
record = read(retained / 'manifest.json')
assert record['status'] == 'retained' and record['gate_status'] == 'passed'
assert record['gate_summary_sha256'] == sha(root / 'summary.json')
for entry in record['files']:
    path = retained / entry['artifact']
    assert sha(path) == entry['sha256'] and path.stat().st_size == entry['bytes']
assert next(entry for entry in record['files'] if entry['artifact'] == 'libtest')['sha256'] == summary['test_binary']['sha256']
result = dict(status='passed', source_commit=head, validation_checkout=summary['git'],
              unchanged_source_inputs=len(source), raw_library_names_verified=len(seen), library_passed=passed,
              library_ignored=ignored, cargo_passed=cargo, total_passed=passed + sum(cargo.values()),
              native_artifact_identity='passed', retained_files_verified=len(record['files']),
              test_binary_sha256=summary['test_binary']['sha256'], summary_sha256=sha(root / 'summary.json'),
              qualification='Full source324 macOS Rust gate: all572 runtime bytes/modes match the immutable published commit and before/after captures; every library name/verdict and Cargo summary is checked. Only the two existing ignores remain. Exact native artifact identity passes. Post-run retained fixture images do not identify per-test use. Frozen, terminal, Linux and performance evidence are separate.',
              goal_complete=False)
prior = evidence / 'source323-macos-full/full/inventory.txt'
old_inventory = {line[:-6] for line in prior.read_text().splitlines() if line.endswith(': test')}
assert old_inventory <= set(inventory) and len(set(inventory) - old_inventory) == 7
result['existing_library_names_preserved'] = len(old_inventory)
result['added_library_tests'] = sorted(set(inventory) - old_inventory)
for name in ['fmt', 'check', 'clippy', 'diff']:
    stage = read(evidence / ('source324-macos-full/' + name + '.json'))
    assert stage['exit_code'] == 0
    for stream in ['stdout', 'stderr']:
        path = evidence / ('source324-macos-full/' + name + '.' + stream)
        assert sha(path) == stage[stream + '_sha256']
        assert not re.search(r'^warning(?:\[.*?\])?:', path.read_text(), re.M)
result['strict_zero_warnings'] = True
with (evidence / 'source324-macos-rust-audit.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(result, indent=2))
