import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import tarfile
import tempfile

root=Path('/Users/nbmhqa186/projects/emaxx')
worktree=root/'target/runtime-goal/recovered-2026-10-08/symbol-plists/emaxx'
evidence=root/'target/runtime-goal/symbol-progress-2026-10-08'
base='b724bab0d945a68f1049233b6212930525a25ded'
def read(path):return json.loads(path.read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
source=read(evidence/'symbol-draft4/source.json')
for name,row in source.items():
    assert sha(worktree/name)==row['sha256'], name
    assert oct((worktree/name).stat().st_mode&0o777)==row['mode'],name
for stage in ['symbol-draft4-release','symbol-draft4-ordinary']:
    assert read(evidence/stage/'source.json')==source
for name in ['fmt','check','clippy','diff']:
    p=evidence/'symbol-draft4'
    assert read(p/(name+'.json'))['exit_code']==0
    assert not re.search(r'^warning(?:\[.*?\])?:', (p/(name+'.stderr')).read_text(),re.M)
profiles={}
for stage,profile in [('symbol-draft4','gate'),('symbol-draft4-release','release')]:
    p=evidence/stage
    binary=read(p/'binary.json')
    assert sha(Path(binary['retained']))==binary['sha256']
    selection=read(p/'selection.json')
    output=(p/'focused.stdout').read_text()
    passed=re.findall(r'^test (.+) \.\.\. ok$',output,re.M)
    assert sorted(passed)==selection
    assert f'test result: ok. {len(selection)} passed; 0 failed; 0 ignored;' in output
    inventory={line[:-6] for line in (p/'inventory.stdout').read_text().splitlines() if line.endswith(': test')}
    old=root/'target/runtime-goal/resume-2026-09-28'/('source313-'+profile+'-inventory.log')
    previous={line[:-6] for line in old.read_text().splitlines() if line.endswith(': test')}
    assert previous and previous<=inventory
    assert len(inventory-previous)==6
    build=[json.loads(line) for line in (p/'build.stdout').read_text().splitlines() if line.startswith('{')]
    assert not any(message.get('message',{}).get('level') in ('warning','error') for message in build)
    profiles[profile]=dict(passed=len(passed),failed=0,ignored=0,inventory=len(inventory),previous_inventory=len(previous),added_tests=sorted(inventory-previous),binary=binary)
ordinary=evidence/'symbol-draft4-ordinary'
rows=read(ordinary/'results.json')
assert len(rows)==12
expected={(f,m,e) for f in ['symbol-field-lifetime','symbol-field-weak-finalizer','symbol-load-history-lifetime','symbol-plist-put-sharing'] for m in (['interpreted','bytecode','native'] if f=='symbol-plist-put-sharing' else ['interpreted']) for e in ['gnu','emaxx']}
assert {(row['fixture'],row['mode'],row['editor']) for row in rows}==expected
for row in rows:
    label='-'.join([row['fixture'],row['mode'],row['editor']])
    receipt=read(ordinary/(label+'.json'))
    output=(ordinary/(label+'.stdout')).read_text()
    assert receipt['exit_code']==0 and not receipt['timed_out']
    assert output==row['stdout'] and output.strip()==row['expected'] and row['passed']
    assert sha(ordinary/(label+'.stdout'))==receipt['stdout_sha256']
    assert sha(ordinary/(label+'.stderr'))==receipt['stderr_sha256']
for fixture,mode,_ in expected:
    pair=[row for row in rows if row['fixture']==fixture and row['mode']==mode]
    assert pair[0]['stdout']==pair[1]['stdout']
artifacts=read(ordinary/'artifacts-before.json')
assert artifacts==read(ordinary/'artifacts-after.json')
for name,row in artifacts.items():assert sha(Path(name))==row['sha256']
auxiliary=read(evidence/'auxiliary-inputs.json')
for name,digest in auxiliary.items():assert sha(worktree/name)==digest,name

# Reproduce every frozen runtime input from the unchanged main base and patch.
replay=Path(tempfile.mkdtemp(prefix='emaxx-symbol-replay-'))
existing=sorted(set(source)-set(read(evidence/'patch-check.json')['new_files']))
archive=subprocess.check_output(['git','archive',base,'--',*existing],cwd=root)
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
    for member in tar.getmembers():
        if not member.isfile():continue
        assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
        destination=replay/member.name
        destination.parent.mkdir(parents=True,exist_ok=True)
        destination.write_bytes(tar.extractfile(member).read())
        destination.chmod(member.mode)
patch=evidence/'symbol-draft4.patch'
subprocess.run(['git','apply','--whitespace=error-all',str(patch)],cwd=replay,check=True)
for name,row in source.items():
    assert sha(replay/name)==row['sha256'],name
    assert oct((replay/name).stat().st_mode&0o777)==row['mode'],name
result=dict(base=base,source_inputs=len(source),auxiliary_inputs=len(auxiliary),profiles=profiles,
            ordinary_processes=len(rows),ordinary_comparisons=len(rows)//2,
            patch_sha256=sha(patch),replay_directory=str(replay),replay_verified=True,
            full_macos_gate='running separately; this audit does not certify its outcome',
            linux='not yet launched',performance='not measured',goal_complete=False,
            preserved_failures={'draft2_focused':{'passed':17,'failed':1},
                'draft3_full_first_group':{'passed':384,'failed':2,'unstarted_library_tests':2678},
                'initial_ordinary_baselines':'retention mismatches and malformed-plist process failure remain raw negative controls'})
(evidence/'selected-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['source_inputs','auxiliary_inputs','ordinary_processes','ordinary_comparisons','replay_verified','goal_complete']}))
