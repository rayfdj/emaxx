import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path('/Users/nbmhqa186/projects/emaxx')
worktree = root / 'target/runtime-goal/recovered-2026-10-08/symbol-plists/emaxx'
evidence = root / 'target/runtime-goal/symbol-progress-2026-10-08'
gnu = root / 'target/runtime-goal/rebuilt-2026-10-01/emacs'
baseline = root / 'target/runtime-goal/recovered-2026-10-07/gc-call-timer-full/emaxx/target/compat-subject/tty-retained/emaxx'
fixture = worktree / 'tests/fixtures' / sys.argv[1]
executables = [('gnu', gnu / 'src/emacs'), ('baseline', baseline)]
if len(sys.argv) > 2:
    executables = [('candidate', Path(sys.argv[2]))]
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
overrides = json.loads((evidence / 'gnu-symbol-weak-finalizer.json').read_text())['environment_overrides']
env = {**os.environ, **overrides}
for label, executable in executables:
    prefix = evidence / (label + '-' + fixture.stem + os.environ.get('PROBE_SUFFIX', ''))
    if prefix.with_suffix('.json').exists():
        raise RuntimeError('preserve existing receipt: ' + str(prefix))
    command = [str(executable), '-Q', '--batch', '--eval', '(prin1 ' + fixture.read_text() + ')']
    started = time.monotonic()
    with prefix.with_suffix('.stdout').open('wb') as out, prefix.with_suffix('.stderr').open('wb') as err:
        result = subprocess.run(command, cwd=worktree, env=env, stdout=out, stderr=err, timeout=120)
    receipt = dict(command=command, cwd=str(worktree), environment_overrides=overrides,
                   elapsed_seconds=time.monotonic()-started, exit_code=result.returncode,
                   executable_sha256=sha(executable), fixture_sha256=sha(fixture),
                   stdout_sha256=sha(prefix.with_suffix('.stdout')),
                   stderr_sha256=sha(prefix.with_suffix('.stderr')))
    prefix.with_suffix('.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(label, result.returncode, prefix.with_suffix('.stdout').read_text())
