import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

root=Path('/Users/nbmhqa186/projects/emaxx')
worktree=root/'target/runtime-goal/recovered-2026-10-08/symbol-plists/emaxx'
evidence=root/'target/runtime-goal/symbol-progress-2026-10-08'
destination=worktree/'docs/handover/2026-10-09-symbol-fields'
destination.mkdir(parents=True,exist_ok=True)
members={}
for path in sorted(evidence.rglob('*')):
    if not path.is_file():continue
    name=str(path.relative_to(evidence))
    if name.startswith('symbol-draft4/full'):
        continue  # This worker is live; no partial output is certified here.
    if path.suffix not in {'.json','.log','.stdout','.stderr','.py','.el','.patch'}:
        continue
    members['evidence/'+name]=path.read_bytes()
for path in sorted((worktree/'tests/fixtures').glob('symbol-*')):
    members['fixtures/'+path.name]=path.read_bytes()
inventory={name:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) for name,data in members.items()}
members['contents.json']=(json.dumps(inventory,indent=2)+'\n').encode()
buffer=io.BytesIO()
with gzip.GzipFile(fileobj=buffer,mode='wb',mtime=0) as gz:
    with tarfile.open(fileobj=gz,mode='w') as archive:
        for name,data in sorted(members.items()):
            info=tarfile.TarInfo(name)
            info.size=len(data)
            info.mode=0o644
            info.mtime=0
            archive.addfile(info,io.BytesIO(data))
payload=buffer.getvalue()
archive_path=destination/'source314-selected-results.tar.gz'
assert not archive_path.exists()
archive_path.write_bytes(payload)
with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as archive:
    assert set(archive.getnames())==set(members)
    for name,data in members.items():assert archive.extractfile(name).read()==data
audit=json.loads((evidence/'selected-audit.json').read_text())
manifest=dict(checkpoint='source314',scope='Selected gate/release and ordinary validation; complete platform gates and performance are separate',
              archive=archive_path.name,archive_sha256=hashlib.sha256(payload).hexdigest(),archive_bytes=len(payload),members=len(members),
              audit=audit,goal_complete=False)
(destination/'source314-selected-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:manifest[k] for k in ('archive','archive_sha256','archive_bytes','members')}))
