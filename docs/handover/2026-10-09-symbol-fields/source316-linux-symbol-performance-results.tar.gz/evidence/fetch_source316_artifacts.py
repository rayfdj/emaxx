from pathlib import Path
import datetime,hashlib,json,urllib.error,urllib.request,zipfile,io
p=Path(__file__).resolve().parent
ns={}
exec((p.parent/'symbol-progress-2026-10-08/github_ci.py').read_text().split('operation=sys.argv[1]')[0],ns)
request=ns['request']; commit=json.loads((p/'source316-linux-dispatch.json').read_text())['commit']
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,req,fp,code,msg,headers,newurl):return None
for run_id,label in [(37880303064,'source316-linux-pair'),(37880301401,'source316-linux-frozen'),(37880299667,'source316-linux-rust')]:
 _,run=request('actions/runs/'+str(run_id))
 assert run['head_sha']==commit
 print(run_id,run['display_title'],run['status'],run['conclusion'],flush=True)
 if run['status']!='completed': continue
 destination=p/label
 if destination.exists():
  print('Already retained',label,flush=True);continue
 _,data=request('actions/runs/'+str(run_id)+'/artifacts')
 assert len(data['artifacts'])==1
 artifact=data['artifacts'][0]
 assert artifact['name']=='ordinary-linux-'+commit and not artifact['expired']
 digest=artifact['digest'].removeprefix('sha256:')
 req=urllib.request.Request(artifact['archive_download_url'],headers={'Authorization':'Basic '+ns['authorization'],'Accept':'application/vnd.github+json','User-Agent':'emaxx-runtime-validation'})
 try:
  with urllib.request.build_opener(NoRedirect).open(req,timeout=30) as response: raw=response.read()
 except urllib.error.HTTPError as error:
  assert error.code in (301,302,303,307,308)
  location=error.headers['Location'];assert location.startswith('https://')
  with urllib.request.urlopen(location,timeout=60) as response:raw=response.read()
 assert hashlib.sha256(raw).hexdigest()==digest
 destination.mkdir(exist_ok=False);(destination/'artifact.zip').write_bytes(raw)
 with zipfile.ZipFile(io.BytesIO(raw)) as archive:
  for member in archive.infolist():
   path=Path(member.filename);assert not path.is_absolute() and '..' not in path.parts
  archive.extractall(destination/'raw')
 receipt=dict(run_id=run_id,run_url=run['html_url'],run_conclusion=run['conclusion'],run_title=run['display_title'],artifact_id=artifact['id'],source_commit=commit,sha256=digest,bytes=len(raw),retained=datetime.datetime.now(datetime.timezone.utc).isoformat())
 (destination/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n'); print('RETAINED',label,json.dumps(receipt),flush=True)
