from pathlib import Path
import gzip,hashlib,io,json,tarfile
p=Path(__file__).resolve().parent;w=p.parent/'recovered-2026-10-09/symbol-ownership/emaxx'
destination=w/'docs/handover/2026-10-09-symbol-fields';read=lambda f:json.loads(f.read_text());sha=lambda data:hashlib.sha256(data).hexdigest()
audit=read(p/'source316-linux-pair-performance-audit.json');raw=p/'source316-linux-pair/raw/core-runtime-pair'
members={};excluded=[]
for name,digest in audit['evidence'].items():
 data=(raw/name).read_bytes();assert sha(data)==digest
 if name in ['oracle-inputs/emacs','oracle-inputs/emacs.pdmp','artifacts/baseline/emaxx','artifacts/baseline/emaxx.pdmp','artifacts/candidate/emaxx','artifacts/candidate/emaxx.pdmp']:
  excluded.append(dict(path=str(raw/name),bytes=len(data),sha256=digest))
 else:members['evidence/raw/'+name]=data
for name in ['source316-linux-pair-performance-audit.json','source316-linux-pair/receipt.json','source316-linux-status.json','source316-linux-dispatch.json','audit-source316-linux-pair.py','fetch_source316_artifacts.py','package_linux_perf.py']:
 members['evidence/'+name]=(p/name).read_bytes()
members['contents.json']=(json.dumps({name:dict(bytes=len(data),sha256=sha(data)) for name,data in members.items()},indent=2)+'\n').encode()
buffer=io.BytesIO()
with gzip.GzipFile(fileobj=buffer,mode='wb',mtime=0) as zipped:
 with tarfile.open(fileobj=zipped,mode='w') as archive:
  for name,data in sorted(members.items()):
   info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
data=buffer.getvalue();path=destination/'source316-linux-symbol-performance-results.tar.gz';assert not path.exists();path.write_bytes(data)
with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as archive:
 assert set(archive.getnames())==set(members)
 assert all(archive.extractfile(name).read()==data for name,data in members.items())
manifest=dict(checkpoint='source316',archive=dict(path=path.name,bytes=len(data),sha256=sha(data),members=len(members)),run_id=audit['run_id'],revisions=audit['source_revisions'],results_verified=192,raw_body_geometric_ratio=audit['raw_body_geometric_ratio'],paired_gnu_geometric_ratios=audit['paired_gnu_geometric_ratios'],per_case=[dict(case=row['case'],candidate_over_baseline=row['candidate_over_baseline'],gnu_ratios=row['gnu_ratios']) for row in audit['results']],excluded_retained_inputs=excluded,qualification=audit['qualification'],goal_complete=False)
(destination/'source316-linux-symbol-performance-results-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest['archive']))
