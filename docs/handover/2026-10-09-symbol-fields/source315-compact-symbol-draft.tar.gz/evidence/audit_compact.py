from pathlib import Path
import hashlib
import io
import json
import re
import subprocess
import sys
import tarfile
import tempfile

p = Path(__file__).resolve().parent
root = p.parents[2]
worktree = p.parent / 'recovered-2026-10-09/symbol-values/emaxx'
previous = p.parent / 'symbol-progress-2026-10-08'
base = '2712c05779e47ec9b8a7c89121d1a79fdcc42596'
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
source = read(p / 'compact-draft1/source.json')
assert source == read(p / 'compact-draft1/source-after.json')
for name, item in source.items():
    assert sha(worktree / name) == item['sha256'], name
    assert oct((worktree / name).stat().st_mode & 0o777) == item['mode'], name
for name in ['fmt', 'check', 'clippy', 'diff']:
    assert read(p / ('compact-draft1/' + name + '.json'))['exit_code'] == 0
    assert not re.search(r'^warning(?:\[.*?\])?:', (p / ('compact-draft1/' + name + '.stderr')).read_text(), re.M)
profiles = {}
for profile, label in [('gate', 'compact-draft1'), ('release', 'compact-draft1-release')]:
    d = p / label
    assert read(d / 'source-after.json') == read(d / 'source.json') == source
    assert read(d / 'focused.json')['exit_code'] == 0
    selected = read(d / 'selection.json')
    assert set(read(previous / 'symbol-draft4/selection.json')) <= set(selected)
    output = (d / 'focused.stdout').read_text()
    starts = list(re.finditer(r'^test (\S+) \.\.\. ', output, re.M))
    seen = []
    for index, match in enumerate(starts):
        end = starts[index + 1].start() if index + 1 < len(starts) else output.rindex('test result:')
        assert re.search(r'(?:^|\s)ok$', output[match.end():end].strip()), match[1]
        seen.append(match[1])
    assert sorted(seen) == selected and len(seen) == len(set(seen))
    assert f'test result: ok. {len(selected)} passed; 0 failed; 0 ignored;' in output
    inventory = {line[:-6] for line in (d / 'inventory.stdout').read_text().splitlines() if line.endswith(': test')}
    old_label = 'symbol-draft4' if profile == 'gate' else 'symbol-draft4-release'
    old_inventory = {line[:-6] for line in (previous / old_label / 'inventory.stdout').read_text().splitlines() if line.endswith(': test')}
    assert old_inventory <= inventory
    added = inventory - old_inventory
    assert added == {
        'lisp::eval::symbol_cells::tests::compact_fields_preserve_nil_values_void_defaults_and_image_replacement',
        'lisp::eval::symbol_cells::tests::alias_enumeration_follows_one_target_through_retargeting_and_compaction',
    }
    binary = read(d / 'binary.json')
    assert sha(Path(binary['retained'])) == binary['sha256']
    messages = [json.loads(line) for line in (d / 'build.stdout').read_text().splitlines() if line.startswith('{')]
    assert not any(message.get('message', {}).get('level') in ['warning', 'error'] for message in messages)
    profiles[profile] = dict(passed=len(seen), inventory=len(inventory), binary=binary, added=sorted(added))

rows = []
ordinary_audited = '--profiles-only' not in sys.argv
if ordinary_audited:
    ordinary = p / 'compact-draft1-ordinary'
    assert read(ordinary / 'source.json') == source
    rows = read(ordinary / 'results.json')
    assert len(rows) == 12
    expected = {(fixture, mode, editor) for fixture in ['symbol-field-lifetime', 'symbol-field-weak-finalizer', 'symbol-load-history-lifetime', 'symbol-plist-put-sharing'] for mode in (['interpreted', 'bytecode', 'native'] if fixture == 'symbol-plist-put-sharing' else ['interpreted']) for editor in ['gnu', 'emaxx']}
    assert {(r['fixture'], r['mode'], r['editor']) for r in rows} == expected
    for row in rows:
        label = '-'.join([row['fixture'], row['mode'], row['editor']])
        receipt = read(ordinary / (label + '.json'))
        assert receipt['exit_code'] == 0 and not receipt['timed_out']
        output = (ordinary / (label + '.stdout')).read_text()
        assert output == row['stdout'] and output.strip() == row['expected'] and row['passed']
        for stream in ['stdout', 'stderr']:
            assert sha(ordinary / (label + '.' + stream)) == receipt[stream + '_sha256']
    for fixture, mode, _ in expected:
        pair = [r for r in rows if r['fixture'] == fixture and r['mode'] == mode]
        assert pair[0]['stdout'] == pair[1]['stdout']
    artifacts = read(ordinary / 'artifacts-before.json')
    assert artifacts == read(ordinary / 'artifacts-after.json')
    assert all(sha(Path(name)) == item['sha256'] for name, item in artifacts.items())
auxiliary = read(previous / 'auxiliary-inputs.json')
assert all(sha(worktree / name) == digest for name, digest in auxiliary.items())

# Every old internal storage assertion remains byte-for-byte intact.
name = 'src/lisp/eval/symbol_cells.rs'
old = subprocess.check_output(['git', 'show', base + ':' + name], cwd=root).decode()
current = (worktree / name).read_text()
old_tests = old.split('#[cfg(test)]\nmod tests {', 1)[1]
new_tests = current.split('#[cfg(test)]\nmod tests {', 1)[1]
start = new_tests.index('    #[test]\n    fn compact_fields_')
end = new_tests.index('    #[test]\n    fn function_enumeration_')
assert new_tests[:start] + new_tests[end:] == old_tests

patch = subprocess.check_output(['git', 'diff', '--binary', base], cwd=worktree)
(p / 'compact-draft1.patch').write_bytes(patch)
replay = Path(tempfile.mkdtemp(prefix='emaxx-compact-symbol-replay-'))
data = subprocess.check_output(['git', 'archive', base, '--', *source], cwd=root)
with tarfile.open(fileobj=io.BytesIO(data)) as archive:
    for member in archive.getmembers():
        if not member.isfile():
            continue
        assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
        destination = replay / member.name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(archive.extractfile(member).read())
        destination.chmod(0o755 if member.mode & 0o111 else 0o644)
subprocess.run(['git', 'apply', '--whitespace=error-all', str(p / 'compact-draft1.patch')], cwd=replay, check=True)
for name, item in source.items():
    assert sha(replay / name) == item['sha256'], name
    assert oct((replay / name).stat().st_mode & 0o777) == item['mode'], name
result = dict(base=base, profiles=profiles, source_inputs=len(source), auxiliary_inputs=len(auxiliary),
              ordinary_audited=ordinary_audited, ordinary_processes=len(rows), ordinary_comparisons=len(rows) // 2,
              original_cell_tests_unchanged=True, replay_verified=True, replay_directory=str(replay),
              patch_sha256=hashlib.sha256(patch).hexdigest(), goal_complete=False,
              qualification=('Selected gate/release controls'+(' and ordinary executions' if ordinary_audited else '; ordinary execution is not audited here')+'. Full gate is separate; no complete platform validation, measured speedup, physical symbol footprint accounting or allocated-symbol authority is established.'))
(p / ('selected-audit.json' if ordinary_audited else 'profiles-audit.json')).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({name: result[name] for name in ['source_inputs', 'auxiliary_inputs', 'ordinary_processes', 'original_cell_tests_unchanged', 'replay_verified']}, indent=2))
