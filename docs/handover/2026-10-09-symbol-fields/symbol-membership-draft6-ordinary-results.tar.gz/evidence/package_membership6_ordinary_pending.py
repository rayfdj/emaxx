from pathlib import Path
import hashlib
import json
import re

p = Path(__file__).resolve().parent
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
audit = read(p / 'symbol-membership-draft6-ordinary-audit.json')
assert audit['comparisons'] == 38 and audit['processes'] == 76
negative = p / 'symbol-membership-draft6-store-negatives'
original = p / 'source324-membership-store-negatives'
assert (negative / 'program.el').read_bytes() == (original / 'program.el').read_bytes()
receipt = read(negative / 'manifest.json')
assert receipt['inputs_unchanged'] and len(receipt['results']) == 2
counts = {}
for row in receipt['results']:
    assert row['exit_code'] == 0 and row['timeout_seconds'] == 180
    for stream in ['stdout', 'stderr']:
        assert sha(negative / (row['editor'] + '.' + stream)) == row[stream + '_sha256']
    assert not (negative / (row['editor'] + '.stderr')).read_bytes()
    raw = (negative / (row['editor'] + '.stdout')).read_text().strip()
    assert re.fullmatch(r'\(\((?:t|nil)(?: (?:t|nil)){7}\)(?: \((?:t|nil)(?: (?:t|nil)){7}\)){4}\)', raw)
    values = re.findall(r'\b(?:nil|t)\b', raw)
    assert len(values) == 40
    counts[row['editor']] = dict(true=values.count('t'), false=values.count('nil'))
assert counts == {'gnu': dict(true=40, false=0), 'membership-draft6': dict(true=20, false=20)}
for path, digest in receipt['inputs'].items():
    assert sha(Path(path)) == digest
negative_audit = dict(status='known mismatch remains', outcomes=counts,
    unchanged_program_sha256=sha(negative / 'program.el'),
    qualification='The same valid program used for the earlier source324 negative runs through ordinary load in both editors. Both exit0 without stderr. Draft6 still has20 false predicates against GNU40true: actual constant/special state, preserved keyword self-value and fresh same-name stores remain unrepaired. These outcomes are separate from the38 passing ordinary comparisons.',
    goal_complete=False)
(p / 'symbol-membership-draft6-store-negative-audit.json').open('x').write(json.dumps(negative_audit, indent=2) + '\n')
ns = {'__file__': str(p / 'package_source323_base.py')}
exec((p / 'package_source323_base.py').read_text(), ns)
ns['destination'] = p / 'pending-publication-source324'
ns['package']('symbol-membership-draft6-ordinary-results',
    [('evidence/ordinary', p / 'symbol-membership-draft6-ordinary'),
     ('evidence/remaining-store-negative', negative)],
    [('evidence/' + name, p / name) for name in [
        'ordinary_membership6.py', 'audit_membership6_ordinary.py',
        'observe_membership6_stores.py', 'symbol-membership-draft6-ordinary-audit.json',
        'symbol-membership-draft6-store-negative-audit.json',
        'package_source323_base.py', Path(__file__).name]],
    dict(checkpoint='unapplied membership draft6 ordinary modes and remaining constant/store negative',
         ordinary=audit, remaining_negative=negative_audit,
         qualification='38 actual ordinary GNU comparisons pass, preserving all28 earlier ones and adding10 membership comparisons; actual bytecode/native predicates are checked. The separate valid constant/store program still differs in20 of40predicates. The draft remains unfinished and lacks full library/platform/frozen certification. Retained executable/image bytes are excluded explicitly; no performance result or full-goal completion.'))
