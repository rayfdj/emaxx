from pathlib import Path
import json

p = Path(__file__).resolve().parent
ns = {'__file__': str(p / 'package_source323_base.py')}
exec((p / 'package_source323_base.py').read_text(), ns)
destination = p / 'pending-publication-2026-10-13'
destination.mkdir(exist_ok=True)
ns['destination'] = destination
audit = json.loads((p / 'source323-terminal-audit.json').read_text())
assert audit['status'] == 'passed' and audit['matching_comparisons'] == 686
assert audit['started_scenarios'] == 226 and not audit['unexecuted_labels'] and not audit['divergent_labels']
assert not audit['full_screen_differences']
files = ['source323-terminal-audit.json', 'audit_source323_terminal.py', 'source323_terminal.py',
         'observe_terminal.py', 'package_source323_base.py', Path(__file__).name]
ns['package']('source323-macos-terminal-results', [('evidence/source323-terminal', p / 'source323-terminal')],
              [('evidence/' + name, p / name) for name in files],
              dict(checkpoint='source323 complete ordinary macOS terminal validation', audit=audit,
                   qualification='One complete passing ordinary run: all226 original scenarios,686 comparison labels,658 full screen snapshots and28 filesystem comparisons. Every captured row, cell attribute and cursor coordinate also matches, independently of the unchanged harness verdict. Original inventory/actions/deadlines are retained. The copied Emaxx executable/image identities match the original failed frozen subject, whose actual bytes are retained separately. This validates source323 only, not the unapplied symbol-field integration or performance completion.'))
