from pathlib import Path
import json

p = Path(__file__).resolve().parent
ns = {'__file__': str(p / 'package_source323_base.py')}
exec((p / 'package_source323_base.py').read_text(), ns)
destination = p / 'pending-publication-source324'
destination.mkdir(exist_ok=True)
ns['destination'] = destination
audit = json.loads((p / 'source324-alloc-profile-audit.json').read_text())
root = p / 'source324-linux-alloc-profile/raw'
for name, row in audit['raw_files'].items():
    path = root / name
    assert path.stat().st_size == row['bytes'] and ns['sha'](path.read_bytes()) == row['sha256']
ns['package']('source324-linux-allocation-profile-results', [('evidence/raw', root)],
    [('evidence/' + name, p / name) for name in [
        'source324-alloc-profile-audit.json', 'source324-alloc-profile-dispatch.json',
        'audit_source324_alloc_profile.py', 'fetch_source324_profile.py',
        'source324-linux-alloc-profile/receipt.json', 'source324_ci.py',
        'package_source323_base.py', Path(__file__).name]],
    dict(checkpoint='source324 separate diagnostic allocation-file CPU samples',
        run_id=audit['run_id'], actual_matching_outcomes=5, successful_processes=2,
        exact_subject_sha256=audit['exact_subject_sha256'], metadata=audit['metadata'],
        qualification=audit['qualification']))
