from pathlib import Path
import hashlib
import json
import re

p = Path(__file__).resolve().parent
root = p / 'source324-linux-alloc-profile/raw'
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
receipt = read(root.parent / 'receipt.json')
head = '999362622a68d6508c356541422f7a48ae6e2175'
assert receipt['source_commit'] == head and receipt['run_id'] == 38340241707
assert receipt['run_conclusion'] == 'success'
assert sha(root.parent / 'artifact.zip') == receipt['sha256']
metadata = read(root / 'ordinary-perf-metadata.json')
assert metadata['kind'] == 'diagnostic_only'
assert metadata['frequency_hz'] == 199 and metadata['call_graph'] == 'dwarf,8192'
for name, digest in metadata['sha256'].items():
    assert sha(root / name) == digest
summaries = list(root.rglob('summary.json'))
assert len(summaries) == 1
run = summaries[0].parent
summary = read(summaries[0])
assert summary['mode'] == 'run' and summary['name_filter'] is None
assert summary['files'] == ['test/src/alloc-tests.el']
assert summary['matching_outcomes'] == summary['total_outcomes'] == 5
assert summary['mismatching_outcomes'] == 0 and not summary['unsuccessful_files']
assert summary['provenance']['subject_git_head'] == head
assert not summary['provenance']['subject_git_dirty']
assert summary['provenance']['subject_sha256'] == sha(root / 'ordinary-perf-emaxx')
assert summary['provenance']['subject_profile'] == 'gate'
assert summary['provenance']['oracle_sha256'] == '5e1721732427d69d8af63211f1e3833ec21e40f97f4b7f6cd4cb224b72cebfcf'
directory = run / 'test/src/alloc-tests.compat'
execution = read(directory / 'execution.json')
assert execution['contract_sha256'] == sha(run / 'contract.json')
for name, digest in execution['sha256'].items():
    assert sha(directory / name) == digest
reports = []
for editor in ['oracle', 'emaxx']:
    report = read(directory / (editor + '.json'))
    assert report['file_status'] == 'loaded' and report['file_error'] is None
    assert report['selector'] == summary['selector']
    assert len(report['selected_tests']) == len(report['results']) == 5
    assert set(report['selected_tests']) == {row['name'] for row in report['results']}
    assert all(row['status'] == 'passed' and row['expected'] for row in report['results'])
    process = read(directory / (editor + '.execution.json'))['process']
    assert process['exit_code'] == 0 and process['test_started'] and not process['timed_out']
    reports.append({row['name']: (row['status'], row['expected']) for row in report['results']})
assert reports[0] == reports[1]
self_report = (root / 'ordinary-perf-self.txt').read_text()
assert '# Total Lost Samples: 0' in self_report
rows = [line.strip() for line in self_report.splitlines() if re.match(r'^\s+\d+\.\d+%\s+', line)]
assert rows and 'CharTableChainSignature7matches' in rows[0]
result = dict(status='verified diagnostic', run_id=receipt['run_id'], source_commit=head,
    exact_subject_sha256=sha(root / 'ordinary-perf-emaxx'), metadata=metadata,
    actual_matching_outcomes=5, successful_processes=2,
    instrumented_timings=summary['timings'], self_rows=rows,
    qualification='The retained profile and exact subject hashes match CI metadata and the ordinary same-input comparison. All five actual outcomes and both zero process exits are verified. This gate-profile process-tree sample includes startup/loading and is not the locked explicit-GC workload, a release measurement, or an uninstrumented timing run. Only a fraction of the recorded samples are selected Emaxx process rows. The largest reported Emaxx self row is regex case-table snapshot validation; these samples do not attribute the separate release explicit-GC regression. The Emaxx image and GNU executable/image are identified by provenance, not retained in this profile artifact. No performance acceptance is established.',
    raw_files={str(path.relative_to(root)): dict(bytes=path.stat().st_size, sha256=sha(path)) for path in root.rglob('*') if path.is_file()},
    goal_complete=False)
(p / 'source324-alloc-profile-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ['status', 'run_id', 'actual_matching_outcomes', 'successful_processes', 'qualification']}, indent=2))
