from pathlib import Path
import json

p = Path(__file__).resolve().parent
fp = p.parent / 'allocated-symbols-2026-10-10'
ns = {'__file__': str(p / 'package_source323_base.py')}
exec((p / 'package_source323_base.py').read_text(), ns)
package = ns['package']
read = lambda path: json.loads(path.read_text())
trees = lambda root, names: [('evidence/' + name, root / name) for name in names]
files = trees

package('source322-linux-rust-and-frozen-failure-results',
    trees(p, ['source322-linux-rust/raw', 'source322-linux-frozen/raw']),
    files(p, ['source322-linux-rust/receipt.json', 'source322-linux-frozen/receipt.json',
              'source322-linux-rust-audit.json', 'audit_source322_linux_rust.py',
              'source322-linux-frozen-failed-audit.json', 'audit_source322_linux_frozen_failure.py',
              'source322-linux-status.json', 'source322-linux-dispatch.json',
              'source322_ci.py', 'fetch_source322_artifacts.py',
              'source322-eglot-observation-dispatch.json', 'observe_source322_eglot.py',
              'package_source323.py', 'package_source323_base.py']),
    dict(checkpoint='source322 complete Linux Rust and failed complete frozen run',
         rust=read(p / 'source322-linux-rust-audit.json'),
         frozen={k:v for k,v in read(p / 'source322-linux-frozen-failed-audit.json').items() if k != 'raw_files'},
         qualification='Linux Rust has 3183 passes/two existing ignores. All 519 frozen files and 7928 outcomes ran; 7927 match. GNU alone fails the Eglot Rust-completion test at its internal JSON-RPC timeout; Emaxx passes. The full frozen run remains failed. A separate unchanged-file observation was dispatched and has no verdict in this archive. Retained GNU inputs and original failures remain intact; no slowdown or verdict substitution is introduced.'))

package('source322-macos-failure-and-native-root-repair-results',
    trees(p, ['source322-macos-full', 'source322-macos-frozen',
              'source322-native-identity-failure', 'source323-native-gate']),
    files(p, ['source322-macos-failed-audit.json', 'audit_source322_macos_failure.py',
              'source323-native-audit.json', 'verify_source323_native.py',
              'validate_native_root.py', 'validate_startup_root.py',
              'source322_macos_frozen.py', 'package_source323.py', 'package_source323_base.py']),
    dict(checkpoint='source322 failed full macOS gate; source323 test-only native oracle correction',
         failed=read(p / 'source322-macos-failed-audit.json'),
         repair=read(p / 'source323-native-audit.json'),
         qualification='The original full run retains 3161 passes, one native identity failure and two existing ignores; three integration targets and every frozen comparison were unstarted. That native fixture chose an adjacent GNU build with a different native ABI. Source323 changes only its oracle-root selection/comment to the configured GNU tree. Strict checks and all seven integration targets pass (39 tests), preserving exact byte comparisons for all nine original native source fixtures. Production is unchanged. Complete source323 macOS/frozen/terminal and Linux results remain pending.'))

package('allocated-symbol-draft16-results',
    trees(fp, ['fields-draft16-gate', 'fields-draft16-release', 'fields-draft16-ordinary',
               'fields-draft16-ordinary-retained-inputs', 'fields-draft16-fixture-gnu',
               'fields-draft16-full', 'fields-draft16-unstarted-groups',
               'fields-draft16-owner-fixture-observations']),
    files(fp, ['fields-draft16.patch', 'fields-draft16-replay.json', 'replay_obarray16.py',
               'fields-draft16-selected-audit.json', 'audit_fields16_selected.py',
               'audit_fields16_selected_attempt1.py', 'audit_fields16_selected_attempt2.py',
               'fields-draft16-ordinary-audit.json', 'audit_fields16_ordinary.py',
               'fields-draft16-full-failed-audit.json', 'audit_fields16_full_failure.py',
               'continue_fields16_groups.py', 'observe_owner_fixture_contracts.py',
               'validate_fields_obarray.py', 'validate_field_final.py',
               'ordinary_fields_obarray15.py'])
    + files(p, ['package_source323.py', 'package_source323_base.py']),
    dict(checkpoint='unapplied allocated-symbol draft16; selected and ordinary pass, full fails',
         selected=read(fp / 'fields-draft16-selected-audit.json'),
         ordinary=read(fp / 'fields-draft16-ordinary-audit.json'),
         full=read(fp / 'fields-draft16-full-failed-audit.json'),
         qualification='The complete cumulative patch replays all 568 inputs from 265d5ba3. GNU-backed fixture corrections preserve same-editor symbol identity and all native names/arities without assuming obarray traversal order. Strict checks and 379 controls pass per profile; 21 ordinary GNU comparisons match in real execution modes. The original full attempt fails after 689 passes/two failures; separate continuation executes the eight unstarted library groups. Combined observed coverage is 3061 passes/15 failures/two existing ignores across all 3078 names; no passing full gate or Cargo result is claimed. Every failure remains unresolved in this patch.'))

package('allocated-symbol-identity-unfinished-results',
    trees(fp, ['fields-identity-negative', 'fields-identity-draft1-gate',
               'fields-identity-draft2-gate', 'fields-identity-eshell-observation']),
    files(fp, ['fields-identity-baseline.json', 'fields-identity-application.json',
               'fields-identity-negative.patch', 'fields-identity-draft1-gate.patch',
               'fields-identity-draft2-gate.patch', 'fields-identity-replay.json',
               'fields-identity-draft2-audit.json', 'audit_identity_draft2.py',
               'prepare_symbol_identity.py', 'observe_identity_eshell.py',
               'validate_fields_obarray.py', 'validate_field_final.py',
               'fields-draft16-full-failed-audit.json'])
    + files(p, ['package_source323.py', 'package_source323_base.py']),
    dict(checkpoint='unapplied allocated symbol identity draft2',
         audit=read(fp / 'fields-identity-draft2-audit.json'),
         qualification='All three cumulative patches replay 568 inputs. The negative fails both the 64-byte layout and editor-specific keyboard-symbol tests. First repair has preserved compile errors; draft2 passes strict checks and 380 selected controls. It removes allocated symbol IDs and their two atomic counters, uses actual symbol identity for locals/aliases/watchers/dumps, and binds keyboard Qsymbols to each editor. The original Eshell assertion fails unchanged both before and after this change. Release, ordinary and full validation have not run. Draft16 broader failures remain open. A 64-byte header is not a whole-process memory or performance result: existing adapter/name structures and 14 per-editor keyboard references remain. Accounting, complete ownership and the full goal remain unfinished.'))
