from pathlib import Path
import hashlib
import json
import re
import subprocess

p = Path(__file__).resolve().parent
r = p.parents[2]
d = p / 'source323-native-gate'
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
before = read(p/'source322-startup-gate2/source.json')
after = read(d/'source.json')
assert after == read(d/'source-after.json') and len(after) == 565
assert [name for name in before if before[name] != after[name]] == ['tests/native_comp_identity.rs']
old = subprocess.check_output(['git','show','f526af1c9e070c3eda68dd9736067f8cfbf35ea0:tests/native_comp_identity.rs'],cwd=r,text=True)
new = (r/'tests/native_comp_identity.rs').read_text()
expected = old.replace(
    '/// ignored integration tests, and the sibling GNU build it needs is the\n/// oracle every other gate test needs too.',
    "/// ignored integration tests, and the configured GNU build is the oracle\n/// used by the other gate tests and Emaxx's native compilation ABI.").replace(
    '    let project = PathBuf::from(env!("CARGO_MANIFEST_DIR"));\n    let gnu_root = project.join("../emacs");',
    '    let gnu_root = emaxx::compat::configured_gnu_source_root();')
assert new == expected
for name, row in after.items():
    assert sha(r/name) == row['sha256'] and oct((r/name).stat().st_mode & 0o777) == row['mode']
for name in ['fmt','check','clippy','diff','integration']:
    receipt = read(d/(name+'.json'))
    assert receipt['exit_code'] == 0
    for stream in ['stdout','stderr']:
        path = d/(name+'.'+stream)
        assert sha(path) == receipt[stream+'_sha256']
        assert not re.search(r'^warning(?:\[.*?\])?:',path.read_text(errors='replace'),re.M)
raw = (d/'integration.stdout').read_text()
rows = re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',raw)
assert rows == [('ok',str(n),'0','0','0','0') for n in [20,6,3,1,1,5,3]]
fixtures = re.findall(r'relative_path: "([^"]+)"',new)
passed = re.findall(r'^native-comp identity PASS: ([^ ]+) \((.*?)\)$',raw,re.M)
assert [name for name,_ in passed] == fixtures and len(fixtures) == 9
assert sum('identical artifact bytes' in description for _,description in passed) == 8
assert sum(description == 'no artifact in either editor' for _,description in passed) == 1
audit = read(p/'source323-native-audit.json')
assert audit['passed'] == 39 and audit['failed'] == audit['ignored'] == 0
assert audit['native_identity_fixtures'] == [list(row) for row in passed]
for row in audit['retained_inputs']:
    path = Path(row['retained'])
    assert sha(path) == row['sha256'] and path.stat().st_size == row['bytes']
print('Verified source323: 39 integration passes and all nine unchanged native fixtures')
