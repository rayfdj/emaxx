from pathlib import Path
import hashlib
import io
import json
import re
import subprocess
import sys
import tarfile

evidence = Path(__file__).resolve().parent
repository = evidence.parents[2]
checkout = repository
root = evidence / 'source322-macos-full/full'
head = json.loads((evidence / 'source322-commit.json').read_text())['commit']
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
summary = read(root / 'summary.json')
assert summary['status'] == 'failed' and summary['scope'] == 'full'
assert summary['git'] == {'dirty': False, 'head': head}
source = read(evidence / 'source322-macos-full/source.json')
assert len(source) == 565
assert source == read(evidence / 'source322-startup-gate2/source.json')
assert not (evidence / 'source322-macos-full/source-after.json').exists()
selected = read(evidence / 'source322-startup-audit.json')
assert selected['source_inputs_verified'] == 565 and selected['production_source_unchanged']
assert selected['only_changed_input'] == 'src/startup.rs'
published = subprocess.check_output(['git', 'archive', head, '--', *source], cwd=repository)
with tarfile.open(fileobj=io.BytesIO(published)) as archive:
    for name, entry in source.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == entry['sha256']
        assert ('0o755' if archive.getmember(name).mode & 0o111 else '0o644') == entry['mode']
receipt = read(evidence / 'source322-macos-full/full.json')
assert receipt['exit_code'] == 1
for stream in ['stdout', 'stderr']:
    assert sha(evidence / ('source322-macos-full/full.' + stream)) == receipt[stream + '_sha256']

inventory = [line[:-6] for line in (root / 'inventory.txt').read_text().splitlines() if line.endswith(': test')]
assert len(inventory) == len(set(inventory)) == 3074
assert summary['inventory']['ignored_tests'] == ['tty::tty_differential_end_to_end', 'tty::tty_smoke_end_to_end']
assert summary['repetitions'] == 1 and len(summary['runs']) == 1
run = summary['runs'][0]
assert run['expected_tests'] == run['observed_outcomes'] == summary['inventory']['scheduled_tests'] == 3074
assert {group['group'] for group in run['groups']} == set(summary['inventory']['groups'])
assert len(run['groups']) == len(summary['inventory']['groups'])
pattern = r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;'
seen = []
passed = ignored = 0
for group in run['groups']:
    assert group['exit_code'] == 0 and not group['timed_out']
    result = group['result']
    assert result['status'] == 'ok' and result['failed'] == result['measured'] == 0
    assert result['passed'] + result['ignored'] == group['expected_tests'] == summary['inventory']['groups'][group['group']]
    assert result['ignored'] == group['expected_ignored']
    log = (root / Path(group['log']).name).read_text()
    assert re.findall(pattern, log) == [('ok', str(result['passed']), '0', str(result['ignored']), '0', str(result['filtered_out']))]
    starts = list(re.finditer(r'^test (\S+) \.\.\. ', log, re.M))
    assert len(starts) == group['expected_tests']
    for index, match in enumerate(starts):
        end = starts[index + 1].start() if index + 1 < len(starts) else log.rindex('test result:')
        verdict = log[match.end():end].strip()
        if match[1] in summary['inventory']['ignored_tests']:
            assert verdict.startswith('ignored')
        else:
            assert re.search(r'(?:^|\s)ok$', verdict), (match[1], verdict)
        seen.append(match[1])
    passed += result['passed']
    ignored += result['ignored']
assert sorted(seen) == sorted(inventory) and len(seen) == len(set(seen))
assert ignored == 2
assert passed == 3072 and ignored == 2
assert [stage['stage'] for stage in summary['cargo_stages']] == ['bins']
bins = summary['cargo_stages'][0]
assert bins['exit_code'] == 0
raw_bins = (root/'bins.log').read_text()
rows = re.findall(pattern, raw_bins)
assert len(rows) == len(bins['results']) == 4
assert rows == [('ok',str(row['passed']),'0','0','0','0') for row in bins['results']]
assert sum(row['passed'] for row in bins['results']) == 60
integration = (root/'integration.log').read_text()
rows = re.findall(pattern,integration)
assert rows == [('ok','20','0','0','0','0'),('ok','6','0','0','0','0'),('ok','3','0','0','0','0'),('FAILED','0','1','0','0','0')]
assert 'test unchanged_gnu_sources_produce_identical_native_artifacts ... FAILED' in integration
assert 'at byte 792; GNU size 34536, Emaxx size 34536' in integration
targets = summary['cargo_test_targets']['integrations']
assert targets == ['cli','cli_parity','ert_runner','native_comp_identity','native_thread_continuations','package_lifecycle','runtime_ownership']
assert len(re.findall(r'^     Running tests/',integration,re.M)) == 4
record = read(root/'retained-inputs/manifest.json')
assert record['status'] == 'retained' and record['gate_status'] == 'failed'
assert record['gate_summary_sha256'] == sha(root/'summary.json')
for row in record['files']:
    path = root/'retained-inputs'/row['artifact']
    assert sha(path) == row['sha256'] and path.stat().st_size == row['bytes']
failure = evidence/'source322-native-identity-failure'
files = read(failure/'files.json')
for name,row in files.items():
    assert sha(failure/name) == row['sha256'] and (failure/name).stat().st_size == row['bytes']
artifacts = sorted((failure/'raw').rglob('*.eln'))
assert len(artifacts) == 2
left,right = [path.read_bytes() for path in artifacts]
differences = [i for i,(a,b) in enumerate(zip(left,right)) if a != b]
assert len(left) == len(right) == 34536 and len(differences) == 88 and differences[0] == 792
assert b'"adba4e3f"' in left and b'"d6eeb69b"' in right
native_inputs = read(failure/'retained-inputs.json')
assert len(native_inputs) == 10
for row in native_inputs:
    path=Path(row['retained']);assert sha(path)==row['sha256'] and path.stat().st_size==row['bytes']
frozen = read(evidence/'source322-macos-frozen/state.json')
assert frozen['status']=='supervisor failed; inspect saved stages' and frozen['results']==[]
result = dict(status='failed original full attempt; raw evidence verified',source_commit=head,
    source_inputs_verified=len(source), library_passed=3072,library_ignored=2,
    bins_passed=60,integration_passed=29,integration_failed=1,total_passed=3161,
    failed_test='unchanged_gnu_sources_produce_identical_native_artifacts',
    unstarted_integration_targets=targets[4:],frozen_comparisons_started=0,
    test_binary_sha256=summary['test_binary']['sha256'],native_differing_bytes=88,
    native_artifact_abis=['adba4e3f','d6eeb69b'],retained_gate_inputs=record,
    qualification='All 3074 library names and all four binary targets completed. The integration stage stopped at native artifact identity after three earlier targets; the remaining three targets were not started. The native test used the adjacent GNU build, while Emaxx uses the configured rebuilt oracle. Different ABI hashes are embedded in the retained artifacts. No byte is ignored or normalized; this full attempt remains failed. The queued frozen comparison did not start. A test-path correction needs its own validation.',goal_complete=False)
with (evidence/'source322-macos-failed-audit.json').open('x') as stream:
    json.dump(result,stream,indent=2);stream.write('\n')
print(json.dumps({key:result[key] for key in ['status','total_passed','integration_failed','unstarted_integration_targets','native_artifact_abis']},indent=2))
