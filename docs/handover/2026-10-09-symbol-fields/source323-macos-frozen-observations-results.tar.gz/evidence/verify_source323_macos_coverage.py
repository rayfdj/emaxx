from pathlib import Path
import hashlib
import json

p = Path(__file__).resolve().parent
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
audit = read(p / 'source323-macos-coverage-audit.json')
state = read(p / 'source323-macos-observations/state.json')
original = Path(state['original_raw_root'])
contract = read(original / 'contract.json')
assert not audit['single_passing_frozen_run'] and audit['original_frozen_verdict'] == 'failed; unchanged'
assert state['status'] == 'terminal; inspect every raw verdict' and state['source_unchanged']
for name, digest in audit['audits'].items():
    assert sha(p / name) == digest
stages = {row['stage']: Path(row['raw_directories'][0]) for row in state['results']}
files = contract['files']
first = {name: original for name in files[:318]}
first['test/lisp/net/tramp-tests.el'] = stages['tramp-longer']
first.update({name: stages['unstarted-tail'] for name in files[319:]})
latest = dict(first)
latest['test/lisp/erc/erc-scenarios-base-statusmsg.el'] = stages['erc-statusmsg']
latest['test/lisp/eshell/esh-proc-tests.el'] = stages['eshell-sigpipe']
for label, selected in [('original_completed_plus_missing_files', first), ('separate_latest_file_observations', latest)]:
    assert set(selected) == set(files) and len(selected) == 519
    matches = differences = 0
    counts = {runner: dict(total=0, passed=0, failed=0, skipped=0, unexpected=0) for runner in ['oracle', 'emaxx']}
    for name, root in selected.items():
        directory = (root / name).with_suffix('.compat')
        comparison = read(directory / 'comparison.json')
        matches += comparison['matching_outcomes']
        differences += comparison['mismatching_outcomes']
        for runner in counts:
            report = read(directory / (runner + '.json'))
            actual = {key: sum(value['status'] == key for value in report['results']) for key in ['passed', 'failed', 'skipped']}
            actual.update(total=len(report['results']), unexpected=sum(not value['expected'] for value in report['results']))
            assert actual == report['summary']
            for key, value in actual.items():
                counts[runner][key] += value
    observed = dict(files=519, matching_outcomes=matches, mismatching_outcomes=differences,
                    total_outcomes=matches + differences, runner_summaries=counts,
                    file_sources={name: str(root) for name, root in selected.items()})
    assert observed == audit['views'][label]
assert audit['views']['original_completed_plus_missing_files']['mismatching_outcomes'] == 8
assert audit['views']['separate_latest_file_observations']['mismatching_outcomes'] == 6
print('Verified both explicit file-to-run views; original frozen failure is preserved.')
