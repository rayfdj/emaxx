from pathlib import Path
import hashlib
import json
import re

p = Path(__file__).resolve().parent
w = p.parents[2]
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
state = read(p / 'source323-macos-observations/state.json')
original = read(Path(state['original_raw_root']) / 'contract.json')
inventory = {}
for line in (w / 'compat/oracle_tests_all.txt').read_text().splitlines():
    match = re.fullmatch(r'(\S+): discovered=(\d+) selected=(\d+)', line)
    if match:
        name = match[1]
        inventory[name] = dict(discovered=int(match[2]), selected=int(match[3]), names=[])
    elif line.strip():
        inventory[name]['names'].append(line.strip())
results = []
for label, file, selected, deadline in [
    ('erc-statusmsg', 'test/lisp/erc/erc-scenarios-base-statusmsg.el', 1, 180),
    ('eshell-sigpipe', 'test/lisp/eshell/esh-proc-tests.el', 24, 180),
    ('tramp-longer', 'test/lisp/net/tramp-tests.el', 59, 600),
]:
    row = next(row for row in state['results'] if row['stage'] == label)
    assert row['exit_code'] == 0 and row['source_unchanged'] and not row['supervisor_timed_out']
    assert sha(p / 'source323-macos-observations' / (label + '.log')) == row['log_sha256']
    assert len(row['raw_directories']) == 1
    r = Path(row['raw_directories'][0])
    contract = read(r / 'contract.json')
    summary = read(r / 'summary.json')
    assert contract['files'] == summary['files'] == [file]
    assert contract['name_filter'] is None and contract['selector'] == original['selector']
    assert contract['provenance']['timeout_seconds'] == deadline
    for key in ['subject_source_sha256', 'subject_git_head', 'subject_git_dirty', 'oracle_sha256',
                'oracle_helper_sha256', 'oracle_repo_commit', 'oracle_test_support_sha256', 'runtime_images_sha256']:
        assert contract['provenance'][key] == original['provenance'][key], key
    assert summary['total_outcomes'] == summary['matching_outcomes'] == selected
    assert summary['mismatching_outcomes'] == 0 and not summary['mismatches'] and not summary['unsuccessful_files']
    d = (r / file).with_suffix('.compat')
    comparison = read(d / 'comparison.json')
    execution = read(d / 'execution.json')
    assert comparison['matches'] and not comparison['issues'] and not comparison['execution_issues']
    assert execution['contract_sha256'] == sha(r / 'contract.json')
    assert all(sha(d / name) == digest for name, digest in execution['sha256'].items())
    pair, timing = {}, {}
    for runner in ['oracle', 'emaxx']:
        report = read(d / (runner + '.json'))
        process = read(d / (runner + '.execution.json'))['process']
        assert process['exit_code'] == 0 and not process['timed_out'] and process['test_started'] and process['timeout_phase'] is None
        assert report['file'] == file and report['selector'] == original['selector']
        assert report['file_status'] == 'loaded' and report['file_error'] is None
        assert len(report['discovered_tests']) == inventory[file]['discovered']
        assert len(report['selected_tests']) == len(set(report['selected_tests'])) == selected
        assert set(report['selected_tests']) == set(inventory[file]['names'])
        values = report['results']
        assert len(values) == len({value['name'] for value in values}) == selected
        assert {value['name'] for value in values} == set(inventory[file]['names'])
        counts = {key:sum(value['status'] == key for value in values) for key in ['passed', 'failed', 'skipped']}
        counts.update(total=len(values), unexpected=sum(not value['expected'] for value in values))
        assert counts == report['summary'] == summary['runner_summaries'][runner]
        assert counts['unexpected'] == 0
        pair[runner] = {value['name']:(value['status'], value['expected'], value['condition_type']) for value in values}
        timing[runner] = process['test_elapsed']['secs'] + process['test_elapsed']['nanos'] / 1e9
        assert 0 < timing[runner] < deadline
    assert pair['oracle'] == pair['emaxx']
    assert len(row['retained_inputs']) == 4
    for artifact in row['retained_inputs']:
        path = Path(artifact['retained'])
        assert sha(path) == artifact['sha256'] and path.stat().st_size == artifact['bytes']
    results.append(dict(stage=label, raw_root=str(r), matching_outcomes=selected,
                        runner_summaries=summary['runner_summaries'], deadline_seconds=deadline,
                        test_seconds=timing, subject_sha256=contract['provenance']['subject_sha256'],
                        retained_inputs=row['retained_inputs'],
                        raw_files={str(path.relative_to(r)):sha(path) for path in r.rglob('*') if path.is_file()}))
assert sum(row['matching_outcomes'] for row in results) == 84
result = dict(status='84 matching outcomes in three separate observations', observations=results,
              original_subject_sha256=original['provenance']['subject_sha256'],
              original_frozen_verdict='failed; unchanged', goal_complete=False,
              qualification='ERC and Eshell use their original180-second deadlines, unchanged files and full selectors. Tramp separately allows600 seconds as authorized and obtains both actual answers. Every original selected name, raw outcome, execution hash and retained input is checked. The harness rebuilt Emaxx from identical source inputs; its new executable hash is recorded separately, with original and observation bytes both retained. GNU and both runtime images are unchanged. These observations neither replace the failed frozen run nor establish why its internal waits failed, and they are not authoritative performance measurements. The200-file tail and226-scenario terminal run are separate.')
with (p / 'source323-macos-three-observations-audit.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(dict(status=result['status'], test_seconds={row['stage']:row['test_seconds'] for row in results})))
