from pathlib import Path
import json

p = Path(__file__).resolve().parent
read = lambda path: json.loads(path.read_text())
ns = {'__file__': str(p / 'package_source323_base.py')}
exec((p / 'package_source323_base.py').read_text(), ns)
destination = p / 'pending-publication-2026-10-13'
destination.mkdir(exist_ok=True)
ns['destination'] = destination
state = read(p / 'source323-macos-observations/state.json')
assert state['status'] == 'terminal; inspect every raw verdict' and state['source_unchanged']
original = Path(state['original_raw_root'])
trees = [('evidence/original-frozen/' + original.name, original)]
trees += [('evidence/observations/' + Path(row['raw_directories'][0]).name, Path(row['raw_directories'][0])) for row in state['results']]
trees += [('evidence/' + name, p / name) for name in ['source323-macos-frozen', 'source323-macos-observations']]
files = ['source323-macos-frozen-incomplete-audit.json', 'audit_source323_macos_frozen_failure.py',
         'source323-macos-three-observations-audit.json', 'audit_source323_macos_observations.py',
         'source323-macos-tail-audit.json', 'audit_source323_macos_tail.py',
         'source323-macos-coverage-audit.json', 'verify_source323_macos_coverage.py',
         'source323_macos_frozen.py', 'source323_macos_observations.py',
         'package_source323_base.py', Path(__file__).name]
references = [('evidence/reference/source318-macos-tail-audit.json', p.parent / 'symbol-payload-api-2026-10-09/source318-macos-tail-audit.json')]
coverage = read(p / 'source323-macos-coverage-audit.json')
ns['package']('source323-macos-frozen-observations-results', trees,
              [('evidence/' + name, p / name) for name in files] + references,
              dict(checkpoint='source323 original failed macOS frozen run and complete separate observations',
                   source_commit='0550a70c8d8b48ae0369e235e570dc484bea6a44',
                   coverage=coverage,
                   original={key:value for key,value in read(p / 'source323-macos-frozen-incomplete-audit.json').items() if key not in ['raw_files', 'tramp_timeouts']},
                   tail={key:value for key,value in read(p / 'source323-macos-tail-audit.json').items() if key != 'raw_files'},
                   qualification='All519 pinned macOS file inventories/7921 outcomes are observed across separately identified attempts. The original run remains failed:4477 matches/two internal-wait differences, then both180-second Tramp timeouts and200 unstarted files. Separate unchanged ERC/Eshell files produce25 matches; bounded600-second Tramp produces59 actual matches; the original200-file tail produces3377 matches/six existing diagnostic differences. Those six issue entries are identical to source318 and remain strict differences. Both original and separately rebuilt Emaxx executable bytes, plus unchanged images/GNU inputs, are retained locally; large bytes are explicitly excluded from this portable archive. The two aggregate views preserve file-to-run mappings and never claim a single passing frozen run. Terminal, the unapplied symbol prototype, architecture/accounting and performance are separate.'))
