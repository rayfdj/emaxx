from pathlib import Path
import hashlib
import io
import json
import re
import subprocess
import tarfile

p = Path(__file__).resolve().parent
w = p.parents[2]
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
state = read(p / 'source323-macos-frozen/state.json')
assert state['status'] == 'terminal; inspect strict raw verdicts' and state['source_unchanged']
assert [row['exit_code'] for row in state['results']] == [0, 2]
assert all(not row['timed_out'] for row in state['results'])
for row in state['results']:
    assert sha(p / 'source323-macos-frozen' / (row['stage'] + '.log')) == row['log_sha256']
r = Path(re.search(r'^Artifacts: (.+)$', (p / 'source323-macos-frozen/frozen.log').read_text(), re.M)[1])
assert not (r / 'summary.json').exists()
contract = read(r / 'contract.json')
head = '0550a70c8d8b48ae0369e235e570dc484bea6a44'
assert contract['mode'] == 'frozen' and contract['name_filter'] is None
assert contract['provenance']['subject_git_head'] == head and not contract['provenance']['subject_git_dirty']
assert contract['provenance']['timeout_seconds'] == 180
lock = read(w / 'compat/oracle.lock.json')
assert contract['selector'] == lock['selector_default']
assert contract['provenance']['oracle_sha256'] == lock['emacs_binary_sha256']
assert contract['provenance']['oracle_repo_commit'] == lock['emacs_repo_commit']
source = state['source_inputs']
assert len(source) == 565
data = subprocess.check_output(['git', 'archive', head, '--', *source], cwd=w)
with tarfile.open(fileobj=io.BytesIO(data)) as archive:
    for name, row in source.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == row['sha256']
        assert ('0o755' if archive.getmember(name).mode & 0o111 else '0o644') == row['mode']
        assert sha(w / name) == row['sha256']
inventory = {}
for line in (w / 'compat/oracle_tests_all.txt').read_text().splitlines():
    match = re.fullmatch(r'(\S+): discovered=(\d+) selected=(\d+)', line)
    if match:
        name = match[1]
        inventory[name] = dict(discovered=int(match[2]), selected=int(match[3]), names=[])
    elif line.strip():
        inventory[name]['names'].append(line.strip())
assert contract['files'] == list(inventory) and len(inventory) == 519
assert sum(row['selected'] for row in inventory.values()) == 7921
completed, issues, unexpected = [], [], {runner: [] for runner in ['oracle', 'emaxx']}
matched = different = processes = 0
for name in contract['files']:
    d = (r / name).with_suffix('.compat')
    if not (d / 'comparison.json').exists():
        continue
    comparison = read(d / 'comparison.json')
    assert comparison['file'] == name
    expected = inventory[name]
    assert comparison['matching_outcomes'] + comparison['mismatching_outcomes'] == expected['selected']
    execution = read(d / 'execution.json')
    assert execution['contract_sha256'] == sha(r / 'contract.json')
    assert all(sha(d / name) == digest for name, digest in execution['sha256'].items())
    pair = {}
    for runner in unexpected:
        report = read(d / (runner + '.json'))
        process = read(d / (runner + '.execution.json'))['process']
        assert process['exit_code'] == 0 and not process['timed_out'] and process['timeout_phase'] is None and process['test_started']
        assert report['file'] == name and report['selector'] == contract['selector']
        assert report['file_status'] == 'loaded' and report['file_error'] is None
        assert len(report['discovered_tests']) == expected['discovered']
        assert len(report['selected_tests']) == len(set(report['selected_tests'])) == expected['selected']
        assert set(report['selected_tests']) == set(expected['names'])
        results = report['results']
        assert len(results) == len({row['name'] for row in results}) == expected['selected']
        assert {row['name'] for row in results} == set(expected['names'])
        counts = {key:sum(row['status'] == key for row in results) for key in ['passed', 'failed', 'skipped']}
        counts.update(total=len(results), unexpected=sum(not row['expected'] for row in results))
        assert counts == report['summary']
        unexpected[runner] += [row for row in results if not row['expected']]
        pair[runner] = {row['name']:(row['status'], row['expected'], row['condition_type']) for row in results}
        processes += 1
    if comparison['matches']:
        assert not comparison['issues'] and not comparison['execution_issues']
        assert pair['oracle'] == pair['emaxx']
    else:
        issues.append(comparison)
    matched += comparison['matching_outcomes']
    different += comparison['mismatching_outcomes']
    completed.append(name)
assert completed == contract['files'][:318] and (matched, different, processes) == (4477, 2, 636)
assert [row['name'] for row in unexpected['oracle']] == ['esh-proc-test/sigpipe-exits-process']
assert [row['name'] for row in unexpected['emaxx']] == ['erc-scenarios-base-statusmsg']
tramp = r / 'test/lisp/net/tramp-tests.compat'
timeouts = {}
for runner in unexpected:
    process = read(tramp / (runner + '.execution.json'))['process']
    assert process['exit_code'] is None and process['timed_out'] and process['timeout_phase'] == 'Test'
    assert process['test_started'] and process['test_elapsed']['secs'] == 180
    timeouts[runner] = process
unstarted = [name for name in contract['files'] if not (r / name).with_suffix('.compat').exists()]
assert unstarted == contract['files'][319:] and len(unstarted) == 200
for row in state['retained_inputs']:
    path = Path(row['retained'])
    assert sha(path) == row['sha256'] and path.stat().st_size == row['bytes']
assert len(state['retained_inputs']) == 4
result = dict(status='failed; incomplete frozen run', source_commit=head, source_inputs_verified=565,
              raw_root=str(r), completed_comparisons=318, matching_outcomes=matched, mismatching_outcomes=different,
              successful_processes=processes, timed_out_processes=2, issues=issues, unexpected_results=unexpected,
              tramp_timeouts=timeouts, unstarted_files=unstarted, retained_inputs=state['retained_inputs'],
              raw_files={str(path.relative_to(r)):sha(path) for path in r.rglob('*') if path.is_file()},
              qualification='The original source323 run remains failed: 318 complete comparisons, ERC wait failure in Emaxx, Eshell SIGPIPE wait failure in GNU, and both original180-second Tramp timeouts. All200 later files are unstarted. Every completed frozen inventory entry, raw outcome count and execution hash is checked. Actual original executable and image bytes were retained before separate observations. These results are not performance measurements or a passing full comparison; subsequent observations retain separate commands and verdicts.',
              goal_complete=False)
with (p / 'source323-macos-frozen-incomplete-audit.json').open('x') as output:
    json.dump(result, output, indent=2)
    output.write('\n')
print(json.dumps({key:result[key] for key in ['status', 'completed_comparisons', 'matching_outcomes', 'mismatching_outcomes', 'successful_processes', 'timed_out_processes']}))
