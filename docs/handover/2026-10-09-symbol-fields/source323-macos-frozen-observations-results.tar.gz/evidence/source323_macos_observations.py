from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess
import time

p = Path(__file__).resolve().parent
w = p.parents[2]
out = p / 'source323-macos-observations'
out.mkdir(exist_ok=False)
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
original_state = read(p / 'source323-macos-frozen/state.json')
assert original_state['status'] == 'terminal; inspect strict raw verdicts'
assert original_state['source_unchanged']
raw = Path(re.search(r'^Artifacts: (.+)$', (p / 'source323-macos-frozen/frozen.log').read_text(), re.M)[1])
contract = read(raw / 'contract.json')
source = original_state['source_inputs']
assert len(source) == 565 and contract['provenance']['subject_git_head'] == '0550a70c8d8b48ae0369e235e570dc484bea6a44'
completed = [name for name in contract['files'] if ((raw / name).with_suffix('.compat') / 'comparison.json').exists()]
unstarted = [name for name in contract['files'] if not (raw / name).with_suffix('.compat').exists()]
assert completed == contract['files'][:318]
assert unstarted == contract['files'][319:] and len(unstarted) == 200
assert unstarted[0] == 'test/lisp/net/webjump-tests.el'
state = dict(status='prepared', pid=os.getpid(), started=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             original_raw_root=str(raw), original_contract_sha256=sha(raw / 'contract.json'),
             source_inputs=source, original_frozen_verdict='failed; preserved unchanged',
             environment_overrides=original_state['environment_overrides'], results=[], goal_complete=False)
environment = {**os.environ, **state['environment_overrides']}

def save():
    (out / 'state.json').write_text(json.dumps(state, indent=2) + '\n')

def verify():
    for name, row in source.items():
        assert sha(w / name) == row['sha256'], name
        assert oct((w / name).stat().st_mode & 0o777) == row['mode'], name
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=w, text=True).strip() == contract['provenance']['subject_git_head']
    assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=w)

def retain(provenance):
    retained = out / 'retained-inputs'
    retained.mkdir(exist_ok=True)
    files = {provenance['subject_binary']: provenance['subject_sha256'],
             provenance['oracle_binary']: provenance['oracle_sha256'], **provenance['runtime_images_sha256']}
    result = []
    for name, digest in files.items():
        path = Path(name)
        assert sha(path) == digest
        target = retained / (digest + '-' + path.name)
        if not target.exists():
            subprocess.run(['cp', '-c', str(path), str(target)], check=True)
        assert sha(target) == digest == sha(path)
        result.append(dict(original=name, retained=str(target), sha256=digest, bytes=target.stat().st_size))
    return result

stages = [
    ('erc-statusmsg', ['--file', 'test/lisp/erc/erc-scenarios-base-statusmsg.el'], 2700),
    ('eshell-sigpipe', ['--file', 'test/lisp/eshell/esh-proc-tests.el'], 2700),
    ('tramp-longer', ['--file', 'test/lisp/net/tramp-tests.el', '--timeout-seconds', '600'], 2700),
    ('unstarted-tail', ['--from-file', unstarted[0]], 10800),
]
save()
try:
    for label, arguments, timeout in stages:
        verify()
        command = [str(w / 'target/gate/compat-harness'), 'run', '--scope', 'all', *arguments]
        state.update(status='running ' + label, current_command=command)
        save()
        print('START', label, flush=True)
        log = out / (label + '.log')
        start = time.monotonic()
        with log.open('xb') as output:
            try:
                result = subprocess.run(command, cwd=w, env=environment, stdout=output, stderr=subprocess.STDOUT, timeout=timeout)
                code, timed_out = result.returncode, False
            except subprocess.TimeoutExpired:
                code, timed_out = None, True
        roots = re.findall(r'^Artifacts: (.+)$', log.read_text(), re.M)
        assert len(roots) <= 1
        row = dict(stage=label, command=command, exit_code=code, supervisor_timed_out=timed_out,
                   elapsed_seconds=time.monotonic() - start, log_sha256=sha(log), raw_directories=roots)
        if roots and (Path(roots[0]) / 'contract.json').exists():
            current = read(Path(roots[0]) / 'contract.json')
            row['retained_inputs'] = retain(current['provenance'])
        verify()
        row['source_unchanged'] = True
        state['results'].append(row)
        save()
        print('END', label, code, round(row['elapsed_seconds'], 2), flush=True)
    state.update(status='terminal; inspect every raw verdict', source_unchanged=True)
    save()
except BaseException as error:
    state.update(status='supervisor failed; preserve completed stages', error=str(error))
    save()
    raise
raise SystemExit(0 if all(row['exit_code'] == 0 for row in state['results']) else 1)
