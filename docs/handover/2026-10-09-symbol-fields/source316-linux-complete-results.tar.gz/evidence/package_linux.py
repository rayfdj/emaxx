from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).resolve().parent
worktree = p.parent / 'recovered-2026-10-09/symbol-ownership/emaxx'
destination = worktree / 'docs/handover/2026-10-09-symbol-fields'
read = lambda path: json.loads(path.read_text())
rust = read(p / 'source316-linux-rust-audit.json')
frozen = read(p / 'source316-linux-frozen-complete-audit.json')
assert rust['status'] == 'passed' and frozen['status'] == 'matched'
members = {}
excluded = []
for label in ['source316-linux-rust', 'source316-linux-frozen']:
    for path in sorted((p / label / 'raw').rglob('*')):
        if not path.is_file():
            continue
        name = str(path.relative_to(p))
        data = path.read_bytes()
        if len(data) > 1_000_000 and (path.name in ['emacs', 'libtest'] or path.suffix == '.pdmp'):
            excluded.append(dict(path=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
        else:
            members['evidence/' + name] = data
    members['evidence/' + label + '/receipt.json'] = (p / label / 'receipt.json').read_bytes()
for name in ['source316-linux-rust-audit.json', 'source316-linux-frozen-complete-audit.json',
             'source316-linux-frozen-raw-integrity-audit.json', 'source316-linux-status.json',
             'source316-linux-dispatch.json', 'audit_source316_linux_rust.py',
             'audit_source316_linux_frozen.py', 'verify_complete_linux_frozen.py',
             'fetch_source316_artifacts.py', 'source316_ci_status.py', 'package_linux.py',
             'redirect-draft1/source.json']:
    members['evidence/' + name] = (p / name).read_bytes()
members['contents.json'] = (json.dumps({name: dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest()) for name, data in members.items()}, indent=2) + '\n').encode()
buffer = io.BytesIO()
with gzip.GzipFile(fileobj=buffer, mode='wb', mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode='w') as archive:
        for name, data in sorted(members.items()):
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o644
            info.mtime = 0
            archive.addfile(info, io.BytesIO(data))
payload = buffer.getvalue()
archive_path = destination / 'source316-linux-complete-results.tar.gz'
assert not archive_path.exists()
archive_path.write_bytes(payload)
with tarfile.open(fileobj=io.BytesIO(payload), mode='r:gz') as archive:
    assert set(archive.getnames()) == set(members)
    assert all(archive.extractfile(name).read() == data for name, data in members.items())
manifest = dict(checkpoint='source316', source_commit=rust['source_commit'],
                archive=dict(path=archive_path.name, bytes=len(payload), sha256=hashlib.sha256(payload).hexdigest()),
                members=len(members), rust=rust, frozen=frozen, excluded_binaries=excluded,
                qualification='All raw inventories, verdicts, reports, successful process records and execution hashes retained. Large executables/images are retained in the downloaded local artifacts and identified by hash here. Expected failures and skips remain distinct from passes. macOS Rust passed separately; the full macOS frozen comparison is running. Source317 is a separate unapplied draft and retains an unresolved source316 public-instance name-property isolation negative.',
                goal_complete=False)
(destination / 'source316-linux-complete-results-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(dict(members=len(members), bytes=len(payload), sha256=manifest['archive']['sha256'])))
