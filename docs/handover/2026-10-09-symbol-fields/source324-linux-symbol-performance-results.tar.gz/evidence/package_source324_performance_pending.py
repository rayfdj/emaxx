from pathlib import Path
import json

p = Path(__file__).resolve().parent
ns = {'__file__': str(p / 'package_source323_base.py')}
exec((p / 'package_source323_base.py').read_text(), ns)
destination = p / 'pending-publication-source324'
destination.mkdir(exist_ok=True)
ns['destination'] = destination
audit_path = p / 'source324-linux-performance-performance-audit.json'
audit = json.loads(audit_path.read_text())
raw = p / 'source324-linux-performance/raw/core-runtime-pair'
for name, digest in audit['evidence'].items():
    assert ns['sha']((raw / name).read_bytes()) == digest
files = [audit_path.name, 'audit-source324-linux-performance.py', 'fetch_source324_artifacts.py',
    'source324_ci.py', 'source324-commit.json', 'source324-source.json',
    'source324-linux-dispatch.json', 'source324-linux-status.json',
    'source324-linux-performance/receipt.json', 'package_source323_base.py', Path(__file__).name]
ns['package']('source324-linux-symbol-performance-results', [('evidence/raw', raw)],
    [('evidence/' + name, p / name) for name in files],
    dict(checkpoint='source324 allocated symbol fields and identity, diagnostic performance',
        run_id=audit['run_id'], revisions=audit['source_revisions'], results_verified=192,
        raw_body_geometric_ratio=audit['raw_body_geometric_ratio'],
        paired_gnu_geometric_ratios=audit['paired_gnu_geometric_ratios'],
        per_case=[dict(case=row['case'], candidate_over_baseline=row['candidate_over_baseline'],
                       gnu_ratios=row['gnu_ratios'], body_samples=row['body_samples']) for row in audit['results']],
        qualification=audit['qualification']))
