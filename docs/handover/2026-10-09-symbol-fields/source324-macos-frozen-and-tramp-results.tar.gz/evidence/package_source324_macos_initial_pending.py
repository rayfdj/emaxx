from pathlib import Path
import json
import shutil

p = Path(__file__).resolve().parent
read = lambda path: json.loads(path.read_text())
original = read(p / 'source324-macos-frozen-incomplete-audit.json')
tramp = read(p / 'source324-macos-tramp-observation-audit.json')
assert original['matching_outcomes'] == 4479 and original['mismatching_outcomes'] == 0
assert original['completed_comparisons'] == 318 and len(tramp['observations']) == 1
assert tramp['observations'][0]['matching_outcomes'] == 59
snapshot = p / 'source324-macos-observations-initial-snapshot.json'
assert not snapshot.exists()
shutil.copyfile(p / 'source324-macos-observations/state.json', snapshot)
ns = {'__file__': str(p / 'package_source323_base.py')}
exec((p / 'package_source323_base.py').read_text(), ns)
ns['destination'] = p / 'pending-publication-source324'
ns['package']('source324-macos-frozen-and-tramp-results',
    [('evidence/original-frozen', p / 'source324-macos-frozen'),
     ('raw/original-frozen', Path(original['raw_root'])),
     ('raw/tramp-observation', Path(tramp['observations'][0]['raw_root']))],
    [('evidence/' + name, p / name) for name in [
        'source324-macos-frozen-incomplete-audit.json', 'source324-macos-tramp-observation-audit.json',
        'source324-macos-observations-initial-snapshot.json', 'source324-macos-observations/tramp-longer.log',
        'source324_macos_frozen.py', 'source324_macos_observations.py',
        'audit_source324_macos_frozen_failure.py', 'audit_source324_macos_observations.py',
        'package_source323_base.py', Path(__file__).name]],
    dict(checkpoint='source324 original macOS frozen timeout and actual Tramp answers',
        original=original, separate_tramp=tramp,
        qualification='The original frozen run stays failed/incomplete:318 completed files/4479matches/636successful processes, then both180-second Tramp timeouts, with200 files unstarted. A separate unchanged Tramp file/full selector at600seconds obtains59 matching actual outcomes:GNU209.042s/Emaxx257.306s. Original executable/image bytes retained before rebuilding for the observation. Rebuilt observation input bytes retained locally under its receipt, explicitly not present in this archive. The200-file tail and226-scenario terminal run are still separate and uncertified here; no full passing macOS frozen result or performance claim.'))
