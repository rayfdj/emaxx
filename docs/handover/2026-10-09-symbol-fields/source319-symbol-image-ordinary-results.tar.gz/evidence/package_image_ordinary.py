from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import subprocess
import tarfile

p = Path(__file__).resolve().parent
out = p / "image-draft6-ordinary2"
w = p.parent / "recovered-2026-10-09/symbol-obarray/emaxx"
destination = p.parents[2] / "docs/handover/2026-10-09-symbol-fields"
read = lambda path: json.loads(path.read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
source = read(out / "source.json")
assert source == read(p / "image-draft6-relocation/source.json") and len(source) == 565
assert all(sha((w/name).read_bytes()) == row["sha256"] and oct((w/name).stat().st_mode & 0o777) == row["mode"] for name,row in source.items())
assert read(out/"summary.json") == dict(processes=24, passed=24, failed=0, source_inputs=565, goal_complete=False)
results, pairs = read(out/"results.json"), {}
assert len(results) == 24
for row in results:
    label = "-".join([row["fixture"], row["mode"], row["editor"]])
    receipt = read(out/(label+".json"))
    assert receipt["exit_code"] == 0 and not receipt["timed_out"] and receipt["timeout_seconds"] == 180
    for stream in ["stdout", "stderr"]:
        assert sha((out/(label+"."+stream)).read_bytes()) == receipt[stream+"_sha256"]
    output = (out/(label+".stdout")).read_text()
    assert output == row["stdout"] and output.strip() == row["expected"] and row["passed"]
    if row["mode"] != "interpreted":
        assert output.startswith("((t t t t) " if row["fixture"] == "symbol-redirect-lifetime" else "(t ")
    pairs.setdefault((row["fixture"],row["mode"]),{})[row["editor"]] = (output,receipt["command"][1:])
assert len(pairs) == 12 and all(set(pair) == {"gnu","emaxx"} and pair["gnu"] == pair["emaxx"] for pair in pairs.values())
for label in ["build", "image"]:
    receipt = read(out/(label+".json"))
    assert receipt["exit_code"] == 0 and not receipt["timed_out"]
    for stream in ["stdout","stderr"]:
        data = (out/(label+"."+stream)).read_bytes()
        assert sha(data) == receipt[stream+"_sha256"]
        assert not re.search(rb"^warning(?:\[.*?\])?:",data,re.M)
identities = read(out/"artifacts-before.json")
assert identities == read(out/"artifacts-after.json")
retained = p / "image-draft6-retained-inputs"
retained.mkdir(exist_ok=False)
retention = []
for index,(name,row) in enumerate(sorted(identities.items())):
    path = Path(name)
    assert sha(path.read_bytes()) == row["sha256"] and path.stat().st_size == row["bytes"]
    copy = retained/(str(index)+"-"+path.name)
    subprocess.run(["cp","-c",str(path),str(copy)],check=True)
    assert sha(copy.read_bytes()) == row["sha256"]
    retention.append(dict(original=name,retained=str(copy),**row))
audit = dict(status="passed", source_inputs_verified=565, processes=24, comparisons=12,
    actual_modes=["interpreted","bytecode","native"], identical_editor_arguments=True,
    previous_nine_comparisons_preserved=True, added_graph_comparisons=3, retained_inputs=retention,
    qualification="Ordinary release executables and each editor's own valid image; actual compiler-mode predicates are checked outside execution. Original wrapper preflight failure remains in the selected archive. This is not complete platform or performance validation.", goal_complete=False)
(p/"image-draft6-ordinary-audit.json").write_text(json.dumps(audit,indent=2)+"\n")
members = {"evidence/"+str(path.relative_to(p)):path.read_bytes() for path in sorted(out.rglob("*")) if path.is_file()}
for name in ["ordinary_image2.py","continue_image2.py","image-draft6-ordinary2-supervisor.log","image-draft6-ordinary-audit.json","package_image_ordinary.py"]:
    members["evidence/"+name] = (p/name).read_bytes()
members["contents.json"] = (json.dumps({name:dict(bytes=len(data),sha256=sha(data)) for name,data in members.items()},indent=2)+"\n").encode()
buffer = io.BytesIO()
with gzip.GzipFile(fileobj=buffer,mode="wb",mtime=0) as zipped:
    with tarfile.open(fileobj=zipped,mode="w") as archive:
        for name,data in sorted(members.items()):
            entry=tarfile.TarInfo(name); entry.size=len(data); entry.mode=0o644
            archive.addfile(entry,io.BytesIO(data))
data=buffer.getvalue()
path=destination/"source319-symbol-image-ordinary-results.tar.gz"
assert not path.exists()
path.write_bytes(data)
with tarfile.open(fileobj=io.BytesIO(data),mode="r:gz") as archive:
    assert set(archive.getnames())==set(members)
    assert all(archive.extractfile(name).read()==payload for name,payload in members.items())
manifest=dict(checkpoint="source319 unapplied image draft6",archive=dict(path=path.name,bytes=len(data),sha256=sha(data),members=len(members)),audit=audit,goal_complete=False)
(destination/"source319-symbol-image-ordinary-results-manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
print(json.dumps(manifest["archive"]))
