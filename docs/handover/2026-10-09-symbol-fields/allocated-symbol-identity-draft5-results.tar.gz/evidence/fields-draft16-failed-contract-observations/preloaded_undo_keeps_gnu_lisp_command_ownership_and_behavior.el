
          (list
           (commandp 'undo)
           (let ((function (symbol-function 'undo)))
             (or (byte-code-function-p function)
                 (and (subrp function) (subr-native-elisp-p function))))
           (car (interactive-form 'undo))
           (with-temp-buffer
             (buffer-enable-undo)
             (insert "first")
             (undo-boundary)
             (insert " second")
             ;; The command loop (and `ert-simulate-command') closes each
             ;; completed command with this boundary before invoking undo.
             (undo-boundary)
             (undo)
             (buffer-string)))
        