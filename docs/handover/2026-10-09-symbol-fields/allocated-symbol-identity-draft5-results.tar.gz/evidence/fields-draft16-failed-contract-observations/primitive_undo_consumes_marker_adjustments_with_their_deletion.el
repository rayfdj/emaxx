
          (with-temp-buffer
            (buffer-enable-undo)
            (insert "abc")
            (setq buffer-undo-list nil)
            (let ((marker (copy-marker 2)))
              (delete-region 1 4)
              (let ((pending buffer-undo-list)
                    (undo-in-progress t))
                (setq pending (primitive-undo 1 pending))
                (list (buffer-string) (marker-position marker) pending))))
        