
          (with-temp-buffer
            (buffer-enable-undo)
            (insert "before")
            (let* ((original buffer-undo-list)
                   (extended (cons nil original)))
              (setq buffer-undo-list extended)
              (let ((extended-is-visible (eq buffer-undo-list extended)))
                (setq buffer-undo-list original)
                (list extended-is-visible
                      (eq buffer-undo-list original)))))
        