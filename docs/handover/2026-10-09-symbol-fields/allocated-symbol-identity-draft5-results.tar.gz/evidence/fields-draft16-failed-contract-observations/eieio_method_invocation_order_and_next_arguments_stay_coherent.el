(let ((actual (list
                   (cl--class-allparents (cl-find-class 'eitest-B))
                   (cl--class-allparents (cl-find-class 'D))
                   (cl--class-allparents (cl-find-class 'E)))) (expected '((eitest-B eitest-B-base1 eitest-B-base2
                    eieio-default-superclass record atom t)
                   (D D-base1 D-base2 D-base0
                    eieio-default-superclass record atom t)
                   (E E-base1 E-base2 E-base0
                    eieio-default-superclass record atom t)))) (list (equal actual expected) actual))