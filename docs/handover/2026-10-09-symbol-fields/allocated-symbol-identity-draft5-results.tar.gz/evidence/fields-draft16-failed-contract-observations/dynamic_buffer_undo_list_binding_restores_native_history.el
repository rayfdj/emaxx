
          (with-temp-buffer
            (buffer-enable-undo)
            (insert "before")
            (undo-boundary)
            (let ((original buffer-undo-list)
                  temporary-result)
              (let ((buffer-undo-list nil))
                (insert " temporary")
                (let ((pending buffer-undo-list)
                      (undo-in-progress t))
                  (setq pending (primitive-undo 1 pending))
                  (setq temporary-result (list (buffer-string) pending))))
              (list temporary-result (eq buffer-undo-list original))))
        