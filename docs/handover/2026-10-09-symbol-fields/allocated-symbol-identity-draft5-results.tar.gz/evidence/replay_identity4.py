from pathlib import Path
import hashlib, io, json, subprocess, tarfile, tempfile

p = Path(__file__).resolve().parent
r = p.parents[2]
base = '265d5ba3405cebe7692560cc29722be65d62237b'
source = json.loads((p / 'fields-identity-draft4-gate/source.json').read_text())
patch = p / 'fields-identity-draft4.patch'
sha = lambda data: hashlib.sha256(data).hexdigest()
available = set(subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', base], cwd=r, text=True).splitlines())
data = subprocess.check_output(['git', 'archive', base, '--', *[name for name in source if name in available]], cwd=r)
with tempfile.TemporaryDirectory(prefix='emaxx-identity4-replay-') as tmp:
    directory = Path(tmp)
    with tarfile.open(fileobj=io.BytesIO(data)) as archive:
        for entry in archive.getmembers():
            if not entry.isfile():
                continue
            target = directory / entry.name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(archive.extractfile(entry).read())
            target.chmod(0o755 if entry.mode & 0o111 else 0o644)
    subprocess.run(['git', 'apply', str(patch)], cwd=directory, check=True)
    for name, row in source.items():
        assert sha((directory / name).read_bytes()) == row['sha256'], name
        assert oct((directory / name).stat().st_mode & 0o777) == row['mode'], name
result = dict(base=base, patch=patch.name, sha256=sha(patch.read_bytes()), source_inputs=len(source), replayed=True, validation='395 pass; unchanged Eshell failure retained', goal_complete=False)
with (p / 'fields-identity-draft4-replay.json').open('x') as output:
    json.dump(result, output, indent=2)
    output.write('\n')
print(json.dumps(result))
