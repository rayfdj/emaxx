;;; -*- lexical-binding: t; -*-
(defvar observed-symbol-events nil)
(advice-add 'pcomplete-find-completion-function :around
 (lambda (original &rest args)
  (let ((answer (apply original args)))
   (push (list answer (intern-soft "pcomplete/echo")
               (eq (intern-soft "pcomplete/echo") 'pcomplete/echo)
               (fboundp 'pcomplete/echo)
               (type-of (symbol-function 'pcomplete/echo))
               (autoloadp (symbol-function 'pcomplete/echo))) observed-symbol-events)
   answer)))
(let ((answer (with-temp-eshell
                     (ert-with-temp-directory default-directory :suffix "-emaxx"
                       (write-region nil nil (expand-file-name "file.txt"))
                       (write-region nil nil (expand-file-name "file.el"))
                       (let ((first (eshell-insert-and-complete "echo fi")))
                         (completion-at-point)
                         (list first
                               (not (null
                                     (get-buffer-window
                                      "*Completions*"))))))))) (prin1 answer) (terpri) (dolist (row (nreverse observed-symbol-events)) (prin1 row) (terpri)))
