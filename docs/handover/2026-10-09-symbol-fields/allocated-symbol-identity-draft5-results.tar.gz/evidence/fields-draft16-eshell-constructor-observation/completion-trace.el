;;; -*- lexical-binding: t; -*-
(defvar observed-constructor-events nil)
(dolist (name '(pcomplete--entries pcomplete-entries pcomplete-find-completion-function))
 (advice-add name :around
  (lambda (original &rest args)
   (push (list name 'enter
          (mapcar (lambda (x) (if (functionp x) 'callable x)) args)
          (special-variable-p 'predicate)
          (special-variable-p 'regexp)) observed-constructor-events)
   (let ((answer (apply original args)))
    (push (list name 'exit (if (functionp answer) 'callable answer)) observed-constructor-events)
    answer))))
(let ((answer (with-temp-eshell
                     (ert-with-temp-directory default-directory :suffix "-emaxx"
                       (write-region nil nil (expand-file-name "file.txt"))
                       (write-region nil nil (expand-file-name "file.el"))
                       (let ((first (eshell-insert-and-complete "echo fi")))
                         (completion-at-point)
                         (list first
                               (not (null
                                     (get-buffer-window
                                      "*Completions*"))))))))) (prin1 answer) (terpri) (dolist (row (nreverse observed-constructor-events)) (prin1 row) (terpri)))
