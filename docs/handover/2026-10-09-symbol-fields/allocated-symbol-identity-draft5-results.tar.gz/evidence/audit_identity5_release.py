from pathlib import Path
import hashlib
import json
import re
import subprocess

p = Path(__file__).resolve().parent
w = p.parent / 'recovered-2026-10-12/symbol-identity/emaxx'
d = p / 'fields-identity-draft5-release'
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
source = read(d / 'source.json')
assert len(source) == 572
assert source == read(d / 'source-after.json') == read(p / 'fields-identity-draft5-gate/source.json')
for name, row in source.items():
    assert sha(w / name) == row['sha256']
    assert oct((w / name).stat().st_mode & 0o777) == row['mode']
for name in ['build', 'inventory', 'focused']:
    receipt = read(d / (name + '.json'))
    assert receipt['exit_code'] == 0
    for stream in ['stdout', 'stderr']:
        path = d / (name + '.' + stream)
        assert sha(path) == receipt[stream + '_sha256']
        if name == 'build':
            assert not re.search(r'^warning(?:\[.*?\])?:', path.read_text(errors='replace'), re.M)
selection = read(d / 'selection.json')
assert selection == read(p / 'fields-identity-draft5-gate/selection.json')
verdicts = re.findall(r'^test (\S+) \.\.\. (ok|FAILED|ignored)\s*$', (d / 'focused.stdout').read_text(), re.M)
assert len(verdicts) == len(selection) == len(set(selection)) == 397
assert set(dict(verdicts)) == set(selection) and all(verdict == 'ok' for _, verdict in verdicts)
old = {line[:-6] for line in (p / 'fields-draft16-release/inventory.stdout').read_text().splitlines() if line.endswith(': test')}
new = {line[:-6] for line in (d / 'inventory.stdout').read_text().splitlines() if line.endswith(': test')}
assert old < new and len(new) == 3080 and len(new - old) == 3
binary = read(d / 'binary.json')
assert sha(Path(binary['retained'])) == binary['sha256']
retained = d / 'retained-fixture-images'
retained.mkdir(exist_ok=False)
files = []
for original in sorted(Path(read(d / 'environment.json')['EMAXX_FIXTURE_IMAGE_DIR']).glob('*.pdmp')):
    digest = sha(original)
    target = retained / original.name
    subprocess.run(['cp', '-c', str(original), str(target)], check=True)
    assert sha(target) == digest == sha(original)
    files.append(dict(original=str(original), artifact=target.name, sha256=digest, bytes=target.stat().st_size))
(retained / 'manifest.json').write_text(json.dumps(dict(files=files, qualification='Post-run images; no per-test image-use claim.'), indent=2) + '\n')
result = dict(status='passed', source_inputs=572, profile='release', selected=397, passed=397,
              inventory=3080, previous_inventory_names_preserved=len(old),
              added_tests=sorted(new - old), source_unchanged=True, retained_binary=binary,
              strict_gate_audit_sha256=sha(p / 'fields-identity-draft5-selected-audit.json'),
              qualification='The same 397 selected controls pass in release with all earlier release inventory names preserved. Inputs match the strict gate validation exactly. This remains an unapplied prototype; full, ordinary, complete platform and performance results are separate.',
              goal_complete=False)
with (p / 'fields-identity-draft5-release-audit.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({key:result[key] for key in ['status', 'source_inputs', 'selected', 'inventory']}))
