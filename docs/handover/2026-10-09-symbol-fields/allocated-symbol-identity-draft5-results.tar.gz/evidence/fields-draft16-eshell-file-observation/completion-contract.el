(prin1 (with-temp-eshell
                     (ert-with-temp-directory default-directory :suffix "-emaxx"
                       (write-region nil nil (expand-file-name "file.txt"))
                       (write-region nil nil (expand-file-name "file.el"))
                       (let ((first (eshell-insert-and-complete "echo fi")))
                         (completion-at-point)
                         (list first
                               (not (null
                                     (get-buffer-window
                                      "*Completions*"))))))))
