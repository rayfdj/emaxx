from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import subprocess
import tarfile

p = Path(__file__).resolve().parent
out = p / "fields-identity-draft5-ordinary"
w = p.parent / "recovered-2026-10-12/symbol-identity/emaxx"
destination = p.parents[2] / "docs/handover/2026-10-09-symbol-fields"
read = lambda path: json.loads(path.read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
source = read(out / "source.json")
assert source == read(p / "fields-identity-draft5-gate/source.json") and len(source) == 572
assert all(sha((w/name).read_bytes()) == row["sha256"] and oct((w/name).stat().st_mode & 0o777) == row["mode"] for name,row in source.items())
assert read(out/"summary.json") == dict(processes=56, passed=56, failed=0, source_inputs=572, goal_complete=False)
results, pairs = read(out/"results.json"), {}
assert len(results) == 56
for row in results:
    label = "-".join([row["fixture"], row["mode"], row["editor"]])
    receipt = read(out/(label+".json"))
    assert receipt["exit_code"] == 0 and not receipt["timed_out"] and receipt["timeout_seconds"] == 180
    for stream in ["stdout", "stderr"]:
        assert sha((out/(label+"."+stream)).read_bytes()) == receipt[stream+"_sha256"]
    output = (out/(label+".stdout")).read_text()
    assert output == row["stdout"] and output.strip() == row["expected"] and row["passed"]
    if row["mode"] != "interpreted":
        assert output.startswith("((t t t t) " if row["fixture"] == "symbol-redirect-lifetime" else "(t ")
    pairs.setdefault((row["fixture"],row["mode"]),{})[row["editor"]] = (output,receipt["command"][1:])
assert len(pairs) == 28 and all(set(pair) == {"gnu","emaxx"} and pair["gnu"] == pair["emaxx"] for pair in pairs.values())
prior = read(p / 'fields-draft16-ordinary/results.json')
assert {(row['fixture'], row['mode']) for row in prior} < set(pairs)
for label in ["build", "image"]:
    receipt = read(out/(label+".json"))
    assert receipt["exit_code"] == 0 and not receipt["timed_out"]
    for stream in ["stdout","stderr"]:
        data = (out/(label+"."+stream)).read_bytes()
        assert sha(data) == receipt[stream+"_sha256"]
        assert not re.search(rb"^warning(?:\[.*?\])?:",data,re.M)
extra = read(out / 'eshell-inputs-before.json')
assert extra == read(out / 'eshell-inputs-after.json')
assert (out / 'completion-contract.el').read_bytes() == (p / 'fields-draft16-eshell-file-observation/completion-contract.el').read_bytes()
for name, row in extra.items():
    assert sha(Path(name).read_bytes()) == row['sha256'] and Path(name).stat().st_size == row['bytes']

identities = read(out/"artifacts-before.json")
assert identities == read(out/"artifacts-after.json")
retained = p / "fields-identity-draft5-ordinary-retained-inputs"
retained.mkdir(exist_ok=False)
retention = []
for index,(name,row) in enumerate(sorted(identities.items())):
    path = Path(name)
    assert sha(path.read_bytes()) == row["sha256"] and path.stat().st_size == row["bytes"]
    copy = retained/(str(index)+"-"+path.name)
    subprocess.run(["cp","-c",str(path),str(copy)],check=True)
    assert sha(copy.read_bytes()) == row["sha256"]
    retention.append(dict(original=name,retained=str(copy),**row))
audit = dict(status="passed", source_inputs_verified=572, processes=56, comparisons=28,
    actual_modes=["interpreted","bytecode","native"], identical_editor_arguments=True,
    previous_twenty_one_comparisons_preserved=True, added_programmed_completion_comparisons=3, added_intern_soft_comparisons=3, added_original_eshell_comparison=1, retained_inputs=retention,
    qualification="Unapplied symbol identity draft5: all original21 comparisons plus programmed-completion and intern-soft in all three real modes, and the original Eshell completion body loaded from a real file. Both editors use their own release executable and valid image. Actual mode predicates and all expected answers are checked. This is not full platform or performance validation; prior failed attempts remain unchanged.", goal_complete=False)
(p/"fields-identity-draft5-ordinary-audit.json").write_text(json.dumps(audit,indent=2)+"\n")
print(json.dumps(audit,indent=2))
