from pathlib import Path
import hashlib
import json
import re
import subprocess

p = Path(__file__).resolve().parent
w = p.parent / 'recovered-2026-10-12/symbol-identity/emaxx'
d = p / 'fields-identity-draft5-gate'
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
source = read(d / 'source.json')
assert len(source) == 572 and source == read(d / 'source-after.json')
for name, row in source.items():
    assert sha(w / name) == row['sha256']
    assert oct((w / name).stat().st_mode & 0o777) == row['mode']
for name in ['fmt', 'check', 'clippy', 'diff', 'build', 'inventory', 'focused']:
    receipt = read(d / (name + '.json'))
    assert receipt['exit_code'] == 0
    for stream in ['stdout', 'stderr']:
        path = d / (name + '.' + stream)
        assert sha(path) == receipt[stream + '_sha256']
        if name in ['check', 'clippy', 'build']:
            assert not re.search(r'^warning(?:\[.*?\])?:', path.read_text(errors='replace'), re.M)
selection = read(d / 'selection.json')
verdicts = re.findall(r'^test (\S+) \.\.\. (ok|FAILED|ignored)\s*$', (d / 'focused.stdout').read_text(), re.M)
assert len(verdicts) == len(selection) == len(set(selection)) == 397
assert set(dict(verdicts)) == set(selection) and all(verdict == 'ok' for _, verdict in verdicts)
prior_failures = read(p / 'fields-draft16-full-failed-audit.json')['failures']
assert len(prior_failures) == 15 and set(prior_failures) <= set(selection)
old = {line[:-6] for line in (p / 'fields-draft16-gate/inventory.stdout').read_text().splitlines() if line.endswith(': test')}
new = {line[:-6] for line in (d / 'inventory.stdout').read_text().splitlines() if line.endswith(': test')}
assert old < new and len(new) == 3081 and len(new - old) == 3
assert set(read(p / 'fields-identity-draft4-gate/selection.json')) < set(selection)
binary = read(d / 'binary.json')
assert sha(Path(binary['retained'])) == binary['sha256']
patch = p / 'fields-identity-draft5.patch'
with patch.open('xb') as stream:
    stream.write((d / 'tracked.patch').read_bytes())
assert subprocess.check_output(['git', 'diff', '--binary'], cwd=w) == patch.read_bytes()
retained = d / 'retained-fixture-images'
retained.mkdir(exist_ok=False)
files = []
for original in sorted(Path(read(d / 'environment.json')['EMAXX_FIXTURE_IMAGE_DIR']).glob('*.pdmp')):
    digest = sha(original)
    target = retained / original.name
    subprocess.run(['cp', '-c', str(original), str(target)], check=True)
    assert sha(target) == digest == sha(original)
    files.append(dict(original=str(original), artifact=target.name, sha256=digest, bytes=target.stat().st_size))
(retained / 'manifest.json').write_text(json.dumps(dict(files=files, qualification='Post-run images; no per-test image-use claim.'), indent=2) + '\n')
result = dict(status='passed', source_inputs=572, selected=397, passed=397, failed=0,
              inventory=3081, previous_inventory_names_preserved=len(old),
              added_tests=sorted(new - old), original_fifteen_failure_names_now_passed=prior_failures,
              patch_sha256=sha(patch), source_unchanged=True, retained_binary=binary,
              qualification='Strict checks have zero warnings. All 397 selected controls pass, including all fifteen previous full-library failures, unchanged Eshell assertions, reclamation assertions, programmed-completion input identity/properties/mutation and nonallocating intern-soft misses. The previous failed runs remain failures. Full, release, ordinary, platform and performance validation of this unapplied prototype remain separate and pending. The original published runtime is not changed or certified by this result.',
              goal_complete=False)
with (p / 'fields-identity-draft5-selected-audit.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({key:result[key] for key in ['status', 'source_inputs', 'selected', 'inventory', 'patch_sha256']}))
