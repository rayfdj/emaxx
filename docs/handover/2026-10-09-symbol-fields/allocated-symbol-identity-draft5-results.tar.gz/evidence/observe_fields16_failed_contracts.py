from pathlib import Path
import hashlib, json, os, re, subprocess, time

p = Path(__file__).resolve().parent
w = p.parent / 'recovered-2026-10-10/symbol-fields/emaxx'
g = p.parent / 'rebuilt-2026-10-01/emacs'
d = p / 'fields-draft16-failed-contract-observations'
d.mkdir(exist_ok=False)
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
programs = []
text = (w / 'src/lisp/primitives/tests.rs').read_text()
for name in ['preloaded_undo_keeps_gnu_lisp_command_ownership_and_behavior',
             'dynamic_buffer_undo_list_binding_restores_native_history',
             'buffer_undo_list_assignment_preserves_cons_identity',
             'primitive_undo_consumes_marker_adjustments_with_their_deletion']:
    block = text[text.index('fn ' + name + '()'):].split('\n#[test]', 1)[0]
    program = re.search(r'r#"(.*?)"#', block, re.S)[1]
    programs.append((name, program, []))
text = (w / 'src/lisp/eval/tests/eval_05.rs').read_text()
name = 'eieio_method_invocation_order_and_next_arguments_stay_coherent'
block = text[text.index('fn ' + name + '()'):].split('\n#[test]', 1)[0]
actual = re.search(r'&mut interp,\s*"([^"]*)"', block)[1]
expected = re.search(r'eval_str\(\s*"([^"]*)"', block)[1]
programs.append((name, '(let ((actual ' + actual + ') (expected ' + expected + ')) (list (equal actual expected) actual))',
                 ['-l', str(g / 'test/lisp/emacs-lisp/eieio-tests/eieio-test-methodinvoke.el')]))
name = 'eshell_ambiguous_completion_displays_candidates_on_second_attempt'
block = text[text.index('fn ' + name + '()'):].split('\n#[test]', 1)[0]
program = re.search(r'r#"(.*?)"#', block, re.S)[1]
programs.append((name, program, ['-L', str(g / 'test/lisp/eshell'), '-l', str(g / 'test/lisp/eshell/em-cmpl-tests.el')]))
executables = [('gnu', g / 'src/emacs'), ('emaxx', w / 'target/release/emaxx')]
inputs = {str(path): dict(sha256=sha(path), bytes=path.stat().st_size)
          for _, binary in executables for path in [binary, binary.with_suffix('.pdmp')]}
(d / 'inputs.json').write_text(json.dumps(inputs, indent=2) + '\n')
comparisons = []
for name, program, args in programs:
    (d / (name + '.el')).write_text(program)
    outputs = {}
    for editor, binary in executables:
        command = [str(binary), '-Q', '--batch', *args, '--eval', '(prin1 ' + program + ')']
        print('START', name, editor, flush=True)
        started = time.monotonic()
        result = subprocess.run(command, cwd=w, env={**os.environ, 'LANG':'C', 'LC_ALL':'C'}, capture_output=True, timeout=180)
        label = name + '-' + editor
        for stream in ['stdout', 'stderr']:
            (d / (label + '.' + stream)).write_bytes(getattr(result, stream))
        record = dict(command=command, exit_code=result.returncode, elapsed_seconds=time.monotonic()-started,
                      stdout_sha256=sha(d / (label + '.stdout')), stderr_sha256=sha(d / (label + '.stderr')))
        (d / (label + '.json')).write_text(json.dumps(record, indent=2) + '\n')
        outputs[editor] = dict(exit_code=result.returncode, stdout=result.stdout.decode(errors='replace'))
        print('END', name, editor, result.returncode, outputs[editor]['stdout'], flush=True)
    comparisons.append(dict(name=name, matched=outputs['gnu']==outputs['emaxx'], results=outputs))
assert all(sha(Path(name))==row['sha256'] for name,row in inputs.items())
(d / 'summary.json').write_text(json.dumps(dict(status='terminal; inspect actual outcomes', comparisons=comparisons,
    inputs_unchanged=True, qualification='Separate ordinary executions of unchanged failing Rust-fixture Lisp operations. Failed Rust results remain failed; these observations distinguish behavior from host object construction/ownership. No deadline or runtime behavior is changed.', goal_complete=False), indent=2) + '\n')
