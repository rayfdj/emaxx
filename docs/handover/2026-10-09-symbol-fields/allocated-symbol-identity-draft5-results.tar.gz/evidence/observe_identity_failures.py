from pathlib import Path
import hashlib, json, os, subprocess, time

p = Path(__file__).resolve().parent
w = p.parent / 'recovered-2026-10-12/symbol-identity/emaxx'
d = p / 'fields-identity-draft2-existing-failures'
d.mkdir(exist_ok=False)
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
capture = p / 'fields-identity-draft2-gate'
binary = read(capture / 'binary.json')
source = read(capture / 'source.json')
failures = read(p / 'fields-draft16-full-failed-audit.json')['failures']
environment = read(capture / 'environment.json')
environment['EMAXX_FIXTURE_IMAGE_DIR'] = str(d / 'fixture-images')
environment['RUST_BACKTRACE'] = '1'
groups = [('eval_02', 'lisp::eval::tests::eval_02::', True),
          ('eval_04', 'lisp::eval::tests::eval_04::', True),
          ('eval_05', 'lisp::eval::tests::eval_05::', True),
          ('primitives', 'lisp::primitives::', True),
          ('batch', 'batch::', False),
          ('lightweight', None, False)]
remaining = set(failures)
state = dict(status='running', source_inputs=source, binary=binary, groups=[], goal_complete=False)
def save():
    (d / 'state.json').write_text(json.dumps(state, indent=2) + '\n')
def verify():
    assert sha(Path(binary['retained'])) == binary['sha256']
    for name, row in source.items():
        assert sha(w / name) == row['sha256']
        assert oct((w / name).stat().st_mode & 0o777) == row['mode']
verify()
save()
for name, prefix, template in groups:
    names = sorted(n for n in remaining if prefix is None or n.startswith(prefix))
    remaining.difference_update(names)
    assert names
    env = {**os.environ, **environment}
    if not template:
        env.pop('EMAXX_IMAGE_TEMPLATE', None)
    command = [binary['retained'], '--exact', '--test-threads=1', *names]
    print('START', name, len(names), flush=True)
    started = time.monotonic()
    with (d / (name + '.log')).open('xb') as output:
        result = subprocess.run(command, cwd=w, env=env, stdout=output, stderr=subprocess.STDOUT, timeout=3600)
    verify()
    state['groups'].append(dict(group=name, selected=names, command=command, environment={k:v for k,v in environment.items() if template or k!='EMAXX_IMAGE_TEMPLATE'}, template=template, exit_code=result.returncode, elapsed_seconds=time.monotonic()-started, log_sha256=sha(d / (name + '.log'))))
    save()
    print('END', name, result.returncode, flush=True)
assert not remaining
state.update(status='terminal; inspect every original failure', source_unchanged=True)
save()
