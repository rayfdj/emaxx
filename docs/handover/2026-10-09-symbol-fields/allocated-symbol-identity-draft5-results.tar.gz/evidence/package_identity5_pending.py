from pathlib import Path
import json

p = Path(__file__).resolve().parent
f = p.parent / 'allocated-symbols-2026-10-10'
ns = {'__file__': str(p / 'package_source323_base.py')}
exec((p / 'package_source323_base.py').read_text(), ns)
destination = p / 'pending-publication-2026-10-13'
destination.mkdir(exist_ok=True)
ns['destination'] = destination
read = lambda path: json.loads(path.read_text())
assert read(f / 'fields-identity-draft5-full-audit.json')['status'] == 'passed'
entries = lambda root, names: [('evidence/' + name, root / name) for name in names]
trees = ['fields-identity-draft2-existing-failures',
         'fields-identity-draft3-gate', 'fields-identity-draft4-gate',
         'fields-identity-draft5-gate', 'fields-identity-draft5-release',
         'fields-identity-draft5-full', 'fields-identity-draft5-ordinary',
         'fields-identity-draft5-ordinary-retained-inputs',
         'fields-draft16-failed-contract-observations', 'fields-draft16-eshell-file-observation',
         'eshell-published-checkpoint-observation',
         'programmed-completion-input-negative', 'programmed-completion-published-checkpoint-negative',
         'intern-soft-no-allocation-negative',
         'fields-draft16-eshell-advice-observation', 'fields-draft16-eshell-return-observation',
         'fields-draft16-eshell-arguments-observation', 'fields-draft16-eshell-file-predicate-observation',
         'fields-draft16-eshell-constructor-observation', 'fields-draft16-eshell-symbol-observation']
files = ['fields-identity-draft3.patch', 'fields-identity-draft4.patch', 'fields-identity-draft5.patch',
         'fields-identity-draft3-audit.json', 'fields-identity-draft4-audit.json',
         'fields-identity-draft3-replay.json', 'fields-identity-draft4-replay.json', 'fields-identity-draft5-replay.json',
         'replay_identity3.py', 'replay_identity4.py', 'replay_identity5.py',
         'fields-identity-draft5-selected-audit.json', 'fields-identity-draft5-release-audit.json',
         'fields-identity-draft5-full-audit.json', 'fields-identity-draft5-ordinary-audit.json',
         'audit_identity5_selected.py', 'audit_identity5_release.py', 'audit_identity5_full.py', 'audit_identity5_ordinary.py',
         'validate_fields_identity3.py', 'validate_fields_identity4.py', 'validate_fields_identity5.py',
         'ordinary_fields_identity5.py', 'observe_identity_failures.py', 'observe_fields16_failed_contracts.py',
         'fields-draft16-full-failed-audit.json']
assert all((f / name).is_dir() for name in trees)
assert all((f / name).is_file() for name in files)
ns['package']('allocated-symbol-identity-draft5-results', entries(f, trees),
              entries(f, files) + entries(p, [Path(__file__).name, 'package_source323_base.py']),
              dict(checkpoint='unapplied symbol identity draft5 with complete local Rust validation',
                   base_commit='265d5ba3405cebe7692560cc29722be65d62237b',
                   replay=read(f / 'fields-identity-draft5-replay.json'),
                   selected=read(f / 'fields-identity-draft5-selected-audit.json'),
                   release=read(f / 'fields-identity-draft5-release-audit.json'),
                   full=read(f / 'fields-identity-draft5-full-audit.json'),
                   ordinary=read(f / 'fields-identity-draft5-ordinary-audit.json'),
                   qualification='The572-input cumulative patch replays from base265d. Strict checks have zero warnings; all397 selected controls pass in both profiles; the full local macOS Rust gate has3178 passes/two existing ignores with native artifact identity; all28 ordinary GNU comparisons match in real interpreted/bytecode/native modes and the original Eshell body. All prior failures remain retained. Fourteen invalid cross-owner fixture setups now preserve their original assertions within the right editor; the real Eshell regression is repaired by making intern-soft lookup nonallocating. The separate programmed-completion repair passes the original Lisp string through callback identity/properties/mutation. That defect was also reproduced in published source323, whose runtime is unchanged by this archive. The prototype native fixture uses the adjacent symlink to the configured GNU tree here; integration onto source323 must preserve its configured-root correction. Allocated symbol IDs/counters and field side metadata are removed, with a64-byte allocated header, but host-name/membership/forwarded adapters, public ownership, physical accounting, Linux/frozen/terminal, profiles and the complete performance goal remain open. This dirty local prototype is not a clean published runtime. Large executable/image bytes are retained locally and explicitly excluded from the portable archive.'))
