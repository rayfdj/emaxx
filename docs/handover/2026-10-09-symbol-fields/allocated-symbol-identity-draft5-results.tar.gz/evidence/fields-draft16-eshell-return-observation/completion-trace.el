;;; -*- lexical-binding: t; -*-
(defvar observed-completion-events nil)
(defun observed-completion-state ()
  (list (buffer-name) this-command last-command completion-auto-help
        (and (get-buffer-window "*Completions*") t)))
(dolist (name '(completion-at-point completion--in-region completion--in-region-1
               completion--do-completion minibuffer-completion-help
               display-buffer minibuffer-hide-completions test-completion completion-try-completion completion--cycle-threshold minibuffer--bitset))
  (advice-add name :around
              (lambda (original &rest args)
                (push (list name 'enter (observed-completion-state)) observed-completion-events)
                (let ((answer (apply original args)))
                  (push (list name 'exit (if (memq name '(test-completion completion-try-completion completion--cycle-threshold minibuffer--bitset completion--do-completion)) answer 'omitted) (observed-completion-state)) observed-completion-events)
                  answer))))
(let ((answer (with-temp-eshell
                     (ert-with-temp-directory default-directory :suffix "-emaxx"
                       (write-region nil nil (expand-file-name "file.txt"))
                       (write-region nil nil (expand-file-name "file.el"))
                       (let ((first (eshell-insert-and-complete "echo fi")))
                         (completion-at-point)
                         (list first
                               (not (null
                                     (get-buffer-window
                                      "*Completions*")))))))))
(prin1 answer) (terpri)
(dolist (entry (nreverse observed-completion-events)) (prin1 entry) (terpri)))
