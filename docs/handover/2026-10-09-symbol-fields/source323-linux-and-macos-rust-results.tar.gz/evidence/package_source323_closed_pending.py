from pathlib import Path
import json
import sys

p = Path(__file__).resolve().parent
ns = {'__file__': str(p / 'package_source323_base.py')}
exec((p / 'package_source323_base.py').read_text(), ns)
destination = p / 'pending-publication-2026-10-13'
destination.mkdir(exist_ok=True)
ns['destination'] = destination
package = ns['package']
read = lambda path: json.loads(path.read_text())
entries = lambda names: [('evidence/' + name, p / name) for name in names]
helpers = ['package_source323_base.py', Path(__file__).name]

if sys.argv[1] == 'platform':
    package('source323-linux-and-macos-rust-results',
            entries(['source323-linux-rust/raw', 'source323-linux-frozen/raw', 'source323-macos-full']),
            entries(helpers + ['source323-commit.json', 'source323-linux-dispatch.json',
                               'source323-linux-status.json', 'source323_ci.py', 'fetch_source323_artifacts.py',
                               'source323-linux-rust/receipt.json', 'source323-linux-frozen/receipt.json',
                               'source323-linux-rust-audit.json', 'audit_source323_linux_rust.py',
                               'source323-linux-frozen-complete-audit.json',
                               'source323-linux-frozen-raw-integrity-audit.json',
                               'audit_source323_linux_frozen.py', 'verify_complete_linux_frozen.py',
                               'source323-native-audit.json', 'source323-macos-rust-audit.json',
                               'audit_source323_macos_rust.py', 'retain_source323_fixture_supplement.py',
                               'validate_native_root.py']),
            dict(checkpoint='source323 complete Linux validation and full macOS Rust gate',
                 source_commit=read(p / 'source323-commit.json')['commit'],
                 linux_rust=read(p / 'source323-linux-rust-audit.json'),
                 linux_frozen=read(p / 'source323-linux-frozen-complete-audit.json'),
                 macos_rust=read(p / 'source323-macos-rust-audit.json'),
                 macos_retention_supplement=read(p / 'source323-macos-full/full/retained-fixture-images-supplement/manifest.json'),
                 qualification='Source323 has 3183 Linux Rust passes/two existing ignores, all519 Linux frozen files/7928 matching outcomes/1038 successful processes, and3171 macOS Rust passes/two existing ignores. Every raw library name, frozen inventory and execution hash is audited. macOS native artifact identity passes. The first macOS retention captured only libtest; a separate supplement preserves nine images from the actual grouped-gate directory without claiming per-test use. Frozen macOS, terminal and performance are separate; their failures are not certified by these green gates. Large binary/image bytes remain locally retained and are explicitly excluded from this portable text archive.'))
elif sys.argv[1] == 'eglot':
    package('source322-eglot-actual-answer-results',
            entries(['source322-eglot-observation/raw']),
            entries(helpers + ['source322-eglot-observation/receipt.json',
                               'source322-eglot-observation-dispatch.json',
                               'source322-eglot-observation-audit.json',
                               'verify_source322_eglot.py', 'observe_source322_eglot.py',
                               'fetch_source322_eglot.py', 'source322-linux-frozen-failed-audit.json']),
            dict(checkpoint='separate unchanged Linux Eglot observation after source322 GNU timeout',
                 audit=read(p / 'source322-eglot-observation-audit.json'),
                 qualification='Run38236654817 obtains all52 matching unchanged Eglot outcomes:45 passes/seven skips in each editor, including the actual GNU Rust-completion answer. The original source322 full frozen run remains failed at GNU internal JSON-RPC timeout; it is preserved in the earlier source322 archive. No source, test, selector, expectation or deadline was changed for this observation, and Emaxx was not slowed. This artifact identifies executable/images through provenance without their bytes.'))
else:
    raise ValueError('unknown package')
