from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys

p = Path(__file__).resolve().parent
r = p.parents[2]
root = p / 'source323-macos-full/full'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda path: json.loads(path.read_text())
summary = read(root / 'summary.json')
assert summary['status'] == 'passed'
assert summary['git']['head'] == read(p / 'source323-commit.json')['commit']
original = root / 'retained-inputs/manifest.json'
record = read(original)
assert record['gate_summary_sha256'] == sha(root / 'summary.json')
assert len(record['files']) == 1 and record['files'][0]['artifact'] == 'libtest'
sys.path.insert(0, str(r / 'tools'))
import grouped_gate
actual = Path(grouped_gate.gate_environment(True)['EMAXX_FIXTURE_IMAGE_DIR'])
assert actual == r / 'target/grouped-gate/fixture-images'
wrapper = Path(read(p / 'source323-macos-full/environment.json')['EMAXX_FIXTURE_IMAGE_DIR'])
assert wrapper != actual and not wrapper.exists()
destination = root / 'retained-fixture-images-supplement'
destination.mkdir(exist_ok=False)
files = []
for path in sorted(actual.glob('*.pdmp')):
    digest = sha(path)
    target = destination / path.name
    subprocess.run(['cp', '-c', str(path), str(target)], check=True)
    assert sha(target) == digest == sha(path)
    files.append(dict(original=str(path), artifact=path.name, sha256=digest,
                      bytes=path.stat().st_size, original_mtime_ns=path.stat().st_mtime_ns))
assert any(path['artifact'].startswith('loadup-' + summary['test_binary']['sha256'][:8] + '-') for path in files)
result = dict(status='retained', retained_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              gate_summary_sha256=sha(root / 'summary.json'),
              original_retention_manifest_sha256=sha(original),
              original_rust_audit_sha256=sha(p / 'source323-macos-rust-audit.json'),
              actual_directory=str(actual), wrapper_directory=str(wrapper),
              gate_environment_source_sha256=sha(r / 'tools/grouped_gate.py'), files=files,
              qualification='The initial retention captured only libtest because it used the outer wrapper environment. grouped_gate.gate_environment overrides that fixture directory. This separate supplement preserves all remaining images in the actual directory, including files from prior executions. It does not identify which image any individual test loaded, and it does not modify the original run, audit or retention manifest.',
              goal_complete=False)
with (destination / 'manifest.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(dict(status=result['status'], files=len(files), gate_summary_sha256=result['gate_summary_sha256'])))
