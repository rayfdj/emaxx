from pathlib import Path
import hashlib,json,re,sys
root=Path(sys.argv[1]);head=sys.argv[2];run_id=int(sys.argv[3]);out=Path(sys.argv[4])
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
s=json.loads((root/'summary.json').read_text());lock=json.loads(Path('compat/oracle.lock.linux.json').read_text());manifest=Path('compat/oracle_tests_all_linux.txt')
expected={};current=None
for line in manifest.read_text().splitlines():
    m=re.fullmatch(r'(\S+): discovered=(\d+) selected=(\d+)',line)
    if m:
        current=m[1];assert current not in expected;expected[current]={'discovered':int(m[2]),'selected':int(m[3]),'names':[]}
    elif line.strip():
        assert current and line.startswith('  ');expected[current]['names'].append(line.strip())
assert len(expected)==519 and sum(v['selected'] for v in expected.values())==7928
assert all(len(v['names'])==v['selected']==len(set(v['names'])) for v in expected.values())
assert s['mode']=='frozen' and s['scope']=='Frozen' and s['name_filter'] is None
assert s['selector']==lock['selector_default']
assert len(s['files'])==len(set(s['files']))==519 and set(s['files'])==set(expected)
assert s['total_files']==519 and s['matching_files']==518 and s['mismatching_files']==1
assert s['matching_outcomes']==7927 and s['total_outcomes']==7928 and s['mismatching_outcomes']==1
assert len(s['mismatches'])==1 and s['unsuccessful_files']==['test/lisp/progmodes/eglot-tests.el']
fm=s['frozen_manifest'];assert fm['sha256']==sha(manifest) and fm['recorded_files']==fm['executed_files']==519 and fm['required_outcomes']==fm['compared_outcomes']==7928 and fm['historical_load_errors']==0
prov=s['provenance'];assert prov['subject_git_head']==head and not prov['subject_git_dirty']
assert prov['oracle_sha256']==lock['emacs_binary_sha256'] and prov['oracle_repo_commit']==lock['emacs_repo_commit'] and prov['oracle_native_compilation']
assert json.loads((root/'head.json').read_text())['commit']==head
counts={r:{k:0 for k in ['total','passed','failed','skipped','unexpected']} for r in ['emaxx','oracle']};processes=0;outcomes=0
for file,inventory in expected.items():
    directory=(root/file).with_suffix('.compat')
    c=json.loads((directory/'comparison.json').read_text())
    assert c['file']==file
    mismatch = file == 'test/lisp/progmodes/eglot-tests.el'
    assert c['mismatching_outcomes']==int(mismatch)
    assert c['matching_outcomes']==inventory['selected']-int(mismatch)
    if mismatch:
        assert not c['matches'] and len(c['issues'])==3 and len(c['execution_issues'])==1
        assert all('eglot-test-rust-completion-exit-function' in issue['detail'] for issue in c['issues']+c['execution_issues'])
    else:
        assert c['matches'] and not c['issues'] and not c['execution_issues']
    outcomes+=inventory['selected']
    for runner in counts:
        report=json.loads((directory/(runner+'.json')).read_text())
        assert report['file']==file and report['file_error'] is None and report['file_status']=='loaded' and report['selector']==s['selector']
        assert len(report['discovered_tests'])==inventory['discovered']
        selected=report['selected_tests'];assert len(selected)==len(set(selected))==inventory['selected'] and set(selected)==set(inventory['names'])
        results=report['results'];assert len(results)==len(set(r['name'] for r in results))==len(selected) and {r['name'] for r in results}==set(selected)
        observed={k:sum(r['status']==k for r in results) for k in ['passed','failed','skipped']};observed.update(total=len(results),unexpected=sum(not r['expected'] for r in results))
        assert observed==report['summary'] and observed['unexpected']==int(mismatch and runner=='oracle')
        if mismatch:
            row=next(r for r in results if r['name']=='eglot-test-rust-completion-exit-function')
            assert row['status']==('failed' if runner=='oracle' else 'passed')
            assert row['expected']==(runner!='oracle')
            if runner=='oracle':
                assert row['condition_type']=='jsonrpc-error' and 'Timed out' in row['message']
        for key,n in observed.items():counts[runner][key]+=n
        process=json.loads((directory/(runner+'.execution.json')).read_text())['process']
        assert process['exit_code']==0 and process['test_started'] and not process['timed_out'] and process['timeout_phase'] is None
        processes+=1
assert counts==s['runner_summaries'] and outcomes==7928 and processes==1038
result={'status':'failed; exactly one GNU-only JSON-RPC timeout','run_id':run_id,'published_commit':head,'verified_files':len(expected),'verified_outcomes':outcomes,'matching_outcomes':7927,'mismatching_outcomes':1,'successful_processes':processes,'runner_summaries':counts,'pinned_oracle_sha256':prov['oracle_sha256'],'frozen_manifest':fm,'summary_sha256':sha(root/'summary.json'),'qualification':'All 519 files, 7928 outcomes and 1038 normally exited processes verified. The full run remains FAILED: the GNU Eglot JSON-RPC request expires internally after 10 seconds; Emaxx passes unchanged. No outer process deadline expired. GNU input bytes are retained; Emaxx executable/image bytes are identified only by provenance. A separate observation cannot rewrite this failure. No macOS or performance conclusion.'}
for file in s['files']:
    directory=(root/file).with_suffix('.compat')
    execution=json.loads((directory/'execution.json').read_text())
    assert execution['contract_sha256']==sha(root/'contract.json')
    assert all(sha(directory/name)==digest for name,digest in execution['sha256'].items())
    pair=[json.loads((directory/(runner+'.json')).read_text()) for runner in ('oracle','emaxx')]
    left={r['name']:(r['status'],r['expected']) for r in pair[0]['results']}
    right={r['name']:(r['status'],r['expected']) for r in pair[1]['results']}
    different=[name for name in left if left[name]!=right[name]]
    assert different==(['eglot-test-rust-completion-exit-function'] if file.endswith('/eglot-tests.el') else [])
artifact=root.parent.parent
cap=artifact/'oracle-inputs'
capture=json.loads((cap/'manifest.json').read_text());verification=json.loads((cap/'verification.json').read_text())
assert capture['status']=='captured' and verification['status']=='unchanged'
assert verification['capture_manifest_sha256']==sha(cap/'manifest.json')
assert verification['files_verified']==len(capture['files'])==4 and not capture['source_tracked_changes']
assert capture['source_commit']==prov['oracle_repo_commit']
for item in capture['files']:
    assert sha(cap/item['artifact'])==item['sha256'] and (cap/item['artifact']).stat().st_size==item['bytes']
assert capture['files'][0]['sha256']==prov['oracle_sha256']
result.update(oracle_capture=capture,oracle_verification=verification,goal_complete=False)
result['raw_files']={str(f.relative_to(artifact)):sha(f) for f in artifact.rglob('*') if f.is_file()}
with out.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['raw_files','oracle_capture','oracle_verification']}))
