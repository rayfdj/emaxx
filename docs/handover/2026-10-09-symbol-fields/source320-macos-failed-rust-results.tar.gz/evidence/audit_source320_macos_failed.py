from pathlib import Path
import hashlib,io,json,re,subprocess,tarfile
p=Path(__file__).resolve().parent;r=p.parents[2];d=p/'image-draft8-full';f=d/'full'
read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
s=read(f/'summary.json');assert s['status']=='failed' and not s['cargo_stages'] and s['git']==dict(dirty=False,head='4905b3e7c7aabe2e25886fe1e0611715db93ec6d')
receipt=read(d/'full.json');assert receipt['exit_code']==1
for stream in ['stdout','stderr']:assert sha(d/('full.'+stream))==receipt[stream+'_sha256']
source=read(d/'source.json');assert source==read(p/'image-draft8-edebug-owner/source.json') and len(source)==565
raw=subprocess.check_output(['git','archive',s['git']['head'],'--',*source],cwd=r)
with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
 for name,row in source.items():
  assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==row['sha256']
  assert ('0o755' if archive.getmember(name).mode&0o111 else '0o644')==row['mode']
inventory={line[:-6] for line in (f/'inventory.txt').read_text().splitlines() if line.endswith(': test')};assert len(inventory)==3073
seen={};groups=[]
pattern=r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;'
for log in sorted(f.glob('repeat-*.log')):
 text=log.read_text();summaries=re.findall(pattern,text);assert len(summaries)==1
 status,passed,failed,ignored,measured,filtered=summaries[0];passed,failed,ignored,measured,filtered=map(int,[passed,failed,ignored,measured,filtered]);assert measured==0
 starts=list(re.finditer(r'^test (\S+) \.\.\. ',text,re.M));assert len(starts)==passed+failed+ignored
 verdicts={}
 for i,m in enumerate(starts):
  end=starts[i+1].start() if i+1<len(starts) else text.find('\n\nfailures:',m.end()) if '\n\nfailures:' in text[m.end():] else text.rindex('test result:')
  tail=text[m.end():end].strip();verdict='ignored' if tail.startswith('ignored') else 'FAILED' if re.search(r'(?:^|\s)FAILED$',tail) else 'ok' if re.search(r'(?:^|\s)ok$',tail) else None
  assert verdict,(m[1],tail);assert m[1] in inventory and m[1] not in seen
  verdicts[m[1]]=verdict;seen[m[1]]=verdict
 assert [sum(v==k for v in verdicts.values()) for k in ['ok','FAILED','ignored']]==[passed,failed,ignored]
 groups.append(dict(log=log.name,sha256=sha(log),passed=passed,failed=failed,ignored=ignored))
failed=[name for name,v in seen.items() if v=='FAILED'];assert failed==['batch::tests::session_path_does_not_discover_the_gnu_test_tree']
assert len(inventory-seen.keys())==572
ret=read(f/'retained-inputs/manifest.json');assert ret['status']=='retained' and ret['gate_status']=='failed' and ret['gate_summary_sha256']==sha(f/'summary.json')
for row in ret['files']:assert sha(f/'retained-inputs'/row['artifact'])==row['sha256']
result=dict(status='failed; complete raw attempted inventory audited',source_commit=s['git']['head'],source_inputs_verified=len(source),library_inventory=len(inventory),observed=len(seen),passed=sum(v=='ok' for v in seen.values()),failed=failed,ignored=[n for n,v in seen.items() if v=='ignored'],unexecuted=sorted(inventory-seen.keys()),groups=groups,retained_inputs=ret,summary_sha256=sha(f/'summary.json'),qualification='The original full gate remains failed. The existing startup control compared the configured rebuilt GNU load path with an assumed adjacent checkout. Remaining library group and Cargo stages were not run. Its corrected fixture retains the environment-independence and exact load-path assertions; actual GNU runs confirm the environment variable does not change load-path. This evidence does not certify the later retirement repair.',goal_complete=False)
(p/'source320-macos-rust-failed-audit.json').open('x').write(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['status','observed','passed','failed','ignored']},indent=2))
