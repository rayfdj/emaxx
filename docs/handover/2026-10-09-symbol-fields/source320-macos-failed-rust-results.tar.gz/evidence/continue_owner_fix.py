from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time

p = Path(__file__).resolve().parent
read = lambda path: json.loads(path.read_text())
gate = p / "image-draft8-edebug-owner"
assert read(gate / "focused.json")["exit_code"] == 0
assert read(gate / "source.json") == read(gate / "source-after.json")
out = p / "image-draft8-continuation-state.json"
assert not out.exists()
state = dict(status="starting source320 ordinary and full macOS validation", pid=os.getpid(),
             started=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             results=[], goal_complete=False)


def save():
    out.write_text(json.dumps(state, indent=2) + "\n")


state['source_commit'] = read(p / 'source320-commit.json')['commit']
state['execution_boundary'] = 'Authorized local socket/PTY execution outside the tool sandbox'
save()
for label, command in [
    ("ordinary", [sys.executable, str(p / "ordinary_owner_fix.py")]),
    ("full", [sys.executable, str(p / "validate_owner_fix.py"), "image-draft8-full", "full"]),
]:
    state.update(status="running " + label)
    save()
    print(state["status"], flush=True)
    start = time.monotonic()
    log = p / ("image-draft8-" + label + "-supervisor.log")
    with log.open("xb") as stream:
        result = subprocess.run(command, cwd=p, stdout=stream, stderr=subprocess.STDOUT)
    state["results"].append(dict(stage=label, command=command, exit_code=result.returncode,
                                 elapsed_seconds=time.monotonic() - start,
                                 log_sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
    save()
    if result.returncode:
        state.update(status="failed " + label + "; preserve evidence")
        save()
        raise SystemExit(result.returncode)
state.update(status="terminal; audit actual results")
save()
print(state["status"], flush=True)
