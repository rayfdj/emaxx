from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).resolve().parent
r = p.parents[2]
fp = p.parent / 'allocated-symbols-2026-10-10'
destination = r / 'docs/handover/2026-10-09-symbol-fields'
read = lambda path: json.loads(path.read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()


def package(name, trees, files, information):
    members, excluded = {}, []

    def add(name, path):
        data = path.read_bytes()
        if len(data) > 1_000_000 and (path.name in ['libtest', 'emaxx', 'emacs'] or path.suffix == '.pdmp'):
            excluded.append(dict(path=str(path), bytes=len(data), sha256=sha(data)))
        else:
            assert name not in members
            members[name] = data

    for prefix, directory in trees:
        for path in sorted(directory.rglob('*')):
            if path.is_file():
                add(prefix + '/' + str(path.relative_to(directory)), path)
    for prefix, path in files:
        add(prefix, path)
    members['contents.json'] = (json.dumps({key:dict(bytes=len(data), sha256=sha(data)) for key,data in members.items()},indent=2)+'\n').encode()
    buffer = io.BytesIO()
    with gzip.GzipFile(fileobj=buffer, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for key, data in sorted(members.items()):
                entry = tarfile.TarInfo(key)
                entry.size, entry.mode = len(data), 0o644
                archive.addfile(entry, io.BytesIO(data))
    data = buffer.getvalue()
    path = destination / (name + '.tar.gz')
    with path.open('xb') as stream:
        stream.write(data)
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
        assert set(archive.getnames()) == set(members)
        assert all(archive.extractfile(key).read() == value for key,value in members.items())
    manifest = dict(archive=dict(path=path.name, bytes=len(data), sha256=sha(data), members=len(members)),
                    excluded_large_inputs=excluded, goal_complete=False, **information)
    with (destination / (name + '-manifest.json')).open('x') as stream:
        json.dump(manifest, stream, indent=2)
        stream.write('\n')
    print(json.dumps(manifest['archive']), flush=True)


failed = read(p / 'source320-macos-rust-failed-audit.json')
ordinary = read(p / 'source320-ordinary-audit.json')
package('source320-macos-failed-rust-results',
    [('evidence/'+label,p/label) for label in ['image-draft8-full','image-draft8-ordinary','source320-macos-frozen']],
    [('evidence/'+name,p/name) for name in ['source320-macos-rust-failed-audit.json','source320-ordinary-audit.json',
       'audit_source320_macos_failed.py','audit_owner_fix_ordinary.py','ordinary_owner_fix.py','validate_owner_fix.py',
       'continue_owner_fix.py','image-draft8-continuation-state.json','image-draft8-full-supervisor.log',
       'image-draft8-ordinary-supervisor.log','source320_macos_frozen.py','load-path-gnu-audit.json',
       'load-path-gnu-unset.stdout','load-path-gnu-unset.stderr','load-path-gnu-test-tree.stdout','load-path-gnu-test-tree.stderr','package_macos320.py']],
    dict(checkpoint='source320 failed macOS Rust attempt, ordinary comparisons and superseded frozen queue',
         failed_audit=failed,ordinary_audit=ordinary,
         qualification='The full attempt retains 2,498 passes, one failed existing path fixture, two existing ignores, 572 unexecuted library names and unstarted Cargo stages. Six post-run executable/image files are retained locally. The 12 ordinary comparisons are separately successful. The macOS frozen queue was canceled before comparisons after a remaining editor-retirement defect was reproduced. Actual GNU processes confirm that EMACS_TEST_DIRECTORY does not change load-path. These are not complete passing platform results.'))
