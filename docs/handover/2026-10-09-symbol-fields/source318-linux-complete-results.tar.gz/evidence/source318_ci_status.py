from pathlib import Path
import datetime,json
p=Path(__file__).resolve().parent
ns={}
exec((p.parent/'symbol-progress-2026-10-08/github_ci.py').read_text().split('operation=sys.argv[1]')[0],ns)
request=ns['request']
receipt=json.loads((p/'source318-linux-dispatch.json').read_text())
_,data=request('actions/workflows/frozen-run.yml/runs?event=workflow_dispatch&per_page=20')
runs=[]
for run in data['workflow_runs']:
 if run['head_sha']!=receipt['commit']:continue
 _,jobs=request('actions/runs/'+str(run['id'])+'/jobs')
 runs.append(dict(id=run['id'],url=run['html_url'],status=run['status'],conclusion=run['conclusion'],created_at=run['created_at'],jobs=jobs['jobs']))
record=dict(commit=receipt['commit'],observed=datetime.datetime.now(datetime.timezone.utc).isoformat(),runs=runs,goal_complete=False)
(p/'source318-linux-status.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps([dict(id=row['id'],url=row['url'],status=row['status'],conclusion=row['conclusion'],active_steps=[step['name'] for job in row['jobs'] for step in job['steps'] if step['status']=='in_progress']) for row in runs],indent=2))
