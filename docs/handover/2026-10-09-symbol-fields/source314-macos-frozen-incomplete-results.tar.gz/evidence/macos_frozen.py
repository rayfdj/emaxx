import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root=Path('/Users/nbmhqa186/projects/emaxx')
worktree=root/'target/runtime-goal/recovered-2026-10-08/symbol-plists/emaxx'
evidence=root/'target/runtime-goal/symbol-progress-2026-10-08'
output=evidence/'source314-macos-frozen'
output.mkdir(exist_ok=False)
gnu=root/'target/runtime-goal/rebuilt-2026-10-01/emacs'
commit=json.loads((evidence/'source314-commit.json').read_text())['commit']
source=json.loads((evidence/'symbol-draft4/source.json').read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def verify():
    for name,row in source.items():assert sha(worktree/name)==row['sha256'],name
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=worktree,text=True).strip()==commit
verify()
local=worktree/'compat/oracle.local.json'
assert not local.exists()
local.write_text(json.dumps(dict(format_version=1,emacs_binary=str(gnu/'src/emacs'),emacs_repo=str(gnu)),indent=2)+'\n')
assert json.loads((worktree/'compat/oracle.lock.json').read_text())['emacs_binary_sha256']==sha(gnu/'src/emacs')
overrides=dict(LANG='C',LC_ALL='C',CARGO_BUILD_JOBS='1',CARGO_NET_OFFLINE='true',
               RUST_TEST_THREADS='1',RUST_MIN_STACK='134217728',
               EMAXX_GNU_SOURCE_DIRECTORY=str(gnu),EMAXX_DUMP_SOURCE_DIRECTORY=str(gnu),EMACS_TEST_DIRECTORY=str(gnu/'test'))
env={**os.environ,**overrides}
state=dict(status='starting',commit=commit,source_inputs=source,environment_overrides=overrides,
           oracle={str(path):sha(path) for path in (gnu/'src/emacs',gnu/'src/emacs.pdmp')},results=[],goal_complete=False)
def save():(output/'state.json').write_text(json.dumps(state,indent=2)+'\n')
def run(name,command,timeout):
    verify()
    state.update(status='running '+name,current_command=command)
    save()
    start=time.monotonic()
    with (output/(name+'.log')).open('wb') as log:
        try:
            result=subprocess.run(command,cwd=worktree,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
            status=result.returncode
            timed_out=False
        except subprocess.TimeoutExpired:
            status=None
            timed_out=True
    row=dict(stage=name,command=command,exit_code=status,timed_out=timed_out,timeout_seconds=timeout,elapsed_seconds=time.monotonic()-start)
    state['results'].append(row)
    save()
    verify()
    print(json.dumps(row),flush=True)
    return status
save()
assert run('runner-build',['cargo','build','--locked','--offline','--profile','gate','--bin','compat-harness'],1800)==0
run('frozen',[str(worktree/'target/gate/compat-harness'),'frozen'],21600)
subject=worktree/'target/compat-subject/gate/emaxx'
state['subject']={str(path):dict(sha256=sha(path),bytes=path.stat().st_size) for path in (subject,subject.with_suffix('.pdmp')) if path.exists()}
for name,digest in state['oracle'].items():assert sha(Path(name))==digest
state['status']='terminal; inspect strict raw verdicts'
save()
print(state['status'],flush=True)
raise SystemExit(0 if all(row['exit_code']==0 for row in state['results']) else 1)
