from pathlib import Path
import collections
import hashlib
import json
import re
import subprocess

p = Path(__file__).resolve().parent
w = p.parent / 'recovered-2026-10-08/symbol-plists/emaxx'
r = w / 'target/compat/frozen-1791509521579363000-3070'
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
contract = read(r / 'contract.json')
assert read(r / 'head.json')['commit'] == '2712c05779e47ec9b8a7c89121d1a79fdcc42596'
assert len(contract['files']) == 519 and not (r / 'summary.json').exists()
inventory = {}
for line in (w / 'compat/oracle_tests_all.txt').read_text().splitlines():
    match = re.fullmatch(r'(\S+): discovered=(\d+) selected=(\d+)', line)
    if match:
        name = match[1]
        inventory[name] = dict(discovered=int(match[2]), selected=int(match[3]), names=[])
    elif line.strip():
        assert line.startswith('  ')
        inventory[name]['names'].append(line.strip())
assert list(inventory) == contract['files'] and sum(x['selected'] for x in inventory.values()) == 7921
assert sha(w / 'compat/oracle_tests_all.txt') == contract['manifest_sha256']
source = read(p / 'symbol-draft4/source.json')
for name, row in source.items():
    assert sha(w / name) == row['sha256'] and oct((w / name).stat().st_mode & 0o777) == row['mode'], name
assert len(source) == 560
counts = {runner: collections.Counter() for runner in ('oracle', 'emaxx')}
seen, failures, rows = {}, [], []
matched = different = successful = 0
for receipt_path in sorted(r.rglob('execution.json')):
    receipt = read(receipt_path)
    name = receipt['file']
    assert name not in seen and name in inventory
    directory = receipt_path.parent
    seen[name] = str(directory.relative_to(r))
    assert receipt['contract_sha256'] == sha(r / 'contract.json')
    assert set(receipt['sha256']) == {runner + suffix for runner in ('oracle', 'emaxx') for suffix in ('.json', '.log', '.execution.json')}
    assert all(sha(directory / n) == h for n, h in receipt['sha256'].items())
    row, pair = dict(file=name), {}
    for runner in counts:
        report = read(directory / (runner + '.json'))
        process = read(directory / (runner + '.execution.json'))['process']
        assert report['file'] == name and report['selector'] == contract['selector']
        result = report['results']
        observed = {status: sum(x['status'] == status for x in result) for status in ('passed', 'failed', 'skipped')}
        observed.update(total=len(result), unexpected=sum(not x['expected'] for x in result))
        assert observed == report['summary']
        counts[runner].update(observed)
        row[runner] = dict(summary=observed, exit_code=process['exit_code'], timed_out=process['timed_out'])
        pair[runner] = report
        if name == 'test/lisp/net/tramp-tests.el':
            assert process['timed_out'] and process['timeout_phase'] == 'Test' and process['test_started'] and process['exit_code'] is None
            assert process['test_elapsed']['secs'] == 180
            assert report['file_status'] == 'load_error' and result == []
            failures.append(dict(file=name, runner=runner, process=process, report=report))
        else:
            assert process['exit_code'] == 0 and process['test_started'] and not process['timed_out'] and process['timeout_phase'] is None
            assert report['file_status'] == 'loaded' and report['file_error'] is None
            expected = inventory[name]
            assert len(report['discovered_tests']) == expected['discovered']
            assert len(report['selected_tests']) == expected['selected'] and set(report['selected_tests']) == set(expected['names'])
            assert len(result) == len({x['name'] for x in result}) == expected['selected']
            assert {x['name'] for x in result} == set(expected['names']) and observed['unexpected'] == 0
            successful += 1
    comparison_path = directory / 'comparison.json'
    if name == 'test/lisp/net/tramp-tests.el':
        assert not comparison_path.exists()
    else:
        comparison = read(comparison_path)
        assert comparison['file'] == name and comparison['matches'] and not comparison['execution_issues'] and not comparison['issues']
        assert comparison['matching_outcomes'] == inventory[name]['selected'] and comparison['mismatching_outcomes'] == 0
        assert {x['name']: (x['status'], x['expected']) for x in pair['oracle']['results']} == {x['name']: (x['status'], x['expected']) for x in pair['emaxx']['results']}
        matched += comparison['matching_outcomes']
        different += comparison['mismatching_outcomes']
    rows.append(row)
assert set(seen) == set(contract['files'][:319])
assert len(failures) == 2 and successful == 636 and len(list(r.rglob('comparison.json'))) == 318
state = read(p / 'source314-macos-frozen/state.json')
assert state['results'][-1]['exit_code'] == 2 and not state['results'][-1]['timed_out']
retained = []
retain = p / 'source314-macos-frozen-failed-inputs'
retain.mkdir(exist_ok=True)
for original, digest in {contract['provenance']['subject_binary']: contract['provenance']['subject_sha256'], **contract['provenance']['runtime_images_sha256'], contract['provenance']['oracle_binary']: contract['provenance']['oracle_sha256']}.items():
    original = Path(original)
    assert sha(original) == digest
    destination = retain / original.name
    if not destination.exists():
        subprocess.run(['cp', '-c', str(original), str(destination)], check=True)
    assert sha(destination) == digest
    retained.append(dict(original=str(original), artifact=str(destination), sha256=digest, bytes=destination.stat().st_size))
result = dict(status='failed: both Tramp processes timed out; remaining frozen files unstarted', source_commit=contract['provenance']['subject_git_head'], raw_root=str(r), source_inputs_verified=len(source), scheduled_files=519, attempted_files=319, completed_comparisons=318, matching_outcomes=matched, mismatching_outcomes=different, successful_processes=successful, raw_counts={k: dict(v) for k, v in counts.items()}, failed_processes=failures, unstarted_files=contract['files'][319:], per_file=rows, retained_inputs=retained, raw_files={str(f.relative_to(r)): sha(f) for f in r.rglob('*') if f.is_file()}, supervisor_receipt=state['results'][-1], goal_complete=False, qualification='The unchanged 180-second test deadline stopped both editors. No Tramp answer or later test is counted. The supervisor saved the child exit before its HEAD assertion rejected documentation-only commits made while the run was active; all 560 actual source bytes and modes and both executable/images verify independently here. No successful wrapper completion is invented. A separate bounded longer Tramp comparison will retain its own deadline and cannot replace this failed run.')
destination = p / 'source314-macos-frozen-incomplete-audit.json'
assert not destination.exists()
destination.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ('status', 'attempted_files', 'completed_comparisons', 'matching_outcomes', 'successful_processes', 'raw_counts')}))
