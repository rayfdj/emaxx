from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).resolve().parent
w = p.parent / 'recovered-2026-10-08/symbol-plists/emaxx'
destination = w / 'docs/handover/2026-10-09-symbol-fields'
read = lambda path: json.loads(path.read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
failed = read(p / 'source314-macos-frozen-incomplete-audit.json')
longer = read(p / 'source314-tramp-longer-audit.json')
members = {}
excluded_tools = []
for label, result in [('frozen-incomplete', failed), ('tramp-longer', longer)]:
    root = Path(result['raw_root'])
    for name, digest in result['raw_files'].items():
        data = (root / name).read_bytes()
        assert sha(data) == digest
        if name.startswith('tools/'):
            excluded_tools.append(dict(path=str(root / name), bytes=len(data), sha256=digest))
            continue
        members['evidence/' + label + '/raw/' + name] = data
for name in ['source314-macos-frozen-incomplete-audit.json', 'source314-tramp-longer-audit.json',
             'source314-macos-frozen/state.json', 'source314-macos-frozen/frozen.log',
             'source314-macos-frozen/runner-build.log', 'source314-tramp-longer/state.json',
             'source314-tramp-longer/run.log', 'symbol-draft4/source.json',
             'audit_source314_macos_incomplete.py', 'audit_source314_tramp_longer.py',
             'macos_frozen.py', 'source314_tramp_longer.py', 'source314_macos_tail.py',
             'package_macos_progress.py']:
    members['evidence/' + name] = (p / name).read_bytes()
members['contents.json'] = (json.dumps({name: dict(bytes=len(data), sha256=sha(data)) for name, data in members.items()}, indent=2) + '\n').encode()
buffer = io.BytesIO()
with gzip.GzipFile(fileobj=buffer, mode='wb', mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode='w') as archive:
        for name, data in sorted(members.items()):
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o644
            info.mtime = 0
            archive.addfile(info, io.BytesIO(data))
data = buffer.getvalue()
archive_path = destination / 'source314-macos-frozen-incomplete-results.tar.gz'
assert not archive_path.exists()
archive_path.write_bytes(data)
with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
    assert set(archive.getnames()) == set(members)
    assert all(archive.extractfile(name).read() == content for name, content in members.items())
manifest = dict(checkpoint='source314', runtime_source_commit='2712c05779e47ec9b8a7c89121d1a79fdcc42596',
    archive=dict(path=archive_path.name, bytes=len(data), sha256=sha(data), members=len(members)),
    original=dict(status=failed['status'], completed_comparisons=318, matching_outcomes=4479, successful_processes=636, failed_processes=2, unstarted_files=200, source_inputs_verified=560, deadline_seconds=180),
    longer=dict(status=longer['status'], matching_outcomes=59, successful_processes=2, runner_summaries=longer['runner_summaries'], test_seconds=longer['test_seconds'], deadline_seconds=600, original_subject_sha256=longer['original_subject_sha256'], subject_sha256=longer['subject_sha256']),
    excluded_large_inputs=failed['retained_inputs'] + longer['retained_inputs'],
    excluded_prerequisite_tools=excluded_tools,
    remaining='The separate ordinary tail covers exactly the final 200 frozen files with the unchanged 180-second deadline. It is running and is not certified by this archive.',
    qualification='All raw partial and longer-run reports, process records, hashes, selectors and audit helpers are retained. Both original Tramp processes timed out without answers. The separately bounded run obtains all 59 actual matching outcomes. It uses the same runtime inputs and image but a rebuilt subject executable, identified separately. The failed frozen run is not relabeled successful; no complete frozen or performance acceptance is claimed. Large executable/images and prerequisite tools remain locally retained and are identified by hash.', goal_complete=False)
(destination / 'source314-macos-frozen-incomplete-results-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest['archive']))
