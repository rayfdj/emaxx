from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).resolve().parent
worktree = p.parents[2]
destination = worktree / 'docs/handover/2026-10-09-symbol-fields'
read = lambda path: json.loads(path.read_text())
rust = read(p / 'source321-linux-rust-audit.json')
frozen = read(p / 'source321-linux-frozen-complete-audit.json')
assert rust['status'] == 'passed' and frozen['status'] == 'matched'
members = {}
excluded = []
for label in ['source321-linux-rust', 'source321-linux-frozen']:
    for path in sorted((p / label / 'raw').rglob('*')):
        if not path.is_file():
            continue
        name = str(path.relative_to(p))
        data = path.read_bytes()
        if len(data) > 1_000_000 and (path.name in ['emacs', 'libtest'] or path.suffix == '.pdmp'):
            excluded.append(dict(path=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
        else:
            members['evidence/' + name] = data
    members['evidence/' + label + '/receipt.json'] = (p / label / 'receipt.json').read_bytes()
for name in ['source321-linux-rust-audit.json', 'source321-linux-frozen-complete-audit.json',
             'source321-linux-frozen-raw-integrity-audit.json', 'source321-linux-status.json',
             'source321-linux-dispatch.json', 'audit_source321_linux_rust.py',
             'audit_source321_linux_frozen.py', 'verify_complete_linux_frozen.py',
             'fetch_source321_artifacts.py', 'source321_ci.py', 'package_linux321.py',
             'image-draft10-final-owner/source.json']:
    members['evidence/' + name] = (p / name).read_bytes()
members['contents.json'] = (json.dumps({name: dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest()) for name, data in members.items()}, indent=2) + '\n').encode()
buffer = io.BytesIO()
with gzip.GzipFile(fileobj=buffer, mode='wb', mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode='w') as archive:
        for name, data in sorted(members.items()):
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o644
            info.mtime = 0
            archive.addfile(info, io.BytesIO(data))
payload = buffer.getvalue()
archive_path = destination / 'source321-linux-complete-results.tar.gz'
assert not archive_path.exists()
archive_path.write_bytes(payload)
with tarfile.open(fileobj=io.BytesIO(payload), mode='r:gz') as archive:
    assert set(archive.getnames()) == set(members)
    assert all(archive.extractfile(name).read() == data for name, data in members.items())
manifest = dict(checkpoint='source321', source_commit=rust['source_commit'],
                archive=dict(path=archive_path.name, bytes=len(payload), sha256=hashlib.sha256(payload).hexdigest()),
                members=len(members), rust=rust, frozen=frozen, excluded_binaries=excluded,
                qualification='All raw Linux inventories, verdicts, reports, process records and execution hashes are verified. Large executables/images remain in downloaded local artifacts and are identified by hash. Expected failures and skips are separate from passes. The macOS Rust run executed all 3074 library names and retains its startup-path fixture failure; Cargo stages never ran. The macOS frozen queue stopped before comparisons. These Linux results certify only published source321, not the newer startup fixture correction or the allocated-field prototype. The full goal remains open',
                goal_complete=False)
(destination / 'source321-linux-complete-results-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(dict(members=len(members), bytes=len(payload), sha256=manifest['archive']['sha256'])))
