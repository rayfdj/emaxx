import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path('/Users/nbmhqa186/projects/emaxx')
worktree = root / 'target/runtime-goal/recovered-2026-10-09/symbol-obarray/emaxx'
evidence = root / 'target/runtime-goal/symbol-obarray-2026-10-09'
gnu = root / 'target/runtime-goal/rebuilt-2026-10-01/emacs'
label = sys.argv[1]
destination = evidence / label
destination.mkdir(exist_ok=False)
overrides = dict(LANG='C', LC_ALL='C', CARGO_BUILD_JOBS='1', CARGO_NET_OFFLINE='true',
    RUST_TEST_THREADS='1', RUST_MIN_STACK='134217728', EMAXX_GC_VERIFY='1',
    EMAXX_IMAGE_TEMPLATE='1', EMAXX_GNU_SOURCE_DIRECTORY=str(gnu),
    EMAXX_DUMP_SOURCE_DIRECTORY=str(gnu), EMACS_TEST_DIRECTORY=str(gnu/'test'),
    EMAXX_FIXTURE_IMAGE_DIR=str(destination/'fixture-images'))
environment = {**os.environ, **overrides}
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
paths = set(json.loads((root/'target/runtime-goal/resume-2026-09-28/source313-manifest.json').read_text()))
paths.add('src/lisp/types/symbols.rs')
paths.update(str(path.relative_to(worktree)) for path in (worktree/'tests/fixtures').glob('symbol-*'))
def manifest():
    return {name: dict(sha256=sha(worktree/name), mode=oct((worktree/name).stat().st_mode & 0o777)) for name in sorted(paths)}
frozen = manifest()
(destination/'source.json').write_text(json.dumps(frozen, indent=2)+'\n')
(destination/'environment.json').write_text(json.dumps(overrides, indent=2)+'\n')
(destination/'tracked.patch').write_bytes(subprocess.check_output(['git','diff','--binary'], cwd=worktree))
def run(name, command):
    started = time.monotonic()
    print('START', name, flush=True)
    with (destination/(name+'.stdout')).open('wb') as out, (destination/(name+'.stderr')).open('wb') as err:
        status = subprocess.run(command, cwd=worktree, env=environment, stdout=out, stderr=err).returncode
    receipt = dict(command=command, cwd=str(worktree), exit_code=status,
        elapsed_seconds=time.monotonic()-started,
        stdout_sha256=sha(destination/(name+'.stdout')),
        stderr_sha256=sha(destination/(name+'.stderr')))
    (destination/(name+'.json')).write_text(json.dumps(receipt, indent=2)+'\n')
    assert manifest() == frozen, 'source changed during validation'
    print('END', name, status, round(receipt['elapsed_seconds'],2), flush=True)
    if status:
        print((destination/(name+'.stderr')).read_text()[-6000:], flush=True)
        print((destination/(name+'.stdout')).read_text()[-6000:], flush=True)
        raise SystemExit(status)
    return destination/(name+'.stdout')

if 'strict' in sys.argv:
    for name, command in [
        ('fmt', ['cargo','fmt','--all','--','--check']),
        ('check', ['cargo','check','--locked','--offline','--all-targets','--all-features']),
        ('clippy', ['cargo','clippy','--locked','--offline','--all-targets','--all-features','--','-D','warnings']),
        ('diff', ['git','diff','--check'])]:
        run(name, command)
if 'focus' in sys.argv:
    profile = 'release' if 'release' in sys.argv else 'gate'
    build = run('build', ['cargo','test','--locked','--offline','--profile',profile,'--all-features','--lib','--no-run','--message-format=json'])
    artifacts = [j for line in build.read_text().splitlines() if line.startswith('{')
        and (j:=json.loads(line)).get('reason') == 'compiler-artifact'
        and j.get('executable') and 'lib' in j['target']['kind'] and j['profile']['test']]
    assert len(artifacts) == 1, artifacts
    binary = Path(artifacts[0]['executable'])
    subprocess.run(['cp','-c',str(binary),str(destination/'libtest')], check=True)
    assert sha(binary) == sha(destination/'libtest')
    (destination/'binary.json').write_text(json.dumps(dict(original=str(binary), retained=str(destination/'libtest'), sha256=sha(binary)), indent=2)+'\n')
    listing = run('inventory', [str(binary),'--list'])
    inventory = sorted(line[:-6] for line in listing.read_text().splitlines() if line.endswith(': test'))
    previous = json.loads((root/'target/runtime-goal/symbol-payload-api-2026-10-09/payload-draft1-gate/selection.json').read_text())
    previous += [name for name in inventory if name.startswith(('lisp::eval::symbol_cells::tests::', 'lisp::primitives::pdumper::tests::', 'lisp::types::tests::', 'lisp::types::symbols::tests::', 'lisp::alloc::verifier_tests::', 'lisp::alloc::vectors::tests::')) or 'hash_table' in name or 'hashtable' in name or (name.startswith('lisp::native_comp::') and 'symbol' in name) or any(part in name for part in ['alias', 'void_default', 'unbound', 'obarray', 'variable_watcher', 'plain_global', 'deep_clone', 'image_', 'function_cell', 'specbind', 'setq', 'watcher', 'special_binding'])]
    selected = sorted(set(previous + [
        'lisp::primitives::tests::symbol_fields_participate_in_weak_fixed_points_and_finalizer_liveness',
        'lisp::primitives::tests::symbol_plist_put_preserves_shared_cells_and_gnu_error_data',
        'lisp::primitives::tests::symbol_alias_fields_follow_the_actual_load_history_root',
        'lisp::primitives::tests::defvaralias_records_the_alias_in_load_history',
        'lisp::primitives::tests::defvaralias_follows_eval_c',
        'lisp::primitives::tests::load_history_lists_a_repeated_definition_twice_as_gnu_does',
        'lisp::eval::tests::eval_01::c_mode_matches_gnu_comment_and_modeline_defaults',
        'lisp::eval::tests::eval_01::load_runs_real_gnu_after_load_forms_after_unbinding_file_context']))
    if 'probe' in sys.argv:
        selected = ['lisp::eval::tests::eval_02::image_clone_symbols_own_names_and_preserve_their_cycles']
    if 'graphprobe' in sys.argv:
        selected = ['lisp::eval::tests::eval_02::image_clone_symbol_graph_preserves_private_keys_and_bindings']
    assert set(selected) <= set(inventory)
    (destination/'selection.json').write_text(json.dumps(selected, indent=2)+'\n')
    log = run('focused', [str(binary),'--exact','--test-threads=1',*selected])
    expected = f'test result: ok. {len(selected)} passed; 0 failed; 0 ignored;'
    assert expected in log.read_text(), 'incomplete focused inventory'
    print('PASS', profile, len(selected), 'focused;', len(inventory), 'inventory', flush=True)
if 'full' in sys.argv:
    run('full', ['python3','tools/serial_grouped_gate.py','--scope','full','--artifact-root',str(destination/'full')])
(destination/'source-after.json').write_text(json.dumps(manifest(), indent=2)+'\n')
