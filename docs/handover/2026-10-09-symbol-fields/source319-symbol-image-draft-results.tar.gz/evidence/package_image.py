from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).resolve().parent
destination = p.parents[2] / "docs/handover/2026-10-09-symbol-fields"
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_text())
audit = read(p / "image-draft6-audit.json")
assert audit["profiles"]["gate"]["passed"] == audit["profiles"]["release"]["passed"] == 232
members, excluded = {}, []
for label in ["image-draft1-negative", "image-draft2-copy", "image-draft3-hook-keys",
              "image-draft3-selected-gate", "image-draft4-graph-negative", "image-draft5-graph-negative",
              "image-draft6-relocation", "image-draft6-release"]:
    for path in sorted((p / label).rglob("*")):
        if not path.is_file():
            continue
        if path.name == "libtest" or path.suffix == ".pdmp":
            digest = hashlib.sha256()
            with path.open("rb") as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b""):
                    digest.update(block)
            excluded.append(dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest()))
        else:
            members["evidence/" + str(path.relative_to(p))] = path.read_bytes()
for name in ["audit_image.py", "package_image.py", "validate_image.py", "image-draft6-audit.json",
             "image-draft6.patch", "symbol-image-graph-setup.el", "symbol-image-graph-check.el",
             "image-graph-gnu.json", "image-graph-gnu.stdout", "image-graph-gnu.stderr",
             "ordinary_image.py", "continue_image.py", "image-draft6-continuation-state.json",
             "image-draft6-release-supervisor.log", "image-draft6-ordinary-supervisor.log",
             "ordinary_image2.py", "continue_image2.py"]:
    members["evidence/" + name] = (p / name).read_bytes()
members["contents.json"] = (json.dumps({name:dict(bytes=len(data), sha256=sha(data)) for name,data in members.items()}, indent=2) + "\n").encode()
buffer = io.BytesIO()
with gzip.GzipFile(fileobj=buffer, mode="wb", mtime=0) as zipped:
    with tarfile.open(fileobj=zipped, mode="w") as archive:
        for name, data in sorted(members.items()):
            entry = tarfile.TarInfo(name)
            entry.size, entry.mode = len(data), 0o644
            archive.addfile(entry, io.BytesIO(data))
data = buffer.getvalue()
path = destination / "source319-symbol-image-draft-results.tar.gz"
assert not path.exists()
path.write_bytes(data)
with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as archive:
    assert set(archive.getnames()) == set(members)
    assert all(archive.extractfile(name).read() == payload for name,payload in members.items())
manifest = dict(checkpoint="source319 unapplied owner/image draft6", archive=dict(path=path.name, bytes=len(data), sha256=sha(data), members=len(members)),
    selected_audit=audit, excluded_large_inputs=excluded,
    wrapper_failure="The first ordinary wrapper referenced draft5's old source manifest; its preflight correctly rejected src/buffer.rs before building or executing any comparison. The original script, traceback and terminal coordinator state are retained. The corrected wrapper names the exact validated draft6 source manifest and is separate.",
    qualification="Portable unfinished draft and completed strict/selected evidence only: 232 controls per profile, every previous inventory name retained, and one exact patch replayed from checkpoint93b and main265d. Original runtime, compilation and setup failures remain preserved. The corrected ordinary comparisons and subsequent full macOS Rust gate are separate and were not complete when this package was created. Source318 production and terminal evidence remain separate. The full architecture/accounting/performance goal is incomplete.",
    goal_complete=False)
(destination / "source319-symbol-image-draft-results-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps(manifest["archive"]))
