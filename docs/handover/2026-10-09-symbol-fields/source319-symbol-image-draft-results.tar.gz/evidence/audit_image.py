from pathlib import Path
import hashlib
import io
import json
import re
import subprocess
import tarfile
import tempfile

p = Path(__file__).resolve().parent
w = p.parent / "recovered-2026-10-09/symbol-obarray/emaxx"
repository = p.parents[2]
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
gate = p / "image-draft6-relocation"
source = read(gate / "source.json")
assert len(source) == 565
for name, row in source.items():
    assert sha(w / name) == row["sha256"], name
    assert oct((w / name).stat().st_mode & 0o777) == row["mode"], name


def stage(directory, name, status=0, compiler=False):
    receipt = read(directory / (name + ".json"))
    assert receipt["exit_code"] == status, (directory, name)
    for stream in ["stdout", "stderr"]:
        path = directory / (name + "." + stream)
        assert sha(path) == receipt[stream + "_sha256"], path
        if compiler:
            assert not re.search(r"^warning(?:\[.*?\])?:", path.read_text(), re.M), path
    return receipt


for name in ["fmt", "check", "clippy", "diff"]:
    stage(gate, name, compiler=True)
new_tests = {
    "lisp::eval::tests::eval_02::image_clone_symbols_own_names_and_preserve_their_cycles",
    "lisp::eval::tests::eval_02::image_clone_symbol_graph_preserves_private_keys_and_bindings",
}
profiles = {}
for profile, label, old in [
    ("gate", "image-draft6-relocation", "obarray-draft5-key-contract"),
    ("release", "image-draft6-release", "obarray-draft5-release"),
]:
    directory, previous = p / label, p / old
    assert read(directory / "source.json") == read(directory / "source-after.json") == source
    selection = read(directory / "selection.json")
    assert len(selection) == 232 and set(selection) == set(read(previous / "selection.json")) | new_tests
    inventory = lambda path: [line[:-6] for line in path.read_text().splitlines() if line.endswith(": test")]
    names, old_names = inventory(directory / "inventory.stdout"), inventory(previous / "inventory.stdout")
    assert len(names) == len(set(names)) == len(old_names) + 2
    assert set(names) == set(old_names) | new_tests
    for name in ["build", "inventory", "focused"]:
        stage(directory, name, compiler=name == "build")
    verdicts = re.findall(r"^test (\S+) \.\.\. (ok|FAILED|ignored)\s*$", (directory / "focused.stdout").read_text(), re.M)
    assert len(verdicts) == 232 and dict(verdicts) == dict.fromkeys(selection, "ok")
    binary = read(directory / "binary.json")
    assert sha(Path(binary["retained"])) == binary["sha256"]
    profiles[profile] = dict(passed=232, failed=0, ignored=0, inventory=len(names), executable=binary)

negative_results = []
for label, name, status, detail in [
    ("image-draft1-negative", "focused", 101, "Original and cloned canonical symbols have the same object word; the new isolation assertion fails."),
    ("image-draft2-copy", "check", 101, "The first copy draft cannot mutate String map keys through iter_mut; Rust rejects it before runtime tests."),
    ("image-draft3-selected-gate", "focused", 101, "229 passes and two failures: one fixture inspects the wrong selected owner, and one expects cross-editor symbol identity."),
    ("image-draft4-graph-negative", "focused", 101, "The full batch setup has live native relocation state; the existing clone guard correctly rejects it."),
    ("image-draft5-graph-negative", "focused", 101, "A valid early-Lisp template reaches the graph check: private name/string/buffer property keys and custom identity hashes fail."),
]:
    directory = p / label
    receipt = stage(directory, name, status)
    negative_results.append(dict(directory=label, stage=name, exit_code=status, detail=detail,
                                 source_sha256=sha(directory / "source.json"), receipt_sha256=sha(directory / (name + ".json")),
                                 stdout_sha256=receipt["stdout_sha256"], stderr_sha256=receipt["stderr_sha256"]))
raw = (p / "image-draft5-graph-negative/focused.stdout").read_text()
left = next(line for line in raw.splitlines() if line.startswith("  left: "))
predicates = re.findall(r"car: Cell \{ value: (T|Nil) \}", left)
assert len(predicates) == 17
assert [i + 1 for i, value in enumerate(predicates) if value == "Nil"] == [5, 6, 9, 16]
oracle = read(p / "image-graph-gnu.json")
assert oracle["exit_code"] == 0
assert (p / "image-graph-gnu.stdout").read_text() == "(" + " ".join(["t"] * 17) + ")"
for name, digest in oracle["artifacts"].items():
    assert sha(Path(name)) == digest, name
for name in ["symbol-image-graph-setup.el", "symbol-image-graph-check.el"]:
    assert (p / name).read_bytes() == (w / "tests/fixtures" / name).read_bytes()

patch = p / "image-draft6.patch"
data = subprocess.check_output(["git", "diff", "--binary", "93b6546f9c54aaecf2237cc751e3f94591066969", "--", "src", "tests"], cwd=w)
if patch.exists():
    assert patch.read_bytes() == data
else:
    patch.write_bytes(data)
replays = []
for revision in ["93b6546f9c54aaecf2237cc751e3f94591066969", "265d5ba3405cebe7692560cc29722be65d62237b"]:
    available = subprocess.check_output(["git", "ls-tree", "-r", "--name-only", revision], cwd=repository, text=True).splitlines()
    raw = subprocess.check_output(["git", "archive", revision, "--", *[name for name in source if name in available]], cwd=repository)
    with tempfile.TemporaryDirectory(prefix="emaxx-image-symbol-replay-") as temporary:
        replay = Path(temporary)
        with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
            for entry in archive.getmembers():
                if entry.isfile():
                    target = replay / entry.name
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(archive.extractfile(entry).read())
                    target.chmod(0o755 if entry.mode & 0o111 else 0o644)
        subprocess.run(["git", "apply", str(patch)], cwd=replay, check=True)
        for name, row in source.items():
            assert sha(replay / name) == row["sha256"], name
            assert oct((replay / name).stat().st_mode & 0o777) == row["mode"], name
    replays.append(dict(base=revision, source_inputs_verified=len(source)))

gnu = p.parent / "rebuilt-2026-10-01/emacs"
result = dict(checkpoint="source319 unapplied symbol ownership and image-copy draft6",
    status="passed strict and selected gate/release validation", source_inputs_verified=len(source),
    strict="zero warnings", profiles=profiles, previous_controls_retained=230, new_controls=sorted(new_tests),
    patch=dict(path=patch.name, sha256=sha(patch), replays=replays),
    preserved_failures=negative_results, gnu_predicates=17, original_failed_predicates=[5, 6, 9, 16],
    gnu_reference={name:sha(gnu/name) for name in ["src/lisp.h", "src/lread.c", "src/fns.c", "src/pdumper.c"]},
    qualification="The private image copier relocates symbol objects and name cycles, symbol-field keys, aliases, local bindings, watchers, private property keys and hash descriptors. Hashes are recomputed after relocation; a private custom table invokes its real hash callback. The production dumper still rejects custom hash tests as GNU does. The positioned-symbol control now checks independent canonical symbols while retaining all sharing and native field-mutation checks. The plist fixture selects its source owner before host inspection. Every old test name remains. Ordinary comparisons, full platform gates and broader native contracts are separate. Private constructor ownership, direct allocated fields, enumeration/ID/GC adapters, descriptor reclamation, physical accounting and performance acceptance remain unfinished.",
    goal_complete=False)
(p / "image-draft6-audit.json").open("x").write(json.dumps(result, indent=2) + "\n")
print(json.dumps({key: result[key] for key in ["status", "source_inputs_verified", "profiles", "patch"]}, indent=2))
