from pathlib import Path
import datetime
import hashlib
import json
import os
import runpy
import subprocess
import sys
import time

p = Path(__file__).resolve().parent
w = p.parents[2]
g = p.parent / "rebuilt-2026-10-01/emacs"
out = p / "source324-terminal"
out.mkdir(exist_ok=False)
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
source = read(p / "source324-source.json")
state = dict(status="prepared for the completed macOS frozen subject", pid=os.getpid(),
             started=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             goal_complete=False)


def save():
    (out / "state.json").write_text(json.dumps(state, indent=2) + "\n")


def verify_source():
    assert len(source) == 572
    for name, row in source.items():
        assert sha(w / name) == row["sha256"], name
        assert oct((w / name).stat().st_mode & 0o777) == row["mode"], name


save()
try:
    verify_source()
    frozen = read(p / "source324-macos-frozen/state.json")
    assert frozen["status"] == "terminal; inspect strict raw verdicts"
    assert frozen["source_unchanged"] and frozen["source_inputs"] == source
    assert len(frozen["results"]) == 2 and frozen["results"][1]["stage"] == "frozen"
    destination = w / "target/compat-subject/tty-source324"
    destination.mkdir(exist_ok=False)
    inputs = {}
    retained = frozen["retained_inputs"]
    for name in ["emaxx", "emaxx.pdmp"]:
        row = next(row for row in retained if Path(row["original"]).name == name)
        original = Path(row["retained"])
        digest = row["sha256"]
        assert sha(original) == digest
        target = destination / name
        subprocess.run(["cp", "-c", str(original), str(target)], check=True)
        assert sha(target) == digest
        inputs[str(target)] = digest
    for path in [g / "src/emacs", g / "src/emacs.pdmp", g / "src/config.h",
                 g / "src/Makefile", w / "tools/ttydiff.py",
                 w / "tools/fixtures/fieldnotes.org", w / "tools/fixtures/fake_lsp_server.py",
                 p / "observe_terminal.py", Path(__file__)]:
        inputs[str(path)] = sha(path)
    for name in ["emacs", "emacs.pdmp"]:
        row = next(row for row in retained if Path(row["original"]).name == name)
        assert inputs[str(g / "src" / name)] == row["sha256"]
    inventory = runpy.run_path(str(w / "tools/ttydiff.py"), run_name="inventory_only")
    names = [entry[0] for entry in inventory["select_scenarios"]([])]
    previous = read(p.parent / "resume-2026-09-28/source312-full-tty-command.json")
    assert names == previous["inventory"] and len(names) == 226
    command = ["/usr/bin/caffeinate", "-i", sys.executable, "-u",
               str(p / "observe_terminal.py"), str(out / "screens.jsonl"),
               str(destination / "emaxx"), str(g / "src/emacs"), str(g / "lisp")]
    environment = dict(EMAXX_TTYDIFF_REQUIRE="1", LANG="C", LC_ALL="C")
    record = dict(command=command, working_directory=str(w),
                  environment_override=environment, source_inputs=source, inputs=inputs,
                  inventory=names, runtime_commit="999362622a68d6508c356541422f7a48ae6e2175",
                  qualification="All 226 ordinary scenarios, original actions, deadlines and comparisons. The observer records full screens and returns the unchanged harness verdict. Same-depth retained copies preserve relative native paths. No retry or deadline extension.")
    (out / "command.json").write_text(json.dumps(record, indent=2) + "\n")
    state.update(status="running all 226 ordinary terminal scenarios")
    save()
    print(state["status"], flush=True)
    start = time.monotonic()
    with (out / "run.log").open("xb") as log:
        result = subprocess.run(command, cwd=w, env={**os.environ, **environment},
                                stdin=subprocess.DEVNULL, stdout=log,
                                stderr=subprocess.STDOUT, timeout=21600)
    verify_source()
    assert all(sha(Path(name)) == digest for name, digest in inputs.items())
    state.update(status="terminal; inspect raw evidence", exit_code=result.returncode,
                 elapsed_seconds=time.monotonic() - start, source_unchanged=True,
                 inputs_unchanged=True, log_sha256=sha(out / "run.log"),
                 screens_sha256=sha(out / "screens.jsonl"))
    save()
    print(json.dumps(state), flush=True)
except BaseException as error:
    state.update(status="failed; preserve raw evidence", error=str(error))
    save()
    raise

raise SystemExit(state["exit_code"])
