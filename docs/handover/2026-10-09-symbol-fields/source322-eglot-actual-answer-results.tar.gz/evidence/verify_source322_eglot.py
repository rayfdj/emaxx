from pathlib import Path
import hashlib, json, re

p = Path(__file__).resolve().parent
r = p.parents[2]
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
raw = p / 'source322-eglot-observation/raw'
directory, = raw.glob('compat/run-*')
file = 'test/lisp/progmodes/eglot-tests.el'
d = (directory / file).with_suffix('.compat')
summary = read(directory / 'summary.json')
lock = read(r / 'compat/oracle.lock.linux.json')
lines = (r / 'compat/oracle_tests_all_linux.txt').read_text().splitlines()
index = next(i for i,line in enumerate(lines) if line.startswith(file + ':'))
discovered, selected = map(int, re.fullmatch(re.escape(file) + r': discovered=(\d+) selected=(\d+)', lines[index]).groups())
names = lines[index+1:index+1+selected]
assert all(line.startswith('  ') for line in names)
names = {line.strip() for line in names}
assert len(names) == selected == 52
assert summary['files'] == [file] and summary['name_filter'] is None
assert summary['total_outcomes'] == summary['matching_outcomes'] == 52
assert summary['mismatching_outcomes'] == 0 and not summary['unsuccessful_files']
assert summary['selector'] == lock['selector_default']
assert summary['provenance']['oracle_sha256'] == lock['emacs_binary_sha256']
assert summary['provenance']['subject_git_head'] == 'f526af1c9e070c3eda68dd9736067f8cfbf35ea0'
assert not summary['provenance']['subject_git_dirty']
comparison = read(d / 'comparison.json')
assert comparison['matches'] and not comparison['issues'] and not comparison['execution_issues']
execution = read(d / 'execution.json')
assert execution['contract_sha256'] == sha(directory / 'contract.json')
for name,digest in execution['sha256'].items():
    assert sha(d / name) == digest
outcomes = []
for runner in ['oracle', 'emaxx']:
    report = read(d / (runner + '.json'))
    assert len(report['discovered_tests']) == discovered
    assert set(report['selected_tests']) == names
    assert len(report['results']) == selected
    assert {row['name'] for row in report['results']} == names
    assert report['summary'] == dict(total=52, passed=45, failed=0, skipped=7, unexpected=0)
    assert all(row['expected'] for row in report['results'])
    outcome = {row['name']:(row['status'],row['expected']) for row in report['results']}
    assert outcome['eglot-test-rust-completion-exit-function'] == ('passed', True)
    outcomes.append(outcome)
    process = read(d / (runner + '.execution.json'))['process']
    assert process['exit_code'] == 0 and not process['timed_out'] and process['test_started']
assert outcomes[0] == outcomes[1]
audit = read(p / 'source322-eglot-observation-audit.json')
assert audit['raw_files'] == {str(path.relative_to(raw)):sha(path) for path in raw.rglob('*') if path.is_file()}
print('Verified 52 matching outcomes, including the actual GNU Rust-completion answer; original full run stays failed.')
