from pathlib import Path
import datetime,json
p=Path(__file__).resolve().parent
ns={}
exec((p/'source322_ci.py').read_text().split('operation=sys.argv[1]')[0],ns)
request=ns['request'];commit=ns['commit']
_,ref=request('git/ref/heads/runtime-char-tables')
assert ref['object']['sha']==commit
receipt=p/'source322-eglot-observation-dispatch.json'
assert not receipt.exists()
body=dict(ref='runtime-char-tables',inputs=dict(validation='affected',file='test/lisp/progmodes/eglot-tests.el'))
record=dict(source_commit=commit,body=body,started=datetime.datetime.now(datetime.timezone.utc).isoformat(),qualification='Separate execution of the unchanged Eglot file to obtain the actual GNU answer. The original full frozen run remains failed after its GNU-only JSON-RPC timeout; no test or runtime timeout is changed.',goal_complete=False)
receipt.write_text(json.dumps(record,indent=2)+'\n')
status,_=request('actions/workflows/frozen-run.yml/dispatches','POST',body)
record['http_status']=status
receipt.write_text(json.dumps(record,indent=2)+'\n')
print(status,commit,body['inputs'])
