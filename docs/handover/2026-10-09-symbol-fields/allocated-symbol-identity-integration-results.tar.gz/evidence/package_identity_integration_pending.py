from pathlib import Path
import json

p = Path(__file__).resolve().parent
f = p.parent / 'allocated-symbols-2026-10-10'
ns = {'__file__': str(p / 'package_source323_base.py')}
exec((p / 'package_source323_base.py').read_text(), ns)
destination = p / 'pending-publication-2026-10-13'
destination.mkdir(exist_ok=True)
ns['destination'] = destination
read = lambda path: json.loads(path.read_text())
audit = read(f / 'fields-identity-integration-audit.json')
assert audit['strict_zero_warnings'] and audit['integration_passed'] == 39 and audit['replayed']
entries = lambda root, names: [('evidence/' + name, root / name) for name in names]
ns['package']('allocated-symbol-identity-integration-results',
              entries(f, ['fields-identity-integration', 'fields-identity-integration-gate']),
              entries(f, ['fields-identity-integration-audit.json', 'integrate_identity5.py',
                          'validate_identity_integration.py', 'audit_identity_integration.py',
                          'fields-identity-draft5-full-audit.json', 'fields-identity-draft5-release-audit.json',
                          'fields-identity-draft5-selected-audit.json', 'fields-identity-draft5-ordinary-audit.json'])
              + entries(p, [Path(__file__).name, 'package_source323_base.py']),
              dict(checkpoint='isolated symbol identity integration onto source323; not published as runtime',
                   audit=audit,
                   qualification='The572-input delta replays from0550a70c and retains its configured-GNU native artifact fixture. Every production byte/mode matches identity5 full local validation. The only different input is that fixture; fresh strict checks have zero warnings and all39 original integration tests pass, including exact native artifacts. Original prototype and root checkouts remain unchanged. This portable patch is still unapplied to the published runtime. It needs clean-source publication/platform validation; remaining representation adapters, ownership, physical accounting, profiles and the full performance goal remain open. Large retained executable/image bytes are explicitly excluded from this archive.'))
