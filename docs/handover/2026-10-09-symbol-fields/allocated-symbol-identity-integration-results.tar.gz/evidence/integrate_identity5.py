from pathlib import Path
import hashlib
import json
import subprocess

p = Path(__file__).resolve().parent
r = p.parents[2]
u = p.parent / 'recovered-2026-10-12/symbol-identity/emaxx'
v = p.parent / 'recovered-2026-10-13/symbol-fields-integration/emaxx'
out = p / 'fields-identity-integration'
out.mkdir(exist_ok=False)
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
source = read(p / 'fields-identity-draft5-gate/source.json')
assert len(source) == 572
assert read(p / 'fields-identity-draft5-full-audit.json')['status'] == 'passed'
assert read(p / 'fields-identity-draft5-full-audit.json')['total_passed'] == 3178
assert read(p / 'fields-identity-draft5-ordinary-audit.json')['comparisons'] == 28
assert read(p / 'fields-identity-draft5-release-audit.json')['selected'] == 397
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=v, text=True).strip() == '0550a70c8d8b48ae0369e235e570dc484bea6a44'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=v)
for name, row in source.items():
    assert sha(u / name) == row['sha256']
    assert oct((u / name).stat().st_mode & 0o777) == row['mode']
native = 'tests/native_comp_identity.rs'
configured = read(r / 'target/runtime-goal/symbol-obarray-2026-10-09/source323-native-gate/source.json')[native]
assert sha(v / native) == configured['sha256']
before, changed, added = {}, [], []
for name, row in source.items():
    path = v / name
    if path.exists():
        before[name] = dict(sha256=sha(path), mode=oct(path.stat().st_mode & 0o777))
    if name == native:
        continue
    if before.get(name) != row:
        if not path.exists():
            added.append(name)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes((u / name).read_bytes())
        path.chmod(int(row['mode'], 8))
        changed.append(name)
subprocess.run(['git', 'add', '-N', '--', *added], cwd=v, check=True)
after = {name:dict(sha256=sha(v / name), mode=oct((v / name).stat().st_mode & 0o777)) for name in source}
assert [name for name in source if source[name] != after[name]] == [native]
assert after[native] == configured
assert all(row == after[name] for name, row in source.items() if name.startswith('src/'))
gnu = p.parent / 'rebuilt-2026-10-01/emacs'
(v.parent / 'emacs').symlink_to(gnu, target_is_directory=True)
(v / 'compat/oracle.local.json').write_bytes((r / 'compat/oracle.local.json').read_bytes())
patch = subprocess.check_output(['git', 'diff', '--binary'], cwd=v)
(out / 'integrated.patch').write_bytes(patch)
(out / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
(out / 'source.json').write_text(json.dumps(after, indent=2) + '\n')
result = dict(status='integrated in isolated checkout; not yet validated or published',
              checkout=str(v), base_commit='0550a70c8d8b48ae0369e235e570dc484bea6a44',
              prototype_patch_sha256=sha(p / 'fields-identity-draft5.patch'),
              integrated_patch_sha256=sha(out / 'integrated.patch'), source_inputs=572,
              copied_paths=changed, added_paths=added,
              differences_from_validated_prototype=[native],
              qualification='Every production source byte/mode is identical to locally validated identity draft5. The only different validation input is source323 native identity fixture selecting the configured GNU root. Original assertions and all prior runtime fixes are retained. Root and original prototype checkouts are unchanged. This isolated integration still needs its own strict checks and native integration validation before publication.',
              goal_complete=False)
(out / 'application.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key:result[key] for key in ['status', 'source_inputs', 'differences_from_validated_prototype', 'integrated_patch_sha256']}))
