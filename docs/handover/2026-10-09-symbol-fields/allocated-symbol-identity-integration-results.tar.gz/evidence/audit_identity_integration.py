from pathlib import Path
import hashlib
import io
import json
import re
import subprocess
import tarfile
import tempfile

p = Path(__file__).resolve().parent
r = p.parents[2]
v = p.parent / 'recovered-2026-10-13/symbol-fields-integration/emaxx'
d = p / 'fields-identity-integration-gate'
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
source = read(d / 'source.json')
assert len(source) == 572
assert source == read(d / 'source-after.json') == read(p / 'fields-identity-integration/source.json')
prototype = read(p / 'fields-identity-draft5-gate/source.json')
assert [name for name in source if source[name] != prototype[name]] == ['tests/native_comp_identity.rs']
assert source['tests/native_comp_identity.rs'] == read(r / 'target/runtime-goal/symbol-obarray-2026-10-09/source323-native-gate/source.json')['tests/native_comp_identity.rs']
for name, row in source.items():
    assert sha(v / name) == row['sha256']
    assert oct((v / name).stat().st_mode & 0o777) == row['mode']
for name in ['fmt', 'check', 'clippy', 'diff', 'integration']:
    receipt = read(d / (name + '.json'))
    assert receipt['exit_code'] == 0
    for stream in ['stdout', 'stderr']:
        path = d / (name + '.' + stream)
        assert sha(path) == receipt[stream + '_sha256']
        assert not re.search(r'^warning(?:\[.*?\])?:', path.read_text(errors='replace'), re.M)
text = (d / 'integration.stdout').read_text()
summaries = re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', text)
assert summaries == [('ok', str(count), '0', '0', '0', '0') for count in [20, 6, 3, 1, 1, 5, 3]]
names = re.findall(r'^test (\S+) \.\.\. ', text, re.M)
assert len(names) == len(set(names)) == 39
prior = (r / 'target/runtime-goal/symbol-obarray-2026-10-09/source323-native-gate/integration.stdout').read_text()
assert names == re.findall(r'^test (\S+) \.\.\. ', prior, re.M)
assert 'test unchanged_gnu_sources_produce_identical_native_artifacts ...' in text
patch = p / 'fields-identity-integration/integrated.patch'
assert patch.read_bytes() == (d / 'tracked.patch').read_bytes()
base = '0550a70c8d8b48ae0369e235e570dc484bea6a44'
available = set(subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', base], cwd=r, text=True).splitlines())
data = subprocess.check_output(['git', 'archive', base, '--', *[name for name in source if name in available]], cwd=r)
with tempfile.TemporaryDirectory(prefix='emaxx-identity-integration-replay-') as tmp:
    directory = Path(tmp)
    with tarfile.open(fileobj=io.BytesIO(data)) as archive:
        for item in archive.getmembers():
            if item.isfile():
                path = directory / item.name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(archive.extractfile(item).read())
                path.chmod(0o755 if item.mode & 0o111 else 0o644)
    subprocess.run(['git', 'apply', str(patch)], cwd=directory, check=True)
    for name, row in source.items():
        assert sha(directory / name) == row['sha256']
        assert oct((directory / name).stat().st_mode & 0o777) == row['mode']
retained = d / 'retained-inputs'
retained.mkdir(exist_ok=False)
binaries = re.findall(r'Running tests/[^\s]+\.rs \((target/gate/deps/[^)]+)\)', (d / 'integration.stderr').read_text())
assert len(binaries) == len(set(binaries)) == 7
paths = [v / name for name in binaries]
paths += [path for path in [v / 'target/gate/emaxx', v / 'target/gate/emaxx.pdmp'] if path.exists()]
paths += sorted(Path(read(d / 'environment.json')['EMAXX_FIXTURE_IMAGE_DIR']).glob('*.pdmp'))
gnu = p.parent / 'rebuilt-2026-10-01/emacs'
paths += [gnu / 'src/emacs', gnu / 'src/emacs.pdmp']
files = []
for index, path in enumerate(paths):
    digest = sha(path)
    target = retained / (str(index) + '-' + path.name)
    subprocess.run(['cp', '-c', str(path), str(target)], check=True)
    assert sha(target) == digest == sha(path)
    files.append(dict(original=str(path), retained=str(target), sha256=digest, bytes=target.stat().st_size))
result = dict(status='passed; isolated integration not yet published', base_commit=base,
              source_inputs_verified=572, integrated_patch_sha256=sha(patch), replayed=True,
              strict_zero_warnings=True, integration_passed=39, original_integration_names_preserved=names,
              production_identical_to_validated_identity5=True,
              different_validation_inputs=['tests/native_comp_identity.rs'], retained_inputs=files,
              prototype_full_audit_sha256=sha(p / 'fields-identity-draft5-full-audit.json'),
              qualification='All572 integrated inputs replay from source323. Production bytes/modes are exactly the locally validated identity5 prototype; the only input difference preserves source323 configured-GNU native fixture correction. Strict checks have zero warnings and all39 original integration tests pass, including exact native artifact identity. Executables and post-run images are retained without per-test image-use claims. This is still an unpublished local integration; required clean-source Linux/macOS/frozen/terminal and performance evidence remains separate.', goal_complete=False)
with (p / 'fields-identity-integration-audit.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({key:result[key] for key in ['status', 'source_inputs_verified', 'replayed', 'integration_passed', 'integrated_patch_sha256']}))
