from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).resolve().parent
w = p.parent / 'recovered-2026-10-09/symbol-ownership/emaxx'
destination = w / 'docs/handover/2026-10-09-symbol-fields'
read = lambda path: json.loads(path.read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
failed = read(p / 'source318-macos-frozen-incomplete-audit.json')
longer = read(p / 'source318-tramp-longer-audit.json')
tail = read(p / 'source318-macos-tail-audit.json')

original_contract = read(Path(failed['raw_root']) / 'contract.json')
longer_contract = read(Path(longer['raw_root']) / 'contract.json')
tail_contract = read(Path(tail['raw_root']) / 'contract.json')
assert original_contract['files'][318:319] == longer_contract['files']
assert original_contract['files'][319:] == tail_contract['files']
assert len(original_contract['files']) == len(set(original_contract['files'])) == 519
assert sum(x['matching_outcomes'] for x in [failed, longer, tail]) == 7915
assert sum(x['successful_processes'] for x in [failed, longer, tail]) == 1038
assert tail['mismatching_outcomes'] == 6
assert tail['subject_sha256'] == longer['subject_sha256']

members = {}
excluded_tools = []
for label, result in [('frozen-incomplete', failed), ('tramp-longer', longer), ('ordinary-tail', tail)]:
    root = Path(result['raw_root'])
    for name, digest in result['raw_files'].items():
        data = (root / name).read_bytes()
        assert sha(data) == digest
        if name.startswith('tools/'):
            excluded_tools.append(dict(path=str(root / name), bytes=len(data), sha256=digest))
            continue
        members['evidence/' + label + '/raw/' + name] = data
for name in ['source318-macos-frozen-incomplete-audit.json', 'source318-tramp-longer-audit.json',
             'source318-macos-frozen/state.json', 'source318-macos-frozen/frozen.log',
             'source318-macos-frozen/runner-build.log', 'source318-tramp-longer/state.json',
             'source318-tramp-longer/run.log', 'payload-draft1/source.json',
             'audit_source318_macos_incomplete.py', 'audit_source318_tramp_longer.py',
             'source318_macos_frozen.py', 'source318_tramp_longer.py', 'source318_macos_tail.py',
             'source318-macos-tail-audit.json', 'source318-macos-tail/state.json', 'source318-macos-tail/run.log',
             'audit_source318_macos_tail.py', 'source318_macos_continue.py',
             'source318-macos-continuation-state.json', 'package_macos_progress.py',
             'observe_terminal.py', 'source318_terminal.py',
             'source318-terminal/state.json', 'source318-terminal/command.json']:
    members['evidence/' + name] = (p / name).read_bytes()
members['contents.json'] = (json.dumps({name: dict(bytes=len(data), sha256=sha(data)) for name, data in members.items()}, indent=2) + '\n').encode()
buffer = io.BytesIO()
with gzip.GzipFile(fileobj=buffer, mode='wb', mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode='w') as archive:
        for name, data in sorted(members.items()):
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o644
            info.mtime = 0
            archive.addfile(info, io.BytesIO(data))
data = buffer.getvalue()
archive_path = destination / 'source318-macos-frozen-continuation-results.tar.gz'
assert not archive_path.exists()
archive_path.write_bytes(data)
with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
    assert set(archive.getnames()) == set(members)
    assert all(archive.extractfile(name).read() == content for name, content in members.items())
manifest = dict(checkpoint='source318', runtime_source_commit='93b6546f9c54aaecf2237cc751e3f94591066969',
    archive=dict(path=archive_path.name, bytes=len(data), sha256=sha(data), members=len(members)),
    original=dict(status=failed['status'], completed_comparisons=318, matching_outcomes=4479, successful_processes=636, failed_processes=2, unstarted_files=200, source_inputs_verified=562, deadline_seconds=180),
    longer=dict(status=longer['status'], matching_outcomes=59, successful_processes=2, runner_summaries=longer['runner_summaries'], test_seconds=longer['test_seconds'], deadline_seconds=600, original_subject_sha256=longer['original_subject_sha256'], subject_sha256=longer['subject_sha256']),
    tail={key: tail[key] for key in ['status', 'files', 'matching_outcomes', 'mismatching_outcomes', 'total_outcomes', 'successful_processes', 'runner_summaries', 'source_inputs_verified', 'subject_sha256', 'deadline_seconds']},
    combined=dict(files_observed=519, distinct_matching_outcomes=7915, mismatching_outcomes=6, successful_processes=1038, original_failed_processes=2),
    excluded_large_inputs=failed['retained_inputs'] + longer['retained_inputs'],
    excluded_prerequisite_tools=excluded_tools,
    remaining='Source318 terminal validation is running separately on retained same-depth executable/image copies. Its launch and observer are included here, not a terminal completion claim. The separately recorded instance ownership defect and the complete architectural and calibrated performance goal remain open.',
    qualification='All raw prefix, bounded Tramp and 200-file tail reports, process records, hashes, selectors and audit helpers are retained. The separate tail has 3,377 matches and six existing feature-message differences, with no unexpected outcome. Across the three attempts, all 519 files are observed and 7,915 distinct outcome labels match. The six diagnostics remain strict mismatches. Both original Tramp processes timed out without answers. The separately bounded run obtains all 59 actual matching outcomes. It uses the same runtime inputs and image but a rebuilt subject executable, identified separately. The failed frozen run is not relabeled successful; no complete frozen or performance acceptance is claimed. Large executable/images and prerequisite tools remain locally retained and are identified by hash.', goal_complete=False)
(destination / 'source318-macos-frozen-continuation-results-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest['archive']))
