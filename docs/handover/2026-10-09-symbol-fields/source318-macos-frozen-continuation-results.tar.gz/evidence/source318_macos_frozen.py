from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
p=Path(__file__).resolve().parent
w=p.parent/'recovered-2026-10-09/symbol-ownership/emaxx'
gnu=p.parent/'rebuilt-2026-10-01/emacs'
output=p/'source318-macos-frozen'
output.mkdir(exist_ok=False)
source=json.loads((p/'payload-draft1/source.json').read_text())
assert len(source)==562
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
def verify():
 for name,row in source.items():
  path=w/name
  assert sha(path)==row['sha256'] and oct(path.stat().st_mode & 0o777)==row['mode'],name
verify()
overrides=dict(LANG='C',LC_ALL='C',CARGO_BUILD_JOBS='1',CARGO_NET_OFFLINE='true',RUST_TEST_THREADS='1',RUST_MIN_STACK='134217728',EMAXX_GNU_SOURCE_DIRECTORY=str(gnu),EMAXX_DUMP_SOURCE_DIRECTORY=str(gnu),EMACS_TEST_DIRECTORY=str(gnu/'test'))
state=dict(status='waiting for full Rust gate',pid=os.getpid(),started=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_inputs=source,environment_overrides=overrides,oracle={str(path):sha(path) for path in (gnu/'src/emacs',gnu/'src/emacs.pdmp')},results=[],goal_complete=False)
def save(): (output/'state.json').write_text(json.dumps(state,indent=2)+'\n')
save()
print(state['status'],flush=True)
try:
 deadline=time.monotonic()+10800
 receipt=p/'payload-draft1-full/full.json'
 captured=p/'payload-draft1-full/source-after.json'
 while True:
  if receipt.exists():
   result=json.loads(receipt.read_text())
   if result['exit_code']!=0: raise RuntimeError('Full Rust gate failed; frozen run not started')
   if captured.exists(): break
  if time.monotonic()>deadline: raise RuntimeError('Full Rust gate did not complete in queue deadline; frozen run not started')
  time.sleep(10)
 assert json.loads(captured.read_text())==source
 state['full_rust_receipt_sha256']=sha(receipt)
 verify()
 local=w/'compat/oracle.local.json'
 override=dict(format_version=1,emacs_binary=str(gnu/'src/emacs'),emacs_repo=str(gnu))
 if local.exists(): assert json.loads(local.read_text())==override
 else: local.write_text(json.dumps(override,indent=2)+'\n')
 assert json.loads((w/'compat/oracle.lock.json').read_text())['emacs_binary_sha256']==sha(gnu/'src/emacs')
 for name,command,timeout in [
  ('runner-build',['cargo','build','--locked','--offline','--profile','gate','--bin','compat-harness'],1800),
  ('frozen',[str(w/'target/gate/compat-harness'),'frozen'],21600),
 ]:
  verify()
  state.update(status='running '+name,current_command=command,source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip())
  save()
  print('START',name,flush=True)
  start=time.monotonic()
  with (output/(name+'.log')).open('wb') as log:
   try:
    result=subprocess.run(command,cwd=w,env={**os.environ,**overrides},stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
    status=result.returncode; timed_out=False
   except subprocess.TimeoutExpired:
    status=None; timed_out=True
  row=dict(stage=name,command=command,exit_code=status,timed_out=timed_out,timeout_seconds=timeout,elapsed_seconds=time.monotonic()-start,log_sha256=sha(output/(name+'.log')))
  state['results'].append(row)
  save()
  verify()
  print(json.dumps(row),flush=True)
  if status!=0: break
 for name,digest in state['oracle'].items(): assert sha(Path(name))==digest
 subject=w/'target/compat-subject/gate/emaxx'
 state['subject']={str(path):dict(sha256=sha(path),bytes=path.stat().st_size) for path in (subject,subject.with_suffix('.pdmp')) if path.exists()}
 state.update(status='terminal; inspect strict raw verdicts',source_unchanged=True)
 save()
except BaseException as error:
 state.update(status='supervisor failed; inspect saved stages',error=str(error))
 save()
 raise
raise SystemExit(0 if len(state['results'])==2 and all(row['exit_code']==0 for row in state['results']) else 1)
