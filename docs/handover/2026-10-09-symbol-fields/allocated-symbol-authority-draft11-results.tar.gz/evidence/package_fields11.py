from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).resolve().parent
r = p.parents[2]
fp = p.parent / 'allocated-symbols-2026-10-10'
destination = r / 'docs/handover/2026-10-09-symbol-fields'
read = lambda path: json.loads(path.read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()


def package(name, trees, files, information):
    members, excluded = {}, []

    def add(name, path):
        data = path.read_bytes()
        if len(data) > 1_000_000 and (path.name in ['libtest', 'emaxx', 'emacs'] or path.suffix == '.pdmp'):
            excluded.append(dict(path=str(path), bytes=len(data), sha256=sha(data)))
        else:
            assert name not in members
            members[name] = data

    for prefix, directory in trees:
        for path in sorted(directory.rglob('*')):
            if path.is_file():
                add(prefix + '/' + str(path.relative_to(directory)), path)
    for prefix, path in files:
        add(prefix, path)
    members['contents.json'] = (json.dumps({key:dict(bytes=len(data), sha256=sha(data)) for key,data in members.items()},indent=2)+'\n').encode()
    buffer = io.BytesIO()
    with gzip.GzipFile(fileobj=buffer, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for key, data in sorted(members.items()):
                entry = tarfile.TarInfo(key)
                entry.size, entry.mode = len(data), 0o644
                archive.addfile(entry, io.BytesIO(data))
    data = buffer.getvalue()
    path = destination / (name + '.tar.gz')
    with path.open('xb') as stream:
        stream.write(data)
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
        assert set(archive.getnames()) == set(members)
        assert all(archive.extractfile(key).read() == value for key,value in members.items())
    manifest = dict(archive=dict(path=path.name, bytes=len(data), sha256=sha(data), members=len(members)),
                    excluded_large_inputs=excluded, goal_complete=False, **information)
    with (destination / (name + '-manifest.json')).open('x') as stream:
        json.dump(manifest, stream, indent=2)
        stream.write('\n')
    print(json.dumps(manifest['archive']), flush=True)


audit=read(fp/'fields-draft11-audit.json')
assert all(v['passed']==237 for v in audit['profiles'].values())
ordinary=read(fp/'fields-draft7-ordinary-audit.json')
package('allocated-symbol-authority-draft11-results',
    [('evidence/'+label,fp/label) for label in ['fields-draft7-ordinary','fields-draft8-retirement-negative',
     'fields-draft9-retirement-mark','fields-draft10-no-id-memo','fields-draft11-release','fields-draft11-gate']],
    [('evidence/'+name,fp/name) for name in ['fields-draft11-audit.json','fields-draft11.patch','audit_fields_latest.py',
     'fields-draft7-ordinary-audit.json','audit_payload_ordinary.py','ordinary_payloads.py','validate_retirement.py',
     'validate_field_final.py','continue_fields_final.py','fields-final-continuation-state.json','fields-final-gate-supervisor.log',
     'allocated-symbol-fields-gnu.el','allocated-symbol-fields-gnu.json','allocated-symbol-fields-gnu.stdout','allocated-symbol-fields-gnu.stderr']]
    + [('evidence/previous/'+label+'/'+name,p/label/name) for label in ['image-draft6-relocation','image-draft6-release'] for name in ['selection.json','inventory.stdout']]
    + [('evidence/package_fields11.py',p/'package_fields11.py')],
    dict(checkpoint='unapplied allocated fields and direct C-slot classification draft11',audit=audit,
         earlier_ordinary_audit=ordinary,
         qualification='Selected gate/release checks cover the exact newest draft; the fifteen ordinary GNU comparisons belong to draft7 and do not certify subsequent changes. Earlier draft1-7 failures remain in the preceding portable package. The retirement negative and all subsequent attempts are retained here. Full architecture, validation, physical accounting and performance requirements remain open.'))
