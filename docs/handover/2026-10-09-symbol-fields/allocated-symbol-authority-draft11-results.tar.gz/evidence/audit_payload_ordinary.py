from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import subprocess
import tarfile

p = Path(__file__).resolve().parent
out = p / "fields-draft7-ordinary"
w = p.parent / "recovered-2026-10-10/symbol-fields/emaxx"
destination = p.parents[2] / "docs/handover/2026-10-09-symbol-fields"
read = lambda path: json.loads(path.read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
source = read(out / "source.json")
assert source == read(p / "fields-draft7-owned-payload-controls/source.json") and len(source) == 566
assert all(sha((w/name).read_bytes()) == row["sha256"] and oct((w/name).stat().st_mode & 0o777) == row["mode"] for name,row in source.items())
assert read(out/"summary.json") == dict(processes=30, passed=30, failed=0, source_inputs=566, goal_complete=False)
results, pairs = read(out/"results.json"), {}
assert len(results) == 30
for row in results:
    label = "-".join([row["fixture"], row["mode"], row["editor"]])
    receipt = read(out/(label+".json"))
    assert receipt["exit_code"] == 0 and not receipt["timed_out"] and receipt["timeout_seconds"] == 180
    for stream in ["stdout", "stderr"]:
        assert sha((out/(label+"."+stream)).read_bytes()) == receipt[stream+"_sha256"]
    output = (out/(label+".stdout")).read_text()
    assert output == row["stdout"] and output.strip() == row["expected"] and row["passed"]
    if row["mode"] != "interpreted":
        assert output.startswith("((t t t t) " if row["fixture"] == "symbol-redirect-lifetime" else "(t ")
    pairs.setdefault((row["fixture"],row["mode"]),{})[row["editor"]] = (output,receipt["command"][1:])
assert len(pairs) == 15 and all(set(pair) == {"gnu","emaxx"} and pair["gnu"] == pair["emaxx"] for pair in pairs.values())
for label in ["build", "image"]:
    receipt = read(out/(label+".json"))
    assert receipt["exit_code"] == 0 and not receipt["timed_out"]
    for stream in ["stdout","stderr"]:
        data = (out/(label+"."+stream)).read_bytes()
        assert sha(data) == receipt[stream+"_sha256"]
        assert not re.search(rb"^warning(?:\[.*?\])?:",data,re.M)
identities = read(out/"artifacts-before.json")
assert identities == read(out/"artifacts-after.json")
retained = p / "fields-draft7-ordinary-retained-inputs"
retained.mkdir(exist_ok=False)
retention = []
for index,(name,row) in enumerate(sorted(identities.items())):
    path = Path(name)
    assert sha(path.read_bytes()) == row["sha256"] and path.stat().st_size == row["bytes"]
    copy = retained/(str(index)+"-"+path.name)
    subprocess.run(["cp","-c",str(path),str(copy)],check=True)
    assert sha(copy.read_bytes()) == row["sha256"]
    retention.append(dict(original=name,retained=str(copy),**row))
audit = dict(status="passed", source_inputs_verified=566, processes=30, comparisons=15,
    actual_modes=["interpreted","bytecode","native"], identical_editor_arguments=True,
    previous_nine_comparisons_preserved=True, added_graph_comparisons=3, added_allocated_field_comparisons=3, retained_inputs=retention,
    qualification="Unapplied allocated-field draft7: ordinary release executables and each editor's own valid image; actual compiler-mode predicates are checked outside execution. Original wrapper preflight failure remains in the selected archive. This is not complete platform or performance validation.", goal_complete=False)
(p/"fields-draft7-ordinary-audit.json").write_text(json.dumps(audit,indent=2)+"\n")
print(json.dumps(audit,indent=2))
