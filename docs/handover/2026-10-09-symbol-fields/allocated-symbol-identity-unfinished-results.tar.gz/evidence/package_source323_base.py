from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).resolve().parent
r = p.parents[2]
fp = p.parent / 'allocated-symbols-2026-10-10'
destination = r / 'docs/handover/2026-10-09-symbol-fields'
read = lambda path: json.loads(path.read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()


def package(name, trees, files, information):
    members, excluded = {}, []

    def add(name, path):
        data = path.read_bytes()
        if len(data) > 1_000_000 and (path.suffix == '.pdmp' or data[:4] in [b'\x7fELF', b'\xcf\xfa\xed\xfe', b'\xfe\xed\xfa\xcf', b'\xca\xfe\xba\xbe']):
            excluded.append(dict(path=str(path), bytes=len(data), sha256=sha(data)))
        else:
            assert name not in members
            members[name] = data

    for prefix, directory in trees:
        for path in sorted(directory.rglob('*')):
            if path.is_file():
                add(prefix + '/' + str(path.relative_to(directory)), path)
    for prefix, path in files:
        add(prefix, path)
    members['contents.json'] = (json.dumps({key:dict(bytes=len(data), sha256=sha(data)) for key,data in members.items()},indent=2)+'\n').encode()
    buffer = io.BytesIO()
    with gzip.GzipFile(fileobj=buffer, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for key, data in sorted(members.items()):
                entry = tarfile.TarInfo(key)
                entry.size, entry.mode = len(data), 0o644
                archive.addfile(entry, io.BytesIO(data))
    data = buffer.getvalue()
    path = destination / (name + '.tar.gz')
    with path.open('xb') as stream:
        stream.write(data)
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
        assert set(archive.getnames()) == set(members)
        assert all(archive.extractfile(key).read() == value for key,value in members.items())
    manifest = dict(archive=dict(path=path.name, bytes=len(data), sha256=sha(data), members=len(members)),
                    excluded_large_inputs=excluded, goal_complete=False, **information)
    with (destination / (name + '-manifest.json')).open('x') as stream:
        json.dump(manifest, stream, indent=2)
        stream.write('\n')
    print(json.dumps(manifest['archive']), flush=True)

