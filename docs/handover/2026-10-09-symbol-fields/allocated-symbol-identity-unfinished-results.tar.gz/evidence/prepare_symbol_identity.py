from pathlib import Path
import hashlib
import json

p = Path(__file__).resolve().parent
w = p.parent / 'recovered-2026-10-12/symbol-identity/emaxx'
out = p / 'identity-proposed'
out.mkdir(exist_ok=False)
files = {}

def get(name):
    return files.setdefault(name, (w / name).read_text())

def replace(name, old, new, count=1):
    text = get(name)
    assert text.count(old) == count, (name, old, text.count(old))
    files[name] = text.replace(old, new)

name = 'src/lisp/alloc/symbols.rs'
replace(name, '    /// Remaining name/local-binding adapters use this id; fields do not.\n    pub(crate) id: u32,\n', '')
replace(name, 'Remaining host name/id and localized/forwarded adapters', 'Remaining host name and localized/forwarded adapters')
replace(name, 'const FUNCTION_DEFINITION: u8 = 16;', '''const FUNCTION_DEFINITION: u8 = 16;
// lisp.h: Lisp_Symbol.interned is object state, not an identity-number bit.
// Standard-obarray removal still has its separate membership adapter.
const UNINTERNED: u8 = 32;''')
replace(name, 'impl SymbolCell {\n', '''impl SymbolCell {
    pub(crate) fn is_uninterned(&self) -> bool {
        self.state.get() & UNINTERNED != 0
    }

    pub(crate) fn mark_uninterned(&self) {
        self.state.set(self.state.get() | UNINTERNED);
    }

''')

name = 'src/lisp/types.rs'
text = get(name)
start = text.index('/// Each allocated symbol owns its id.')
end = text.index("/// alloc.c's `sweep_symbols'", start)
files[name] = text[:start] + text[end:]
replace(name, 'if cell.id & UNINTERNED_SYMBOL_ID_BIT == 0 {', 'if !cell.is_uninterned() {')
replace(name, '            let id = next_symbol_id(false);\n', '')
replace(name, '                    id,\n', '')
replace(name, '        let id = next_symbol_id(true);\n', '')
replace(name, '                id,\n', '')
text = get(name)
start = text.index('    /// The id of the state TEXT currently names')
end = text.index('    /// The existing object, without allocating or converting it to an id.', start)
files[name] = text[:start] + text[end:]
replace(name, '    /// The existing object, without allocating or converting it to an id.', '    /// The existing object, without allocating.')
text = get(name)
start = text.index("    /// The process-wide symbol id (see `SymbolCell::id');")
end = text.index('    pub fn into_string(self)', start)
files[name] = text[:start] + text[end:]
replace(name, '        UNINTERNED_SYMBOL_BOOK.with_borrow_mut(|book| {\n            book.replace(symbols::NameEntry(name));', '        name.cell().mark_uninterned();\n        UNINTERNED_SYMBOL_BOOK.with_borrow_mut(|book| {\n            book.replace(symbols::NameEntry(name));')
replace(name, 'assq_environment(environment, |bound| bound.id() == symbol.id())', 'assq_environment(environment, |bound| bound == symbol)')
# Keep the historical selector and its cross-thread lookup/reclamation checks.
# A collected address may be reused, just as GNU's symbol free list permits.
replace(name, '                (interned.id(), uninterned.id())', '''                uninterned.cell().set_value(Value::Integer(73));
                uninterned.cell().function.set(Value::T);
                uninterned.cell().plist.set(Value::Integer(91));
                (interned.identity_ptr(), uninterned.identity_ptr())''')
replace(name, 'SymbolName::id_of(INTERNED)', 'SymbolName::find(INTERNED).map(|symbol| symbol.identity_ptr())', 2)
replace(name, 'SymbolName::id_of(&second_text)', 'SymbolName::find(&second_text).map(|symbol| symbol.identity_ptr())')
replace(name, 'SymbolName::id_of(&collected_text)', 'SymbolName::find(&collected_text).map(|symbol| symbol.identity_ptr())', 2)
replace(name, 'SymbolName::intern_str(INTERNED).id()', 'SymbolName::intern_str(INTERNED).identity_ptr()', 2)
replace(name, 'SymbolName::intern_str(&second_text).id()', 'SymbolName::intern_str(&second_text).identity_ptr()')
replace(name, '                assert_ne!(replacement.id(), uninterned);', '''                // The free list may reuse the old address after reclamation.
                // The replacement must have freshly initialized object fields.
                assert!(replacement.cell().is_uninterned());
                assert!(replacement.cell().value().is_none());
                assert!(replacement.cell().function.get().is_nil());
                assert!(replacement.cell().plist.get().is_nil());''')
replace(name, 'Some(replacement.id())', 'Some(replacement.identity_ptr())')

name = 'src/lisp/eval/local_cells.rs'
text = get(name)
text = text.replace("//! the symbol's id, keeps first-binding order, and stores `Value::Unbound'", "//! the actual symbol, keeps first-binding order, and stores `Value::Unbound'")
text = text.replace('LinkedHashMap<u32, (SymbolName, Value), FnvBuildHasher>', 'LinkedHashMap<SymbolName, Value, FnvBuildHasher>')
start = text.index('    /// The symbols this table holds cells for')
end = text.index('    /// The binding for SYMBOL', start)
text = text[:start] + '''    /// A local binding retains its actual symbol, as GNU's local_var_alist does.
    pub(crate) fn symbols(&self) -> impl Iterator<Item = &SymbolName> {
        self.cells.keys()
    }

''' + text[end:]
text = text.replace('.get(&symbol.id())', '.get(symbol)').replace('.map(|(_, value)|', '.map(|value|')
text = text.replace('let id = SymbolName::id_of(name)?;', 'let symbol = SymbolName::find(name)?;')
text = text.replace('.get(&id)', '.get(&symbol)').replace('self.cells.remove(&id).map(|value| value)', 'self.cells.remove(&symbol)')
start = text.index('        match self.cells.get_mut(&symbol.id())')
end = text.index('\n    }', start)
text = text[:start] + '        match self.cells.get_mut(symbol) {\n            Some(existing) => *existing = value,\n            None => {\n                self.cells.insert(*symbol, value);\n            }\n        }' + text[end:]
text = text.replace('self.cells.values().map(|(symbol, value)| (symbol, value))', 'self.cells.iter()')
text = text.replace('self.cells.values_mut().map(|value| value)', 'self.cells.values_mut()')
text = text.replace('.map(|(_, (symbol, value))| {\n                let symbol = copy(symbol);\n                (symbol.id(), (symbol, value))\n            })', '.map(|(symbol, value)| (copy(symbol), value))')
files[name] = text
replace('src/lisp/eval.rs', 'bindings.uninterned_symbols()', 'bindings.symbols()')

name = 'src/lisp/eval/bindings.rs'
replace(name, 'let mut seen: Vec<u32> = vec![symbol.id()];', 'let mut seen = vec![*symbol];')
replace(name, 'seen.contains(&current.id())', 'seen.contains(&current)', 2)
replace(name, 'seen.push(current.id());', 'seen.push(current);', 2)
name = 'src/lisp/eval/variables.rs'
replace(name, 'watched.id() == symbol.id()', 'watched == symbol')
replace(name, '        let id = symbol.id();\n', '')
replace(name, 'restore.name.id() == id', 'restore.name == *symbol')
replace(name, 'resolved.id() == symbol.id()', 'resolved == *symbol')
replace(name, 'any watcher is registered under it, by id.', 'any watcher is registered under its object identity.')
replace(name, 'the records by id.', 'the records by object identity.')
name = 'src/lisp/primitives/dispatch/misc.rs'
replace(name, 'resolved.id() == symbol.id()', 'resolved == *symbol')
replace(name, 'scope and cells are read by id', 'scope and cells are read from the object')
text = get(name)
start = text.index('                    // nil and t are told apart by symbol id')
end = text.index('                        call_function_value(interp, &args[0], &[symbol], env)?;', start)
files[name] = text[:start] + '''                    for symbol in symbols.iter() {
                        // The shared Value constructor preserves the nil/t ABI.
                        let symbol = Value::Symbol(*symbol);
''' + text[end:]

name = 'src/lisp/primitives/pdumper/context.rs'
replace(name, '    Symbol(u32),', '    Symbol(usize),')
replace(name, 'ObjectKey::Symbol(name.id())', 'ObjectKey::Symbol(name.identity_ptr())')
replace(name, 'symbol.id() & crate::lisp::types::UNINTERNED_SYMBOL_ID_BIT != 0', 'symbol.cell().is_uninterned()')
replace(name, 'keeps such a name in a set beside its ordinary id, so the record', 'still keeps standard-obarray removals in a membership set, so the record')
name = 'src/lisp/primitives/pdumper/tests.rs'
replace(name, '(x.id() & crate::lisp::types::UNINTERNED_SYMBOL_ID_BIT != 0)\n                != (y.id() & crate::lisp::types::UNINTERNED_SYMBOL_ID_BIT != 0)', 'x.cell().is_uninterned() != y.cell().is_uninterned()')
replace('src/lisp/eval/image_install.rs', 'symbol.symbol.id() & crate::lisp::types::UNINTERNED_SYMBOL_ID_BIT == 0', '!symbol.symbol.cell().is_uninterned()')
replace('src/lisp/eval/symbol_cells.rs', 'the allocated header still includes host name/id adapters.', 'the allocated header still includes its host-name adapter.')

name = 'src/lisp/types/symbols.rs'
keyboard = ['overriding-terminal-local-map', 'last-command', 'real-last-command',
    'keyboard-translate-table', 'last-repeatable-command', 'prefix-arg', 'last-prefix-arg',
    'defining-kbd-macro', 'last-kbd-macro', 'system-key-alist', 'window-system',
    'default-minibuffer-frame', 'input-decode-map', 'local-function-key-map']
replace(name, '    "undo-auto--undoable-change",\n];', '    "undo-auto--undoable-change",\n' + ''.join('    "'+key+'",\n' for key in keyboard) + '];')
text = get(name)
start = text.index('    pub(crate) fn with<R>(self, body: impl FnOnce(&SymbolName) -> R) -> R {')
end = text.index('\nfn mark_names(', start)
files[name] = text[:start] + '''    fn get(self, symbols: &Symbols) -> SymbolName {
        symbols.keys[self.0].get().unwrap_or_else(|| {
            let symbol = SymbolName::intern_str(KEY_NAMES[self.0]);
            symbols.keys[self.0].set(Some(symbol));
            symbol
        })
    }

    pub(crate) fn with<R>(self, body: impl FnOnce(&SymbolName) -> R) -> R {
        let symbol = with_current(|symbols| self.get(symbols));
        body(&symbol)
    }
}

/// Qsymbol references belong to each editor, like GNU's process references.
/// The existing terminal forwarding adapter consumes these until keyboard
/// bindings use an allocated Lisp_Fwd redirect. No symbol-id lookup is needed.
pub(crate) fn is_keyboard_variable(symbol: &SymbolName) -> bool {
    const KEYS: [SymbolKey; 14] = [
''' + ''.join('        SymbolKey::new("'+key+'"),\n' for key in keyboard) + '''    ];
    with_current(|symbols| KEYS.iter().any(|key| key.get(symbols) == *symbol))
}
''' + text[end:]
name = 'src/lisp/eval/terminal.rs'
text = get(name)
start = text.index('    /// Whether SYMBOL is one of the keyboard\'s per-terminal variables')
end = text.index('    pub(crate) fn keyboard_binding_terminal(', start)
files[name] = text[:start] + '''    /// Whether SYMBOL is one of this editor's keyboard variable objects.
    pub(crate) fn is_keyboard_variable(symbol: &crate::lisp::types::SymbolName) -> bool {
        crate::lisp::types::symbols::is_keyboard_variable(symbol)
    }

''' + text[end:]

record = {}
for name, text in files.items():
    target = out / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text)
    record[name] = dict(before_sha256=hashlib.sha256((w / name).read_bytes()).hexdigest(),
                       proposed_sha256=hashlib.sha256(target.read_bytes()).hexdigest())
(out / 'manifest.json').write_text(json.dumps(record, indent=2) + '\n')
print('Prepared', len(files), 'files without changing the validating checkout')
