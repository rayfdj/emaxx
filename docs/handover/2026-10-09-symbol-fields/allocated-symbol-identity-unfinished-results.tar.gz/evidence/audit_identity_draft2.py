from pathlib import Path
import hashlib
import json
import re

p = Path(__file__).resolve().parent
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
replays = read(p/'fields-identity-replay.json')
source = read(p/'fields-identity-draft2-gate/source.json')
assert len(source) == 568
assert source == read(p/'fields-identity-draft2-gate/source-after.json')
results = []
for label, failed_stage, expected_passed, expected_failed in [
    ('fields-identity-negative','focused',0,2),
    ('fields-identity-draft1-gate','check',None,None),
    ('fields-identity-draft2-gate',None,380,0),
]:
    d = p/label
    replay = next(row for row in replays if row['label'] == label)
    assert replay['replayed'] and replay['source_inputs'] == 568
    assert sha(p/replay['patch']) == replay['sha256']
    for name in ['fmt','check','clippy','diff','build','inventory','focused']:
        path = d/(name+'.json')
        if not path.exists():
            continue
        receipt = read(path)
        assert receipt['exit_code'] == (101 if name == failed_stage else 0)
        for stream in ['stdout','stderr']:
            path = d/(name+'.'+stream)
            assert sha(path) == receipt[stream+'_sha256']
            if failed_stage is None and name in ['check','clippy','build']:
                assert not re.search(r'^warning(?:\[.*?\])?:',path.read_text(errors='replace'),re.M)
    row = dict(label=label,patch=replay,failed_stage=failed_stage)
    if expected_passed is not None:
        selection = read(d/'selection.json')
        raw = (d/'focused.stdout').read_text()
        verdicts = re.findall(r'^test (\S+) \.\.\. (ok|FAILED|ignored)\s*$',raw,re.M)
        assert len(verdicts) == len(selection) == len(set(selection))
        assert set(dict(verdicts)) == set(selection)
        assert sum(v=='ok' for _,v in verdicts) == expected_passed
        assert sum(v=='FAILED' for _,v in verdicts) == expected_failed
        assert not any(v=='ignored' for _,v in verdicts)
        binary = read(d/'binary.json')
        assert sha(Path(binary['retained'])) == binary['sha256']
        row.update(passed=expected_passed,failed=expected_failed,binary=binary)
    results.append(row)
d = p/'fields-identity-draft2-gate'
old = {line[:-6] for line in (p/'fields-draft16-gate/inventory.stdout').read_text().splitlines() if line.endswith(': test')}
new = {line[:-6] for line in (d/'inventory.stdout').read_text().splitlines() if line.endswith(': test')}
assert old < new and len(new) == 3079 and len(new-old) == 1
assert set(read(p/'fields-draft16-gate/selection.json')) < set(read(d/'selection.json'))
eshell = p/'fields-identity-eshell-observation'
for label in ['before','after']:
    row = read(eshell/(label+'.json'))
    assert row['exit_code'] == 101
    for stream in ['stdout','stderr']:
        assert sha(eshell/(label+'.'+stream)) == row[stream+'_sha256']
    assert 'test result: FAILED. 0 passed; 1 failed; 0 ignored;' in (eshell/(label+'.stdout')).read_text()
result = dict(status='unapplied; strict and 380 selected controls passed; Eshell failure unresolved',
    source_inputs_verified=568,attempts=results,previous_inventory_names_preserved=len(old),
    inventory=len(new),allocated_symbol_bytes=64,previous_allocated_symbol_bytes=72,
    eshell_before_and_after='both fail the unchanged completion-window assertion',
    qualification='Allocated symbol IDs and both numeric ID counters are removed. Locals, aliases, watchers and dump identities use actual objects. Buffer-local keys no longer duplicate their symbol handles. Keyboard Qsymbol references belong to each editor; the new before-change negative fails in the second owner and now passes. The existing host-name adapters, uninterned name book, standard membership tombstones, localized/forwarded adapters, physical accounting, release/full/ordinary validation and performance remain open. The earlier full prototype also has four cross-owner expectation fixtures to repair against GNU observations. The separate Eshell failure is not fixed or waived.',goal_complete=False)
with (p/'fields-identity-draft2-audit.json').open('x') as output:
    json.dump(result,output,indent=2);output.write('\n')
print(json.dumps({k:result[k] for k in ['status','source_inputs_verified','inventory','allocated_symbol_bytes']},indent=2))
