from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

p = Path(__file__).resolve().parent
d = p / 'fields-identity-eshell-observation'
d.mkdir(exist_ok=False)
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
test = 'lisp::eval::tests::eval_05::eshell_ambiguous_completion_displays_candidates_on_second_attempt'
rows = []
for label, capture, checkout in [
    ('before', 'fields-draft16-gate', 'recovered-2026-10-10/symbol-fields/emaxx'),
    ('after', 'fields-identity-draft2-gate', 'recovered-2026-10-12/symbol-identity/emaxx'),
]:
    w = p.parent / checkout
    record = read(p/capture/'binary.json')
    binary = Path(record['retained'])
    assert sha(binary) == record['sha256']
    source = read(p/capture/'source.json')
    for name, row in source.items():
        assert sha(w/name) == row['sha256']
    environment = read(p/capture/'environment.json')
    environment['EMAXX_FIXTURE_IMAGE_DIR'] = str(d/(label+'-fixture-images'))
    command = [str(binary), '--exact', '--test-threads=1', test]
    start = time.monotonic()
    print('START', label, flush=True)
    with (d/(label+'.stdout')).open('xb') as out, (d/(label+'.stderr')).open('xb') as err:
        result = subprocess.run(command, cwd=w, env={**os.environ,**environment},
                                stdout=out, stderr=err, timeout=3600)
    row = dict(label=label, command=command, cwd=str(w), environment=environment,
               exit_code=result.returncode, elapsed_seconds=time.monotonic()-start,
               stdout_sha256=sha(d/(label+'.stdout')), stderr_sha256=sha(d/(label+'.stderr')),
               test_binary=record, source_inputs=source)
    (d/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n')
    rows.append(dict(label=label,exit_code=result.returncode))
    assert sha(binary) == record['sha256']
    assert all(sha(w/name)==item['sha256'] for name,item in source.items())
    print('END',label,result.returncode,flush=True)
    print((d/(label+'.stdout')).read_text()[-2500:],flush=True)
(d/'summary.json').write_text(json.dumps(dict(test=test,runs=rows,
    qualification='Separate same-selector observations of the actual failed Eshell contract. Original full and continuation failures remain unchanged.',
    goal_complete=False),indent=2)+'\n')
