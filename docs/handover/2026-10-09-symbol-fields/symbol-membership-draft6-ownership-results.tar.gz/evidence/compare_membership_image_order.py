from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time

p = Path(__file__).resolve().parent
r = p.parents[2]
w = p.parent / 'recovered-2026-10-13/symbol-membership/emaxx'
out = p / 'symbol-membership-draft5-image-order-comparison'
out.mkdir(exist_ok=False)
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
original = p / 'symbol-membership-draft5-selected-gate'
draft_binary = json.loads((original / 'binary.json').read_text())
baseline = r / 'target/gate/deps/emaxx-51c583d2b156da0e'
baseline_sha = json.loads((p / 'source324-macos-rust-audit.json').read_text())['test_binary_sha256']
assert sha(baseline) == baseline_sha
target = 'lisp::primitives::pdumper::tests::image_carries_the_root_groups_as_pdumper_c_dumps_the_static_roots'
first = 'batch::tests::batch_runtime_applies_the_gnu_locale_startup_policy'
second = 'batch::tests::batch_runtime_reconstructs_the_image_despite_a_shadowing_load_path'
results = []
for label, cwd, binary, digest, predecessors in [
    ('draft-second', w, Path(draft_binary['original']), draft_binary['sha256'], [second]),
    ('baseline-first', r, baseline, baseline_sha, [first]),
    ('baseline-both', r, baseline, baseline_sha, [first, second]),
]:
    directory = out / label
    directory.mkdir()
    env = json.loads((original / 'environment.json').read_text())
    env['EMAXX_FIXTURE_IMAGE_DIR'] = str(directory / 'fixture-images')
    command = [str(binary), '--exact', '--test-threads=1', *sorted(predecessors + [target])]
    assert sha(binary) == digest
    row = dict(command=command, cwd=str(cwd), binary_sha256=digest, environment_overrides=env)
    (directory / 'command.json').write_text(json.dumps(row, indent=2) + '\n')
    start = time.monotonic()
    print('START', label, flush=True)
    with (directory / 'stdout').open('xb') as stdout, (directory / 'stderr').open('xb') as stderr:
        process = subprocess.run(command, cwd=cwd, env={**os.environ, **env}, stdout=stdout, stderr=stderr, timeout=900)
    log = (directory / 'stdout').read_text()
    verdicts = re.findall(r'^test (\S+) \.\.\. (ok|FAILED)$', log, re.M)
    assert set(name for name, _ in verdicts) == set(predecessors + [target])
    row.update(exit_code=process.returncode, elapsed_seconds=time.monotonic()-start, verdicts=verdicts,
               stdout_sha256=sha(directory / 'stdout'), stderr_sha256=sha(directory / 'stderr'),
               failure_messages=re.findall(r'(?:dump failed:|unsupported object:).*', log))
    (directory / 'result.json').write_text(json.dumps(row, indent=2) + '\n')
    results.append(row)
    (out / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
    print('END', label, row['exit_code'], row['failure_messages'], round(row['elapsed_seconds'], 2), flush=True)
    assert sha(binary) == digest
