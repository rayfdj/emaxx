from pathlib import Path
import hashlib
import json
import re

p = Path(__file__).resolve().parent
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
audits = []
for profile, directory in [('gate', 'symbol-membership-draft6-formatted-gate'), ('release', 'symbol-membership-draft6-release')]:
    d = p / directory
    source = read(d / 'source.json')
    assert len(source) == 580 and source == read(d / 'source-after.json')
    stages = ['build', 'inventory', 'selected']
    if profile == 'gate':
        stages = ['fmt', 'check', 'clippy', 'diff'] + stages
    for stage in stages:
        row = read(d / (stage + '.json'))
        assert row['exit_code'] == 0
        for stream in ['stdout', 'stderr']:
            path = d / (stage + '.' + stream)
            assert sha(path) == row[stream + '_sha256']
            assert not re.search(r'^warning(?:\[.*?\])?:', path.read_text(), re.M)
    selected = read(d / 'selection.json')
    verdicts = re.findall(r'^test (\S+) \.\.\. (ok|FAILED|ignored)$', (d / 'selected.stdout').read_text(), re.M)
    assert len(selected) == len(verdicts) == 403
    assert set(name for name, _ in verdicts) == set(selected)
    assert all(verdict == 'ok' for _, verdict in verdicts)
    old = read(p / 'symbol-membership-draft5-selected-gate/selection.json')
    assert len(old) == 402 and set(old) < set(selected)
    binary = read(d / 'binary.json')
    assert sha(Path(binary['retained'])) == binary['sha256']
    audits.append(dict(profile=profile, passed=403, ignored=0, raw_names_verified=True,
        original402_preserved=True, stages_verified=stages, binary=binary,
        patch_sha256=sha(d / 'tracked.patch'), source_sha256=sha(d / 'source.json')))
assert audits[0]['patch_sha256'] == audits[1]['patch_sha256']
assert audits[0]['source_sha256'] == audits[1]['source_sha256']
replay = read(p / 'symbol-membership-draft6-replay.json')
assert len(replay['results']) == 2 and all(row['replayed'] for row in replay['results'])
assert replay['results'][1]['patch_sha256'] == audits[0]['patch_sha256']
audit = dict(status='403 controls pass in both gate and release; strict zero warnings', audits=audits,
    replay=replay, goal_complete=False,
    qualification='An isolated unfinished membership prototype, not a published runtime or full platform gate. All original draft5 failures and the draft6 formatting failure remain preserved. Fresh same-name constant/store semantics, ordinary GNU execution modes and complete platform validation remain open.')
(p / 'symbol-membership-draft6-audit.json').write_text(json.dumps(audit, indent=2) + '\n')
gnu = p.parent / 'rebuilt-2026-10-01/emacs/src/keymap.c'
mapping = dict(gnu_source='636f166cfc86aa90d63f592fd99f3fdd9ef95ebd', keymap_c_sha256=sha(gnu),
    c_mechanism='keymap.c:unicode_case_table and Flookup_key capture one staticpro root per Emacs editor process; the table survives removal from the Unicode property alist.',
    repair='Replace process-global ProcessTable<Option<CharTableRef>> with one Lisp word in InterpreterState. Mark it with the owning editor, preserve the existing image root, and graph-copy it with that editor. A newly constructed editor starts nil.',
    reason='The process hosts successive serialized editors. The global slot exposed the previous editor\'s mutable symbol fields to a fresh editor through the captured table. The preserved failing root trace reaches a foreign string symbol and its CL/native graph from this root.',
    cost='One word per editor replaces one process-global optional pointer. No additional payload mirror or registry. No net memory or speed improvement measured; public ownership/serialization remains unfinished.',
    evidence='The exact draft5 executable fails after either one of the two startup predecessors; clean source324 passes the recorded first/both sequences. Draft6 preserves every original image assertion and all402 controls, adds one editor/copy control, and passes403 per profile.')
(p / 'symbol-membership-draft6-c-mapping.json').write_text(json.dumps(mapping, indent=2) + '\n')
ns = {'__file__': str(p / 'package_source323_base.py')}
exec((p / 'package_source323_base.py').read_text(), ns)
ns['destination'] = p / 'pending-publication-source324'
entries = lambda names: [('evidence/' + name, p / name) for name in names]
ns['package']('symbol-membership-draft6-ownership-results',
    entries(['symbol-membership-draft5-image-order', 'symbol-membership-draft5-image-order-comparison',
        'symbol-membership-draft6-gate', 'symbol-membership-draft6-formatted-gate', 'symbol-membership-draft6-release']),
    entries(['symbol-membership-draft6-audit.json', 'symbol-membership-draft6-c-mapping.json',
        'symbol-membership-draft6-replay.json', 'replay_membership6.py',
        'compare_membership_image_order.py', 'isolate_membership_image_order.py',
        'validate_membership6_selected.py', 'validate_symbol_membership.py',
        'package_source323_base.py', Path(__file__).name]),
    dict(checkpoint='isolated membership draft6 ownership repair; full goal incomplete',
        validation=audit, c_mapping=mapping,
        qualification='Supplements the draft5 unfinished/failure packages. The ordering diagnostic stopped when the last failure changed from a non-fixed-up native unit to a foreign record; its39MB raw root trace is retained and its unrecorded supervisor exit/time are not reconstructed. Both exact baseline sequences pass. All580 inputs of the failed-format and repaired patches replay from99936262. Gate and release each pass403 controls; neither is a full platform gate. No assertion is removed or failure recast. Same-name builtin constant/store controls remain a known unrepaired defect.'))
