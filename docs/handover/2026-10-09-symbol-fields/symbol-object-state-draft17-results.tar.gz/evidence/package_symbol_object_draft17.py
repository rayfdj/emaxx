from pathlib import Path
import json
p=Path(__file__).resolve().parent
ns={'__file__':str(p/'package_source323_base.py')}
exec((p/'package_source323_base.py').read_text(),ns)
ns['destination']=p/'pending-publication-symbol-object-state'
entries=lambda names:[('evidence/'+name,p/name) for name in names]
selected=json.loads((p/'symbol-object-state-draft17-selected-rechecked-audit.json').read_text())
ordinary=json.loads((p/'symbol-object-state-draft17-ordinary-audit.json').read_text())
assert all(r['passed']==407 for r in selected['results']) and ordinary['processes']==88 and ordinary['comparisons']==44
ns['package']('symbol-object-state-draft17-results',
 entries(['symbol-object-state-draft16-gate','symbol-object-state-draft17-gate','symbol-object-state-draft17-selected-gate','symbol-object-state-draft17-selected-release','symbol-object-state-draft17-ordinary']),
 entries(['symbol-object-state-drafts16-17-replay.json','replay_symbol_object_native.py','symbol-object-state-c-mapping.json','symbol-object-state-draft17-selected-rechecked-audit.json','symbol-object-state-draft17-ordinary-audit.json','validate_symbol_object_native.py','validate_symbol_object_native_selected.py','audit_symbol_object_selected.py','ordinary_symbol_object_state.py','audit_symbol_object_ordinary17.py','validate_symbol_object_full17.py','audit_symbol_object_full17.py','package_source323_base.py',Path(__file__).name]),
 dict(checkpoint='symbol object-state draft17; selected and ordinary validation complete; full platforms pending',
  source_inputs=584, selected=selected, ordinary=ordinary,
  qualification='Every source byte/mode replays from99936262. Strict0warnings,4focused controls and407selected perprofile pass. All44ordinary comparisons/88processes match actualGNU answers in actualmodes, retaining every prior38case. The nativeQnil/Qt bridge now reads actualowner objects, fixing the preserved draft15 void-variable(nil) failure on the unchanged original40-predicate program. That failed run remains in the predecessor package; draft16unusedimport failure also remains. FullmacOS Rust gate is running separately with no result certified here. CleanLinux/frozen/terminal/performance and remaining architecture/accounting/publicownership are stillrequired. A local checkpoint is not full goal completion.'))
