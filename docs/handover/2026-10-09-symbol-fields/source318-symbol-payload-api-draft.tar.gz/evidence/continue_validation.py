from pathlib import Path
import datetime,json,os,subprocess,time
p=Path(__file__).resolve().parent
state_path=p/'continued-validation-state.json'
assert not state_path.exists()
state=dict(status='waiting for gate controls',pid=os.getpid(),started=datetime.datetime.now(datetime.timezone.utc).isoformat(),results=[],goal_complete=False)
def save():state_path.write_text(json.dumps(state,indent=2)+'\n')
save()
try:
 deadline=time.monotonic()+7200
 while True:
  receipt=p/'payload-draft1-gate/focused.json'
  if receipt.exists():
   assert json.loads(receipt.read_text())['exit_code']==0, 'gate controls failed'
   if (p/'payload-draft1-gate/source-after.json').exists():break
  if time.monotonic()>deadline:raise RuntimeError('gate control deadline expired')
  time.sleep(10)
 for name,command in [('release',['python3',str(p/'validate.py'),'payload-draft1-release','focus','release']),('ordinary',['python3',str(p/'ordinary.py')])]:
  state.update(status='running '+name);save();print(state['status'],flush=True)
  start=time.monotonic()
  with (p/(name+'-supervisor.log')).open('wb') as log:
   result=subprocess.run(command,cwd=p,stdout=log,stderr=subprocess.STDOUT,timeout=7200)
  state['results'].append(dict(stage=name,command=command,exit_code=result.returncode,elapsed_seconds=time.monotonic()-start));save()
  if result.returncode:raise RuntimeError(name+' failed')
 state.update(status='terminal; audit raw results',exit_code=0);save()
except BaseException as error:
 state.update(status='failed; inspect retained results',error=str(error));save();raise
