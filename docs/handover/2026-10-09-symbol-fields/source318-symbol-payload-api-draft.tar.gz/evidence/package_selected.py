from pathlib import Path
import gzip,hashlib,io,json,tarfile
p=Path(__file__).resolve().parent
w=p.parent/'recovered-2026-10-09/symbol-ownership/emaxx'
destination=w/'docs/handover/2026-10-09-symbol-fields'
sha=lambda b:hashlib.sha256(b).hexdigest()
audit=json.loads((p/'selected-audit.json').read_text())
assert audit['source_inputs_verified']==562 and len(audit['replays'])==2
members={};excluded=[]
for label in ['payload-draft1','payload-draft1-gate','payload-draft1-release','payload-draft1-ordinary']:
 for path in sorted((p/label).rglob('*')):
  if not path.is_file():continue
  name=str(path.relative_to(p));data=path.read_bytes()
  if path.name=='libtest' or path.suffix=='.pdmp':
   excluded.append(dict(path=str(path),bytes=len(data),sha256=sha(data)))
  else:members['evidence/'+name]=data
for name in ['selected-audit.json','gnu-payload-review.json','payload-draft1.patch','payload-cumulative.patch','audit_selected.py','validate.py','ordinary.py','continue_validation.py','finish_selected_and_full.py','continued-validation-state.json','release-supervisor.log','ordinary-supervisor.log','package_selected.py']:
 members['evidence/'+name]=(p/name).read_bytes()
members['contents.json']=(json.dumps({name:dict(bytes=len(data),sha256=sha(data)) for name,data in members.items()},indent=2)+'\n').encode()
buffer=io.BytesIO()
with gzip.GzipFile(fileobj=buffer,mode='wb',mtime=0) as zipped:
 with tarfile.open(fileobj=zipped,mode='w') as archive:
  for name,data in sorted(members.items()):
   info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
data=buffer.getvalue();path=destination/'source318-symbol-payload-api-draft.tar.gz'
assert not path.exists();path.write_bytes(data)
with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as archive:
 assert set(archive.getnames())==set(members)
 assert all(archive.extractfile(name).read()==data for name,data in members.items())
manifest=dict(checkpoint='source318 separately packaged, unapplied copied symbol payload API',base=audit['base'],cumulative_base='4dcf9f6a9b651545a9fba49934131e5488f0a05d',archive=dict(path=path.name,bytes=len(data),sha256=sha(data),members=len(members)),selected_audit=audit,excluded_retained_inputs=excluded,qualification='The cumulative patch includes source317 but does not change PR81 production runtime. Strict checks, 208 retained/affected controls in each profile and nine ordinary GNU comparisons pass. This changes how Rust callers access the existing cells, without allocating replacement payloads, adding lookups, changing fixtures or repairing the recorded source316 instance-name isolation negative. Full source318 macOS validation runs separately; Linux/frozen/terminal/timing and all unfinished full-goal requirements remain.',goal_complete=False)
(destination/'source318-symbol-payload-api-draft-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest['archive']))
