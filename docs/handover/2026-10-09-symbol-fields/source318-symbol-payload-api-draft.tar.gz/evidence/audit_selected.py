from pathlib import Path
import hashlib,io,json,re,subprocess,tarfile,tempfile
p=Path(__file__).resolve().parent
w=p.parent/'recovered-2026-10-09/symbol-registry/emaxx'
prior=p.parent/'symbol-registry-2026-10-09'
base='c7185a614d256128d00929ee6fc6251149e4766f'
cumulative_base='4dcf9f6a9b651545a9fba49934131e5488f0a05d'
read=lambda f:json.loads(f.read_text())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
source=read(p/'payload-draft1/source.json');assert len(source)==562
assert all(sha(w/name)==row['sha256'] and oct((w/name).stat().st_mode & 0o777)==row['mode'] for name,row in source.items())
strict=p/'payload-draft1'
assert read(strict/'source-after.json')==source
for label in ['fmt','check','clippy','diff']:
 row=read(strict/(label+'.json'));assert row['exit_code']==0
 for stream in ['stdout','stderr']:
  file=strict/(label+'.'+stream);assert sha(file)==row[stream+'_sha256']
  assert not re.search(r'^warning(?:\[.*?\])?:',file.read_text(),re.M)
controls=set(read(prior/'registry-draft1/selection.json'));assert len(controls)==175
selection=read(p/'payload-draft1-gate/selection.json')
assert len(selection)==len(set(selection))==208 and controls<=set(selection)
profiles={}
for profile,label,old_label in [('gate','payload-draft1-gate','registry-draft1'),('release','payload-draft1-release','registry-draft1-release')]:
 d=p/label;old=prior/old_label
 assert read(d/'source.json')==read(d/'source-after.json')==source
 assert read(d/'selection.json')==selection
 inventory=[line[:-6] for line in (d/'inventory.stdout').read_text().splitlines() if line.endswith(': test')]
 previous=[line[:-6] for line in (old/'inventory.stdout').read_text().splitlines() if line.endswith(': test')]
 assert sorted(inventory)==sorted(previous) and len(set(inventory))==len(inventory)
 for stage in ['build','inventory','focused']:
  receipt=read(d/(stage+'.json'));assert receipt['exit_code']==0
  for stream in ['stdout','stderr']:
   file=d/(stage+'.'+stream);assert sha(file)==receipt[stream+'_sha256']
   assert not re.search(r'^warning(?:\[.*?\])?:',file.read_text(),re.M)
 text=(d/'focused.stdout').read_text()
 verdicts=re.findall(r'^test (\S+) \.\.\. (ok|FAILED|ignored)\s*$',text,re.M)
 assert len(verdicts)==208 and dict(verdicts)==dict.fromkeys(selection,'ok')
 assert 'test result: ok. 208 passed; 0 failed; 0 ignored;' in text
 binary=read(d/'binary.json');assert sha(Path(binary['retained']))==binary['sha256']
 artifacts=[j for line in (d/'build.stdout').read_text().splitlines() if line.startswith('{') and (j:=json.loads(line)).get('reason')=='compiler-artifact' and j.get('executable') and 'lib' in j['target']['kind'] and j['profile']['test']]
 assert len(artifacts)==1 and artifacts[0]['executable']==binary['original']
 profiles[profile]=dict(selected=208,inventory=len(inventory),binary_sha256=binary['sha256'])
ordinary=p/'payload-draft1-ordinary'
assert read(ordinary/'summary.json')==dict(processes=18,passed=18,failed=0,source_inputs=562,goal_complete=False)
assert read(ordinary/'source.json')==source
before=read(ordinary/'artifacts-before.json');assert before==read(ordinary/'artifacts-after.json')
for name,row in before.items():assert sha(Path(name))==row['sha256']
results=read(ordinary/'results.json');assert len(results)==18
pairs={}
for row in results:
 label='-'.join([row['fixture'],row['mode'],row['editor']]);process=read(ordinary/(label+'.json'))
 assert process['exit_code']==0 and not process['timed_out'] and process['timeout_seconds']==180
 for stream in ['stdout','stderr']:assert sha(ordinary/(label+'.'+stream))==process[stream+'_sha256']
 output=(ordinary/(label+'.stdout')).read_text()
 assert output==row['stdout'] and output.strip()==row['expected'] and row['passed']
 key=(row['fixture'],row['mode']);pairs.setdefault(key,{})[row['editor']]=output
 if row['mode'] in ['native','bytecode']:
  assert output.startswith('((t t t t) ' if row['fixture']=='symbol-redirect-lifetime' else '(t ')
assert len(pairs)==9 and all(set(pair)=={'gnu','emaxx'} and pair['gnu']==pair['emaxx'] for pair in pairs.values())
# The ordinary program, expectation, selector, deadline and native-mode checks
# are byte-identical to source317; only evidence paths change.
old_launcher=(prior/'ordinary.py').read_text()
expected=old_launcher.replace("evidence = root / 'target/runtime-goal/symbol-registry-2026-10-09'", "evidence = root / 'target/runtime-goal/symbol-payload-api-2026-10-09'").replace('registry-draft1-ordinary','payload-draft1-ordinary').replace("evidence/'registry-draft1/", "evidence/'payload-draft1-gate/")
assert (p/'ordinary.py').read_text()==expected
# All old test assertions remain. The only changes to the test module are
# explicit Rust borrowed/copy type adaptation and a strengthened name-store
# check. Match those precise transformations against the entire old module.
path='src/lisp/eval/symbol_cells.rs'
old=subprocess.check_output(['git','show',base+':'+path],cwd=w,text=True)
current=(w/path).read_text();marker='#[cfg(test)]\nmod tests {'
old_tests=old[old.index(marker):];new_tests=current[current.index(marker):]
expected=old_tests.replace('Some(&Value::','Some(Value::').replace('Some(&function)','Some(function)').replace('Some(&target)','Some(target)').replace('Some((&symbol, &second))','Some((&symbol, second))')
expected=expected.replace('.map(|(symbol, target)| (*symbol, *target))','.map(|(symbol, target)| (*symbol, target))').replace('.map(|(symbol, value)| (*symbol, *value))','.map(|(symbol, value)| (*symbol, value))').replace('.value(&symbol).copied()', '.value(&symbol)')
expected=expected.replace('*cells.value_by_name_mut("symbol-cells-word").expect("bound") = Value::Integer(3);','assert_eq!(cells.insert_by_name("symbol-cells-word", Value::Integer(3)), Some(Value::Integer(2)));')
normalize=lambda s:re.sub(r'\s+','',s).replace(',)',')')
assert normalize(new_tests)==normalize(expected)
assert 'Option<&Value>' not in current and 'Option<&mut Value>' not in current and 'Option<&SymbolName>' not in current
allowed={'src/lisp/eval.rs','src/lisp/eval/bindings.rs','src/lisp/eval/core.rs','src/lisp/eval/definitions.rs','src/lisp/eval/symbol_cells.rs','src/lisp/eval/terminal.rs','src/lisp/eval/variables.rs'}
assert set(subprocess.check_output(['git','diff','--name-only',base],cwd=w,text=True).splitlines())==allowed
replays={}
for name,revision in [('payload-draft1.patch',base),('payload-cumulative.patch',cumulative_base)]:
 patch=p/name;assert patch.read_bytes()==subprocess.check_output(['git','diff','--binary',revision],cwd=w)
 raw=subprocess.check_output(['git','archive',revision,'--',*source],cwd=w)
 with tempfile.TemporaryDirectory(prefix='emaxx-symbol-payload-replay-') as temporary:
  root=Path(temporary)
  with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
   for entry in archive.getmembers():
    if entry.isfile():
     target=root/entry.name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(archive.extractfile(entry).read());target.chmod(0o755 if entry.mode & 0o111 else 0o644)
  subprocess.run(['git','apply',str(patch)],cwd=root,check=True)
  assert all(sha(root/name)==row['sha256'] and oct((root/name).stat().st_mode & 0o777)==row['mode'] for name,row in source.items())
 replays[name]=dict(base=revision,sha256=sha(patch),source_inputs_verified=562)
result=dict(checkpoint='source318 selected copied symbol payload API draft',base=base,source_inputs_verified=562,profiles=profiles,ordinary_processes=18,ordinary_comparisons=9,original_controls_retained=175,unchanged_full_test_inventory=True,bounded_test_type_adaptations_verified=True,ordinary_launcher_unchanged_except_paths=True,replays=replays,goal_complete=False,qualification='Strict and selected gate/release checks plus nine actual ordinary GNU comparisons. The cumulative patch includes source317. Per-interpreter field tables, process-shared symbol objects, the recorded source316 public-instance ownership negative, full platform/frozen/terminal validation, honest accounting and final performance criteria remain open. This API avoids exposing mutable payload references; it does not implement per-instance interning or allocated fields.')
(p/'selected-audit.json').open('x').write(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
