from pathlib import Path
import datetime,json,os,subprocess,time
p=Path(__file__).resolve().parent
state_path=p/'full-validation-state.json'
assert not state_path.exists()
state=dict(status='waiting for selected release and ordinary validation',pid=os.getpid(),started=datetime.datetime.now(datetime.timezone.utc).isoformat(),results=[],goal_complete=False)
def save():state_path.write_text(json.dumps(state,indent=2)+'\n')
save()
try:
 deadline=time.monotonic()+14400
 while True:
  upstream=json.loads((p/'continued-validation-state.json').read_text())
  if upstream['status'].startswith('failed'):raise RuntimeError('selected validation failed; full gate not started')
  if upstream['status'].startswith('terminal'):
   assert upstream['exit_code']==0
   break
  if time.monotonic()>deadline:raise RuntimeError('selected validation waiting deadline expired')
  time.sleep(10)
 for name,command in [('selected-audit',['python3',str(p/'audit_selected.py')]),('full',['python3',str(p/'validate.py'),'payload-draft1-full','full'])]:
  state.update(status='running '+name);save();print(state['status'],flush=True)
  start=time.monotonic()
  with (p/(name+'-supervisor.log')).open('wb') as log:
   result=subprocess.run(command,cwd=p,stdout=log,stderr=subprocess.STDOUT,timeout=10800)
  state['results'].append(dict(stage=name,command=command,exit_code=result.returncode,elapsed_seconds=time.monotonic()-start));save()
  if result.returncode:raise RuntimeError(name+' failed')
 state.update(status='terminal; inspect full raw results',exit_code=0);save()
except BaseException as error:
 state.update(status='failed; inspect retained results',error=str(error));save();raise
