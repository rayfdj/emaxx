from pathlib import Path
import hashlib,io,json,math,re,statistics,subprocess,sys,tarfile
p=Path(__file__).parent.resolve();root=p.parents[2];sys.path.insert(0,str(root/'tools'));import core_runtime_perf as perf
head='93b6546f9c54aaecf2237cc751e3f94591066969';base='30fa6e5b669c5cbd26e842e7675bfc18d306c2b4';artifact=p/'source318-linux-pair/raw';d=artifact/'core-runtime-pair'
read=lambda f:perf.parse_json(f.read_text());sha=perf.sha256
terminal=read(p/'source318-linux-status.json');assert terminal['commit']==head;run=next(r for r in terminal['runs'] if r['id']==37904576961);assert run['status']=='completed' and run['conclusion']=='success'
s=read(d/'summary.json');assert s['status']=='all 192 actual process results and modes verified';assert s['revisions']==dict(baseline=base,candidate=head)
assert s['schedule']==[['baseline','candidate'],['candidate','baseline'],['baseline','candidate']]
assert all(c['exit_code']==0 and not c['timed_out'] for c in s['commands'])
assert s['helper_sha256']==sha(root/'tools/core_runtime_perf_pair.py')
assert all(sha(root/n)==h for n,h in s['measurement_inputs'].items())
assert not read(d/'process-audit.json')['competing_task_processes']
contract=read(root/'compat/core_runtime_perf.json');perf.validate_contract(contract);cases={c['id']:c for c in contract['cases']}
cap=read(d/'oracle-inputs/manifest.json');verification=read(d/'oracle-inputs/verification.json');assert cap['source_commit']=='636f166cfc86aa90d63f592fd99f3fdd9ef95ebd'
assert verification['status']=='unchanged' and verification['files_verified']==4 and verification['capture_manifest_sha256']==sha(d/'oracle-inputs/manifest.json')
for f in cap['files']:assert sha(d/'oracle-inputs'/f['artifact'])==f['sha256']
assert cap['files'][0]['sha256']=='5e1721732427d69d8af63211f1e3833ec21e40f97f4b7f6cd4cb224b72cebfcf'
assert cap['files'][1]['sha256']=='bf4974228f3b3ea4374cec75a38eeb2bd0e7dd944da5bec4e6ad0387092502ae'
subjects={};samples={label:[] for label in s['revisions']};process_count=0
for label,revision in s['revisions'].items():
 subject=read(d/(label+'-inputs.json'));assert subject['revision']==revision
 raw=subprocess.check_output(['git','archive',revision,'--',*subject['source']],cwd=root)
 with tarfile.open(fileobj=io.BytesIO(raw)) as published:
  assert all(hashlib.sha256(published.extractfile(n).read()).hexdigest()==h for n,h in subject['source'].items())
 for name,h in subject['artifacts'].items():assert sha(d/'artifacts'/label/Path(name).name)==h
 for name,h in subject['retained'].items():assert sha(d/'artifacts'/label/Path(name).name)==h
 messages=[json.loads(line) for line in (d/(label+'-build.log')).read_text().splitlines() if line.startswith('{')]
 assert all(m.get('message',{}).get('level') not in ['warning','error'] for m in messages)
 built=[m for m in messages if m.get('reason')=='compiler-artifact' and m['target']['name']=='emaxx' and m.get('executable')]
 assert len(built)==1 and not built[0]['fresh'] and built[0]['executable'] in subject['artifacts']
 subjects[label]=subject
for repetition,order in enumerate(s['schedule']):
 for label in order:
  directory=d/(label+'-pilot-'+str(repetition));assert read(directory/'contract.json')==contract
  provenance=read(directory/'provenance.json');final=read(directory/'final-inputs.json')
  assert provenance['source_commit']==s['revisions'][label] and provenance['frozen_oracle_identity']
  assert final['unchanged'] and final['input_sha256']==provenance['input_sha256']
  for name in ('core_runtime_perf.py','core_runtime_perf.json','core_runtime_perf.el'):
   f=directory/'measurement-source'/name;expected=root/('tools/'+name if name.endswith('.py') else 'compat/'+name);assert sha(f)==sha(expected)
  for name,h in subjects[label]['artifacts'].items():assert provenance['input_sha256'][name]==h
  retained_count=0
  for name,h in provenance['input_sha256'].items():
   marker='/target/frozen-ci/core-runtime-pair/'
   if marker in name:
    local=d/name.split(marker,1)[1];assert sha(local)==h;retained_count+=1
  assert retained_count>=2
  records=read(directory/'runs.json');expected={(name,editor) for name in cases for editor in ('oracle','emaxx')};seen={}
  for record in records:
   key=(record['case_id'],record['runner']);assert key in expected and key not in seen and record['round']==0
   loc=directory/'round-00'/key[0]/key[1];process=read(loc/'process.json');report=read(loc/'report.json')
   observations=perf.validate_report(report,process,cases[key[0]],contract,(loc/'stdout.txt').read_text(),0,1)
   assert record['validation']=='completed' and record['process']==process and record['observations']==observations and record['modes']==report['modes'] and read(loc/'validation.json')==record
   seen[key]=dict(observation=observations[0],modes=report['modes'],process=process);process_count+=1
  assert set(seen)==expected and len(records)==32
  sample={}
  for name in cases:
   oracle,emaxx=(seen[name,e] for e in ('oracle','emaxx'));assert oracle['observation']['result']==emaxx['observation']['result'] and oracle['modes']==emaxx['modes']
   sample[name]=dict(oracle=oracle,emaxx=emaxx)
  samples[label].append(sample)
results=[]
for name in cases:
 bodies={label:[sample[name]['emaxx']['observation']['seconds'] for sample in group] for label,group in samples.items()}
 medians={label:statistics.median(v) for label,v in bodies.items()}
 ratios={label:statistics.median(sample[name]['emaxx']['observation']['seconds']/sample[name]['oracle']['observation']['seconds'] for sample in group) for label,group in samples.items()}
 result=dict(case=name,body_samples=bodies,body_medians=medians,gnu_ratios=ratios,candidate_over_baseline=medians['candidate']/medians['baseline'],samples={label:[sample[name] for sample in group] for label,group in samples.items()})
 results.append(result)
assert process_count==192 and results==s['results']
ratio=math.exp(statistics.mean(math.log(r['candidate_over_baseline']) for r in results));assert ratio==s['raw_body_geometric_ratio']
result=dict(status='192 actual Linux process results and modes independently verified',run_id=37904576961,source_revisions=s['revisions'],raw_body_geometric_ratio=ratio,
 paired_gnu_geometric_ratios={label:math.exp(statistics.mean(math.log(r['gnu_ratios'][label]) for r in results)) for label in s['revisions']},results=results,
 evidence={str(f.relative_to(d)):sha(f) for f in d.rglob('*') if f.is_file()},goal_complete=False,
 qualification='Three alternating full16 diagnostic pilots; all samples, actual GNU/Emaxx results and modes verified. Published tracked source, retained GNU/Emaxx executables/images, native payloads, measurement inputs and build messages independently checked. GNU Lisp/bytecode/native-library inventory hashes outside the retained artifact are bound by original pre/post-run receipts, not rehashed from missing remote paths. No calibrated nine-round or every-case3% acceptance. Both revisions include source312 native GC completion and source314 symbol lifetime/plist repairs. Both revisions also include source316 compact value/alias storage. The candidate removes the duplicate symbol registry and uses copied payload access; performance changes are not isolated to either part. Missing real allocation counters, per-instance allocated-symbol authority and physical accounting remain open. These are before/after diagnostics, not completed equivalent-work acceptance.')
(p/'source318-linux-pair-performance-audit.json').open('x').write(json.dumps(result,indent=2))
print(json.dumps({k:result[k] for k in ['status','raw_body_geometric_ratio','paired_gnu_geometric_ratios']}))
