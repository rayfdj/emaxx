from pathlib import Path
import hashlib, io, json, re, subprocess, tarfile, tempfile
p=Path(__file__).resolve().parent
w=p.parent/'recovered-2026-10-09/symbol-obarray/emaxx'
base='93b6546f'
base=subprocess.check_output(['git','rev-parse',base],cwd=w,text=True).strip()
read=lambda f:json.loads(f.read_text())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
strict=p/'obarray-draft4-hash-owner';source=read(strict/'source.json')
assert len(source)==563 and source==read(strict/'source-after.json')
assert all(sha(w/n)==v['sha256'] and oct((w/n).stat().st_mode&0o777)==v['mode'] for n,v in source.items())
for step in ['fmt','check','clippy','diff']:
 row=read(strict/(step+'.json'));assert row['exit_code']==0
 for stream in ['stdout','stderr']:
  f=strict/(step+'.'+stream);assert sha(f)==row[stream+'_sha256']
  assert not re.search(r'^warning(?:\[.*?\])?:',f.read_text(),re.M)
probes={}
old=p.parent/'symbol-registry-2026-10-09/isolation-flushed'
for label in ['obarray-draft2-public-deps','obarray-draft3-public','obarray-draft4-public']:
 d=p/label;r=read(d/'run.json');assert r['source_unchanged']
 for name in ['first.el','second.el','public_instances.rs']:
  assert sha(d/name)==sha(old/name)==r['inputs'][name]
 assert sha(d/'hash-types.el')==sha(p/'obarray-draft4-public/hash-types.el')==r['inputs']['hash-types.el']
 for row in r['processes']:
  assert row['exit_code']==0 and not row['timed_out']
  for stream in ['stdout','stderr']:
   assert sha(d/(row['label']+'.'+stream))==row[stream+'_sha256']
 assert len(r['processes'])==8
 for row in r['comparisons']:
  name=row['label'];expected=(d/(name+'-gnu-first.stdout')).read_text()+(d/(name+'-gnu-second.stdout')).read_text();actual=(d/(name+'-emaxx-two-editors.stdout')).read_text()
  assert row['gnu']==expected and row['emaxx']==actual
  assert row['matches']==(actual==expected) and row['exit_codes']==[0,0,0]
 expected=[True,False] if label=='obarray-draft3-public' else [True,True]
 assert [x['matches'] for x in r['comparisons']]==expected
 assert sha(d/'public-instances')==r['artifacts'][str(d/'public-instances')]
 probes[label]=dict(comparisons=r['comparisons'],public_launcher_sha256=sha(d/'public_instances.rs'),subject_sha256=sha(d/'public-instances'),library_sha256=r['library']['sha256'])
 if label=='obarray-draft4-public':
  assert r['source_inputs']==source
  lib=Path(r['library']['path']);assert sha(lib)==r['library']['sha256']
  retained=d/'libemaxx.rlib'
  if not retained.exists():subprocess.run(['cp','-c',str(lib),str(retained)],check=True)
  assert sha(retained)==r['library']['sha256']
first=read(p/'obarray-draft2-public/run.json')
assert [row['exit_code'] for row in first['processes']]==[0,1]
assert 'error[E0463]' in (p/'obarray-draft2-public/compile.stderr').read_text()
assert read(p/'obarray-draft1/clippy.json')['exit_code']!=0
replays={}
for name,revision in [('obarray-draft4.patch',base),('obarray-cumulative-draft4.patch','30fa6e5b669c5cbd26e842e7675bfc18d306c2b4')]:
 patch=p/name;data=subprocess.check_output(['git','diff','--binary',revision,'--','src','tests'],cwd=w)
 if patch.exists():assert patch.read_bytes()==data
 else:patch.write_bytes(data)
 available=subprocess.check_output(['git','ls-tree','-r','--name-only',revision],cwd=w,text=True).splitlines()
 raw=subprocess.check_output(['git','archive',revision,'--',*[n for n in source if n in available]],cwd=w)
 with tempfile.TemporaryDirectory(prefix='emaxx-owned-symbol-replay-') as tmp:
  root=Path(tmp)
  with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
   for entry in archive.getmembers():
    if entry.isfile():
     f=root/entry.name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(archive.extractfile(entry).read());f.chmod(0o755 if entry.mode&0o111 else 0o644)
  subprocess.run(['git','apply',str(patch)],cwd=root,check=True)
  assert all(sha(root/n)==v['sha256'] and oct((root/n).stat().st_mode&0o777)==v['mode'] for n,v in source.items())
 replays[name]=dict(base=revision,sha256=sha(patch),source_inputs_verified=len(source))
gnu=p.parent/'rebuilt-2026-10-01/emacs'
review=dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=gnu,text=True).strip(),sources={name:sha(gnu/'src'/name) for name in ['lread.c','alloc.c','data.c','fns.c','lisp.h']},mechanisms=['lread.c:init_obarray_once initializes and roots this Emacs process\'s canonical symbols','data.c:Feq and lisp.h:EQ compare Lisp identity, not symbol spelling','fns.c:hashtest_eq/eql/equal contain this editor\'s canonical symbol words','fns.c:get_hash_table_user_test and mark_fns share/retain actual descriptor fields for the editor lifetime'],deviations=['Editor entry uses an Rc owner and scoped active selection because a single embedding process can contain successive or nested editors; allocator ownership is already serialized. No guard is added to each VM instruction.','Existing static descriptor allocations remain leaked; only their pool and Lisp roots now belong to the editor. Reclamation and honest physical accounting remain required.','Private interpreter image clones still share symbol names. Payload fields, IDs and weak enumeration adapters are not removed. No completed ownership or performance claim.'])
(p/'gnu-owner-review.json').write_text(json.dumps(review,indent=2)+'\n')
result=dict(checkpoint='source319 unfinished editor-owned symbol draft4',base=base,source_inputs_verified=len(source),strict='passed with zero warnings',probes=probes,replays=replays,retained_initial_failures=['draft1 Clippy unused import','draft2 public launcher missing dependency search path','draft3 actual second-editor hash descriptor identity mismatch'],qualification='Only strict checks and bounded public API probes are audited here. The original source316 name-property negative now matches GNU. The text-equality shortcut initially hid foreign descriptors; pointer equality exposed the recorded draft3 mismatch, repaired by owner-specific descriptors in draft4. Full selected/platform/frozen/terminal/native/image/GC validation and remaining ownership/allocation work are open. No per-instance allocated-field or performance completion claim.',goal_complete=False)
(p/'public-audit.json').open('x').write(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['checkpoint','source_inputs_verified','strict','replays','retained_initial_failures','goal_complete']},indent=2))
