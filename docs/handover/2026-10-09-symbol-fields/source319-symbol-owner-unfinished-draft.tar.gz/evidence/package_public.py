from pathlib import Path
import gzip,hashlib,io,json,re,tarfile
p=Path(__file__).resolve().parent
w=p.parent/'recovered-2026-10-09/symbol-ownership/emaxx'
destination=w/'docs/handover/2026-10-09-symbol-fields'
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda f:json.loads(f.read_text())
audit=read(p/'public-audit.json');assert audit['source_inputs_verified']==563
# Verify all raw gate names, including the 208 predecessor selectors.
gate=p/'obarray-draft4-gate';source=read(p/'obarray-draft4-hash-owner/source.json')
assert read(gate/'source.json')==read(gate/'source-after.json')==source
selected=read(gate/'selection.json');assert len(selected)==len(set(selected))==229
assert set(read(p.parent/'symbol-payload-api-2026-10-09/payload-draft1-gate/selection.json'))<=set(selected)
for label in ['build','inventory','focused']:
 r=read(gate/(label+'.json'));assert r['exit_code']==0
 for stream in ['stdout','stderr']:
  data=(gate/(label+'.'+stream)).read_bytes();assert sha(data)==r[stream+'_sha256']
  assert not re.search(rb'^warning(?:\[.*?\])?:',data,re.M)
verdicts=re.findall(r'^test (\S+) \.\.\. (ok|FAILED|ignored)\s*$',(gate/'focused.stdout').read_text(),re.M)
assert len(verdicts)==229 and dict(verdicts)==dict.fromkeys(selected,'ok')
listing=[line[:-6] for line in (gate/'inventory.stdout').read_text().splitlines() if line.endswith(': test')]
old=p.parent/'symbol-payload-api-2026-10-09/payload-draft1-gate/inventory.stdout'
assert sorted(listing)==sorted(line[:-6] for line in old.read_text().splitlines() if line.endswith(': test'))
assert len(listing)==3069
binary=read(gate/'binary.json');assert sha(Path(binary['retained']).read_bytes())==binary['sha256']
gate_audit=dict(status='passed',selected=229,prior_controls_retained=208,inventory=3069,unchanged_full_inventory=True,binary_sha256=binary['sha256'],source_inputs_verified=563)
(p/'gate-selected-audit.json').write_text(json.dumps(gate_audit,indent=2)+'\n')
members={};excluded=[]
labels=['obarray-draft1','obarray-draft2','obarray-draft2-public','obarray-draft2-public-deps','obarray-draft3-identity','obarray-draft3-public','obarray-draft4-hash-owner','obarray-draft4-public','obarray-draft4-gate']
for label in labels:
 for path in sorted((p/label).rglob('*')):
  if not path.is_file():continue
  name=str(path.relative_to(p));data=path.read_bytes()
  if path.name in ['libtest','public-instances'] or path.suffix in ['.pdmp','.rlib']:
   excluded.append(dict(path=str(path),bytes=len(data),sha256=sha(data)))
  else:members['evidence/'+name]=data
for name in ['public-audit.json','gate-selected-audit.json','gnu-owner-review.json','obarray-draft4.patch','obarray-cumulative-draft4.patch','audit_public.py','validate.py','ordinary.py','continue_selected.py','probe_instance_symbols.py','probe_instance_symbols_deps.py','probe_instance_symbols_identity.py','probe_instance_symbols_hash_owner.py','package_public.py','base.json']:
 members['evidence/'+name]=(p/name).read_bytes()
members['contents.json']=(json.dumps({name:dict(bytes=len(data),sha256=sha(data)) for name,data in members.items()},indent=2)+'\n').encode()
buffer=io.BytesIO()
with gzip.GzipFile(fileobj=buffer,mode='wb',mtime=0) as zipped:
 with tarfile.open(fileobj=zipped,mode='w') as archive:
  for name,data in sorted(members.items()):
   info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
data=buffer.getvalue();path=destination/'source319-symbol-owner-unfinished-draft.tar.gz'
assert not path.exists();path.write_bytes(data)
with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as archive:
 assert set(archive.getnames())==set(members)
 assert all(archive.extractfile(name).read()==data for name,data in members.items())
manifest=dict(checkpoint='source319 separately packaged unfinished editor-owned symbol draft4',base=audit['base'],cumulative_base='30fa6e5b669c5cbd26e842e7675bfc18d306c2b4',archive=dict(path=path.name,bytes=len(data),sha256=sha(data),members=len(members)),public_audit=audit,gate_audit=gate_audit,excluded_retained_inputs=excluded,qualification='This patch is unapplied to PR82 runtime. Only strict checks, 229 gate controls and bounded public ownership probes are complete in this archive. Every original failure is retained, including the hash descriptor mismatch exposed by true symbol identity. Release/ordinary validation is running separately. Allocated fields, private interpreter image-copy isolation, other process-wide Lisp roots, descriptor allocation ownership, physical accounting and all final validation/performance requirements remain open. The name lookup wrapper compares immutable host text only for canonical lookup; Lisp equality compares objects. No completed ownership or performance claim.',goal_complete=False)
(destination/'source319-symbol-owner-unfinished-draft-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest['archive']))
