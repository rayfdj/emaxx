(progn
  (setq purify-flag nil)
  (garbage-collect)
  (prin1
   (list (eq (hash-table-test (make-hash-table :test 'eq)) 'eq)
         (eq (hash-table-test (make-hash-table :test 'eql)) 'eql)
         (eq (hash-table-test (make-hash-table :test 'equal)) 'equal)
         (eq (type-of 17) 'integer)
         (eq (type-of :owned-symbol) 'symbol)))
  (terpri))
