from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).resolve().parent
w=p.parent/'recovered-2026-10-09/symbol-obarray/emaxx'
g=p.parent/'rebuilt-2026-10-01/emacs'
old=p.parent/'symbol-registry-2026-10-09/isolation-flushed'
out=p/'obarray-draft2-public';out.mkdir(exist_ok=False)
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
source=json.loads((p/'obarray-draft2/source.json').read_text())
env=json.loads((p/'obarray-draft2/environment.json').read_text())
env.pop('EMAXX_FIXTURE_IMAGE_DIR');env.pop('EMAXX_IMAGE_TEMPLATE')
def verify():
 assert all(sha(w/n)==v['sha256'] and oct((w/n).stat().st_mode&0o777)==v['mode'] for n,v in source.items())
verify()
for name in ['first.el','second.el','public_instances.rs']:(out/name).write_bytes((old/name).read_bytes())
(out/'hash-types.el').write_text('''(progn
  (setq purify-flag nil)
  (garbage-collect)
  (prin1
   (list (eq (hash-table-test (make-hash-table :test 'eq)) 'eq)
         (eq (hash-table-test (make-hash-table :test 'eql)) 'eql)
         (eq (hash-table-test (make-hash-table :test 'equal)) 'equal)
         (eq (type-of 17) 'integer)
         (eq (type-of :owned-symbol) 'symbol)))
  (terpri))
''')
record=dict(status='building',source_inputs=source,environment_overrides=env,original_inputs_unchanged=all(sha(out/n)==sha(old/n) for n in ['first.el','second.el','public_instances.rs']),inputs={n:sha(out/n) for n in ['first.el','second.el','public_instances.rs','hash-types.el']},processes=[],goal_complete=False)
def save():(out/'run.json').write_text(json.dumps(record,indent=2)+'\n')
def run(label,command,timeout=300):
 print('START',label,flush=True);start=time.monotonic()
 with (out/(label+'.stdout')).open('wb') as stdout,(out/(label+'.stderr')).open('wb') as stderr:
  try:
   result=subprocess.run(command,cwd=w,env={**os.environ,**env},stdout=stdout,stderr=stderr,timeout=timeout);code=result.returncode;timed_out=False
  except subprocess.TimeoutExpired:code=None;timed_out=True
 row=dict(label=label,command=command,exit_code=code,timed_out=timed_out,timeout_seconds=timeout,elapsed_seconds=time.monotonic()-start,stdout_sha256=sha(out/(label+'.stdout')),stderr_sha256=sha(out/(label+'.stderr')))
 record['processes'].append(row);save();verify();print('END',label,code,flush=True)
 return code
save()
assert run('build',['cargo','build','--locked','--offline','--release','--all-features','--lib','--message-format=json'],1800)==0
rows=[json.loads(line) for line in (out/'build.stdout').read_text().splitlines() if line.startswith('{')]
libs=[r for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']=='emaxx' and 'lib' in r['target']['kind'] and not r['profile']['test']]
assert len(libs)==1
library=next(Path(n) for n in libs[0]['filenames'] if n.endswith('.rlib'))
record['library']=dict(path=str(library),sha256=sha(library),artifact=libs[0])
links=sorted({path for r in rows if r.get('reason')=='build-script-executed' for path in r.get('linked_paths',[])})
command=['rustc','--edition=2024','-C','opt-level=3','-C','lto=fat','-C','codegen-units=1','--extern','emaxx='+str(library),'-L','dependency='+str(library.parent)]
for path in links:command.extend(['-L',path])
command.extend([str(out/'public_instances.rs'),'-o',str(out/'public-instances')])
assert run('compile',command,1200)==0
record['artifacts']={str(f):sha(f) for f in [library,out/'public-instances',g/'src/emacs',g/'src/emacs.pdmp']};save()
comparisons=[]
for label,first,second in [('original-name','first.el','second.el'),('hash-types','hash-types.el','hash-types.el')]:
 codes=[]
 for kind,program in [('first',first),('second',second)]:
  codes.append(run(label+'-gnu-'+kind,[str(g/'src/emacs'),'-Q','--batch','-l',str(out/program)]))
 codes.append(run(label+'-emaxx-two-editors',[str(out/'public-instances'),str(out/first),str(out/second)]))
 expected=(out/(label+'-gnu-first.stdout')).read_bytes()+(out/(label+'-gnu-second.stdout')).read_bytes()
 actual=(out/(label+'-emaxx-two-editors.stdout')).read_bytes()
 comparisons.append(dict(label=label,exit_codes=codes,gnu=expected.decode(errors='replace'),emaxx=actual.decode(errors='replace'),matches=all(code==0 for code in codes) and actual==expected and len(actual.splitlines())==2))
 print(json.dumps(comparisons[-1]),flush=True)
for f,digest in record['artifacts'].items():assert sha(Path(f))==digest
verify()
record.update(status='terminal; retain every actual result',source_unchanged=True,comparisons=comparisons)
save()
