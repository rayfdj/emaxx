from pathlib import Path
import datetime,json,os,subprocess,time
p=Path(__file__).resolve().parent
record=dict(status='running',pid=os.getpid(),started=datetime.datetime.now(datetime.timezone.utc).isoformat(),results=[],goal_complete=False)
state=p/'continued-validation-state.json'
assert not state.exists()
def save():state.write_text(json.dumps(record,indent=2)+'\n')
save()
for label,command in [('release',['python3',str(p/'validate.py'),'obarray-draft4-release','focus','release']),('ordinary',['python3',str(p/'ordinary.py')])]:
 record.update(status='running '+label);save();start=time.monotonic()
 with (p/(label+'-supervisor.log')).open('wb') as log:
  code=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT).returncode
 record['results'].append(dict(stage=label,command=command,exit_code=code,elapsed_seconds=time.monotonic()-start));save()
 print(label,code,flush=True)
 if code:break
record.update(status='terminal; inspect every raw result');save()
raise SystemExit(code)
