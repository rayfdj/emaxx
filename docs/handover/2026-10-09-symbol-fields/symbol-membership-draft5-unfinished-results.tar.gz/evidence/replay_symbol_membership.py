from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile
import tempfile

p = Path(__file__).resolve().parent
r = p.parents[2]
base = '999362622a68d6508c356541422f7a48ae6e2175'
available = set(subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', base], cwd=r, text=True).splitlines())
sha = lambda data: hashlib.sha256(data).hexdigest()
results = []
for version in range(1, 6):
    directory = p / ('symbol-membership-draft' + str(version))
    source = json.loads((directory / 'source.json').read_text())
    patch = directory / 'tracked.patch'
    data = subprocess.check_output(['git', 'archive', base, '--', *[name for name in source if name in available]], cwd=r)
    with tempfile.TemporaryDirectory(prefix='emaxx-membership-replay-') as temporary:
        root = Path(temporary)
        with tarfile.open(fileobj=io.BytesIO(data)) as archive:
            for entry in archive.getmembers():
                if not entry.isfile():
                    continue
                target = root / entry.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(archive.extractfile(entry).read())
                target.chmod(0o755 if entry.mode & 0o111 else 0o644)
        subprocess.run(['git', 'apply', str(patch)], cwd=root, check=True)
        for name, entry in source.items():
            assert sha((root / name).read_bytes()) == entry['sha256'], (version, name)
            assert oct((root / name).stat().st_mode & 0o777) == entry['mode'], (version, name)
    results.append(dict(draft=version, source_inputs=len(source), patch_sha256=sha(patch.read_bytes()), source_sha256=sha((directory / 'source.json').read_bytes()), replayed=True))
    print(json.dumps(results[-1]), flush=True)
result = dict(base=base, results=results, goal_complete=False,
    qualification='Every archived intermediate patch reproduces its captured source bytes and executable modes. This is source reconstruction, not validation or acceptance of any failed draft.')
with (p / 'symbol-membership-replay.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
