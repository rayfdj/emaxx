from pathlib import Path
import datetime
import json
import os
import subprocess
import sys

p = Path(__file__).resolve().parent
path = p / 'symbol-membership-draft5-selected-queue.json'
assert not path.exists(), 'Inspect the existing queue before restarting'
state = dict(pid=os.getpid(), started=datetime.datetime.now(datetime.timezone.utc).isoformat(), results=[], goal_complete=False)
for profile in ['gate', 'release']:
    label = 'symbol-membership-draft5-selected-' + profile
    command = [sys.executable, '-u', str(p / 'validate_membership_selected.py'), label, profile]
    state.update(status='running ' + profile, command=command)
    path.write_text(json.dumps(state, indent=2) + '\n')
    print(state['status'], flush=True)
    result = subprocess.run(command, cwd=p.parents[2])
    state['results'].append(dict(profile=profile, exit_code=result.returncode))
    if result.returncode:
        state['status'] = 'failed; later profiles not started'
        path.write_text(json.dumps(state, indent=2) + '\n')
        raise SystemExit(result.returncode)
state['status'] = 'both profiles completed; audit raw results'
path.write_text(json.dumps(state, indent=2) + '\n')
