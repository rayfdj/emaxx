from pathlib import Path
import json

p = Path(__file__).resolve().parent
ns = {'__file__': str(p / 'package_source323_base.py')}
exec((p / 'package_source323_base.py').read_text(), ns)
destination = p / 'pending-publication-source324'
destination.mkdir(exist_ok=True)
ns['destination'] = destination
read = lambda name: json.loads((p / name).read_text())
entries = lambda names: [('evidence/' + name, p / name) for name in names]
replay = read('symbol-membership-replay.json')
assert len(replay['results']) == 5 and all(row['replayed'] for row in replay['results'])
audit = read('symbol-membership-draft5-probe-audit.json')
assert audit['source_inputs'] == 580 and len(audit['tests']) == 5
ns['package']('symbol-membership-draft5-unfinished-results',
    entries(['symbol-membership-draft' + str(index) for index in range(1, 6)] + [
        'source324-unintern-identity-negative', 'source324-unintern-identity-valid-negative',
        'source324-membership-edge-negatives', 'source324-membership-store-negatives',
        'membership-lifetime-gnu', 'membership-lifetime-return-gnu']),
    entries(['symbol-membership-replay.json', 'replay_symbol_membership.py',
        'symbol-membership-draft5-probe-audit.json', 'symbol-membership-c-mapping.json',
        'validate_symbol_membership.py', 'validate_membership_selected.py', 'membership_selected_queue.py',
        'observe_unintern_identity.py', 'observe_membership_edges.py', 'observe_membership_stores.py',
        'source324-unintern-identity-probe.el', 'source324-unintern-identity-probe-v2.el',
        'membership-lifetime.el', 'source324-application.json', 'source324-source.json',
        'package_source323_base.py', Path(__file__).name]),
    dict(checkpoint='isolated and unfinished symbol membership draft5',
        patch_base=replay['base'], replay=replay, selected_probe=audit,
        c_mapping=read('symbol-membership-c-mapping.json'),
        qualification='All five intermediate patches replay their captured bytes/modes; latest has580 inputs. Draft1 compiler warnings, draft2 malformed printing/boolean fixture failures, and draft4 minimal-interpreter lambda setup failure remain preserved. Draft5 passes strict zero-warning checks and five controls for same-name fields/membership, printing, nil/t identity, weak GC lifetime, image cloning and dump restoration. Initial ordinary identity input had a trailing delimiter and both processes failed; its corrected successor exits zero in allthree editors and distinguishes34 GNU true predicates from22 false predicates in both main323 and source324-production. Edge --eval programs retain extra trailing delimiters consumed after the first form; their raw commands and outputs are preserved and they are not loadable fixture certificates. The lifetime probe initially retained the last detached symbol in GNU while the helper was active; returning before collection produces actual reclamation, with the original output retained and its exact C root undiagnosed. The same-name constant store controls expose an existing defect that this draft has not repaired. The402-control gate/release queue is separate and ongoing, not certified here. No clean published platform, native-mode, full frozen, memory or speed claim follows from this unfinished draft.'))
