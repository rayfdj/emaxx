from pathlib import Path
import json
import subprocess
import sys

p = Path(__file__).resolve().parent
profile = sys.argv[2]
assert profile in ['gate', 'release']
ns = {'__file__': str(p / 'validate_symbol_membership.py')}
exec((p / 'validate_symbol_membership.py').read_text().split("if 'strict' in sys.argv:")[0], ns)
out, w, run, manifest, sha = (ns[name] for name in ['out', 'w', 'run', 'manifest', 'sha'])
assert manifest() == json.loads((p / 'symbol-membership-draft5/source-after.json').read_text())
build = run('build', ['cargo', 'test', '--locked', '--offline', '--profile', profile,
    '--all-features', '--lib', '--no-run', '--message-format=json'])
artifacts = [entry for line in build.read_text().splitlines() if line.startswith('{')
    and (entry := json.loads(line)).get('reason') == 'compiler-artifact'
    and entry.get('executable') and 'lib' in entry['target']['kind'] and entry['profile']['test']]
assert len(artifacts) == 1
binary = Path(artifacts[0]['executable'])
subprocess.run(['cp', '-c', str(binary), str(out / 'libtest')], check=True)
assert sha(binary) == sha(out / 'libtest')
(out / 'binary.json').write_text(json.dumps(dict(original=str(binary), retained=str(out / 'libtest'), sha256=sha(binary)), indent=2) + '\n')
listing = run('inventory', [str(binary), '--list'])
inventory = sorted(line[:-6] for line in listing.read_text().splitlines() if line.endswith(': test'))
old = json.loads((p.parent / 'allocated-symbols-2026-10-10/fields-identity-draft5-gate/selection.json').read_text())
assert len(old) == 397
added = [name for name in inventory if 'standard_unintern_' in name]
assert len(added) == 5
selected = sorted(set(old) | set(added))
assert len(selected) == 402 and set(selected) <= set(inventory)
(out / 'selection.json').write_text(json.dumps(selected, indent=2) + '\n')
log = run('selected', [str(binary), '--exact', '--test-threads=1', *selected])
assert 'test result: ok. 402 passed; 0 failed; 0 ignored;' in log.read_text()
(out / 'source-after.json').write_text(json.dumps(manifest(), indent=2) + '\n')
print('PASS', profile, '402 selected controls; full inventory', len(inventory), flush=True)
