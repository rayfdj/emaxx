from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

p = Path(__file__).resolve().parent
g = p.parent / 'rebuilt-2026-10-01/emacs'
u = p.parent / 'recovered-2026-10-12/symbol-identity/emaxx'
f = p.parent / 'allocated-symbols-2026-10-10'
out = p / 'source324-membership-edge-negatives'
out.mkdir(exist_ok=False)
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
programs = {
    'printing': '''(prin1
      (mapcar (lambda (suffix)
        (let* ((name (concat "detached-print-" suffix))
               (old (intern name)))
          (unintern old)
          (let ((new (intern name)) (print-gensym t))
            (list (string= (prin1-to-string old) (concat "#:" name))
                  (string= (prin1-to-string new) name)
                  (not (eq old new))))))
        (list "one" "λ-two"))))''',
    'builtin-booleans': '''(prin1
      (mapcar (lambda (name)
        (let* ((old (intern name))
               (removed (unintern old))
               (new (intern (copy-sequence name))))
          (list removed (not (eq old new))
                (null (intern-soft old))
                (eq (intern-soft new) new)
                (null (unintern old))
                (eq (intern-soft name) new)
                (eq (car (read-from-string name)) new)
                (not (boundp new)) (not (fboundp new)))))
        (list "nil" "t"))))''',
}
env = json.loads((f / 'fields-identity-draft5-ordinary/environment.json').read_text())
editors = [('gnu', g / 'src/emacs'), ('source324-production', u / 'target/release/emaxx')]
inputs = {str(path): sha(path) for _, exe in editors for path in [exe, exe.with_suffix('.pdmp')]}
record = dict(inputs=inputs, environment_overrides=env, results=[], goal_complete=False,
    qualification='Separate ordinary same-input observations using the retained identity5 production bytes, which match source324. Existing executable/image provenance and retention are in the draft5 ordinary archive. No repair or passing platform gate is claimed.')
for name, program in programs.items():
    (out / (name + '.el')).write_text(program + '\n')
    for editor, exe in editors:
        command = [str(exe), '-Q', '--batch', '--eval', program]
        start = time.monotonic()
        result = subprocess.run(command, cwd=u, env={**os.environ, **env}, capture_output=True, timeout=180)
        stem = name + '-' + editor
        (out / (stem + '.stdout')).write_bytes(result.stdout)
        (out / (stem + '.stderr')).write_bytes(result.stderr)
        row = dict(case=name, editor=editor, command=command, cwd=str(u), exit_code=result.returncode, elapsed_seconds=time.monotonic() - start, timeout_seconds=180, stdout_sha256=sha(out / (stem + '.stdout')), stderr_sha256=sha(out / (stem + '.stderr')))
        record['results'].append(row)
        (out / 'manifest.json').write_text(json.dumps(record, indent=2) + '\n')
        print(name, editor, result.returncode, result.stdout.decode().strip(), result.stderr.decode()[:350], flush=True)
for name, digest in inputs.items():
    assert sha(Path(name)) == digest
record['inputs_unchanged'] = True
(out / 'manifest.json').write_text(json.dumps(record, indent=2) + '\n')
