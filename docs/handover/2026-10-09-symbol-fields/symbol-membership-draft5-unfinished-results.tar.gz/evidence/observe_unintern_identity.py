from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import time

p = Path(__file__).resolve().parent
r = p.parents[2]
f = p.parent / 'allocated-symbols-2026-10-10'
g = p.parent / 'rebuilt-2026-10-01/emacs'
u = p.parent / 'recovered-2026-10-12/symbol-identity/emaxx'
out = p / 'source324-unintern-identity-valid-negative'
out.mkdir(exist_ok=False)
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda path: json.loads(path.read_text())
original = (p / 'source324-unintern-identity-probe.el').read_text()
assert original.endswith('(concat "second" "-λ")))))\n')
fixture = p / 'source324-unintern-identity-probe-v2.el'
fixture.write_text(original[:-2] + '\n')
source = read(p / 'source324-source.json')
for name, row in source.items():
    if name != 'tests/native_comp_identity.rs':
        assert sha(u / name) == row['sha256'], name
env = read(f / 'fields-identity-draft5-ordinary/environment.json')
executables = [
    ('gnu', g / 'src/emacs'),
    ('source323-main', r / 'target/compat-subject/tty-source323/emaxx'),
    ('source324-production', u / 'target/release/emaxx'),
]
inputs = {str(path): sha(path) for _, exe in executables for path in [exe, exe.with_suffix('.pdmp')]}
inputs[str(fixture)] = sha(fixture)
old_inputs = read(f / 'fields-identity-draft5-ordinary-audit.json')['retained_inputs']
for row in old_inputs:
    assert inputs[row['original']] == row['sha256']
terminal_inputs = read(p / 'source323-terminal/command.json')['inputs']
for path in [executables[1][1], executables[1][1].with_suffix('.pdmp')]:
    assert inputs[str(path)] == terminal_inputs[str(path)]
record = dict(observed=datetime.datetime.now(datetime.timezone.utc).isoformat(), fixture_sha256=sha(fixture), inputs=inputs, environment_overrides=env, results=[],
    qualification='Ordinary unchanged program in GNU, source323 main retained subject and identity5 retained executable. Every identity5 runtime input equals source324; only the native identity fixture differs. No new published-source build or full correctness claim. The first probe with an extra closing parenthesis remains a separate failed attempt.', goal_complete=False)


def save():
    (out / 'manifest.json').write_text(json.dumps(record, indent=2) + '\n')


save()
for label, exe in executables:
    command = [str(exe), '-Q', '--batch', '--load', str(fixture)]
    start = time.monotonic()
    try:
        result = subprocess.run(command, cwd=u, env={**os.environ, **env}, capture_output=True, timeout=180)
        stdout, stderr, status, timed_out = result.stdout, result.stderr, result.returncode, False
    except subprocess.TimeoutExpired as error:
        stdout, stderr, status, timed_out = error.stdout or b'', error.stderr or b'', None, True
    (out / (label + '.stdout')).write_bytes(stdout)
    (out / (label + '.stderr')).write_bytes(stderr)
    row = dict(label=label, command=command, cwd=str(u), exit_code=status, timed_out=timed_out, timeout_seconds=180, elapsed_seconds=time.monotonic() - start, stdout_sha256=sha(out / (label + '.stdout')), stderr_sha256=sha(out / (label + '.stderr')))
    (out / (label + '.json')).write_text(json.dumps(row, indent=2) + '\n')
    record['results'].append(row)
    save()
    print(label, status, stdout.decode().strip(), stderr.decode()[:600], flush=True)
for name, digest in inputs.items():
    assert sha(Path(name)) == digest
record['inputs_unchanged'] = True
record['all_processes_successful'] = all(row['exit_code'] == 0 for row in record['results'])
save()
