from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

p = Path(__file__).resolve().parent
g = p.parent / 'rebuilt-2026-10-01/emacs'
u = p.parent / 'recovered-2026-10-12/symbol-identity/emaxx'
f = p.parent / 'allocated-symbols-2026-10-10'
out = p / 'source324-membership-store-negatives'
out.mkdir(exist_ok=False)
program = '''(mapcar
 (lambda (name)
   (let* ((old (intern name))
          (previous (symbol-value old))
          (removed (unintern old))
          (new (intern (copy-sequence name)))
          (keyword (string-prefix-p ":" name)))
     (list removed (not (eq old new))
           (eq (symbol-value old) previous)
           (eq (boundp new) keyword)
           (eq (special-variable-p new) keyword)
           (condition-case err (progn (set old 43) nil)
             (setting-constant (eq (cadr err) old)))
           (condition-case err
               (progn (set new 71) (and (not keyword) (= (symbol-value new) 71)))
             (setting-constant (and keyword (eq (cadr err) new))))
           (condition-case err
               (progn (makunbound new) (and (not keyword) (not (boundp new))))
             (setting-constant (and keyword (eq (cadr err) new)))))))
 (list "nil" "t" "most-positive-fixnum" "most-negative-fixnum" ":detached-store-λ"))'''
(out / 'body.el').write_text(program + '\n')
path = out / 'program.el'
path.write_text('(prin1\n' + program + ')\n')
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
env = json.loads((f / 'fields-identity-draft5-ordinary/environment.json').read_text())
editors = [('gnu', g / 'src/emacs'), ('source324-production', u / 'target/release/emaxx')]
inputs = {str(path): sha(path) for _, exe in editors for path in [exe, exe.with_suffix('.pdmp')]}
record = dict(inputs=inputs, environment_overrides=env, results=[], goal_complete=False,
    qualification='Separate unchanged loadable program in GNU and retained identity5 production, whose runtime bytes match source324. These controls test the remaining object membership/constant adapter; no prototype or clean platform certification follows.')
for editor, exe in editors:
    command = [str(exe), '-Q', '--batch', '--load', str(path)]
    start = time.monotonic()
    result = subprocess.run(command, cwd=u, env={**os.environ, **env}, capture_output=True, timeout=180)
    (out / (editor + '.stdout')).write_bytes(result.stdout)
    (out / (editor + '.stderr')).write_bytes(result.stderr)
    row = dict(editor=editor, command=command, cwd=str(u), exit_code=result.returncode,
               elapsed_seconds=time.monotonic() - start, timeout_seconds=180,
               stdout_sha256=sha(out / (editor + '.stdout')), stderr_sha256=sha(out / (editor + '.stderr')))
    record['results'].append(row)
    (out / 'manifest.json').write_text(json.dumps(record, indent=2) + '\n')
    print(editor, result.returncode, result.stdout.decode().strip(), result.stderr.decode()[:500], flush=True)
assert all(sha(Path(path)) == digest for path, digest in inputs.items())
record['inputs_unchanged'] = True
(out / 'manifest.json').write_text(json.dumps(record, indent=2) + '\n')
