from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time

p = Path(__file__).resolve().parent
w = p.parent / 'recovered-2026-10-13/symbol-membership/emaxx'
g = p.parent / 'rebuilt-2026-10-01/emacs'
out = p / sys.argv[1]
out.mkdir(exist_ok=False)
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
paths = set(json.loads((p / 'source324-source.json').read_text()))
paths.update(['tests/fixtures/symbol-standard-unintern-identity.el', 'tests/fixtures/symbol-standard-unintern-identity.expected'])


def manifest():
    return {name: dict(sha256=sha(w / name), mode=oct((w / name).stat().st_mode & 0o777)) for name in sorted(paths)}


frozen = manifest()
assert len(frozen) == 574
(out / 'source.json').write_text(json.dumps(frozen, indent=2) + '\n')
(out / 'tracked.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary'], cwd=w))
overrides = dict(LANG='C', LC_ALL='C', CARGO_BUILD_JOBS='1', CARGO_NET_OFFLINE='true',
    RUST_TEST_THREADS='1', RUST_MIN_STACK='134217728', EMAXX_GC_VERIFY='1',
    EMAXX_IMAGE_TEMPLATE='1', EMAXX_GNU_SOURCE_DIRECTORY=str(g),
    EMAXX_DUMP_SOURCE_DIRECTORY=str(g), EMACS_TEST_DIRECTORY=str(g / 'test'),
    EMAXX_FIXTURE_IMAGE_DIR=str(out / 'fixture-images'))
(out / 'environment.json').write_text(json.dumps(overrides, indent=2) + '\n')


def run(name, command):
    assert manifest() == frozen
    print('START', name, flush=True)
    start = time.monotonic()
    with (out / (name + '.stdout')).open('xb') as stdout, (out / (name + '.stderr')).open('xb') as stderr:
        result = subprocess.run(command, cwd=w, env={**os.environ, **overrides}, stdout=stdout, stderr=stderr)
    row = dict(command=command, cwd=str(w), exit_code=result.returncode, elapsed_seconds=time.monotonic() - start, stdout_sha256=sha(out / (name + '.stdout')), stderr_sha256=sha(out / (name + '.stderr')))
    (out / (name + '.json')).write_text(json.dumps(row, indent=2) + '\n')
    print('END', name, result.returncode, round(row['elapsed_seconds'], 2), flush=True)
    assert manifest() == frozen
    if result.returncode:
        print((out / (name + '.stderr')).read_text()[-5000:], flush=True)
        print((out / (name + '.stdout')).read_text()[-5000:], flush=True)
        raise SystemExit(result.returncode)
    for stream in ['stdout', 'stderr']:
        assert not re.search(r'^warning(?:\[.*?\])?:', (out / (name + '.' + stream)).read_text(), re.M), 'compiler warning retained; resolve its cause'
    return out / (name + '.stdout')


if 'strict' in sys.argv:
    for name, command in [
        ('fmt', ['cargo', 'fmt', '--all', '--', '--check']),
        ('check', ['cargo', 'check', '--locked', '--offline', '--all-targets', '--all-features']),
        ('clippy', ['cargo', 'clippy', '--locked', '--offline', '--all-targets', '--all-features', '--', '-D', 'warnings']),
        ('diff', ['git', 'diff', '--check']),
    ]:
        run(name, command)
if 'probe' in sys.argv:
    run('probe', ['cargo', 'test', '--locked', '--offline', '--profile', 'gate', '--all-features', '--lib', 'lisp::primitives::tests::standard_unintern_detaches_the_object_and_preserves_its_fields', '--', '--exact', '--nocapture'])
    assert 'test result: ok. 1 passed; 0 failed; 0 ignored;' in (out / 'probe.stdout').read_text()
(out / 'source-after.json').write_text(json.dumps(manifest(), indent=2) + '\n')
