from pathlib import Path
import hashlib
import json
import re

p = Path(__file__).resolve().parent
w = p.parent / 'recovered-2026-10-08/symbol-plists/emaxx'
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
receipt = read(p / 'source314-eglot-replay/state.json')
tail = read(p / 'source314-macos-tail/state.json')
assert receipt['exit_code'] == 0 and receipt['source_unchanged']
assert receipt['source_inputs'] == tail['source_inputs']
assert receipt['environment_overrides'] == tail['environment_overrides']
assert len(receipt['raw_directories']) == 1
r = Path(receipt['raw_directories'][0])
t = Path(tail['raw_directories'][0])
name = 'test/lisp/progmodes/eglot-tests.el'
contract, prior = read(r / 'contract.json'), read(t / 'contract.json')
summary = read(r / 'summary.json')
assert contract['files'] == [name] and summary['files'] == [name]
assert summary['mode'] == 'run' and summary['name_filter'] is None
assert contract['selector'] == prior['selector']
for key in contract['provenance']:
    if key not in ['subject_git_head', 'subject_git_dirty']:
        assert contract['provenance'][key] == prior['provenance'][key], key
assert contract['provenance']['timeout_seconds'] == 180
assert summary['total_files'] == summary['matching_files'] == 1
assert summary['matching_outcomes'] == summary['total_outcomes'] == 52
assert summary['mismatching_outcomes'] == 0 and not summary['mismatches'] and not summary['unsuccessful_files']
inventory = {}
for line in (w / 'compat/oracle_tests_all.txt').read_text().splitlines():
    match = re.fullmatch(r'(\S+): discovered=(\d+) selected=(\d+)', line)
    if match:
        current = match[1]
        inventory[current] = dict(discovered=int(match[2]), selected=int(match[3]), names=[])
    elif line.strip():
        inventory[current]['names'].append(line.strip())
expected = inventory[name]
directory = (r / name).with_suffix('.compat')
execution = read(directory / 'execution.json')
assert execution['contract_sha256'] == sha(r / 'contract.json')
assert set(execution['sha256']) == {runner + suffix for runner in ['oracle', 'emaxx'] for suffix in ['.json', '.log', '.execution.json']}
assert all(sha(directory / path) == digest for path, digest in execution['sha256'].items())
comparison = read(directory / 'comparison.json')
assert comparison['matches'] and not comparison['issues'] and not comparison['execution_issues']
assert comparison['matching_outcomes'] == 52 and comparison['mismatching_outcomes'] == 0
pair = {}
counts = {}
for runner in ['oracle', 'emaxx']:
    report = read(directory / (runner + '.json'))
    process = read(directory / (runner + '.execution.json'))['process']
    assert process['exit_code'] == 0 and not process['timed_out'] and process['test_started'] and process['timeout_phase'] is None
    assert report['file'] == name and report['selector'] == contract['selector']
    assert report['file_status'] == 'loaded' and report['file_error'] is None
    assert len(report['discovered_tests']) == expected['discovered']
    assert len(report['selected_tests']) == expected['selected'] and set(report['selected_tests']) == set(expected['names'])
    results = report['results']
    assert len(results) == len({row['name'] for row in results}) == expected['selected'] == 52
    assert {row['name'] for row in results} == set(expected['names'])
    observed = {status: sum(row['status'] == status for row in results) for status in ['passed', 'failed', 'skipped']}
    observed.update(total=len(results), unexpected=sum(not row['expected'] for row in results))
    assert observed == report['summary'] == summary['runner_summaries'][runner]
    assert observed == dict(total=52, passed=45, failed=0, skipped=7, unexpected=0)
    pair[runner] = {row['name']: row for row in results}
    counts[runner] = observed
for test_name, oracle in pair['oracle'].items():
    subject = pair['emaxx'][test_name]
    for key in ['status', 'expected', 'condition_type']:
        assert oracle[key] == subject[key]
    if oracle['status'] != 'passed':
        assert oracle['message'] == subject['message']
assert pair['oracle']['eglot-test-auto-reconnect']['status'] == 'passed'
assert pair['emaxx']['eglot-test-auto-reconnect']['status'] == 'passed'
old = read((t / name).with_suffix('.compat') / 'oracle.json')
assert [row['name'] for row in old['results'] if not row['expected']] == ['eglot-test-auto-reconnect']
source = receipt['source_inputs']
assert len(source) == 560
assert all(sha(w / name) == row['sha256'] and oct((w / name).stat().st_mode & 0o777) == row['mode'] for name, row in source.items())
result = dict(status='passed separate ordinary Eglot observation; original GNU failure retained', raw_root=str(r), files=1, matching_outcomes=52, mismatching_outcomes=0, successful_processes=2, runner_summaries=counts, source_inputs_verified=560, runtime_source_commit='2712c05779e47ec9b8a7c89121d1a79fdcc42596', provenance=contract['provenance'], raw_files={str(path.relative_to(r)): sha(path) for path in r.rglob('*') if path.is_file()}, original_failed_tail=str(t), unchanged_artifacts=True, deadline_seconds=180, goal_complete=False, qualification='The entire frozen Eglot selection was repeated once with identical source bytes, executable/image hashes, harness, environment overrides, selector and 180-second deadline. All 52 outcomes match. The prior GNU reconnect expectation failure remains failed and unexplained; no runtime repair or complete passing frozen run is inferred.')
path = p / 'source314-eglot-replay-audit.json'
assert not path.exists()
path.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ['status', 'files', 'matching_outcomes', 'successful_processes', 'runner_summaries', 'unchanged_artifacts']}))
