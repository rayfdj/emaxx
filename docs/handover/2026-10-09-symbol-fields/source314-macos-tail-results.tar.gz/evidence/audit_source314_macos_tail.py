from pathlib import Path
import hashlib
import json
import re

p = Path(__file__).resolve().parent
w = p.parent / 'recovered-2026-10-08/symbol-plists/emaxx'
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
receipt = read(p / 'source314-macos-tail/state.json')
assert receipt['exit_code'] == 1 and receipt['source_unchanged']
assert len(receipt['raw_directories']) == 1
r = Path(receipt['raw_directories'][0])
summary = read(r / 'summary.json')
contract = read(r / 'contract.json')
original = read(w / 'target/compat/frozen-1791509521579363000-3070/contract.json')
assert contract['files'] == original['files'][319:] and len(contract['files']) == 200
assert summary['mode'] == 'run' and summary['name_filter'] is None and contract['selector'] == original['selector']
assert contract['provenance']['timeout_seconds'] == 180
assert summary['files'] == contract['files'] and summary['total_files'] == 200
assert (summary['matching_outcomes'], summary['mismatching_outcomes'], summary['total_outcomes']) == (3376, 7, 3383)
assert summary['mismatches'] == ['test/lisp/progmodes/eglot-tests.el', 'test/src/emacs-tests.el']
assert summary['unsuccessful_files'] == ['test/lisp/progmodes/eglot-tests.el']
for key in ['subject_source_sha256', 'oracle_sha256', 'oracle_helper_sha256', 'oracle_repo_commit', 'oracle_test_support_sha256', 'runtime_images_sha256']:
    assert contract['provenance'][key] == original['provenance'][key], key
inventory = {}
for line in (w / 'compat/oracle_tests_all.txt').read_text().splitlines():
    match = re.fullmatch(r'(\S+): discovered=(\d+) selected=(\d+)', line)
    if match:
        name = match[1]
        inventory[name] = dict(discovered=int(match[2]), selected=int(match[3]), names=[])
    elif line.strip():
        inventory[name]['names'].append(line.strip())
counts = {runner: dict(total=0, passed=0, failed=0, skipped=0, unexpected=0) for runner in ['oracle', 'emaxx']}
processes = matched = different = 0
issues = []
for name in contract['files']:
    directory = (r / name).with_suffix('.compat')
    execution = read(directory / 'execution.json')
    assert execution['contract_sha256'] == sha(r / 'contract.json')
    assert set(execution['sha256']) == {runner + suffix for runner in counts for suffix in ['.json', '.log', '.execution.json']}
    assert all(sha(directory / path) == digest for path, digest in execution['sha256'].items())
    comparison = read(directory / 'comparison.json')
    assert comparison['file'] == name
    assert comparison['matching_outcomes'] + comparison['mismatching_outcomes'] == inventory[name]['selected']
    if name == 'test/lisp/progmodes/eglot-tests.el':
        assert comparison['mismatching_outcomes'] == 1
        assert {x['kind'] for x in comparison['issues']} == {'result_expectation', 'test_status', 'condition_type'}
        assert [x['kind'] for x in comparison['execution_issues']] == ['unexpected_outcome']
    elif name == 'test/src/emacs-tests.el':
        assert comparison['mismatching_outcomes'] == 6 and not comparison['execution_issues']
        assert [x['kind'] for x in comparison['issues']] == ['failure_message'] * 6
    else:
        assert comparison['matches'] and not comparison['issues'] and not comparison['execution_issues'] and comparison['mismatching_outcomes'] == 0
    if comparison['issues'] or comparison['execution_issues']:
        issues.append(comparison)
    matched += comparison['matching_outcomes']
    different += comparison['mismatching_outcomes']
    pair = {}
    for runner in counts:
        report = read(directory / (runner + '.json'))
        process = read(directory / (runner + '.execution.json'))['process']
        assert process['exit_code'] == 0 and not process['timed_out'] and process['test_started'] and process['timeout_phase'] is None
        assert report['file'] == name and report['selector'] == contract['selector']
        assert report['file_status'] == 'loaded' and report['file_error'] is None
        expected = inventory[name]
        assert len(report['discovered_tests']) == expected['discovered']
        assert len(report['selected_tests']) == expected['selected'] and set(report['selected_tests']) == set(expected['names'])
        results = report['results']
        assert len(results) == len({row['name'] for row in results}) == expected['selected']
        assert {row['name'] for row in results} == set(expected['names'])
        observed = {status: sum(row['status'] == status for row in results) for status in ['passed', 'failed', 'skipped']}
        observed.update(total=len(results), unexpected=sum(not row['expected'] for row in results))
        assert observed == report['summary']
        for key, count in observed.items():
            counts[runner][key] += count
        unexpected = [row for row in results if not row['expected']]
        if name == 'test/lisp/progmodes/eglot-tests.el' and runner == 'oracle':
            assert len(unexpected) == 1 and unexpected[0]['name'] == 'eglot-test-auto-reconnect'
            assert unexpected[0]['status'] == 'failed' and unexpected[0]['condition_type'] == 'ert-test-failed'
            assert '(eglot-current-server)' in unexpected[0]['message'] and ':value nil' in unexpected[0]['message']
        else:
            assert not unexpected
        if name == 'test/src/comp-tests.el':
            assert len(results) == 177 and all(row['status'] == 'passed' and row['expected'] for row in results)
        pair[runner] = {row['name']: row for row in results}
        processes += 1
    for test_name, oracle in pair['oracle'].items():
        emaxx = pair['emaxx'][test_name]
        if test_name == 'eglot-test-auto-reconnect':
            assert emaxx['status'] == 'passed' and emaxx['expected']
        else:
            assert (oracle['status'], oracle['expected'], oracle['condition_type']) == (emaxx['status'], emaxx['expected'], emaxx['condition_type'])
        if name == 'test/src/emacs-tests.el' and oracle['message'] != emaxx['message']:
            assert test_name.startswith('emacs-tests/seccomp/') and oracle['status'] == emaxx['status'] == 'skipped'
            assert 'system-configuration-features' in oracle['message'] and 'system-configuration-features' in emaxx['message']
assert processes == 400 and (matched, different) == (3376, 7) and counts == summary['runner_summaries']
source = receipt['source_inputs']
assert len(source) == 560
assert all(sha(w / name) == row['sha256'] and oct((w / name).stat().st_mode & 0o777) == row['mode'] for name, row in source.items())
result = dict(status='failed: one GNU Eglot expectation failure and six existing feature-message differences', raw_root=str(r), files=200, matching_outcomes=matched, mismatching_outcomes=different, total_outcomes=matched+different, successful_processes=processes, runner_summaries=counts, issues=issues, source_inputs_verified=560, source_commit=contract['provenance']['subject_git_head'], runtime_source_commit='2712c05779e47ec9b8a7c89121d1a79fdcc42596', subject_sha256=contract['provenance']['subject_sha256'], raw_files={str(path.relative_to(r)): sha(path) for path in r.rglob('*') if path.is_file()}, deadline_seconds=180, goal_complete=False, qualification='The ordinary tail covers exactly every frozen file missing from the first attempt, with unchanged selectors, names, outcome checks and deadline. Every process exits successfully and all 177 native compiler outcomes pass in both editors. One GNU Eglot test fails its original reconnect assertion while Emaxx passes; no failure is normalized or converted to an expectation. The separate Eglot reproduction must retain its own outcome and does not replace this failed tail. This is not one complete passing ordinary frozen run.')
path = p / 'source314-macos-tail-audit.json'
assert not path.exists()
path.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ['status', 'files', 'matching_outcomes', 'mismatching_outcomes', 'successful_processes', 'runner_summaries']}))
