from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).resolve().parent
w = p.parent / 'recovered-2026-10-08/symbol-plists/emaxx'
destination = w / 'docs/handover/2026-10-09-symbol-fields'
read = lambda path: json.loads(path.read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
tail = read(p / 'source314-macos-tail-audit.json')
replay = read(p / 'source314-eglot-replay-audit.json')
members = {}
excluded_tools = []
for label, result in [('ordinary-tail', tail), ('eglot-replay', replay)]:
    root = Path(result['raw_root'])
    for name, digest in result['raw_files'].items():
        data = (root / name).read_bytes()
        assert sha(data) == digest
        if name.startswith('tools/'):
            excluded_tools.append(dict(path=str(root / name), bytes=len(data), sha256=digest))
            continue
        members['evidence/' + label + '/raw/' + name] = data
for name in ['source314-macos-tail-audit.json', 'source314-eglot-replay-audit.json',
             'source314-macos-tail/state.json', 'source314-macos-tail/run.log',
             'source314-eglot-replay/state.json', 'source314-eglot-replay/run.log',
             'audit_source314_macos_tail.py', 'audit_source314_eglot_replay.py',
             'source314_macos_tail.py', 'source314_eglot_replay.py',
             'package_macos_tail.py']:
    members['evidence/' + name] = (p / name).read_bytes()
members['contents.json'] = (json.dumps({name: dict(bytes=len(data), sha256=sha(data)) for name, data in members.items()}, indent=2) + '\n').encode()
buffer = io.BytesIO()
with gzip.GzipFile(fileobj=buffer, mode='wb', mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode='w') as archive:
        for name, data in sorted(members.items()):
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o644
            info.mtime = 0
            archive.addfile(info, io.BytesIO(data))
data = buffer.getvalue()
archive_path = destination / 'source314-macos-tail-results.tar.gz'
assert not archive_path.exists()
archive_path.write_bytes(data)
with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
    assert set(archive.getnames()) == set(members)
    assert all(archive.extractfile(name).read() == content for name, content in members.items())
manifest = dict(checkpoint='source314', runtime_source_commit='2712c05779e47ec9b8a7c89121d1a79fdcc42596',
    archive=dict(path=archive_path.name, bytes=len(data), sha256=sha(data), members=len(members)),
    tail={key: tail[key] for key in ['status', 'files', 'matching_outcomes', 'mismatching_outcomes', 'total_outcomes', 'successful_processes', 'runner_summaries', 'source_inputs_verified', 'subject_sha256', 'deadline_seconds']},
    replay={key: replay[key] for key in ['status', 'files', 'matching_outcomes', 'mismatching_outcomes', 'successful_processes', 'runner_summaries', 'unchanged_artifacts', 'deadline_seconds']},
    excluded_prerequisite_tools=excluded_tools,
    qualification='The original frozen prefix, separately bounded Tramp observation, ordinary 200-file tail and single whole-file Eglot replay cover all 519 frozen files. Across these separate attempts 7,915 distinct outcome labels have matching observations; six existing macOS feature-message differences remain strict mismatches. The first run timed out, and the tail retains its GNU Eglot failure. The identical-artifact Eglot replay matches all 52 outcomes but does not explain or repair the earlier failure. This is not one complete passing ordinary frozen run, performance acceptance, or full-goal completion.',
    goal_complete=False)
(destination / 'source314-macos-tail-results-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest['archive']))
