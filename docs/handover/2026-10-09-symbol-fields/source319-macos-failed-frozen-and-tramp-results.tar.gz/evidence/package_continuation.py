from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).resolve().parent
r = p.parents[2]
fp = p.parent / 'allocated-symbols-2026-10-10'
destination = r / 'docs/handover/2026-10-09-symbol-fields'
read = lambda path: json.loads(path.read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()


def package(name, trees, files, information):
    members, excluded = {}, []

    def add(name, path):
        data = path.read_bytes()
        if len(data) > 1_000_000 and (path.name in ['libtest', 'emaxx', 'emacs'] or path.suffix == '.pdmp'):
            excluded.append(dict(path=str(path), bytes=len(data), sha256=sha(data)))
        else:
            assert name not in members
            members[name] = data

    for prefix, directory in trees:
        for path in sorted(directory.rglob('*')):
            if path.is_file():
                add(prefix + '/' + str(path.relative_to(directory)), path)
    for prefix, path in files:
        add(prefix, path)
    members['contents.json'] = (json.dumps({key:dict(bytes=len(data), sha256=sha(data)) for key,data in members.items()},indent=2)+'\n').encode()
    buffer = io.BytesIO()
    with gzip.GzipFile(fileobj=buffer, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for key, data in sorted(members.items()):
                entry = tarfile.TarInfo(key)
                entry.size, entry.mode = len(data), 0o644
                archive.addfile(entry, io.BytesIO(data))
    data = buffer.getvalue()
    path = destination / (name + '.tar.gz')
    with path.open('xb') as stream:
        stream.write(data)
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
        assert set(archive.getnames()) == set(members)
        assert all(archive.extractfile(key).read() == value for key,value in members.items())
    manifest = dict(archive=dict(path=path.name, bytes=len(data), sha256=sha(data), members=len(members)),
                    excluded_large_inputs=excluded, goal_complete=False, **information)
    with (destination / (name + '-manifest.json')).open('x') as stream:
        json.dump(manifest, stream, indent=2)
        stream.write('\n')
    print(json.dumps(manifest['archive']), flush=True)


audit = read(p / 'source320-owner-fix-audit.json')
assert all(row['passed'] == 233 for row in audit['profiles'].values())
package('source320-symbol-owner-fix-selected-results',
    [('evidence/'+label, p/label) for label in ['image-draft7-edebug-negative','image-draft8-edebug-owner','image-draft8-release']],
    [('evidence/'+name, p/name) for name in ['source320-owner-fix-audit.json','image-draft8.patch','audit_owner_fix.py','validate_owner_fix.py','package_continuation.py']]
    + [('evidence/'+label+'/'+name,p/label/name) for label in ['image-draft6-relocation','image-draft6-release'] for name in ['selection.json','inventory.stdout']],
    dict(checkpoint='source320 debugger owner repair', audit=audit))

failed = read(p / 'source319-macos-frozen-incomplete-audit.json')
longer = read(p / 'source319-tramp-longer-audit.json')
package('source319-macos-failed-frozen-and-tramp-results',
    [('evidence/frozen-raw',Path(failed['raw_root'])),('evidence/tramp-longer-raw',Path(longer['raw_root']))]
    + [('evidence/'+label,p/label) for label in ['source319-macos-frozen','source319-macos-frozen2','source319-tramp-longer']],
    [('evidence/'+name,p/name) for name in ['source319-macos-frozen-incomplete-audit.json','source319-tramp-longer-audit.json',
        'audit_source319_macos_incomplete.py','audit_source319_macos_incomplete2.py','audit_source319_macos_incomplete3.py',
        'source319-macos-audit-attempt1.txt','source319-macos-audit-attempt2.txt','audit_source319_tramp_longer.py',
        'source319_macos_frozen.py','source319_macos_frozen2.py','source319_tramp_longer.py','source319-macos-runtime-commit.json','package_continuation.py']],
    dict(checkpoint='source319 failed macOS frozen attempt and separate bounded Tramp observation',failed_audit=failed,longer_audit=longer,
         qualification='The first launcher rejected an uncommitted checkout. The committed frozen attempt then retained nine strict file failures, including denied local sockets in both editors, both 180-second Tramp timeouts and 200 unstarted files. The separate 600-second observation obtains 59 matching Tramp answers. The original failed-run Emaxx executable was rebuilt before it was copied; its recorded identity is retained and its original bytes remain missing. The current executable and unchanged GNU/images are retained separately. No failed attempt is converted to a pass.'))

audit = read(fp / 'fields-draft7-audit.json')
assert all(row['passed'] == 235 for row in audit['profiles'].values())
labels = ['fields-draft1-function-plist','fields-draft2-function-plist','fields-draft3-owned-fixtures',
          'fields-draft3-release','fields-draft4-edebug-negative','fields-draft5-edebug-owner',
          'fields-draft6-allocated-payload','fields-draft7-owned-payload-controls','fields-draft7-release']
package('allocated-symbol-payload-unfinished-results',
    [('evidence/'+label,fp/label) for label in labels],
    [('evidence/'+name,fp/name) for name in ['fields-draft7-audit.json','fields-draft3-audit.json',
        'fields-draft3.patch','fields-draft5.patch','fields-draft7.patch','audit_fields.py','audit_payloads.py',
        'validate_fields.py','move_symbol_payload.py','allocated-symbol-fields-gnu.el','allocated-symbol-fields-gnu.json',
        'allocated-symbol-fields-gnu.stdout','allocated-symbol-fields-gnu.stderr']]
    + [('evidence/previous/'+label+'/'+name,p/label/name) for label in ['image-draft6-relocation','image-draft6-release'] for name in ['selection.json','inventory.stdout']]
    + [('evidence/package_continuation.py',p/'package_continuation.py')],
    dict(checkpoint='unapplied allocated symbol payload draft7',audit=audit))
