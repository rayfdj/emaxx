from pathlib import Path
import hashlib
import io
import json
import re
import subprocess
import sys
import tarfile

evidence = Path(__file__).resolve().parent
repository = evidence.parents[2]
checkout = evidence.parent / 'recovered-2026-10-09/symbol-ownership/emaxx'
root = evidence / 'redirect-draft1-full/full'
head = '2712c05779e47ec9b8a7c89121d1a79fdcc42596'
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
summary = read(root / 'summary.json')
assert summary['status'] == 'passed' and summary['scope'] == 'full'
assert summary['git'] == {'dirty': True, 'head': head}
source = read(evidence / 'redirect-draft1-full/source.json')
assert len(source) == 562
post_run_source = {name: dict(sha256=sha(checkout / name), mode=oct((checkout / name).stat().st_mode & 0o777)) for name in source}
assert source == post_run_source
assert source == read(evidence / 'redirect-draft1-full/source-after.json') == read(evidence / 'redirect-draft1/source.json')
selected = read(evidence / 'selected-audit.json')
assert selected['replay_verified'] and selected['source_inputs'] == 562
assert sha(evidence / 'redirect-draft1.patch') == selected['patch_sha256']
receipt = read(evidence / 'redirect-draft1-full/full.json')
assert receipt['exit_code'] == 0
for stream in ['stdout', 'stderr']:
    assert sha(evidence / ('redirect-draft1-full/full.' + stream)) == receipt[stream + '_sha256']

inventory = [line[:-6] for line in (root / 'inventory.txt').read_text().splitlines() if line.endswith(': test')]
assert len(inventory) == len(set(inventory)) == 3068
assert summary['inventory']['ignored_tests'] == ['tty::tty_differential_end_to_end', 'tty::tty_smoke_end_to_end']
assert summary['repetitions'] == 1 and len(summary['runs']) == 1
run = summary['runs'][0]
assert run['expected_tests'] == run['observed_outcomes'] == summary['inventory']['scheduled_tests'] == 3068
assert {group['group'] for group in run['groups']} == set(summary['inventory']['groups'])
assert len(run['groups']) == len(summary['inventory']['groups'])
pattern = r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;'
seen = []
passed = ignored = 0
for group in run['groups']:
    assert group['exit_code'] == 0 and not group['timed_out']
    result = group['result']
    assert result['status'] == 'ok' and result['failed'] == result['measured'] == 0
    assert result['passed'] + result['ignored'] == group['expected_tests'] == summary['inventory']['groups'][group['group']]
    assert result['ignored'] == group['expected_ignored']
    log = (root / Path(group['log']).name).read_text()
    assert re.findall(pattern, log) == [('ok', str(result['passed']), '0', str(result['ignored']), '0', str(result['filtered_out']))]
    starts = list(re.finditer(r'^test (\S+) \.\.\. ', log, re.M))
    assert len(starts) == group['expected_tests']
    for index, match in enumerate(starts):
        end = starts[index + 1].start() if index + 1 < len(starts) else log.rindex('test result:')
        verdict = log[match.end():end].strip()
        if match[1] in summary['inventory']['ignored_tests']:
            assert verdict.startswith('ignored')
        else:
            assert re.search(r'(?:^|\s)ok$', verdict), (match[1], verdict)
        seen.append(match[1])
    passed += result['passed']
    ignored += result['ignored']
assert sorted(seen) == sorted(inventory) and len(seen) == len(set(seen))
assert ignored == 2
assert [stage['stage'] for stage in summary['cargo_stages']] == ['bins', 'integration']
cargo = {}
for stage in summary['cargo_stages']:
    assert stage['exit_code'] == 0
    log = (root / Path(stage['log']).name).read_text()
    assert not re.search(r'^warning(?:\[.*?\])?:', log, re.M)
    rows = re.findall(pattern, log)
    assert len(rows) == len(stage['results']) > 0
    for row, result in zip(rows, stage['results']):
        assert result['status'] == 'ok'
        assert result['failed'] == result['ignored'] == result['measured'] == result['filtered_out'] == 0
        assert row == ('ok', str(result['passed']), '0', '0', '0', '0')
    cargo[stage['stage']] = sum(result['passed'] for result in stage['results'])
identity = [line for line in (root / 'integration.log').read_text().splitlines() if line.startswith('test unchanged_gnu_sources_produce_identical_native_artifacts ')]
assert len(identity) == 1 and identity[0].endswith(' ... ok')

sys.path.insert(0, str(repository / 'tools'))
import retain_rust_gate_artifacts
retained = root / 'retained-inputs'
if not retained.exists():
    retain_rust_gate_artifacts.retain(root / 'summary.json', checkout / 'target/grouped-gate/fixture-images')
record = read(retained / 'manifest.json')
assert record['status'] == 'retained' and record['gate_status'] == 'passed'
assert record['gate_summary_sha256'] == sha(root / 'summary.json')
for entry in record['files']:
    path = retained / entry['artifact']
    assert sha(path) == entry['sha256'] and path.stat().st_size == entry['bytes']
assert next(entry for entry in record['files'] if entry['artifact'] == 'libtest')['sha256'] == summary['test_binary']['sha256']
result = dict(status='passed', draft_base=head, draft_patch_sha256=selected['patch_sha256'], validation_checkout=summary['git'],
              unchanged_source_inputs=len(source), raw_library_names_verified=len(seen), library_passed=passed,
              library_ignored=ignored, cargo_passed=cargo, total_passed=passed + sum(cargo.values()),
              native_artifact_identity='passed', retained_files_verified=len(record['files']),
              test_binary_sha256=summary['test_binary']['sha256'], summary_sha256=sha(root / 'summary.json'),
              qualification='Full source316 macOS gate: all 562 bytes/modes match its original selected source, terminal wrapper capture, current checkout and verified portable patch. The run began on the dirty base2712 draft, then the identical runtime inputs were committed as ee0bddb9 and merged with documentation/main history. Every raw library verdict and Cargo result checked. Retained post-run fixture images do not establish per-test use. Linux, frozen and timing have separate evidence; no allocated-symbol authority or full-goal completion claim.',
              goal_complete=False)
with (evidence / 'source316-macos-rust-audit.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(result, indent=2))
