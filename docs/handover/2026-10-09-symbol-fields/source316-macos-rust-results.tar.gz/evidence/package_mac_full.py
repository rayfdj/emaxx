from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).resolve().parent
w = p.parent / 'recovered-2026-10-09/symbol-ownership/emaxx'
destination = w / 'docs/handover/2026-10-09-symbol-fields'
read = lambda path: json.loads(path.read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
audit = read(p / 'source316-macos-rust-audit.json')
assert audit['status'] == 'passed' and audit['total_passed'] == 3165
members, excluded = {}, []
for path in sorted((p / 'redirect-draft1-full').rglob('*')):
    if not path.is_file():
        continue
    name = str(path.relative_to(p))
    data = path.read_bytes()
    if len(data) > 1_000_000 and (path.name == 'libtest' or path.suffix == '.pdmp'):
        excluded.append(dict(path=str(path), bytes=len(data), sha256=sha(data)))
    else:
        members['evidence/' + name] = data
for name in ['source316-macos-rust-audit.json', 'selected-audit.json', 'redirect-draft1.patch',
             'close_macos_rust.py', 'validate.py', 'package_mac_full.py']:
    members['evidence/' + name] = (p / name).read_bytes()
members['contents.json'] = (json.dumps({name: dict(bytes=len(data), sha256=sha(data)) for name, data in members.items()}, indent=2) + '\n').encode()
buffer = io.BytesIO()
with gzip.GzipFile(fileobj=buffer, mode='wb', mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode='w') as archive:
        for name, data in sorted(members.items()):
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o644
            archive.addfile(info, io.BytesIO(data))
data = buffer.getvalue()
path = destination / 'source316-macos-rust-results.tar.gz'
assert not path.exists()
path.write_bytes(data)
with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
    assert set(archive.getnames()) == set(members)
    assert all(archive.extractfile(name).read() == value for name, value in members.items())
manifest = dict(checkpoint='source316 applied runtime, full macOS Rust gate', archive=dict(path=path.name, bytes=len(data), sha256=sha(data), members=len(members)), audit=audit, excluded_large_inputs=excluded, goal_complete=False, qualification='All full-gate raw inventories, per-test verdicts, Cargo logs, wrapper receipts and source captures are retained. Large libtest/image inputs remain locally retained and identified here. Source316 is the PR81 runtime. Linux Rust/frozen and diagnostic timing have separate evidence; macOS frozen is running. This does not repair the separately recorded instance-name ownership gap or complete the full goal.')
(destination / 'source316-macos-rust-results-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest['archive']))
