from pathlib import Path
import hashlib
import io
import json
import re
import subprocess
import tarfile
import tempfile

p = Path(__file__).resolve().parent
w = p.parent / "recovered-2026-10-09/symbol-obarray/emaxx"
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
gate = p / "obarray-draft5-key-contract"
source = read(gate / "source.json")
old_source = read(p / "obarray-draft4-hash-owner/source.json")
assert set(source) == set(old_source) and len(source) == 563
changed = sorted(name for name in source if source[name] != old_source[name])
assert changed == ["src/lisp/types.rs", "src/lisp/types/symbols.rs"]
assert all(sha(w / name) == row["sha256"] and oct((w / name).stat().st_mode & 0o777) == row["mode"] for name, row in source.items())
for step in ["fmt", "check", "clippy", "diff"]:
    receipt = read(gate / (step + ".json"))
    assert receipt["exit_code"] == 0
    for stream in ["stdout", "stderr"]:
        path = gate / (step + "." + stream)
        assert sha(path) == receipt[stream + "_sha256"]
        assert not re.search(r"^warning(?:\[.*?\])?:", path.read_text(), re.M)

new_test = "lisp::types::symbols::tests::nested_editors_keep_same_named_symbols_distinct_and_restore_the_caller"
profiles = {}
for profile, label in [("gate", "obarray-draft5-key-contract"), ("release", "obarray-draft5-release")]:
    directory = p / label
    assert read(directory / "source.json") == read(directory / "source-after.json") == source
    selection = read(directory / "selection.json")
    assert len(selection) == 230
    assert set(selection) == set(read(p / ("obarray-draft4-" + profile) / "selection.json")) | {new_test}
    inventory = [line[:-6] for line in (directory / "inventory.stdout").read_text().splitlines() if line.endswith(": test")]
    previous = [line[:-6] for line in (p / ("obarray-draft4-" + profile) / "inventory.stdout").read_text().splitlines() if line.endswith(": test")]
    assert len(inventory) == len(set(inventory)) == len(previous) + 1
    assert set(inventory) == set(previous) | {new_test}
    for step in ["build", "inventory", "focused"]:
        receipt = read(directory / (step + ".json"))
        assert receipt["exit_code"] == 0
        for stream in ["stdout", "stderr"]:
            path = directory / (step + "." + stream)
            assert sha(path) == receipt[stream + "_sha256"]
            assert not re.search(r"^warning(?:\[.*?\])?:", path.read_text(), re.M)
    verdicts = re.findall(r"^test (\S+) \.\.\. (ok|FAILED|ignored)\s*$", (directory / "focused.stdout").read_text(), re.M)
    assert len(verdicts) == 230 and dict(verdicts) == dict.fromkeys(selection, "ok")
    binary = read(directory / "binary.json")
    assert sha(Path(binary["retained"])) == binary["sha256"]
    profiles[profile] = dict(selected=230, inventory=len(inventory), test_binary_sha256=binary["sha256"])

replays = {}
for name, revision in [("obarray-draft5.patch", "93b6546f9c54aaecf2237cc751e3f94591066969"),
                       ("obarray-cumulative-draft5.patch", "30fa6e5b669c5cbd26e842e7675bfc18d306c2b4")]:
    patch = p / name
    data = subprocess.check_output(["git", "diff", "--binary", revision, "--", "src", "tests"], cwd=w)
    if patch.exists():
        assert patch.read_bytes() == data
    else:
        patch.write_bytes(data)
    available = subprocess.check_output(["git", "ls-tree", "-r", "--name-only", revision], cwd=w, text=True).splitlines()
    raw = subprocess.check_output(["git", "archive", revision, "--", *[name for name in source if name in available]], cwd=w)
    with tempfile.TemporaryDirectory(prefix="emaxx-symbol-key-replay-") as temporary:
        root = Path(temporary)
        with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
            for entry in archive.getmembers():
                if entry.isfile():
                    target = root / entry.name
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(archive.extractfile(entry).read())
                    target.chmod(0o755 if entry.mode & 0o111 else 0o644)
        subprocess.run(["git", "apply", str(patch)], cwd=root, check=True)
        assert all(sha(root / name) == row["sha256"] and oct((root / name).stat().st_mode & 0o777) == row["mode"] for name, row in source.items())
    replays[name] = dict(base=revision, sha256=sha(patch), source_inputs_verified=563)

gnu = p.parent / "rebuilt-2026-10-01/emacs"
result = dict(checkpoint="source319 unfinished owner draft5", status="passed selected controls",
              changed_from_draft4=changed, source_inputs_verified=563, strict="zero warnings",
              profiles=profiles, previous_controls_retained=229, added_control=new_test,
              replays=replays, gnu_source_commit=subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=gnu, text=True).strip(),
              gnu_reference=dict(path="src/fns.c", sha256=sha(gnu / "src/fns.c"), mechanism="sxhash_eq hashes identity; canonical name lookup has a separate key contract"),
              qualification="SymbolName equality and hashing now both use object identity; only NameEntry borrows text for canonical lookup. Original selectors and fixtures remain. This audit covers strict and selected gate/release validation and exact patches. Draft4 public/native results remain historical and are not new draft5 validation. Ordinary comparisons run separately. Private image-clone ownership, allocated fields, descriptor reclamation, other process roots, physical accounting and full validation remain open.",
              goal_complete=False)
with (p / "draft5-keys-audit.json").open("x") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")
print(json.dumps({key: result[key] for key in ["status", "source_inputs_verified", "profiles", "replays"]}, indent=2))
