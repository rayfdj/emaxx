from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import subprocess
import tarfile

p = Path(__file__).resolve().parent
w = p.parent / "recovered-2026-10-09/symbol-obarray/emaxx"
published = p.parent / "recovered-2026-10-09/symbol-ownership/emaxx"
destination = published / "docs/handover/2026-10-09-symbol-fields"
read = lambda path: json.loads(path.read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
audit = read(p / "draft5-keys-audit.json")
ordinary = p / "obarray-draft5-ordinary"
source = read(p / "obarray-draft5-key-contract/source.json")
assert read(ordinary / "source.json") == source
assert all(sha((w / name).read_bytes()) == row["sha256"] and oct((w / name).stat().st_mode & 0o777) == row["mode"] for name, row in source.items())
assert read(ordinary / "summary.json") == dict(processes=18, passed=18, failed=0, source_inputs=563, goal_complete=False)
expected = (p / "ordinary.py").read_text().replace("obarray-draft4-ordinary", "obarray-draft5-ordinary").replace("obarray-draft4-gate", "obarray-draft5-key-contract")
assert (p / "ordinary_draft5.py").read_text() == expected
identities = read(ordinary / "artifacts-before.json")
assert identities == read(ordinary / "artifacts-after.json")
pairs = {}
results = read(ordinary / "results.json")
assert len(results) == 18
for row in results:
    label = "-".join([row["fixture"], row["mode"], row["editor"]])
    receipt = read(ordinary / (label + ".json"))
    assert receipt["exit_code"] == 0 and not receipt["timed_out"] and receipt["timeout_seconds"] == 180
    for stream in ["stdout", "stderr"]:
        assert sha((ordinary / (label + "." + stream)).read_bytes()) == receipt[stream + "_sha256"]
    output = (ordinary / (label + ".stdout")).read_text()
    assert output == row["stdout"] and output.strip() == row["expected"] and row["passed"]
    if row["mode"] in ["bytecode", "native"]:
        assert output.startswith("((t t t t) " if row["fixture"] == "symbol-redirect-lifetime" else "(t ")
    pairs.setdefault((row["fixture"], row["mode"]), {})[row["editor"]] = output
assert len(pairs) == 9 and all(set(pair) == {"gnu", "emaxx"} and pair["gnu"] == pair["emaxx"] for pair in pairs.values())
for label in ["build", "image"]:
    receipt = read(ordinary / (label + ".json"))
    assert receipt["exit_code"] == 0 and not receipt["timed_out"]
    for stream in ["stdout", "stderr"]:
        path = ordinary / (label + "." + stream)
        assert sha(path.read_bytes()) == receipt[stream + "_sha256"]
        assert not re.search(r"^warning(?:\[.*?\])?:", path.read_text(), re.M)

retained = p / "obarray-draft5-retained-inputs"
retained.mkdir(exist_ok=False)
retention = []
for index, (name, row) in enumerate(sorted(identities.items())):
    path = Path(name)
    assert sha(path.read_bytes()) == row["sha256"] and path.stat().st_size == row["bytes"]
    copy = retained / (str(index) + "-" + path.name)
    subprocess.run(["cp", "-c", str(path), str(copy)], check=True)
    assert sha(copy.read_bytes()) == row["sha256"]
    retention.append(dict(original=name, retained=str(copy), **row))
(retained / "manifest.json").write_text(json.dumps(retention, indent=2) + "\n")
ordinary_audit = dict(status="passed", source_inputs_verified=563, processes=18, comparisons=9,
                      actual_modes=["interpreted", "bytecode", "native"],
                      previous_launcher_and_fixtures_preserved=True, retained_inputs=retention,
                      goal_complete=False)
(p / "draft5-ordinary-audit.json").write_text(json.dumps(ordinary_audit, indent=2) + "\n")
members, excluded = {}, []
for label in ["obarray-draft5-key-contract", "obarray-draft5-release", "obarray-draft5-ordinary"]:
    for path in sorted((p / label).rglob("*")):
        if not path.is_file():
            continue
        data = path.read_bytes()
        if path.name == "libtest" or path.suffix == ".pdmp":
            excluded.append(dict(path=str(path), bytes=len(data), sha256=sha(data)))
        else:
            members["evidence/" + str(path.relative_to(p))] = data
for name in ["draft5-keys-audit.json", "draft5-ordinary-audit.json", "audit_draft5_keys.py",
             "validate_draft5.py", "ordinary_draft5.py", "continue_draft5.py",
             "draft5-continuation-state.json", "draft5-release-supervisor.log",
             "draft5-ordinary-supervisor.log", "obarray-draft5.patch", "obarray-cumulative-draft5.patch",
             "obarray-draft5-retained-inputs/manifest.json", "package_draft5.py"]:
    members["evidence/" + name] = (p / name).read_bytes()
members["contents.json"] = (json.dumps({name: dict(bytes=len(data), sha256=sha(data)) for name, data in members.items()}, indent=2) + "\n").encode()
buffer = io.BytesIO()
with gzip.GzipFile(fileobj=buffer, mode="wb", mtime=0) as zipped:
    with tarfile.open(fileobj=zipped, mode="w") as archive:
        for name, data in sorted(members.items()):
            entry = tarfile.TarInfo(name)
            entry.size, entry.mode = len(data), 0o644
            archive.addfile(entry, io.BytesIO(data))
data = buffer.getvalue()
path = destination / "source319-symbol-key-contract-results.tar.gz"
assert not path.exists()
path.write_bytes(data)
with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as archive:
    assert set(archive.getnames()) == set(members)
    assert all(archive.extractfile(name).read() == data for name, data in members.items())
manifest = dict(checkpoint="source319 unapplied owner draft5", archive=dict(path=path.name, bytes=len(data), sha256=sha(data), members=len(members)),
                selected_audit=audit, ordinary_audit=ordinary_audit, excluded_large_inputs=excluded,
                qualification="Both exact patches reproduce 563 inputs. Strict checks have zero warnings; all 229 earlier controls plus the nested-editor identity control pass in gate and release. All 18 unchanged ordinary processes match in nine comparisons with actual bytecode/native modes. Original source319 failures and draft4 public/native evidence remain separately preserved. Draft5 full platform/frozen/terminal and public native validation have not run; private clone ownership, allocated fields, reclamation, accounting and full-goal performance remain open.",
                goal_complete=False)
(destination / "source319-symbol-key-contract-results-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps(manifest["archive"]))
