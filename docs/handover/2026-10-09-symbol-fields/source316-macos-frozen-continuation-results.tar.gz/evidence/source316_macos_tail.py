from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import time

p = Path(__file__).resolve().parent
w = p.parent / 'recovered-2026-10-09/symbol-ownership/emaxx'
output = p / 'source316-macos-tail'
output.mkdir(exist_ok=False)
source = json.loads((p / 'redirect-draft1/source.json').read_text())
original = json.loads((p / 'source316-macos-frozen/state.json').read_text())
def verify():
    for name, row in source.items():
        path = w / name
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
        assert oct(path.stat().st_mode & 0o777) == row['mode']
verify()
command = [str(w / 'target/gate/compat-harness'), 'run', '--scope', 'all', '--from-file', 'test/lisp/net/webjump-tests.el']
record = dict(status='running', pid=os.getpid(), started=datetime.datetime.now(datetime.timezone.utc).isoformat(), command=command, environment_overrides=original['environment_overrides'], original_frozen_deadline_seconds=180, observation_deadline_seconds=180, source_inputs=source, goal_complete=False)
def save(): (output / 'state.json').write_text(json.dumps(record, indent=2) + '\n')
save()
before = set((w / 'target/compat').glob('run-*'))
start = time.monotonic()
with (output / 'run.log').open('wb') as log:
    process = subprocess.run(command, cwd=w, env={**os.environ, **record['environment_overrides']}, stdout=log, stderr=subprocess.STDOUT, timeout=10800)
record.update(status='terminal; inspect raw results', exit_code=process.returncode, elapsed_seconds=time.monotonic()-start, raw_directories=[str(x) for x in set((w / 'target/compat').glob('run-*')) - before])
save()
verify()
record['source_unchanged'] = True
save()
print(json.dumps({k: record[k] for k in ('status', 'exit_code', 'elapsed_seconds', 'raw_directories')}), flush=True)
raise SystemExit(process.returncode)
