from pathlib import Path
import hashlib
import json
import re
import subprocess

p = Path(__file__).resolve().parent
w = p.parent / 'recovered-2026-10-09/symbol-ownership/emaxx'
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
receipt = read(p / 'source316-tramp-longer/state.json')
assert receipt['exit_code'] == 0 and receipt['source_unchanged']
assert len(receipt['raw_directories']) == 1
r = Path(receipt['raw_directories'][0])
summary = read(r / 'summary.json')
contract = read(r / 'contract.json')
original = read(w / 'target/compat/frozen-1791519403990625000-85993/contract.json')
assert summary['total_files'] == summary['matching_files'] == 1
assert summary['matching_outcomes'] == summary['total_outcomes'] == 59
assert summary['mismatching_outcomes'] == 0 and summary['mismatches'] == summary['unsuccessful_files'] == []
assert contract['files'] == ['test/lisp/net/tramp-tests.el'] and contract['name_filter'] is None
assert contract['selector'] == original['selector']
assert contract['provenance']['timeout_seconds'] == 600 and original['provenance']['timeout_seconds'] == 180
for key in ['subject_source_sha256', 'oracle_sha256', 'oracle_helper_sha256', 'oracle_repo_commit', 'oracle_test_support_sha256', 'runtime_images_sha256']:
    assert contract['provenance'][key] == original['provenance'][key], key
manifest = (w / 'compat/oracle_tests_all.txt').read_text()
entry = re.search(r'^test/lisp/net/tramp-tests.el: discovered=(\d+) selected=(\d+)\n((?:  [^\n]+\n)+)', manifest, re.M)
assert entry and int(entry[2]) == 59
names = [line.strip() for line in entry[3].splitlines()]
directory = r / 'test/lisp/net/tramp-tests.compat'
execution = read(directory / 'execution.json')
assert execution['contract_sha256'] == sha(r / 'contract.json')
assert set(execution['sha256']) == {runner + suffix for runner in ['oracle', 'emaxx'] for suffix in ['.json', '.log', '.execution.json']}
assert all(sha(directory / name) == digest for name, digest in execution['sha256'].items())
comparison = read(directory / 'comparison.json')
assert comparison['matches'] and not comparison['issues'] and not comparison['execution_issues']
assert comparison['matching_outcomes'] == 59 and comparison['mismatching_outcomes'] == 0
counts, timing, pair = {}, {}, {}
for runner in ['oracle', 'emaxx']:
    report = read(directory / (runner + '.json'))
    process = read(directory / (runner + '.execution.json'))['process']
    assert process['exit_code'] == 0 and not process['timed_out'] and process['test_started'] and process['timeout_phase'] is None
    assert report['file_status'] == 'loaded' and report['file_error'] is None
    assert report['file'] == contract['files'][0] and report['selector'] == contract['selector']
    assert len(report['discovered_tests']) == int(entry[1])
    assert len(report['selected_tests']) == len(set(report['selected_tests'])) == 59
    assert set(report['selected_tests']) == set(names)
    result = report['results']
    assert len(result) == len({row['name'] for row in result}) == 59 and {row['name'] for row in result} == set(names)
    observed = {status: sum(row['status'] == status for row in result) for status in ['passed', 'failed', 'skipped']}
    observed.update(total=len(result), unexpected=sum(not row['expected'] for row in result))
    assert observed == report['summary'] == dict(total=59, passed=52, failed=0, skipped=7, unexpected=0)
    counts[runner] = observed
    timing[runner] = process['test_elapsed']['secs'] + process['test_elapsed']['nanos'] / 1e9
    assert 0 < timing[runner] < 600
    pair[runner] = {row['name']: (row['status'], row['expected'], row['condition_type']) for row in result}
assert pair['oracle'] == pair['emaxx'] and counts == summary['runner_summaries']
source = receipt['source_inputs']
assert len(source) == 562
assert all(sha(w / name) == row['sha256'] and oct((w / name).stat().st_mode & 0o777) == row['mode'] for name, row in source.items())
retained = []
destination = p / 'source316-tramp-longer/retained-inputs'
destination.mkdir(exist_ok=True)
provenance = contract['provenance']
for original_path, digest in {provenance['subject_binary']: provenance['subject_sha256'], **provenance['runtime_images_sha256'], provenance['oracle_binary']: provenance['oracle_sha256']}.items():
    original_path = Path(original_path)
    assert sha(original_path) == digest
    target = destination / original_path.name
    if not target.exists():
        subprocess.run(['cp', '-c', str(original_path), str(target)], check=True)
    assert sha(target) == digest
    retained.append(dict(original=str(original_path), artifact=str(target), sha256=digest, bytes=target.stat().st_size))
result = dict(status='matched in separate bounded longer run', source_inputs_verified=562, source_commit=provenance['subject_git_head'], runtime_source_commit='ee0bddb9', files=1, matching_outcomes=59, successful_processes=2, runner_summaries=counts, test_seconds=timing, deadline_seconds=600, raw_root=str(r), raw_files={str(f.relative_to(r)): sha(f) for f in r.rglob('*') if f.is_file()}, retained_inputs=retained, original_subject_sha256=original['provenance']['subject_sha256'], subject_sha256=provenance['subject_sha256'], goal_complete=False, qualification='The original 180-second frozen comparison remains failed. Per user instruction, this separate run waited up to 600 seconds for actual answers from both editors. Every pinned Tramp name and verdict matches. The harness prepared the subject from the same 562 runtime inputs; the original and current executable hashes are recorded independently and both artifacts are retained. The image and GNU executable/image are unchanged. This observation does not replace the failed frozen run, explain the original timeouts, or establish authoritative performance.')
path = p / 'source316-tramp-longer-audit.json'
assert not path.exists()
path.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['status', 'matching_outcomes', 'successful_processes', 'test_seconds', 'subject_sha256']}))
