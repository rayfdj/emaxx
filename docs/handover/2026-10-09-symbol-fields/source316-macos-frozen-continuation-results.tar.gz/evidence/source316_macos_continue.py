from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
p=Path(__file__).resolve().parent
out=p/'source316-macos-continuation-state.json'
assert not out.exists()
failed=json.loads((p/'source316-macos-frozen-incomplete-audit.json').read_text())
assert failed['completed_comparisons']==318 and len(failed['unstarted_files'])==200
assert failed['unstarted_files'][0]=='test/lisp/net/webjump-tests.el'
state=dict(status='starting bounded Tramp observation',pid=os.getpid(),started=datetime.datetime.now(datetime.timezone.utc).isoformat(),results=[],original_run='failed; preserved unchanged',goal_complete=False)
def save():out.write_text(json.dumps(state,indent=2)+'\n')
save()
try:
 for label,script in [('tramp-longer','source316_tramp_longer.py'),('tail','source316_macos_tail.py')]:
  command=['python3',str(p/script)]
  state.update(status='running '+label);save();print(state['status'],flush=True)
  start=time.monotonic()
  log=p/('source316-'+label+'-supervisor.log')
  with log.open('wb') as output:
   result=subprocess.run(command,cwd=p,stdout=output,stderr=subprocess.STDOUT,timeout=14400)
  state['results'].append(dict(stage=label,command=command,exit_code=result.returncode,elapsed_seconds=time.monotonic()-start,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest()));save()
  print(label,result.returncode,flush=True)
  # Preserve unfavorable outcomes and still observe the previously unstarted
  # files. A later stage never changes this stage's verdict.
 state.update(status='terminal; audit both actual results');save()
except BaseException as error:
 state.update(status='supervisor failed; inspect retained stages',error=str(error));save();raise
