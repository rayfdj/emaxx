(progn (require 'cconv) (let ((actual 
            (progn
              (setq lexical-binding t)
              (require 'bytecomp)
              (defun sample-cconv-intern-all (x)
                (cond ((symbolp x) (intern (symbol-name x)))
                      ((consp x) (cons (sample-cconv-intern-all (car x))
                                       (sample-cconv-intern-all (cdr x))))
                      (t x)))
              (sample-cconv-intern-all
               (cconv-closure-convert
                '#'(lambda (x)
                     (let ((f #'(lambda () x)))
                       (let ((x 'b))
                         (list x (funcall f))))))))
            ) (expected '#'(lambda (x)
                      (let ((f #'(lambda (x) x)))
                        (let ((x 'b)
                              (closed-x x))
                          (list x (funcall f closed-x))))))) (list (equal actual expected) actual)))