(progn (require 'cconv) (let ((actual 
            (progn
              (setq lexical-binding t)
              (require 'bytecomp)
              (defun sample-cconv-intern-all (x)
                (cond ((symbolp x) (intern (symbol-name x)))
                      ((consp x) (cons (sample-cconv-intern-all (car x))
                                       (sample-cconv-intern-all (cdr x))))
                      (t x)))
              (sample-cconv-intern-all
               (cconv-closure-convert '#'(lambda (x) #'(lambda () x)))))
            ) (expected '#'(lambda (x) (internal-make-closure nil (x) nil (internal-get-closed-var 0))))) (list (equal actual expected) actual)))