(let ((actual (eval '``(,,x) '((x . 1))))
      (expected (read "`(,1)")))
  (list (equal actual expected) actual))