(let* ((file (make-temp-file "emaxx-persist-probe-"))
                          (jane (make-instance 'person :name "Jane"))
                          (bob (make-instance 'person :name "Bob"))
                          (object
                           (make-instance
                            'classy
                            :teacher jane
                            :janitors (list [tuesday nil] [friday nil])
                            :random-vector [nil]
                            :file file)))
                     (puthash "Bob" bob (slot-value object 'students))
                     (aset (slot-value object 'random-vector) 0
                           (make-instance 'persistent-random-class))
                     (unwind-protect
                         (let ((save
                                (condition-case error
                                    (progn
                                      (eieio-persistent-save object)
                                      'save-ok)
                                  (error (list 'save-error error)))))
                           (list
                            save
                            (condition-case error
                                (progn
                                  (eieio-persistent-read file 'classy)
                                  'read-ok)
                              (error (list 'read-error error)))))
                       (ignore-errors (delete-file file))))
