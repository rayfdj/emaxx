from pathlib import Path
import hashlib
import json
import re

p = Path(__file__).resolve().parent
w = p.parent / 'recovered-2026-10-10/symbol-fields/emaxx'
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
source = read(p / 'fields-draft16-gate/source.json')
previous = read(p / 'fields-draft15-gate/source.json')
assert set(source) == set(previous) and len(source) == 568
changed = sorted(name for name in source if source[name] != previous[name])
assert changed == ['src/lisp/eval/tests/eval_05.rs', 'src/lisp/primitives/tests.rs']
for name, row in source.items():
    assert sha(w / name) == row['sha256']
    assert oct((w / name).stat().st_mode & 0o777) == row['mode']
replay = read(p / 'fields-draft16-replay.json')
assert len(replay) == 1 and replay[0]['replayed'] and replay[0]['source_inputs'] == 568
assert sha(p / replay[0]['patch']) == replay[0]['sha256']
profiles = {}
for profile in ['gate', 'release']:
    d = p / ('fields-draft16-' + profile)
    assert read(d / 'source.json') == read(d / 'source-after.json') == source
    stages = ['build', 'inventory', 'focused']
    if profile == 'gate':
        stages = ['fmt', 'check', 'clippy', 'diff'] + stages
    for name in stages:
        receipt = read(d / (name + '.json'))
        assert receipt['exit_code'] == 0
        for stream in ['stdout', 'stderr']:
            data = (d / (name + '.' + stream)).read_bytes()
            assert hashlib.sha256(data).hexdigest() == receipt[stream + '_sha256']
            if name in ['check', 'clippy', 'build']:
                assert not re.search(rb'^warning(?:\[.*?\])?:', data, re.M)
    inventory = {line[:-6] for line in (d / 'inventory.stdout').read_text().splitlines() if line.endswith(': test')}
    old = {line[:-6] for line in (p / ('fields-draft11-' + profile) / 'inventory.stdout').read_text().splitlines() if line.endswith(': test')}
    assert old <= inventory and len(inventory - old) == 2
    selection = read(d / 'selection.json')
    assert set(read(p / 'fields-draft15-gate/selection.json')) == set(selection)
    assert len(selection) == len(set(selection)) == 379
    raw = (d / 'focused.stdout').read_text()
    verdicts = re.findall(r'^test (\S+) \.\.\. (ok|FAILED|ignored)\s*$', raw, re.M)
    assert len(verdicts) == len(selection) and set(dict(verdicts)) == set(selection)
    assert all(verdict == 'ok' for _, verdict in verdicts)
    assert 'test result: ok. 379 passed; 0 failed; 0 ignored;' in raw
    binary = read(d / 'binary.json')
    assert sha(Path(binary['retained'])) == binary['sha256']
    profiles[profile] = dict(passed=379, failed=0, ignored=0, inventory=len(inventory),
                             previous_names_preserved=len(old), binary=binary)

gnu = p / 'fields-draft16-fixture-gnu'
observations = {}
for label in ['persistence', 'obarray-order', 'obarray-order-varied-names', 'obarray-order-varied-content']:
    receipt = read(gnu / (label + '.json'))
    assert receipt['exit_code'] == 0 and receipt['timeout_seconds'] == 180
    expression = (gnu / (label + '.el')).read_text()
    if label != 'obarray-order-varied-content':
        assert expression.endswith('\n')
        expression = expression[:-1]
    assert receipt['command'][-2:] == ['--eval', '(prin1 ' + expression + ')']
    for stream in ['stdout', 'stderr']:
        assert sha(gnu / (label + '.' + stream)) == receipt[stream + '_sha256']
    observations[label] = (gnu / (label + '.stdout')).read_text()
assert observations['persistence'] == '(save-ok read-ok)'
assert observations['obarray-order'] == '(t t t 3930 "eval-print-last-sexp" "eval-print-last-sexp")'
assert observations['obarray-order-varied-names'] == 'nil'
assert observations['obarray-order-varied-content'].startswith('(t t t 4 ')
inputs = read(gnu / 'inputs.json')
for name, row in inputs.items():
    if name.endswith('/src/lisp/eval/tests/eval_05.rs'):
        assert previous['src/lisp/eval/tests/eval_05.rs']['sha256'] == row['sha256']
    else:
        assert sha(Path(name)) == row['sha256']
        assert Path(name).stat().st_size == row['bytes']

result = dict(status='strict and 379 controls per profile passed', source_inputs_verified=568,
              production_unchanged_from_draft15=True, changed_local_fixtures=changed,
              patch=replay[0], profiles=profiles, gnu_fixture_observations=observations,
              qualification='Only two local test fixtures change from draft15. EIEIO expected symbols now belong to the tested editor; all four upstream ERT cases and their expected outcomes remain. The dump test now compares every native function name and arity after restoration, instead of the first hash-table entry. GNU demonstrates identical native mappings with different first entries; the two inconclusive preceding observations remain explicit. All prior selected and inventory names remain. Ordinary, complete platform, native/module/terminal and performance validation are separate; ownership/name/id and accounting adapters remain unfinished.',
              goal_complete=False)
with (p / 'fields-draft16-selected-audit.json').open('x') as output:
    json.dump(result, output, indent=2)
    output.write('\n')
print(json.dumps({k: result[k] for k in ['status', 'source_inputs_verified', 'changed_local_fixtures']}, indent=2))
