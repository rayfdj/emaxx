from pathlib import Path
import hashlib
import json
import re
import subprocess

p = Path(__file__).resolve().parent
w = p.parent / 'recovered-2026-10-10/symbol-fields/emaxx'
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
full = p / 'fields-draft16-full/full'
tail = p / 'fields-draft16-unstarted-groups'
summary = read(full / 'summary.json')
continuation = read(tail / 'state.json')
source = read(p / 'fields-draft16-full/source.json')
assert summary['status'] == 'failed' and not summary['cargo_stages']
assert continuation['source_unchanged'] and continuation['source'] == source
assert continuation['binary'] == summary['test_binary']
assert len(source) == 568
for name, row in source.items():
    assert sha(w / name) == row['sha256']
    assert oct((w / name).stat().st_mode & 0o777) == row['mode']
inventory = {line[:-6] for line in (full / 'inventory.txt').read_text().splitlines() if line.endswith(': test')}
assert len(inventory) == 3078
rows = []
for name in ['eval_01', 'eval_02']:
    receipt = read(full / ('repeat-01-' + name + '.json'))
    rows.append((receipt, full / ('repeat-01-' + name + '.log'), 'original failed gate'))
for receipt in continuation['groups']:
    rows.append((receipt, tail / (receipt['group'] + '.log'), 'separate unexecuted-group continuation'))
assert len(rows) == 10
verdicts = {}
groups = []
pattern = r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;'
for receipt, path, origin in rows:
    text = path.read_text()
    result, = re.findall(pattern, text)
    prefix = text.split('\nfailures:\n')[0].split('\ntest result:')[0]
    starts = list(re.finditer(r'^test (\S+) \.\.\. ', prefix, re.M))
    local = {}
    for index, match in enumerate(starts):
        end = starts[index + 1].start() if index + 1 < len(starts) else len(prefix)
        body = prefix[match.end():end].strip()
        if body.startswith('ignored'):
            verdict = 'ignored'
        else:
            terminal = re.search(r'(?:^|\s)(ok|FAILED)$', body)
            assert terminal, (match[1], body)
            verdict = terminal[1]
        assert match[1] not in verdicts and match[1] not in local
        local[match[1]] = verdict
    counts = [sum(v == outcome for v in local.values()) for outcome in ['ok', 'FAILED', 'ignored']]
    assert counts == list(map(int, result[1:4]))
    assert int(result[4]) == 0 and int(result[5]) + len(local) == 3078
    assert not receipt['timed_out'] and receipt['exit_code'] == (101 if counts[1] else 0)
    if 'expected_names' in receipt:
        assert set(receipt['expected_names']) == set(local)
        assert sha(path) == receipt['log_sha256']
    else:
        assert receipt['expected_tests'] == len(local)
    verdicts.update(local)
    groups.append(dict(group=receipt['group'], origin=origin, passed=counts[0], failed=counts[1], ignored=counts[2], log_sha256=sha(path)))
assert set(verdicts) == inventory
assert sum(v == 'ok' for v in verdicts.values()) == 3061
assert sum(v == 'FAILED' for v in verdicts.values()) == 15
assert sum(v == 'ignored' for v in verdicts.values()) == 2
retained = tail / 'retained-inputs'
retained.mkdir(exist_ok=False)
paths = [Path(summary['test_binary']['path'])]
assert sha(paths[0]) == summary['test_binary']['sha256']
environment = read(p / 'fields-draft16-full/environment.json')
paths += sorted(Path(environment['EMAXX_FIXTURE_IMAGE_DIR']).rglob('*.pdmp'))
copies = []
for index, path in enumerate(paths):
    digest = sha(path)
    target = retained / (str(index) + '-' + path.name)
    subprocess.run(['cp', '-c', str(path), str(target)], check=True)
    assert sha(target) == digest == sha(path)
    copies.append(dict(original=str(path), retained=str(target), sha256=digest, bytes=path.stat().st_size))
result = dict(status='failed; all library names observed across original and diagnostic continuation', source_inputs=568, library_inventory=3078, passed=3061, failed=15, ignored=2, groups=groups, failures=sorted(name for name, verdict in verdicts.items() if verdict == 'FAILED'), retained_inputs=copies, qualification='The original full gate stopped after 689 passes and two failures. Its eight unexecuted library groups were run separately with unchanged selectors, source, binary, template policy and deadlines. All 3078 library names are now observed, but no passing full gate or Cargo-stage result is claimed. Four cconv/backquote/EIEIO comparisons visibly involve separate editor owners; batch locale, undo, bytecode switch, native calls, Eshell completion and escaped-frame reclamation also fail and require diagnosis. The later ID-removal prototype has selected coverage only and still fails Eshell. Retained post-run fixture images do not establish which image each individual test used.', goal_complete=False)
with (p / 'fields-draft16-full-failed-audit.json').open('x') as output:
    json.dump(result, output, indent=2)
    output.write('\n')
print(json.dumps({key:result[key] for key in ['status', 'library_inventory', 'passed', 'failed', 'ignored', 'failures']}, indent=2))
