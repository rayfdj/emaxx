from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time

p = Path(__file__).resolve().parent
w = p.parent / 'recovered-2026-10-10/symbol-fields/emaxx'
g = p.parent / 'rebuilt-2026-10-01/emacs'
d = p / 'fields-draft16-owner-fixture-observations'
d.mkdir(exist_ok=False)
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
source = (w / 'src/lisp/eval/tests/eval_02.rs').read_text()
programs = {}
for name in ['cconv_closure_convert_captures_simple_free_variable',
             'cconv_closure_convert_remaps_shadowed_lambda_lifted_variable']:
    block = source[source.index('fn ' + name + '()'):].split('\n#[test]', 1)[0]
    actual = re.search(r'r#"(.*?)"#', block, re.S).group(1)
    expected = re.search(r'result,\s*eval_str\(\s*"(.*?)"', block, re.S).group(1)
    assert '\\' not in expected
    programs[name] = "(progn (require 'cconv) (let ((actual " + actual + ") (expected " + expected + ")) (list (equal actual expected) actual)))"
programs['nested_backquote_decrements_unquote_depth'] = '''(let ((actual (eval '``(,,x) '((x . 1))))
      (expected (read "`(,1)")))
  (list (equal actual expected) actual))'''
binary = w / 'target/release/emaxx'
inputs = {str(path): dict(sha256=sha(path), bytes=path.stat().st_size)
          for path in [binary, binary.with_suffix('.pdmp'), g/'src/emacs', g/'src/emacs.pdmp',
                       w/'src/lisp/eval/tests/eval_02.rs', w/'src/lisp/eval/tests/eval_04.rs']}
(d/'inputs-before.json').write_text(json.dumps(inputs, indent=2)+'\n')
comparisons = []
for name, program in programs.items():
    (d/(name+'.el')).write_text(program)
    outputs = {}
    for editor, executable in [('gnu', g/'src/emacs'), ('emaxx', binary)]:
        command = [str(executable), '-Q', '--batch', '--eval', '(prin1 '+program+')']
        label = name+'-'+editor
        start = time.monotonic()
        result = subprocess.run(command, cwd=w, env={**os.environ,'LANG':'C','LC_ALL':'C'},
                                capture_output=True, timeout=180)
        for stream in ['stdout','stderr']:
            (d/(label+'.'+stream)).write_bytes(getattr(result,stream))
        receipt = dict(command=command, exit_code=result.returncode, timeout_seconds=180,
                       elapsed_seconds=time.monotonic()-start,
                       stdout_sha256=sha(d/(label+'.stdout')), stderr_sha256=sha(d/(label+'.stderr')))
        (d/(label+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
        outputs[editor] = result.stdout.decode()
        print(name,editor,result.returncode,outputs[editor],flush=True)
        assert result.returncode == 0 and result.stdout.startswith(b'(t ')
    assert outputs['gnu'] == outputs['emaxx']
    comparisons.append(dict(name=name, identical=True, output=outputs['gnu']))
assert all(sha(Path(name)) == row['sha256'] for name,row in inputs.items())
(d/'summary.json').write_text(json.dumps(dict(status='passed',comparisons=comparisons,
    qualification='Exact original Lisp operations and expected forms evaluated in one editor, with identical ordinary GNU and Emaxx arguments. The failed Rust fixtures constructed expected symbols in a different owner; original failed runs remain failed.',
    inputs_unchanged=True,goal_complete=False),indent=2)+'\n')
