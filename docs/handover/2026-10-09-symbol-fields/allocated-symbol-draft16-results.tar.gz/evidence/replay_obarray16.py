from pathlib import Path
import hashlib,io,json,subprocess,tarfile,tempfile
p=Path(__file__).resolve().parent;r=p.parents[2];w=p.parent/'recovered-2026-10-10/symbol-fields/emaxx'
base='265d5ba3405cebe7692560cc29722be65d62237b';sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda f:json.loads(f.read_text())
available=set(subprocess.check_output(['git','ls-tree','-r','--name-only',base],cwd=r,text=True).splitlines())
results=[]
for number in [16]:
 d=p/('fields-draft'+str(number)+'-gate');source=read(d/'source.json');patch=(d/'tracked.patch').read_bytes()
 for name in ['tests/fixtures/symbol-obarray-field-order.el','tests/fixtures/symbol-obarray-reader-membership.el']:
  if name not in source:continue
  assert sha((w/name).read_bytes())==source[name]['sha256']
  diff=subprocess.run(['git','diff','--no-index','--','/dev/null',name],cwd=w,capture_output=True)
  assert diff.returncode==1 and diff.stdout and not diff.stderr;patch+=diff.stdout
 path=p/('fields-draft'+str(number)+'.patch');path.open('xb').write(patch)
 archive_bytes=subprocess.check_output(['git','archive',base,'--',*[name for name in source if name in available]],cwd=r)
 with tempfile.TemporaryDirectory(prefix='emaxx-obarray-replay-') as tmp:
  out=Path(tmp)
  with tarfile.open(fileobj=io.BytesIO(archive_bytes)) as archive:
   for entry in archive.getmembers():
    if not entry.isfile():continue
    dest=out/entry.name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(archive.extractfile(entry).read());dest.chmod(0o755 if entry.mode&0o111 else 0o644)
  subprocess.run(['git','apply',str(path)],cwd=out,check=True)
  for name,row in source.items():assert sha((out/name).read_bytes())==row['sha256'] and oct((out/name).stat().st_mode&0o777)==row['mode'],name
 results.append(dict(draft=number,base=base,patch=path.name,sha256=sha(patch),source_inputs=len(source),replayed=True,validation_status='separate; no inference from replay'))
(p/'fields-draft16-replay.json').open('x').write(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
