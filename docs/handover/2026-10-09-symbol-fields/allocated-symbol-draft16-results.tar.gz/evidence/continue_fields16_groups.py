from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

p = Path(__file__).resolve().parent
w = p.parent / 'recovered-2026-10-10/symbol-fields/emaxx'
d = p / 'fields-draft16-unstarted-groups'
d.mkdir(exist_ok=False)
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
source = read(p / 'fields-draft16-full/source.json')
failed = read(p / 'fields-draft16-full/full/summary.json')
assert failed['status'] == 'failed'
retained = read(p / 'fields-draft16-full/full/retained-inputs/manifest.json')
assert retained['status'] == 'retained'
binary = Path(failed['test_binary']['path'])
assert sha(binary) == failed['test_binary']['sha256']
os.environ.update(read(p / 'fields-draft16-full/environment.json'))
sys.path.insert(0, str(w / 'tools'))
import serial_grouped_gate
gate = serial_grouped_gate.gate
inventory = gate.parse_inventory((p / 'fields-draft16-full/full/inventory.txt').read_text())
groups, phases = gate.classify_inventory(inventory, 'full')
specs = [spec for phase in phases for spec in phase]
assert [spec.name for spec in specs[:2]] == ['eval_01', 'eval_02']
state = dict(status='running separate continuation of unexecuted library groups',
             original_full_status='failed', source=source, binary=failed['test_binary'],
             groups=[], goal_complete=False)

def save():
    (d / 'state.json').write_text(json.dumps(state, indent=2) + '\n')

def verify():
    assert sha(binary) == failed['test_binary']['sha256']
    for name, row in source.items():
        assert sha(w / name) == row['sha256']
        assert oct((w / name).stat().st_mode & 0o777) == row['mode']

save()
verify()
for spec in specs[2:]:
    command = spec.command(binary)
    environment = gate.gate_environment(spec.template)
    start = time.monotonic()
    print('START', spec.name, len(groups[spec.name]), flush=True)
    with (d / (spec.name + '.log')).open('xb') as log:
        try:
            result = subprocess.run(command, cwd=w, env=environment, stdout=log,
                                    stderr=subprocess.STDOUT, timeout=3600)
            code, timed_out = result.returncode, False
        except subprocess.TimeoutExpired:
            code, timed_out = None, True
    text = (d / (spec.name + '.log')).read_text(errors='replace')
    try:
        outcome = gate.parse_test_result(text)
    except gate.GateError:
        outcome = None
    state['groups'].append(dict(group=spec.name, command=command,
        template=spec.template, expected_names=groups[spec.name],
        exit_code=code, timed_out=timed_out, timeout_seconds=3600,
        elapsed_seconds=time.monotonic()-start, result=outcome,
        log_sha256=sha(d / (spec.name + '.log'))))
    verify()
    save()
    print('END', spec.name, code, outcome, flush=True)
state['status'] = 'terminal; audit raw results; original full attempt remains failed'
state['source_unchanged'] = True
save()
