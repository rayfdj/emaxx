from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile
import tempfile

p = Path(__file__).resolve().parent
w = p.parent / 'recovered-2026-10-13/gc-cons-trace/emaxx'
out = p / 'gc-cons-trace-draft1-gate'
base = '999362622a68d6508c356541422f7a48ae6e2175'
source = json.loads((out / 'source.json').read_text())
patch = out / 'tracked.patch'
sha = lambda data: hashlib.sha256(data).hexdigest()
assert len(source) == 572
data = subprocess.check_output(['git', 'archive', '--format=tar', base, *source], cwd=w)
with tempfile.TemporaryDirectory(prefix='emaxx-gc-cons-replay-', dir='/private/tmp') as tmp:
    root = Path(tmp)
    with tarfile.open(fileobj=io.BytesIO(data)) as archive:
        for entry in archive.getmembers():
            assert not Path(entry.name).is_absolute() and '..' not in Path(entry.name).parts
        assert all(entry.isfile() or entry.isdir() for entry in archive.getmembers())
        for entry in archive.getmembers():
            if not entry.isfile():
                continue
            target = root / entry.name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(archive.extractfile(entry).read())
            target.chmod(0o755 if entry.mode & 0o111 else 0o644)
    subprocess.run(['git', 'apply', '--check', str(patch)], cwd=root, check=True)
    subprocess.run(['git', 'apply', str(patch)], cwd=root, check=True)
    for name, row in source.items():
        path = root / name
        assert sha(path.read_bytes()) == row['sha256']
        assert oct(path.stat().st_mode & 0o777) == row['mode'], name
record = dict(base=base, source_inputs=572, changed_inputs=['src/lisp/eval.rs'],
    patch_sha256=sha(patch.read_bytes()), source_manifest_sha256=sha((out / 'source.json').read_bytes()),
    status='every patched input byte and mode replays', goal_complete=False)
(p / 'gc-cons-trace-draft1-replay.json').open('x').write(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
