from pathlib import Path
import hashlib
import json
import re

p = Path(__file__).resolve().parent
out = p / 'gc-cons-trace-draft1-gate'
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
for name in ['fmt', 'check', 'clippy', 'diff', 'build', 'inventory', 'selected']:
    row = read(out / (name + '.json'))
    assert row['exit_code'] == (101 if name == 'selected' else 0)
    for stream in ['stdout', 'stderr']:
        assert sha(out / (name + '.' + stream)) == row[stream + '_sha256']
        if name != 'selected':
            assert not re.search(r'^warning(?:\[.*?\])?:', (out / (name + '.' + stream)).read_text(), re.M)
raw = (out / 'selected.stdout').read_text()
assert 'test result: FAILED. 438 passed; 96 failed; 0 ignored;' in raw
passed = re.findall(r'^test (\S+) \.\.\. ok$', raw, re.M)
failed = re.findall(r'^test (\S+) \.\.\. FAILED$', raw, re.M)
selected = read(out / 'selection.json')
assert len(passed) == 438 and len(failed) == 96
assert set(passed + failed) == set(selected) and len(selected) == 534
assert 'run locale oracle' in raw and 'No such file or directory' in raw
assert 'load GNU early owner emacs-lisp/debug-early' in raw
replay = read(p / 'gc-cons-trace-draft1-replay.json')
audit = dict(status='strict checks pass; original selected run failed',
    source_inputs=572, selected=534, passed=438, failed=96, ignored=0,
    passed_names=passed, failed_names=failed, replay=replay, goal_complete=False,
    qualification='The initial isolated checkout omitted the adjacent GNU fixture tree. Raw failures include missing ../emacs/src/emacs and GNU Lisp fixture files. That required layout is now provided by a symlink to the pinned source/build; the identical534 controls are running separately. The original remains failed. No runtime correctness, release or performance acceptance is inferred from a setup correction.')
(p / 'gc-cons-trace-draft1-initial-audit.json').open('x').write(json.dumps(audit, indent=2) + '\n')
ns = {'__file__': str(p / 'package_source323_base.py')}
exec((p / 'package_source323_base.py').read_text(), ns)
ns['destination'] = p / 'pending-publication-source324'
ns['package']('gc-cons-trace-draft1-unfinished-results', [('evidence/initial-gate', out)],
    [('evidence/' + name, p / name) for name in [
        'gc-cons-trace-draft1-initial-audit.json', 'gc-cons-trace-draft1-c-mapping.json',
        'gc-cons-trace-draft1-replay.json', 'gc-cons-trace-draft1-layout-correction.json',
        'gc-cons-trace-draft1-initial-replay-failure.json', 'gc-cons-trace-draft1-archive-mode-failure.json',
        'replay_gc_cons_trace.py', 'replay_gc_cons_trace.unsupported-python-filter.py',
        'replay_gc_cons_trace.archive-modes.py', 'validate_gc_cons_trace.py',
        'package_source323_base.py', Path(__file__).name]],
    dict(checkpoint='separate unapplied source324 cons marking experiment', audit=audit,
         qualification='Only src/lisp/eval.rs changes, with every572input byte/mode replayed from99936262. GNU alloc.c process_mark_stack motivates direct cons marking/tracing with unchanged mark epoch and car-first field order. Strict checks have zero warnings; original selected run fails with the omitted GNU fixture layout. Corrected-layout repetition remains separate and uncertified here. No release or speed result; do not apply without further validation and measured benefit.'))
