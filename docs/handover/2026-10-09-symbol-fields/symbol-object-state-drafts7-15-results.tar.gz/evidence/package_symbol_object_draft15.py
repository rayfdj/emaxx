from pathlib import Path
import json
p=Path(__file__).resolve().parent
ns={'__file__':str(p/'package_source323_base.py')}
exec((p/'package_source323_base.py').read_text(),ns)
destination=p/'pending-publication-symbol-object-state'
destination.mkdir(exist_ok=True)
ns['destination']=destination
entries=lambda names:[('evidence/'+name,p/name) for name in names]
ns['package']('symbol-object-state-drafts7-15-results',
 entries([f'symbol-object-state-draft{i}-gate' for i in range(7,16)]+['symbol-object-state-draft15-selected-gate','symbol-object-state-draft15-selected-release','symbol-object-state-draft15-ordinary','symbol-object-state-gnu-entries']),
 entries(['symbol-object-state-c-mapping.json','symbol-object-state-drafts7-15-replay.json','replay_symbol_object_state.py','symbol-object-state-draft15-gate-audit.json','symbol-object-state-draft15-selected-rechecked-audit.json','symbol-object-state-draft15-ordinary-failure-audit.json','validate_symbol_object_state.py','validate_symbol_object_entries.py','validate_symbol_object_selected.py','audit_symbol_object_selected.py','ordinary_symbol_object_state.py','package_source323_base.py',Path(__file__).name]),
 dict(checkpoint='unapplied symbol object-state draft15; native comparison failure retained',
  source_inputs=584,
  selected=json.loads((p/'symbol-object-state-draft15-selected-rechecked-audit.json').read_text()),
  ordinary_failure=json.loads((p/'symbol-object-state-draft15-ordinary-failure-audit.json').read_text()),
  qualification='Drafts7-11/13-14 compile/lint failures remain failed. Draft12 passes the unchanged40-predicate GNU control. Draft15 passes strict0warnings,93interpretedGNU predicates,imagecopy/restore and406selectedcontrols perprofile; its44ordinarycomparisons retain43matches/one actualnativeEmaxx exit255 on the unchanged40-predicate program. All38previous comparisons match. Every patch replays captured input bytes/modes from99936262. Neither partialsuccess nor the pending native repair is full correctness or goal completion. Large retained executable/image files are explicitly excluded with hashes and local paths.'))
