from pathlib import Path
import json, hashlib, re, sys
p=Path(__file__).resolve().parent
prefix=sys.argv[1]
expected=int(sys.argv[2])
read=lambda f:json.loads(f.read_text())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
old=set(read(p/'symbol-membership-draft5-selected-gate/selection.json'))|{'lisp::primitives::pdumper::tests::captured_menu_case_table_belongs_to_its_editor_and_image'}
assert len(old)==403
reports=[]
for profile in ['gate','release']:
 q=p/(prefix+'-selected-'+profile)
 selected=read(q/'selection.json');assert len(selected)==expected and old<=set(selected)
 assert all(name.rsplit('::',1)[-1].startswith('symbol_constant_') for name in set(selected)-old)
 raw=(q/'selected.stdout').read_text();passed=re.findall(r'^test (.*?) \.\.\. ok$',raw,re.M)
 assert sorted(passed)==selected and len(set(passed))==expected
 assert f'test result: ok. {expected} passed; 0 failed; 0 ignored;' in raw
 for stage in ['build','inventory','selected']:
  receipt=read(q/(stage+'.json'));assert receipt['exit_code']==0
  for stream in ['stdout','stderr']:assert receipt[stream+'_sha256']==sha(q/(stage+'.'+stream))
 assert read(q/'source.json')==read(q/'source-after.json')==read(p/(prefix+'-gate/source.json'))
 artifact=read(q/'binary.json');assert sha(Path(artifact['retained']))==artifact['sha256']
 reports.append(dict(profile=profile,passed=expected,failed=0,ignored=0,prior_inventory_preserved=403,added_controls=expected-403,source_inputs=len(read(q/'source.json')),source_sha256=sha(q/'source.json'),selected_sha256=sha(q/'selected.stdout'),binary_sha256=artifact['sha256']))
report=dict(results=reports,qualification='All prior selected control names preserved in both profiles. Ordinary and complete platform validation are separate. Runtime is unapplied.',goal_complete=False)
(p/(prefix+'-selected-rechecked-audit.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
