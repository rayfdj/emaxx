from pathlib import Path
import datetime
import json
import os
import subprocess
import sys

evidence = Path(__file__).resolve().parent
root = evidence.parents[2]
state_path = evidence / 'validation-state.json'
assert not state_path.exists(), 'Do not launch duplicate validation'
state = dict(status='running', pid=os.getpid(), base='2712c05779e47ec9b8a7c89121d1a79fdcc42596',
             started=datetime.datetime.now(datetime.timezone.utc).isoformat(), stages=[], goal_complete=False)
for label, command in [
    ('release', [sys.executable, str(evidence / 'validate.py'), 'compact-draft1-release', 'focus', 'release']),
    ('ordinary', [sys.executable, str(evidence / 'ordinary.py')]),
    ('full-gate', [sys.executable, str(evidence / 'validate.py'), 'compact-draft1-full', 'full']),
]:
    state['current_stage'] = label
    state['current_command'] = command
    state_path.write_text(json.dumps(state, indent=2) + '\n')
    print('START PIPELINE', label, flush=True)
    code = subprocess.run(command, cwd=root).returncode
    state['stages'].append(dict(stage=label, command=command, exit_code=code))
    if code != 0:
        state['status'] = 'failed'
        state_path.write_text(json.dumps(state, indent=2) + '\n')
        raise SystemExit(code)
state['status'] = 'passed'
state.pop('current_stage')
state.pop('current_command')
state_path.write_text(json.dumps(state, indent=2) + '\n')
print('VALIDATION PIPELINE PASSED', flush=True)
