from pathlib import Path
import hashlib,json,re
p=Path(__file__).resolve().parent
w=p.parent/'recovered-2026-10-09/symbol-obarray/emaxx'
prior=p.parent/'symbol-payload-api-2026-10-09'
read=lambda f:json.loads(f.read_text())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
source=read(p/'obarray-draft4-hash-owner/source.json');assert len(source)==563
assert all(sha(w/n)==v['sha256'] and oct((w/n).stat().st_mode&0o777)==v['mode'] for n,v in source.items())
public=read(p/'public-audit.json');assert public['source_inputs_verified']==563
for name,row in public['replays'].items():assert sha(p/name)==row['sha256']
for n,v in read(prior/'payload-draft1/source.json').items():
 if n.startswith('tests/') or n.startswith('compat/'):
  assert source[n]==v
selection=read(p/'obarray-draft4-gate/selection.json');assert len(selection)==229
assert set(read(prior/'payload-draft1-gate/selection.json'))<=set(selection)
profiles={}
for profile in ['gate','release']:
 d=p/('obarray-draft4-'+profile);old=prior/('payload-draft1-'+profile)
 assert read(d/'source.json')==read(d/'source-after.json')==source
 assert read(d/'selection.json')==selection
 inventory=[line[:-6] for line in (d/'inventory.stdout').read_text().splitlines() if line.endswith(': test')]
 old_names=[line[:-6] for line in (old/'inventory.stdout').read_text().splitlines() if line.endswith(': test')]
 assert sorted(inventory)==sorted(old_names) and len(inventory)==len(set(inventory))
 for step in ['build','inventory','focused']:
  r=read(d/(step+'.json'));assert r['exit_code']==0
  for stream in ['stdout','stderr']:
   f=d/(step+'.'+stream);assert sha(f)==r[stream+'_sha256']
   assert not re.search(r'^warning(?:\[.*?\])?:',f.read_text(),re.M)
 verdicts=re.findall(r'^test (\S+) \.\.\. (ok|FAILED|ignored)\s*$',(d/'focused.stdout').read_text(),re.M)
 assert len(verdicts)==229 and dict(verdicts)==dict.fromkeys(selection,'ok')
 binary=read(d/'binary.json');assert sha(Path(binary['retained']))==binary['sha256']
 profiles[profile]=dict(selected=229,inventory=len(inventory),binary_sha256=binary['sha256'])
ordinary=p/'obarray-draft4-ordinary'
assert read(ordinary/'source.json')==source
assert read(ordinary/'summary.json')==dict(processes=18,passed=18,failed=0,source_inputs=563,goal_complete=False)
artifacts=read(ordinary/'artifacts-before.json');assert artifacts==read(ordinary/'artifacts-after.json')
for name,row in artifacts.items():assert sha(Path(name))==row['sha256']
results=read(ordinary/'results.json');assert len(results)==18
pairs={}
for row in results:
 label='-'.join([row['fixture'],row['mode'],row['editor']]);r=read(ordinary/(label+'.json'))
 assert r['exit_code']==0 and not r['timed_out'] and r['timeout_seconds']==180
 for stream in ['stdout','stderr']:assert sha(ordinary/(label+'.'+stream))==r[stream+'_sha256']
 output=(ordinary/(label+'.stdout')).read_text()
 assert output==row['stdout'] and output.strip()==row['expected'] and row['passed']
 pairs.setdefault((row['fixture'],row['mode']),{})[row['editor']]=output
 if row['mode'] in ['bytecode','native']:
  assert output.startswith('((t t t t) ' if row['fixture']=='symbol-redirect-lifetime' else '(t ')
assert len(pairs)==9 and all(set(pair)=={'gnu','emaxx'} and pair['gnu']==pair['emaxx'] for pair in pairs.values())
expected=(prior/'ordinary.py').read_text().replace('recovered-2026-10-09/symbol-registry','recovered-2026-10-09/symbol-obarray').replace('symbol-payload-api-2026-10-09','symbol-obarray-2026-10-09').replace('payload-draft1','obarray-draft4')
assert (p/'ordinary.py').read_text()==expected
restored=p/'obarray-draft4-restored-public-target-image';r=read(restored/'run.json')
assert r['source_inputs']==source and r['source_unchanged']
assert len(r['processes'])==11 and len(r['comparisons'])==3
for row in r['processes']:
 assert row['exit_code']==0 and not row['timed_out']
 assert row['timeout_seconds']==({'compile':1200,'image-build':1800}.get(row['label'],300))
 for stream in ['stdout','stderr']:assert sha(restored/(row['label']+'.'+stream))==row[stream+'_sha256']
for name,digest in r['artifacts'].items():assert sha(Path(name))==digest
for row in r['comparisons']:
 label=row['label'];gnu=(restored/(label+'-gnu-first.stdout')).read_text()+(restored/(label+'-gnu-second.stdout')).read_text();emaxx=(restored/(label+'-emaxx-two-editors.stdout')).read_text()
 assert row['matches'] and row['gnu']==gnu==row['emaxx']==emaxx
assert r['comparisons'][0]['gnu']=='(t t)\n(t t)\n'
assert (restored/'ordinary_cli.rs').read_text()==(w/'src/main.rs').read_text().replace('fn main() -> ExitCode {','pub fn cli_main() -> ExitCode {')
assert r['library']['sha256']==read(p/'obarray-draft4-public/run.json')['library']['sha256']
assert sha(Path(r['library']['path']))==r['library']['sha256']
old=p/'obarray-draft4-restored-public';failed=read(old/'run.json')
assert len(failed['processes'])==9
assert [row['matches'] for row in failed['comparisons']]==[False,False,False]
for row in failed['processes']:
 expected=1 if row['label'].endswith('emaxx-two-editors') else 0
 assert row['exit_code']==expected and not row['timed_out']
 for stream in ['stdout','stderr']:assert sha(old/(row['label']+'.'+stream))==row[stream+'_sha256']
 if expected:assert 'not built for this Emacs executable' in (old/(row['label']+'.stderr')).read_text()
for label,needle in [('obarray-draft4-restored-public-own-image','failed to get bitcode'),('obarray-draft4-restored-public-own-image-link','could not parse bitcode')]:
 d=p/label;failure=read(d/'run.json');assert len(failure['processes'])==1
 row=failure['processes'][0];assert row['label']=='compile' and row['exit_code']==1
 assert needle in (d/'compile.stderr').read_text()
 for stream in ['stdout','stderr']:assert sha(d/('compile.'+stream))==row[stream+'_sha256']

result=dict(checkpoint='source319 unfinished owner draft4 selected validation',source_inputs_verified=563,profiles=profiles,prior_controls_retained=208,unchanged_full_test_inventories=True,unchanged_fixtures_and_ordinary_launcher=True,ordinary_processes=18,ordinary_comparisons=9,restored_public_processes=9,restored_public_comparisons=r['comparisons'],restored_public_artifacts=r['artifacts'],replays=public['replays'],goal_complete=False,qualification='Both selected profiles and ordinary modes pass. A new launcher linked to the same retained production library, with the unchanged normal CLI source exposed for dumping, runs two successive editors from its own valid fingerprinted image; actual pdumper-stats proves both loads, and name/descriptor identities match GNU. The mismatched-image attempt and two standalone link failures are retained as setup failures; the original name/descriptor failures remain in the separate draft archive. Full platform/frozen/terminal/native/module validation, private image-clone ownership, direct allocated fields, descriptor reclamation, other process roots and physical accounting remain open. No total performance or ownership completion claim.')
(p/'selected-audit.json').open('x').write(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['checkpoint','source_inputs_verified','profiles','ordinary_processes','ordinary_comparisons','restored_public_processes','goal_complete']},indent=2))
