from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
p=Path(__file__).resolve().parent
w=p.parent/'recovered-2026-10-09/symbol-ownership/emaxx'
destination=w/'docs/handover/2026-10-09-symbol-fields'
read=lambda f:json.loads(f.read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
audit=read(p/'selected-audit.json');assert audit['ordinary_processes']==18 and audit['source_inputs_verified']==563
retained=p/'obarray-draft4-retained-inputs';retained.mkdir(exist_ok=True)
identities={}
for name,row in read(p/'obarray-draft4-ordinary/artifacts-before.json').items():identities[name]=row['sha256']
for label in ['obarray-draft4-restored-public','obarray-draft4-restored-public-target-image']:
 identities.update(read(p/label/'run.json')['artifacts'])
retention=[]
for index,(name,digest) in enumerate(sorted(identities.items())):
 path=Path(name);assert sha(path.read_bytes())==digest
 copy=retained/(str(index)+'-'+path.name)
 if not copy.exists():subprocess.run(['cp','-c',str(path),str(copy)],check=True)
 assert sha(copy.read_bytes())==digest
 retention.append(dict(original=name,retained=str(copy),bytes=copy.stat().st_size,sha256=digest))
(retained/'manifest.json').write_text(json.dumps(retention,indent=2)+'\n')
members={};excluded=[]
labels=['obarray-draft4-release','obarray-draft4-ordinary','obarray-draft4-restored-public','obarray-draft4-restored-public-own-image','obarray-draft4-restored-public-own-image-link','obarray-draft4-restored-public-target-image']
for label in labels:
 for path in sorted((p/label).rglob('*')):
  if not path.is_file():continue
  data=path.read_bytes();name=str(path.relative_to(p))
  if path.name in ['libtest','public-instances'] or path.suffix in ['.rlib','.pdmp']:
   excluded.append(dict(path=str(path),bytes=len(data),sha256=sha(data)))
  else:members['evidence/'+name]=data
for name in ['selected-audit.json','audit_selected.py','ordinary.py','continue_selected.py','continued-validation-state.json','release-supervisor.log','ordinary-supervisor.log','probe_restored_instances.py','probe_restored_instances_own_image.py','probe_restored_instances_own_image_link.py','probe_restored_instances_target_image.py','package_selected.py','obarray-draft4-retained-inputs/manifest.json']:
 members['evidence/'+name]=(p/name).read_bytes()
members['contents.json']=(json.dumps({name:dict(bytes=len(data),sha256=sha(data)) for name,data in members.items()},indent=2)+'\n').encode()
buffer=io.BytesIO()
with gzip.GzipFile(fileobj=buffer,mode='wb',mtime=0) as zipped:
 with tarfile.open(fileobj=zipped,mode='w') as archive:
  for name,data in sorted(members.items()):
   info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
data=buffer.getvalue();path=destination/'source319-symbol-owner-selected-results.tar.gz'
assert not path.exists();path.write_bytes(data)
with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as archive:
 assert set(archive.getnames())==set(members)
 assert all(archive.extractfile(name).read()==data for name,data in members.items())
manifest=dict(checkpoint='source319 unapplied owner draft4 selected continuation',archive=dict(path=path.name,bytes=len(data),sha256=sha(data),members=len(members)),selected_audit=audit,retained_large_inputs=retention,excluded_large_test_inputs=excluded,qualification='Complements source319-symbol-owner-unfinished-draft.tar.gz, which contains the exact patches, strict/gate results and original ownership failures. All 229 controls pass in gate/release. Nine ordinary GNU comparisons and three restored public-image comparisons match. Image fingerprint rejection and both standalone link failures remain preserved. The corrected launcher uses the target libc artifact and builds its own fingerprinted image through the unchanged CLI. Public-thread/ERT integration is running separately; broader platform/frozen/terminal/native/module validation, complete ownership, reclamation, accounting and performance remain open.',goal_complete=False)
(destination/'source319-symbol-owner-selected-results-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest['archive']))
