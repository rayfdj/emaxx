from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).resolve().parent
w=p.parent/'recovered-2026-10-09/symbol-obarray/emaxx'
g=p.parent/'rebuilt-2026-10-01/emacs'
out=p/'obarray-draft4-restored-public';out.mkdir(exist_ok=False)
old=p/'obarray-draft4-public';ordinary=p/'obarray-draft4-ordinary'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
source=json.loads((ordinary/'source.json').read_text())
env=json.loads((ordinary/'environment.json').read_text());env.pop('EMAXX_IMAGE_FORCE')
def verify():
 assert all(sha(w/n)==v['sha256'] and oct((w/n).stat().st_mode&0o777)==v['mode'] for n,v in source.items())
verify()
# Keep the established image's directory depth. Copy the exact successful
# public launcher beside it; its default startup selects its own .pdmp.
subject=w/'target/release/owned-image-probe';dump=subject.with_suffix('.pdmp')
assert not subject.exists() and not dump.exists()
subprocess.run(['cp','-c',str(old/'public-instances'),str(subject)],check=True)
subprocess.run(['cp','-c',str(w/'target/release/emaxx.pdmp'),str(dump)],check=True)
assert sha(subject)==sha(old/'public-instances')
for name in ['first.el','second.el','hash-types.el']:(out/name).write_bytes((old/name).read_bytes())
(out/'image-state.el').write_text("(progn (prin1 (list (consp (pdumper-stats)) (eq (hash-table-test (make-hash-table :test 'eq)) 'eq))) (terpri))\n")
record=dict(status='running',source_inputs=source,environment_overrides=env,inputs={n:sha(out/n) for n in ['first.el','second.el','hash-types.el','image-state.el']},artifacts={str(f):sha(f) for f in [subject,dump,g/'src/emacs',g/'src/emacs.pdmp']},processes=[],comparisons=[],goal_complete=False)
def save():(out/'run.json').write_text(json.dumps(record,indent=2)+'\n')
def run(label,command):
 start=time.monotonic()
 with (out/(label+'.stdout')).open('wb') as stdout,(out/(label+'.stderr')).open('wb') as stderr:
  try:
   result=subprocess.run(command,cwd=w,env={**os.environ,**env},stdout=stdout,stderr=stderr,timeout=300);code=result.returncode;timed_out=False
  except subprocess.TimeoutExpired:code=None;timed_out=True
 record['processes'].append(dict(label=label,command=command,exit_code=code,timed_out=timed_out,timeout_seconds=300,elapsed_seconds=time.monotonic()-start,stdout_sha256=sha(out/(label+'.stdout')),stderr_sha256=sha(out/(label+'.stderr'))));save();verify()
 return code
save()
for label,first,second in [('image-state','image-state.el','image-state.el'),('original-name','first.el','second.el'),('hash-types','hash-types.el','hash-types.el')]:
 codes=[]
 for name,program in [('first',first),('second',second)]:codes.append(run(label+'-gnu-'+name,[str(g/'src/emacs'),'-Q','--batch','-l',str(out/program)]))
 codes.append(run(label+'-emaxx-two-editors',[str(subject),str(out/first),str(out/second)]))
 expected=(out/(label+'-gnu-first.stdout')).read_bytes()+(out/(label+'-gnu-second.stdout')).read_bytes();actual=(out/(label+'-emaxx-two-editors.stdout')).read_bytes()
 row=dict(label=label,exit_codes=codes,gnu=expected.decode(errors='replace'),emaxx=actual.decode(errors='replace'),matches=all(x==0 for x in codes) and actual==expected and len(actual.splitlines())==2)
 record['comparisons'].append(row);save();print(json.dumps(row),flush=True)
for name,digest in record['artifacts'].items():assert sha(Path(name))==digest
verify();record.update(status='terminal; retain every actual result',source_unchanged=True);save()
raise SystemExit(0 if all(row['matches'] for row in record['comparisons']) else 1)
