from pathlib import Path
import hashlib
import json
import re
import sys

p = Path(__file__).resolve().parent
draft = sys.argv[1]
assert draft == 'draft2'
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
old_selection = read(p / 'gc-cons-trace-draft1-gate-layout/selection.json')
assert len(old_selection) == 534
results = []
source = None
for profile in ['gate', 'release']:
    out = p / ('gc-cons-trace-' + draft + '-' + profile)
    current = read(out / 'source.json')
    assert len(current) == 572 and current == read(out / 'source-after.json')
    if source is None:
        source = current
    assert source == current
    assert read(out / 'selection.json') == old_selection
    labels = ['build', 'inventory', 'selected']
    if profile == 'gate':
        labels += ['fmt', 'check', 'clippy', 'diff']
    for label in labels:
        receipt = read(out / (label + '.json'))
        assert receipt['exit_code'] == 0
        for stream in ['stdout', 'stderr']:
            path = out / (label + '.' + stream)
            assert sha(path) == receipt[stream + '_sha256']
            assert not re.search(r'^warning(?:\[.*?\])?:', path.read_text(), re.M)
    messages = [json.loads(line) for line in (out / 'build.stdout').read_text().splitlines() if line.startswith('{')]
    assert not any(message.get('message', {}).get('level') in ['warning', 'error'] for message in messages)
    raw = (out / 'selected.stdout').read_text()
    assert 'test result: ok. 534 passed; 0 failed; 0 ignored;' in raw
    passed = re.findall(r'^test (\S+) \.\.\. ok$', raw, re.M)
    assert len(passed) == 534 and set(passed) == set(old_selection)
    assert not re.findall(r'^test (\S+) \.\.\. (?:FAILED|ignored)', raw, re.M)
    binary = read(out / 'binary.json')
    assert sha(out / 'libtest') == binary['sha256']
    results.append(dict(profile=profile, passed=len(passed), failed=0, ignored=0,
                        selection_sha256=sha(out / 'selection.json')))
w = p.parent / 'recovered-2026-10-13/gc-cons-trace/emaxx'
for name, row in source.items():
    assert sha(w / name) == row['sha256'] and oct((w / name).stat().st_mode & 0o777) == row['mode']
audit = dict(status='All 534 unchanged controls pass in gate and release; strict checks have zero warnings',
             source_inputs=len(source), results=results, goal_complete=False,
             qualification='Selected validation of the separately recorded cons tracing/inlining experiment. All original397 symbol controls and137 additional GC/root/reclamation controls remain. This is not a complete platform gate or performance result; no final-goal completion claim.')
(p / ('gc-cons-trace-' + draft + '-selected-audit.json')).open('x').write(json.dumps(audit, indent=2) + '\n')
print(json.dumps(audit))
