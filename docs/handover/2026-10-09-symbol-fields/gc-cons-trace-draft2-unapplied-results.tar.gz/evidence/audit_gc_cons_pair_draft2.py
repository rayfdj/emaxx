from pathlib import Path
import hashlib
import json
import math
import statistics
import sys

p = Path(__file__).resolve().parent
r = p.parents[2]
sys.path.insert(0, str(r / 'tools'))
from core_runtime_perf_pair import audit_pilot

out = p / 'gc-cons-trace-draft2-pair'
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
state = read(out / 'summary.json')
assert state['status'] == 'all 192 actual results and modes verified'
assert state['schedule'] == [['baseline','candidate'], ['candidate','baseline'], ['baseline','candidate']]
assert len(state['pilots']) == 6
assert not read(out / 'process-audit.json')['competing_task_processes']
contract = read(r / 'compat/core_runtime_perf.json')
samples = {label: [audit_pilot(out / (label + '-pilot-' + str(index)), contract) for index in range(3)]
           for label in ['baseline', 'candidate']}
assert len(state['results']) == len(contract['cases']) == 16
for case, row in zip(contract['cases'], state['results']):
    name = case['id']
    assert name == row['case']
    for label in samples:
        actual = [sample[name] for sample in samples[label]]
        assert actual == row['samples'][label]
        bodies = [pair['emaxx']['observation']['seconds'] for pair in actual]
        assert bodies == row['body_samples'][label]
        assert statistics.median(bodies) == row['body_medians'][label]
        ratio = statistics.median(pair['emaxx']['observation']['seconds'] / pair['oracle']['observation']['seconds'] for pair in actual)
        assert ratio == row['gnu_ratios'][label]
        if name == 'explicit-gc':
            assert all(pair[editor]['observation']['gc_count'] == 32 for pair in actual for editor in ['oracle','emaxx'])
    assert row['candidate_over_baseline'] == row['body_medians']['candidate'] / row['body_medians']['baseline']
assert state['raw_body_geometric_ratio'] == math.exp(statistics.mean(math.log(row['candidate_over_baseline']) for row in state['results']))
for row in state['commands']:
    assert row['exit_code'] == 0 and not row['timed_out']
    assert sha(out / (row['stage'] + '.log')) == row['log_sha256']
for label, checkout in [('baseline','gc-cons-baseline'), ('candidate','gc-cons-trace')]:
    inputs = read(out / (label + '-inputs.json'))
    w = p.parent / ('recovered-2026-10-13/' + checkout + '/emaxx')
    assert len(inputs['source']) == 572
    for name, row in inputs['source'].items():
        assert sha(w / name) == row['sha256'] and oct((w / name).stat().st_mode & 0o777) == row['mode']
    for path, digest in inputs['artifacts'].items():
        assert sha(Path(path)) == digest
        assert sha(out / 'artifacts' / label / Path(path).name) == digest
oracle_dir = out / 'oracle-inputs'
captured = read(oracle_dir / 'manifest.json')
oracle = read(oracle_dir / 'verification.json')
assert captured['status'] == 'captured'
assert [row['artifact'] for row in captured['files']] == ['emacs', 'emacs.pdmp', 'config.h', 'Makefile']
assert oracle['status'] == 'unchanged' and oracle['files_verified'] == 4
assert oracle['capture_manifest_sha256'] == sha(oracle_dir / 'manifest.json')
for row in captured['files']:
    for path in [Path(row['original']), oracle_dir / row['artifact']]:
        assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256']
gc = next(row for row in state['results'] if row['case'] == 'explicit-gc')
audit = dict(status='192 actual results and modes independently rechecked',
    source_inputs=572, cases=16, processes=192,
    raw_body_geometric_ratio=state['raw_body_geometric_ratio'],
    explicit_gc_candidate_over_baseline=gc['candidate_over_baseline'],
    paired_gnu_geometric_ratios=state['paired_gnu_geometric_ratios'],
    results=[{key: row[key] for key in ['case','body_samples','body_medians','gnu_ratios','candidate_over_baseline']} for row in state['results']],
    oracle_verification=oracle, goal_complete=False,
    qualification='Three alternating diagnostic pilots over all16 locked workloads on macOS, with the unchanged534 controls in each profile and28 ordinary comparisons checked first. All samples remain. This is not the calibrated nine-round/every-workload GNU-ratio ceiling of1.03. No full platform validation, real public allocation counters, or final-goal completion. Candidate adds inline(always) to the previously rejected direct cons tracing helper; generated-code observations and the adoption decision are separate.')
(p / 'gc-cons-trace-draft2-performance-audit.json').open('x').write(json.dumps(audit, indent=2) + '\n')
print(json.dumps({key: audit[key] for key in ['status','cases','processes','raw_body_geometric_ratio','explicit_gc_candidate_over_baseline','paired_gnu_geometric_ratios']}))
