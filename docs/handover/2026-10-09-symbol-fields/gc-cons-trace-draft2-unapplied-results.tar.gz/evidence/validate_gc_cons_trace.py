from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time

p = Path(__file__).resolve().parent
w = p.parent / 'recovered-2026-10-13/gc-cons-trace/emaxx'
g = p.parent / 'rebuilt-2026-10-01/emacs'
out = p / sys.argv[1]
profile = sys.argv[2]
assert profile in ['gate', 'release']
out.mkdir(exist_ok=False)
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
names = json.loads((p / 'source324-source.json').read_text())
def manifest():
    return {name: dict(sha256=sha(w / name), mode=oct((w / name).stat().st_mode & 0o777)) for name in names}
source = manifest()
assert len(source) == 572
assert [name for name in source if source[name] != names[name]] == ['src/lisp/eval.rs']
(out / 'source.json').write_text(json.dumps(source, indent=2) + '\n')
(out / 'tracked.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary'], cwd=w))
overrides = dict(LANG='C', LC_ALL='C', CARGO_BUILD_JOBS='1', CARGO_NET_OFFLINE='true',
    RUST_TEST_THREADS='1', RUST_MIN_STACK='134217728', EMAXX_GC_VERIFY='1', EMAXX_IMAGE_TEMPLATE='1',
    EMAXX_GNU_SOURCE_DIRECTORY=str(g), EMAXX_DUMP_SOURCE_DIRECTORY=str(g),
    EMACS_TEST_DIRECTORY=str(g / 'test'), EMAXX_FIXTURE_IMAGE_DIR=str(out / 'fixture-images'))
(out / 'environment.json').write_text(json.dumps(overrides, indent=2) + '\n')
def run(label, command):
    assert manifest() == source
    print('START', label, flush=True)
    start = time.monotonic()
    with (out / (label + '.stdout')).open('xb') as stdout, (out / (label + '.stderr')).open('xb') as stderr:
        process = subprocess.run(command, cwd=w, env={**os.environ, **overrides}, stdout=stdout, stderr=stderr)
    row = dict(command=command, cwd=str(w), exit_code=process.returncode,
               elapsed_seconds=time.monotonic() - start,
               stdout_sha256=sha(out / (label + '.stdout')), stderr_sha256=sha(out / (label + '.stderr')))
    (out / (label + '.json')).write_text(json.dumps(row, indent=2) + '\n')
    assert manifest() == source
    print('END', label, process.returncode, round(row['elapsed_seconds'], 2), flush=True)
    if process.returncode:
        print((out / (label + '.stderr')).read_text()[-4000:], flush=True)
        print((out / (label + '.stdout')).read_text()[-4000:], flush=True)
        raise SystemExit(process.returncode)
    for stream in ['stdout', 'stderr']:
        assert not re.search(r'^warning(?:\[.*?\])?:', (out / (label + '.' + stream)).read_text(), re.M)
    return out / (label + '.stdout')
if 'strict' in sys.argv:
    for label, command in [
        ('fmt', ['cargo', 'fmt', '--all', '--', '--check']),
        ('check', ['cargo', 'check', '--locked', '--offline', '--all-targets', '--all-features']),
        ('clippy', ['cargo', 'clippy', '--locked', '--offline', '--all-targets', '--all-features', '--', '-D', 'warnings']),
        ('diff', ['git', 'diff', '--check']),
    ]:
        run(label, command)
build = run('build', ['cargo', 'test', '--locked', '--offline', '--profile', profile,
                      '--all-features', '--lib', '--no-run', '--message-format=json'])
artifacts = [entry for line in build.read_text().splitlines() if line.startswith('{')
    and (entry := json.loads(line)).get('reason') == 'compiler-artifact'
    and entry.get('executable') and 'lib' in entry['target']['kind'] and entry['profile']['test']]
assert len(artifacts) == 1
binary = Path(artifacts[0]['executable'])
subprocess.run(['cp', '-c', str(binary), str(out / 'libtest')], check=True)
assert sha(binary) == sha(out / 'libtest')
(out / 'binary.json').write_text(json.dumps(dict(original=str(binary), retained=str(out / 'libtest'), sha256=sha(binary)), indent=2) + '\n')
inventory = run('inventory', [str(binary), '--list'])
all_names = sorted(line[:-6] for line in inventory.read_text().splitlines() if line.endswith(': test'))
old = json.loads((p.parent / 'allocated-symbols-2026-10-10/fields-identity-draft5-gate/selection.json').read_text())
assert len(old) == 397 and set(old) <= set(all_names)
selected = sorted(set(old) | {name for name in all_names if re.search(r'gc|weak|reclaim|root|cons_|mark_', name)})
(out / 'selection.json').write_text(json.dumps(selected, indent=2) + '\n')
print('SELECTION', len(selected), 'preserving all397 original controls', flush=True)
log = run('selected', [str(binary), '--exact', '--test-threads=1', *selected])
assert f'test result: ok. {len(selected)} passed; 0 failed; 0 ignored;' in log.read_text()
(out / 'source-after.json').write_text(json.dumps(manifest(), indent=2) + '\n')
print('PASS', profile, len(selected), 'controls; not full platform or performance validation', flush=True)
