from pathlib import Path
import json

p = Path(__file__).resolve().parent
read = lambda path: json.loads(path.read_text())
audit = read(p / 'gc-cons-trace-draft2-performance-audit.json')
assert audit['processes'] == 192
decision = dict(status='Keep draft2 unapplied; these pilots do not establish an overall benefit',
    source_inputs=572, changed_file='src/lisp/eval.rs',
    aggregate_candidate_over_main=audit['raw_body_geometric_ratio'],
    gc_candidate_over_main=audit['explicit_gc_candidate_over_baseline'],
    generated_code='The out-of-line mark_and_trace symbol is absent. The pending loop uses one272-byte frame, matching baseline. Its10776code bytes exceed baseline10260. This removes draft1\'s per-object call but is not a complete explanation of the measured timings.',
    next_work='Return to the known symbol constant/store identity defect in the separate membership prototype. Preserve this patch and all results; do not apply either GC experiment to main.',
    qualification='Three diagnostic pilots, not calibrated acceptance or causal attribution of all per-workload changes. All192actual results/modes match; all32explicit collections occur in both editors for every GC observation. Full goal and the current production GC regression remain open.', goal_complete=False)
(p / 'gc-cons-trace-draft2-decision.json').open('x').write(json.dumps(decision, indent=2) + '\n')
ns = {'__file__': str(p / 'package_source323_base.py')}
exec((p / 'package_source323_base.py').read_text(), ns)
ns['destination'] = p / 'pending-publication-gc-cons'
trees = ['gc-cons-trace-draft2-gate', 'gc-cons-trace-draft2-release',
         'gc-cons-trace-draft2-ordinary', 'gc-cons-trace-draft2-pair',
         'gc-cons-trace-draft2-code']
files = ['gc-cons-trace-draft2-selected-audit.json',
         'gc-cons-trace-draft2-ordinary-audit.json',
         'gc-cons-trace-draft2-performance-audit.json',
         'gc-cons-trace-draft2-replay.json', 'gc-cons-trace-draft2-decision.json',
         'validate_gc_cons_trace.py', 'audit_gc_cons_selected.py',
         'ordinary_gc_cons_trace_draft2.py', 'audit_gc_cons_ordinary_draft2.py',
         'measure_gc_cons_pair_draft2.py', 'audit_gc_cons_pair_draft2.py',
         'inspect_gc_cons_draft2_code.py', 'replay_gc_cons_trace_draft2.py',
         'package_source323_base.py', Path(__file__).name]
ns['package']('gc-cons-trace-draft2-unapplied-results',
    [('evidence/' + name, p / name) for name in trees],
    [('evidence/' + name, p / name) for name in files],
    dict(checkpoint='Unapplied direct cons tracing with inline helper',
         audit=audit, decision=decision,
         selected=read(p / 'gc-cons-trace-draft2-selected-audit.json'),
         ordinary=read(p / 'gc-cons-trace-draft2-ordinary-audit.json'),
         qualification='534 unchanged controls pass in each profile with strict zero-warning checks;28 ordinary comparisons and192 timed answers/modes match. The three full16 macOS pilots show3.11%faster explicitGC but1.15%slower aggregate versus fresh main758d2138. This does not establish an overall benefit; keep the draft separate. No final performance acceptance or full-platform certification. Draft1 failures and unfavorable results remain separate and preserved.'))
