from pathlib import Path
import hashlib
import json
import subprocess

p = Path(__file__).resolve().parent
out = p / 'gc-cons-trace-draft2-code'
out.mkdir(exist_ok=False)
w = p.parent / 'recovered-2026-10-13/gc-cons-trace/emaxx'
binary = w / 'target/release/emaxx'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
ordinary = json.loads((p / 'gc-cons-trace-draft2-ordinary/artifacts-after.json').read_text())
identity = ordinary[str(binary)]
assert sha(binary) == identity['sha256']
retained = p / 'gc-cons-trace-draft2-ordinary/retained-inputs' / (identity['sha256'] + '-emaxx')
assert sha(retained) == identity['sha256']
commands = []
def run(label, command):
    result = subprocess.run(command, capture_output=True)
    stdout = out / (label + '.stdout')
    stderr = out / (label + '.stderr')
    stdout.write_bytes(result.stdout)
    stderr.write_bytes(result.stderr)
    commands.append(dict(label=label, command=command, exit_code=result.returncode,
                         stdout_sha256=sha(stdout), stderr_sha256=sha(stderr)))
    (out / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    assert result.returncode == 0 and not result.stderr
    return result.stdout.decode()
symbols = run('symbols', ['xcrun', 'llvm-nm', '--defined-only', str(retained)])
rows = []
for line in symbols.splitlines():
    parts = line.split(None, 2)
    if len(parts) == 3 and parts[1].lower() == 't':
        rows.append((int(parts[0], 16), parts[2]))
rows.sort()
selected = []
for index, (start, name) in enumerate(rows):
    if ('LispReachability' in name and any(token in name for token in ['trace_pending', 'mark_and_trace'])) or ('mark_all_stacks' in name and 'weak_hash_reachability' in name):
        end = next(address for address, _ in rows[index + 1:] if address > start)
        label = 'range-' + str(len(selected))
        assembly = run(label, ['xcrun', 'llvm-objdump', '--disassemble', '--demangle',
            '--no-show-raw-insn', '--start-address=' + hex(start), '--stop-address=' + hex(end), str(retained)])
        selected.append(dict(symbol=name, start=hex(start), end=hex(end), bytes=end-start,
                             assembly=label + '.stdout', lines=len(assembly.splitlines())))
assert selected
assert sha(retained) == sha(binary) == identity['sha256']
record = dict(binary=str(retained), identity=identity, ranges=selected,
    out_of_line_mark_and_trace=[name for _,name in rows if 'LispReachability' in name and 'mark_and_trace' in name],
    out_of_line_trace_pending=[name for _,name in rows if 'LispReachability' in name and 'trace_pending' in name],
    qualification='Generated-code evidence only. Inspect the retained loop and caller ranges; this does not establish elapsed-time improvement or isolate every contribution.', goal_complete=False)
(out / 'summary.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
