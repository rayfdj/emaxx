"""Compare the isolated cons-marking change with fresh main; diagnostic only."""
from pathlib import Path
import hashlib
import json
import math
import os
import re
import statistics
import subprocess
import sys
import time

p = Path(__file__).resolve().parent
r = p.parents[2]
g = p.parent / 'rebuilt-2026-10-01/emacs'
sys.path.insert(0, str(r / 'tools'))
import core_runtime_perf as perf
from core_runtime_perf_pair import audit_pilot
import retain_oracle_artifacts

read = lambda path: json.loads(path.read_text())
source = read(p / 'source324-source.json')
candidate_source = read(p / 'gc-cons-trace-draft2-gate/source.json')
assert len(source) == len(candidate_source) == 572
assert [name for name in source if source[name] != candidate_source[name]] == ['src/lisp/eval.rs']
assert read(p / 'gc-cons-trace-draft2-release/selected.json')['exit_code'] == 0
assert 'test result: ok. 534 passed; 0 failed; 0 ignored;' in (p / 'gc-cons-trace-draft2-release/selected.stdout').read_text()
assert read(p / 'gc-cons-trace-draft2-ordinary/summary.json') == dict(processes=56, passed=56, failed=0, source_inputs=572, goal_complete=False)
baseline_audit = read(p / 'gc-cons-trace-main-baseline/audit.json')
assert baseline_audit['status'] == 'fresh clean main release build and image prepared'
ordinary = read(p / 'gc-cons-trace-draft2-ordinary/artifacts-after.json')
assert ordinary == read(p / 'gc-cons-trace-draft2-ordinary/artifacts-before.json')
out = p / 'gc-cons-trace-draft2-pair'
out.mkdir(exist_ok=False)
subjects = {
    'baseline': dict(checkout=p.parent / 'recovered-2026-10-13/gc-cons-baseline/emaxx',
                     source=source, head='758d2138e9fe834abf6391a84946af32b30f5c6c'),
    'candidate': dict(checkout=p.parent / 'recovered-2026-10-13/gc-cons-trace/emaxx',
                      source=candidate_source, head='999362622a68d6508c356541422f7a48ae6e2175'),
}
state = dict(status='preparing native inputs', source_runtime='999362622a68d6508c356541422f7a48ae6e2175',
    changed_source='src/lisp/eval.rs', commands=[], pilots=[], goal_complete=False,
    schedule=[['baseline','candidate'], ['candidate','baseline'], ['baseline','candidate']],
    qualification='Three alternating full16 diagnostic pilots on one macOS host, after both fresh release builds, correctness checks and native preparation. The source324 baseline is fresh clean main758d2138; the candidate is the separately recorded one-file cons-marking patch on99936262. All sources, modes, results, samples, GC counts, startup/body/total time and RSS remain. This is not calibrated nine-round/every-workload3% acceptance. Missing public allocation counters remain explicit.')
overrides = dict(LANG='C', LC_ALL='C', CARGO_BUILD_JOBS='1',
    EMAXX_GNU_SOURCE_DIRECTORY=str(g), EMAXX_DUMP_SOURCE_DIRECTORY=str(g), EMACS_TEST_DIRECTORY=str(g / 'test'))
environment = {key: value for key, value in os.environ.items() if not key.startswith('EMAXX_') and key != 'GH_TOKEN'}
environment.update(overrides)
(out / 'environment.json').write_text(json.dumps(overrides, indent=2) + '\n')
def save():
    perf.write_json(out / 'summary.json', state)
def verify():
    for label, subject in subjects.items():
        w = subject['checkout']
        assert perf.git(w, 'rev-parse', 'HEAD') == subject['head']
        for name, row in subject['source'].items():
            assert perf.sha256(w / name) == row['sha256'] and oct((w / name).stat().st_mode & 0o777) == row['mode'], (label, name)
        changed = perf.git(w, 'diff', '--name-only').splitlines()
        assert changed == ([] if label == 'baseline' else ['src/lisp/eval.rs'])
        if 'artifacts' in subject:
            assert all(perf.sha256(Path(path)) == digest for path, digest in subject['artifacts'].items())
def execute(label, command, cwd, timeout=1800):
    verify()
    row = dict(stage=label, command=[str(value) for value in command], cwd=str(cwd), timeout_seconds=timeout)
    state['commands'].append(row)
    state['status'] = 'running ' + label
    save()
    print('START', label, flush=True)
    start = time.monotonic()
    with (out / (label + '.log')).open('xb') as log:
        try:
            process = subprocess.run(row['command'], cwd=cwd, env=environment,
                stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, timeout=timeout)
            row.update(exit_code=process.returncode, timed_out=False)
        except subprocess.TimeoutExpired:
            row.update(exit_code=None, timed_out=True)
    row.update(elapsed_seconds=time.monotonic() - start, log_sha256=perf.sha256(out / (label + '.log')))
    save()
    print('END', label, row['exit_code'], round(row['elapsed_seconds'], 2), flush=True)
    verify()
    assert row['exit_code'] == 0 and not row['timed_out'], label
save()
try:
    verify()
    capture = retain_oracle_artifacts.capture(g, out / 'oracle-inputs')
    lock = read(r / 'compat/oracle.lock.json')
    assert capture['source_commit'] == lock['emacs_repo_commit']
    assert capture['files'][0]['sha256'] == lock['emacs_binary_sha256']
    measurement = {name: perf.sha256(r / name) for name in ['tools/core_runtime_perf.py', 'compat/core_runtime_perf.json', 'compat/core_runtime_perf.el']}
    for label, subject in subjects.items():
        w = subject['checkout']
        assert all(perf.sha256(w / name) == digest for name, digest in measurement.items())
        binary = w / 'target/release/emaxx'
        paths = [binary, binary.with_suffix('.pdmp')]
        subject['artifacts'] = {str(path): perf.sha256(path) for path in paths}
        if label == 'baseline':
            recorded = {row['original']: row['sha256'] for row in baseline_audit['inputs']}
        else:
            recorded = {path: row['sha256'] for path, row in ordinary.items()}
        assert all(recorded[str(path)] == perf.sha256(path) for path in paths)
        retained = out / 'artifacts' / label
        retained.mkdir(parents=True)
        for path in paths:
            target = retained / path.name
            subprocess.run(['cp', '-c', str(path), str(target)], check=True)
            assert perf.sha256(target) == perf.sha256(path)
        subject['native'] = out / (label + '-native')
        subject['args'] = ['--source', g, '--oracle', g / 'src/emacs', '--emaxx', binary, '--diagnostic']
        perf.write_json(out / (label + '-inputs.json'), dict(head=subject['head'], source=subject['source'],
            artifacts=subject['artifacts'], source_patch=perf.git(w, 'diff', '--binary'),
            rustc=subprocess.check_output(['rustc', '-Vv'], text=True), cargo=subprocess.check_output(['cargo', '-V'], text=True)))
        execute(label + '-native', [sys.executable, '-B', 'tools/core_runtime_perf.py', 'prepare',
                *subject['args'], '--output', subject['native']], w)
    processes = subprocess.check_output(['ps', '-axo', 'pid,ppid,args'], text=True)
    competitors = [line for line in processes.splitlines() if any(token in line for token in (
        'cargo build ', 'cargo test ', '/rustc ', 'serial_grouped_gate.py', 'tools/ttydiff.py',
        'compat-harness frozen', 'perf record ', '/usr/bin/sample ', '--test-threads=1'))]
    perf.write_json(out / 'process-audit.json', dict(competing_task_processes=competitors,
        process_listing_sha256=hashlib.sha256(processes.encode()).hexdigest()))
    assert not competitors, 'competing task process before timing'
    contract = read(r / 'compat/core_runtime_perf.json')
    perf.validate_contract(contract)
    samples = {label: [] for label in subjects}
    for repetition, order in enumerate(state['schedule']):
        for label in order:
            subject = subjects[label]
            location = out / (label + '-pilot-' + str(repetition))
            execute(label + '-pilot-' + str(repetition), [sys.executable, '-B', 'tools/core_runtime_perf.py', 'pilot',
                    *subject['args'], '--pilot-runner', 'both', '--native-dir', subject['native'], '--output', location], subject['checkout'])
            samples[label].append(audit_pilot(location, contract))
            state['pilots'].append(dict(label=label, repetition=repetition, processes=32, raw_directory=location.name))
            save()
    verify()
    results = []
    for case in contract['cases']:
        name = case['id']
        bodies = {label: [sample[name]['emaxx']['observation']['seconds'] for sample in group] for label, group in samples.items()}
        medians = {label: statistics.median(values) for label, values in bodies.items()}
        ratios = {label: statistics.median(sample[name]['emaxx']['observation']['seconds'] / sample[name]['oracle']['observation']['seconds'] for sample in group) for label, group in samples.items()}
        results.append(dict(case=name, body_samples=bodies, body_medians=medians, gnu_ratios=ratios,
            candidate_over_baseline=medians['candidate'] / medians['baseline'], samples={label: [sample[name] for sample in group] for label, group in samples.items()}))
    state.update(status='all 192 actual results and modes verified', results=results,
        raw_body_geometric_ratio=math.exp(statistics.mean(math.log(row['candidate_over_baseline']) for row in results)),
        paired_gnu_geometric_ratios={label: math.exp(statistics.mean(math.log(row['gnu_ratios'][label]) for row in results)) for label in subjects})
except (AssertionError, OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as error:
    state.update(status='diagnostic stopped', error=repr(error))
finally:
    try:
        state['oracle_verification'] = retain_oracle_artifacts.verify(out / 'oracle-inputs')
    except (OSError, ValueError, KeyError) as error:
        state.update(status='diagnostic stopped', oracle_verification_error=repr(error))
    save()
print(json.dumps({key: state[key] for key in ['status', 'raw_body_geometric_ratio', 'paired_gnu_geometric_ratios', 'error'] if key in state}), flush=True)
raise SystemExit(0 if state['status'] == 'all 192 actual results and modes verified' else 1)
