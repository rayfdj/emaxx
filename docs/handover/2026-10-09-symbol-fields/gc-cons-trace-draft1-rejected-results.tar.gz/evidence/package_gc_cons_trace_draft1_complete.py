from pathlib import Path
import json

p = Path(__file__).resolve().parent
read = lambda path: json.loads(path.read_text())
audit = read(p / 'gc-cons-trace-draft1-performance-audit.json')
assert audit['processes'] == 192 and audit['raw_body_geometric_ratio'] > 1
ns = {'__file__': str(p / 'package_source323_base.py')}
exec((p / 'package_source323_base.py').read_text(), ns)
ns['destination'] = p / 'pending-publication-gc-cons'
ns['destination'].mkdir(exist_ok=True)
trees = ['gc-cons-trace-draft1-gate-layout', 'gc-cons-trace-draft1-release',
         'gc-cons-trace-draft1-ordinary', 'gc-cons-trace-main-baseline',
         'gc-cons-trace-draft1-pair', 'gc-cons-trace-draft1-code']
files = ['gc-cons-trace-draft1-selected-audit.json',
         'gc-cons-trace-draft1-gate-layout-audit.json',
         'gc-cons-trace-draft1-ordinary-audit.json',
         'gc-cons-trace-draft1-performance-audit.json',
         'gc-cons-trace-draft1-replay.json',
         'gc-cons-trace-draft1-c-mapping.json',
         'gc-cons-trace-draft1-audit-count-correction.json',
         'gc-cons-trace-draft1-ordinary-audit.invalid-comparison-count.json',
         'audit_gc_cons_ordinary.invalid-comparison-count.py',
         'audit_gc_cons_pair.duplicate-verification.py',
         'gc-cons-trace-draft1-audit-receipt-correction.json',
         'validate_gc_cons_trace.py', 'ordinary_gc_cons_trace.py',
         'audit_gc_cons_ordinary.py', 'measure_gc_cons_pair.py',
         'audit_gc_cons_pair.py', 'build_gc_cons_baseline.py',
         'replay_gc_cons_trace.py', 'package_source323_base.py',
         'source324-main-merge.json', Path(__file__).name]
ns['package']('gc-cons-trace-draft1-rejected-results',
    [('evidence/' + name, p / name) for name in trees],
    [('evidence/' + name, p / name) for name in files],
    dict(checkpoint='Unapplied source324 cons-tracing experiment; rejected after measurement',
         audit=audit, selected=read(p / 'gc-cons-trace-draft1-selected-audit.json'),
         ordinary=read(p / 'gc-cons-trace-draft1-ordinary-audit.json'),
         qualification='534 selected controls pass in each profile with unchanged assertions and zero-warning strict checks; all28 ordinary comparisons and192 timed answers/modes match. Three alternating full16 pilots on macOS show1.9256%aggregate and10.4904%explicitGC regressions versus fresh main758d2138. Keep this experiment unapplied. The initial438pass/96failure missing-fixture attempt remains in the separately published unfinished archive. Generated-code observations identify an additional per-object helper call, not a complete causal decomposition. No calibrated nine-round performance acceptance or full-platform validation. Large binaries/images are excluded explicitly with retained local paths and identities.'))
