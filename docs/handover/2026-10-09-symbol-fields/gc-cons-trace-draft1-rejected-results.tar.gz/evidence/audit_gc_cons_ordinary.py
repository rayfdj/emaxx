from pathlib import Path
import hashlib
import json
import re

p = Path(__file__).resolve().parent
out = p / 'gc-cons-trace-draft1-ordinary'
w = p.parent / 'recovered-2026-10-13/gc-cons-trace/emaxx'
f = p.parent / 'allocated-symbols-2026-10-10'
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
source = read(out / 'source.json')
assert source == read(p / 'gc-cons-trace-draft1-gate-layout/source.json') and len(source) == 572
for name, row in source.items():
    assert sha(w / name) == row['sha256'] and oct((w / name).stat().st_mode & 0o777) == row['mode']
assert read(out / 'summary.json') == dict(processes=56, passed=56, failed=0, source_inputs=572, goal_complete=False)
results = read(out / 'results.json')
assert len(results) == 56
pairs = {}
for row in results:
    label = '-'.join([row['fixture'], row['mode'], row['editor']])
    receipt = read(out / (label + '.json'))
    assert receipt['exit_code'] == 0 and not receipt['timed_out'] and receipt['timeout_seconds'] == 180
    for stream in ['stdout', 'stderr']:
        assert sha(out / (label + '.' + stream)) == receipt[stream + '_sha256']
    output = (out / (label + '.stdout')).read_text()
    assert output == row['stdout'] and output.strip() == row['expected'] and row['passed']
    if row['mode'] != 'interpreted':
        assert output.startswith('((t t t t) ' if row['fixture'] == 'symbol-redirect-lifetime' else '(t ')
    pair = pairs.setdefault((row['fixture'], row['mode']), {})
    assert row['editor'] not in pair
    pair[row['editor']] = (output, receipt['command'][1:])
assert len(pairs) == 28 and all(set(pair) == {'gnu', 'emaxx'} and pair['gnu'] == pair['emaxx'] for pair in pairs.values())
previous = {(row['fixture'], row['mode']) for row in read(f / 'fields-identity-draft5-ordinary/results.json')}
assert len(previous) == 28 and previous == set(pairs)
for label in ['build', 'image']:
    receipt = read(out / (label + '.json'))
    assert receipt['exit_code'] == 0 and not receipt['timed_out']
    if label == 'build':
        messages = [json.loads(line) for line in (out / 'build.stdout').read_text().splitlines() if line.startswith('{')]
        assert not any(message.get('message', {}).get('level') in ['warning', 'error'] for message in messages)
        executables = [row for row in messages if row.get('reason') == 'compiler-artifact' and row['target']['name'] == 'emaxx' and row.get('executable')]
        assert len(executables) == 1 and not executables[0]['fresh']
    for stream in ['stdout', 'stderr']:
        path = out / (label + '.' + stream)
        assert sha(path) == receipt[stream + '_sha256']
        assert not re.search(rb'^warning(?:\[.*?\])?:', path.read_bytes(), re.M)
extra = read(out / 'eshell-inputs-before.json')
assert extra == read(out / 'eshell-inputs-after.json')
assert (out / 'completion-contract.el').read_bytes() == (f / 'fields-draft16-eshell-file-observation/completion-contract.el').read_bytes()
for name, row in extra.items():
    assert sha(Path(name)) == row['sha256'] and Path(name).stat().st_size == row['bytes']
identities = read(out / 'artifacts-before.json')
assert identities == read(out / 'artifacts-after.json') and len(identities) == 4
retention = []
for name, row in identities.items():
    path = Path(name)
    retained = out / 'retained-inputs' / (row['sha256'] + '-' + path.name)
    assert sha(path) == sha(retained) == row['sha256']
    assert path.stat().st_size == retained.stat().st_size == row['bytes']
    retention.append(dict(original=name, retained=str(retained), **row))
audit = dict(status='passed', source_inputs_verified=572, processes=len(results), comparisons=len(pairs),
             actual_modes=['interpreted', 'bytecode', 'native'], identical_editor_arguments=True,
             previous_twenty_eight_comparisons_preserved=True, same_twenty_eight_comparison_inventory=True,
             retained_inputs=retention, goal_complete=False,
             qualification='Unapplied cons tracing experiment, preserving all original28 ordinary comparisons. All expected outputs and actual mode predicates are checked from raw output; compiler/image stages have no warnings. Each editor uses its own executable and image. The known source324 constant/store adapters remain separate unfinished architecture. This is not a full platform gate, proof of public ownership or a performance result.')
(p / 'gc-cons-trace-draft1-ordinary-audit.json').open('x').write(json.dumps(audit, indent=2) + '\n')
print(json.dumps({key: audit[key] for key in ['status', 'source_inputs_verified', 'processes', 'comparisons', 'actual_modes']}))
