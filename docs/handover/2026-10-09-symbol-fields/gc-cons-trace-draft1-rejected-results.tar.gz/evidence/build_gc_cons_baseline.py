from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time

p = Path(__file__).resolve().parent
w = p.parent / 'recovered-2026-10-13/gc-cons-baseline/emaxx'
g = p.parent / 'rebuilt-2026-10-01/emacs'
out = p / 'gc-cons-trace-main-baseline'
out.mkdir(exist_ok=False)
source = json.loads((p / 'source324-source.json').read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=w, text=True).strip() == '758d2138e9fe834abf6391a84946af32b30f5c6c'
def check():
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=w, text=True).strip()
    for name, row in source.items():
        assert sha(w / name) == row['sha256'] and oct((w / name).stat().st_mode & 0o777) == row['mode']
check()
(out / 'source.json').write_text(json.dumps(source, indent=2) + '\n')
overrides = dict(LANG='C', LC_ALL='C', CARGO_BUILD_JOBS='1', CARGO_NET_OFFLINE='true',
    EMAXX_GNU_SOURCE_DIRECTORY=str(g), EMAXX_DUMP_SOURCE_DIRECTORY=str(g),
    EMACS_TEST_DIRECTORY=str(g / 'test'), EMAXX_IMAGE_FORCE='1')
(out / 'environment.json').write_text(json.dumps(overrides, indent=2) + '\n')
def run(label, command):
    print('START', label, flush=True)
    check()
    start = time.monotonic()
    with (out / (label + '.stdout')).open('xb') as stdout, (out / (label + '.stderr')).open('xb') as stderr:
        try:
            process = subprocess.run(command, cwd=w, env={**os.environ, **overrides}, stdout=stdout, stderr=stderr, timeout=1800)
            code, timed_out = process.returncode, False
        except subprocess.TimeoutExpired:
            code, timed_out = None, True
    receipt = dict(command=command, cwd=str(w), exit_code=code, timed_out=timed_out,
        elapsed_seconds=time.monotonic() - start, timeout_seconds=1800,
        stdout_sha256=sha(out / (label + '.stdout')), stderr_sha256=sha(out / (label + '.stderr')))
    (out / (label + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    print('END', label, code, round(receipt['elapsed_seconds'], 2), flush=True)
    check()
    assert code == 0 and not timed_out
    for stream in ['stdout', 'stderr']:
        assert not re.search(r'^warning(?:\[.*?\])?:', (out / (label + '.' + stream)).read_text(), re.M)
run('build', ['cargo', 'build', '--locked', '--offline', '--release', '--all-features',
              '--bin', 'emaxx', '--bin', 'make-fingerprint', '--message-format=json'])
messages = [json.loads(line) for line in (out / 'build.stdout').read_text().splitlines() if line.startswith('{')]
assert not any(message.get('message', {}).get('level') in ['warning', 'error'] for message in messages)
artifacts = [row for row in messages if row.get('reason') == 'compiler-artifact' and row['target']['name'] == 'emaxx' and row.get('executable')]
assert len(artifacts) == 1 and not artifacts[0]['fresh']
binary = Path(artifacts[0]['executable'])
assert binary == w / 'target/release/emaxx'
run('image', ['sh', 'tools/build-image.sh', str(binary)])
retained = out / 'retained-inputs'
retained.mkdir()
inputs = []
for path in [binary, binary.with_suffix('.pdmp'), g / 'src/emacs', g / 'src/emacs.pdmp']:
    target = retained / (sha(path) + '-' + path.name)
    subprocess.run(['cp', '-c', str(path), str(target)], check=True)
    assert sha(path) == sha(target)
    inputs.append(dict(original=str(path), retained=str(target), sha256=sha(path), bytes=path.stat().st_size))
record = dict(status='fresh clean main release build and image prepared', inputs=inputs,
    runtime_inputs=572, source_commit='758d2138e9fe834abf6391a84946af32b30f5c6c',
    rustc=subprocess.check_output(['rustc', '-Vv'], text=True), cargo=subprocess.check_output(['cargo', '-V'], text=True),
    qualification='Preparation only, before any timing; same runtime inputs as source324. No new runtime or performance acceptance.', goal_complete=False)
(out / 'audit.json').write_text(json.dumps(record, indent=2) + '\n')
print('PASS fresh baseline release preparation', flush=True)
