from pathlib import Path
import hashlib
import json
import math
import statistics
import sys

p = Path(__file__).resolve().parent
r = p.parents[2]
sys.path.insert(0, str(r / 'tools'))
from core_runtime_perf_pair import audit_pilot

out = p / 'gc-cons-trace-draft1-pair'
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
state = read(out / 'summary.json')
assert state['status'] == 'all 192 actual results and modes verified'
assert state['schedule'] == [['baseline','candidate'], ['candidate','baseline'], ['baseline','candidate']]
assert len(state['pilots']) == 6
assert not read(out / 'process-audit.json')['competing_task_processes']
contract = read(r / 'compat/core_runtime_perf.json')
samples = {label: [audit_pilot(out / (label + '-pilot-' + str(index)), contract) for index in range(3)]
           for label in ['baseline', 'candidate']}
assert len(state['results']) == len(contract['cases']) == 16
for case, row in zip(contract['cases'], state['results']):
    name = case['id']
    assert name == row['case']
    for label in samples:
        actual = [sample[name] for sample in samples[label]]
        assert actual == row['samples'][label]
        bodies = [pair['emaxx']['observation']['seconds'] for pair in actual]
        assert bodies == row['body_samples'][label]
        assert statistics.median(bodies) == row['body_medians'][label]
        ratio = statistics.median(pair['emaxx']['observation']['seconds'] / pair['oracle']['observation']['seconds'] for pair in actual)
        assert ratio == row['gnu_ratios'][label]
        if name == 'explicit-gc':
            assert all(pair[editor]['observation']['gc_count'] == 32 for pair in actual for editor in ['oracle','emaxx'])
    assert row['candidate_over_baseline'] == row['body_medians']['candidate'] / row['body_medians']['baseline']
assert state['raw_body_geometric_ratio'] == math.exp(statistics.mean(math.log(row['candidate_over_baseline']) for row in state['results']))
for row in state['commands']:
    assert row['exit_code'] == 0 and not row['timed_out']
    assert sha(out / (row['stage'] + '.log')) == row['log_sha256']
for label, checkout in [('baseline','gc-cons-baseline'), ('candidate','gc-cons-trace')]:
    inputs = read(out / (label + '-inputs.json'))
    w = p.parent / ('recovered-2026-10-13/' + checkout + '/emaxx')
    assert len(inputs['source']) == 572
    for name, row in inputs['source'].items():
        assert sha(w / name) == row['sha256'] and oct((w / name).stat().st_mode & 0o777) == row['mode']
    for path, digest in inputs['artifacts'].items():
        assert sha(Path(path)) == digest
        assert sha(out / 'artifacts' / label / Path(path).name) == digest
oracle_dir = out / 'oracle-inputs'
captured = read(oracle_dir / 'manifest.json')
oracle = read(oracle_dir / 'verification.json')
assert captured['status'] == 'captured'
assert [row['artifact'] for row in captured['files']] == ['emacs', 'emacs.pdmp', 'config.h', 'Makefile']
assert oracle['status'] == 'unchanged' and oracle['files_verified'] == 4
assert oracle['capture_manifest_sha256'] == sha(oracle_dir / 'manifest.json')
for row in captured['files']:
    for path in [Path(row['original']), oracle_dir / row['artifact']]:
        assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256']
gc = next(row for row in state['results'] if row['case'] == 'explicit-gc')
audit = dict(status='192 actual results and modes independently rechecked; slower draft remains unapplied',
    source_inputs=572, cases=16, processes=192,
    raw_body_geometric_ratio=state['raw_body_geometric_ratio'],
    explicit_gc_candidate_over_baseline=gc['candidate_over_baseline'],
    paired_gnu_geometric_ratios=state['paired_gnu_geometric_ratios'],
    results=[{key: row[key] for key in ['case','body_samples','body_medians','gnu_ratios','candidate_over_baseline']} for row in state['results']],
    oracle_verification=oracle, goal_complete=False,
    decision='Do not apply draft1: these pilots show1.9256%aggregate regression and10.4904%explicitGC regression versus fresh main. Preserve every sample; no calibrated confidence or final performance acceptance claim.',
    code_observation='Retained Mach-O code has trace_pending as the baseline loop; candidate code calls the out-of-line10132-byte mark_and_trace function per queued object. Its224-byte stack frame is entered per call. This is a concrete extra cost and a hypothesis for the slowdown; the measurement does not isolate every contribution.',
    environment_review='The ordinary candidate image build used EMAXX_GC_VERIFY. alloc.rs implements that flag as a process-local OnceLock read from the running process environment; it is not dumped state. The shared performance runner strips all EMAXX_ variables from both editor environments. Both editors execute exactly32 explicit collections in every observed GC body.',
    qualification='A separately recorded one-file prototype, not the main runtime. Three alternating diagnostic full16 pilots on macOS; actual compiler/image/source/native/workload identities and process reports are retained. No full platform certification, resolved calibration, real public allocation counters or nine-round/every-workload3% acceptance. The initial missing-fixture failure and rejected audit-count metadata remain separate and unchanged.')
(p / 'gc-cons-trace-draft1-performance-audit.json').open('x').write(json.dumps(audit, indent=2) + '\n')
print(json.dumps({key: audit[key] for key in ['status','cases','processes','raw_body_geometric_ratio','explicit_gc_candidate_over_baseline','paired_gnu_geometric_ratios']}))
