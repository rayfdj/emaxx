from pathlib import Path
import hashlib
import io
import json
import re
import subprocess
import sys
import tarfile

evidence = Path(__file__).resolve().parent
repository = evidence.parents[2]
checkout = evidence.parent / 'recovered-2026-10-08/symbol-plists/emaxx'
root = evidence / 'symbol-draft4/full'
head = '2712c05779e47ec9b8a7c89121d1a79fdcc42596'
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
summary = read(root / 'summary.json')
assert summary['status'] == 'passed' and summary['scope'] == 'full'
assert summary['git'] == {'dirty': True, 'head': 'b724bab0d945a68f1049233b6212930525a25ded'}
source = read(evidence / 'symbol-draft4/source.json')
assert len(source) == 560
post_run_source = {name: dict(sha256=sha(checkout / name), mode=oct((checkout / name).stat().st_mode & 0o777)) for name in source}
assert source == post_run_source
with (evidence / 'source314-macos-rust-post-run-source.json').open('x') as stream:
    json.dump(post_run_source, stream, indent=2)
    stream.write('\n')
for name, entry in source.items():
    assert sha(checkout / name) == entry['sha256'], name
    assert oct((checkout / name).stat().st_mode & 0o777) == entry['mode'], name
published = subprocess.check_output(['git', 'archive', head, '--', *source], cwd=repository)
with tarfile.open(fileobj=io.BytesIO(published)) as archive:
    for name, entry in source.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == entry['sha256']
        mode = '0o755' if archive.getmember(name).mode & 0o111 else '0o644'
        assert mode == entry['mode']
receipt = read(evidence / 'symbol-draft4/full.json')
assert receipt['exit_code'] == 0
for stream in ['stdout', 'stderr']:
    assert sha(evidence / ('symbol-draft4/full.' + stream)) == receipt[stream + '_sha256']

inventory = [line[:-6] for line in (root / 'inventory.txt').read_text().splitlines() if line.endswith(': test')]
assert len(inventory) == len(set(inventory)) == 3064
assert summary['inventory']['ignored_tests'] == ['tty::tty_differential_end_to_end', 'tty::tty_smoke_end_to_end']
assert summary['repetitions'] == 1 and len(summary['runs']) == 1
run = summary['runs'][0]
assert run['expected_tests'] == run['observed_outcomes'] == summary['inventory']['scheduled_tests'] == 3064
assert {group['group'] for group in run['groups']} == set(summary['inventory']['groups'])
assert len(run['groups']) == len(summary['inventory']['groups'])
pattern = r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;'
seen = []
passed = ignored = 0
for group in run['groups']:
    assert group['exit_code'] == 0 and not group['timed_out']
    result = group['result']
    assert result['status'] == 'ok' and result['failed'] == result['measured'] == 0
    assert result['passed'] + result['ignored'] == group['expected_tests'] == summary['inventory']['groups'][group['group']]
    assert result['ignored'] == group['expected_ignored']
    log = (root / Path(group['log']).name).read_text()
    assert re.findall(pattern, log) == [('ok', str(result['passed']), '0', str(result['ignored']), '0', str(result['filtered_out']))]
    starts = list(re.finditer(r'^test (\S+) \.\.\. ', log, re.M))
    assert len(starts) == group['expected_tests']
    for index, match in enumerate(starts):
        end = starts[index + 1].start() if index + 1 < len(starts) else log.rindex('test result:')
        verdict = log[match.end():end].strip()
        if match[1] in summary['inventory']['ignored_tests']:
            assert verdict.startswith('ignored')
        else:
            assert re.search(r'(?:^|\s)ok$', verdict), (match[1], verdict)
        seen.append(match[1])
    passed += result['passed']
    ignored += result['ignored']
assert sorted(seen) == sorted(inventory) and len(seen) == len(set(seen))
assert ignored == 2
assert [stage['stage'] for stage in summary['cargo_stages']] == ['bins', 'integration']
cargo = {}
for stage in summary['cargo_stages']:
    assert stage['exit_code'] == 0
    log = (root / Path(stage['log']).name).read_text()
    assert not re.search(r'^warning(?:\[.*?\])?:', log, re.M)
    rows = re.findall(pattern, log)
    assert len(rows) == len(stage['results']) > 0
    for row, result in zip(rows, stage['results']):
        assert result['status'] == 'ok'
        assert result['failed'] == result['ignored'] == result['measured'] == result['filtered_out'] == 0
        assert row == ('ok', str(result['passed']), '0', '0', '0', '0')
    cargo[stage['stage']] = sum(result['passed'] for result in stage['results'])
identity = [line for line in (root / 'integration.log').read_text().splitlines() if line.startswith('test unchanged_gnu_sources_produce_identical_native_artifacts ')]
assert len(identity) == 1 and identity[0].endswith(' ... ok')

sys.path.insert(0, str(repository / 'tools'))
import retain_rust_gate_artifacts
retained = root / 'retained-inputs'
if not retained.exists():
    retain_rust_gate_artifacts.retain(root / 'summary.json', checkout / 'target/grouped-gate/fixture-images')
record = read(retained / 'manifest.json')
assert record['status'] == 'retained' and record['gate_status'] == 'passed'
assert record['gate_summary_sha256'] == sha(root / 'summary.json')
for entry in record['files']:
    path = retained / entry['artifact']
    assert sha(path) == entry['sha256'] and path.stat().st_size == entry['bytes']
assert next(entry for entry in record['files'] if entry['artifact'] == 'libtest')['sha256'] == summary['test_binary']['sha256']
result = dict(status='passed', source_commit=head, validation_checkout=summary['git'],
              unchanged_source_inputs=len(source), raw_library_names_verified=len(seen), library_passed=passed,
              library_ignored=ignored, cargo_passed=cargo, total_passed=passed + sum(cargo.values()),
              native_artifact_identity='passed', retained_files_verified=len(record['files']),
              test_binary_sha256=summary['test_binary']['sha256'], summary_sha256=sha(root / 'summary.json'),
              wrapper_limit='The detached wrapper saved the full command exit-zero receipt but did not save its final source-after.json; its observation handle had already disappeared. No wrapper success is inferred. This independent post-run source capture matches the original frozen source and published commit.',
              qualification='Full gate started as a dirty b724bab0 checkout; all 560 pre-run and independently captured post-run bytes/modes match published source314. Each raw library name/verdict and Cargo summary checked. Post-run retained fixture images do not identify per-test use. Frozen comparisons, selected release and performance are separate.',
              goal_complete=False)
with (evidence / 'source314-macos-rust-audit.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(result, indent=2))
