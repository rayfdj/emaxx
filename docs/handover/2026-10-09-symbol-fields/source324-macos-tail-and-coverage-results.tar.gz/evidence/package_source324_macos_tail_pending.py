from pathlib import Path
import json

p = Path(__file__).resolve().parent
read = lambda path: json.loads(path.read_text())
audit = read(p / 'source324-macos-tail-audit.json')
coverage = read(p / 'source324-macos-coverage-audit.json')
assert coverage['files'] == 519 and not coverage['single_passing_frozen_run']
ns = {'__file__': str(p / 'package_source323_base.py')}
exec((p / 'package_source323_base.py').read_text(), ns)
ns['destination'] = p / 'pending-publication-source324'
ns['package']('source324-macos-tail-and-coverage-results',
    [('raw/unstarted-tail', Path(audit['raw_root'])),
     ('evidence/observations', p / 'source324-macos-observations')],
    [('evidence/' + name, p / name) for name in [
        'source324-macos-tail-audit.json', 'source324-macos-coverage-audit.json',
        'source324-macos-frozen-incomplete-audit.json', 'source324-macos-tramp-observation-audit.json',
        'audit_source324_macos_tail.py', 'audit_source324_macos_coverage.py',
        'source324_macos_observations.py', 'package_source323_base.py', Path(__file__).name]],
    dict(checkpoint='source324 completed macOS tail and explicit all-file coverage',
         coverage=coverage, tail=audit,
         qualification='Exactly200 previously unstarted files at their original180-second deadline:3377matches/six existing diagnostic differences/400successful processes. All177native tests pass in both editors. With the separately archived original318completed files and59actualTramp answers, all519files/7921outcomes are covered across distinct attempts. The original frozen run remains failed; there is no single passing macOS frozen run. Original/observation binary and image exclusions remain explicit. Terminal results and full performance acceptance are separate.'))
