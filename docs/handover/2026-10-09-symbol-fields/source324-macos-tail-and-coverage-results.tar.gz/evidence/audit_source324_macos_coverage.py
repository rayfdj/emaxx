from pathlib import Path
import hashlib
import json

p = Path(__file__).resolve().parent
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
names = ['source324-macos-frozen-incomplete-audit.json',
         'source324-macos-tramp-observation-audit.json', 'source324-macos-tail-audit.json']
original_audit, tramp, tail = [read(p / name) for name in names]
state = read(p / 'source324-macos-observations/state.json')
assert state['status'] == 'terminal; inspect every raw verdict' and state['source_unchanged']
original = Path(state['original_raw_root'])
contract = read(original / 'contract.json')
stages = {row['stage']: Path(row['raw_directories'][0]) for row in state['results']}
assert set(stages) == {'tramp-longer', 'unstarted-tail'}
assert original_audit['matching_outcomes'] == 4479 and original_audit['mismatching_outcomes'] == 0
assert tramp['observations'][0]['matching_outcomes'] == 59
assert tail['matching_outcomes'] == 3377 and tail['mismatching_outcomes'] == 6
assert tail['previous_six_issue_entries_identical']
files = contract['files']
selected = {name: original for name in files[:318]}
assert files[318] == 'test/lisp/net/tramp-tests.el'
selected[files[318]] = stages['tramp-longer']
selected.update({name: stages['unstarted-tail'] for name in files[319:]})
assert len(selected) == 519 and set(selected) == set(files)
matched = different = processes = 0
counts = {editor: dict(total=0, passed=0, failed=0, skipped=0, unexpected=0)
          for editor in ['oracle', 'emaxx']}
for name, root in selected.items():
    folder = (root / name).with_suffix('.compat')
    comparison = read(folder / 'comparison.json')
    execution = read(folder / 'execution.json')
    assert execution['contract_sha256'] == sha(root / 'contract.json')
    assert all(sha(folder / name) == digest for name, digest in execution['sha256'].items())
    matched += comparison['matching_outcomes']
    different += comparison['mismatching_outcomes']
    assert not comparison['execution_issues']
    for editor in counts:
        report = read(folder / (editor + '.json'))
        process = read(folder / (editor + '.execution.json'))['process']
        assert process['exit_code'] == 0 and not process['timed_out'] and process['test_started']
        actual = {status: sum(row['status'] == status for row in report['results'])
                  for status in ['passed', 'failed', 'skipped']}
        actual.update(total=len(report['results']), unexpected=sum(not row['expected'] for row in report['results']))
        assert actual == report['summary']
        for key, value in actual.items():
            counts[editor][key] += value
        processes += 1
assert (matched, different, processes) == (7915, 6, 1038)
assert counts['oracle'] == counts['emaxx'] and counts['oracle']['unexpected'] == 0
assert counts['oracle']['total'] == 7921
record = dict(status='complete file coverage across three separately identified attempts; six strict existing differences',
    runtime_commit='999362622a68d6508c356541422f7a48ae6e2175', source_inputs=572,
    files=519, matching_outcomes=matched, mismatching_outcomes=different, total_outcomes=matched+different,
    successful_processes=processes, runner_summaries=counts,
    file_sources={name: str(root) for name, root in selected.items()},
    audits={name: sha(p / name) for name in names},
    original_frozen_verdict='failed; unchanged', single_passing_frozen_run=False,
    qualification='The 318 completed original files, separate unchanged Tramp file with a 600-second deadline, and exact 200-file tail at original 180-second deadlines cover all frozen file inventories. No completed original file is substituted. Original Tramp timeouts remain failed. Six feature-message differences remain strict mismatches and are identical to source318. All native outcomes match. This mapping is not one passing frozen run or a performance measurement.',
    goal_complete=False)
destination = p / 'source324-macos-coverage-audit.json'
destination.open('x').write(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: record[key] for key in ['status','files','matching_outcomes','mismatching_outcomes','successful_processes']}))
