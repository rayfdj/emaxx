from pathlib import Path
import datetime
import hashlib
import json
import math
import os
import re
import subprocess
import time

p = Path(__file__).resolve().parent
out = p / 'symbol-membership-draft5-image-order'
out.mkdir(exist_ok=False)
original = p / 'symbol-membership-draft5-selected-gate'
w = p.parent / 'recovered-2026-10-13/symbol-membership/emaxx'
source = json.loads((original / 'source.json').read_text())
binary_record = json.loads((original / 'binary.json').read_text())
binary = Path(binary_record['original'])
selection = json.loads((original / 'selection.json').read_text())
target = json.loads((p / 'symbol-membership-draft5-selected-failed-audit.json').read_text())['failed'][0]
prefix = selection[:selection.index(target)]
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(binary) == binary_record['sha256']
state = dict(pid=os.getpid(), started=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    target=target, binary=binary_record, results=[], status='diagnosing ordering', goal_complete=False,
    qualification='Diagnostic subsets of the exact failed selected run, preserving original assertions. Passing subsets do not replace the failed402-control result. No source or binary changes.')
(out / 'source.json').write_text(json.dumps(source, indent=2) + '\n')


def save():
    (out / 'state.json').write_text(json.dumps(state, indent=2) + '\n')


def attempt(label, predecessors):
    assert len(state['results']) < 32, 'bounded diagnostic attempt budget'
    assert sha(binary) == binary_record['sha256']
    directory = out / ('%02d-' % len(state['results']) + label)
    directory.mkdir()
    env = json.loads((original / 'environment.json').read_text())
    env['EMAXX_FIXTURE_IMAGE_DIR'] = str(directory / 'fixture-images')
    command = [str(binary), '--exact', '--test-threads=1', *sorted(set(predecessors + [target]))]
    (directory / 'environment.json').write_text(json.dumps(env, indent=2) + '\n')
    row = dict(label=label, command=command, cwd=str(w), predecessor_count=len(predecessors))
    (directory / 'command.json').write_text(json.dumps(row, indent=2) + '\n')
    print('START', label, len(predecessors), flush=True)
    start = time.monotonic()
    with (directory / 'stdout').open('xb') as stdout, (directory / 'stderr').open('xb') as stderr:
        result = subprocess.run(command, cwd=w, env={**os.environ, **env}, stdout=stdout, stderr=stderr, timeout=900)
    log = (directory / 'stdout').read_text()
    verdict = re.search(r'^test ' + re.escape(target) + r' \.\.\. (ok|FAILED)$', log, re.M)
    assert verdict, 'target did not finish; inspect raw results'
    failed = verdict[1] == 'FAILED'
    if failed:
        assert 'trying to dump non fixed-up eln file' in log
    row.update(exit_code=result.returncode, target_failed=failed, elapsed_seconds=time.monotonic()-start,
        stdout_sha256=sha(directory / 'stdout'), stderr_sha256=sha(directory / 'stderr'))
    (directory / 'result.json').write_text(json.dumps(row, indent=2) + '\n')
    state['results'].append(row)
    save()
    print('END', label, 'target_failed', failed, round(row['elapsed_seconds'], 2), flush=True)
    assert all(sha(w / name) == entry['sha256'] for name, entry in source.items())
    return failed


save()
try:
    if attempt('last-two-predecessors', prefix[-2:]):
        current = prefix[-2:]
    elif attempt('original-prefix', prefix):
        current = prefix
    else:
        state['status'] = 'original prefix did not reproduce; preserve changed fixture-directory limit'
        save()
        raise SystemExit(0)
    granularity = 2
    while len(current) >= 2:
        size = math.ceil(len(current) / granularity)
        chunks = [current[index:index+size] for index in range(0, len(current), size)]
        reduced = False
        for index, chunk in enumerate(chunks):
            if attempt('subset-' + str(index), chunk):
                current, granularity, reduced = chunk, 2, True
                break
        if reduced:
            continue
        for index, chunk in enumerate(chunks):
            complement = [name for name in current if name not in chunk]
            if complement and attempt('complement-' + str(index), complement):
                current, granularity, reduced = complement, max(2, granularity-1), True
                break
        if reduced:
            continue
        if granularity >= len(current):
            break
        granularity = min(len(current), granularity*2)
    state.update(status='minimal diagnostic predecessor set found', predecessors=current)
    save()
    print(json.dumps(dict(status=state['status'], predecessors=current)), flush=True)
except BaseException as error:
    if not isinstance(error, SystemExit):
        state.update(status='diagnostic stopped; inspect preserved attempts', error=str(error))
        save()
    raise
