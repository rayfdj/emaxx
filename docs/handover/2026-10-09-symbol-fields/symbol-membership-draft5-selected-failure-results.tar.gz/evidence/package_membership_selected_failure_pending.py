from pathlib import Path
import json

p = Path(__file__).resolve().parent
ns = {'__file__': str(p / 'package_source323_base.py')}
exec((p / 'package_source323_base.py').read_text(), ns)
ns['destination'] = p / 'pending-publication-source324'
audit = json.loads((p / 'symbol-membership-draft5-selected-failed-audit.json').read_text())
assert audit['passed'] == 399 and len(audit['failed']) == 3 and audit['inventory_verified'] == 402
ns['package']('symbol-membership-draft5-selected-failure-results',
    [('evidence/' + name, p / name) for name in [
        'symbol-membership-draft5-selected-gate', 'symbol-membership-draft5-three-image-replay']],
    [('evidence/' + name, p / name) for name in [
        'symbol-membership-draft5-selected-failed-audit.json', 'symbol-membership-draft5-selected-queue.json',
        'validate_membership_selected.py', 'validate_symbol_membership.py', 'membership_selected_queue.py',
        'isolate_membership_image_order.py', 'package_source323_base.py', Path(__file__).name]],
    dict(checkpoint='isolated membership draft5 broader gate failure; release not started',
        failed_selected=audit,
        qualification='All402 raw names/verdicts are checked:399pass/three failures/no ignores. The failures are native-image dumping checks rejecting a non-fixed-up native unit. Release was not started. A separate fresh process using retained identical executable bytes passes those three unchanged tests; its executable path and fixture-image directory differ, so that replay does not establish the exact cause or repair and does not replace the original failures. A separate bounded predecessor-sequence diagnostic is running, with no result certified by this package. Current source remains580inputs; the five focused passes in the earlier unfinished package do not imply broader success.'))
