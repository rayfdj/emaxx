from pathlib import Path
import hashlib, json, subprocess, sys

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/retention/emaxx'
artifacts = json.loads((p / 'source173-ordinary-artifacts.json').read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
assert all(sha(Path(name)) == item['sha256'] == sha(Path(item['immutable_copy']))
           for name, item in artifacts.items())
names = ['builtin-function-cell-authority', 'builtin-nil-function-cell',
         'builtin-special-form-funcall', 'unwind-protected-payloads',
         'unwind-native-payloads', 'unwind-payload-reclamation',
         'reader-callable-execution-modes', 'reader-callable-redefinition',
         'reader-callable-errors', 'reader-callable-gc']
command = [sys.executable, str(p / 'compare-recovered-continuation-fixtures.py'),
           'source173', str(root), *names]
with (p / 'source173-ordinary-suite-command.json').open('x') as f:
    json.dump({'command': command, 'fixtures': names}, f, indent=2)
run = subprocess.run(command, check=False)
results = {name: json.loads((p / ('source173-ordinary-' + name + '-comparison.json')).read_text())
           for name in names if (p / ('source173-ordinary-' + name + '-comparison.json')).exists()}
valid = (run.returncode == 0 and len(results) == len(names)
         and all(item['passed'] for item in results.values())
         and all(sha(Path(name)) == item['sha256'] for name, item in artifacts.items()))
with (p / 'source173-ordinary-suite-result.json').open('x') as f:
    json.dump({'exit_code': run.returncode, 'expected_inventory': names,
               'results': results, 'all_match': valid}, f, indent=2)
raise SystemExit(0 if valid else 1)
