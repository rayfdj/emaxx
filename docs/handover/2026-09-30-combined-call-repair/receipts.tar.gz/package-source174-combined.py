from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
checkout = p.parent / 'recovered-2026-09-30/combined/emaxx'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read('source174-manifest.json')
assert len(manifest) == 345
assert all(sha((checkout / name).read_bytes()) == digest for name, digest in manifest.items())
for stage in ['check', 'fmt', 'clippy', 'diff', 'gate-build', 'release-build', 'ordinary-build', 'ordinary-image']:
    result = read(f'source174-{stage}-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
for profile in ['gate', 'release']:
    stem = f'source174-{profile}-selected'
    result = read(stem + '-result.json')
    command = read(stem + '-command.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
    inventory = command['selected_inventory']
    assert len(inventory) == len(set(inventory)) == 395
    log = (p / (stem + '.log')).read_text()
    summaries = re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', log, re.M)
    assert summaries == [('ok', '395', '0', '0')]
    starts = list(re.finditer(r'^test (\S+) \.\.\. ', log, re.M))
    assert sorted(item[1] for item in starts) == sorted(inventory)
    for index, item in enumerate(starts):
        end = starts[index + 1].start() if index + 1 < len(starts) else log.rindex('test result:')
        assert log[item.end():end].strip().endswith('ok'), item[1]
    assert sha((p / f'source174-{profile}-libtest').read_bytes()) == command['binary_sha256']
for tag, expected in [('peer-report', '((nil nil t t t t nil t) (nil nil t t t t nil t))'),
                      ('tls-gc-replay', '((open 9 (t t t t)) (open 9 (t t t t)))')]:
    result = read(f'source174-{tag}-comparison.json')
    for runner in ['gnu', 'emaxx']:
        item = result[runner]
        assert item['exit_code'] == 0 and not item['timed_out'] and item['inputs_unchanged']
        assert item['stdout'] == expected and item['stderr'] == ''
        assert (p / f'source174-{tag}-{runner}.stdout').read_text() == expected
        assert not (p / f'source174-{tag}-{runner}.stderr').read_bytes()
for name, item in read('source174-ordinary-artifacts.json').items():
    assert sha(Path(name).read_bytes()) == item['sha256']
    assert sha(Path(item['immutable_copy']).read_bytes()) == item['sha256']
suite = read('source174-ordinary-suite-result.json')
assert suite['exit_code'] == 0 and suite['all_match']
assert len(suite['expected_inventory']) == len(suite['results']) == 10
for fixture, comparison in suite['results'].items():
    assert comparison['passed'] and comparison['exact_match']
    for editor in ['gnu', 'emaxx']:
        prefix = 'source174-ordinary-' + fixture + '-' + editor
        result = read(prefix + '.result.json')
        assert result['exit_code'] == 0 and not result['timed_out']
        assert result['inputs_unchanged'] and result['source_unchanged']
        assert sha((p / (prefix + '.stdout')).read_bytes()) == result['stdout_sha256']
        assert (p / (prefix + '.stderr')).read_bytes().hex() == result['stderr_hex'] == ''
assert read('source174-selected-validation-result.json')['status'] == 'passed'
replays = read('pending-linux-replays-audit.json')
assert [item['outcomes'] for item in replays['results']] == [52, 27]

out = root / 'docs/handover/2026-09-30-combined-call-repair'
out.mkdir(exist_ok=False)
suffixes = {'.json', '.log', '.txt', '.stdout', '.stderr', '.py', '.patch', '.el', '.expected'}
files = {}
for f in p.iterdir():
    if not f.is_file() or f.suffix not in suffixes:
        continue
    if f.name.startswith('source174-full-') or f.name == 'source174-validation-driver.log':
        continue
    if (f.name.startswith('source174-')
        or f.name.startswith('source173-ordinary-')
        or f.name in ['audit-pending-linux-replays.py', 'pending-linux-replays-audit.json',
                      'package-source174-combined.py', 'check-combined174.py', 'static-combined174.py',
                      'test-combined174.py', 'build-combined174.py', 'queue-source174-validation.py',
                      'compare-recovered-continuation-fixtures.py', 'validate-source173-ordinary.py',
                      'validate-source174-ordinary.py', 'run-source174-peer-report.py',
                      'run-source174-tls-gc-replay.py', 'run-source174-full-gate.py', 'run-source174-full-tty.py']):
        files[f.name] = f
for directory in ['linux-source170-eglot-replay-artifacts', 'linux-source172-tls-artifacts']:
    for f in (p / directory).rglob('*'):
        if f.is_file():
            files[str(f.relative_to(p))] = f
inventory = []
with (out / 'receipts.tar.gz').open('xb') as stream:
    with gzip.GzipFile(fileobj=stream, mode='wb', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w') as archive:
            for name, f in sorted(files.items()):
                data = f.read_bytes()
                info = tarfile.TarInfo(name)
                info.mode = 0o644
                info.size = len(data)
                archive.addfile(info, io.BytesIO(data))
                inventory.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
with tarfile.open(out / 'receipts.tar.gz', 'r:gz') as archive:
    assert archive.getnames() == [item['path'] for item in inventory]
    for item in inventory:
        data = archive.extractfile(item['path']).read()
        assert sha(data) == item['sha256'] and len(data) == item['bytes']
data = (out / 'receipts.tar.gz').read_bytes()
record = {
    'status': 'source174 combined candidate passes selected validation; complete validation pending',
    'base_commit': read('source174-base.json')['commit'],
    'compiled_inputs': 345, 'gate_passed': 395, 'release_passed': 395,
    'ordinary_gnu_comparisons': 12,
    'completed_predecessor_evidence': {
        'source173_ordinary_exact_comparisons': 10,
        'source170_eglot_replay': '52 outcomes match, 45 passes and 7 existing skips per editor',
        'source172_network_stream': '27 outcomes match, 26 passes and 1 existing skip per editor; both TLS Rust controls pass',
    },
    'qualification': 'No original assertion, selector, expected outcome or timeout changed. Complete combined-source Rust, frozen and terminal validation remain pending. Source166/source170 reclamation failures and the source170 full frozen GNU Eglot timeout remain preserved. The affected Eglot replay does not turn the earlier full comparison into a pass. GNU matches source and native ABI but is not the Darwin frozen executable. The isolated input decoder, post-deinit TLS behavior, representation completion, physical accounting, final audit and locked performance remain unfinished.',
    'archive': {'path': 'receipts.tar.gz', 'bytes': len(data), 'sha256': sha(data)},
    'files': inventory,
}
(out / 'manifest.json').write_text(json.dumps(record, indent=2) + '\n')
print(f'Audited {len(inventory)} receipts; {len(data)} archived bytes; 395 gate + 395 release + 12 ordinary comparisons.')
