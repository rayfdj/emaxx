from pathlib import Path
from collections import Counter
import hashlib, json, re

p = Path(__file__).parent.resolve()
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
cases = [
    ('source170-eglot-replay', 36669998865, '24b85d726d34976a1a5ceb7a61444bb912e8edd1',
     'test/lisp/progmodes/eglot-tests.el', 52, 7),
    ('source172-tls', 36670346867, 'a46b71cdb61b00813ca2ead6c47eb30fb8921992',
     'test/lisp/net/network-stream-tests.el', 27, 1),
]
records = []
for tag, run, head, file, count, skipped in cases:
    root = next((p / ('linux-' + tag + '-artifacts')).glob('ordinary-*'))
    summary_path = next(root.rglob('summary.json'))
    summary = json.loads(summary_path.read_text())
    contract_path = summary_path.with_name('contract.json')
    contract = json.loads(contract_path.read_text())
    assert summary['files'] == contract['files'] == [file]
    assert summary['selector'] == contract['selector'] == '(not (or (tag :expensive-test) (tag :unstable)))'
    assert summary['name_filter'] is None and contract['name_filter'] is None
    assert summary['matching_files'] == summary['total_files'] == 1
    assert summary['matching_outcomes'] == summary['total_outcomes'] == count
    assert summary['mismatching_files'] == summary['mismatching_outcomes'] == 0
    assert not summary['mismatches'] and not summary['unsuccessful_files']
    assert summary['provenance'] == contract['provenance']
    provenance = summary['provenance']
    assert provenance['subject_git_head'] == head and not provenance['subject_git_dirty']
    assert provenance['oracle_repo_commit'] == '636f166cfc86aa90d63f592fd99f3fdd9ef95ebd'
    assert provenance['oracle_native_compilation'] and provenance['timeout_seconds'] == 180
    reports = {}
    comparison_path = next(root.rglob('comparison.json'))
    directory = comparison_path.parent
    comparison = json.loads(comparison_path.read_text())
    assert comparison['matches'] and not comparison['issues'] and not comparison['execution_issues']
    execution = json.loads((directory / 'execution.json').read_text())
    assert execution['contract_sha256'] == sha(contract_path)
    for name, digest in execution['sha256'].items():
        assert sha(directory / name) == digest, name
    for runner in ['emaxx', 'oracle']:
        report = json.loads((directory / (runner + '.json')).read_text())
        process = json.loads((directory / (runner + '.execution.json')).read_text())['process']
        assert process['exit_code'] == 0 and not process['timed_out'] and process['test_started']
        assert report['file_status'] == 'loaded' and report['file_error'] is None
        selected = report['selected_tests']
        assert len(selected) == len(set(selected)) == count
        assert [r['name'] for r in report['results']] == selected
        assert all(r['expected'] for r in report['results'])
        totals = Counter(r['status'] for r in report['results'])
        assert totals == {'passed': count - skipped, 'skipped': skipped}
        assert report['summary'] == summary['runner_summaries'][runner]
        reports[runner] = report
    assert reports['emaxx']['discovered_tests'] == reports['oracle']['discovered_tests']
    assert reports['emaxx']['selected_tests'] == reports['oracle']['selected_tests']
    assert [(r['name'], r['status'], r['expected']) for r in reports['emaxx']['results']] == [
        (r['name'], r['status'], r['expected']) for r in reports['oracle']['results']]
    record = {'tag': tag, 'run': run, 'head': head, 'file': file, 'outcomes': count,
              'passed_per_editor': count - skipped, 'existing_skips_per_editor': skipped,
              'successful_processes': 2, 'inventories_and_raw_hashes_verified': True,
              'provenance': provenance}
    if tag == 'source172-tls':
        log = (root / 'runtime-control.log').read_text()
        expected = {'lisp::primitives::tests::process_tls_peer_reports_are_independent_values_from_the_live_session',
                    'lisp::primitives::tests::process_tls_state_survives_collection_before_and_after_async_handshake'}
        assert set(re.findall(r'^test (\S+) \.\.\. ok$', log, re.M)) == expected
        assert 'test result: ok. 2 passed; 0 failed; 0 ignored;' in log
        record['rust_controls'] = sorted(expected)
        record['rust_binary_hash_limitation'] = 'Existing affected workflow does not archive its Rust libtest executable SHA.'
    records.append(record)
with (p / 'pending-linux-replays-audit.json').open('x') as f:
    json.dump({'results': records,
               'qualification': 'Affected-file replays only. The original source170 full frozen GNU Eglot timeout remains preserved; the replay does not turn that full run into a pass. No performance or final-source certification.'}, f, indent=2)
print([(r['tag'], r['outcomes']) for r in records])
