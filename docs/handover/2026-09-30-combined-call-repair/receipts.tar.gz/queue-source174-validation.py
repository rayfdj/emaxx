from pathlib import Path
import hashlib, json, subprocess, sys, time

p = Path(__file__).parent.resolve()
root = p.parent / 'recovered-2026-09-30/combined/emaxx'
manifest = json.loads((p / 'source174-manifest.json').read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
unchanged = lambda: all(sha(root / name) == digest for name, digest in manifest.items())

def run(script, *args):
    assert unchanged()
    result = subprocess.run([sys.executable, str(p / script), *args], check=False)
    assert unchanged()
    if result.returncode:
        raise SystemExit(result.returncode)

run('check-combined174.py', '174')
run('static-combined174.py', '174')
run('test-combined174.py', '174', 'gate')
run('test-combined174.py', '174', 'release')
run('build-combined174.py', '174')
run('validate-source174-ordinary.py')
for script, stem, fixture in [
    ('run-source174-peer-report.py', 'peer-report', 'process-tls-report'),
    ('run-source174-tls-gc-replay.py', 'tls-gc-replay', 'process-tls-gc'),
]:
    run(script)
    outcomes = json.loads((p / ('source174-' + stem + '-comparison.json')).read_text())
    expected = (root / ('tests/fixtures/' + fixture + '.expected')).read_text().rstrip('\n')
    assert set(outcomes) == {'gnu', 'emaxx'}
    assert all(r['exit_code'] == 0 and not r['timed_out'] and r['inputs_unchanged']
               and r['stdout'] == expected and r['stderr'] == '' for r in outcomes.values())
with (p / 'source174-selected-validation-result.json').open('x') as f:
    json.dump({'status': 'passed', 'ordinary_exact_comparisons': 12,
               'source_unchanged': unchanged(), 'completed_unix': time.time(),
               'qualification': 'Combined selected validation only. Full Rust, frozen compatibility, terminal validation and the full runtime goal remain open.'}, f, indent=2)
children = []
for kind in ['gate', 'tty']:
    script = p / ('run-source174-full-' + kind + '.py')
    with (p / ('source174-full-' + kind + '-driver.log')).open('x') as log:
        process = subprocess.Popen([sys.executable, str(script)], stdin=subprocess.DEVNULL,
                                   stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    with (p / ('source174-full-' + kind + '-launch.json')).open('x') as f:
        json.dump({'pid': process.pid, 'script': str(script), 'started_unix': time.time()}, f, indent=2)
    children.append((kind, process))
    print('started', kind, process.pid, flush=True)
results = {kind: process.wait() for kind, process in children}
with (p / 'source174-full-local-supervisor-result.json').open('x') as f:
    json.dump({'exit_codes': results, 'source_unchanged': unchanged()}, f, indent=2)
raise SystemExit(0 if unchanged() and all(code == 0 for code in results.values()) else 1)
