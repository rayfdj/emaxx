from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).parent
root = p.parents[2]
sha = lambda data: hashlib.sha256(data).hexdigest()
rust = json.loads((p / 'source155-complete-rust-audit.json').read_text())
frozen = json.loads((p / 'source155-complete-frozen-audit.json').read_text())
assert rust['macos']['total_passed'] == 3012
assert rust['linux']['total_passed'] == 3024
assert all(result['status'] == 'passed' for result in rust.values())
assert frozen['verified_files'] == 519 and frozen['verified_outcomes'] == 7928
assert frozen['successful_processes'] == 1038
assert json.loads((p / 'source139-terminal-org-terminal-result.json').read_text())['passed']
assert not json.loads((p / 'source155-terminal-org-terminal-result.json').read_text())['passed']
selected = {}
suffixes = {'.json', '.log', '.txt', '.stdout', '.stderr', '.loaded', '.el', '.py'}
for directory in ['full-gate-source155', 'linux-source155-full-artifacts',
                  'linux-source155-frozen-artifacts']:
    for f in (p / directory).rglob('*'):
        if f.is_file() and f.suffix in suffixes:
            selected[str(f.relative_to(p))] = f
prefixes = ('source155-full-gate', 'source155-complete-',
            'source139-org-terminal-', 'source139-pty-org-terminal',
            'source139-terminal-org-terminal', 'source155-terminal-org-terminal',
            'source155-ordinary-keymap-org-menu',
            'source155-ordinary-keymap-sequence-types',
            'source139-ordinary-keymap-sequence-types')
names = {'source155-manifest.json', 'source139-ordinary-artifacts.json',
         'run-source155-full-gate.py', 'package-source155-rust-frozen.py',
         'replay-org-terminal.py', 'compare-continuation-fixtures.py',
         'keymap-org-menu.el', 'keymap-sequence-types.el'}
for f in p.iterdir():
    if f.is_file() and f.suffix in suffixes and (f.name.startswith(prefixes) or f.name in names):
        selected[f.name] = f
out = root / 'docs/handover/2026-09-30-compatibility-rust-frozen'
out.mkdir(exist_ok=False)
files = []
with (out / 'receipts.tar.gz').open('xb') as stream:
    with gzip.GzipFile(fileobj=stream, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, f in sorted(selected.items()):
                data = f.read_bytes()
                info = tarfile.TarInfo(name)
                info.mode = 0o644
                info.size = len(data)
                archive.addfile(info, io.BytesIO(data))
                files.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
with tarfile.open(out / 'receipts.tar.gz', 'r:gz') as archive:
    assert archive.getnames() == [f['path'] for f in files]
    for f in files:
        data = archive.extractfile(f['path']).read()
        assert len(data) == f['bytes'] and sha(data) == f['sha256']
data = (out / 'receipts.tar.gz').read_bytes()
record = {
    'source_manifest': 'source155-manifest.json',
    'macos_commit': '72d985987ce642705d642c86316302f7a0d0a798',
    'linux_commit': 'f237bfcf46f07d86c9006bbff445b5c5645dbdaf',
    'rust': rust,
    'linux_frozen': frozen,
    'terminal_regression': 'Unchanged org-open passes on retained main source139 and fails on source155: Table and Org menu captions are absent. Ordinary lookup itself matches GNU composed maps. The complete source155 terminal run is still active and is not packaged here. Source161 repairs rendering; its final validation is separate.',
    'existing_negative_control': 'lookup-key initial nil/integer/symbol sequence types disagree with GNU on both retained main source139 and source155. Both complete original outputs are included. A separate keymap architecture draft repairs this; no such repair is claimed for source155/161.',
    'setup_limits': 'The first two Org replay attempts could not access /dev/tty under the sandbox and establish no parity result. The subsequent permitted terminal replays completed. One old-main batch invocation from a copied executable directory could not locate its relative native libraries; the original-directory alias then completed with verified executable/image identities.',
    'qualification': 'All complete Rust and frozen reports were checked against raw counts and process status. Expected failed and skipped frozen outcomes remain distinct from passes. Retained Rust artifact hashes were verified locally; binary bytes are not in this portable archive. Frozen identities come from runner provenance. Darwin GNU remains source/ABI matched, not the frozen executable. Newer menu repair validation, remaining architecture, final audit and performance parity remain open.',
    'archive': {'path': 'receipts.tar.gz', 'bytes': len(data), 'sha256': sha(data)},
    'files': files,
}
(out / 'manifest.json').write_text(json.dumps(record, indent=2) + '\n')
print('Verified', len(files), 'receipts;', len(data), 'archive bytes')
