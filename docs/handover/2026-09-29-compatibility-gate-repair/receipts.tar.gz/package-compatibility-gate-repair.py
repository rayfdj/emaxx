from pathlib import Path
import gzip,hashlib,io,json,tarfile
p=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28');root=p.parents[2]
sha=lambda data:hashlib.sha256(data).hexdigest()
manifest=json.loads((p/'source153-manifest.json').read_text());assert all(sha((root/f).read_bytes())==h for f,h in manifest.items())
for stage in ['check','fmt','clippy','diff','debug-build','debug-selected','release-build','release-selected','ordinary-build','ordinary-image']:
 d=json.loads((p/('source153-'+stage+'-result.json')).read_text());assert d['exit_code']==0 and d['source_unchanged']
for mode in ['debug','release']:
 d=json.loads((p/('source153-'+mode+'-selected-inventory-check.json')).read_text());c=json.loads((p/('source153-'+mode+'-selected-command.json')).read_text())
 assert d['expected']==len(c['selected_inventory'])==382 and d['process_exit_code']==0
 assert d['summary']=='test result: ok. 382 passed; 0 failed; 0 ignored;'
 assert sha((p/('source153-'+mode+'-libtest')).read_bytes())==d['binary_unchanged']==c['binary_sha256']
fixtures=['keymap-parameterized-char-table','keymap-prefix-filter-count','keymap-filter-effects','keymap-prefix-precedence','keymap-lookup-argument-order','keymap-filter-error-unbound','unwind-protected-payloads','unwind-native-payloads','unwind-payload-reclamation','keymap-description-context','keymap-menu-fallback','keymap-menu-case-table-order','string-make-multibyte-identity']
for name in fixtures:
 d=json.loads((p/('source153-ordinary-'+name+'-comparison.json')).read_text());assert d['exact_match'] and d['passed']
for name in ['repeat-tests','keymap-tests','casefiddle-tests','gv-tests']:
 reports=[]
 for side in ['gnu','emaxx']:
  stem=p/('source153-'+name+'-report-'+side);r=json.loads(stem.with_suffix('.result.json').read_text());assert r['exit_code']==0 and not r['timed_out'] and r['inputs_unchanged'] and r['source_unchanged']
  reports.append([{k:v for k,v in x.items() if k!='duration_ns'} for x in json.loads(stem.with_suffix('.json').read_text())['results']])
 assert reports[0]==reports[1]
selected={};suffixes={'.json','.log','.txt','.patch','.py','.md','.el','.expected','.stdout','.stderr','.loaded'}
for f in p.iterdir():
 if not f.is_file() or f.suffix not in suffixes:continue
 include=f.name.startswith(('source151','source152','source153')) and not f.name.startswith('source153-full-gate')
 include|=f.name.startswith(('source148-full-gate','source148-original-full-failures','source148-linux-frozen','linux-source148-failed','linux-source148-frozen-failed'))
 include|=f.name in ['repair-source148-full-gates.py','check-compatibility-gate-repair.py','static-compatibility-gate-repair.py','test-compatibility-gate-repair.py','release-compatibility-gate-repair.py','build-compatibility-gate-repair.py','compare-continuation-fixtures.py','diagnose-compatibility-gate-reports.py','package-compatibility-gate-repair.py','run-source148-full-gate.py','run-source152-full-gate.py','run-source153-full-gate.py']
 if include:selected[f.name]=f
for dirname in ['full-gate-source148','full-gate-source152','linux-source148-full-artifacts','linux-source148-frozen-artifacts']:
 for f in (p/dirname).rglob('*'):
  if f.is_file() and f.suffix in suffixes:selected[str(f.relative_to(p))]=f
out=root/'docs/handover/2026-09-29-compatibility-gate-repair';out.mkdir(exist_ok=False);files=[]
with (out/'receipts.tar.gz').open('xb') as stream:
 with gzip.GzipFile(fileobj=stream,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as archive:
   for name,f in sorted(selected.items()):
    data=f.read_bytes();info=tarfile.TarInfo(name);info.mode=0o644;info.size=len(data);archive.addfile(info,io.BytesIO(data));files.append({'path':name,'bytes':len(data),'sha256':sha(data)})
with tarfile.open(out/'receipts.tar.gz','r:gz') as archive:
 assert archive.getnames()==[f['path'] for f in files]
 for f in files:
  data=archive.extractfile(f['path']).read();assert len(data)==f['bytes'] and sha(data)==f['sha256']
data=(out/'receipts.tar.gz').read_bytes()
(out/'manifest.json').write_text(json.dumps({'scope':'Source153 strict checks,382debug+382release,13exactordinaryGNUfixtures,fourunchangedupstreamreports. Original148fullRustfailures, complete148Linuxfrozen519file7928outcomes/onefailure,151compilerfailure,152debugfailureandcancelledincompletegate retained.','source_manifest':'source153-manifest.json','candidate':'82fcb6c9','published':'900a6b7f','qualification':'Source153 complete macOS/Linux and Linux frozen runs remain pending. Report duration is the only excluded outcome field. Original failure summaries and fixtures remain raw. Darwin GNU is source/ABI matched but not the frozen executable. No architecture, final-audit or performance completion claim.','binary_policy':'Post-run Rust binaries/images verified against retained manifests locally; archive carries their identity receipts. Linux frozen binaries are identified by the original runner provenance, not included in its artifact. Rebuild on a new host.','archive':{'path':'receipts.tar.gz','bytes':len(data),'sha256':sha(data)},'files':files},indent=2)+'\n')
print('Verified',len(files),'receipts;',len(data),'archive bytes')
