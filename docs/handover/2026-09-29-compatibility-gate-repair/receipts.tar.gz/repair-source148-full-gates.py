from pathlib import Path
root=Path('/private/tmp/emaxx-runtime-audit-followup/emaxx')
p=root/'src/lisp/primitives/dispatch/misc_keymaps.rs';s=p.read_text()
a=s.index('        let parts = key_sequence_keymap_parts(&normalized)?;');b=s.index('\n    })',a)
s=s[:a]+'''        // lookup_key_1 advances once per original event. Meta-to-ESC is
        // part of access_keymap_1; a missing Meta prefix on the final event
        // is an undefined binding, not a zero-length failed sequence.
        let events = key_description_events(&normalized)?;
        keymap_lookup_sequence_value_with_default(
            interp, &keymap, &events, accept_default, env,
        )'''+s[b:];p.write_text(s)
p=root/'src/lisp/primitives/keys.rs';s=p.read_text()
a=s.index('pub(crate) fn key_sequence_prefix_event_count(');b=s.index('pub(crate) fn textual_key_sequence_keymap_parts(',a);s=s[:a]+s[b:];p.write_text(s)
p=root/'src/lisp/primitives/values.rs';s=p.read_text()
old='''    let map = keymap_reference_map(interp, &map, env).unwrap_or(map);
    let map = public_keymap_value(interp, &map);
    let tail = if map'''
new='''    let map = keymap_reference_map(interp, &map, env).unwrap_or(map);
    let mut map = public_keymap_value(interp, &map);
    let event = event.cons_values().map_or(event, |(head, _)| head);
    let mut event = match event.kind() {
        Kind::Integer(code) => Value::Integer(code & (KEY_DESCRIPTION_META_BIT | (KEY_DESCRIPTION_META_BIT - 1))),
        Kind::Symbol(name) => {
            let (modifiers, base) = event_symbol_name_modifiers(&name);
            Value::symbol(&modified_event_symbol_name(modifiers, base))
        }
        _ => event,
    };
    let _input_roots = crate::lisp::alloc::RootedVec::from_vec(vec![map, event]);
    if let Kind::Integer(code) = event.kind() && code & KEY_DESCRIPTION_META_BIT != 0 {
        // keymap.c:access_keymap_1 handles Meta within this one event, so
        // failure here cannot consume part of lookup_key_1's key sequence.
        let mut prefix = interp.lookup_var("meta-prefix-char", env)
            .unwrap_or(Value::Integer(KEY_DESCRIPTION_META_PREFIX));
        if prefix.as_integer()? & KEY_DESCRIPTION_META_BIT != 0 {
            prefix = Value::Integer(KEY_DESCRIPTION_META_PREFIX);
            interp.set_global_binding("meta-prefix-char", prefix);
        }
        let binding = keymap_access_event(interp, map, prefix, accept_default, env)?;
        if let Some(prefix_map) = binding.and_then(|value| keymap_reference_map(interp, &value, env)) {
            map = prefix_map;
            event = Value::Integer(code & !KEY_DESCRIPTION_META_BIT);
        } else if accept_default {
            event = Value::T;
        } else {
            return Ok(binding.filter(Value::is_nil));
        }
    }
    let tail = if map'''
assert old in s;s=s.replace(old,new,1);p.write_text(s)
p=root/'tests/fixtures/unwind-payload-reclamation.el';s=p.read_text()
a=s.index('    (dolist (function (list body bytecode native))');s=s[:a]+'''    ;; GNU's conservative native stack scan can retain the most recent
    ;; payload until the enclosing caller returns on Linux. Collect only
    ;; after all creating/calling frames have returned, while keeping each
    ;; weak table and its live-payload verdict. No payload becomes strong.
    (setq answers
          (funcall
           (lambda (functions)
             (let (results)
               (dolist (function functions (nreverse results))
                 (let ((unwind-reclamation-table
                        (make-hash-table :test 'eq :weakness 'value)))
                   (push (list (funcall function) unwind-reclamation-table)
                         results)))))
           (list body bytecode native)))
    (garbage-collect)
    (list (byte-code-function-p bytecode) (native-comp-function-p native)
          (mapcar (lambda (result)
                    (list (car result) (hash-table-count (cadr result))))
                  answers))))
''';p.write_text(s)
