from pathlib import Path
import hashlib,json,os,subprocess,sys,time
p=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28')
r=Path('/private/tmp/emaxx-runtime-audit-followup/emaxx');g=Path('/private/tmp/emaxx-runtime-gnu-20260928')
tag='source'+sys.argv[1]
manifest=json.loads((p/(tag+'-manifest.json')).read_text());sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
unchanged=lambda:all(sha(r/f)==h for f,h in manifest.items());assert unchanged()
binaries={'gnu':g/'src/emacs','emaxx':r/'target/frame-validation/release/emaxx'}
selector="(not (or (tag :expensive-test) (tag :unstable)))"
summary=[]
for relative in sys.argv[2:] or ['test/src/keymap-tests.el','test/src/casefiddle-tests.el','test/lisp/emacs-lisp/gv-tests.el']:
    reports={};runs={};name=Path(relative).stem
    for label,b in binaries.items():
        stem=p/(tag+'-'+name+'-report-'+label);fixture=g/relative;reporter=r/'compat/emacs_compat_runner.el'
        report=stem.with_suffix('.json');assert not report.exists()
        command=[str(b),'-Q','--batch','-l',str(reporter),'-l',str(fixture),'--eval',"(emaxx-compat-run '"+selector+")"]
        inputs={str(f):sha(f) for f in [b,b.with_suffix('.pdmp'),fixture,reporter]}
        env={'LANG':'C','LC_ALL':'C','EMAXX_GC_VERIFY':'1','EMACS_TEST_DIRECTORY':str(g/'test'),
             'EMAXX_GNU_SOURCE_DIRECTORY':str(g),'EMAXX_DUMP_SOURCE_DIRECTORY':str(g),
             'EMAXX_BATCH_RESULT_FILE':str(report),'EMAXX_COMPAT_RUNNER':label,
             'EMAXX_COMPAT_RELATIVE_FILE':relative,'EMAXX_COMPAT_SELECTOR':"'"+selector}
        with stem.with_suffix('.command.json').open('x') as f:json.dump({'command':command,'working_directory':str(p),'environment_override':env,'inputs':inputs,'timeout_seconds':180,'qualification':'Same original upstream file, default selector, unchanged reporter, strict UTF-8 JSON. Source-matched GNU, not frozen Darwin pin; diagnostic file run, not complete compatibility certification.'},f,indent=2)
        start=time.monotonic()
        try:
            c=subprocess.run(command,cwd=p,env={**os.environ,**env},capture_output=True,timeout=180)
            rc=c.returncode;stdout,stderr=c.stdout,c.stderr;timed_out=False
        except subprocess.TimeoutExpired as e:
            rc=None;stdout,stderr=e.stdout or b'',e.stderr or b'';timed_out=True
        stem.with_suffix('.stdout').write_bytes(stdout);stem.with_suffix('.stderr').write_bytes(stderr)
        result={'exit_code':rc,'timed_out':timed_out,'elapsed_seconds':time.monotonic()-start,'source_unchanged':unchanged(),'inputs_unchanged':all(sha(Path(f))==h for f,h in inputs.items())}
        try:
            data=json.loads(report.read_text(encoding='utf-8'));reports[label]=data
            result['report_summary']=data['summary']
            result['outcomes']=[{k:t.get(k) for k in ['name','status','expected','condition_type','message']} for t in data['results'] if t['status']!='passed']
        except (OSError,UnicodeDecodeError,json.JSONDecodeError,KeyError) as e:
            result['report_error']=repr(e)
        with stem.with_suffix('.result.json').open('x') as f:json.dump(result,f,indent=2)
        runs[label]=result
        print(relative,label,json.dumps(result),flush=True)
    summary.append({'file':relative,'runs':runs})
with (p/(tag+'-compatibility-reports-summary.json')).open('x') as f:json.dump(summary,f,indent=2)
