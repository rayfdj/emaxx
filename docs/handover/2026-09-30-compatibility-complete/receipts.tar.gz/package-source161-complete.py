from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import subprocess
import tarfile

p = Path(__file__).parent
root = p.parents[2]
sha = lambda data: hashlib.sha256(data).hexdigest()
rust = {platform: json.loads((p / f'source161-{platform}-complete-rust-audit.json').read_text())
        for platform in ['macos', 'linux']}
assert rust['macos']['total_passed'] == 3013 and rust['linux']['total_passed'] == 3025
assert all(r['status'] == 'passed' and r['native_artifact_identity'] == 'passed' for r in rust.values())
frozen = json.loads((p / 'source161-linux-complete-frozen-audit.json').read_text())
assert frozen['status'] == 'matched' and frozen['verified_files'] == 519
assert frozen['verified_outcomes'] == 7928 and frozen['successful_processes'] == 1038
terminal = json.loads((p / 'source161-complete-terminal-audit.json').read_text())
assert terminal['status'] == 'passed' and terminal['scenarios'] == 223 and terminal['verified_checkpoints'] == 679
failed = json.loads((p / 'full-gate-source161/summary.json').read_text())
assert failed['status'] == 'failed' and not failed['cargo_stages']
assert failed['test_binary']['sha256'] == rust['macos']['test_binary_sha256']
old_counts = []
for f in (p / 'full-gate-source161').glob('repeat-*.log'):
    matches = re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed;', f.read_text())
    assert len(matches) == 1
    old_counts.append(tuple(map(int, matches[0])))
assert len(old_counts) == 6 and tuple(map(sum, zip(*old_counts))) == (2176, 12)
source = json.loads((p / 'source161-manifest.json').read_text())
assert len(source) == 328
heads = ['d9caac1e9535b97438cdcb52abe7d3cfde434f7b',
         '72b487b1902c7368c16a2f6f7a2b6615bf74cd74',
         'e02cd7ecb0eb73f54986d3a1e6026afc3e5fdc17']
for head in heads:
    data = subprocess.check_output(['git', 'archive', head, '--', *source], cwd=root)
    with tarfile.open(fileobj=io.BytesIO(data)) as archive:
        for name, digest in source.items():
            assert sha(archive.extractfile(name).read()) == digest, (head, name)
assert all(sha((root / name).read_bytes()) == digest for name, digest in source.items())
equivalence = {'verified_commits': heads, 'verified_inputs': len(source), 'source_manifest': 'source161-manifest.json'}
with (p / 'source161-compiled-equivalence.json').open('x') as f:
    json.dump(equivalence, f, indent=2)
    f.write('\n')
selected = {}
suffixes = {'.json', '.log', '.txt', '.stdout', '.stderr', '.loaded', '.el', '.expected', '.py', '.patch', '.md'}
for directory in ['full-gate-source161', 'full-gate-source161-host',
                  'linux-source161-full-artifacts', 'linux-source161-frozen-artifacts']:
    for f in (p / directory).rglob('*'):
        if f.is_file() and f.suffix in suffixes:
            selected[str(f.relative_to(p))] = f
names = {'package-source161-complete.py', 'run-source161-full-gate.py',
         'run-source161-host-full-gate.py', 'run-source161-full-tty.py',
         'verify-complete-rust-receipts.py', 'verify-complete-frozen-receipts.py',
         'verify-complete-terminal-receipts.py'}
for f in p.iterdir():
    if f.is_file() and f.suffix in suffixes and (f.name.startswith('source161-') or f.name in names):
        selected[f.name] = f
out = root / 'docs/handover/2026-09-30-compatibility-complete'
out.mkdir(exist_ok=False)
files = []
with (out / 'receipts.tar.gz').open('xb') as stream:
    with gzip.GzipFile(fileobj=stream, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, f in sorted(selected.items()):
                data = f.read_bytes()
                info = tarfile.TarInfo(name)
                info.mode = 0o644
                info.size = len(data)
                archive.addfile(info, io.BytesIO(data))
                files.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
with tarfile.open(out / 'receipts.tar.gz', 'r:gz') as archive:
    assert archive.getnames() == [f['path'] for f in files]
    for f in files:
        data = archive.extractfile(f['path']).read()
        assert len(data) == f['bytes'] and sha(data) == f['sha256']
data = (out / 'receipts.tar.gz').read_bytes()
record = {
    'source_manifest': 'source161-manifest.json', 'source_equivalence': equivalence,
    'rust': rust, 'linux_frozen': frozen, 'terminal': terminal,
    'strict_and_selected_validation': 'Formatting, compiler, warnings-denied Clippy and diff checks, 72 debug and 72 release controls, fifteen ordinary GNU comparisons and focused org-open pass; the earlier menu-composition bundle preserves the selected run details and source159 setup failure.',
    'sandbox_failure_preserved': 'The first macOS full run was launched inside the restricted sandbox: 2,176 passes and twelve localhost-socket Operation not permitted failures across six groups; four later groups and both Cargo stages did not execute. The complete host-permitted rerun uses the identical source and exact test binary SHA-256, and all original tests pass. No selector, timeout or expected outcome changed. The failed run retained only its binary because its initial retainer named the wrong fixture directory; no fixture-image retention is claimed for that failed run.',
    'artifact_qualification': 'Fourteen post-run macOS Rust artifacts and four Linux artifacts were rehashed against retained manifests. These are remaining files, not a per-test image-use transcript. Executable/image bytes are kept locally and excluded from this portable text archive. Linux frozen identities come from runner provenance, not downloaded executable bytes.',
    'preexisting_limits': 'Initial sequence-type checking, collecting callback mutation and macro prefix/filter mismatches are preserved in ordinary negative probes. Retained main reproduces the documented callback and dispatch failures. A separate source166 architecture draft repairs them with its own selected evidence; this source161 checkpoint does not claim those fixes.',
    'qualification': 'Complete unchanged Rust inventories and raw results pass on macOS and Linux, Linux frozen inventories match, and all default terminal screen/filesystem checkpoints match source/ABI-matched Darwin GNU. The Darwin frozen executable is still unavailable. Remaining architecture, physical allocation accounting, final adversarial audit and locked performance criteria remain open; this validated main checkpoint does not complete the goal.',
    'archive': {'path': 'receipts.tar.gz', 'bytes': len(data), 'sha256': sha(data)},
    'files': files,
}
(out / 'manifest.json').write_text(json.dumps(record, indent=2) + '\n')
print('Verified', len(files), 'complete receipts;', len(data), 'archive bytes')
