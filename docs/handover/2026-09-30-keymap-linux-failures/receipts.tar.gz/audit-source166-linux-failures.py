from pathlib import Path
import hashlib,json,re
p=Path(__file__).parent
root=p.parents[2]
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
head='3bada057ce99da19609909d97088e73d69cd27f3'
rust=next((p/'linux-source166-full-artifacts').glob('*/rust'))
rs=json.loads((rust/'summary.json').read_text())
assert rs['status']=='failed' and rs['git']=={'dirty':False,'head':head} and not rs['cargo_stages']
inventory=[line[:-6] for line in (rust/'inventory.txt').read_text().splitlines() if line.endswith(': test')]
assert len(inventory)==len(set(inventory))==2930
counts=[]
for group in ['eval_01','eval_02','eval_03','eval_04','eval_05','primitives']:
 record=json.loads((rust/f'repeat-01-{group}.json').read_text())
 log=(rust/f'repeat-01-{group}.log').read_text()
 prefix=record['command'][1]
 expected=sorted(n for n in inventory if prefix in n)
 executed=re.findall(r'^test (\S+) \.\.\.',log.split('\nfailures:')[0],re.M)
 assert sorted(executed)==expected and len(expected)==record['expected_tests']
 summaries=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)
 assert len(summaries)==(2 if group=='primitives' else 1)
 passed,failed,ignored=map(int,summaries[-1]);assert passed+failed+ignored==len(expected) and ignored==0
 assert record['exit_code']==(101 if group=='primitives' else 0) and not record['timed_out']
 counts.append({'group':group,'passed':passed,'failed':failed})
assert sum(r['passed'] for r in counts)==2201 and sum(r['failed'] for r in counts)==1
retained=json.loads((rust/'retained-inputs/manifest.json').read_text())
assert retained['gate_summary_sha256']==sha(rust/'summary.json')
for item in retained['files']:
 f=rust/'retained-inputs'/item['artifact'];assert f.stat().st_size==item['bytes'] and sha(f)==item['sha256']
fr=next((p/'linux-source166-frozen-artifacts').glob('*/compat/frozen-*'))
s=json.loads((fr/'summary.json').read_text())
lock=json.loads((root/'compat/oracle.lock.linux.json').read_text())
manifest=root/'compat/oracle_tests_all_linux.txt'
expected={};current=None
for line in manifest.read_text().splitlines():
 match=re.fullmatch(r'(\S+): discovered=(\d+) selected=(\d+)',line)
 if match:
  current=match[1];expected[current]={'discovered':int(match[2]),'selected':int(match[3]),'names':[]}
 elif line.strip():expected[current]['names'].append(line.strip())
assert len(expected)==519 and sum(x['selected'] for x in expected.values())==7928
assert s['mode']=='frozen' and s['name_filter'] is None and s['selector']==lock['selector_default']
assert len(s['files'])==len(set(s['files']))==519 and set(s['files'])==set(expected)
assert s['frozen_manifest']['sha256']==sha(manifest)
prov=s['provenance'];assert prov['subject_git_head']==head and not prov['subject_git_dirty']
assert prov['oracle_sha256']==lock['emacs_binary_sha256'] and prov['oracle_repo_commit']==lock['emacs_repo_commit']
runner_counts={r:{k:0 for k in ['total','passed','failed','skipped','unexpected']} for r in ['emaxx','oracle']}
matching=0;mismatching=0;processes=0;failures=[]
for file,inv in expected.items():
 directory=(fr/file).with_suffix('.compat')
 comp=json.loads((directory/'comparison.json').read_text())
 matching+=comp['matching_outcomes'];mismatching+=comp['mismatching_outcomes']
 assert comp['matching_outcomes']+comp['mismatching_outcomes']==inv['selected']
 reports={}
 for runner in runner_counts:
  report=json.loads((directory/(runner+'.json')).read_text());reports[runner]=report
  assert report['file_status']=='loaded' and report['file_error'] is None and report['selector']==s['selector']
  assert len(report['discovered_tests'])==inv['discovered'] and sorted(report['selected_tests'])==sorted(inv['names'])
  results=report['results'];assert sorted(x['name'] for x in results)==sorted(inv['names'])
  observed={k:sum(x['status']==k for x in results) for k in ['passed','failed','skipped']}
  observed.update(total=len(results),unexpected=sum(not x['expected'] for x in results));assert observed==report['summary']
  for k,n in observed.items():runner_counts[runner][k]+=n
  process=json.loads((directory/(runner+'.execution.json')).read_text())['process']
  assert process['exit_code']==0 and process['test_started'] and not process['timed_out'] and process['timeout_phase'] is None
  processes+=1
 if not comp['matches']:
  failures.append({'file':file,'issues':comp['issues'],'execution_issues':comp['execution_issues'],
                   'unexpected_results':[x for x in reports['emaxx']['results'] if not x['expected']]})
 else:assert not comp['issues'] and not comp['execution_issues']
assert runner_counts==s['runner_summaries'] and (matching,mismatching,processes)==(7926,2,1038)
assert sorted(f['file'] for f in failures)==sorted(s['mismatches'])==sorted(s['unsuccessful_files'])
replays={}
for label in ['autorevert','network','reclamation']:
 base=p/f'linux-source166-{label}-replay-artifacts'
 summary=next(base.rglob('summary.json'));d=json.loads(summary.read_text())
 if label=='reclamation':
  assert d['status']=='failed' and d['exit_code']==101 and not d['timed_out']
  assert d['test_binary']['sha256']==rs['test_binary']['sha256']==sha(summary.parent/d['test_binary']['artifact'])
  for item in d['fixture_images']:
   f=summary.parent/item['artifact'];assert sha(f)==item['sha256'] and f.stat().st_size==item['bytes']
  replays[label]={'status':'failed','test_binary_sha256':d['test_binary']['sha256'],'environment':d['environment'],'finding':'Original assertion again returns ((1 t 1) (1 t 0)) instead of ((1 t 0) (1 t 0)).'}
 else:
  report=json.loads(next(base.rglob('emaxx.json')).read_text())
  assert report['file_status']=='load_error' and not report['results']
  execution=json.loads(next(base.rglob('emaxx.execution.json')).read_text())['process']
  assert execution['exit_code'] is None and not execution['timed_out'] and 'use of a cons the collector freed' in execution['stderr']
  assert d['provenance']['subject_sha256']==prov['subject_sha256'] and d['provenance']['subject_source_sha256']==prov['subject_source_sha256']
  replays[label]={'status':'aborted','finding':'Freed-cons assertion; no complete Emaxx test results. GNU completes original selected inventory.','total_expected_outcomes':d['total_outcomes'],'subject_sha256':d['provenance']['subject_sha256']}
result={'status':'failed','compiled_source':head,'rust':{'run_id':36647925886,'passed':2201,'failed':1,'groups':counts,'remaining_groups':['compat_runtime','tty','batch','lightweight'],'cargo_stages':'not executed','retained_artifacts':retained},'frozen':{'run_id':36647928962,'files':519,'matching_outcomes':matching,'mismatching_outcomes':mismatching,'successful_processes':processes,'runner_summaries':runner_counts,'failures':failures,'provenance':prov},'diagnostic_replays':replays,'qualification':'Original selectors, expected results and timeouts retained. Failed full gates remain failed. Ordinary replays are diagnostic and cannot certify frozen or full Rust coverage. Retained Rust files were rehashed; ordinary executable/image identities are runner provenance rather than downloaded binaries. No timing or final-goal pass is claimed.'}
with (p/'source166-linux-failure-audit.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print('Verified failed full Linux Rust and frozen inventories, all raw outcomes, retained Rust artifacts and all three diagnostic replays.')
