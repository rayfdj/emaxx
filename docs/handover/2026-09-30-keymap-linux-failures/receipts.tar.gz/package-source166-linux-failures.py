from pathlib import Path
import gzip,hashlib,io,json,tarfile
p=Path(__file__).parent
root=p.parents[2]
audit=json.loads((p/'source166-linux-failure-audit.json').read_text());assert audit['status']=='failed'
out=root/'docs/handover/2026-09-30-keymap-linux-failures'
out.mkdir(exist_ok=False)
suffixes={'.json','.log','.txt','.stdout','.stderr','.loaded','.py','.md','.el','.expected','.apparmor'}
files={}
for name in ['linux-source166-full-artifacts','linux-source166-frozen-artifacts','linux-source166-autorevert-replay-artifacts','linux-source166-network-replay-artifacts','linux-source166-reclamation-replay-artifacts']:
 for f in (p/name).rglob('*'):
  if f.is_file() and f.suffix in suffixes:files[str(f.relative_to(p))]=f
for f in p.iterdir():
 if f.is_file() and f.suffix in suffixes and (f.name.startswith('source166-linux-') or f.name in ['audit-source166-linux-failures.py','package-source166-linux-failures.py','source166-manifest.json','source166-base.json']):files[f.name]=f
sha=lambda data:hashlib.sha256(data).hexdigest()
inventory=[]
with (out/'receipts.tar.gz').open('xb') as stream:
 with gzip.GzipFile(fileobj=stream,mode='wb',filename='',mtime=0) as zipped:
  with tarfile.open(fileobj=zipped,mode='w') as archive:
   for name,f in sorted(files.items()):
    data=f.read_bytes();info=tarfile.TarInfo(name);info.mode=0o644;info.size=len(data)
    archive.addfile(info,io.BytesIO(data));inventory.append({'path':name,'bytes':len(data),'sha256':sha(data)})
with tarfile.open(out/'receipts.tar.gz','r:gz') as archive:
 assert archive.getnames()==[f['path'] for f in inventory]
 for f in inventory:
  data=archive.extractfile(f['path']).read();assert sha(data)==f['sha256'] and len(data)==f['bytes']
data=(out/'receipts.tar.gz').read_bytes()
record={**audit,'archive':{'path':'receipts.tar.gz','bytes':len(data),'sha256':sha(data)},'files':inventory}
(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
print('Retained',len(inventory),'receipts;',len(data),'archive bytes.')
