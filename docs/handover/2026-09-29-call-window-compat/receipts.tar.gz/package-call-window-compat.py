from pathlib import Path
import gzip,hashlib,io,json,tarfile
p=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28')
root=p.parents[2]
out=root/'docs/handover/2026-09-29-call-window-compat'
sha=lambda data:hashlib.sha256(data).hexdigest()
selected={}
for name in ['source119-full-ttydiff-command.json','source119-full-ttydiff-result.json','source119-full-ttydiff.log','run-source119-full-tty.py','source119-manifest.json','source119-ordinary-artifacts.json','source115-tail-ttydiff-command.json','source115-tail-ttydiff-result.json','source115-tail-ttydiff.log','run-source115-tail-tty.py','source115-manifest.json','source115-ordinary-artifacts.json','source119-linux-frozen-result.json','linux-49d0c25b-frozen-workflow.log','linux-49d0c25b-frozen-status.json','package-call-window-compat.py']:
 selected[name]=p/name
for f in (p/'linux-49d0c25b-frozen-artifacts').rglob('*'):
 if f.is_file():selected[str(f.relative_to(p))]=f
for n,expected in [(119,223),(115,77)]:
 stage='full' if n==119 else 'tail'
 r=json.loads((p/f'source{n}-{stage}-ttydiff-result.json').read_text())
 assert r['exit_code']==0 and r['source_unchanged'] and r['inputs_unchanged'] and r['complete_start_inventory']
 assert r['expected_scenarios']==r['started_scenarios']==expected and r['terminal_summary']==['PASS: all scenarios match']
manifest=json.loads((p/'source119-manifest.json').read_text())
assert all(sha((root/k).read_bytes())==v for k,v in manifest.items())
out.mkdir(exist_ok=False)
files=[]
with (out/'receipts.tar.gz').open('xb') as compressed:
 with gzip.GzipFile(fileobj=compressed,mode='wb',mtime=0,filename='') as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,path in sorted(selected.items()):
    data=path.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644
    tar.addfile(info,io.BytesIO(data))
    files.append({'path':name,'bytes':len(data),'sha256':sha(data)})
with tarfile.open(out/'receipts.tar.gz','r:gz') as tar:
 assert tar.getnames()==[f['path'] for f in files]
 for f in files:
  data=tar.extractfile(f['path']).read();assert len(data)==f['bytes'] and sha(data)==f['sha256']
archive=(out/'receipts.tar.gz').read_bytes()
record={'scope':'Main source119 full223terminal pass; source115 separate77scenario tail pass; main49 Linux frozen comparison failure with incomplete inventory.',
'qualification':'Terminal GNU executable is source matched, not the pinned Darwin binary. Source115 original fullrun remains failed/incomplete. Linux compares500of519files:498match,2differ;7411matching and3mismatching outcomes among completed comparisons. The keymap report contains invalid UTF8;18laterfiles neverexecute. No final goal or performance certificate.',
'archive':{'path':'receipts.tar.gz','bytes':len(archive),'sha256':sha(archive),'format':'gzip-compressed POSIX tar; extract to obtain lossless original bytes, including the invalidUTF8report.'},
'source119_manifest_matches_main_runtime':True,'files':files}
(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
print('Verified',len(files),'receipts,',len(archive),'archive bytes')
