from pathlib import Path
p=Path('src/lisp/primitives/keys.rs');s=p.read_text()
a=s.index('pub(crate) fn key_sequence_keymap_parts(');b=s.index('pub(crate) fn key_sequence_prefix_event_count',a)
s=s[:a]+'''pub(crate) fn key_sequence_keymap_parts(value: &Value) -> Result<Vec<Value>, LispError> {
    // Keep actual event words: key descriptions are deliberately lossy (for
    // example both 1 and CHAR_CTL | 'a' print as C-a).
    if let Ok(events) = vector_items(value)
        && let [event] = events.as_slice()
        && let Some(string) = string_like(event)
    {
        return textual_key_sequence_keymap_parts(&Value::String(string.text.into()));
    }
    let mut parts = Vec::new();
    for event in key_description_events(value)? {
        let event = if event.cons_values().is_some() && !lucid_event_type_list_p(&event) {
            event.car()?
        } else {
            event
        };
        match event.kind() {
            Kind::Integer(code) if code & KEY_DESCRIPTION_META_BIT != 0 => {
                parts.push(Value::Integer(KEY_DESCRIPTION_META_PREFIX));
                parts.push(Value::Integer(code & !KEY_DESCRIPTION_META_BIT));
            }
            _ => parts.push(event),
        }
    }
    Ok(parts)
}

''' + s[b:]
a=s.index('pub(crate) fn textual_key_sequence_keymap_parts(');b=s.index('pub(crate) fn append_key_description_parts',a)
s=s[:a]+'''pub(crate) fn textual_key_sequence_keymap_parts(value: &Value) -> Result<Vec<Value>, LispError> {
    if let Some(string) = string_like(value) {
        let events = vector_items(&parse_kbd_sequence(&string.text)?)?
            .into_iter().map(reader_key_event_value);
        let sequence = Value::list(std::iter::once(Value::symbol("vector-literal")).chain(events));
        return key_sequence_keymap_parts(&sequence);
    }
    key_sequence_keymap_parts(value)
}

''' + s[b:];p.write_text(s)
p=Path('src/lisp/primitives/hash_insert.rs');s=p.read_text().replace('parts: Option<Vec<String>>','parts: Option<Vec<Value>>')
a=s.index('pub(crate) fn keymap_entry_key_value(');b=s.index('pub(crate) fn set_hash_table_entries',a)
s=s[:a]+'''pub(crate) fn keymap_entry_key_value(parts: &[Value], key: &str) -> Value {
    if let [event] = parts { *event } else { Value::String(key.into()) }
}

''' + s[b:];p.write_text(s)
p=Path('src/lisp/primitives/values.rs');s=p.read_text()
s=s.replace('Option<Vec<String>>','Option<Vec<Value>>').replace('&[String]','&[Value]').replace('Vec<Vec<String>>','Vec<Vec<Value>>').replace('Vec::<Vec<String>>','Vec::<Vec<Value>>').replace('Vec<(Vec<String>, Value)>','Vec<(Vec<Value>, Value)>')
s=s.replace('fn approximate_key_parts(key: &str) -> Vec<String>','fn approximate_key_parts(key: &str) -> Vec<Value>').replace('fn binding_key_parts(binding: &RuntimeKeymapBinding) -> Vec<String>','fn binding_key_parts(binding: &RuntimeKeymapBinding) -> Vec<Value>')
s=s.replace('key.split_whitespace().map(str::to_string).collect()', 'key.split_whitespace().map(Value::symbol).collect()')
s=s.replace('''                        let parts = items
                            .into_iter()
                            .filter_map(|item| string_text(&item).ok())
                            .collect::<Vec<_>>();
                        (!parts.is_empty()).then_some(parts)''','''                        (!items.is_empty()).then_some(items)''')
s=s.replace('''.map(|parts| {
                    Value::list(parts.into_iter().map(|value| Value::String(value.into())))
                })''', '.map(Value::list)')
s=s.replace('head.join(" ")','key_parts_description(head)').replace('parts[1..].join(" ")','key_parts_description(&parts[1..])')
s=s.replace('let existing = bindings.iter().position(|existing| existing.key == key);', '''let existing = bindings.iter().position(|existing| {
        key_parts.as_ref().map_or_else(|| existing.key == key,
            |parts| binding_matches_key_parts(existing, parts))
    });''')
s=s.replace('''    key: &str,
) -> Result<(), LispError> {
    let parts = approximate_key_parts(key);''','''    parts: &[Value],
) -> Result<(), LispError> {
    let key = key_parts_description(parts);''')
s=s.replace('keymap_entry_key_value(std::slice::from_ref(part), key);','keymap_entry_key_value(std::slice::from_ref(part), &key);')
s=s.replace('bindings.retain(|existing| existing.key != key);','bindings.retain(|existing| !binding_matches_key_parts(existing, parts));')
s=s.replace('return keymap_remove_binding(interp, &prefix, &key_parts_description(&parts[1..]));','return keymap_remove_binding(interp, &prefix, &parts[1..]);')
s=s.replace('existing.key != key && !key_parts_match(&binding_key_parts(existing), &parts)','!key_parts_match(&binding_key_parts(existing), parts)')
a=s.index('pub(crate) fn canonical_key_part(');b=s.index('pub(crate) enum KeyLookupResult',a)
s=s[:a]+'''pub(crate) fn canonical_key_part(part: &Value) -> String {
    match part.kind() {
        Kind::Symbol(name) => name.replace("\\\\ ", "-").replace(' ', "-").to_lowercase(),
        Kind::T => "t".into(),
        Kind::Integer(code) => describe_key_code(code).to_lowercase(),
        _ => part.to_string(),
    }
}

pub(crate) fn key_parts_match(binding_parts: &[Value], requested_parts: &[Value]) -> bool {
    binding_parts.len() == requested_parts.len()
        && binding_parts.iter().zip(requested_parts).all(|(binding, requested)| {
            binding.eq_value(*requested)
                || (binding.is_symbol() && requested.is_symbol()
                    && canonical_key_part(binding) == canonical_key_part(requested))
        })
}

fn key_parts_description(parts: &[Value]) -> String {
    key_sequence_binding_text(&key_parts_to_sequence_value(parts))
        .unwrap_or_else(|_| key_parts_to_sequence_value(parts).to_string())
}

fn key_parts_identity(parts: &[Value]) -> Vec<usize> {
    parts.iter().map(|event| event.word()).collect()
}

''' + s[b:]
s=s.replace('keymap_entry_key_value(std::slice::from_ref(part), part)', '*part')
s=s.replace('["<t>".to_string()]','[Value::T]')
s=s.replace('prefix_parts.join(" ")','key_parts_identity(prefix_parts)').replace('let key = parts.join(" ");','let key = key_parts_description(&parts);')
s=s.replace('visited: &mut HashSet<((bool, usize), String)>','visited: &mut HashSet<((bool, usize), Vec<usize>)>')
a=s.index('pub(crate) fn key_parts_to_sequence_value(');b=s.index('fn where_is_binding_rank',a)
s=s[:a]+'''pub(crate) fn key_parts_to_sequence_value(parts: &[Value]) -> Value {
    // keymap.c:accessible-keymaps combines ESC followed by an integer event
    // into a Meta event when constructing its returned key sequences.
    let mut events = vec![Value::symbol("vector-literal")];
    let mut index = 0;
    while index < parts.len() {
        if parts[index] == Value::Integer(KEY_DESCRIPTION_META_PREFIX)
            && let Some(Kind::Integer(next)) = parts.get(index + 1).map(|v| v.kind())
            && next != KEY_DESCRIPTION_META_PREFIX
            && next & KEY_DESCRIPTION_META_BIT == 0
        {
            events.push(Value::Integer(next | KEY_DESCRIPTION_META_BIT));
            index += 2;
        } else {
            events.push(parts[index]);
            index += 1;
        }
    }
    Value::list(events)
}

''' + s[b:]
s=s.replace('let event_parts = vec![describe_key_code(i64::from(code))];','let event_parts = vec![Value::Integer(i64::from(code))];')
s=s.replace('key_sequence_binding_parts(&args[1])?', 'key_sequence_keymap_parts(&args[1])?').replace('parts.push(describe_key_code(i64::from(code)));','parts.push(Value::Integer(i64::from(code)));')
s=s.replace('''    let mut base = first.trim_start_matches('<').trim_end_matches('>');''','''    let Kind::Symbol(name) = first.kind() else { return false; };
    let mut base = name.as_str();''')
a=s.index('pub(crate) fn key_part_is_non_key_event(');b=s.index('pub(crate) fn key_parts_are_remap',a)
s=s[:a]+'''pub(crate) fn key_part_is_non_key_event(interp: &Interpreter, part: &Value) -> bool {
    let Kind::Symbol(name) = part.kind() else { return false; };
    interp.get_symbol_property(&name, "non-key-event")
        .is_some_and(|value| value.is_truthy())
}

''' + s[b:]
a=s.index('pub(crate) fn maybe_prefer_modifier_notation(');b=s.index('fn preferred_modifier_name',a)
s=s[:a]+s[b:]
s=s.replace('&maybe_prefer_modifier_notation(interp, advertised_parts, env)', 'advertised_parts').replace('&maybe_prefer_modifier_notation(interp, &parts, env)', '&parts')
s=s.replace('visited: HashSet<((bool, usize), String)>','visited: HashSet<((bool, usize), Vec<usize>)>').replace('seen: HashSet<String>,\n    matches:', 'seen: HashSet<Vec<usize>>,\n    matches:')
s=s.replace('let prefix_key = prefix.join(" ");','let prefix_key = key_parts_identity(prefix);').replace('let key = full_parts.join(" ");','let key = key_parts_identity(&full_parts);')
p.write_text(s)
p=Path('src/lisp/primitives/dispatch/misc_keymaps.rs');s=p.read_text()
s=s.replace('''                let key = key_sequence_binding_text(&normalized_key)?;
                let key_parts = key_sequence_keymap_parts(&normalized_key)?;''','''                let key_parts = key_sequence_keymap_parts(&normalized_key)?;
                let key = key_sequence_binding_text(&key_parts_to_sequence_value(&key_parts))?;''')
s=s.replace('keymap_remove_binding(interp, &args[0], &key)?','keymap_remove_binding(interp, &args[0], &key_parts)?')
p.write_text(s)
