from pathlib import Path
import hashlib,json,os,subprocess,sys,time
p=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28')
r=Path('/private/tmp/emaxx-runtime-frames-gsnnjxa_/emaxx');g=Path('/private/tmp/emaxx-runtime-gnu-20260928')
tag='source'+sys.argv[1];sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
manifest=json.loads((p/(tag+'-manifest.json')).read_text())
unchanged=lambda:all(sha(r/f)==h for f,h in manifest.items())
assert unchanged()
binaries={'gnu':g/'src/emacs','emaxx':r/'target/frame-validation/release/emaxx'}
results=[]
for name in ['keymap-menu-fallback','keymap-menu-case-table-order','string-make-multibyte-identity']:
 fixture=r/'tests/fixtures'/(name+'.el');expected=r/'tests/fixtures'/(name+'.expected');runs={}
 for label,b in binaries.items():
  stem=p/(tag+'-ordinary-'+name+'-'+label)
  inputs={str(f):sha(f) for f in [b,b.with_suffix('.pdmp'),fixture,expected]}
  command=[str(b),'-Q','--batch','--eval','(prin1 '+fixture.read_text()+')']
  env={'EMAXX_GC_VERIFY':'1'}
  with stem.with_suffix('.command.json').open('x') as f:json.dump({'command':command,'working_directory':str(p),'environment_override':env,'inputs':inputs,'source_manifest':tag+'-manifest.json','qualification':'Ordinary same-input GNU comparison; source-matched candidate, not frozen Darwin pin.'},f,indent=2)
  start=time.monotonic();c=subprocess.run(command,cwd=p,env={**os.environ,**env},capture_output=True,timeout=120)
  stem.with_suffix('.stdout').write_bytes(c.stdout);stem.with_suffix('.stderr').write_bytes(c.stderr)
  result={'exit_code':c.returncode,'elapsed_seconds':time.monotonic()-start,'stdout_hex':c.stdout.hex(),'stderr_hex':c.stderr.hex(),'source_unchanged':unchanged(),'inputs_unchanged':all(sha(Path(f))==h for f,h in inputs.items()),'expected_match':c.stdout==expected.read_bytes().strip()}
  with stem.with_suffix('.result.json').open('x') as f:json.dump(result,f,indent=2)
  runs[label]=result
  print(name,label,result['exit_code'],result['expected_match'],flush=True)
 results.append({'fixture':name,'runs':runs,'exact_match':all(x['exit_code']==0 and not x['stderr_hex'] and x['source_unchanged'] and x['inputs_unchanged'] and x['expected_match'] for x in runs.values())})
with (p/(tag+'-ordinary-keymap-case-comparisons.json')).open('x') as f:json.dump(results,f,indent=2)
assert all(x['exact_match'] for x in results)
