from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28')
r=Path('/private/tmp/emaxx-runtime-frames-gsnnjxa_/emaxx');g=Path('/private/tmp/emaxx-runtime-gnu-20260928')
manifest=json.loads((p/'source119-manifest.json').read_text());sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
unchanged=lambda:all(sha(r/f)==h for f,h in manifest.items());assert unchanged()
binaries={'gnu':g/'src/emacs','emaxx':r/'target/frame-validation/release/emaxx'}
for label,b in binaries.items():
 stem=p/('source119-keymap-upstream-'+label);fixture=g/'test/src/keymap-tests.el'
 cmd=[str(b),'-Q','--batch','-l',str(fixture),'--eval',"(ert-run-tests-batch-and-exit '(not (or (tag :expensive-test) (tag :unstable))))"]
 inputs={str(f):sha(f) for f in [b,b.with_suffix('.pdmp'),fixture]}
 env={'EMAXX_GC_VERIFY':'1','EMACS_TEST_DIRECTORY':str(g/'test'),'EMAXX_GNU_SOURCE_DIRECTORY':str(g),'EMAXX_DUMP_SOURCE_DIRECTORY':str(g)}
 with stem.with_suffix('.command.json').open('x') as f:json.dump({'command':cmd,'cwd':str(p),'environment_overrides':env,'inputs':inputs,'qualification':'Diagnostic original keymap upstream file, same contracted selector; source119 executable/image. Source-matched GNU candidate, not frozen pin. No permissive report decoder or modified expected results.'},f,indent=2)
 start=time.monotonic()
 try:
  c=subprocess.run(cmd,cwd=p,env={**os.environ,**env},capture_output=True,timeout=300);rc=c.returncode;stdout,stderr=c.stdout,c.stderr;timeout=False
 except subprocess.TimeoutExpired as e:rc=None;stdout,stderr=e.stdout or b'',e.stderr or b'';timeout=True
 stem.with_suffix('.stdout').write_bytes(stdout);stem.with_suffix('.stderr').write_bytes(stderr)
 result={'exit_code':rc,'timed_out':timeout,'elapsed_seconds':time.monotonic()-start,'source_unchanged':unchanged(),'inputs_unchanged':all(sha(Path(f))==h for f,h in inputs.items())}
 with stem.with_suffix('.result.json').open('x') as f:json.dump(result,f,indent=2)
 print(label,result,flush=True)
