from pathlib import Path
import hashlib, json, os, subprocess, sys, time

p = Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28')
tag = sys.argv[1]
fixture = p / 'keymap-prefix-filter-count.el'
binaries = {'gnu': Path('/private/tmp/emaxx-runtime-gnu-20260928/src/emacs'),
            'emaxx': Path('/private/tmp/emaxx-runtime-frames-gsnnjxa_/emaxx/target/frame-validation/release/emaxx')}
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
results = {}
for label, binary in binaries.items():
    stem = p / (tag + '-ordinary-keymap-prefix-filter-count-' + label)
    inputs = {str(f): sha(f) for f in [binary, binary.with_suffix('.pdmp'), fixture]}
    command = [str(binary), '-Q', '--batch', '--eval', '(prin1 ' + fixture.read_text() + ')']
    with stem.with_suffix('.command.json').open('x') as f:
        json.dump({'command': command, 'working_directory': str(p),
                   'environment_override': {'EMAXX_GC_VERIFY': '1'}, 'inputs': inputs,
                   'qualification': 'Ordinary GNU prefix lookup contract: exact callback counts, explicit GC, missing intermediate binding and successful leaf lookup. GNU source matched, not frozen pin.'}, f, indent=2)
    start = time.monotonic()
    run = subprocess.run(command, cwd=p, env={**os.environ, 'EMAXX_GC_VERIFY': '1'}, capture_output=True, timeout=120)
    stem.with_suffix('.stdout').write_bytes(run.stdout)
    stem.with_suffix('.stderr').write_bytes(run.stderr)
    result = {'exit_code': run.returncode, 'elapsed_seconds': time.monotonic() - start,
              'stdout_hex': run.stdout.hex(), 'stderr_hex': run.stderr.hex(),
              'inputs_unchanged': all(sha(Path(f)) == digest for f, digest in inputs.items())}
    with stem.with_suffix('.result.json').open('x') as f:
        json.dump(result, f, indent=2)
    results[label] = result
    print(label, run.returncode, run.stdout[:500], run.stderr[:200], flush=True)
with (p / (tag + '-ordinary-keymap-prefix-filter-count-comparison.json')).open('x') as f:
    json.dump({'outcomes': results, 'exact_match': results['gnu']['stdout_hex'] == results['emaxx']['stdout_hex'] and results['gnu']['stderr_hex'] == results['emaxx']['stderr_hex'] and results['gnu']['exit_code'] == results['emaxx']['exit_code']}, f, indent=2)
if tag == 'source143':
    assert all(r['exit_code'] == 0 and r['stderr_hex'] == '' and r['inputs_unchanged'] for r in results.values())
    assert results['gnu']['stdout_hex'] == results['emaxx']['stdout_hex']
