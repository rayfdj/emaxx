from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path('/private/tmp/emaxx-runtime-frames-gsnnjxa_/emaxx')
p=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28')
n=int(sys.argv[1]);prefix='source'+str(n)
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
files=[*root.joinpath('src').rglob('*.rs'),*root.joinpath('tests').rglob('*')]
files += [root/name for name in ['Cargo.toml','Cargo.lock','build.rs'] if (root/name).is_file()]
files += list(root.joinpath('.cargo').glob('*'))
files=sorted({f for f in files if f.is_file()})
manifest={str(f.relative_to(root)):sha(f) for f in files}
def save(name,data):
    with (p/(prefix+'-'+name+'.json')).open('x') as stream:json.dump(data,stream,indent=2);stream.write('\n')
save('manifest',manifest)
save('base',{'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    'worktree':str(root),'qualification':'Combined runtime-entry stack, casing, keymap and scoped pending-error root repairs on main1d1e8cdc; strict and selected validation pending. Historical source134-146 evidence remains separate.'})
patch=subprocess.check_output(['git','diff','--binary'],cwd=root)
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=root).decode().split('\0')
for name in untracked:
    if name not in manifest:continue
    new=subprocess.run(['git','diff','--no-index','--binary','/dev/null',name],cwd=root,stdout=subprocess.PIPE)
    assert new.returncode==1
    patch+=new.stdout
with (p/(prefix+'.patch')).open('xb') as f:f.write(patch)
command=['cargo','check','--locked','--all-targets','--all-features']
overrides={'CARGO_TARGET_DIR':'/private/tmp/emaxx-runtime-frames-gsnnjxa_/emaxx/target/frame-validation','CARGO_BUILD_JOBS':'1'}
save('check-command',{'command':command,'working_directory':str(root),'environment_override':overrides,'source_manifest':prefix+'-manifest.json'})
start=time.monotonic()
with (p/(prefix+'-check.log')).open('x') as log:
    result=subprocess.run(command,cwd=root,env={**os.environ,**overrides},stdout=log,stderr=subprocess.STDOUT)
record={'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,'source_unchanged':all(sha(root/name)==value for name,value in manifest.items())}
save('check-result',record)
print(json.dumps(record),flush=True)
sys.exit(result.returncode or (0 if record['source_unchanged'] else 1))
