from pathlib import Path
import gzip, hashlib, io, json, re, subprocess, tarfile

p = Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28')
root = p.parents[2]
out = root / 'docs/handover/2026-09-29-compatibility-history'
sha = lambda data: hashlib.sha256(data).hexdigest()
base = '1febcd73f7e1ddd7c8dc1c680d71387511d2238c'
archive = subprocess.check_output(['git', 'archive', '--format=tar', base, 'src', 'tests', 'Cargo.toml', 'Cargo.lock', 'build.rs', '.cargo'], cwd=root)
manifest = json.loads((p / 'source144-manifest.json').read_text())
with tarfile.open(fileobj=io.BytesIO(archive)) as files:
    assert all(sha(files.extractfile(name).read()) == digest for name, digest in manifest.items())
patch = subprocess.check_output(['git', 'diff', '--binary', '1d1e8cdcf205ed093550af869ba84a18232750c8', base, '--', 'src', 'tests', 'Cargo.toml', 'Cargo.lock', 'build.rs', '.cargo'], cwd=root)
with (p / 'source144-cumulative-from-main.patch').open('xb') as stream:
    stream.write(patch)
for tag, profiles, count in [('source144', ['debug', 'release'], 193), ('source145', ['debug', 'release'], 184), ('source146', ['debug'], 193)]:
    for stage in ['check', 'fmt', 'clippy', 'diff'] + [profile + '-selected' for profile in profiles]:
        result = json.loads((p / (tag + '-' + stage + '-result.json')).read_text())
        assert result['exit_code'] == 0 and result['source_unchanged']
    for profile in profiles:
        checked = json.loads((p / (tag + '-' + profile + '-selected-inventory-check.json')).read_text())
        assert checked['expected'] == count and checked['process_exit_code'] == 0
        assert checked['summary'] == 'test result: ok. %d passed; 0 failed; 0 ignored;' % count
        assert sha((p / (tag + '-' + profile + '-libtest')).read_bytes()) == checked['binary_unchanged']
for name in ['unwind-error-payload', 'unwind-protected-payloads', 'unwind-native-payloads', 'unwind-payload-reclamation']:
    comparison = json.loads((p / ('source145-ordinary-' + name + '-comparison.json')).read_text())
    assert comparison['exact_match']
selected = {}
suffixes = {'.json', '.py', '.rs', '.el', '.expected', '.md', '.patch', '.log', '.txt', '.stdout', '.stderr'}
for file in p.iterdir():
    if not file.is_file() or file.suffix not in suffixes:
        continue
    match = re.match(r'source(\d+)(?:[.-]|$)', file.name)
    include = bool(match and int(match[1]) in {134, 136, 137, 138, 140, 141, 142, 143, 144, 145, 146})
    include |= file.name.startswith(('keymap-', 'unwind-')) and file.suffix in {'.el', '.expected', '.json', '.stdout', '.stderr'}
    include |= file.name in ['describe-buffer-bindings-draft.rs', 'string-make-multibyte-identity.el', 'string-make-multibyte-identity.expected']
    include |= file.suffix == '.py' and any(part in file.name for part in ['compatibility', 'keymap', 'error-root', 'unwind', 'source134-ordinary-root', 'continuation-fixtures'])
    if include:
        selected[file.name] = file
out.mkdir(exist_ok=False)
records = []
with (out / 'receipts.tar.gz').open('xb') as stream:
    with gzip.GzipFile(fileobj=stream, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, file in sorted(selected.items()):
                data = file.read_bytes()
                info = tarfile.TarInfo(name)
                info.mode, info.size = 0o644, len(data)
                archive.addfile(info, io.BytesIO(data))
                records.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
with tarfile.open(out / 'receipts.tar.gz', 'r:gz') as archive:
    assert archive.getnames() == [record['path'] for record in records]
    for record in records:
        data = archive.extractfile(record['path']).read()
        assert len(data) == record['bytes'] and sha(data) == record['sha256']
data = (out / 'receipts.tar.gz').read_bytes()
(out / 'manifest.json').write_text(json.dumps({
    'scope': 'Independent stack, casing, keymap description and pending-error root repair history134-146, including original compiler/test failures and ordinary diagnostics.',
    'qualification': '144 passes193debug+193release and46upstream keymap tests; case10pass1existing skip andgv6pass2expected failures matchGNU.145 passes184debug+184release andfour ordinary root controls; old menu callback probe now reports255 instead of crashing but still differsGNU0.146 passes193debug andstrict checks; new callback fixtures await combined147validation. No full combined-source, frozen, or performance certification.',
    'reconstruction': 'source144-cumulative-from-main.patch applies to main1d1e8cdc.145 and146 patches contain subsequent independent repairs. Historical source-base qualifications naming running hash133 gates are superseded by source145-diagnostic-qualification.json.',
    'binary_policy': 'Large executables and images remain local. Exact identities, commands, source manifests, raw logs and reproduction drivers are retained. Source-matched GNU is not the frozen Darwin executable.',
    'archive': {'path': 'receipts.tar.gz', 'bytes': len(data), 'sha256': sha(data)}, 'files': records,
}, indent=2) + '\n')
print('Verified', len(records), 'receipts;', len(data), 'archive bytes')
