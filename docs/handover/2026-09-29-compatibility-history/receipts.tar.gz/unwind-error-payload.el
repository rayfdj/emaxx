(progn
  (require 'bytecomp)
  (put 'payload-condition 'error-conditions '(payload-condition error))
  (put 'payload-condition 'error-message "Payload condition")
  (let* ((body '(lambda ()
                 (unwind-protect
                     (signal 'payload-condition
                             (list (make-string 513 120)
                                   (vector (make-symbol "payload-symbol")
                                           (cons 37 (list 91)))))
                   (garbage-collect))))
         (compiled (byte-compile body))
         answers)
    (dolist (function (list body compiled))
      (push (condition-case data (funcall function)
              (payload-condition
               (list (car data)
                     (length (cadr data))
                     (symbol-name (aref (caddr data) 0))
                     (aref (caddr data) 1))))
            answers))
    (nreverse answers)))
