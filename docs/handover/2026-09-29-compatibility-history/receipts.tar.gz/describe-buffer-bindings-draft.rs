/// keymap.c:Fdescribe_buffer_bindings selects the maps and their shadow order;
/// unchanged help.el owns traversal, filtering, ranges and presentation.
pub(crate) fn describe_buffer_bindings(
    interp: &mut Interpreter,
    args: &[Value],
    env: &mut Env,
) -> Result<Value, LispError> {
    if args.is_empty() || args.len() > 3 {
        return Err(LispError::WrongNumberOfArgs(
            "describe-buffer-bindings".into(),
            args.len(),
        ));
    }
    let buffer = args[0];
    if !matches!(buffer.kind(), Kind::Buffer(_)) {
        return Err(LispError::WrongTypeArgument("bufferp".into(), buffer));
    }
    let prefix = args.get(1).copied().unwrap_or(Value::Nil);
    let nomenu = if args.get(2).is_some_and(Value::is_truthy) { Value::Nil } else { Value::T };
    // This is the actual argument vector for help--describe-map-tree. Keep
    // its maps, accumulated shadow list, prefix and buffer rooted across
    // arbitrary Lisp filters and insertion hooks.
    let mut description = crate::lisp::alloc::RootedVec::from_vec(vec![
        Value::Nil, Value::Nil, Value::Nil, prefix, Value::Nil, nomenu,
        Value::T, Value::Nil, Value::Nil, buffer,
    ]);
    let translation = interp.lookup_var("keyboard-translate-table", env).unwrap_or(Value::Nil);
    if !prefix.is_nil() && let Some(table) = string_like(&translation) {
        let size = table.text.chars().count();
        let mut heading = true;
        for index in 0..size {
            // GNU reacquires the table after insertions, which can run Lisp.
            let table = interp.lookup_var("keyboard-translate-table", env).unwrap_or(Value::Nil);
            let Some(table) = string_like(&table) else { break; };
            let bytes = internal_string_bytes(&table)?;
            let Some(&translated) = bytes.get(index) else { break; };
            if usize::from(translated) == index { continue; }
            if heading {
                call(interp, "insert", &[Value::String("Keyboard translations:\n\nYou type        Translation\n--------        -----------\n".into())], env)?;
                heading = false;
            }
            let key = single_key_description_text(&Value::Integer(i64::from(translated)), false)?;
            call(interp, "insert", &[Value::String(key)], env)?;
            call(interp, "indent-to", &[Value::Integer(16), Value::Integer(1)], env)?;
            let key = single_key_description_text(&Value::Integer(index as i64), false)?;
            call(interp, "insert", &[Value::String(key), Value::String("\n".into())], env)?;
        }
        call(interp, "insert", &[Value::String("\n".into())], env)?;
    }
    let translations = interp.lookup_var("key-translation-map", env).unwrap_or(Value::Nil);
    if !translations.is_nil() {
        insert_keymap_description(interp, &mut description, translations, "Key translations".into(), env)?;
    }
    description[1] = Value::T;
    description[6] = Value::Nil;
    let terminal = interp.lookup_var("overriding-terminal-local-map", env).unwrap_or(Value::Nil);
    let overriding = if !terminal.is_nil() {
        insert_keymap_description(interp, &mut description, terminal, "\x0c\nOverriding Bindings".into(), env)?;
        description[2] = Value::cons(description[0], description[2]);
        Value::Nil
    } else {
        interp.lookup_var("overriding-local-map", env).unwrap_or(Value::Nil)
    };
    if !overriding.is_nil() {
        insert_keymap_description(interp, &mut description, overriding, "\x0c\nOverriding Bindings".into(), env)?;
        description[2] = Value::cons(description[0], description[2]);
    } else {
        let minor = with_keymap_description_buffer(interp, buffer, |interp| {
            active_minor_mode_bindings(interp, env).map(crate::lisp::alloc::RootedVec::from_vec)
        })?;
        let property = with_keymap_description_buffer(interp, buffer, |interp| {
            Ok(keymap_at_active_position(interp, None).unwrap_or(Value::Nil))
        })?;
        if !property.is_nil() {
            insert_keymap_description(interp, &mut description, property, "\x0c\n`keymap' Property Bindings".into(), env)?;
            description[2] = Value::cons(description[0], description[2]);
        }
        for (mode, map) in minor.iter() {
            insert_keymap_description(interp, &mut description, *map, format!("\x0c\n`{mode}' Minor Mode Bindings"), env)?;
            description[2] = Value::cons(description[0], description[2]);
        }
        let (local, is_buffer_map, major) = with_keymap_description_buffer(interp, buffer, |interp| {
            let normal = interp.lookup_var("current-local-map", env).unwrap_or(Value::Nil);
            let local = local_map_at_active_position(interp, None).unwrap_or(normal);
            let major = interp.lookup_var("major-mode", env).unwrap_or(Value::Nil);
            Ok((local, values_eq_in_env(interp, &local, &normal, env), major))
        })?;
        if !local.is_nil() {
            description[0] = local;
            let title = if is_buffer_map {
                let title = call(interp, "format", &[Value::String("\x0c\n`%s' Major Mode Bindings".into()), major], env)?;
                string_like(&title).expect("format returns a string").text
            } else {
                "\x0c\n`local-map' Property Bindings".into()
            };
            insert_keymap_description(interp, &mut description, local, title, env)?;
            description[2] = Value::cons(description[0], description[2]);
        }
    }
    description[7] = Value::T;
    let global = interp.current_global_map_value();
    insert_keymap_description(interp, &mut description, global, "\x0c\nGlobal Bindings".into(), env)?;
    description[1] = Value::Nil;
    description[2] = Value::Nil;
    description[6] = Value::T;
    description[7] = Value::Nil;
    for (variable, title) in [
        ("local-function-key-map", "\x0c\nFunction key map translations"),
        ("input-decode-map", "\x0c\nInput decoding map translations"),
    ] {
        let map = interp.lookup_var(variable, env).unwrap_or(Value::Nil);
        if !map.is_nil() {
            insert_keymap_description(interp, &mut description, map, title.into(), env)?;
        }
    }
    Ok(Value::Nil)
}

fn insert_keymap_description(
    interp: &mut Interpreter,
    args: &mut crate::lisp::alloc::RootedVec<Value>,
    map: Value,
    title: String,
    env: &mut Env,
) -> Result<(), LispError> {
    args[0] = map;
    args[4] = Value::String(title);
    call_function_value(interp, &Value::symbol("help--describe-map-tree"), args, env)?;
    Ok(())
}

fn with_keymap_description_buffer<T>(
    interp: &mut Interpreter,
    buffer: Value,
    body: impl FnOnce(&Interpreter) -> Result<T, LispError>,
) -> Result<T, LispError> {
    let saved = interp.current_buffer_id();
    let target = interp.resolve_buffer_id(&buffer)?;
    interp.set_current_buffer_id(target)?;
    let result = body(interp);
    let restored = interp.set_current_buffer_id(saved);
    result.and_then(|value| restored.map(|()| value))
}

