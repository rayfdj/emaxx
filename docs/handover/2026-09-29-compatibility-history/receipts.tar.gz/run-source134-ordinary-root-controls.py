from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28');r=Path('/private/tmp/emaxx-runtime-frames-gsnnjxa_/emaxx');g=Path('/private/tmp/emaxx-runtime-gnu-20260928')
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();manifest=json.loads((p/'source134-manifest.json').read_text());unchanged=lambda:all(sha(r/f)==h for f,h in manifest.items())
assert unchanged();records=[]
for name,mode in [('runtime-cons-mutation','eval'),('weak-hash-setup-roots','eval'),('reader-callable-gc','eval'),('thread-native-suspension','load')]:
 fixture=r/'tests/fixtures'/(name+'.el');outcomes={}
 for label,b in [('gnu',g/'src/emacs'),('emaxx',r/'target/frame-validation/release/emaxx')]:
  stem=p/('source134-ordinary-'+name+'-'+label);home=p/('source134-ordinary-home-'+label);home.mkdir(exist_ok=True)
  cmd=[str(b),'-Q','--batch']+(['--eval','(prin1 '+fixture.read_text()+')'] if mode=='eval' else ['-l',str(fixture)])
  inputs={str(f):sha(f) for f in [b,b.with_suffix('.pdmp'),fixture]};env={'HOME':str(home),'EMAXX_GC_VERIFY':'1','EMAXX_GNU_SOURCE_DIRECTORY':str(g),'EMAXX_DUMP_SOURCE_DIRECTORY':str(g),'EMACS_TEST_DIRECTORY':str(g/'test')}
  with stem.with_suffix('.command.json').open('x') as f:json.dump({'command':cmd,'cwd':str(p),'environment_override':env,'inputs':inputs,'source_manifest':'source134-manifest.json','scope':'Original sharedLispGC/reader/copy/nativecontinuationfixtures throughordinaryentrypoints; source-matchedGNU,notfrozenpin.'},f,indent=2)
  start=time.monotonic()
  try:
   c=subprocess.run(cmd,cwd=p,env={**os.environ,**env},capture_output=True,timeout=180);rc=c.returncode;stdout,stderr=c.stdout,c.stderr;timeout=False
  except subprocess.TimeoutExpired as e:rc=None;stdout,stderr=e.stdout or b'',e.stderr or b'';timeout=True
  stem.with_suffix('.stdout').write_bytes(stdout);stem.with_suffix('.stderr').write_bytes(stderr)
  record={'exit_code':rc,'timed_out':timeout,'elapsed_seconds':time.monotonic()-start,'stdout_hex':stdout.hex(),'stderr_hex':stderr.hex(),'inputs_unchanged':all(sha(Path(f))==h for f,h in inputs.items()),'source_unchanged':unchanged()}
  with stem.with_suffix('.result.json').open('x') as f:json.dump(record,f,indent=2)
  outcomes[label]=record;print(name,label,record['exit_code'],repr(stdout),repr(stderr[-250:]),flush=True)
 records.append({'fixture':name,'outcomes':outcomes,'exact_match':outcomes['gnu']['stdout_hex']==outcomes['emaxx']['stdout_hex']})
with (p/'source134-ordinary-root-comparisons.json').open('x') as f:json.dump(records,f,indent=2)
assert all(r['exact_match'] and all(x['exit_code']==0 and not x['timed_out'] and x['stderr_hex']=='' and x['source_unchanged'] and x['inputs_unchanged'] for x in r['outcomes'].values()) for r in records)
