# Source132 release failure: address-dependent positioned hash assertion

Source132 passes105debug,all strict static checks,then270/271release tests.
`equal_hash_tables_match_positioned_and_bare_keys_while_enabled` fails because
lookup of the identical positioned list after disabling symbol-position equality
returns207 in the original and copied table, where the test expected missing.
The exact immutable release executable passes the unchanged test in isolation.
Its SHA256 is78510d5f9f3287bf97c867081e1fa488037de3460f5cecb56c9c8fe0bc934b61.
Neither run is substituted for the other; the broad release run remains failed.

GNU fns.c:hash_lookup_with_hash checks EQ on a candidate before comparing its
stored hash. Changing symbols-with-pos-enabled after insertion changes the
computed hash. The identical key is still found if that hash selects the same
bucket, even if its full hash changed. Copy preserves the stored arrays, so
both tables give the same result. Distinct bare keys compare unequal while
positions are significant and must miss.

The exact original Lisp body in GNU once yields the old expected result.
Repeating that same body4096times in one ordinaryGNUprocess yields526instances
of(207 missing207missing),3570instances of(missing missing missing missing),
and no other result. The original assertion is therefore invalid inGNUtoo.
Raw inputs,commands,executable hashes,outputs,and exitcodes are preserved.

Source133 changes only the test and adds its shared ordinary fixture. It keeps
the count=1 overwrite check, both enabled lookups=207, and restoration=207.
During the disabled scope it asserts identical-key lookup agrees between the
original and copy, both distinct bare-key lookups miss, and positioned/bare
lists compare unequal. GNU gives the exact corrected result
(1 207207(t missing missing nil)207). This does not suppress any test or alter
production lookup. Source133 passes105debug,271release andallstrictstaticchecks. Freshordinary executable/image validation also passes all eightfixtures with empty stderr, zero exits andunchangedidentities.
