from pathlib import Path
import gzip,hashlib,io,json,re,tarfile
p=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28');root=p.parents[2]
out=root/'docs/handover/2026-09-29-hash-allocation'
sha=lambda data:hashlib.sha256(data).hexdigest()
source=json.loads((p/'source133-manifest.json').read_text())
assert all(sha((root/f).read_bytes())==h for f,h in source.items())
for check in ['check','fmt','clippy','diff','debug-build','release-build','ordinary-build','ordinary-image','debug-selected','release-selected']:
 r=json.loads((p/f'source133-{check}-result.json').read_text());assert r['exit_code']==0 and r['source_unchanged']
for profile,count in [('debug',105),('release',271)]:
 command=json.loads((p/f'source133-{profile}-selected-command.json').read_text())
 check=json.loads((p/f'source133-{profile}-selected-inventory-check.json').read_text())
 assert check['expected']==count and check['process_exit_code']==0 and check['binary_unchanged']==command['binary_sha256']
 assert check['summary']==f'test result: ok. {count} passed; 0 failed; 0 ignored;'
 assert sha((p/f'source133-{profile}-libtest').read_bytes())==command['binary_sha256']
comparisons=json.loads((p/'source133-ordinary-hash-comparisons.json').read_text());assert len(comparisons)==8
assert all(c['exact_match'] and all(v['exit_code']==0 and v['stderr_hex']=='' and v['expected_match'] and v['source_unchanged'] and v['artifacts_unchanged'] for v in c['outcomes'].values()) for c in comparisons)
selected={}
for f in p.iterdir():
 if not f.is_file() or f.name=='source133-full-gate.log':continue
 m=re.match(r'source(\d+)(?:[-.]|$)',f.name)
 include=(m and 121<=int(m[1])<=133) or f.name.startswith(('gnu-hash-','hash-','source119-keymap-upstream-')) or f.name=='diagnose-source119-keymap.py' or f.name in ['hash_arrays_draft.rs','check-hash-migration.py','static-hash-migration.py','test-hash-migration.py','release-hash-migration.py','build-hash-ordinary.py','package-hash-allocation.py','run-source133-full-gate.py','run-source133-core.py','hash-allocation-checkpoint-draft.md'] or re.match(r'compare-source13[0123]-hash.py$',f.name)
 if include and f.suffix in {'.json','.py','.rs','.c','.el','.md','.patch','.log','.txt','.stdout','.stderr','.expected'}:selected[f.name]=f
# Complete diagnostic pilot, if finished by packaging. All samples are retained.
for folder in ['source133-core-native','source133-core-pilot-all']:
 if (p/folder).exists():
  result=json.loads((p/(folder+'-result.json')).read_text());assert result['exit_code']==0 and result['source_unchanged']
  for f in (p/folder).rglob('*'):
   if f.is_file() and f.suffix not in {'.eln','.elc','.pdmp'}:selected[str(f.relative_to(p))]=f
out.mkdir(exist_ok=False);files=[]
with (out/'receipts.tar.gz').open('xb') as output:
 with gzip.GzipFile(fileobj=output,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as archive:
   for name,f in sorted(selected.items()):
    data=f.read_bytes();info=tarfile.TarInfo(name);info.mode=0o644;info.size=len(data);archive.addfile(info,io.BytesIO(data))
    files.append({'path':name,'bytes':len(data),'sha256':sha(data)})
with tarfile.open(out/'receipts.tar.gz','r:gz') as archive:
 assert archive.getnames()==[f['path'] for f in files]
 for f in files:
  data=archive.extractfile(f['path']).read();assert sha(data)==f['sha256'] and len(data)==f['bytes']
data=(out/'receipts.tar.gz').read_bytes()
record={'scope':'Shared hash-table allocation: original failednativeprobe, compiler and runtime failures121through132, source133 strictstatic/debug/release/ordinary controls and diagnosis. Large executable/image files retained locally, checksums included.',
'qualification':'105debug and271release passes; eight ordinaryGNUmatches. GNU source/ABI matched, not frozenDarwinpin. Full macOS/Linux gates and remaining frozen failures are separate required work. No complete architectural/accounting/performance certificate.',
'archive':{'path':'receipts.tar.gz','format':'gzip-compressed POSIX tar','bytes':len(data),'sha256':sha(data)},'source_manifest':'source133-manifest.json','files':files}
(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
print('Verified',len(files),'receipts;',len(data),'archive bytes')
