# Shared hash-table allocation — working checkpoint notes

Source133 committed as c7839c13 in the audit worktree and integrated as3a0f4d41 on the task branch. Main remains49d0c25b throughPR75.
The full runtime/performance goal is open. Replace pending results with verified
receipts before publishing this note as a checkpoint.

## Representation

GNU lisp.h:Lisp_Hash_Table and fns.c:make_hash_table define the new allocated
PVEC_HASH_TABLE (14): a 72-byte C-compatible object, rounded to 80 bytes by the
vector allocator. Count, flags, descriptor and all four owned array pointers are
actual fields. Native code, interpreter primitives, JSON, printer, CCL, GC and
image loading use that same word and storage. Four per-interpreter tables for
standard/custom entries, callback mutation protection and immutable tables are
removed. No per-key identity registry or mirrored entry list is introduced.

For positive capacity N, arrays occupy 24*N + 4*I bytes, with I the next power
of two strictly greater than N. Capacity zero shares the constant empty index.
Allocation staging owns every array until installation; replacement and sweep
release them. Stored hashes and slot/free/collision chains survive ordinary
copying and growth. Purecopy recursively replaces Lisp fields without rehashing.
GNU charges 72 logical header/payload bytes; the allocator census includes the
80-byte footprint. Live array bytes are actual separately owned storage.

Descriptors follow fns.c:get_hash_table_user_test and mark_fns: custom descriptors
and their three Lisp roots live for the process lifetime. Standard descriptors
are reached directly and never search the custom list. Rust binds allocated
symbol words on first use, requiring one 48-byte allocation for each of the three
standard descriptors instead of GNU's static initializers. Each unique custom
node is 56 bytes before system allocator overhead. These process-lifetime host
bytes are not charged to GNU's GC allocation counter. The first40bytes keep theGNU ABI; a private immutable kind byte follows it, avoiding Rust function-address identity and its three comparisons. Alignment adds8bytes per shared descriptor, not per table. No physical-memory or
complete-allocation-accounting certificate is claimed.

The collector marks strong entries in place, solves weak reachability to a fixed
point, and removes dead entries in bucket/collision-chain order before sweeping
objects. Temporary GC work lists retain table handles and rejected slot indices,
not entry mirrors. The pre-existing policy for other parked interpreter states
still treats their weak entries strongly; that policy remains a goal-wide issue.
Dump serialization retains its existing hash wire record while restoring actual
allocated hash objects. Every object's fields are relocated before rehashing.

## Preserved failures and evidence limits

Source121's unchanged native acceptance probe fails PVEC34 versus GNU PVEC14.
Sources122/123/126 have compiler failures; source124 fails91/100 selected tests
at the old native initializer; source125 fails15/100 at the checked native decoder.
Source127 passes102 debug controls, but Clippy reports five cleanup issues;
source128 reports one remaining Clippy issue. Source129 passes103 debug and all
strict static checks, but its wider release run fails one of269 tests.

The source129 failed release binary fails the same isolated weak-table test.
Its retained ARM disassembly shows the positive survival assertion leaving the
raw value address in x22 through the second GC. Register/stack scanning therefore
correctly retains it. Source130 uses the existing non-inlined hidden-word helper
for both positive checks, preserving every survival and eventual reclamation
assertion. It passes103 debug and269 release tests, no ignores, and all strict
static checks. This does not explain earlier Linux suspended-bytecode failures.

A separate GNU purecopy probe with unused hash slots aborts with exit -6. It is
preserved; a distinct full-table control passes with exact expected output.
No GNU crash is treated as a pass or emulated in Rust. Constructor comparisons
also expose positioned-symbol and error-order differences, including pre-existing
main behavior. Source131 fixes descriptor capture before size validation, env-aware
weakness and callback EQ, and allocation after keyword validation. Both new same-input GNU controls pass.

Source131 passes105debug and271release controls, no ignores, and all strict static
checks. Its fresh ordinary executable/image matches all seven GNU fixtures exactly,
including empty stderr and unchanged input/source/artifact hashes. Source132 adds
only the explicit descriptor kind above. It passes105debug and strictstatic
checks; release has270pass1fail in the positioned-key assertion. The unchanged
isolated release replay passes. Repeated same-input GNU calls prove the
assertion address dependent:526hits,3570misses. Source133 preserves the stable
copy/equality-mode contracts and adds an eighth ordinary fixture; validation
is running. See hash-positioned-equality-diagnosis.md for full reasoning. No hash checkpoint has
been committed, pushed, or merged yet. Final-source full gates, ordinary pinned
compatibility, audit, ownership/retention work, actual allocation accounting and
locked runtime performance parity remain required.
