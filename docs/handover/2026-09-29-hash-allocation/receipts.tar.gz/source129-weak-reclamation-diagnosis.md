# Release weak-table diagnostic, source 129

The broader release run fails with 268 passes and one failure in
`native_gc_finishes_weak_table_marking_before_sweeping`. The exact same
immutable binary fails the unchanged isolated test too. Both logs remain.
The failed executable SHA-256 is
`76660f84ad2a0fcf38b508a01364126ae5d3b066e07aa5c4730a0757c6c9d68b`.

The retained ARM disassembly identifies an unintended conservative root:

- `0x1006d14d8` loads the hidden key/value words into x21/x20.
- `0x1006d1548` unhides the value word; `0x1006d154c` puts the raw cons
  address in callee-saved x22 for the original positive survival assertion.
- x22 is not overwritten before the second collection at `0x1006d1628`.
- `alloc.rs:spill_registers` explicitly spills x21/x22. The collection
  scans saved registers and stack words, so this raw address is a root.

Source 130 changes the two positive survival checks to use the existing
non-inlined `hidden_cons_is_live` helper, which was already used for the
negative reclamation checks. All original survival, reclamation and table
membership assertions remain, as do both collections and stack clobbers.
No production behavior is changed from source 129 (only these test accesses
and corrections to stale representation/accounting comments).

Source 130 passes103debug and269release tests with no ignores, all strict static checks and five initial ordinaryGNU comparisons. Source131 also passes105debug and271release tests and seven ordinary comparisons after independent constructor/descriptor repairs. This diagnosis does not explain or clear
the earlier, separately recorded Linux suspended-bytecode retention failures.
