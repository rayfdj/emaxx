from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
result = read('source170-full-gate-result.json')
summary = read('full-gate-source170/summary.json')
assert result['exit_code'] == 1 and result['source_unchanged']
assert summary['status'] == 'failed' and not summary['cargo_stages']
assert summary['test_binary']['sha256'] == sha(Path(result['immutable_binary']['path']).read_bytes())
groups = ['eval_01', 'eval_02', 'eval_03', 'eval_04', 'eval_05', 'primitives']
totals = []
for group in groups:
    text = (p / f'full-gate-source170/repeat-01-{group}.log').read_text()
    verdicts = re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text, re.M)
    final = verdicts[-1]
    expected = ('FAILED', '588', '1', '0') if group == 'primitives' else ('ok', str(summary['inventory']['groups'][group]), '0', '0')
    assert final == expected, (group, final)
    totals.append(int(final[1]))
assert sum(totals) == 2195
assert 'left: "((1 t 1) (1 t 0))"' in text
assert 'right: "((1 t 0) (1 t 0))"' in text
assert not any((p / f'full-gate-source170/repeat-01-{group}.log').exists()
               for group in ['compat_runtime', 'tty', 'batch', 'lightweight'])
retained = p / 'full-gate-source170/retained-inputs'
for item in json.loads((retained / 'manifest.json').read_text())['files']:
    assert sha((retained / item['artifact']).read_bytes()) == item['sha256']
exact = p / 'linux-source166-exact-roots-artifacts/ordinary-linux-ab59bb99ba223682e432f3936bda5dd8879c9606/rust-exact-roots'
diagnosis = json.loads((exact / 'summary.json').read_text())
assert diagnosis['source_unchanged'] and diagnosis['binary_unchanged'] and diagnosis['source_matches_original']
assert diagnosis['plain']['exit_code'] == diagnosis['debugger']['exit_code'] == 101
original = exact / 'original/ordinary-linux-eca7b36e936f636842f022004add273e8384f0cc/rust-replay'
assert sha((original / 'libtest').read_bytes()) == diagnosis['binary_sha256']
events = json.loads((exact / 'trace-events.json').read_text())
assert len(events) == diagnosis['trace_events'] == 17
key = next(event['key'] for event in events if event['event'] == 'weak insertion')
assert [event['epoch'] for event in events if event.get('key') == key and event.get('marked')] == [2, 3, 4, 5]
assert (exact / 'debugger.log').read_text().count('0x00005644d2e9ed74') >= 4

out = root / 'docs/handover/2026-09-30-gc-retention-diagnosis'
out.mkdir(exist_ok=False)
suffixes = {'.json', '.log', '.txt', '.stdout', '.stderr', '.py', '.patch', '.el', '.expected'}
files = {}
for directory in ['full-gate-source170', 'linux-source166-exact-roots-artifacts', 'linux-source166-root-trace3-artifacts']:
    for f in (p / directory).rglob('*'):
        if f.is_file() and f.suffix in suffixes:
            files[str(f.relative_to(p))] = f
for f in p.iterdir():
    if f.is_file() and f.suffix in suffixes and (
        f.name.startswith(('source170-full-gate', 'source166-exact-', 'source170-input-replay-', 'source170-peer-report-'))
        or f.name in ['package-source170-gate-failure.py', 'source170-manifest.json',
                      'source170-base.json', 'source170.patch', 'source170-input-probe-invocation-error.json',
                      'input-decode-general.el', 'input-decode-extra.el',
                      'run-source170-full-gate.py']
    ):
        files[f.name] = f
inventory = []
with (out / 'receipts.tar.gz').open('xb') as stream:
    with gzip.GzipFile(fileobj=stream, mode='wb', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w') as archive:
            for name, f in sorted(files.items()):
                data = f.read_bytes()
                info = tarfile.TarInfo(name)
                info.mode = 0o644
                info.size = len(data)
                archive.addfile(info, io.BytesIO(data))
                inventory.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
with tarfile.open(out / 'receipts.tar.gz', 'r:gz') as archive:
    assert archive.getnames() == [item['path'] for item in inventory]
    for item in inventory:
        data = archive.extractfile(item['path']).read()
        assert sha(data) == item['sha256'] and len(data) == item['bytes']
data = (out / 'receipts.tar.gz').read_bytes()
record = {
    'status': 'source170 macOS full Rust gate failed; original source166 Linux failure reproduced under GDB',
    'source170_revision': '3d45f96ffba413e1bdf2e41e05d34716de2b726f',
    'macos_passed': sum(totals), 'macos_failed': 1,
    'unexecuted': ['compat_runtime', 'tty', 'batch', 'lightweight', 'binary Cargo stage', 'integration Cargo stage'],
    'original_linux_diagnosis_run': 36666863766,
    'original_linux_binary_sha256': diagnosis['binary_sha256'],
    'finding': 'The first weak key is marked at epochs 2 through 5 from the native_roots loop in weak_hash_reachability. The root array combines native relocation/handler/parked roots and a native stack scan; this trace does not yet identify the owning input.',
    'qualification': 'No failure cleared. Hardware watchpoints preserve the original executable and assertion but alter timing. The instrumented trace3 pass uses another binary. Source170 full Linux and terminal runs are still pending at this checkpoint. General input decoding and TLS peer-report alias probes are negative evidence, not passing comparisons. No performance claim.',
    'archive': {'path': 'receipts.tar.gz', 'bytes': len(data), 'sha256': sha(data)},
    'files': inventory,
}
(out / 'manifest.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: value for key, value in record.items() if key != 'files'}, indent=2))
