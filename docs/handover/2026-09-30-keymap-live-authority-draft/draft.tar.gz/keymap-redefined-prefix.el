(let ((saved (current-global-map))
      (map (make-sparse-keymap))
      (prefix (make-sparse-keymap))
      calls)
  (unwind-protect
      (progn
        (use-global-map map)
        (define-key map [24] (lambda () (interactive) (push 'rebound-x calls)))
        (define-key prefix [97] (lambda () (interactive) (push 'custom-prefix calls)))
        (define-key map [17] prefix)
        (execute-kbd-macro [24])
        (execute-kbd-macro [17 97])
        (nreverse calls))
    (use-global-map saved)))
