(progn
  (require 'org)
  (with-temp-buffer
    (org-mode)
    (let ((bar (lookup-key (current-local-map) [menu-bar])))
      (list major-mode
            (eq (current-local-map) org-mode-map)
            (keymapp bar)
            (mapcar (lambda (entry) (if (consp entry) (car entry) entry))
                    (cdr bar))
            (mapcar
             (lambda (event)
               (let ((definition (lookup-key org-mode-map (vector 'menu-bar event))))
                 (list event (keymapp definition) (car-safe definition))))
             '(Org Table org table))))))
