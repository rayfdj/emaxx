(let ((map (make-sparse-keymap))
      (prefix (make-sparse-keymap))
      (keys (vector 'prefix 'first))
      (calls 0))
  (define-key prefix [first] 'first-command)
  (define-key prefix [second] 'second-command)
  (define-key map [prefix]
    (list 'menu-item "Prefix" prefix
          :filter (lambda (definition)
                    (setq calls (1+ calls))
                    (aset keys 1 'second)
                    (garbage-collect)
                    definition)))
  (list (lookup-key map keys) (aref keys 1) calls))
