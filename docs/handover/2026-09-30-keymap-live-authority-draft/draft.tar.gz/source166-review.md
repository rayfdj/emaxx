# Focused source166 review (not the final goal audit)

The portable patch replays all 339 compiled/test inputs from published d9caac1e.
The source166 manifest is the authority for these inputs; the isolated full
macOS gate runs the same files on local commit ecb35bb1. Final validation results
must be read separately; this note does not certify an active run.

GNU references are from 636f166cfc86aa90d63f592fd99f3fdd9ef95ebd:

- keymap.c:lookup_key_1 reads Faref immediately before each map access. Source163
  stopped normalizing/copying the entire input up front. Vector slots, mutable
  string characters, current unibyte Meta interpretation, Lucid events and
  positioned symbols are read when reached. Original and translated arrays
  retain their existing type and empty-sequence checks.
- keymap.c:Fkey_binding uses one Flookup_key on current-active-maps. Source165
  removes the separate immutable map search, runs prefix/leaf menu filters,
  preserves swallowed ordinary errors versus quit/throw, and reacquires active
  maps for command remapping after callbacks. Internal command readers use the
  same primitive path. The caller's actual key and derived position, temporary
  map list, current composed map, current event and pending command are rooted
  through callbacks.
- keyboard.c:read_key_sequence continues according to the binding. Source166
  removes the hardcoded C-c/C-x/ESC prefix shortcut and the redundant lookup
  used to classify a command. A rebound C-x now executes; a collecting leaf
  filter runs once. Three command-loop paths reuse their resolved binding.
- keyboard.c:menu_bar_items and keymap.c:map_keymap_canonical use unchanged
  subr.el:keymap-canonicalize. The source161 repair is integrated into the
  draft; ordinary Org rendering is retained rather than replacing the Lisp
  owner with another formatter.

The new controls execute identical Lisp in GNU and Emaxx. Retained main source139
reproduces the callback and macro-dispatch failures. Source163's 20 matching
ordinary comparisons and three remaining mismatches, source164's compile error,
and source165's 22 matches and three remaining macro mismatches stay preserved.
The source164 compiler rejected a triple root tuple; source165 uses the existing
nested-pair root implementation. No assertion, selector, timeout or expected
failure was weakened. New command-loop coverage is disjoint from the broader
selected test list, in both debug and release modes.

Remaining limits are explicit: the private record/keymap payload, reverse
indexes, snapshot synchronization, binding cache and permanent keymap roots are
removed, but temporary compound-event/enumeration adapters and older bounded
lookup paths remain in input decoding and signal handling. Input decoding still
has separate protocol paths and a bounded prefix scan requiring further audit.
Symbol value/function/property ownership, physical allocation accounting,
complete final-source validation and locked performance parity remain open.
Darwin GNU is source/ABI matched, not the pinned executable. This review makes no
performance claim and is not the full-source adversarial audit required to close
the goal.
