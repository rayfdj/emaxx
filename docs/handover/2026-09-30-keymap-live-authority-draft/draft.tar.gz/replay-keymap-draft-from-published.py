from pathlib import Path
import hashlib,io,json,subprocess,sys,tarfile,tempfile
p=Path(__file__).parent;tag=sys.argv[1];root=Path(sys.argv[2]);base=sys.argv[3]
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
m=json.loads((p/(tag+'-manifest.json')).read_text())
assert all(sha(root/n)==h for n,h in m.items())
base=subprocess.check_output(['git','rev-parse',base],cwd=root,text=True).strip()
patch=subprocess.check_output(['git','diff','--binary',base,'--','src','tests','Cargo.toml','Cargo.lock','build.rs','.cargo'],cwd=root)
for name in subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=root).decode().split('\0'):
    if name not in m:continue
    r=subprocess.run(['git','diff','--no-index','--binary','/dev/null',name],cwd=root,stdout=subprocess.PIPE)
    assert r.returncode==1;patch+=r.stdout
path=p/(tag+'-from-published.patch')
if path.exists():
    assert path.read_bytes()==patch
else:
    with path.open('xb') as f:f.write(patch)
replay=Path(tempfile.mkdtemp(prefix='emaxx-'+tag+'-portable-',dir='/private/tmp'))
archive=subprocess.check_output(['git','archive',base],cwd=root)
with tarfile.open(fileobj=io.BytesIO(archive)) as t:
    for member in t.getmembers():
        target=(replay/member.name).resolve()
        assert target==replay or replay in target.parents
        if member.issym() or member.islnk():
            link=(target.parent/member.linkname).resolve()
            assert link==replay or replay in link.parents
    t.extractall(replay)
subprocess.run(['git','apply',str(path)],cwd=replay,check=True)
assert all(sha(replay/n)==h for n,h in m.items())
assert all(sha(root/n)==h for n,h in m.items())
result={'base':base,'portable_patch':path.name,'patch_sha256':sha(path),'replay_directory':str(replay),'verified_inputs':len(m),'source_manifest':tag+'-manifest.json','qualification':'Portable source/input replay only; executed validation must be read separately.'}
with (p/(tag+'-portable-replay.json')).open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result,indent=2))
