from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).parent
root = p.parents[2]
sha = lambda data: hashlib.sha256(data).hexdigest()
for mode in ['debug', 'release']:
    result = json.loads((p / f'source166-{mode}-selected-inventory-check.json').read_text())
    assert result['expected'] == 393 and result['process_exit_code'] == 0
    assert result['summary'] == 'test result: ok. 393 passed; 0 failed; 0 ignored;'
    extra = json.loads((p / f'source166-{mode}-command-loops-result.json').read_text())
    assert extra['exit_code'] == 0 and extra['source_unchanged'] and extra['binary_unchanged']
    assert extra['expected'] == 69 and extra['summary'] == 'test result: ok. 69 passed; 0 failed; 0 ignored;'
for stage in ['check', 'fmt', 'clippy', 'diff', 'ordinary-build', 'ordinary-image']:
    result = json.loads((p / f'source166-{stage}-result.json').read_text())
    assert result['exit_code'] == 0 and result['source_unchanged']
for tag, total, passed in [('source163', 23, 20), ('source165', 25, 22), ('source166', 25, 25)]:
    comparisons = [json.loads(f.read_text()) for f in p.glob(f'{tag}-ordinary-*-comparison.json')]
    assert len(comparisons) == total and sum(c['passed'] for c in comparisons) == passed
replay = json.loads((p / 'source166-portable-replay.json').read_text())
assert replay['verified_inputs'] == 339
assert sha((p / replay['portable_patch']).read_bytes()) == replay['patch_sha256']
selected = {}
suffixes = {'.json', '.log', '.txt', '.stdout', '.stderr', '.el', '.expected', '.py', '.patch', '.md'}
prefixes = ('source163', 'source164', 'source165', 'source166',
            'source139-retained-key-binding', 'source139-retained-retry-',
            'source161-ordinary-key-binding', 'source161-ordinary-keymap-rebound',
            'source161-ordinary-keymap-redefined', 'source161-ordinary-keymap-dispatch',
            'keymap-dispatch-prefix-observation')
names = {'compare-continuation-fixtures.py', 'package-keymap-authority166.py',
         'replay-retained-keymap-negative.py', 'replay-retained-keymap-negative-env.py',
         'replay-keymap-draft-from-published.py', 'replay-keymap-draft-from-published-first.py',
         'test-keymap-command-loops.py', 'queue-keymap-command-loop-checks.py',
         'queue-source166-ordinary-comparisons.py', 'run-source166-full-gate.py',
         'replay-org-terminal.py'}
for f in p.iterdir():
    if not f.is_file() or f.suffix not in suffixes:
        continue
    include = f.name.startswith(prefixes) or f.name in names
    include |= f.suffix == '.py' and 'keymap-authority' in f.name
    include |= f.suffix in {'.el', '.expected'} and f.name.startswith(('keymap-', 'key-binding-'))
    if include and not f.name.startswith('source166-full-gate'):
        selected[f.name] = f
out = root / 'docs/handover/2026-09-30-keymap-live-authority-draft'
out.mkdir(exist_ok=False)
files = []
with (out / 'draft.tar.gz').open('xb') as stream:
    with gzip.GzipFile(fileobj=stream, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, f in sorted(selected.items()):
                data = f.read_bytes()
                info = tarfile.TarInfo(name)
                info.mode = 0o644
                info.size = len(data)
                archive.addfile(info, io.BytesIO(data))
                files.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
with tarfile.open(out / 'draft.tar.gz', 'r:gz') as archive:
    assert archive.getnames() == [f['path'] for f in files]
    for f in files:
        data = archive.extractfile(f['path']).read()
        assert len(data) == f['bytes'] and sha(data) == f['sha256']
data = (out / 'draft.tar.gz').read_bytes()
record = {
    'status': 'UNFINISHED_DRAFT_NOT_PRODUCTION',
    'published_base': replay['base'],
    'portable_patch': replay['portable_patch'],
    'source_manifest': 'source166-manifest.json',
    'replay_verified_inputs': 339,
    'scope': 'Actual cons/char-table keymaps remove private keymap records, reverse indexes, mutation snapshots, binding caches and permanent roots. Integrates the source161 menu repair. Lookup reads the live input at each event; key-binding and command-remapping use the actual lookup path and collecting menu filters; command readers classify the resolved binding instead of hardcoded C-x/C-c/ESC prefixes or a repeated lookup.',
    'validation': 'Strict checks, 393 selected plus 69 disjoint command-loop tests in each of debug and release (462 each), and all 25 ordinary exact GNU comparisons pass. The anonymous-map fixture reports zero after its creator returns, live-input mutation is visible, native pair/tail sharing and restored-image sharing are covered. Source163 also passes the unchanged org-open terminal scenario. Source166 complete macOS Rust is active and excluded; no complete Linux/frozen/terminal certification for this draft.',
    'failures_preserved': 'Source163: 391 selected debug and release passes, 20 of 23 ordinary comparisons match; key-binding callbacks and macro dispatch still differ. Source164: compiler E0277 rejects a triple root tuple; no tests execute. Source165: 392 selected plus 69 additional passes per mode, 22 of 25 ordinary comparisons match; three macro dispatch cases still differ. Source166 repairs those causes. Retained source139 reproduces callback and macro failures; the initial replay environment setup failure is distinct from the corrected successful negative controls. The first portable replay script fails on a Python 3.9 API mismatch; corrected path-checked replay verifies the unchanged patch.',
    'history': 'The source162 draft and its earlier failures remain in ../2026-09-30-keymap-authority-draft. This patch supersedes that entry point and includes the production source161 menu repair. Source163/165 incremental patches have local bases; use source166-from-published.patch for portable replay.',
    'lineage_qualification': 'Some inherited driver command descriptions mention the older source155 integration. The source166 manifest and replay proof establish the actual combined source161/163/165/166 inputs; those older prose descriptions are not the lineage authority.',
    'qualification': 'Temporary compound-event/enumeration adapters and bounded input-decoding/signal paths remain. Symbol authority, physical allocation accounting, final adversarial audit, complete final-source validation and locked performance parity remain open. Darwin GNU is source/ABI matched, not the frozen executable. No performance gain is claimed.',
    'archive': {'path': 'draft.tar.gz', 'bytes': len(data), 'sha256': sha(data)},
    'files': files,
}
(out / 'manifest.json').write_text(json.dumps(record, indent=2) + '\n')
print('Verified', len(files), 'draft receipts;', len(data), 'archive bytes')
