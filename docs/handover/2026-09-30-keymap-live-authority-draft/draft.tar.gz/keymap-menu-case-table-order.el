(let* ((map (make-sparse-keymap))
       (name (intern (string-make-multibyte "Qux-Casetable-Probe")))
       (key (vector 'menu-bar name))
       (saved-registry char-code-property-alist)
       result)
  (define-key map [menu-bar qux-casetable-probe] 'unicode-first)
  (define-key map [menu-bar zux-casetable-probe] 'local-second)
  (with-case-table (copy-case-table (current-case-table))
    (aset (current-case-table) ?Q ?z)
    (setq result (list (multibyte-string-p (symbol-name name))
                       (lookup-key map key)))
    (define-key map [menu-bar qux-casetable-probe] nil)
    (setq result (append result (list (lookup-key map key))))
    (define-key map [menu-bar qux-casetable-probe] 'unicode-restored)
    (unwind-protect
        (progn
          (setq char-code-property-alist
                (assq-delete-all 'lowercase
                                 (copy-sequence char-code-property-alist)))
          (garbage-collect)
          (setq result (append result (list (lookup-key map key)))))
      (setq char-code-property-alist saved-registry)))
  result)
