from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).parent
root = p.parents[2]
sha = lambda data: hashlib.sha256(data).hexdigest()
for mode in ['debug', 'release']:
    result = json.loads((p / f'source162-{mode}-selected-inventory-check.json').read_text())
    assert result['expected'] == 386 and result['process_exit_code'] == 0
    assert result['summary'] == 'test result: ok. 386 passed; 0 failed; 0 ignored;'
for stage in ['check', 'fmt', 'clippy', 'diff', 'ordinary-build', 'ordinary-image']:
    result = json.loads((p / f'source162-{stage}-result.json').read_text())
    assert result['exit_code'] == 0 and result['source_unchanged']
comparisons = [json.loads(f.read_text()) for f in p.glob('source162-ordinary-*-comparison.json')]
assert len(comparisons) == 19 and sum(c['passed'] for c in comparisons) == 18
assert not json.loads((p / 'source162-ordinary-keymap-live-input-comparison.json').read_text())['passed']
replay = json.loads((p / 'source162-portable-replay.json').read_text())
assert replay['verified_inputs'] == 333
selected = {}
suffixes = {'.json', '.log', '.txt', '.stdout', '.stderr', '.el', '.expected', '.py', '.patch'}
prefixes = tuple('source' + str(n) for n in [156, 157, 158, 160, 162]) + (
    'source139-retained-keymap-live-input', 'source161-ordinary-keymap-live-input')
names = {'check-keymap-authority.py', 'static-keymap-authority.py',
         'test-keymap-authority.py', 'test-keymap-authority-focused.py',
         'release-keymap-authority.py', 'build-keymap-authority.py',
         'compare-continuation-fixtures.py', 'package-keymap-authority162.py',
         'keymap-live-input.el'}
for f in p.iterdir():
    if f.is_file() and f.suffix in suffixes and (f.name.startswith(prefixes) or f.name in names):
        selected[f.name] = f
out = root / 'docs/handover/2026-09-30-keymap-authority-draft'
out.mkdir(exist_ok=False)
files = []
with (out / 'draft.tar.gz').open('xb') as stream:
    with gzip.GzipFile(fileobj=stream, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, f in sorted(selected.items()):
                data = f.read_bytes()
                info = tarfile.TarInfo(name)
                info.mode = 0o644
                info.size = len(data)
                archive.addfile(info, io.BytesIO(data))
                files.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
with tarfile.open(out / 'draft.tar.gz', 'r:gz') as archive:
    assert archive.getnames() == [f['path'] for f in files]
    for f in files:
        data = archive.extractfile(f['path']).read()
        assert len(data) == f['bytes'] and sha(data) == f['sha256']
data = (out / 'draft.tar.gz').read_bytes()
record = {
    'status': 'UNFINISHED_DRAFT_NOT_PRODUCTION',
    'published_base': replay['base'],
    'portable_patch': 'source162-from-published.patch',
    'source_manifest': 'source162-manifest.json',
    'replay_verified_inputs': 333,
    'scope': 'Actual cons/char-table keymaps replace private record facades, reverse indexes, mutation snapshots, retained binding cache and process-lifetime roots. Image restoration installs the actual dumped symbol cells before the added live/shared-map probe. Symbol stores resolve aliases and collecting keymap autoloads, and initial key sequences receive GNU type checks.',
    'validation': 'Strict static checks, 386 debug and 386 release controls, and 18 ordinary exact GNU comparisons pass. Reachable maps survive, anonymous maps are reclaimed after creator return, native stores share actual pairs/tails, and image sharing survives collection. No full gate, terminal or frozen certification for this draft.',
    'failures_preserved': 'Source156: Clippy failure and 248 debug passes/one image-probe failure. Source157: strict checks pass, 248 debug passes/one image-probe failure. Source158: 250 debug passes, then 382 release passes/three symbol-map store failures. Source160 does not compile because it names a private helper. Source162 corrects these causes; original failures remain.',
    'remaining_negative': 'A nineteenth ordinary probe mutates a later input-vector event in a collecting prefix filter. GNU returns second-command; source162, source161 and retained main source139 return first-command. All report the same mutated vector and one callback. This existing eager-input-copy mismatch is still open in this packaged draft.',
    'integration_limit': 'Source162 includes the source155 parser/native test repairs, but predates the source161 composed-menu rendering repair. Integrate that repair before using this draft as the next production candidate. Local source162.patch is relative to an unpublished local integration; use source162-from-published.patch for portable replay.',
    'qualification': 'Remaining temporary event/enumeration allocations, physical allocation accounting, symbol authority, final audit, complete Linux/macOS/frozen/terminal validation and locked performance parity remain open. Darwin GNU is source/ABI matched, not the frozen executable. No performance gain is established.',
    'archive': {'path': 'draft.tar.gz', 'bytes': len(data), 'sha256': sha(data)},
    'files': files,
}
(out / 'manifest.json').write_text(json.dumps(record, indent=2) + '\n')
print('Verified', len(files), 'draft receipts;', len(data), 'archive bytes')
