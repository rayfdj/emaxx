from pathlib import Path
import hashlib,json,os,subprocess,sys,time
p=Path(__file__).parent;name=sys.argv[1];binary=Path('/private/tmp/emaxx-runtime-audit-validation/release/retained-source139');image=binary.with_suffix('.pdmp')
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
identities={str(binary):sha(binary),str(image):sha(image)}
assert identities[str(binary)]=='116daa002f5aad88f1f504189621e6ed6f2a71f77772f73aa1ce9c1082d1cfd4'
assert identities[str(image)]=='e39775af79e3142624251219fcd11673918f50e647fbf2b8f918735e0273132b'
f=p/(name+'.el');command=[str(binary),'-Q','--batch','--eval','(prin1 '+f.read_text()+')']
env={'EMAXX_GC_VERIFY':'1'}
base=p/('source139-retained-retry-'+name)
with Path(str(base)+'.command.json').open('x') as out:json.dump({'command':command,'cwd':str(p),'environment_override':env,'inputs':identities,'fixture_sha256':sha(f)},out,indent=2)
start=time.monotonic();r=subprocess.run(command,cwd=p,env={**os.environ,**env},capture_output=True,timeout=120)
for suffix,data in [('.stdout',r.stdout),('.stderr',r.stderr)]:
    with Path(str(base)+suffix).open('xb') as out:out.write(data)
result={'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'inputs_unchanged':all(sha(Path(n))==h for n,h in identities.items()),'same_as_current_negative':r.stdout==(p/f'source161-ordinary-{name}-emaxx.stdout').read_bytes(),'matches_gnu':r.stdout==(p/f'source161-ordinary-{name}-gnu.stdout').read_bytes()}
with Path(str(base)+'.result.json').open('x') as out:json.dump(result,out,indent=2)
print(name,result)
assert r.returncode==0 and not r.stderr and result['inputs_unchanged']
