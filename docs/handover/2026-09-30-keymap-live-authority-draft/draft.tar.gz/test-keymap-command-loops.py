from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time
p=Path(__file__).parent;tag=sys.argv[1];mode=sys.argv[2];root=Path(sys.argv[3])
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
m=json.loads((p/(tag+'-manifest.json')).read_text())
def unchanged():return all(sha(root/name)==h for name,h in m.items())
assert unchanged()
original=json.loads((p/f'{tag}-{mode}-selected-command.json').read_text())
already=set(original['selected_inventory']);binary=p/f'{tag}-{mode}-libtest'
assert sha(binary)==original['binary_sha256']
inv=[line[:-6] for line in (p/f'{tag}-{mode}-inventory.txt').read_text().splitlines() if line.endswith(': test')]
filters=['kbd_macro','keyboard_macro','minibuffer','command_loop','read_key','user_signal','signal_events','input_decode','xterm_mouse','unread','command_remapping']
selected=[name for name in inv if name not in already and any(part in name for part in filters)]
assert selected and len(selected)==len(set(selected))
command=[str(binary),*selected,'--exact','--nocapture','--test-threads=1']
record={'command':command,'working_directory':str(root),'environment_override':original['environment_override'],'selected_inventory':selected,'binary_sha256':sha(binary),'purpose':'Additional disjoint command-loop, macro, minibuffer, remapping and input controls affected by key-binding changes; no selector or assertion removed.'}
def save(suffix,item):
    with (p/f'{tag}-{mode}-command-loops-{suffix}.json').open('x') as f:json.dump(item,f,indent=2);f.write('\n')
save('command',record);start=time.monotonic()
with (p/f'{tag}-{mode}-command-loops.log').open('x') as log:
    r=subprocess.run(command,cwd=root,env={**os.environ,**record['environment_override']},stdout=log,stderr=subprocess.STDOUT,timeout=3600)
raw=(p/f'{tag}-{mode}-command-loops.log').read_text();match=re.search(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',raw)
result={'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'source_unchanged':unchanged(),'binary_unchanged':sha(binary)==record['binary_sha256'],'expected':len(selected),'summary':match.group(0) if match else None}
save('result',result);print(json.dumps(result),flush=True)
if r.returncode:print(raw[-7000:]);sys.exit(r.returncode)
assert result['source_unchanged'] and result['binary_unchanged'] and match and match[1]=='ok' and int(match[2])==len(selected) and int(match[3])==int(match[4])==0
