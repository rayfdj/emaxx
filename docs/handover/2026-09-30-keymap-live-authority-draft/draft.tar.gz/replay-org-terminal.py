from pathlib import Path
import contextlib
import hashlib
import json
import os
import runpy
import sys
import time

p = Path(__file__).parent
root = p.parents[2]
tag, binary_text, *labels = sys.argv[1:]
label = labels[0] if labels else tag
binary = Path(binary_text)
gnu = Path('/private/tmp/emaxx-runtime-gnu-20260928/src/emacs')
lisp = gnu.parent.parent / 'lisp'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
artifact = json.loads((p / (tag + '-ordinary-artifacts.json')).read_text())
for candidate in [binary, binary.with_suffix('.pdmp')]:
    assert sha(candidate) in [item['sha256'] for item in artifact.values()]
inputs = {str(f): sha(f) for f in [binary, binary.with_suffix('.pdmp'), gnu,
                                 gnu.with_suffix('.pdmp'), root / 'tools/ttydiff.py']}
module = runpy.run_path(str(root / 'tools/ttydiff.py'), run_name='inventory_only')
name, contents, keys, suffix = module['select_scenarios'](['org-open'])[0]
home = p / (label + '-org-terminal-home')
home.mkdir(exist_ok=False)
env = {'HOME': str(home)}
load_path = os.pathsep.join([str(lisp)] + sorted(str(f) for f in lisp.iterdir() if f.is_dir()))
(gnu_path, emaxx_path), targets = module['create_scenario_target_pair'](name, contents, suffix)
args = dict(scenario=name, keys=keys,
            gnu_argv=[str(gnu), '-nw', '-Q', '--eval', module['gnu_no_window_setup'](str(lisp)), gnu_path],
            emaxx_argv=[str(binary), emaxx_path],
            gnu_env=env, emaxx_env={**env, 'EMACSLOADPATH': load_path},
            boot_wait=module['STARTUP_WAIT_SECONDS'])
with (p / (label + '-org-terminal-command.json')).open('x') as f:
    json.dump({'inputs': inputs, 'gnu_argv': args['gnu_argv'], 'emaxx_argv': args['emaxx_argv'],
               'environment': env, 'scenario': name, 'actions': [key.hex() for key in keys],
               'qualification': 'Unchanged built-in scenario, comparator, readiness and settle timings. Direct compare entry avoids initializing unrelated shared fixture paths while the full run is active. Source/ABI-matched GNU, not frozen Darwin.'}, f, indent=2)
start = time.monotonic()
passed = False
failure = None
try:
    with (p / (label + '-org-terminal.log')).open('x') as log, contextlib.redirect_stdout(log):
        passed = module['compare'](**args)
except Exception as error:
    failure = repr(error)
finally:
    for target in targets:
        module['remove_scenario_target'](target)
record = {'passed': passed, 'elapsed_seconds': time.monotonic() - start,
          'failure': failure,
          'inputs_unchanged': all(sha(Path(f)) == value for f, value in inputs.items())}
with (p / (label + '-org-terminal-result.json')).open('x') as f:
    json.dump(record, f, indent=2)
print(tag, record, flush=True)
raise SystemExit(0 if passed and record['inputs_unchanged'] else 1)
