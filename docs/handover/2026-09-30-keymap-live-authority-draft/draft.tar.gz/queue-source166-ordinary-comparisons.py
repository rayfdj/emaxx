from pathlib import Path
import json,subprocess,time
p=Path(__file__).parent.resolve();tag='source166';root='/private/tmp/emaxx-runtime-frames-gsnnjxa_/emaxx'
result=p/(tag+'-release-command-loops-result.json')
while not result.exists():
    failure=p/(tag+'-debug-command-loops-result.json')
    if failure.exists() and json.loads(failure.read_text())['exit_code']:
        raise SystemExit('Additional debug controls failed; ordinary checks await review')
    time.sleep(5)
assert json.loads(result.read_text())['exit_code']==0
names='keymap-parameterized-char-table keymap-prefix-filter-count keymap-filter-effects keymap-prefix-precedence keymap-lookup-argument-order keymap-filter-error-unbound keymap-translated-sequence-validation unwind-protected-payloads unwind-native-payloads unwind-payload-reclamation keymap-description-context keymap-menu-fallback keymap-menu-case-table-order string-make-multibyte-identity keymap-org-menu keymap-anonymous-reclamation keymap-sequence-types keymap-symbol-stores keymap-live-input keymap-live-sequence key-binding-live-prefix key-binding-filter-semantics keymap-rebound-prefix-commands keymap-redefined-prefix keymap-dispatch-live-bindings'.split()
r=subprocess.run(['python3',str(p/'compare-continuation-fixtures.py'),tag,root,*names])
raise SystemExit(r.returncode)
