from pathlib import Path
root=Path('/private/tmp/emaxx-runtime-frames-gsnnjxa_/emaxx')
p=root/'src/lisp/primitives/values.rs'
s=p.read_text()
def cut(a,b,new=''):
 global s
 i=s.index(a); j=s.index(b,i); s=s[:i]+new+s[j:]
cut('pub(crate) fn keymap_records_equal(', 'fn char_tables_equal(')
cut('pub(crate) fn keymap_record_equals_list(', 'pub(crate) fn record_equals_record_literal_form(')
cut('        (Kind::Record(left_id), Kind::Record(right_id))\n            if interp', '        (Kind::Record(left_id), Kind::Record(right_id)) => {')
cut('        crate::lisp::eval::RecordKind::Keymap => {', '        crate::lisp::eval::RecordKind::Closure')
s=s.replace('        | crate::lisp::eval::RecordKind::Keymap', '')
s=s.replace('    if let Some(items) = keymap_record_list_items(interp, value)? {\n        return Ok(items.len() as i64);\n    }\n','')
cut('pub(crate) const KEYMAP_RECORD_TYPE:', 'pub(crate) fn keymap_char_table_value(', '''// keymap.c:Fmake_sparse_keymap/Fmake_keymap: the Lisp list owns every
// binding. There is no private record, reverse index or public projection.
pub(crate) fn make_runtime_keymap(_interp: &mut Interpreter, prompt: Value) -> Value {
    let tail = if prompt.is_nil() { Value::Nil } else { Value::list([prompt]) };
    Value::cons(Value::symbol("keymap"), tail)
}

pub(crate) fn make_runtime_full_keymap(interp: &mut Interpreter, prompt: Value) -> Value {
    let table = interp.make_char_table(Some("keymap".into()), Value::Nil);
    let tail = if prompt.is_nil() { Value::Nil } else { Value::list([prompt]) };
    Value::cons(Value::symbol("keymap"), Value::cons(table, tail))
}

pub(crate) fn is_keymap_placeholder(value: &Value) -> bool {
    value.cons_values().is_some_and(|(head, _)| head.eq_value(Value::symbol("keymap")))
}

pub(crate) fn is_keymap_value(_interp: &Interpreter, value: &Value) -> bool {
    is_keymap_placeholder(value)
}

/// The first character table in this map's own list, before its parent.
''')
s=s.replace('    let view = runtime_keymap_public_view(interp, keymap).unwrap_or(*keymap);', '    let view = *keymap;')
s=s.replace('pub(crate) fn keymap_char_table_value(interp: &Interpreter,', 'pub(crate) fn keymap_char_table_value(_interp: &Interpreter,')
cut('pub(crate) fn keymap_bindings(', 'fn runtime_keymap_binding_from_public_entry(', '''/// A temporary enumeration of this map's sparse bindings. Ordinary key
/// lookup and mutation read the actual cells; this is not retained or cached.
pub(crate) fn keymap_direct_bindings(
    interp: &Interpreter,
    keymap: &Value,
) -> Result<Vec<RuntimeKeymapBinding>, LispError> {
    if !is_keymap_value(interp, keymap) { return Ok(Vec::new()); }
    let (items, _) = keymap_public_view_own_items(keymap)?;
    let mut bindings = Vec::new();
    for entry in items {
        if is_keymap_value(interp, &entry) { continue; }
        if let Some(binding) = runtime_keymap_binding_from_public_entry(&entry)? {
            bindings.push(binding);
        }
    }
    Ok(bindings)
}

''')
s=s.replace('    after_prompt: bool,\n) -> Result<Option<RuntimeKeymapBinding>', ') -> Result<Option<RuntimeKeymapBinding>')
s=s.replace('        after_prompt,\n    }))', '    }))')
cut('/// Replace the public cdr of an identity-bearing runtime keymap.', "/// The child's own cells")
cut('fn parse_runtime_keymap_public_view(', 'pub(crate) fn keymap_parent_values(', '''/// keymap.c:keymap_parent follows the spine, not included submaps.
pub(crate) fn keymap_parent_value(interp: &Interpreter, map: Value, env: &Env) -> Value {
    let mut tail = map.cdr().unwrap_or(Value::Nil);
    let mut cycle = crate::lisp::types::CycleGuard::new();
    while let Kind::Cons(cell) = tail.kind() {
        if is_keymap_placeholder(&tail) { return tail; }
        if cycle.step(crate::lisp::types::ConsCell::identity(&cell)) { return Value::Nil; }
        tail = cell.cdr.get();
    }
    keymap_reference_map(interp, &tail, env).unwrap_or(Value::Nil)
}

pub(crate) fn set_keymap_parent_value(
    interp: &Interpreter, map: Value, parent: Value, env: &Env,
) -> Result<Value, LispError> {
    let mut ancestor = parent;
    let mut parents = HashSet::new();
    while !ancestor.is_nil() && parents.insert(ancestor.word()) {
        if ancestor.eq_value(map) { return Err(LispError::Signal("Cyclic keymap inheritance".into())); }
        ancestor = keymap_parent_value(interp, ancestor, env);
    }
    let mut previous = map;
    let mut seen = HashSet::new();
    loop {
        if !seen.insert(previous.word()) { return Err(LispError::Signal("Cyclic keymap inheritance".into())); }
        let tail = previous.cdr()?;
        if !tail.is_cons() || is_keymap_placeholder(&tail) {
            previous.set_cdr(parent)?;
            return Ok(parent);
        }
        previous = tail;
    }
}

''')
cut('pub(crate) fn keymap_value_identity(', "type KeymapEntryCallback", '''pub(crate) fn keymap_value_identity(_interp: &Interpreter, keymap: &Value) -> Option<usize> {
    is_keymap_placeholder(keymap).then_some(keymap.word())
}

''')
s=s.replace('    ensure_runtime_keymap_current(interp, &keymap)?;\n    let map = public_keymap_value(interp, &keymap);', '    let map = keymap;')
cut('pub(crate) fn keymap_define_character_range(', 'pub(crate) fn keymap_define_binding_with_placement(', '''/// keymap.c:store_in_keymap mutates the actual alist, vector or character
/// table in order and stops before the inherited tail. Included submaps are
/// updated in place because lookup may return a temporary composed map.
fn store_in_keymap(
    interp: &mut Interpreter, map: Value, event: Value, definition: Value,
    remove: bool, after_prompt: bool,
) -> Result<(), LispError> {
    if !is_keymap_placeholder(&map) {
        return Err(LispError::Signal("attempt to define a key in a non-keymap".into()));
    }
    let range = event.cons_values().and_then(|(start, end)| {
        match (start.kind(), end.kind()) {
            (Kind::Integer(start), Kind::Integer(end)) => Some((start as u32, end as u32)),
            _ => None,
        }
    });
    let mut insertion = map;
    let mut previous = map;
    let mut tail = map.cdr()?;
    let mut seen = HashSet::new();
    while let Some((entry, rest)) = tail.cons_values() {
        if !seen.insert(tail.word()) { break; }
        if entry.eq_value(Value::symbol("keymap")) { break; }
        match entry.kind() {
            Kind::Vector(vector) => {
                if let Kind::Integer(index) = event.kind()
                    && let Ok(index) = usize::try_from(index)
                    && index < vector.len() {
                    vector.set(index, definition);
                    return Ok(());
                }
                if let Some((start, end)) = range {
                    for index in (start as usize)..=(end as usize).min(vector.len().saturating_sub(1)) {
                        if index < vector.len() { vector.set(index, definition); }
                    }
                    if (end as usize) < vector.len() { return Ok(()); }
                }
                insertion = tail;
            }
            Kind::CharTable(table) => {
                let stored = if remove { Value::Nil } else if definition.is_nil() { Value::T } else { definition };
                if let Some((start, end)) = range {
                    interp.char_table_set_range(table, start, end, stored)?;
                    return Ok(());
                }
                if let Kind::Integer(code) = event.kind() && (0..=0x3f_ffff).contains(&code) {
                    interp.char_table_set(table, code as u32, stored)?;
                    return Ok(());
                }
                insertion = tail;
            }
            Kind::Cons(_) => {
                if is_keymap_placeholder(&entry) {
                    insertion = entry;
                    previous = entry;
                    tail = entry.cdr()?;
                    continue;
                }
                let key = entry.car()?;
                let exact = key.eq_value(event);
                let covered = range.is_some_and(|(start, end)| matches!(key.kind(), Kind::Integer(code) if (i64::from(start)..=i64::from(end)).contains(&code)));
                if exact || covered {
                    if remove { previous.set_cdr(rest)?; } else { entry.set_cdr(definition)?; }
                    if exact || range.is_some_and(|(start, end)| start == end) { return Ok(()); }
                    if remove { tail = rest; continue; }
                }
            }
            _ if after_prompt && string_like(&entry).is_some() => insertion = tail,
            _ => {}
        }
        previous = tail;
        tail = rest;
    }
    if !remove {
        let entry = if let Some((start, end)) = range {
            let table = interp.make_char_table(Some("keymap".into()), Value::Nil);
            let Kind::CharTable(table_ref) = table.kind() else { unreachable!() };
            interp.char_table_set_range(table_ref, start, end, if definition.is_nil() { Value::T } else { definition })?;
            table
        } else { Value::cons(event, definition) };
        insertion.set_cdr(Value::cons(entry, insertion.cdr()?))?;
    }
    Ok(())
}

pub(crate) fn keymap_define_character_range(
    interp: &mut Interpreter, keymap: &Value, start: i64, end: i64,
    binding: Value, remove: bool,
) -> Result<(), LispError> {
    if !(0..=0x3f_ffff).contains(&start) || !(0..=0x3f_ffff).contains(&end) {
        return Err(LispError::Signal("Invalid keymap character range".into()));
    }
    store_in_keymap(interp, *keymap, Value::cons(Value::Integer(start), Value::Integer(end)), binding, remove, false)
}

''')
s=s.replace('    ensure_runtime_keymap_current(interp, keymap)?;\n    if let Some(parts)', '    let _roots = crate::lisp::alloc::RootedVec::from_vec(vec![*keymap, binding]);\n    let key_parts = Some(key_parts.unwrap_or_else(|| approximate_key_parts(key)));\n    if let Some(parts)',1)
s=s.replace('make_runtime_keymap(interp, None)', 'make_runtime_keymap(interp, Value::Nil)')
cut('    // store_in_keymap returns after a character-table store.', 'pub(crate) fn keymap_remove_binding(', '''    let parts = key_parts.expect("decoded key parts");
    if parts.is_empty() { return Ok(()); }
    let event = keymap_entry_key_value(&parts, key);
    store_in_keymap(interp, *keymap, event, binding, false, after_prompt)
}

''')
cut('    ensure_runtime_keymap_current(interp, keymap)?;', 'pub(crate) fn approximate_key_parts(', '''    if parts.len() > 1 {
        let prefix = keymap_lookup_direct_binding_exact_parts(interp, keymap, &parts[..1])?;
        let prefix = keymap_get_keyelt(interp, &prefix, false, &mut Env::new())?;
        if is_keymap_value(interp, &prefix) { return keymap_remove_binding(interp, &prefix, &parts[1..]); }
        return Ok(());
    }
    if let [event] = parts { store_in_keymap(interp, *keymap, *event, Value::Nil, true, false)?; }
    Ok(())
}

''')
s=s.replace('    let map = public_keymap_value(interp, &map);\n','')
s=s.replace('roots[1] = public_keymap_value(interp, &parent);', 'roots[1] = parent;')
s=s.replace('keymap_record_id(interp, &other.value())', 'keymap_value_identity(interp, &other.value())')
s=s.replace('keymap_record_id(interp, &function)', 'keymap_value_identity(interp, &function)')
s=s.replace('keymap_record_id(interp, &value)', 'keymap_value_identity(interp, &value)')
s=s.replace('keymap_record_id(interp, &resolved)', 'keymap_value_identity(interp, &resolved)')
s=s.replace('target_keymap_id: Option<u64>', 'target_keymap_id: Option<usize>')
cut('/// The remap probe against already-assembled maps:', '// The keymaps consulted for command dispatch:', '''/// Read command remapping from the same actual maps as other bindings.
pub(crate) fn command_remapping_in_maps(
    interp: &Interpreter, command_name: &str, maps: &[Value],
) -> Result<Value, LispError> {
    let parts = [Value::symbol("remap"), Value::symbol(command_name)];
    for map in maps {
        let binding = keymap_lookup_binding_exact_parts(interp, map, &parts)?;
        if !binding.is_nil() { return Ok(binding); }
    }
    Ok(Value::Nil)
}

''')
p.write_text(s)
