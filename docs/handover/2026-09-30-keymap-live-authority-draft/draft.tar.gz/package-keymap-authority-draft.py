from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile,tempfile
p=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28');root=p.parents[2];sha=lambda data:hashlib.sha256(data).hexdigest()
manifest=json.loads((p/'source150-manifest.json').read_text());draft=Path('/private/tmp/emaxx-runtime-frames-gsnnjxa_/emaxx')
assert all(sha((draft/f).read_bytes())==h for f,h in manifest.items())
base='c2d328ab7046569a4e15d5c03825f3ae655636a0'
with tempfile.TemporaryDirectory(prefix='emaxx-draft150-replay-',dir='/private/tmp') as temp:
 data=subprocess.check_output(['git','archive','--format=tar',base],cwd=root)
 with tarfile.open(fileobj=io.BytesIO(data),mode='r:') as archive:archive.extractall(temp)
 subprocess.run(['git','apply',str(p/'source150.patch')],cwd=temp,check=True)
 assert all(sha((Path(temp)/f).read_bytes())==h for f,h in manifest.items())
out=root/'docs/handover/2026-09-29-keymap-authority-draft';out.mkdir(exist_ok=False)
selected={f.name:f for f in p.iterdir() if f.is_file() and f.name.startswith(('source149','source150')) and f.suffix in {'.json','.log','.patch'}}
for name in ['migrate-keymap-authority.py','migrate-keymap-consumers.py','migrate-keymap-tests.py','check-keymap-authority.py','keymap-anonymous-reclamation.el','keymap-authority-next-step.md','keymap-migration-reference-inventory.txt','package-keymap-authority-draft.py']:selected[name]=p/name
files=[]
with (out/'draft.tar.gz').open('xb') as stream:
 with gzip.GzipFile(fileobj=stream,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as archive:
   for name,f in sorted(selected.items()):
    data=f.read_bytes();info=tarfile.TarInfo(name);info.mode=0o644;info.size=len(data);archive.addfile(info,io.BytesIO(data));files.append({'path':name,'bytes':len(data),'sha256':sha(data)})
with tarfile.open(out/'draft.tar.gz','r:gz') as archive:
 assert archive.getnames()==[f['path'] for f in files]
 for f in files:
  data=archive.extractfile(f['path']).read();assert len(data)==f['bytes'] and sha(data)==f['sha256']
data=(out/'draft.tar.gz').read_bytes()
(out/'manifest.json').write_text(json.dumps({'status':'UNFINISHED_UNVALIDATED_DRAFT','source_manifest':'source150-manifest.json','local_base':json.loads((p/'source150-base.json').read_text())['commit'],'portable_base':base,'portable_replay':'git archive portable_base; git apply source150.patch; every source150 manifest input verified equal','scope':'Prototype removal of keymap facade records, owner indexes, snapshots, binding cache, GC process roots and image reconstruction; raw cons/table constructors and mutation, native and image sharing controls, anonymous live/reclamation fixture.','validation':'Source149 compilation fails;150 compiles with one unused-helper warning. No debug/release test run, ordinary comparison, full gate or performance validation. Do not treat as production or goal completion.','integration_limit':'Draft predates source153 Meta/textual lookup repair. Integrate that repair explicitly; never overwrite the newer production values.rs with this older draft. Nonallocating ordinary read paths, rooting and all semantics still require review.','archive':{'path':'draft.tar.gz','bytes':len(data),'sha256':sha(data)},'files':files},indent=2)+'\n')
print('Verified',len(files),'draft receipts and replay from',base,';',len(data),'bytes')
