from pathlib import Path
import json,subprocess,sys,time
p=Path(__file__).parent;tag=sys.argv[1];root=sys.argv[2]
result=p/(tag+'-ordinary-image-result.json')
while not result.exists():
    for mode in ['debug','release']:
        failure=p/(tag+'-'+mode+'-selected-result.json')
        if failure.exists() and json.loads(failure.read_text())['exit_code']:
            raise SystemExit('Selected validation failed; additional checks not started')
    time.sleep(5)
assert json.loads(result.read_text())['exit_code']==0
for mode in ['debug','release']:
    print('Starting',tag,mode,'additional command-loop controls',flush=True)
    subprocess.run(['python3',str(p/'test-keymap-command-loops.py'),tag,mode,root],check=True)
