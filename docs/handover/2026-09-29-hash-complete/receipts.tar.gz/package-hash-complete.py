from pathlib import Path
import gzip,hashlib,io,json,re,subprocess,tarfile
p=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28');root=p.parents[2]
out=root/'docs/handover/2026-09-29-hash-complete';sha=lambda data:hashlib.sha256(data).hexdigest()
manifest=json.loads((p/'source139-manifest.json').read_text())
assert all(sha((root/name).read_bytes())==digest for name,digest in manifest.items())
mac=json.loads((p/'source139-full-gate-result.json').read_text());assert mac['exit_code']==0 and mac['source_unchanged']
linux_path=next((p/'linux-75b69738-full-artifacts').rglob('rust/summary.json'));linux=json.loads(linux_path.read_text())
ci=json.loads((p/'linux-75b69738-full-status.json').read_text());assert ci['conclusion']=='success' and ci['headSha']=='75b6973897a17a42b01530916810ef4772de331f'
totals={};retained={}
for label,summary,directory in [('macOS',mac['summary'],p/'full-gate-source139'),('Linux',linux,linux_path.parent)]:
 assert summary['status']=='passed' and summary['scope']=='full' and not summary['git']['dirty']
 assert len(summary['runs'])==1
 groups=summary['runs'][0]['groups'];assert len(groups)==10
 assert all(g['exit_code']==0 and not g['timed_out'] and g['result']['status']=='ok' and g['result']['failed']==0 for g in groups)
 counts={k:sum(g['result'][k] for g in groups) for k in ['passed','failed','ignored']}
 assert sum(summary['inventory']['groups'].values())==counts['passed']+counts['ignored']==summary['inventory']['total_tests']==summary['inventory']['scheduled_tests']
 assert sorted(summary['inventory']['ignored_tests'])==['tty::tty_differential_end_to_end','tty::tty_smoke_end_to_end']
 assert [s['stage'] for s in summary['cargo_stages']]==['bins','integration']
 for stage in summary['cargo_stages']:
  assert stage['exit_code']==0
  actual=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (directory/(stage['stage']+'.log')).read_text())
  assert actual and all(int(f)==int(i)==0 for _,f,i in actual)
  counts[stage['stage']+'_passed']=sum(int(n) for n,_,_ in actual)
  assert counts[stage['stage']+'_passed']==sum(r['passed'] for r in stage['results'])
 record=json.loads((directory/'retained-inputs/manifest.json').read_text())
 assert record['status']=='retained' and record['gate_status']=='passed'
 assert record['gate_summary_sha256']==sha((directory/'summary.json').read_bytes())
 for f in record['files']:
  data=(directory/'retained-inputs'/f['artifact']).read_bytes();assert sha(data)==f['sha256'] and len(data)==f['bytes']
 assert next(f['sha256'] for f in record['files'] if f['artifact']=='libtest')==summary['test_binary']['sha256']
 retained[label]=record;totals[label]=counts
assert totals['macOS']=={'passed':2900,'failed':0,'ignored':2,'bins_passed':60,'integration_passed':39}
assert totals['Linux']=={'passed':2908,'failed':0,'ignored':2,'bins_passed':61,'integration_passed':42}
def save(name,data):
 with (p/name).open('x') as f:json.dump(data,f,indent=2);f.write('\n')
save('source139-complete-totals.json',totals)
save('source139-complete-source-identity.json',{'candidate':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'source_manifest':'source139-manifest.json','inputs':len(manifest),'all_inputs_match':True,'macOS_source':mac['summary']['git']['head'],'Linux_source':linux['git']['head'],'retained_artifacts_hash_verified':True})
save('source139-additional-diagnostic-limits.json',{'keymap_callback_error':'Original --eval input exits -11 on retained main119,139 and independent141; main119 valid lexical-closure variant executes successfully. LLDB lexical-file backtrace reaches emit_batch_error_message -> error-message-string -> symbol_property_index. Earlier multiline LLDB invocation failed its command parser; file without lexical-binding used a different execution mode and succeeded. Every attempt retained. Cause not yet repaired or fully established.','pending_error_payload':'Same original ordinary input succeeds in GNU. Emaxx139 exits -9 after46.84seconds with empty captured streams; reason for external kill is not established. The driver qualification mistakenly calls bytecode mode verified: this first probe requested byte-compile but did not separately assert byte-code-function-p. No verified-mode claim is made for it.','scope':'Additional diagnostics, not complete compatibility certification. Full performance and correctness goal remains open.'})
selected={};suffixes={'.json','.py','.el','.txt','.log','.stdout','.stderr','.patch'}
for f in p.iterdir():
 if not f.is_file() or f.suffix not in suffixes:continue
 include=f.name.startswith(('source139-full-gate','source139-complete','source139-additional','linux-75b69738-','source139-keymap-error-lldb','source139-ordinary-keymap-prefix-filter-count','source119-before142-ordinary-keymap-prefix-filter-count','source139-ordinary-unwind-error-payload'))
 include|=f.name in ['source139-manifest.json','run-source139-full-gate.py','package-hash-complete.py','keymap-prefix-filter-count.el','keymap-prefix-filter-count-v2.el','keymap-prefix-filter-count-printed.el','keymap-prefix-filter-count-lexical.el','unwind-error-payload.el','compare-source139-keymap-prefix-filter-count.py','compare-source119-keymap-prefix-filter-count.py','compare-source119-keymap-prefix-filter-count-v2.py','compare-unwind-error-payload.py','source119-ordinary-artifacts.json']
 if include:selected[f.name]=f
for folder in ['full-gate-source139','linux-75b69738-full-artifacts']:
 for f in (p/folder).rglob('*'):
  if f.is_file() and f.name!='libtest' and f.suffix not in {'.pdmp','.eln','.elc'}:selected[str(f.relative_to(p))]=f
out.mkdir(exist_ok=False);files=[]
with (out/'receipts.tar.gz').open('xb') as stream:
 with gzip.GzipFile(fileobj=stream,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as archive:
   for name,f in sorted(selected.items()):
    data=f.read_bytes();info=tarfile.TarInfo(name);info.mode=0o644;info.size=len(data);archive.addfile(info,io.BytesIO(data));files.append({'path':name,'bytes':len(data),'sha256':sha(data)})
with tarfile.open(out/'receipts.tar.gz','r:gz') as archive:
 assert archive.getnames()==[f['path'] for f in files]
 for f in files:
  data=archive.extractfile(f['path']).read();assert len(data)==f['bytes'] and sha(data)==f['sha256']
data=(out/'receipts.tar.gz').read_bytes()
record={'scope':'Complete unchanged source139 macOS and Linux Rust gates, exact retained executable/images and additional pre-existing callback/error-path diagnostics.','qualification':'macOS2999 and Linux3011 passes, two existing terminal ignores each. Full frozen comparisons, remaining architecture/ownership, complete physical accounting, final audit and performance parity remain open. Additional failures remain failures; no complete correctness certification.','binary_policy':'Large executable/images remain local or in linked CI artifacts; all downloaded and retained hashes verified. No portable-binary or frozen Darwin identity claim.','validation':totals,'archive':{'path':'receipts.tar.gz','bytes':len(data),'sha256':sha(data)},'files':files}
(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(totals));print('Verified',len(files),'receipts;',len(data),'archive bytes')
