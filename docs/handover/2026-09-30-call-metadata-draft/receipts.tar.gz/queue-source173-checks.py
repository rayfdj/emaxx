from pathlib import Path
import json,subprocess,sys,time
p=Path(__file__).parent.resolve()
for step in ['check','fmt','clippy','diff']:
 deadline=time.monotonic()+1800
 while time.monotonic()<deadline:
  f=p/f'source173-{step}-result.json'
  try:r=json.loads(f.read_text())
  except (FileNotFoundError,json.JSONDecodeError):time.sleep(2);continue
  assert r['exit_code']==0 and r['source_unchanged'],(step,r)
  break
 else:raise RuntimeError(f'{step} did not complete')
for command in [[sys.executable,str(p/'test-retention.py'),'173','gate'],[sys.executable,str(p/'test-retention.py'),'173','release'],[sys.executable,str(p/'build-retention.py'),'173']]:
 code=subprocess.call(command)
 if code:sys.exit(code)
