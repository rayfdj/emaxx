from pathlib import Path
import gzip, hashlib, io, json, tarfile

p = Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28')
root = p.parents[2]
out = root / 'docs/handover/2026-09-29-hash-ordering-repair'
sha = lambda data: hashlib.sha256(data).hexdigest()
manifest = json.loads((p / 'source139-manifest.json').read_text())
assert all(sha((root / name).read_bytes()) == digest for name, digest in manifest.items())
for stage in ['check', 'fmt', 'clippy', 'diff', 'debug-build', 'debug-selected', 'release-build', 'release-selected']:
    result = json.loads((p / ('source139-' + stage + '-result.json')).read_text())
    assert result['exit_code'] == 0 and result['source_unchanged']
for profile in ['debug', 'release']:
    checked = json.loads((p / ('source139-' + profile + '-selected-inventory-check.json')).read_text())
    assert checked['expected'] == 154 and checked['process_exit_code'] == 0
    assert checked['summary'] == 'test result: ok. 154 passed; 0 failed; 0 ignored;'
    assert sha((p / ('source139-' + profile + '-libtest')).read_bytes()) == checked['binary_unchanged']

selected = {}
suffixes = {'.json', '.py', '.rs', '.el', '.md', '.patch', '.log', '.txt', '.stdout', '.stderr', '.expected'}
for f in p.iterdir():
    if not f.is_file() or f.suffix not in suffixes:
        continue
    include = f.name.startswith(('source135-full-gate-', 'source135-complete-gate-', 'linux-27effbdd-', 'source133-before139-ordinary-hash-value-ordering'))
    include |= f.name.startswith('source139-') and 'full-gate' not in f.name
    include |= f.name in ['source139.patch', 'source135-full-gate.log', 'package-hash-ordering-repair.py',
                         'test-hash-ordering.py', 'release-hash-ordering.py', 'run-source139-full-gate.py',
                         'check-hash-migration.py', 'static-hash-migration.py', 'build-hash-ordinary.py',
                         'compare-source139-hash.py', 'compare-hash-value-ordering.py', 'hash-value-ordering.el']
    include |= f.name.startswith('hash-') and f.suffix in {'.el', '.expected'}
    if include:
        selected[f.name] = f
for folder in ['full-gate-source135', 'linux-27effbdd-full-artifacts']:
    directory = p / folder
    assert directory.is_dir(), directory
    for f in directory.rglob('*'):
        if f.is_file() and f.name != 'libtest' and f.suffix not in {'.pdmp', '.eln', '.elc'}:
            selected[str(f.relative_to(p))] = f

out.mkdir(exist_ok=False)
files = []
with (out / 'receipts.tar.gz').open('xb') as output:
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, f in sorted(selected.items()):
                data = f.read_bytes()
                info = tarfile.TarInfo(name)
                info.mode, info.size = 0o644, len(data)
                archive.addfile(info, io.BytesIO(data))
                files.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
with tarfile.open(out / 'receipts.tar.gz', 'r:gz') as archive:
    assert archive.getnames() == [f['path'] for f in files]
    for f in files:
        data = archive.extractfile(f['path']).read()
        assert len(data) == f['bytes'] and sha(data) == f['sha256']
data = (out / 'receipts.tar.gz').read_bytes()
record = {
    'scope': 'Both source135 complete-gate failures and source139 hash-table ordering repair, selected validation and nine exact ordinary GNU comparisons.',
    'qualification': 'Source135 macOS2260pass1fail and Linux2268pass1fail; three later library groups and all later Cargo stages unexecuted. Source139 strictstatic and154debug/154release pass with original assertions unchanged. All nine ordinary comparisons pass. Fresh full gates are separate; no complete-source or frozen/performance certification.',
    'binary_policy': 'Large executable/images remain local or in linked CI artifacts; original hashes retained here. No portable binary or frozen Darwin identity claim.',
    'archive': {'path': 'receipts.tar.gz', 'format': 'gzip-compressed POSIX tar', 'bytes': len(data), 'sha256': sha(data)},
    'source_manifest': 'source139-manifest.json', 'files': files,
}
(out / 'manifest.json').write_text(json.dumps(record, indent=2) + '\n')
print('Verified', len(files), 'receipts;', len(data), 'archive bytes')
