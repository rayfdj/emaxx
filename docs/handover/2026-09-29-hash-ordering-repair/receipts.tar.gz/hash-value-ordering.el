(progn
  (define-hash-table-test
    'ordering-no-callback
    (lambda (_a _b) (error "ordering called the equality callback"))
    (lambda (_a) (error "ordering called the hash callback")))
  (let ((first (make-hash-table :test 'eq :size 1))
        (second (make-hash-table :test 'equal :size 64))
        (custom (make-hash-table :test 'ordering-no-callback)))
    (puthash 'first '(7 . 9) first)
    (dotimes (i 37) (puthash (list i) (vector i) second))
    (garbage-collect)
    (list (value< first first)
          (value< first second)
          (value< second first)
          (value< custom first)
          (value< (list first 1) (list second 2))
          (value< (vector first 2) (vector second 1))
          (condition-case condition
              (value< first 17)
            (error (list (car condition)
                         (eq (nth 1 condition) first)
                         (eq (nth 2 condition) 17)))))))
