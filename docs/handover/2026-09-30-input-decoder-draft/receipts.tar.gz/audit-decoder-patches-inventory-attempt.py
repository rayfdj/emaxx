from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile
import tempfile

p = Path(__file__).parent.resolve()
repository = p.parents[2]
base = "ebfdbf9547b76e23013f8ce70f417aed02a744c2"
archive = subprocess.check_output(
    ["git", "archive", base, "--", "src", "tests", "Cargo.toml",
     "Cargo.lock", "build.rs", ".cargo"], cwd=repository)
sha = lambda data: hashlib.sha256(data).hexdigest()
results = []
for tag in ["source175", "source176", "source177"]:
    manifest = json.loads((p / (tag + "-manifest.json")).read_text())
    patch = p / (tag + "-complete.patch")
    with tempfile.TemporaryDirectory(prefix=tag + "-replay-", dir="/private/tmp") as directory:
        root = Path(directory)
        with tarfile.open(fileobj=io.BytesIO(archive)) as source:
            for member in source:
                relative = Path(member.name)
                assert not relative.is_absolute() and ".." not in relative.parts
                if member.isdir():
                    continue
                assert member.isfile(), member.name
                target = root / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(source.extractfile(member).read())
        subprocess.run(["git", "apply", "--check", str(patch)], cwd=root, check=True)
        subprocess.run(["git", "apply", str(patch)], cwd=root, check=True)
        actual = {str(f.relative_to(root)): sha(f.read_bytes())
                  for f in root.rglob("*") if f.is_file()}
        assert actual == manifest, (tag, sorted(set(actual) ^ set(manifest)),
                                    [name for name in manifest if actual.get(name) != manifest[name]])
    results.append({"source": tag, "base_commit": base,
                    "complete_patch": patch.name, "patch_sha256": sha(patch.read_bytes()),
                    "manifest_sha256": sha((p / (tag + "-manifest.json")).read_bytes()),
                    "inputs_replayed_and_verified": len(manifest), "passed": True})
with (p / "decoder-patches-replay-audit.json").open("x") as stream:
    json.dump({"results": results, "qualification": "Patch replay and exact compiled-input identity only; validation results remain separately recorded."}, stream, indent=2)
print(json.dumps(results, indent=2))
