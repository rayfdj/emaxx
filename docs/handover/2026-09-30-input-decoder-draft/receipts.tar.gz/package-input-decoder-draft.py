from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import tarfile
import time

p = Path(__file__).parent.resolve()
root = p.parents[2]
checkout = p.parent / "recovered-2026-09-30/decoder/emaxx"
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read("source177-manifest.json")
assert all(sha((checkout / name).read_bytes()) == digest for name, digest in manifest.items())
assert all(item["passed"] for item in read("decoder-patches-replay-audit.json")["results"])
assert len(re.findall(r"^warning: function `", (p / "source175-check.log").read_text(), re.M)) == 6
assert read("source176-gate-selected-result.json")["exit_code"] == 101
old_log = (p / "source176-gate-selected.log").read_text()
assert "test result: FAILED. 304 passed; 1 failed; 0 ignored;" in old_log
assert "batch::tests::xt_mouse_read_key_discards_the_unbound_down_event" in old_log
assert not read("source176-reader-contract-diagnostic-result.json")["matches_gnu_stdout"]
closed = []
for stage in ["check", "fmt", "clippy", "diff", "gate-build", "gate-selected",
              "release-build", "release-selected", "ordinary-build", "ordinary-image"]:
    result = p / ("source177-" + stage + "-result.json")
    if result.exists():
        value = json.loads(result.read_text())
        assert value["exit_code"] == 0 and value["source_unchanged"], (stage, value)
        closed.append(stage)
for profile in ["gate", "release"]:
    if profile + "-selected" not in closed:
        continue
    stem = "source177-" + profile + "-selected"
    command = read(stem + "-command.json")
    names = command["selected_inventory"]
    log = (p / (stem + ".log")).read_text()
    assert len(names) == len(set(names)) == 306
    assert re.findall(r"^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;", log, re.M) == [("ok", "306", "0", "0")]
    starts = list(re.finditer(r"^test (\S+) \.\.\. ", log, re.M))
    assert sorted(item[1] for item in starts) == sorted(names)
    for index, item in enumerate(starts):
        end = starts[index + 1].start() if index + 1 < len(starts) else log.rindex("test result:")
        assert log[item.end():end].strip().endswith("ok"), item[1]
    assert sha((p / ("source177-" + profile + "-libtest")).read_bytes()) == command["binary_sha256"]

suffixes = {".json", ".log", ".txt", ".py", ".patch", ".el", ".expected", ".stdout", ".stderr", ".d"}
helpers = {"audit-decoder-patches.py", "audit-decoder-patches-initial.py",
           "audit-decoder-patches-inventory-attempt.py", "check-decoder.py",
           "static-decoder.py", "test-decoder.py", "test-decoder176.py",
           "test-decoder177.py", "build-decoder.py", "queue-source177-validation.py",
           "compare-recovered-continuation-fixtures.py", "package-input-decoder-draft.py",
           "source-dependency-coverage-audit.json", "source174-supplemental-inputs.json",
           "source174-gate-rustc-dependencies.d", "source174-linux-validation-launch.json"}
files = {}
for f in p.iterdir():
    if not f.is_file() or f.suffix not in suffixes:
        continue
    name = f.name
    include = (name.startswith(("source175-", "source176-", "decoder-mouse-", "decoder-patches-", "input-decode-", "source174-ordinary-input-decode-"))
               or name in helpers or name == "source175.patch")
    if name.startswith("source177-"):
        include = name in {"source177-base.json", "source177-manifest.json", "source177-complete.patch",
                           "source177-supplemental-inputs.json", "source177-gate-rustc-dependencies.d",
                           "source177-validation-launch.json"}
        include |= any(name.startswith("source177-" + stage + "-") or name == "source177-" + stage + ".log" for stage in closed)
        for profile in ["gate", "release"]:
            if profile + "-selected" in closed and name == "source177-" + profile + "-inventory.txt":
                include = True
    if include:
        files[name] = f

out = root / "docs/handover/2026-09-30-input-decoder-draft"
out.mkdir(exist_ok=False)
inventory = []
with (out / "receipts.tar.gz").open("xb") as stream:
    with gzip.GzipFile(fileobj=stream, mode="wb", mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode="w") as archive:
            for name, f in sorted(files.items()):
                data = f.read_bytes()
                info = tarfile.TarInfo(name)
                info.mode = 0o644
                info.size = len(data)
                archive.addfile(info, io.BytesIO(data))
                inventory.append({"path": name, "bytes": len(data), "sha256": sha(data)})
with tarfile.open(out / "receipts.tar.gz", "r:gz") as archive:
    assert archive.getnames() == [item["path"] for item in inventory]
    for item in inventory:
        data = archive.extractfile(item["path"]).read()
        assert sha(data) == item["sha256"] and len(data) == item["bytes"]
data = (out / "receipts.tar.gz").read_bytes()
record = {
    "status": "unfinished isolated input-decoder draft; not applied to production",
    "source": "source177", "base_commit": "ebfdbf9547b76e23013f8ce70f417aed02a744c2",
    "recorded_rust_test_build_inputs": len(manifest), "supplemental_embedded_inputs": 4,
    "complete_patch": "source177-complete.patch", "closed_source177_stages": closed,
    "captured_unix": time.time(),
    "preserved_failures": {"source175": "six dead-code warnings", "source176": "304 passes and one unchanged XTerm mouse assertion failure; ordinary executable repeats raw ESC failure",
                           "reader_contract": "source176 drops generated sequence suffixes, lacks case fallback, and accepts a non-string prompt; zero process exits do not make these GNU comparisons pass"},
    "remaining": ["Complete source177 gate/release/ordinary validation", "Repair full generated-sequence return, case fallback and reader argument semantics", "Share incremental decoding with terminal and minibuffer command loops", "Complete final-source validation, representation, allocation accounting, adversarial audit and locked performance goal"],
    "qualification": "Closed receipts only; running logs excluded. Complete patches include untracked files and replay the original recorded inventories. The legacy manifest scanner omitted four embedded inputs; their supplemental hashes match the recorded base and current root, but were checked after the original pre-run manifests. GNU is source/ABI matched, not the frozen Darwin executable. No full correctness, performance or goal-completion claim.",
    "archive": {"path": "receipts.tar.gz", "bytes": len(data), "sha256": sha(data)}, "files": inventory,
}
(out / "manifest.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({key: value for key, value in record.items() if key != "files"}, indent=2))
