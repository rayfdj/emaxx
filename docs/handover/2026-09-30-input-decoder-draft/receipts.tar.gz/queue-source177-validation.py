from pathlib import Path
import hashlib,json,subprocess,sys,time
p=Path(__file__).parent.resolve()
root=p.parent/'recovered-2026-09-30/decoder/emaxx'
manifest=json.loads((p/'source177-manifest.json').read_text())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def unchanged():return all(sha(root/f)==h for f,h in manifest.items())
steps=[['check-decoder.py','177'],['static-decoder.py','177'],['test-decoder177.py','177','gate'],['test-decoder177.py','177','release'],['build-decoder.py','177'],['compare-recovered-continuation-fixtures.py','source177',str(root),'input-decode-general','input-decode-extra','input-decode-pipeline','input-decode-xt-setup']]
results=[]
for args in steps:
    assert unchanged()
    run=subprocess.run([sys.executable,str(p/args[0]),*args[1:]],check=False)
    results.append({'script':args,'exit_code':run.returncode,'source_unchanged':unchanged()})
    if run.returncode or not unchanged():break
with (p/'source177-selected-validation-result.json').open('x') as f:json.dump({'steps':results,'all_completed':len(results)==len(steps),'source_unchanged':unchanged(),'completed_unix':time.time(),'qualification':'Selected isolated draft validation only; no complete compatibility or performance claim.'},f,indent=2)
raise SystemExit(0 if len(results)==len(steps) and all(r['exit_code']==0 and r['source_unchanged'] for r in results) else 1)
