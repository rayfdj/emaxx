(progn
                     (require 'xt-mouse)
                     (require 'cl-lib)
                     (let ((width (frame-width))
                           (height (frame-height)))
                       (unwind-protect
                           (progn
                             (set-frame-width nil (max width 2000))
                             (set-frame-height nil (max height 2000))
                             (cl-letf (((terminal-parameter nil 'xterm-mouse-x) nil)
                                       ((terminal-parameter nil 'xterm-mouse-y) nil)
                                       ((terminal-parameter nil 'xterm-mouse-last-down) nil)
                                       ((terminal-parameter nil 'xterm-mouse-last-click) nil))
                               (unless xterm-mouse-mode
                                 (cl-letf (((symbol-function 'terminal-name)
                                            (lambda (&optional _) "fake-terminal")))
                                   (xterm-mouse-mode)))
                               (unwind-protect
                                   (let* ((unread-command-events
                                           (append "\e[M%\xD9\x81"
                                                   "\e[M'\xD9\x81" nil))
                                          (key (read-key)))
                                     (list (car key)
                                           (nth 2 (cadr key))
                                           unread-command-events))
                                 (xterm-mouse-mode 0))))
                         (set-frame-width nil width)
                         (set-frame-height nil height))))
