from pathlib import Path
root=Path('/private/tmp/emaxx-runtime-frames-gsnnjxa_/emaxx')
p=root/'src/lisp/native_comp/runtime.rs';s=p.read_text()
s=s.replace('        assert!(crate::lisp::primitives::keymap_record_id(&interpreter, &child).is_none());','        assert_eq!(child.car().expect("native cons head"), Value::symbol("no-longer-a-keymap"));')
s=s.replace('        // Read without going through a primitive that synchronizes the\n        // derived keymap record first, as key-binding\'s internal walkers do.', '        // Internal readers see the same native-written words directly.')
s=s.replace('        // The historical selector required eager rebuilding of the private\n        // record. With direct stores, a reader must consult the actual list\n        // or validate its derived view before using it.', '        // Both internal readers and Lisp lookup see the actual native store.')
a=s.index('        let keymap_id = crate::lisp::primitives::keymap_record_id(&interpreter, &keymap)'); b=s.index('\n    }',a)
s=s[:a]+'''        // Reading a keymap must preserve its spine and binding pair identity.
        assert!(keymap.cdr().expect("actual tail").eq_value(tail));
        let entry = tail.car().expect("actual binding");
        assert_eq!(entry.car().expect("event"), Value::symbol("Chinese"));
        assert_eq!(entry.cdr().expect("definition"), definition);
        assert!(tail.cdr().expect("one binding").is_nil());
'''+s[b:]; p.write_text(s)
p=root/'src/lisp/primitives/pdumper/tests.rs';s=p.read_text()
s=s.replace('            (define-key m "\\C-c" \'car))','            (define-key m "\\C-c" \'car)\n            (setq zz-image-child m zz-image-parent p))')
assert 'setq zz-image-child m zz-image-parent p' in s
a=s.index('    // The keymap facade records came through as a group'); b=s.index('\n}\n\n#[test]',a)
s=s[:a]+'''    // Actual Lisp roots carry both maps; the restored child shares the
    // parent's cons cells. Collection must preserve both while reachable.
    let form = crate::lisp::reader::Reader::new(
        r#"(progn (garbage-collect)
           (list (keymapp zz-image-child) (lookup-key zz-image-child "\\C-c")
                 (keymapp (keymap-parent zz-image-child))
                 (lookup-key zz-image-child "\\M-q")
                 (eq (keymap-parent zz-image-child) zz-image-parent)
                 (eq (nthcdr 2 zz-image-child) zz-image-parent)))"#,
    ).read().expect("probe parses").expect("a form");
    let answer = target.eval(&form, &mut crate::lisp::types::Env::new())
        .expect("restored maps remain live");
    assert_eq!(printed(&mut target, &answer), "(t car t ignore t t)");
'''+s[b:];p.write_text(s)
