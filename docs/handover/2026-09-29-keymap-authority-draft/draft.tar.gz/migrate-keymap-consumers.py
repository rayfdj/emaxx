from pathlib import Path
root=Path('/private/tmp/emaxx-runtime-frames-gsnnjxa_/emaxx')
def transform(name,action):
 p=root/name; s=p.read_text(); p.write_text(action(s))
def between(s,a,b,new=''):
 i=s.index(a); j=s.index(b,i); return s[:i]+new+s[j:]
def remove_fn(s,marker):
 i=s.index(marker); k=s.index('{',i); depth=1; j=k+1
 while depth:
  depth += (s[j]=='{')-(s[j]=='}'); j+=1
 return s[:i]+s[j:].lstrip('\n')
def values(s):
 return s.replace('// termination the same way keymap_records_equal already does; without', '// termination across repeated object pairs; without')
transform('src/lisp/primitives/values.rs',values)
def eval_file(s):
 s=s.replace('    /// Identity-bearing host facade whose public Elisp representation is a\n    /// list.  GNU itself therefore never exposes this as a pseudovector.\n    Keymap,\n','')
 s=s.replace('            // Keymaps are Lisp cons structures in GNU, not pseudovectors.\n            Self::Keymap => 0,\n','')
 s=s.replace('            self.forget_keymap_public_view(id);\n','')
 s=s.replace('            if let Some(slot) = self.keymap_bindings_cache.get_mut().get_mut(index) {\n                *slot = None;\n            }\n','')
 s=s.replace('        for record in self.records.iter().flatten() {\n            if record.kind == RecordKind::Keymap {\n                mark(&Value::Record(*record));\n            }\n        }\n','')
 s=s.replace("    /// loaded-units table and the subrs' unit slots), and the keymap\n    /// facade records (not C: the facade lives while the process does).", "    /// loaded-units table and the subrs' unit slots).")
 s=s.replace('        clone.keymap_bindings_cache.get_mut().clear();\n','')
 s=between(s,'        // The public-cons registry for keymap records', '        // Identity-bearing keys acquire new addresses')
 s=between(s,'    /// Runtime keymaps keep stable record identity', '    /// The ID of the current buffer.')
 s=between(s,'    /// Materialized, ordered keymap bindings per keymap record', '    /// Recycled operand stacks')
 for field in ['keymap_public_cons_owners', 'keymap_public_cons_ids','keymap_public_view_watch']:
  s=s.replace('            '+field+': HashMap::new(),\n','')
 s=s.replace('            keymap_bindings_cache: std::cell::RefCell::new(Vec::new()),\n','')
 s=s.replace('Some("visual-line-mode-map")', 'Value::string("visual-line-mode-map")')
 s=s.replace('Some("minibuffer-local-map")', 'Value::string("minibuffer-local-map")')
 s=s.replace('Some("input-decode-map")', 'Value::string("input-decode-map")')
 s=s.replace('make_runtime_keymap(&mut interp, Some(name))','make_runtime_keymap(&mut interp, Value::string(name))')
 return s
transform('src/lisp/eval.rs',eval_file)
def runtime(s):
 s=s.replace("        // or materialized keymap index for this record can no longer be\n        // trusted (see bytecode::vm and primitives::keymap_direct_bindings).", "        // for this record can no longer be trusted (see bytecode::vm).")
 s=between(s,'        if let Some(slot) = (id as usize)\n            .checked_sub(1)\n            .and_then(|index| self.keymap_bindings_cache', '        // SAFETY: as `find_record')
 s=between(s,'    pub(crate) fn forget_keymap_public_view(', '    pub(crate) fn create_treesit_query(')
 return s
transform('src/lisp/eval/runtime.rs',runtime)
def roots(s):
 s=between(s,'    (\n        "keymap_public_cons_owners",','    (\n', '') if False else s
 for name in ['keymap_public_cons_owners','keymap_public_cons_ids','keymap_public_view_watch']:
  a=s.index('    (\n        "'+name+'",'); b=s.index('    ),',a)+7; s=s[:a]+s[b:]
 s=between(s,'        // Not GNU: a keymap is a list in GNU;', '        let mut doc_offsets')
 s=between(s,'                // The keymap records were installed by the loader', '                _ => {}')
 return s
transform('src/lisp/eval/dump_roots.rs',roots)
transform('src/lisp/primitives/pdumper/image.rs',lambda s:s.replace('    KeymapRecords = 55,','    // Former keymap facade root code 55 is unsupported.').replace('            55 => Self::KeymapRecords,\n',''))
transform('src/lisp/primitives/pdumper/context.rs',lambda s:s.replace('        RecordKind::Keymap => 20,\n','').replace('        20 => RecordKind::Keymap,','        // Former keymap facade record code 20 is unsupported.').replace('RecordKind::Closure | RecordKind::Font | RecordKind::Keymap', 'RecordKind::Closure | RecordKind::Font'))
transform('src/lisp/primitives/pdumper/load.rs',lambda s:s.replace('    interp.rebuild_keymap_public_views();\n',''))
transform('src/lisp/primitives/buffers.rs',lambda s:s.replace('                crate::lisp::eval::RecordKind::Keymap => "cons",\n',''))
transform('src/lisp/primitives/print.rs',lambda s:between(s,'                    // print.c has no keymap case at all:', '                    // print.c:2087.'))
def keys(s):
 s=s.replace('    } else if let Some(items) = keymap_list_items(interp, sequence)? {\n        Ok(items)\n','')
 s=between(s, '/// The copy of a keymap Emaxx owns through a runtime record', 'fn copy_keymap_1(')
 s=s.replace('    if let Some(id) = keymap_record_id(interp, keymap) {\n        return copy_runtime_keymap(interp, id, depth, env);\n    }\n','')
 s=s.replace('    if let Some(id) = keymap_record_id(interp, &keymap) {\n        return copy_runtime_keymap(interp, id, depth, env);\n    }\n','')
 return s
transform('src/lisp/primitives/keys.rs',keys)
def hash_insert(s):
 s=between(s,'pub(crate) fn keymap_list_items(', '#[cfg(test)]')
 s=between(s,'fn keymap_list_items_inner(', '#[derive(Clone)]\npub(crate) struct RuntimeKeymapBinding')
 s=s.replace('    pub(crate) after_prompt: bool,\n','')
 return s
transform('src/lisp/primitives/hash_insert.rs',hash_insert)
transform('src/lisp/primitives/sequences.rs',lambda s:between(s,'    if matches!(value.kind(), Kind::Record(_))','    if let Some(string)'))
def lists(s):
 s=between(s,'            "nconc" => {', '            "append" => {','            "nconc" => nconc_values(args),\n')
 s=between(s,'                    let projected;\n', '                    let is_last')
 s=s.replace('                    keymap_record_list_items(interp, &args[0])?\n                        .map(|items| items.len() as i64)\n                        .unwrap_or_else(|| safe_list_length(&args[0])),','                    safe_list_length(&args[0]),')
 for field in ['car','cdr']:
  s=s.replace('        value => runtime_keymap_public_view(interp, &value.value())\n            .and_then(|view| view.'+field+'().ok())\n            .unwrap_or(Value::Nil),','        _ => Value::Nil,')
  s=s.replace('    if let Some(view) = runtime_keymap_public_view(interp, &args[0]) {\n        view.'+field+'()\n    } else {\n        args[0]\n            .'+field+'()\n            .map_err(|_| wrong_type_argument("listp", args[0]))\n    }','    args[0].'+field+'().map_err(|_| wrong_type_argument("listp", args[0]))')
 s=s.replace('    if let Some(items) = keymap_record_list_items(interp, &args[1])? {\n        nth_list_element(&Value::list(items), &args[0])\n    } else {\n        nth_list_element(&args[1], &args[0])\n    }','    nth_list_element(&args[1], &args[0])')
 s=between(s,'    if let Some(items) = keymap_record_list_items(interp, &args[1])?', '    nthcdr_value(&args[0], &args[1])')
 s=between(s,'    let projected;\n    let alist = if let Some(items) = keymap_list_items', '    let mut seen =', '    let alist = &args[1];\n')
 for func in ['direct_car_safe','direct_cdr_safe','direct_nth','direct_nthcdr','direct_car','direct_cdr']:
  s=s.replace('fn '+func+'(\n    interp:', 'fn '+func+'(\n    _interp:')
 return s
transform('src/lisp/primitives/dispatch/lists.rs',lists)
def predicates(s):
 s=s.replace('                Ok(match keymap_list_items(interp, &args[0])? {\n                    Some(items) => Value::Integer(items.len() as i64),\n                    None => match proper_list_length(&args[0]) {\n                        Some(length) => Value::Integer(length as i64),\n                        None => Value::Nil,\n                    },\n                })','                Ok(match proper_list_length(&args[0]) {\n                    Some(length) => Value::Integer(length as i64),\n                    None => Value::Nil,\n                })')
 s=s.replace('\n                        || keymap_list_items(interp, &args[0])?.is_some()', '')
 return s
transform('src/lisp/primitives/dispatch/predicates.rs',predicates)
def collections(s):
 s=between(s,'                // GNU keymaps are ordinary cons lists.', '                if name == "take"', '                let list = args[1];\n')
 s=s.replace('                            if let Some(keymap_id) = keymap_id {\n                                sync_runtime_keymap_from_public_view(interp, keymap_id)?;\n                            }\n','')
 return s
transform('src/lisp/primitives/dispatch/collections.rs',collections)
def strings(s):
 s=s.replace('                    args.first()\n                        .and_then(string_like)\n                        .map(|string| string.text)\n                        .as_deref(),','                    args.first().copied().unwrap_or(Value::Nil),')
 s=between(s,'                crate::lisp::primitives::values::ensure_runtime_keymap_current', '                crate::lisp::primitives::keys::copy_keymap_value', '                // keymap.c:Fcopy_keymap copies own entries and shares the parent.\n')
 return s
transform('src/lisp/primitives/dispatch/strings.rs',strings)
def misc(s):
 s=s.replace('                keymap_arguments_current(interp, args)?;\n','').replace('    ensure_runtime_keymap_current(interp, keymap)?;\n','')
 s=between(s,'                if let Some(id) = keymap_record_id(interp, &args[0]) {', '                if let Ok(items)')
 s=between(s,'                // GNU\'s constructor returns the same Lisp keymap object', '            "map-keymap" => {', '''                let map = resolve_keymap_without_autoload(interp, &args[0], env)?;
                Ok(keymap_parent_value(interp, map, env))
            }
            "set-keymap-parent" => {
                need_args(name, args, 2)?;
                let map = resolve_keymap_without_autoload(interp, &args[0], env)?;
                let parent = if args[1].is_nil() { Value::Nil } else {
                    resolve_keymap_without_autoload(interp, &args[1], env)?
                };
                set_keymap_parent_value(interp, map, parent, env)
            }
''')
 s=between(s, "/// A keymap argument's record follows its public view", "/// The `symbol-function' primitive")
 s=s.replace('HashSet<(bool, usize)>','HashSet<usize>')
 return s
transform('src/lisp/primitives/dispatch/misc_keymaps.rs',misc)
def interactive(s):
 s=s.replace('matches!(value.kind(), Kind::Cons(_)) || keymap_record_id(interp, value).is_some()', 'matches!(value.kind(), Kind::Cons(_))')
 s=s.replace('super::keymap_record_id(', 'super::keymap_value_identity(')
 s=between(s,'            // A runtime keymap answers as its record identity;', '            if !matches!(menu.car()')
 s=between(s,'    let menu = {\n        if let Some(id) = super::keymap_value_identity', '    #[allow(clippy::type_complexity)]', '    let menu = *menu;\n')
 return s
transform('src/lisp/primitives/interactive.rs',interactive)
transform('src/lisp/primitives/dispatch/gui_actions.rs',lambda s:s.replace('        let projected = crate::lisp::primitives::public_keymap_value(interp, menu);\n','').replace('let mut tail = projected.cdr()', 'let mut tail = menu.cdr()'))
# Constructor call sites retain the prompt as an actual Lisp object.
for name in ['src/lisp/native_comp/runtime.rs','src/lisp/primitives/tests.rs']:
 transform(name,lambda s:s.replace('make_runtime_keymap(&mut interpreter, None)','make_runtime_keymap(&mut interpreter, Value::Nil)').replace('make_runtime_keymap(&mut interp, Some("test-map"))','make_runtime_keymap(&mut interp, Value::string("test-map"))'))
