(let* ((compressed (prin1-to-string (string 2 7 256)))
       (depth2 (concat "#^^[2 4096 " compressed " " compressed
                       (apply #'concat (make-list 30 " nil")) "]"))
       (depth1 (concat "#^^[1 0 nil " depth2
                       (apply #'concat (make-list 14 " nil")) "]"))
       (table (read (concat "#^[nil nil char-code-property-table nil " depth1
                            (apply #'concat (make-list 63 " nil"))
                            " nil nil nil nil nil]")))
       (control (copy-sequence table)))
  (list (equal table control)
        (char-table-range table '(4096 . 4351))
        (progn (aref control 4096) (equal table control))
        (progn (aref control 4224) (equal table control))))
