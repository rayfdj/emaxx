from pathlib import Path
import subprocess

p = Path(__file__).parent
root = '/private/tmp/emaxx-runtime-reader-streams/emaxx'
for driver in ['release-compatibility-final-focused.py', 'build-compatibility-final-repair.py']:
    subprocess.run(['python3', str(p / driver), '155'], check=True)
fixtures = [
    'keymap-parameterized-char-table', 'keymap-prefix-filter-count',
    'keymap-filter-effects', 'keymap-prefix-precedence',
    'keymap-lookup-argument-order', 'keymap-filter-error-unbound',
    'keymap-translated-sequence-validation', 'unwind-protected-payloads',
    'unwind-native-payloads', 'unwind-payload-reclamation',
    'keymap-description-context', 'keymap-menu-fallback',
    'keymap-menu-case-table-order', 'string-make-multibyte-identity',
]
subprocess.run(['python3', str(p / 'compare-continuation-fixtures.py'),
                'source155', root, *fixtures], check=True)
