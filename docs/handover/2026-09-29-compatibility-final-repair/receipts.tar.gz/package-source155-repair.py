from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

p = Path(__file__).parent
root = p.parents[2]
sha = lambda data: hashlib.sha256(data).hexdigest()
manifest = json.loads((p / 'source155-manifest.json').read_text())
assert all(sha((root / name).read_bytes()) == value for name, value in manifest.items())
for mode in ['debug', 'release']:
    failed = json.loads((p / f'source154-{mode}-selected-inventory-check.json').read_text())
    assert failed['expected'] == 383 and failed['process_exit_code'] == 101
    assert failed['summary'] == 'test result: FAILED. 382 passed; 1 failed; 0 ignored;'
    passed = json.loads((p / f'source155-{mode}-selected-inventory-check.json').read_text())
    assert passed['expected'] == 6 and passed['process_exit_code'] == 0
    assert passed['summary'] == 'test result: ok. 6 passed; 0 failed; 0 ignored;'
    assert sha((p / f'source155-{mode}-libtest').read_bytes()) == passed['binary_unchanged']
for stage in ['check', 'fmt', 'clippy', 'diff', 'debug-build', 'release-build',
              'ordinary-build', 'ordinary-image']:
    record = json.loads((p / f'source155-{stage}-result.json').read_text())
    assert record['exit_code'] == 0 and record['source_unchanged']
comparisons = list(p.glob('source155-ordinary-*-comparison.json'))
assert len(comparisons) == 14
assert all(json.loads(f.read_text())['passed'] for f in comparisons)
negative = json.loads((p / 'source153-ordinary-keymap-translated-sequence-valid-input-comparison.json').read_text())
assert not negative['passed'] and not negative['exact_match']
selected = {}
suffixes = {'.json', '.log', '.txt', '.stdout', '.stderr', '.el', '.expected', '.py', '.patch'}
drivers = {
    'compare-continuation-fixtures.py', 'run-source154-release-and-ordinary.py',
    'run-source155-release-and-ordinary.py', 'package-source155-repair.py',
    'keymap-translated-sequence-valid-input.el',
}
for f in p.iterdir():
    if not f.is_file() or f.suffix not in suffixes:
        continue
    keep = f.name.startswith(('source154-', 'source155-', 'source153-ordinary-keymap-translated-sequence-valid-input'))
    keep = keep and not f.name.startswith(('source155-full-', 'source155-gate-'))
    keep |= f.name in drivers or '-compatibility-final-' in f.name
    keep |= f.name in ['source154.patch', 'source155.patch']
    if keep:
        selected[f.name] = f
for dirname in ['linux-source153-nonlifo-replay-artifacts', 'linux-source153-nonlifo-backtrace-artifacts']:
    for f in (p / dirname).rglob('*'):
        if f.is_file() and f.suffix in suffixes:
            selected[str(f.relative_to(p))] = f
out = root / 'docs/handover/2026-09-29-compatibility-final-repair'
out.mkdir(exist_ok=False)
files = []
with (out / 'receipts.tar.gz').open('xb') as stream:
    with gzip.GzipFile(fileobj=stream, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, f in sorted(selected.items()):
                data = f.read_bytes()
                info = tarfile.TarInfo(name)
                info.mode = 0o644
                info.size = len(data)
                archive.addfile(info, io.BytesIO(data))
                files.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
with tarfile.open(out / 'receipts.tar.gz', 'r:gz') as archive:
    assert archive.getnames() == [f['path'] for f in files]
    for f in files:
        data = archive.extractfile(f['path']).read()
        assert len(data) == f['bytes'] and sha(data) == f['sha256']
data = (out / 'receipts.tar.gz').read_bytes()
record = {
    'source_manifest': 'source155-manifest.json',
    'production_commit': '72d98598',
    'published_commit': 'f237bfcf46f07d86c9006bbff445b5c5645dbdaf',
    'scope': 'Source155 strict checks, six focused debug and six release controls, fourteen exact ordinary GNU comparisons. Source154 passes 382 controls in each mode and fails the newly added fixture reader because of an extra trailing parenthesis; source155 corrects only that fixture input. The valid-input original parser mismatch is retained.',
    'native_failure_limit': 'Original source153 full Linux native non-LIFO failure remains unresolved by its isolated passes. Ordinary isolated replay uses the same 52a69e52 test executable as the failed full gate; debugger executable differs. Source155 uses the existing dead-stack helper but retains all original live/native/result and reclamation assertions. Exact original root attribution is not established.',
    'qualification': 'Complete source155 macOS/Linux Rust, Linux frozen and macOS terminal runs remain pending. Raw source154 failures are not recast as passes. Darwin GNU is source/ABI matched, not the frozen executable. Rebuild on another host; these receipts do not establish full architecture, final audit or performance completion.',
    'archive': {'path': 'receipts.tar.gz', 'bytes': len(data), 'sha256': sha(data)},
    'files': files,
}
(out / 'manifest.json').write_text(json.dumps(record, indent=2) + '\n')
print('Verified', len(files), 'receipts;', len(data), 'archive bytes')
