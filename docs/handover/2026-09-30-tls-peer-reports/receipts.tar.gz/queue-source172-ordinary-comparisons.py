from pathlib import Path
import json
import subprocess
import sys
import time

p = Path(__file__).parent.resolve()
deadline = time.monotonic() + 1800
while time.monotonic() < deadline:
    if (p / 'source172-ordinary-artifacts.json').exists():
        break
    time.sleep(2)
else:
    raise RuntimeError('ordinary TLS candidate build did not finish')
for tag in ['peer-report', 'tls-gc-replay']:
    subprocess.run([sys.executable, str(p / f'run-source172-{tag}.py')], check=True)
print('Both ordinary probes recorded; compare raw outcomes before claiming a pass.', flush=True)
