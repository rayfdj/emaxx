from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import tarfile

p = Path(__file__).parent.resolve()
root = p.parents[2]
checkout = p.parent / 'recovered-2026-09-30/tls/emaxx'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((p / name).read_text())
manifest = read('source172-manifest.json')
assert len(manifest) == 345
assert all(sha((checkout / name).read_bytes()) == digest for name, digest in manifest.items())
for stage in ['check', 'fmt', 'clippy', 'diff', 'debug-build', 'release-build', 'ordinary-build', 'ordinary-image']:
    result = read(f'source172-{stage}-result.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
for profile in ['debug', 'release']:
    stem = f'source172-{profile}-selected'
    result = read(stem + '-result.json')
    command = read(stem + '-command.json')
    assert result['exit_code'] == 0 and result['source_unchanged']
    inventory = command['selected_inventory']
    assert len(inventory) == len(set(inventory)) == 414
    log = (p / (stem + '.log')).read_text()
    summaries = re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', log, re.M)
    assert summaries == [('ok', '414', '0', '0')]
    starts = list(re.finditer(r'^test (\S+) \.\.\. ', log, re.M))
    assert sorted(item[1] for item in starts) == sorted(inventory)
    for index, item in enumerate(starts):
        end = starts[index + 1].start() if index + 1 < len(starts) else log.rindex('test result:')
        assert log[item.end():end].strip().endswith('ok'), item[1]
    assert sha((p / f'source172-{profile}-libtest').read_bytes()) == command['binary_sha256']
for tag, expected in [('peer-report', '((nil nil t t t t nil t) (nil nil t t t t nil t))'),
                      ('tls-gc-replay', '((open 9 (t t t t)) (open 9 (t t t t)))')]:
    result = read(f'source172-{tag}-comparison.json')
    for runner in ['gnu', 'emaxx']:
        item = result[runner]
        assert item['exit_code'] == 0 and not item['timed_out'] and item['inputs_unchanged']
        assert item['stdout'] == expected and item['stderr'] == ''
        assert (p / f'source172-{tag}-{runner}.stdout').read_text() == expected
        assert not (p / f'source172-{tag}-{runner}.stderr').read_bytes()
for name, item in read('source172-ordinary-artifacts.json').items():
    assert sha(Path(name).read_bytes()) == item['sha256']
    assert sha(Path(item['immutable_copy']).read_bytes()) == item['sha256']
negative = read('source171-inplace-peer-report-mutation-comparison.json')
assert all(item['exit_code'] == 0 and not item['timed_out'] and item['inputs_unchanged'] for item in negative.values())
assert negative['gnu']['stdout'] == '((nil nil t t t t nil t) (nil nil t t t t nil t))'
assert negative['emaxx']['stdout'] == '((nil nil t t t t nil nil) (nil nil t t t t nil nil))'

out = root / 'docs/handover/2026-09-30-tls-peer-reports'
out.mkdir(exist_ok=False)
suffixes = {'.json', '.log', '.txt', '.stdout', '.stderr', '.py', '.patch', '.el', '.expected'}
files = {}
for f in p.iterdir():
    if f.is_file() and f.suffix in suffixes and (
        f.name.startswith(('source171-', 'source172-', 'source170-peer-report-'))
        or f.name in ['tls-report-mutation.el', 'package-source172-tls-report.py',
                      'check-tls-report.py', 'static-tls-report.py', 'check-prepared-tls-report.py',
                      'test-tls-report.py', 'release-tls-report.py', 'test-tls-report172.py',
                      'release-tls-report172.py', 'build-tls-report.py',
                      'queue-source171-checks.py', 'queue-source172-checks.py',
                      'run-source170-peer-report.py', 'run-source171-peer-report.py',
                      'run-source171-inplace-peer-report.py', 'run-source171-peer-report-mutation.py',
                      'run-source171-inplace-peer-report-mutation.py', 'run-source171-tls-gc-replay.py',
                      'run-source171-inplace-tls-gc-replay.py', 'run-source172-peer-report.py',
                      'run-source172-tls-gc-replay.py', 'queue-source171-ordinary-comparisons.py',
                      'queue-source172-ordinary-comparisons.py']
    ):
        files[f.name] = f
inventory = []
with (out / 'receipts.tar.gz').open('xb') as stream:
    with gzip.GzipFile(fileobj=stream, mode='wb', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w') as archive:
            for name, f in sorted(files.items()):
                data = f.read_bytes()
                info = tarfile.TarInfo(name)
                info.mode = 0o644
                info.size = len(data)
                archive.addfile(info, io.BytesIO(data))
                inventory.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
with tarfile.open(out / 'receipts.tar.gz', 'r:gz') as archive:
    assert archive.getnames() == [item['path'] for item in inventory]
    for item in inventory:
        data = archive.extractfile(item['path']).read()
        assert sha(data) == item['sha256'] and len(data) == item['bytes']
data = (out / 'receipts.tar.gz').read_bytes()
record = {
    'status': 'source172 selected validation passed; complete final-source validation required',
    'base_commit': read('source172-base.json')['commit'],
    'compiled_inputs': 345, 'debug_passed': 414, 'release_passed': 414,
    'ordinary_gnu_comparisons': 2,
    'preserved_failures': [
        'Source170 shares peer reports where GNU returns independent objects.',
        'Source171 removes the cache but its returned cipher string ignores mutation; the stronger source172 fixture adds a mutation assertion without weakening the original GC or independence contracts.',
        'Moving source171 executable/image copies changes relative native-module paths; three invocations fail before Lisp evaluation. Replays at the original unchanged paths preserve all outputs.',
        'The first source172 compiler-check helper stops on an already created manifest before invoking Cargo; the corrected helper verifies that same manifest and the actual compiler check passes.',
    ],
    'qualification': 'No existing assertion, selector, expected outcome or timeout is weakened. Source170 complete macOS Rust and Linux frozen failures remain recorded separately. Input decoding, post-deinit TLS behavior, source173 call metadata, representation completion, final audit, physical accounting and locked performance remain unfinished. GNU is source/ABI matched, not the Darwin frozen executable. No performance claim.',
    'archive': {'path': 'receipts.tar.gz', 'bytes': len(data), 'sha256': sha(data)},
    'files': inventory,
}
(out / 'manifest.json').write_text(json.dumps(record, indent=2) + '\n')
print(f'Audited {len(inventory)} receipts; {len(data)} archived bytes; 414 debug + 414 release + 2 ordinary comparisons.')
