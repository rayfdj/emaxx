from pathlib import Path
import hashlib,json,os,socket,subprocess,time
p=Path(__file__).parent.resolve()
r=p.parent/'recovered-2026-09-30'
with socket.socket() as reservation:
 reservation.bind(('127.0.0.1',0));port=reservation.getsockname()[1]
args=['gnutls-serv','--quiet','--echo','--priority','NORMAL:+ANON-ECDH','--port',str(port)]
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
source=(r/'tls/emaxx/tests/fixtures/process-tls-gc.el').read_text().replace('@PORT@',str(port))
fixture=p/'source171-tls-gc-replay.el'
with fixture.open('x') as f:f.write(source)
with (p/'source171-tls-gc-replay-server.log').open('x') as log:
 server=subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
 try:
  for attempt in range(100):
   try:
    with socket.create_connection(('127.0.0.1',port),timeout=.1):break
   except OSError:
    assert server.poll() is None;time.sleep(.02)
  else:raise RuntimeError('test server not ready')
  outcomes={}
  for runner,binary in [('gnu',r/'emacs/src/emacs'),('emaxx',p/'source171-ordinary-emaxx')]:
   tag=f'source171-tls-gc-replay-{runner}'
   inputs={str(f):sha(f) for f in [binary,binary.with_suffix('.pdmp'),fixture]}
   cmd=[str(binary),'-Q','--batch','--eval','(prin1 '+source.strip()+')']
   env={'EMAXX_GC_VERIFY':'1','RUST_BACKTRACE':'1'}
   with (p/(tag+'.command.json')).open('x') as f:json.dump({'command':cmd,'inputs':inputs,'environment_override':env,'server_command':args},f,indent=2)
   start=time.monotonic()
   try:
    run=subprocess.run(cmd,cwd=p,env={**os.environ,**env},stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120)
    code,out,err,timed=run.returncode,run.stdout,run.stderr,False
   except subprocess.TimeoutExpired as error:code,out,err,timed=None,error.stdout or b'',error.stderr or b'',True
   for suffix,data in [('stdout',out),('stderr',err)]:
    with (p/(tag+'.'+suffix)).open('xb') as f:f.write(data)
   result={'exit_code':code,'timed_out':timed,'elapsed_seconds':time.monotonic()-start,'inputs_unchanged':all(sha(Path(f))==h for f,h in inputs.items()),'stdout':out.decode(errors='replace'),'stderr':err.decode(errors='replace')}
   with (p/(tag+'.result.json')).open('x') as f:json.dump(result,f,indent=2)
   outcomes[runner]=result
   print(runner,result,flush=True)
 finally:
  server.terminate();server.wait(timeout=10)
with (p/'source171-tls-gc-replay-comparison.json').open('x') as f:json.dump(outcomes,f,indent=2)
