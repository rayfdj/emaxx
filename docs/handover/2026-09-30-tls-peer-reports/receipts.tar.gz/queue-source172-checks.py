from pathlib import Path
import json,subprocess,sys,time
p=Path(__file__).parent.resolve()
for step in ['check','fmt','clippy','diff']:
 deadline=time.monotonic()+1800
 while time.monotonic()<deadline:
  f=p/f'source172-{step}-result.json'
  try:r=json.loads(f.read_text())
  except (FileNotFoundError,json.JSONDecodeError):time.sleep(2);continue
  assert r['exit_code']==0 and r['source_unchanged'],(step,r)
  break
 else:raise RuntimeError(f'{step} did not complete')
for script in ['test-tls-report172.py','release-tls-report172.py','build-tls-report.py']:
 code=subprocess.call([sys.executable,str(p/script),'172'])
 if code:sys.exit(code)
