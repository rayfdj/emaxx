from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys,time
p=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28')
root=Path('/private/tmp/emaxx-runtime-audit-followup/emaxx')
tag='source'+sys.argv[1]
manifest=json.loads((p/(tag+'-manifest.json')).read_text())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def unchanged():return all(sha(root/name)==value for name,value in manifest.items())
def save(suffix,data):
    with (p/(tag+'-'+suffix+'.json')).open('x') as stream:json.dump(data,stream,indent=2);stream.write('\n')
env={'CARGO_TARGET_DIR':'/private/tmp/emaxx-runtime-audit-validation','CARGO_BUILD_JOBS':'1',
     'RUST_MIN_STACK':'134217728','RUST_TEST_THREADS':'1','EMAXX_GC_VERIFY':'1',
     'EMAXX_FIXTURE_IMAGE_DIR':str(p/'fixture-images'),
     'EMAXX_GNU_SOURCE_DIRECTORY':'/private/tmp/emaxx-runtime-gnu-20260928',
     'EMAXX_DUMP_SOURCE_DIRECTORY':'/private/tmp/emaxx-runtime-gnu-20260928',
     'EMACS_TEST_DIRECTORY':'/private/tmp/emaxx-runtime-gnu-20260928/test'}
def run(stage,command,extra=None):
    assert unchanged()
    save(stage+'-command',{'command':command,'working_directory':str(root),'environment_override':env,**(extra or {})})
    start=time.monotonic()
    with (p/(tag+'-'+stage+'.log')).open('x') as log:
        result=subprocess.run(command,cwd=root,env={**os.environ,**env},stdout=log,stderr=subprocess.STDOUT,timeout=3600)
    record={'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,'source_unchanged':unchanged()}
    save(stage+'-result',record)
    print(stage,json.dumps(record),flush=True)
    return result.returncode or (0 if record['source_unchanged'] else 2)
code=run('release-build',['cargo','test','--release','--locked','--all-features','--lib','--no-run','--message-format=json-render-diagnostics'])
if code:sys.exit(code)
artifacts=[]
for line in (p/(tag+'-release-build.log')).read_text().splitlines():
    try:item=json.loads(line)
    except json.JSONDecodeError:continue
    if item.get('reason')=='compiler-artifact' and item.get('profile',{}).get('test') and item.get('executable'):artifacts.append(item['executable'])
assert len(artifacts)==1
binary=p/(tag+'-release-libtest');assert not binary.exists();shutil.copy2(artifacts[0],binary)
listed=subprocess.run([str(binary),'--list','--format','terse'],cwd=root,env={**os.environ,**env},capture_output=True,text=True,check=True)
(p/(tag+'-release-inventory.txt')).write_text(listed.stdout)
inventory=[line[:-6] for line in listed.stdout.splitlines() if line.endswith(': test')]
filters=['dump_emacs_portable']
selected=[name for name in inventory if any(part in name for part in filters)]
assert selected and len(selected)==len(set(selected))
assert any(name.endswith('::dump_emacs_portable_restores_context_and_reports_native_image_limit') for name in selected)
code=run('release-selected',[str(binary),*filters,'--nocapture','--test-threads=1'],{'binary_sha256':sha(binary),'selected_inventory':selected})
text=(p/(tag+'-release-selected.log')).read_text()
match=re.search(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
if not code:
    assert match and match[1]=='ok' and int(match[2])==len(selected) and int(match[3])==int(match[4])==0
save('release-selected-inventory-check',{'expected':len(selected),'summary':match.group(0) if match else None,'binary_unchanged':sha(binary),'process_exit_code':code})
print(text[-5000:],flush=True)
sys.exit(code)
