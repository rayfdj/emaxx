from pathlib import Path
import gzip, hashlib, io, json, tarfile

p = Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28')
root = p.parents[2]
out = root / 'docs/handover/2026-09-29-hash-gate-repair'
sha = lambda data: hashlib.sha256(data).hexdigest()
manifest = json.loads((p / 'source135-manifest.json').read_text())
assert all(sha((root / name).read_bytes()) == digest for name, digest in manifest.items())
for stage in ['check', 'fmt', 'clippy', 'diff', 'debug-build', 'debug-selected', 'release-build', 'release-selected']:
    result = json.loads((p / ('source135-' + stage + '-result.json')).read_text())
    assert result['exit_code'] == 0 and result['source_unchanged']
for profile in ['debug', 'release']:
    checked = json.loads((p / ('source135-' + profile + '-selected-inventory-check.json')).read_text())
    assert checked['expected'] == 2 and checked['process_exit_code'] == 0
    assert checked['summary'] == 'test result: ok. 2 passed; 0 failed; 0 ignored;'
    assert sha((p / ('source135-' + profile + '-libtest')).read_bytes()) == checked['binary_unchanged']

selected = {}
suffixes = {'.json', '.py', '.rs', '.el', '.md', '.patch', '.log', '.txt', '.stdout', '.stderr', '.expected'}
for f in p.iterdir():
    if not f.is_file() or f.suffix not in suffixes:
        continue
    include = f.name.startswith(('source133-full-gate-', 'source133-complete-gate-', 'source133-core-', 'linux-d7994e6d-', 'linux-7672986e-', 'source119-linux-tail-'))
    include |= f.name.startswith('source135-') and 'full-gate' not in f.name
    include |= f.name == 'source135.patch'
    include |= f.name in ['package-hash-gate-repair.py', 'test-hash-dump-accounting.py', 'release-hash-dump-accounting.py', 'run-source135-full-gate.py', 'source133-full-gate.log']
    if include:
        selected[f.name] = f
for folder in ['full-gate-source133', 'linux-d7994e6d-full-artifacts', 'linux-7672986e-tail-artifacts', 'source133-core-native', 'source133-core-pilot-all']:
    directory = p / folder
    assert directory.is_dir(), directory
    for f in directory.rglob('*'):
        if f.is_file() and f.name != 'libtest' and f.suffix not in {'.pdmp', '.eln', '.elc'}:
            selected[str(f.relative_to(p))] = f

out.mkdir(exist_ok=False)
files = []
with (out / 'receipts.tar.gz').open('xb') as output:
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, f in sorted(selected.items()):
                data = f.read_bytes()
                info = tarfile.TarInfo(name)
                info.mode, info.size = 0o644, len(data)
                archive.addfile(info, io.BytesIO(data))
                files.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
with tarfile.open(out / 'receipts.tar.gz', 'r:gz') as archive:
    assert archive.getnames() == [f['path'] for f in files]
    for f in files:
        data = archive.extractfile(f['path']).read()
        assert len(data) == f['bytes'] and sha(data) == f['sha256']
data = (out / 'receipts.tar.gz').read_bytes()
record = {
    'scope': 'Both original source133 full-gate failures, source135 exact remembered-scalar assertion correction, all16 diagnostic workload results and the separate main119 Linux18-file tail.',
    'qualification': 'Source133 macOS2174pass1fail and Linux2182pass1fail; four later library groups and all later Cargo stages unexecuted. Source135 strictstatic and two debug/two release dump controls pass; its full gates remain separate. Diagnostic workload ratios1.31-8.55, no parity or controlled-speedup claim. Separate18-file tail does not clear failed main119 frozen run.',
    'binary_policy': 'Large executable/images remain local or in linked CI artifacts; original hashes retained here. No portable binary or frozen Darwin identity claim.',
    'archive': {'path': 'receipts.tar.gz', 'format': 'gzip-compressed POSIX tar', 'bytes': len(data), 'sha256': sha(data)},
    'source_manifest': 'source135-manifest.json', 'files': files,
}
(out / 'manifest.json').write_text(json.dumps(record, indent=2) + '\n')
print('Verified', len(files), 'receipts;', len(data), 'archive bytes')
