from pathlib import Path
import gzip, hashlib, io, json, tarfile
p=Path('/Users/nbmhqa186/projects/emaxx/target/runtime-goal/resume-2026-09-28');root=p.parents[2]
out=root/'docs/handover/2026-09-29-compatibility';sha=lambda data:hashlib.sha256(data).hexdigest()
manifest=json.loads((p/'source148-manifest.json').read_text());assert all(sha((root/f).read_bytes())==h for f,h in manifest.items())
for stage in ['check','fmt','clippy','diff','debug-build','debug-selected','release-build','release-selected','ordinary-build','ordinary-image']:
 d=json.loads((p/('source148-'+stage+'-result.json')).read_text());assert d['exit_code']==0 and d['source_unchanged']
for profile in ['debug','release']:
 check=json.loads((p/('source148-'+profile+'-selected-inventory-check.json')).read_text());command=json.loads((p/('source148-'+profile+'-selected-command.json')).read_text())
 assert check['expected']==len(command['selected_inventory'])==367 and check['process_exit_code']==0
 assert check['summary']=='test result: ok. 367 passed; 0 failed; 0 ignored;'
 assert sha((p/('source148-'+profile+'-libtest')).read_bytes())==check['binary_unchanged']==command['binary_sha256']
fixtures=['keymap-prefix-filter-count','keymap-filter-effects','keymap-prefix-precedence','keymap-lookup-argument-order','keymap-filter-error-unbound','unwind-protected-payloads','unwind-native-payloads','unwind-payload-reclamation','keymap-description-context']
for name in fixtures:
 d=json.loads((p/('source148-ordinary-'+name+'-comparison.json')).read_text());assert d['exact_match']
 assert all(r['exit_code']==0 and r['stderr_hex']=='' and r['inputs_unchanged'] for r in d['outcomes'].values())
old=json.loads((p/'source148-ordinary-keymap-case-comparisons.json').read_text());assert len(old)==3 and all(d['exact_match'] for d in old)
for name in ['keymap-tests','casefiddle-tests','gv-tests']:
 results=[]
 for side in ['gnu','emaxx']:
  d=json.loads((p/('source148-'+name+'-report-'+side+'.json')).read_text())
  result=json.loads((p/('source148-'+name+'-report-'+side+'.result.json')).read_text())
  assert result['exit_code']==0 and not result['timed_out'] and result['source_unchanged'] and result['inputs_unchanged']
  results.append([{k:v for k,v in entry.items() if k!='duration_ns'} for entry in d['results']])
 assert results[0]==results[1]
selected={};suffixes={'.json','.py','.rs','.el','.expected','.md','.patch','.log','.txt','.stdout','.stderr'}
for f in p.iterdir():
 if not f.is_file() or f.suffix not in suffixes:continue
 include=f.name.startswith(('source147','source148')) and 'full-gate' not in f.name
 include|=f.name.startswith(('main139-keymap-anonymous','source145-ordinary-keymap-anonymous'))
 include|=f.name in ['keymap-authority-next-step.md','keymap-anonymous-reclamation.el','keymap-filter-error-unbound.el','keymap-filter-error-unbound.expected','unwind-payload-reclamation.el','package-compatibility-checkpoint.py','compare-continuation-fixtures.py','check-combined-compatibility.py','test-combined-compatibility.py','release-combined-compatibility.py','static-compatibility-repairs.py','build-compatibility-ordinary.py','compare-keymap-case-fixtures.py','compare-keymap-description-context.py','diagnose-compatibility-reports.py']
 if include:selected[f.name]=f
out.mkdir(exist_ok=False);files=[]
with (out/'receipts.tar.gz').open('xb') as stream:
 with gzip.GzipFile(fileobj=stream,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as archive:
   for name,f in sorted(selected.items()):
    data=f.read_bytes();info=tarfile.TarInfo(name);info.mode=0o644;info.size=len(data);archive.addfile(info,io.BytesIO(data));files.append({'path':name,'bytes':len(data),'sha256':sha(data)})
with tarfile.open(out/'receipts.tar.gz','r:gz') as archive:
 assert archive.getnames()==[f['path'] for f in files]
 for f in files:
  data=archive.extractfile(f['path']).read();assert len(data)==f['bytes'] and sha(data)==f['sha256']
data=(out/'receipts.tar.gz').read_bytes()
(out/'manifest.json').write_text(json.dumps({'scope':'Combined source148 strict checks,367debug+367release,12exactordinaryGNUfixtures andthreeunchangedupstreamreport comparisons; original147failure and existingkeymapretentionfailure preserved.','qualification':'No new ignores or normalized semantic outputs. Report durations are excluded only from outcome equality. Full macOS/Linux and Linux frozen runs continue separately; source-matched GNU is not the frozen Darwin executable. Architecture and performance goal remains open.','source_manifest':'source148-manifest.json','candidate':'7cba6e526295277e5fd12e0ea98a4889f2a84e58','binary_policy':'Exact local executable/image identities retained; large binary copies remain local. Rebuild and validate on a new host.','archive':{'path':'receipts.tar.gz','bytes':len(data),'sha256':sha(data)},'files':files},indent=2)+'\n')
print('Verified',len(files),'receipts;',len(data),'archive bytes')
